#!/usr/bin/env python3
from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
FIG = ROOT / "figure"
OUT = RESULTS / "final_metric_and_novelty_tables"

ADACLIP_ROOT = RESULTS / "layer_recipe_retrained_all_20260502"
FAPROMPT_ROOT = RESULTS / "faprompt_layer_recipe_retrained_20260502"

MODE_ALIASES = {
    "B": ("baseline_txt", "baseline", "baseline_official", "baseline_maptopk"),
    "C": ("ted_calibrated", "branch_calibrated_alpha_1", "branch_calibrated_alpha_1.0", "branch_calibrated_alpha_0.5"),
}

RECIPES = [
    ("Full", "all4_official"),
    ("EL", "earlylate"),
    ("M2", "mid2"),
    ("L2", "last2"),
    ("L", "last"),
]


def load(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(value) -> float | None:
    if value is None:
        return None
    value = float(value)
    if math.isnan(value):
        return None
    return value * 100.0 if abs(value) <= 1.5 else value


def row_vals(summary: dict | None, mode: str) -> dict[str, float] | None:
    if summary is None:
        return None
    aliases = MODE_ALIASES[mode]
    rows = summary.get("rows", [])
    if isinstance(rows, list):
        for alias in aliases:
            for row in rows:
                if row.get("target_label") == "mean" and row.get("mode") == alias:
                    return {
                        "i_auc": pct(row.get("image_auroc", row.get("image_auc"))),
                        "p_auc": pct(row.get("pixel_auroc", row.get("pixel_auc"))),
                        "pro": pct(row.get("pixel_aupro", row.get("pixel_pro"))),
                        "ap": pct(row.get("pixel_ap")),
                    }
    mean = summary.get("mean", {})
    if isinstance(mean, dict):
        for alias in aliases:
            if alias in mean:
                row = mean[alias]
                return {
                    "i_auc": pct(row.get("image_auroc", row.get("image_auc"))),
                    "p_auc": pct(row.get("pixel_auroc", row.get("pixel_auc"))),
                    "pro": pct(row.get("pixel_aupro", row.get("pixel_pro"))),
                    "ap": pct(row.get("pixel_ap")),
                }
        parallel = mean.get("parallel")
        if isinstance(parallel, dict):
            for alias in aliases:
                if alias in parallel:
                    row = parallel[alias]
                    return {
                        "i_auc": pct(row.get("image_auroc", row.get("image_auc"))),
                        "p_auc": pct(row.get("pixel_auroc", row.get("pixel_auc"))),
                        "pro": pct(row.get("pixel_aupro", row.get("pixel_pro"))),
                        "ap": pct(row.get("pixel_ap")),
                    }
    return None


def summary_path(host: str, recipe: str) -> Path:
    if host == "AdaCLIP":
        if recipe == "all4_official":
            return ADACLIP_ROOT / "adaclip_visa_all4_baseline_eval/summary.json"
        return ADACLIP_ROOT / f"adaclip_visa_{recipe}_eval/summary.json"
    if host == "FAPrompt":
        if recipe == "all4_official":
            return FAPROMPT_ROOT / "faprompt_visa_all4_official_eval/summary.json"
        return FAPROMPT_ROOT / f"faprompt_visa_{recipe}_eval/summary.json"
    raise KeyError(host)


def collect(host: str) -> list[dict]:
    rows = []
    for label, recipe in RECIPES:
        summary = load(summary_path(host, recipe))
        b = row_vals(summary, "B")
        c = row_vals(summary, "C")
        if b is None or c is None:
            continue
        rows.append({"recipe": label, "B": b, "C": c})
    return rows


def style(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", color="#E9E0D2", linewidth=0.7)
    ax.set_axisbelow(True)
    ax.tick_params(axis="both", labelsize=9.5, length=0)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")


def draw_host(ax: plt.Axes, host: str, rows: list[dict]) -> None:
    labels = [r["recipe"] for r in rows]
    x = np.arange(len(labels))
    width = 0.36
    b = np.asarray([r["B"]["pro"] for r in rows], dtype=float)
    c = np.asarray([r["C"]["pro"] for r in rows], dtype=float)
    bars_b = ax.bar(x - width / 2, b, width, color="#6B7280", label="B", edgecolor="#262626", linewidth=0.4)
    bars_c = ax.bar(x + width / 2, c, width, color="#2F7D73", label="C-TED", edgecolor="#262626", linewidth=0.4)
    for xb, yb, yc in zip(x, b, c):
        ax.annotate(
            "",
            xy=(xb + width / 2, yc),
            xytext=(xb - width / 2, yb),
            arrowprops={"arrowstyle": "->", "lw": 1.0, "color": "#8A5A1F"},
        )
        ax.text(xb, max(yb, yc) + 1.4, f"{yc-yb:+.1f}", ha="center", va="bottom", fontsize=8.0, fontweight="bold")
    ax.set_title(host, fontsize=12.5, fontweight="bold")
    ax.set_ylabel("PRO", fontsize=10.5, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylim(0, max(np.nanmax(b), np.nanmax(c)) * 1.25)
    style(ax)


def write_values(data: dict[str, list[dict]]) -> None:
    lines = [
        "# Recipe Residual Diagnostic Values",
        "",
        "VisA -> MVTec layer-recipe retraining. Values are mean PRO from completed summaries.",
        "",
    ]
    for host, rows in data.items():
        lines += [f"## {host}", "", "| Recipe | B PRO | C-TED PRO | Delta |", "|---|---:|---:|---:|"]
        for row in rows:
            b = row["B"]["pro"]
            c = row["C"]["pro"]
            lines.append(f"| {row['recipe']} | {b:.2f} | {c:.2f} | {c-b:+.2f} |")
        lines.append("")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "recipe_residual_diagnostic_values_20260503.md").write_text("\n".join(lines))


def main() -> int:
    data = {host: collect(host) for host in ("AdaCLIP", "FAPrompt")}
    FIG.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "pdf.fonttype": 42, "ps.fonttype": 42})
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.35), constrained_layout=True)
    for ax, host in zip(axs, data):
        draw_host(ax, host, data[host])
    axs[0].legend(frameon=False, fontsize=8.5, loc="upper left")
    fig.savefig(FIG / "recipe_residual_diagnostic_20260503.pdf", bbox_inches="tight")
    fig.savefig(FIG / "recipe_residual_diagnostic_20260503.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    write_values(data)
    print(
        {
            "figure": str(FIG / "recipe_residual_diagnostic_20260503.pdf"),
            "values": str(OUT / "recipe_residual_diagnostic_values_20260503.md"),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
