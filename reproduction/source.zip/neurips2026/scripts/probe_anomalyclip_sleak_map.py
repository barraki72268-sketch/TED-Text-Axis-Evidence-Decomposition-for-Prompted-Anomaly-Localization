from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from utils import get_transform  # noqa: E402


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def build_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model


def load_basis_cache(cache_path: Path) -> tuple[dict[int, torch.Tensor], dict]:
    payload = torch.load(cache_path, map_location="cpu")
    tail_bases = {int(k): v.float() for k, v in payload["tail_bases"].items()}
    basis_stats = payload["basis_stats"]
    return tail_bases, basis_stats


def save_rows(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "class_name",
                "num_anomaly",
                "num_normal",
                "inside_mean",
                "outside_mean",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe S_leak map as anomaly score for baseline AnomalyCLIP")
    parser.add_argument(
        "--target_root",
        type=str,
        default="/mnt/data/gijeong/MMAD_new/VisA",
    )
    parser.add_argument(
        "--basis_cache",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_source_visual_tail_basis_skip1.pt"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_sleak_map_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--aggregate", type=str, default="mean", choices=["mean", "sum"])
    parser.add_argument("--contrast_kernel", type=int, default=0)
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    model = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    tail_bases, basis_stats = load_basis_cache(Path(args.basis_cache))

    class Args:
        pass

    dargs = Args()
    dargs.image_size = args.image_size
    preprocess, target_transform = get_transform(dargs)
    dataset = Dataset(root=args.target_root, transform=preprocess, target_transform=target_transform, dataset_name="visa")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    print(
        json.dumps(
            {
                "stage": "sleak_map_start",
                "num_target_images": len(dataset),
                "aggregate": args.aggregate,
                "contrast_kernel": args.contrast_kernel,
                "basis_cache": args.basis_cache,
            },
            indent=2,
        ),
        flush=True,
    )

    per_class = {}
    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(args.device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            layer_maps = []
            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < args.feature_map_layer[0]:
                    continue
                patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True).clamp_min(1e-6)
                patch_tok = patch_feature[:, 1:, :]
                n_patch = patch_tok.shape[1]
                side = int(round(math.sqrt(n_patch)))
                if side * side != n_patch:
                    raise RuntimeError(f"Unexpected patch count {n_patch}")
                tail = tail_bases[layer_idx].to(device=args.device, dtype=patch_tok.dtype)
                coeff = torch.matmul(patch_tok, tail)
                leak = coeff.pow(2).sum(dim=-1)
                denom = patch_tok.pow(2).sum(dim=-1).clamp_min(1e-8)
                leak = (leak / denom).reshape(1, 1, side, side)
                leak = F.interpolate(leak, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                layer_maps.append(leak[0, 0].detach().cpu().numpy())

            if args.aggregate == "mean":
                sleak_map = np.mean(np.stack(layer_maps, axis=0), axis=0)
            else:
                sleak_map = np.sum(np.stack(layer_maps, axis=0), axis=0)
            if args.contrast_kernel > 1:
                k = args.contrast_kernel
                pad = k // 2
                leak_t = torch.from_numpy(sleak_map).float()[None, None]
                local_mean = F.avg_pool2d(leak_t, kernel_size=k, stride=1, padding=pad)[0, 0].numpy()
                sleak_map = np.maximum(0.0, sleak_map - local_mean)
            sleak_map = gaussian_filter(sleak_map, sigma=args.sigma)

            stats = per_class.setdefault(
                cls_name,
                {
                    "num_anomaly": 0,
                    "num_normal": 0,
                    "inside_sum": 0.0,
                    "outside_sum": 0.0,
                    "ratio_sum": 0.0,
                    "normal_topk_sum": 0.0,
                    "normal_mean_sum": 0.0,
                },
            )

            if is_anomaly and gt_mask.any():
                inside = float(sleak_map[gt_mask].mean())
                outside = float(sleak_map[~gt_mask].mean())
                stats["num_anomaly"] += 1
                stats["inside_sum"] += inside
                stats["outside_sum"] += outside
                stats["ratio_sum"] += outside / max(inside, 1e-8)
            else:
                stats["num_normal"] += 1
                stats["normal_topk_sum"] += topk_mean(sleak_map, args.topk_frac)
                stats["normal_mean_sum"] += float(sleak_map.mean())

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "sleak_map_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    rows = []
    for cls_name, stats in per_class.items():
        rows.append(
            {
                "class_name": cls_name,
                "num_anomaly": stats["num_anomaly"],
                "num_normal": stats["num_normal"],
                "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
                "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
                "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
                "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
                "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
                "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
            }
        )

    mean_row = {
        "class_name": "mean",
        "num_anomaly": sum(r["num_anomaly"] for r in rows),
        "num_normal": sum(r["num_normal"] for r in rows),
        "inside_mean": float(np.mean([r["inside_mean"] for r in rows])),
        "outside_mean": float(np.mean([r["outside_mean"] for r in rows])),
        "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in rows])),
        "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in rows])),
        "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in rows])),
        "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in rows])),
    }
    rows.append(mean_row)

    summary = {
        "target_root": args.target_root,
        "basis_cache": args.basis_cache,
        "aggregate": args.aggregate,
        "contrast_kernel": args.contrast_kernel,
        "basis_stats": basis_stats,
        "mean": mean_row,
    }
    save_rows(rows, summary, save_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
