#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_baselast_tedlast_fresh_visa2mvtec_20260502"
LOG_ROOT = RESULT_ROOT / "_logs"

VISA_ROOT = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_CKPT = ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth"


def build_cmd(seed: int, device: str) -> list[str]:
    save_dir = RESULT_ROOT / f"visa2mvtec_seed{seed}"
    bank_cache = RESULT_ROOT / "visa2mvtec_last_scorebank.pt"
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        str(VISA_CKPT),
        "--model_name_or_path",
        "ViT-L/14@336px",
        "--heldout_class",
        "none",
        "--source_root",
        str(VISA_ROOT),
        "--source_dataset",
        "visa",
        "--target_root",
        str(MVTEC_ROOT),
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--baseline_features_list",
        "24",
        "--features_list",
        "24",
        "--dpam_layer",
        "20",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(bank_cache),
        "--refresh_bank_cache",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]


def main() -> int:
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    cmd = build_cmd(seed=0, device="cuda:0")
    log_path = LOG_ROOT / "visa2mvtec_seed0.log"
    with log_path.open("w") as log_file:
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            env=env,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
    print({"stage": "launched", "pid": proc.pid, "log": str(log_path), "cmd": cmd}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
