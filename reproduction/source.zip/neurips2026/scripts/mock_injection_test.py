from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dummy", action="store_true")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, default="chewinggum")
    parser.add_argument("--inject_layer", type=int, default=6)
    parser.add_argument("--subspace_k", type=int, default=4)
    parser.add_argument("--alphas", nargs="*", type=float, default=[0.0, 0.1, 0.25, 0.5, 1.0])
    parser.add_argument("--max_fit_anomaly_images", type=int, default=20)
    parser.add_argument("--max_eval_normal_images", type=int, default=10)
    parser.add_argument("--max_anomaly_patches", type=int, default=4096)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="mock_injection_test")
    return parser.parse_args()


def build_token_normal_anchor(backbone, class_name: str) -> torch.Tensor:
    prompts: list[str] = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = backbone.visual.proj.detach().float().to(text_anchor.device)
    token_anchor = proj @ text_anchor
    return F.normalize(token_anchor, dim=0)


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> torch.Tensor:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .to(dtype=torch.bool)
    )


def maybe_subsample(tokens: torch.Tensor, max_count: int) -> torch.Tensor:
    if max_count <= 0 or tokens.shape[0] <= max_count:
        return tokens
    idx = torch.linspace(0, tokens.shape[0] - 1, steps=max_count, device=tokens.device).round().long()
    return tokens[idx]


def get_null_space_residual(V: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    V = V.float()
    V_proj = (V @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return V - V_proj


def extract_anomaly_subspace(
    backbone,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    layer_idx: int,
    max_images: int,
    max_patches: int,
    subspace_k: int,
) -> torch.Tensor:
    ds = OfficialVisAWinClipDataset(dataset_root, split_csv, class_name, "test")
    anomaly_indices = [i for i, rec in enumerate(ds.records) if rec["label"] != "normal"][:max_images]
    collected: list[torch.Tensor] = []

    for idx in anomaly_indices:
        image_np, mask_np, label, _, _ = ds[idx]
        assert label == 1
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        tokens = forward_up_to_layer(backbone, image_t, layer_idx)
        patch_mask = to_patch_mask(mask_np, backbone.grid_size, backbone.device)
        pos = patch_mask.to(tokens.device)
        if int(pos.sum().item()) == 0:
            continue
        collected.append(tokens[0][pos].detach())

    if not collected:
        raise RuntimeError(f"No anomaly patches collected for class={class_name}, layer={layer_idx}")

    patches = torch.cat(collected, dim=0)
    patches = maybe_subsample(patches, max_patches)
    residual = get_null_space_residual(patches, p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    basis = vh[:subspace_k].T.contiguous()
    return basis


def forward_up_to_layer(model, image: torch.Tensor, layer_idx: int, return_sequence: bool = False):
    sequence = model.prepare_sequence(image)
    seq_mid = model.run_blocks(sequence, start_layer=1, end_layer=layer_idx)
    tokens_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
    if return_sequence:
        return tokens_mid, seq_mid
    return tokens_mid


def forward_remaining(model, v_mid_modified: torch.Tensor, layer_idx: int, cls_token: torch.Tensor) -> torch.Tensor:
    batch_seq = torch.cat([cls_token, v_mid_modified], dim=1)
    sequence = batch_seq.permute(1, 0, 2)
    seq_final = model.run_blocks(sequence, start_layer=layer_idx + 1, end_layer=model.num_layers)
    final_batch = seq_final.permute(1, 0, 2)
    final_batch = model.visual.ln_post(final_batch)
    return F.normalize(final_batch[:, 1:, :].float(), dim=-1)


def inject_kinematic_signal(v_mid: torch.Tensor, p_norm: torch.Tensor, V_anom: torch.Tensor, alpha: float) -> torch.Tensor:
    r_mid = get_null_space_residual(v_mid, p_norm)
    delta_v = torch.matmul(torch.matmul(r_mid, V_anom), V_anom.T)
    return v_mid + float(alpha) * delta_v


def evaluate_survival(model, image: torch.Tensor, p_norm: torch.Tensor, V_anom: torch.Tensor, alpha: float, inject_layer: int) -> dict[str, float]:
    with torch.no_grad():
        _, seq_mid = forward_up_to_layer(model, image, inject_layer, return_sequence=True)
        cls_token = seq_mid.permute(1, 0, 2)[:, :1, :].float()
        v_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()

        v_final_baseline = forward_remaining(model, v_mid, inject_layer, cls_token)
        v_mid_injected = inject_kinematic_signal(v_mid, p_norm, V_anom, alpha)
        v_final_injected = forward_remaining(model, v_mid_injected, inject_layer, cls_token)

        baseline_sim = float((v_final_baseline @ p_norm).mean().item())
        injected_sim = float((v_final_injected @ p_norm).mean().item())

        r_final_base = get_null_space_residual(v_final_baseline[0], p_norm)
        r_final_inj = get_null_space_residual(v_final_injected[0], p_norm)
        energy_base = float(torch.linalg.vector_norm(r_final_base @ V_anom, dim=-1).mean().item())
        energy_inj = float(torch.linalg.vector_norm(r_final_inj @ V_anom, dim=-1).mean().item())

        return {
            "alpha": float(alpha),
            "baseline_semantic_sim": baseline_sim,
            "injected_semantic_sim": injected_sim,
            "semantic_drop": injected_sim - baseline_sim,
            "baseline_subspace_energy": energy_base,
            "injected_subspace_energy": energy_inj,
            "energy_gain": energy_inj - energy_base,
            "energy_ratio": energy_inj / max(energy_base, 1e-8),
        }


def run_dummy() -> None:
    torch.manual_seed(0)
    N, D, k = 225, 896, 4
    v_mid = F.normalize(torch.randn(N, D), dim=-1)
    p_norm = F.normalize(torch.randn(D), dim=0)
    q, _ = torch.linalg.qr(torch.randn(D, k), mode="reduced")
    V_anom = q[:, :k]
    for alpha in [0.0, 0.1, 0.25, 0.5, 1.0]:
        v_injected = inject_kinematic_signal(v_mid, p_norm, V_anom, alpha)
        r_base = get_null_space_residual(v_mid, p_norm)
        r_inj = get_null_space_residual(v_injected, p_norm)
        print(
            {
                "alpha": alpha,
                "v_mid_shape": tuple(v_mid.shape),
                "v_injected_shape": tuple(v_injected.shape),
                "energy_base": float(torch.linalg.vector_norm(r_base @ V_anom, dim=-1).mean().item()),
                "energy_inj": float(torch.linalg.vector_norm(r_inj @ V_anom, dim=-1).mean().item()),
            }
        )


def main_real(args: argparse.Namespace) -> None:
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    if args.inject_layer < 1 or args.inject_layer > backbone.num_layers:
        raise ValueError(f"inject_layer must be in [1, {backbone.num_layers}]")

    p_norm = build_token_normal_anchor(backbone, args.class_name).to(backbone.device)
    V_anom = extract_anomaly_subspace(
        backbone=backbone,
        dataset_root=args.dataset_root,
        split_csv=args.split_csv,
        class_name=args.class_name,
        p_norm=p_norm,
        layer_idx=args.inject_layer,
        max_images=args.max_fit_anomaly_images,
        max_patches=args.max_anomaly_patches,
        subspace_k=args.subspace_k,
    ).to(backbone.device)

    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, args.class_name, "test")
    normal_indices = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"][: args.max_eval_normal_images]
    rows: list[dict[str, float]] = []

    for alpha in args.alphas:
        metrics: list[dict[str, float]] = []
        for idx in normal_indices:
            image_np, _, label, name, _ = ds[idx]
            assert label == 0
            image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
            image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
            out = evaluate_survival(
                model=backbone,
                image=image_t,
                p_norm=p_norm,
                V_anom=V_anom,
                alpha=float(alpha),
                inject_layer=args.inject_layer,
            )
            metrics.append(out)

        row = {"class_name": args.class_name, "inject_layer": args.inject_layer, "subspace_k": args.subspace_k, "num_eval_normals": len(metrics)}
        for key in metrics[0].keys():
            vals = np.asarray([m[key] for m in metrics], dtype=np.float64)
            row[f"{key}_mean"] = float(vals.mean())
            row[f"{key}_std"] = float(vals.std())
        rows.append(row)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{args.class_name}_L{args.inject_layer}_k{args.subspace_k}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(
            {
                "config": vars(args),
                "rows": rows,
                "p_norm_norm": float(torch.linalg.vector_norm(p_norm).item()),
                "V_anom_shape": list(V_anom.shape),
            },
            f,
            indent=2,
        )
    print(csv_path)
    print(json_path)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    args = parse_args()
    if args.dummy:
        run_dummy()
    else:
        main_real(args)
