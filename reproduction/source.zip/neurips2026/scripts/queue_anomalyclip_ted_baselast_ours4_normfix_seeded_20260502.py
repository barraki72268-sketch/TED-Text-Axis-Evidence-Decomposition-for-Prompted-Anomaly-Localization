#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_ted_baselast_ours4_hostanchor_normfix_seeded_20260502"
LOG_ROOT = RESULT_ROOT / "_logs"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")

MVTEC_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth")
VISA_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth")

TRANSFERS = {
    "visa2mvtec": {
        "source_root": VISA_ROOT,
        "source_dataset": "visa",
        "target_root": MVTEC_ROOT,
        "target_dataset": "mvtec",
        "checkpoint": VISA_CKPT,
    },
    "mvtec2visa": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": VISA_ROOT,
        "target_dataset": "visa",
        "checkpoint": MVTEC_CKPT,
    },
    "mvtec2mpdd": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": MPDD_ROOT,
        "target_dataset": "mpdd",
        "checkpoint": MVTEC_CKPT,
    },
    "mvtec2btad": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": BTAD_ROOT,
        "target_dataset": "btad",
        "checkpoint": MVTEC_CKPT,
    },
}


def build_cmd(name: str, transfer: dict[str, str], seed: int, device: str) -> list[str]:
    save_dir = RESULT_ROOT / f"{name}_seed{seed}"
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        transfer["checkpoint"],
        "--heldout_class",
        "none",
        "--source_root",
        transfer["source_root"],
        "--source_dataset",
        transfer["source_dataset"],
        "--target_root",
        transfer["target_root"],
        "--target_dataset",
        transfer["target_dataset"],
        "--target_mode",
        "test",
        "--baseline_features_list",
        "24",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]


def parse_transfers(raw: str) -> list[str]:
    names = [name.strip() for name in raw.split(",") if name.strip()]
    unknown = [name for name in names if name not in TRANSFERS]
    if unknown:
        raise SystemExit(f"Unknown transfers {unknown}. Allowed: {sorted(TRANSFERS)}")
    return names


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--transfers", default="visa2mvtec")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    seeds = [int(seed.strip()) for seed in args.seeds.split(",") if seed.strip()]
    for name in parse_transfers(args.transfers):
        transfer = TRANSFERS[name]
        for seed in seeds:
            save_dir = RESULT_ROOT / f"{name}_seed{seed}"
            summary_path = save_dir / "summary.json"
            log_path = LOG_ROOT / f"{name}_seed{seed}.log"
            if summary_path.exists() and not args.force:
                print({"stage": "skip_completed", "transfer": name, "seed": seed, "summary": str(summary_path)}, flush=True)
                continue
            cmd = build_cmd(name, transfer, seed, args.device)
            print({"stage": "start", "transfer": name, "seed": seed, "log": str(log_path)}, flush=True)
            with log_path.open("w") as log_file:
                proc = subprocess.run(cmd, cwd=str(ROOT), stdout=log_file, stderr=subprocess.STDOUT, text=True)
            print({"stage": "done", "transfer": name, "seed": seed, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
            if proc.returncode != 0:
                raise SystemExit(proc.returncode)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
