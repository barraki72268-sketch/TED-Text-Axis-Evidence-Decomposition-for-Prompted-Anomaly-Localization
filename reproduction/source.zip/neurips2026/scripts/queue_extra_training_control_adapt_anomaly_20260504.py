#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "training_control_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "training_control_20260504"
BANK = ROOT / "neurips2026" / "results" / "bank_cache"

ADAPT_SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaptclip_vlrefine.py"
ANOM_SCRIPT = ROOT / "neurips2026" / "scripts" / "probe_anomalyclip_text_decomposition_score.py"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADAPT_MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
ADAPT_VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"

ANOM_MVTEC_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
ANOM_VISA_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"


VARIANTS = {
    "correct": "correct",
    "label_shuffle": "shuffle",
    "label_swap": "swap",
}

DATASETS = {
    "mvtec": MVTEC_ROOT,
    "visa": VISA_ROOT,
    "mpdd": MPDD_ROOT,
    "btad": BTAD_ROOT,
}


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def split_preset(preset: str) -> tuple[str, str]:
    if "2" not in preset:
        raise SystemExit(f"Unsupported preset={preset}; expected source2target")
    source, target = preset.split("2", 1)
    if source not in DATASETS or target not in DATASETS:
        raise SystemExit(f"Unsupported preset={preset}")
    return source, target


def source_ckpt(host: str, source: str) -> Path:
    if host == "adaptclip":
        return ADAPT_VISA_CKPT if source == "visa" else ADAPT_MVTEC_CKPT
    if host == "anomalyclip":
        return ANOM_VISA_CKPT if source == "visa" else ANOM_MVTEC_CKPT
    raise SystemExit(f"Unsupported host={host}")


def build_adaptclip_cmd(preset: str, variant: str, device: str, seed: int) -> tuple[list[str], Path]:
    source, target = split_preset(preset)
    control = VARIANTS[variant]
    save_dir = RESULTS / f"adaptclip_vl_last24_{preset}_{variant}_seed{seed}"
    bank_cache = BANK / f"adaptclip_control_{source}_vl_last24_seed{seed}.pt"
    cmd = [
        str(PY),
        "-u",
        str(ADAPT_SCRIPT),
        "--source_root",
        str(DATASETS[source]),
        "--source_dataset",
        source,
        "--target_root",
        str(DATASETS[target]),
        "--target_dataset",
        target,
        "--checkpoint_path",
        str(source_ckpt("adaptclip", source)),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank_cache),
        "--pretrained_model",
        "ViT-L/14@336px",
        "--checkpoint_load_mode",
        "strict",
        "--features_list",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "8",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--corr_alpha",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_pair_label_control",
        control,
        "--seed",
        str(seed),
        "--device",
        device,
        "--num_workers",
        "4",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
    ]
    return cmd, save_dir


def build_anomalyclip_cmd(preset: str, variant: str, device: str, seed: int) -> tuple[list[str], Path]:
    source, target = split_preset(preset)
    control = VARIANTS[variant]
    save_dir = RESULTS / f"anomalyclip_last24_{preset}_{variant}_seed{seed}"
    bank_cache = BANK / f"anomalyclip_control_{source}_last24.pt"
    score_bank_cache = BANK / f"anomalyclip_control_{source}_last24_withscores.pt"
    cmd = [
        str(PY),
        "-u",
        str(ANOM_SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        str(source_ckpt("anomalyclip", source)),
        "--heldout_class",
        "none",
        "--source_root",
        str(DATASETS[source]),
        "--source_dataset",
        source,
        "--target_root",
        str(DATASETS[target]),
        "--target_dataset",
        target,
        "--target_mode",
        "test",
        "--features_list",
        "24",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--calib_pair_label_control",
        control,
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--aupro_max_step",
        "200",
        "--bank_cache_path",
        str(bank_cache),
        "--score_bank_cache_path",
        str(score_bank_cache),
        "--save_dir",
        str(save_dir),
    ]
    return cmd, save_dir


def launch(cmd: list[str], save_dir: Path, log_path: Path, force: bool) -> dict:
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        return {"stage": "skip_done", "summary": str(summary)}
    save_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = log_path.open("ab", buffering=0)
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        stdout=log_f,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {"stage": "launched", "pid": proc.pid, "save_dir": str(save_dir), "log": str(log_path)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="adaptclip,anomalyclip")
    ap.add_argument("--presets", default="visa2btad,visa2mpdd,mvtec2btad")
    ap.add_argument("--variants", default="correct,label_swap")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    builders = {
        "adaptclip": build_adaptclip_cmd,
        "anomalyclip": build_anomalyclip_cmd,
    }
    hosts = parse_csv(args.hosts)
    presets = parse_csv(args.presets)
    variants = parse_csv(args.variants)
    devices = parse_csv(args.devices)
    jobs = []
    for host in hosts:
        if host not in builders:
            raise SystemExit(f"Unsupported host={host}; allowed={sorted(builders)}")
        for preset in presets:
            for variant in variants:
                if variant not in VARIANTS:
                    raise SystemExit(f"Unsupported variant={variant}; allowed={sorted(VARIANTS)}")
                device = devices[len(jobs) % len(devices)]
                cmd, save_dir = builders[host](preset, variant, device, args.seed)
                jobs.append((cmd, save_dir, LOGS / f"{save_dir.name}.log"))

    launched = [launch(cmd, save_dir, log_path, args.force) for cmd, save_dir, log_path in jobs]
    print(json.dumps({"stage": "extra_training_control_queue", "jobs": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
