#!/usr/bin/env python3
from __future__ import annotations

import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/launch_anomalyclip_layer_retrain_full4_20260502.py"
OUT_ROOT = ROOT / "neurips2026/results/anomalyclip_layer_retrained_full4_20260502"
LOG_PATH = OUT_ROOT / "launcher.detached.log"
PID_PATH = OUT_ROOT / "launcher.pid"


def main() -> int:
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("w") as log:
        proc = subprocess.Popen(
            [PY, "-u", str(SCRIPT)],
            cwd=str(ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
    PID_PATH.write_text(f"{proc.pid}\n")
    print({"stage": "detached", "pid": proc.pid, "log": str(LOG_PATH), "pid_file": str(PID_PATH)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
