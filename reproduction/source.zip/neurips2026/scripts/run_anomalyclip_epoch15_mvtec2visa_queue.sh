#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
CKPT="${ROOT}/neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth"
CACHE="${ROOT}/neurips2026/results/bank_cache/anomalyclip_mvtec_exclude-bottle_epoch15_multiscale_visa.pt"
SOURCE_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
TARGET_ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP/neurips2026/data/VisA_pytorch_official/1cls"
DEVICE="cuda:0"

while [ ! -f "${CACHE}" ]; do
  sleep 30
done

for CLS in capsules pcb4 macaroni2; do
  SAVE_DIR="${ROOT}/neurips2026/results/anomalyclip_text_decomposition_score_mvtec2visa_${CLS}_epoch15"
  ${PY} "${SCRIPT}" \
    --device "${DEVICE}" \
    --checkpoint_path "${CKPT}" \
    --heldout_class bottle \
    --source_root "${SOURCE_ROOT}" \
    --target_root "${TARGET_ROOT}" \
    --target_dataset visa \
    --target_mode test \
    --target_classes "${CLS}" \
    --bank_cache_path "${CACHE}" \
    --save_dir "${SAVE_DIR}"
done
