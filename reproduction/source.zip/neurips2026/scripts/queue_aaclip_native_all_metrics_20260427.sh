#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP
PY="/mnt/data/envs/patchcore-conda/bin/python"

run_native() {
  local preset="$1"
  local save_dir="$2"
  if [[ -f "${save_dir}/summary.json" ]]; then
    echo "[$(date '+%F %T')] skip existing ${save_dir}"
    return 0
  fi
  echo "[$(date '+%F %T')] start AA-CLIP native ${preset}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip.py \
    --preset "${preset}" \
    --model_name ViT-B-16-plus-240 \
    --pretrained laion400m_e32 \
    --adapter_load_mode project_crop \
    --levels 6,12 \
    --img_size 518 \
    --batch_size 16 \
    --num_workers 4 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas=-0.5 \
    --blend_modes prescore_rectify \
    --candidate_topk_frac 0.10 \
    --gate_sharpness 3.0 \
    --candidate_image_mode map_topk \
    --cal_pro \
    --aupro_max_step 50 \
    --device cuda:0 \
    --save_dir "${save_dir}"
}

run_native visa2mvtec neurips2026/results/aaclip_prescore_segtoken_vitbplus_visa2mvtec_img518_full_neg05_map_topk_pro_20260427
run_native mvtec2visa neurips2026/results/aaclip_prescore_segtoken_vitbplus_mvtec2visa_img518_full_neg05_map_topk_pro_20260427
run_native visa2mpdd neurips2026/results/aaclip_prescore_segtoken_vitbplus_visa2mpdd_img518_full_neg05_map_topk_pro_20260427
run_native visa2btad neurips2026/results/aaclip_prescore_segtoken_vitbplus_visa2btad_img518_full_neg05_map_topk_pro_20260427

echo "[$(date '+%F %T')] AA-CLIP native all-metric queue finished"
