from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.train_clip_aqm_oracle import AnomalyQueryModuleV1
from neurips2026.scripts.train_clip_aqm_v40_mvtec_to_visa import (
    compute_aqm_v40_loss,
    load_resized_mask,
    patch_scores_to_pixel_map,
    safe_pixel_auc,
    safe_pro,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    forward_up_to_layer,
    patchify_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.scripts.train_clip_ksm_v3_mvtec_to_visa import (
    PromptCondition,
    build_prompt_condition,
    collect_mvtec_train_records,
    collect_visa_eval_records,
    materialize_record_batch,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("AQM v4.0-min multilayer MVTec -> VisA prompt-centric transfer pilot.")
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument(
        "--target_classes",
        nargs="+",
        default=[
            "chewinggum",
            "pipe_fryum",
            "pcb4",
            "macaroni2",
            "cashew",
            "pcb1",
            "macaroni1",
            "fryum",
            "pcb2",
            "capsules",
            "candle",
            "pcb3",
        ],
    )
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12])
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_simplex_tokens", type=int, default=32)
    parser.add_argument("--num_subspace_tokens", type=int, default=32)
    parser.add_argument("--gamma_init", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=8)
    parser.add_argument("--train_anomaly_images", type=int, default=8)
    parser.add_argument("--train_batch_size", type=int, default=64)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--lambda_proj", type=float, default=0.3)
    parser.add_argument("--lambda_router", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--router_tau", type=float, default=5.0)
    parser.add_argument("--router_lse_beta", type=float, default=10.0)
    parser.add_argument("--fusion_eta", type=float, default=1.0)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--pixel_blur_sigma", type=float, default=4.0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_aqm_mvtec2visa_v40_multilayer")
    return parser.parse_args()


def train_one_epoch(
    backbone,
    aqms: dict[int, AnomalyQueryModuleV1],
    prompt_cache: dict[str, PromptCondition],
    train_records,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    for aqm in aqms.values():
        aqm.train()
    loss_vals = []
    alpha_by_layer = {layer: [] for layer in args.layers}
    gamma_s_by_layer = {layer: [] for layer in args.layers}
    gamma_u_by_layer = {layer: [] for layer in args.layers}

    records_by_class: dict[str, list] = {}
    for rec in train_records:
        records_by_class.setdefault(rec.class_name, []).append(rec)
    rng = np.random.default_rng(epoch_idx)
    class_order = list(records_by_class.keys())
    rng.shuffle(class_order)

    for class_name in class_order:
        cond = prompt_cache[class_name]
        class_records = records_by_class[class_name]
        order = rng.permutation(len(class_records))
        for start in range(0, len(order), args.train_batch_size):
            batch_idx = order[start : start + args.train_batch_size]
            batch_records = [class_records[int(i)] for i in batch_idx]
            image_t_cpu, patch_mask = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            mask = torch.from_numpy(patch_mask.astype(np.int64)).to(device)

            total_loss = torch.zeros([], device=device)
            per_layer_losses = []
            per_layer_aux = {}
            for layer in args.layers:
                seq = forward_up_to_layer(backbone, image_t, layer)
                _, patches = patchify_sequence(seq)
                _, aux = aqms[layer](patches, cond.p_norm, return_aux=True)
                loss, _ = compute_aqm_v40_loss(
                    aux,
                    cond,
                    mask,
                    topk_anom_ratio=args.topk_anom_ratio,
                    hard_neg_ratio=args.hard_neg_ratio,
                    lambda_zero=args.lambda_zero,
                    lambda_proj=args.lambda_proj,
                    lambda_router=args.lambda_router,
                    router_lse_beta=args.router_lse_beta,
                    router_tau=args.router_tau,
                )
                total_loss = total_loss + loss
                per_layer_losses.append(loss)
                per_layer_aux[layer] = aux

            optimizer.zero_grad(set_to_none=True)
            total_loss.backward()
            optimizer.step()

            loss_vals.append(float(total_loss.item()))
            for layer in args.layers:
                aux = per_layer_aux[layer]
                alpha_by_layer[layer].append(aux["alpha_mean"])
                gamma_s_by_layer[layer].append(aux["gamma_simplex_abs"])
                gamma_u_by_layer[layer].append(aux["gamma_subspace_abs"])

    stats = {"train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan")}
    for layer in args.layers:
        stats[f"alpha_mean_L{layer}"] = float(np.mean(alpha_by_layer[layer])) if alpha_by_layer[layer] else float("nan")
        stats[f"gamma_simplex_abs_mean_L{layer}"] = (
            float(np.mean(gamma_s_by_layer[layer])) if gamma_s_by_layer[layer] else float("nan")
        )
        stats[f"gamma_subspace_abs_mean_L{layer}"] = (
            float(np.mean(gamma_u_by_layer[layer])) if gamma_u_by_layer[layer] else float("nan")
        )
    return stats


def evaluate_target_class(
    backbone,
    aqms: dict[int, AnomalyQueryModuleV1],
    cond: PromptCondition,
    eval_records,
    layers: list[int],
    img_size: int,
    topk_ratio: float,
    eval_batch_size: int,
    fusion_eta: float,
    pixel_blur_sigma: float,
    device: str,
) -> dict[str, float]:
    for aqm in aqms.values():
        aqm.eval()
    deepest = max(layers)
    patch_labels = []
    base_patch_scores = []
    mix_patch_scores = []
    image_labels = []
    base_image_scores = []
    mix_image_scores = []
    gt_masks = []
    base_pixel_maps = []
    mix_pixel_maps = []
    alpha_by_layer = {layer: [] for layer in layers}

    with torch.no_grad():
        for start in range(0, len(eval_records), eval_batch_size):
            batch_records = eval_records[start : start + eval_batch_size]
            image_t_cpu, patch_masks = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)

            base_scores = None
            layer_mixed_scores: dict[int, np.ndarray] = {}
            for layer in layers:
                seq = forward_up_to_layer(backbone, image_t, layer)
                _, patches = patchify_sequence(seq)
                _, aux = aqms[layer](patches, cond.p_norm, return_aux=True)
                if layer == deepest:
                    base_scores = score_promptmax(patches, cond.p_norm, cond.prompt_features)
                simplex_scores = score_promptmax(aux["simplex_feat"], cond.p_norm, cond.prompt_features)
                subspace_scores = score_promptmax(aux["subspace_feat"], cond.p_norm, cond.prompt_features)
                alpha_np = aux["alpha_tensor"].view(-1).detach().cpu().numpy()
                layer_mixed_scores[layer] = np.asarray(
                    [float(a) * ss + (1.0 - float(a)) * us for ss, us, a in zip(simplex_scores, subspace_scores, alpha_np)]
                )
                alpha_by_layer[layer].extend(alpha_np.tolist())
            assert base_scores is not None

            for rec_idx, (rec, patch_mask, bs) in enumerate(zip(batch_records, patch_masks, base_scores)):
                mixed_anom = sum(layer_mixed_scores[layer][rec_idx] for layer in layers) / float(len(layers))
                fused_mix = bs + float(fusion_eta) * mixed_anom
                patch_labels.extend(patch_mask.astype(np.int64).tolist())
                base_patch_scores.extend(bs.tolist())
                mix_patch_scores.extend(fused_mix.tolist())
                image_labels.append(rec.label)
                base_image_scores.append(topk_mean(np.asarray(bs), topk_ratio))
                mix_image_scores.append(topk_mean(np.asarray(fused_mix), topk_ratio))
                gt_mask = load_resized_mask(rec.mask_path if rec.label == 1 else None, img_size)
                gt_masks.append(gt_mask)
                base_pixel_maps.append(patch_scores_to_pixel_map(np.asarray(bs), img_size, pixel_blur_sigma))
                mix_pixel_maps.append(patch_scores_to_pixel_map(np.asarray(fused_mix), img_size, pixel_blur_sigma))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    mix_patch_auc = safe_auc(patch_labels, mix_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    mix_image_auc = safe_auc(image_labels, mix_image_scores)
    base_pixel_auc = safe_pixel_auc(base_pixel_maps, gt_masks)
    mix_pixel_auc = safe_pixel_auc(mix_pixel_maps, gt_masks)
    base_p_pro = safe_pro(base_pixel_maps, gt_masks)
    mix_p_pro = safe_pro(mix_pixel_maps, gt_masks)

    stats = {
        "base_prompt_patch_auc": base_patch_auc,
        "aqm_prompt_patch_auc": mix_patch_auc,
        "prompt_patch_auc_delta": mix_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "aqm_prompt_image_auc": mix_image_auc,
        "prompt_image_auc_delta": mix_image_auc - base_image_auc,
        "base_prompt_pixel_auc": base_pixel_auc,
        "aqm_prompt_pixel_auc": mix_pixel_auc,
        "prompt_pixel_auc_delta": mix_pixel_auc - base_pixel_auc,
        "base_prompt_p_pro": base_p_pro,
        "aqm_prompt_p_pro": mix_p_pro,
        "prompt_p_pro_delta": mix_p_pro - base_p_pro,
    }
    for layer in layers:
        stats[f"alpha_mean_eval_L{layer}"] = (
            float(np.mean(alpha_by_layer[layer])) if alpha_by_layer[layer] else float("nan")
        )
    return stats


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for p in backbone.parameters():
        p.requires_grad_(False)

    train_records = collect_mvtec_train_records(backbone, args)
    source_class_names = list(args.source_classes)
    source_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in source_class_names
    }
    target_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.target_classes
    }

    dim = int(next(iter(source_prompt_cache.values())).prompt_features.shape[1])
    aqms = {
        layer: AnomalyQueryModuleV1(
            dim=dim,
            num_simplex_tokens=args.num_simplex_tokens,
            num_subspace_tokens=args.num_subspace_tokens,
            gamma_init=args.gamma_init,
        ).to(device)
        for layer in args.layers
    }
    param_groups = []
    for layer in args.layers:
        aqm = aqms[layer]
        token_params = [aqm.simplex_tokens, aqm.subspace_tokens]
        other_params = [p for n, p in aqm.named_parameters() if n not in {"simplex_tokens", "subspace_tokens"}]
        param_groups.append({"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay})
        param_groups.append(
            {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay}
        )
    optimizer = torch.optim.AdamW(param_groups)

    print(
        f"[setup] source_dataset=mvtec source_classes={len(source_class_names)} "
        f"source_records={len(train_records)} target_classes={len(args.target_classes)} "
        f"layers={','.join(map(str, args.layers))}"
    )

    history = []
    for epoch in range(1, args.epochs + 1):
        stats = train_one_epoch(backbone, aqms, source_prompt_cache, train_records, args, optimizer, device, epoch)
        history.append({"epoch": epoch, **stats})
        alpha_msg = " ".join(f"L{layer}={stats[f'alpha_mean_L{layer}']:.4f}" for layer in args.layers)
        print(f"[epoch {epoch}/{args.epochs}] loss={stats['train_loss']:.6f} alpha({alpha_msg})")

    rows = []
    for class_name in args.target_classes:
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(
            backbone,
            aqms,
            target_prompt_cache[class_name],
            eval_records,
            args.layers,
            args.img_size,
            args.topk_ratio,
            args.eval_batch_size,
            args.fusion_eta,
            args.pixel_blur_sigma,
            device,
        )
        rows.append(
            {
                "class_name": class_name,
                "layers": "-".join(str(x) for x in args.layers),
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "img_size": args.img_size,
                "epochs": args.epochs,
                "gamma_init": args.gamma_init,
                "num_simplex_tokens": args.num_simplex_tokens,
                "num_subspace_tokens": args.num_subspace_tokens,
                "lambda_zero": args.lambda_zero,
                "lambda_proj": args.lambda_proj,
                "lambda_router": args.lambda_router,
                "router_tau": args.router_tau,
                "router_lse_beta": args.router_lse_beta,
                "fusion_eta": args.fusion_eta,
                "source_dataset": "mvtec",
                "source_classes": len(source_class_names),
                "source_train_records": len(train_records),
                "text_rank": target_prompt_cache[class_name].text_rank,
                **history[-1],
                **eval_stats,
            }
        )

    layer_tag = "-".join(str(x) for x in args.layers)
    stem = f"{args.output_tag}_{args.backbone}_L{layer_tag}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump(
            {
                "args": vars(args),
                "history": history,
                "rows": rows,
                "source_classes": source_class_names,
                "target_classes": args.target_classes,
            },
            f,
            indent=2,
        )
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
