from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.scripts.eval_winclip_oneclass_featureop import run_eval, write_outputs


VISA_CLASSES = [
    "candle",
    "capsules",
    "cashew",
    "chewinggum",
    "fryum",
    "macaroni1",
    "macaroni2",
    "pcb1",
    "pcb2",
    "pcb3",
    "pcb4",
    "pipe_fryum",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--classes", nargs="+", default=VISA_CLASSES)
    parser.add_argument("--feature_ops", nargs="+", default=["identity", "learned_refiner"])
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--k_shot", type=int, default=0)
    parser.add_argument("--cal_pro", action="store_true")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--refiner_ckpt", type=str, default="")
    parser.add_argument("--refiner_ckpts", nargs="*", default=[])
    parser.add_argument(
        "--output_dir",
        type=str,
        default="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP/neurips2026/results",
    )
    parser.add_argument("--output_tag", type=str, default="winclip_learned_all_visa")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_rows: list[dict] = []
    for class_name in args.classes:
        class_args = argparse.Namespace(**vars(args))
        class_args.class_name = class_name
        rows = run_eval(class_args)
        write_outputs(rows, output_dir, args.output_tag, class_name)
        all_rows.extend(rows)
        for row in rows:
            print(
                f"{row['class_name']} | {row['feature_op']} | "
                f"I-ROC={row['i_roc']:.2f} | P-ROC={row['p_roc']:.2f} | P-PRO={row['p_pro']:.2f}"
            )

    aggregate_path = output_dir / f"{args.output_tag}_aggregate.csv"
    with aggregate_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        writer.writeheader()
        writer.writerows(all_rows)
    print(aggregate_path)


if __name__ == "__main__":
    main()
