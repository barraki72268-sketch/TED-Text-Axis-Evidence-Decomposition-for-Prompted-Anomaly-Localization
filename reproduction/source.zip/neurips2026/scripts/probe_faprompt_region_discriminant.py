from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

import AnomalyCLIP_lib  # noqa: E402
from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402
from region_descriptor_utils import extract_region_descriptor, iterate_components, load_rows  # noqa: E402
from region_eval_utils import image_auroc, pixel_auroc, topk_mean  # noqa: E402
from utils import get_transform  # noqa: E402


def build_dataset(root: str, image_size: int, dataset_name: str):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name=dataset_name)


def build_model(device: str, checkpoint_path: str, image_size: int, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    prompt_learner = FAPrompt(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    model.to(device)
    prompt_learner.eval()
    model.eval()
    return model, prompt_learner


def compute_map(model, prompt_learner, image: torch.Tensor, features_list: list[int], image_size: int, sigma: int):
    image_features, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
    image_features = image_features / image_features.norm(dim=-1, keepdim=True)
    patch_features = patch_features / patch_features.norm(dim=-1, keepdim=True)
    prompts_pos, prompts_neg, tokenized_prompts_pos, tokenized_prompts_neg, compound_prompts_text, _ = prompt_learner.forward()
    text_features_pos = model.encode_text_learn(prompts_pos, tokenized_prompts_pos, compound_prompts_text).float()
    text_features_neg = model.encode_text_learn(prompts_neg, tokenized_prompts_neg, compound_prompts_text).float()
    text_features_neg = torch.mean(text_features_neg, dim=0, keepdim=True)
    text_features = torch.cat([text_features_pos, text_features_neg])
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    similarity, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_features[0])
    similarity_map1 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], image_size).squeeze(0)
    num = min(10, similarity[1:, :, 1].shape[0])
    pk_indx = torch.topk(similarity[1:, :, 1], k=num, dim=0, largest=True, sorted=True).indices
    pk_indx = pk_indx.permute(1, 0)
    selected_tokens = []
    for i in range(len(pk_indx)):
        selected_tokens2 = []
        for k in range(len(pk_indx[0])):
            tmp_token = patch_features[1:, :, :].permute(1, 0, 2)[i, k, :]
            selected_tokens2.append(tmp_token)
        selected_tokens2 = torch.stack(selected_tokens2)
        selected_tokens.append(selected_tokens2)
    selected_tokens = torch.stack(selected_tokens)

    text_features_list = []
    for i in range(selected_tokens.shape[0]):
        p_pos, p_neg, tok_pos, tok_neg, comp_text, _ = prompt_learner.forward(selected_tokens=selected_tokens[i])
        tf_pos = model.encode_text_learn(p_pos, tok_pos, comp_text).float()
        tf_neg = model.encode_text_learn(p_neg, tok_neg, comp_text).float()
        tf_neg = torch.mean(tf_neg, dim=0, keepdim=True)
        tf = torch.cat([tf_pos, tf_neg])
        text_features_list.append(tf)
    text_features = torch.stack(text_features_list)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_features, text_features)
    similarity_map2 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], image_size).squeeze(0)
    anomaly_map = (similarity_map1[1, :] + 1 - similarity_map1[0, :] + similarity_map2[1, :] + 1 - similarity_map2[0, :]) / 4.0
    return gaussian_filter(anomaly_map.detach().cpu().numpy(), sigma=sigma)


def fit_region_classifier(fp_rows: list[dict], defect_rows: list[dict], features: list[str]):
    def rows_to_x(rows: list[dict]) -> np.ndarray:
        return np.asarray([[float(row[f]) for f in features] for row in rows], dtype=np.float32)
    X = np.concatenate([rows_to_x(fp_rows), rows_to_x(defect_rows)], axis=0)
    y = np.concatenate([np.zeros(len(fp_rows), dtype=np.int64), np.ones(len(defect_rows), dtype=np.int64)], axis=0)
    clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
    clf.fit(X, y)
    return clf


def save_results(rows: list[dict], summary: dict, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe FAPrompt region discriminant on VisA")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_baseline_mvtec" / "checkpoints" / "epoch_15.pth"),
    )
    parser.add_argument(
        "--fp_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_region_bank_holdout_epoch15" / "fp_rows.csv"),
    )
    parser.add_argument(
        "--defect_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_region_bank_holdout_epoch15" / "defect_rows.csv"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_region_discriminant_epoch15"),
    )
    parser.add_argument("--descriptor_combo", type=str, default="peak,mean,area,fill_ratio,compactness,ring_contrast")
    parser.add_argument("--candidate_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.25, 0.5, 0.75, 1.0])
    parser.add_argument("--modes", type=str, nargs="+", default=["gate", "dual"])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    descriptor_features = [x.strip() for x in args.descriptor_combo.split(",") if x.strip()]
    fp_rows = load_rows(Path(args.fp_csv))
    defect_rows = load_rows(Path(args.defect_csv))
    clf = fit_region_classifier(fp_rows, defect_rows, descriptor_features)
    model, prompt_learner = build_model(args.device, args.checkpoint_path, args.image_size, args.depth, args.n_ctx, args.t_n_ctx)
    dataset = build_dataset(args.target_root, args.image_size, args.target_dataset)

    rows = []
    with torch.no_grad():
        for mode in args.modes:
            for alpha in args.alphas:
                image_labels, image_scores = [], []
                masks, maps = [], []
                normal_topk, normal_mean = [], []
                gaps, ratios, num_components, mean_probs = [], [], [], []
                for idx in range(len(dataset)):
                    item = dataset[idx]
                    image = item["img"].unsqueeze(0).to(args.device)
                    gt_mask = item["img_mask"][0].numpy() > 0.5
                    anomaly_flag = item["anomaly"]
                    if hasattr(anomaly_flag, "item"):
                        anomaly_flag = anomaly_flag.item()
                    anomaly_flag = int(anomaly_flag)

                    anomaly_map = compute_map(model, prompt_learner, image, args.features_list, args.image_size, args.sigma)
                    defect_prob_map = np.zeros_like(anomaly_map, dtype=np.float32)
                    covered = np.zeros_like(anomaly_map, dtype=bool)
                    comp_probs = []
                    for frac in args.candidate_fracs:
                        mask = top_fraction_mask(anomaly_map, frac)
                        for comp in iterate_components(mask):
                            if int(comp.sum()) < args.min_area:
                                continue
                            desc = extract_region_descriptor(anomaly_map, comp)
                            if not desc:
                                continue
                            X = np.asarray([[float(desc[f]) for f in descriptor_features]], dtype=np.float32)
                            prob = float(clf.predict_proba(X)[0, 1])
                            defect_prob_map[comp] = np.maximum(defect_prob_map[comp], prob)
                            covered |= comp
                            comp_probs.append(prob)
                    final_map = anomaly_map.copy()
                    if covered.any():
                        if mode == "gate":
                            factor = ((1.0 - alpha) + alpha * defect_prob_map)[covered]
                            final_map[covered] = anomaly_map[covered] * factor
                        elif mode == "dual":
                            factor = (defect_prob_map - alpha * (1.0 - defect_prob_map))[covered]
                            final_map[covered] = anomaly_map[covered] * factor
                        else:
                            raise ValueError(mode)

                    image_labels.append(anomaly_flag)
                    image_scores.append(topk_mean(final_map, args.image_score_topk))
                    masks.append(gt_mask)
                    maps.append(final_map)
                    num_components.append(len(comp_probs))
                    mean_probs.append(float(np.mean(comp_probs)) if comp_probs else 0.5)
                    if anomaly_flag == 0:
                        normal_topk.append(topk_mean(final_map, args.normal_topk_ratio))
                        normal_mean.append(float(final_map.mean()))
                    elif gt_mask.any() and (~gt_mask).any():
                        inside = float(final_map[gt_mask].mean())
                        outside = float(final_map[~gt_mask].mean())
                        gaps.append(inside - outside)
                        ratios.append(outside / (inside + 1e-6))

                rows.append(
                    {
                        "mode": mode,
                        "alpha": float(alpha),
                        "image_auroc": image_auroc(image_labels, image_scores),
                        "pixel_auroc": pixel_auroc(masks, maps),
                        "inside_outside_gap": float(np.mean(gaps)) if gaps else float("nan"),
                        "outside_inside_ratio": float(np.mean(ratios)) if ratios else float("nan"),
                        "normal_topk_mean": float(np.mean(normal_topk)) if normal_topk else float("nan"),
                        "normal_map_mean": float(np.mean(normal_mean)) if normal_mean else float("nan"),
                        "avg_num_components": float(np.mean(num_components)) if num_components else float("nan"),
                        "avg_mean_defect_prob": float(np.mean(mean_probs)) if mean_probs else float("nan"),
                    }
                )
                print(json.dumps({"stage": "region_discriminant_progress", "mode": mode, "alpha": alpha}), flush=True)

    summary = {
        "descriptor_features": descriptor_features,
        "num_fp_rows": len(fp_rows),
        "num_defect_rows": len(defect_rows),
        "checkpoint_path": args.checkpoint_path,
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"stage": "region_discriminant_saved", "save_dir": args.save_dir, "rows": rows}, indent=2), flush=True)


if __name__ == "__main__":
    main()
