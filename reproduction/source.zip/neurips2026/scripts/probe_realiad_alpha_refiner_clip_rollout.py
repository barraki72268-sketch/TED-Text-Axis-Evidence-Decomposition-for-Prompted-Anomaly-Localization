from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import open_clip
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.models.clip import ClipModel
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts
from neurips2026.learned_refiner import AlphaSpaceKinematicRefiner, AlphaSpaceObjective
from neurips2026.scripts.probe_realiad_alpha_refiner_clip_dryrun import (
    LAYER_IDS,
    _audit_cache_path,
    _load_cached_json,
    _trainable_cache_path,
    audit_dataset,
    build_mask_transform,
    build_transform,
    collect_records_by_label,
    compute_patch_residual,
    cosine_decay_lr,
    filter_trainable_anomalies,
    flatten_records,
    imagewise_mean,
    imagewise_mean_vec,
    linear_schedule,
    sample_balanced_batch,
    set_seed,
    build_batch_tensors,
)
from ADPretrain.datasets.real_iad import RealIAD
from open_clip.transformer import _expand_token


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--clip_backbone", type=str, default="clip-large-336", choices=["clip-large-336"])
    parser.add_argument("--layer", type=int, default=12, choices=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=336)
    parser.add_argument("--imagesize", type=int, default=336)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--hidden_dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--lambda_sem", type=float, default=1.0)
    parser.add_argument("--lambda_normal", type=float, default=0.1)
    parser.add_argument("--lambda_anomaly", type=float, default=0.1)
    parser.add_argument("--lambda_pairwise", type=float, default=1.0)
    parser.add_argument("--pairwise_margin", type=float, default=0.1)
    parser.add_argument("--sem_threshold", type=float, default=0.02)
    parser.add_argument("--sem_gas_beta", type=float, default=10.0)
    parser.add_argument("--lr_decay_start", type=int, default=100)
    parser.add_argument("--lr_min_ratio", type=float, default=0.1)
    parser.add_argument("--eval_interval", type=int, default=10)
    parser.add_argument("--probe_normals", type=int, default=8)
    parser.add_argument("--probe_anomalies", type=int, default=8)
    parser.add_argument("--probe_sem_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_target", type=float, default=0.35)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--steps", type=int, default=120)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--audit_verify_limit", type=int, default=4000)
    parser.add_argument("--mask_audit_limit", type=int, default=4000)
    parser.add_argument("--reuse_dataset_cache", action="store_true", default=True)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--output_tag", type=str, default="realiad_clip_alpha_rollout_probe")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def build_prompt_semantics(class_name: str, model: ClipModel, device: torch.device) -> dict[str, torch.Tensor]:
    tokenizer = open_clip.get_tokenizer("ViT-L-14")
    prompts = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    tokens = tokenizer(prompts).to(device)
    with torch.no_grad():
        text_features = model.visual_encoder.encode_text(tokens).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    q_text, _ = torch.linalg.qr(text_features.T, mode="reduced")

    visual = model.visual_encoder.visual
    proj = getattr(visual, "proj", None)
    if proj is None:
        token_basis = q_text
        token_anchor = text_anchor
    else:
        proj = proj.float().to(device)
        token_basis = proj @ q_text
        token_basis, _ = torch.linalg.qr(token_basis, mode="reduced")
        token_anchor = F.normalize(proj @ text_anchor, dim=0)
    return {
        "token_basis": token_basis.cpu(),
        "token_anchor": token_anchor.cpu(),
        "text_anchor": text_anchor.cpu(),
    }


def _prepare_visual_tokens(visual, x: torch.Tensor) -> torch.Tensor:
    if visual.input_patchnorm:
        x = x.reshape(
            x.shape[0],
            x.shape[1],
            visual.grid_size[0],
            visual.patch_size[0],
            visual.grid_size[1],
            visual.patch_size[1],
        )
        x = x.permute(0, 2, 4, 1, 3, 5)
        x = x.reshape(x.shape[0], visual.grid_size[0] * visual.grid_size[1], -1)
        x = visual.patchnorm_pre_ln(x)
        x = visual.conv1(x)
    else:
        x = visual.conv1(x)
        x = x.reshape(x.shape[0], x.shape[1], -1)
        x = x.permute(0, 2, 1)

    cls = _expand_token(visual.class_embedding, x.shape[0]).to(x.dtype)
    x = torch.cat([cls, x], dim=1)
    x = x + visual.positional_embedding.to(x.dtype)
    x = visual.patch_dropout(x)
    x = visual.ln_pre(x)
    return x.permute(1, 0, 2)  # NLD -> LND


def _global_pool_from_tokens(visual, x_nld: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    attn_pool = getattr(visual, "attn_pool", None)
    attn_pool_contrastive = getattr(visual, "attn_pool_contrastive", None)
    attn_pool_type = getattr(visual, "attn_pool_type", None)
    final_ln_after_pool = getattr(visual, "final_ln_after_pool", False)

    if attn_pool is not None:
        if attn_pool_contrastive is not None:
            x_nld = visual.ln_post(x_nld)
            tokens = attn_pool(x_nld)
            if attn_pool_type == "parallel":
                pooled = attn_pool_contrastive(x_nld)
            else:
                pooled = attn_pool_contrastive(tokens)
        else:
            x_nld = attn_pool(x_nld)
            x_nld = visual.ln_post(x_nld)
            pooled, tokens = visual._global_pool(x_nld)
    elif final_ln_after_pool:
        pooled, tokens = visual._global_pool(x_nld)
        pooled = visual.ln_post(pooled)
    else:
        x_nld = visual.ln_post(x_nld)
        pooled, tokens = visual._global_pool(x_nld)

    if visual.proj is not None:
        pooled = pooled @ visual.proj
    return pooled, tokens


def _run_visual_blocks(
    visual,
    x_lnd: torch.Tensor,
    out_layers: tuple[int, ...],
    inject_layer: int | None = None,
    injected_patch_tokens_nld: torch.Tensor | None = None,
) -> tuple[dict[int, torch.Tensor], torch.Tensor]:
    outputs: dict[int, torch.Tensor] = {}
    x = x_lnd
    for block_idx, block in enumerate(visual.transformer.resblocks, start=1):
        x, _ = block(x, attn_mask=None)
        if inject_layer is not None and block_idx == inject_layer:
            if injected_patch_tokens_nld is None:
                raise ValueError("injected_patch_tokens_nld must be provided when inject_layer is set.")
            tokens_nld = x.permute(1, 0, 2)
            tokens_nld = torch.cat([tokens_nld[:, :1, :], injected_patch_tokens_nld], dim=1)
            x = tokens_nld.permute(1, 0, 2)
        if block_idx in out_layers:
            outputs[block_idx] = x.permute(1, 0, 2)
    pooled, _ = _global_pool_from_tokens(visual, x.permute(1, 0, 2))
    return outputs, pooled


def extract_raw_and_rollout(
    clip_model: ClipModel,
    images: torch.Tensor,
    target_layer: int,
    refined_patch_tokens_nld: torch.Tensor,
) -> tuple[dict[int, torch.Tensor], torch.Tensor, dict[int, torch.Tensor], torch.Tensor]:
    visual = clip_model.visual_encoder.visual
    out_layers = tuple(LAYER_IDS)
    with torch.no_grad():
        x0 = _prepare_visual_tokens(visual, images)
        raw_layers, raw_global = _run_visual_blocks(visual, x0, out_layers)
        rollout_layers, rollout_global = _run_visual_blocks(
            visual,
            x0,
            out_layers,
            inject_layer=target_layer,
            injected_patch_tokens_nld=refined_patch_tokens_nld,
        )
    return raw_layers, raw_global, rollout_layers, rollout_global


def build_probe_semantics(
    probe_batch: list[dict],
    semantic_by_class: dict[str, dict[str, torch.Tensor]],
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    token_basis = []
    token_anchor = []
    text_anchor = []
    for rec in probe_batch:
        sem = semantic_by_class[rec["class_name"]]
        token_basis.append(sem["token_basis"])
        token_anchor.append(sem["token_anchor"])
        text_anchor.append(sem["text_anchor"])
    return (
        torch.stack(token_basis, dim=0).to(device),
        torch.stack(token_anchor, dim=0).to(device),
        torch.stack(text_anchor, dim=0).to(device),
    )


def evaluate_local_probe(
    *,
    model: AlphaSpaceKinematicRefiner,
    objective: AlphaSpaceObjective,
    clip_model: ClipModel,
    probe_batch: list[dict],
    semantic_by_class: dict[str, dict[str, torch.Tensor]],
    transform,
    mask_transform,
    args: argparse.Namespace,
    device: torch.device,
    layer_index: int,
    token_side: int,
) -> dict[str, float]:
    images, masks_t, _, labels = build_batch_tensors(
        probe_batch,
        transform,
        mask_transform,
        {k: v["token_basis"] for k, v in semantic_by_class.items()},
        clip_model,
        args,
        device,
    )
    basis_t, _, _ = build_probe_semantics(probe_batch, semantic_by_class, device)
    with torch.no_grad():
        features = clip_model.encode_image_from_tensors(images, shape="img")[layer_index].float()
        out = model(features, semantic_basis=basis_t)
        loss_stats = objective(
            raw_features=features,
            refined_features=out.refined,
            alpha=out.alpha,
            anomaly_mask=masks_t,
            semantic_basis=basis_t,
        )
        anomaly_patch_mask = F.interpolate(masks_t.float(), size=(token_side, token_side), mode="nearest").reshape(len(probe_batch), -1) > 0.5
        anomaly_image_mask = torch.tensor(labels, device=device, dtype=torch.bool)
        token_anomaly_counts = anomaly_patch_mask.sum(dim=1)
        anomaly_token_counts_only = token_anomaly_counts[anomaly_image_mask]
        alpha_n = float(loss_stats["alpha_normal_mean"].item())
        alpha_a = float(loss_stats["alpha_anomaly_mean"].item())
        sem = float(loss_stats["loss_sem"].item())
        gap = alpha_n - alpha_a
        score = (
            gap
            - args.probe_sem_penalty * sem
            - args.probe_alphaa_penalty * max(0.0, alpha_a - args.probe_alphaa_target)
        )
    return {
        "probe_score": float(score),
        "probe_alpha_normal_mean": alpha_n,
        "probe_alpha_anomaly_mean": alpha_a,
        "probe_alpha_gap": float(gap),
        "probe_sem_loss": sem,
        "probe_anomaly_zero_token_fraction": float((anomaly_token_counts_only == 0).float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
        "probe_anomaly_token_count_mean": float(anomaly_token_counts_only.float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
    }


def evaluate_rollout_probe(
    *,
    model: AlphaSpaceKinematicRefiner,
    clip_model: ClipModel,
    probe_batch: list[dict],
    semantic_by_class: dict[str, dict[str, torch.Tensor]],
    transform,
    mask_transform,
    args: argparse.Namespace,
    device: torch.device,
    target_layer: int,
    token_side: int,
) -> dict[str, float]:
    images, masks_t, _, labels = build_batch_tensors(
        probe_batch,
        transform,
        mask_transform,
        {k: v["token_basis"] for k, v in semantic_by_class.items()},
        clip_model,
        args,
        device,
    )
    basis_t, token_anchor_t, text_anchor_t = build_probe_semantics(probe_batch, semantic_by_class, device)
    target_index = LAYER_IDS.index(target_layer)

    with torch.no_grad():
        raw_features = clip_model.encode_image_from_tensors(images, shape="img")[target_index].float()
        out = model(raw_features, semantic_basis=basis_t)
        refined_patch_tokens = out.refined.flatten(2).transpose(1, 2)

        raw_layers, raw_global, rollout_layers, rollout_global = extract_raw_and_rollout(
            clip_model=clip_model,
            images=images,
            target_layer=target_layer,
            refined_patch_tokens_nld=refined_patch_tokens,
        )

        raw_final_patch = raw_layers[24][:, 1:, :]
        rollout_final_patch = rollout_layers[24][:, 1:, :]

        raw_global_score = F.cosine_similarity(raw_global, text_anchor_t, dim=-1)
        rollout_global_score = F.cosine_similarity(rollout_global, text_anchor_t, dim=-1)

        raw_patch_score = F.cosine_similarity(
            raw_final_patch,
            token_anchor_t.unsqueeze(1).expand_as(raw_final_patch),
            dim=-1,
        )
        rollout_patch_score = F.cosine_similarity(
            rollout_final_patch,
            token_anchor_t.unsqueeze(1).expand_as(rollout_final_patch),
            dim=-1,
        )

        label_mask = torch.tensor(labels, device=device, dtype=torch.bool)
        normal_mask = ~label_mask
        anomaly_mask = label_mask

        def _safe_mean(x: torch.Tensor, m: torch.Tensor) -> float:
            return float(x[m].mean().item()) if m.any() else float("nan")

        raw_patch_mean = raw_patch_score.mean(dim=1)
        rollout_patch_mean = rollout_patch_score.mean(dim=1)
        raw_patch_max = raw_patch_score.max(dim=1).values
        rollout_patch_max = rollout_patch_score.max(dim=1).values
        raw_patch_var = raw_patch_score.var(dim=1, unbiased=False)
        rollout_patch_var = rollout_patch_score.var(dim=1, unbiased=False)

        raw_global_gap = _safe_mean(raw_global_score, normal_mask) - _safe_mean(raw_global_score, anomaly_mask)
        rollout_global_gap = _safe_mean(rollout_global_score, normal_mask) - _safe_mean(rollout_global_score, anomaly_mask)
        raw_patch_gap = _safe_mean(raw_patch_mean, normal_mask) - _safe_mean(raw_patch_mean, anomaly_mask)
        rollout_patch_gap = _safe_mean(rollout_patch_mean, normal_mask) - _safe_mean(rollout_patch_mean, anomaly_mask)

        final_patch_delta = (1.0 - F.cosine_similarity(raw_final_patch, rollout_final_patch, dim=-1)).mean()
        final_global_delta = (1.0 - F.cosine_similarity(raw_global, rollout_global, dim=-1)).mean()

    return {
        "rollout_raw_global_gap": float(raw_global_gap),
        "rollout_refined_global_gap": float(rollout_global_gap),
        "rollout_raw_patch_gap": float(raw_patch_gap),
        "rollout_refined_patch_gap": float(rollout_patch_gap),
        "rollout_normal_patch_max_raw": _safe_mean(raw_patch_max, normal_mask),
        "rollout_normal_patch_max_refined": _safe_mean(rollout_patch_max, normal_mask),
        "rollout_normal_patch_var_raw": _safe_mean(raw_patch_var, normal_mask),
        "rollout_normal_patch_var_refined": _safe_mean(rollout_patch_var, normal_mask),
        "rollout_final_patch_delta_mean": float(final_patch_delta.item()),
        "rollout_final_global_delta_mean": float(final_global_delta.item()),
    }


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_layer{args.layer}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    png_path = output_dir / f"{stem}_curves.png"

    transform = build_transform(args.resize, args.imagesize)
    mask_transform = build_mask_transform(args.imagesize)

    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.resize,
        crp_size=args.imagesize,
        msk_size=args.imagesize,
        msk_crp_size=args.imagesize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    records = flatten_records(dataset)
    normal_records, anomaly_records = collect_records_by_label(records)
    records_by_image_path = {rec["image_path"]: rec for rec in records}

    clip_model = ClipModel(args.clip_backbone, device=str(device)).eval()
    clip_model.visual_encoder = clip_model.visual_encoder.to(device)
    layer_index = LAYER_IDS.index(args.layer)
    token_side = args.imagesize // 14

    audit_cache_path = _audit_cache_path(output_dir, args)
    audit = _load_cached_json(audit_cache_path) if args.reuse_dataset_cache else None
    if audit is None:
        audit = audit_dataset(
            records=records,
            mask_transform=mask_transform,
            image_size=args.imagesize,
            token_side=token_side,
            verify_limit=args.audit_verify_limit,
            mask_audit_limit=args.mask_audit_limit,
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with audit_cache_path.open("w") as f:
            json.dump(audit, f, indent=2)

    shared_trainable_cache_path = _trainable_cache_path(output_dir, args, token_side)
    trainable_anomalies = None
    trainable_meta = None
    if args.reuse_dataset_cache:
        cached_trainable = _load_cached_json(shared_trainable_cache_path)
        if cached_trainable is not None:
            cached_records = []
            for rec in cached_trainable.get("records", []):
                current = records_by_image_path.get(rec["image_path"])
                if current is not None:
                    cached_records.append(current)
            if cached_records:
                trainable_anomalies = cached_records
                trainable_meta = cached_trainable.get("pool_meta", {})
    if trainable_anomalies is None or trainable_meta is None:
        trainable_anomalies, trainable_meta = filter_trainable_anomalies(
            anomaly_records=anomaly_records,
            mask_transform=mask_transform,
            token_side=token_side,
            scan_limit=max(args.mask_audit_limit, args.batch_size * args.steps * 4),
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with shared_trainable_cache_path.open("w") as f:
            json.dump(
                {
                    "config": {
                        "mask_dilate_kernel": args.mask_dilate_kernel,
                        "token_side": token_side,
                        "scan_limit": max(args.mask_audit_limit, args.batch_size * args.steps * 4),
                    },
                    "pool_meta": trainable_meta,
                    "records": [
                        {
                            "image_path": rec["image_path"],
                            "mask_path": rec["mask_path"],
                            "class_name": rec["class_name"],
                            "anomaly_type": rec["anomaly_type"],
                            "sample_id": rec["sample_id"],
                        }
                        for rec in trainable_anomalies
                    ],
                },
                f,
                indent=2,
            )
    if not trainable_anomalies:
        raise RuntimeError("No trainable anomaly samples survived token-grid downsampling.")

    semantic_by_class: dict[str, dict[str, torch.Tensor]] = {}
    model = AlphaSpaceKinematicRefiner(
        feature_dim=clip_model.feature_dimensions[layer_index],
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
    ).to(device)
    objective = AlphaSpaceObjective(
        lambda_sem=args.lambda_sem,
        lambda_normal=args.lambda_normal,
        lambda_anomaly=args.lambda_anomaly,
        lambda_pairwise=args.lambda_pairwise,
        pairwise_margin=args.pairwise_margin,
        sem_threshold=args.sem_threshold,
        sem_gas_beta=args.sem_gas_beta,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    rng = random.Random(args.seed)
    probe_rng = random.Random(args.seed + 101)
    probe_batch = probe_rng.sample(normal_records, min(len(normal_records), args.probe_normals))
    probe_batch += probe_rng.sample(trainable_anomalies, min(len(trainable_anomalies), args.probe_anomalies))
    probe_rng.shuffle(probe_batch)

    probe_classes = {rec["class_name"] for rec in probe_batch}
    for class_name in probe_classes:
        semantic_by_class[class_name] = build_prompt_semantics(class_name, clip_model, device)

    best_probe_score = -float("inf")
    best_probe_step = -1
    best_state = None
    best_local_metrics = None
    step_rows = []

    for step in range(1, args.steps + 1):
        tic = time.time()
        current_lr = cosine_decay_lr(
            step=step,
            total_steps=args.steps,
            base_lr=args.lr,
            start_step=max(1, args.lr_decay_start),
            min_ratio=args.lr_min_ratio,
        )
        for group in optimizer.param_groups:
            group["lr"] = current_lr

        batch = sample_balanced_batch(normal_records, trainable_anomalies, args.batch_size, rng)
        images, masks_t, basis_t, labels = build_batch_tensors(
            batch,
            transform,
            mask_transform,
            {k: v["token_basis"] for k, v in semantic_by_class.items()},
            clip_model,
            args,
            device,
        )
        with torch.no_grad():
            features = clip_model.encode_image_from_tensors(images, shape="img")[layer_index].float()
        out = model(features, semantic_basis=basis_t)
        loss_stats = objective(
            raw_features=features,
            refined_features=out.refined,
            alpha=out.alpha,
            anomaly_mask=masks_t,
            semantic_basis=basis_t,
        )

        optimizer.zero_grad()
        loss_stats["loss"].backward()
        optimizer.step()

        row = {
            "step": step,
            "loss": float(loss_stats["loss"].detach().item()),
            "loss_sem": float(loss_stats["loss_sem"].item()),
            "loss_pairwise": float(loss_stats["loss_pairwise"].item()),
            "alpha_normal_mean": float(loss_stats["alpha_normal_mean"].item()),
            "alpha_anomaly_mean": float(loss_stats["alpha_anomaly_mean"].item()),
            "alpha_gap": float(loss_stats["alpha_normal_mean"].item() - loss_stats["alpha_anomaly_mean"].item()),
            "lr_current": current_lr,
        }

        if step % args.eval_interval == 0 or step == 1 or step == args.steps:
            local_metrics = evaluate_local_probe(
                model=model,
                objective=objective,
                clip_model=clip_model,
                probe_batch=probe_batch,
                semantic_by_class=semantic_by_class,
                transform=transform,
                mask_transform=mask_transform,
                args=args,
                device=device,
                layer_index=layer_index,
                token_side=token_side,
            )
            row.update(local_metrics)
            if local_metrics["probe_score"] > best_probe_score:
                best_probe_score = local_metrics["probe_score"]
                best_probe_step = step
                best_local_metrics = dict(local_metrics)
                best_state = copy.deepcopy(model.state_dict())

        step_rows.append(row)
        print(
            f"[step {step}] loss={row['loss']:.4f} sem={row['loss_sem']:.4f} pair={row['loss_pairwise']:.4f} "
            f"alpha_n={row['alpha_normal_mean']:.4f} alpha_a={row['alpha_anomaly_mean']:.4f} gap={row['alpha_gap']:.4f} "
            f"lr={row['lr_current']:.5f} t={time.time() - tic:.2f}s",
            flush=True,
        )

    if best_state is None:
        raise RuntimeError("No checkpoint was selected during rollout probe.")
    model.load_state_dict(best_state)

    rollout_metrics = evaluate_rollout_probe(
        model=model,
        clip_model=clip_model,
        probe_batch=probe_batch,
        semantic_by_class=semantic_by_class,
        transform=transform,
        mask_transform=mask_transform,
        args=args,
        device=device,
        target_layer=args.layer,
        token_side=token_side,
    )

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(step_rows[0].keys()))
        writer.writeheader()
        writer.writerows(step_rows)

    summary = {
        "config": vars(args),
        "dataset_audit": audit,
        "trainable_anomaly_pool": trainable_meta,
        "best_probe_step": best_probe_step,
        "best_local_metrics": best_local_metrics,
        "final_step": step_rows[-1],
        "rollout_metrics": rollout_metrics,
    }
    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    steps = [row["step"] for row in step_rows]
    train_gaps = [row["alpha_gap"] for row in step_rows]
    probe_gaps = [row.get("probe_alpha_gap", float("nan")) for row in step_rows]
    fig, ax = plt.subplots(1, 1, figsize=(7, 4))
    ax.plot(steps, train_gaps, label="train gap")
    ax.plot(steps, probe_gaps, label="local probe gap")
    ax.set_xlabel("step")
    ax.set_ylabel("alpha gap")
    ax.legend()
    ax.grid(True, alpha=0.2)
    fig.tight_layout()
    fig.savefig(png_path, dpi=200)

    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_png={png_path}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
