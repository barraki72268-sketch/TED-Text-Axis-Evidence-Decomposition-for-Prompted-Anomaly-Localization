from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026" / "results" / "adaclip_recipe_fragility"


def load_mean_rows(summary_path: Path) -> list[dict]:
    payload = json.loads(summary_path.read_text())
    summary = payload.get("summary", {})
    out = []
    for row in payload["rows"]:
        if row.get("target_label") != "mean":
            continue
        merged = dict(row)
        merged["preset"] = summary.get("source_dataset", "src") + "2" + summary.get("target_dataset", "tgt")
        merged["layer_recipe"] = summary.get("layer_recipe", row.get("layer_recipe", "unknown"))
        merged["selected_layers"] = summary.get("selected_layers", [])
        merged["save_dir"] = str(summary_path.parent)
        out.append(merged)
    return out


def main() -> None:
    parser = argparse.ArgumentParser("Collect AdaCLIP recipe fragility summaries")
    parser.add_argument("--run_tag", type=str, required=True)
    parser.add_argument("--result_root", type=str, default=str(RESULT_ROOT))
    args = parser.parse_args()

    result_root = Path(args.result_root)
    rows: list[dict] = []
    for summary_path in sorted(result_root.glob(f"*_{args.run_tag}/summary.json")):
        rows.extend(load_mean_rows(summary_path))

    if not rows:
        raise FileNotFoundError(f"No summary.json found for run_tag={args.run_tag} under {result_root}")

    groups: dict[tuple[str, str], list[dict]] = {}
    for row in rows:
        key = (row["preset"], row["mode"])
        groups.setdefault(key, []).append(row)

    for (_, _), group_rows in groups.items():
        default_row = next((row for row in group_rows if row["layer_recipe"] == "all4"), None)
        if default_row is None:
            continue
        for row in group_rows:
            for metric in ["image_auroc", "image_ap", "pixel_auroc", "pixel_ap", "pixel_aupro"]:
                base = float(default_row.get(metric, np.nan))
                value = float(row.get(metric, np.nan))
                row[f"{metric}_drop_vs_all4"] = base - value if np.isfinite(base) and np.isfinite(value) else float("nan")
                row[f"{metric}_retention_vs_all4"] = value / base if np.isfinite(base) and np.isfinite(value) and abs(base) > 1e-12 else float("nan")

    out_dir = result_root / f"collected_{args.run_tag}"
    out_dir.mkdir(parents=True, exist_ok=True)

    json_path = out_dir / "recipe_fragility_summary.json"
    csv_path = out_dir / "recipe_fragility_summary.csv"
    json_path.write_text(json.dumps(rows, indent=2))

    preferred_fields = [
        "preset",
        "mode",
        "layer_recipe",
        "target_label",
        "selected_layers",
        "image_auroc",
        "image_ap",
        "pixel_auroc",
        "pixel_ap",
        "pixel_aupro",
        "image_auroc_drop_vs_all4",
        "image_ap_drop_vs_all4",
        "pixel_auroc_drop_vs_all4",
        "pixel_ap_drop_vs_all4",
        "pixel_aupro_drop_vs_all4",
        "image_auroc_retention_vs_all4",
        "image_ap_retention_vs_all4",
        "pixel_auroc_retention_vs_all4",
        "pixel_ap_retention_vs_all4",
        "pixel_aupro_retention_vs_all4",
        "save_dir",
    ]
    fieldnames = list(preferred_fields)
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    print(json.dumps({"json": str(json_path), "csv": str(csv_path), "num_rows": len(rows)}, indent=2))


if __name__ == "__main__":
    main()
