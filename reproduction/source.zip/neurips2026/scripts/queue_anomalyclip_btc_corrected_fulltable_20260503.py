#!/usr/bin/env python3
"""Queue corrected AnomalyCLIP B/T/C full-table runs.

Corrected protocol from 2026-05-03 smoke/full validation:
- B: official AnomalyCLIP last-layer patch-text score.
- T: train-free TED with AnomalyCLIP-specific fp_minus_def orientation.
- C: source-calibrated residual anchored to the train-free TED score.

The queue is detached-safe and writes one summary per transfer/backbone/seed.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
PROBE = ROOT / "neurips2026" / "scripts" / "probe_anomalyclip_text_decomposition_score.py"

RESULT_ROOT = ROOT / "neurips2026" / "results" / "anomalyclip_btc_corrected_fulltable_20260503"
LOG_ROOT = RESULT_ROOT / "_logs"
BANK_ROOT = RESULT_ROOT / "bank_cache"

MVTEC_ROOT = ROOT.parent / "ijepa" / "data" / "mvtec"
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

MVTEC_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"

VIT_L_OPENAI = Path("/home/jinyoung/.cache/clip/ViT-L-14.pt")
VIT_B_OPENAI = Path("/home/jinyoung/.cache/clip/ViT-B-16.pt")
VIT_H_LAION = Path(
    "/mnt/data/hf-cache/hub/models--laion--CLIP-ViT-H-14-laion2B-s32B-b79K/"
    "blobs/9a78ef8e8c73fd0df621682e7a8e8eb36c6916cb3c16b291a082ecd52ab79cc4"
)


TRANSFERS = {
    "visa2mvtec": {
        "source_root": VISA_ROOT,
        "source_dataset": "visa",
        "target_root": MVTEC_ROOT,
        "target_dataset": "mvtec",
        "checkpoint": VISA_CKPT,
    },
    "mvtec2visa": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": VISA_ROOT,
        "target_dataset": "visa",
        "checkpoint": MVTEC_CKPT,
    },
    "mvtec2mpdd": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": MPDD_ROOT,
        "target_dataset": "mpdd",
        "checkpoint": MVTEC_CKPT,
    },
    "mvtec2btad": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": BTAD_ROOT,
        "target_dataset": "btad",
        "checkpoint": MVTEC_CKPT,
    },
}


BACKBONES = {
    "vitl336": {
        "label": "ViT-L/14-336",
        "model_name_or_path": "ViT-L/14@336px",
        "image_size": 518,
        "dpam_layer": 20,
        "features": [24],
        "allow_prompt_projection": False,
    },
    "vitl_openai": {
        "label": "ViT-L/14 OpenAI",
        "model_name_or_path": str(VIT_L_OPENAI),
        "image_size": 224,
        "dpam_layer": 20,
        "features": [24],
        "allow_prompt_projection": False,
    },
    "vitb16": {
        "label": "ViT-B/16",
        "model_name_or_path": str(VIT_B_OPENAI),
        "image_size": 224,
        "dpam_layer": 12,
        "features": [12],
        "allow_prompt_projection": True,
    },
    "vith14": {
        "label": "ViT-H/14",
        "model_name_or_path": str(VIT_H_LAION),
        "image_size": 224,
        "dpam_layer": 32,
        "features": [32],
        "allow_prompt_projection": True,
    },
}


def parse_csv(raw: str) -> list[str]:
    return [item.strip() for item in raw.split(",") if item.strip()]


def pct(value: float) -> float:
    value = float(value)
    return value * 100.0 if abs(value) <= 1.5 else value


def live_pid(pid: int) -> bool:
    return pid > 0 and Path(f"/proc/{pid}").exists()


def wait_pid(pid: int) -> None:
    if not live_pid(pid):
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while live_pid(pid):
        time.sleep(60)
    print({"stage": "wait_pid_done", "pid": pid}, flush=True)


def validate_paths() -> None:
    required = [MVTEC_ROOT, VISA_ROOT, MPDD_ROOT, BTAD_ROOT, MVTEC_CKPT, VISA_CKPT, VIT_L_OPENAI, VIT_B_OPENAI, VIT_H_LAION]
    missing = [str(path) for path in required if not Path(path).exists()]
    if missing:
        raise SystemExit(f"Missing required paths: {missing}")


def build_cmd(
    transfer_name: str,
    transfer: dict[str, object],
    backbone_name: str,
    backbone: dict[str, object],
    seed: int,
    device: str,
    force_bank: bool,
) -> list[str]:
    features = [str(x) for x in backbone["features"]]
    bank_path = BANK_ROOT / f"anomalyclip_{backbone_name}_{transfer_name}_last_withscores.pt"
    save_dir = RESULT_ROOT / f"{backbone_name}_{transfer_name}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        str(PROBE),
        "--device",
        device,
        "--checkpoint_path",
        str(transfer["checkpoint"]),
        "--model_name_or_path",
        str(backbone["model_name_or_path"]),
        "--heldout_class",
        "none",
        "--source_root",
        str(transfer["source_root"]),
        "--source_dataset",
        str(transfer["source_dataset"]),
        "--target_root",
        str(transfer["target_root"]),
        "--target_dataset",
        str(transfer["target_dataset"]),
        "--target_mode",
        "test",
        "--baseline_features_list",
        *features,
        "--features_list",
        *features,
        "--dpam_layer",
        str(backbone["dpam_layer"]),
        "--image_size",
        str(backbone["image_size"]),
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--ted_margin_sign",
        "fp_minus_def",
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(bank_path),
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "40",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.2",
        "--calib_lambda",
        "0.03",
        "--calib_map_anchor",
        "trainfree",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "0.2",
        "--calibrated_image_fusion_weight",
        "0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if bool(backbone["allow_prompt_projection"]):
        cmd.extend(["--allow_prompt_projection", "--prompt_projection_ridge", "1e-3"])
    if force_bank or not bank_path.exists():
        cmd.append("--refresh_bank_cache")
    return cmd


def extract_mean(summary_path: Path) -> dict[str, dict[str, float]]:
    data = json.loads(summary_path.read_text())
    out: dict[str, dict[str, float]] = {}
    for row in data.get("rows", []):
        if row.get("target_label") != "mean":
            continue
        out[str(row["mode"])] = {
            "I-AUC": pct(row["image_auroc"]),
            "P-AUC": pct(row["pixel_auroc"]),
            "P-PRO": pct(row["pixel_aupro"]),
            "P-AP": pct(row["pixel_ap"]),
        }
    return out


def write_index(records: list[dict[str, object]]) -> None:
    if not records:
        return
    csv_path = RESULT_ROOT / "index.csv"
    keys = [
        "backbone",
        "transfer",
        "seed",
        "status",
        "B_I-AUC",
        "B_P-AUC",
        "B_P-PRO",
        "B_P-AP",
        "T_I-AUC",
        "T_P-AUC",
        "T_P-PRO",
        "T_P-AP",
        "C_I-AUC",
        "C_P-AUC",
        "C_P-PRO",
        "C_P-AP",
        "summary",
        "log",
    ]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(records)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--transfers", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    parser.add_argument("--backbones", default="vitl336,vitl_openai,vitb16,vith14")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--force_bank", action="store_true")
    args = parser.parse_args()

    validate_paths()
    wait_pid(args.wait_pid)
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    BANK_ROOT.mkdir(parents=True, exist_ok=True)

    transfers = parse_csv(args.transfers)
    backbones = parse_csv(args.backbones)
    seeds = [int(x) for x in parse_csv(args.seeds)]
    unknown_transfers = [name for name in transfers if name not in TRANSFERS]
    unknown_backbones = [name for name in backbones if name not in BACKBONES]
    if unknown_transfers:
        raise SystemExit(f"Unknown transfers {unknown_transfers}; allowed={sorted(TRANSFERS)}")
    if unknown_backbones:
        raise SystemExit(f"Unknown backbones {unknown_backbones}; allowed={sorted(BACKBONES)}")

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.device_id)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-anomalyclip-corrected-20260503")

    records: list[dict[str, object]] = []
    for backbone_name in backbones:
        backbone = BACKBONES[backbone_name]
        for transfer_name in transfers:
            transfer = TRANSFERS[transfer_name]
            for seed in seeds:
                save_dir = RESULT_ROOT / f"{backbone_name}_{transfer_name}_seed{seed}"
                summary_path = save_dir / "summary.json"
                log_path = LOG_ROOT / f"{backbone_name}_{transfer_name}_seed{seed}.log"
                record: dict[str, object] = {
                    "backbone": backbone_name,
                    "transfer": transfer_name,
                    "seed": seed,
                    "summary": str(summary_path),
                    "log": str(log_path),
                }
                if summary_path.exists() and not args.force:
                    record["status"] = "skip_completed"
                    metrics = extract_mean(summary_path)
                    for prefix, mode in [("B", "baseline_txt"), ("T", "parallel_margin"), ("C", "ted_calibrated")]:
                        for metric, value in metrics.get(mode, {}).items():
                            record[f"{prefix}_{metric}"] = value
                    records.append(record)
                    write_index(records)
                    print({"stage": "skip_completed", **record}, flush=True)
                    continue

                cmd = build_cmd(
                    transfer_name=transfer_name,
                    transfer=transfer,
                    backbone_name=backbone_name,
                    backbone=backbone,
                    seed=seed,
                    device="cuda:0",
                    force_bank=args.force_bank,
                )
                print(
                    {
                        "stage": "start",
                        "backbone": backbone_name,
                        "transfer": transfer_name,
                        "seed": seed,
                        "log": str(log_path),
                    },
                    flush=True,
                )
                with log_path.open("w") as log_file:
                    proc = subprocess.run(
                        cmd,
                        cwd=str(ROOT),
                        env=env,
                        stdout=log_file,
                        stderr=subprocess.STDOUT,
                        text=True,
                    )
                record["status"] = "done" if proc.returncode == 0 else f"failed:{proc.returncode}"
                print({"stage": "done", **record}, flush=True)
                if proc.returncode != 0:
                    records.append(record)
                    write_index(records)
                    return proc.returncode
                metrics = extract_mean(summary_path)
                for prefix, mode in [("B", "baseline_txt"), ("T", "parallel_margin"), ("C", "ted_calibrated")]:
                    for metric, value in metrics.get(mode, {}).items():
                        record[f"{prefix}_{metric}"] = value
                records.append(record)
                write_index(records)

    print({"stage": "done_all", "root": str(RESULT_ROOT), "num_records": len(records)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
