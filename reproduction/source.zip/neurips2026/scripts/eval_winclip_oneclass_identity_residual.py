from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from WinCLIP import WinClipAD  # noqa: E402
from neurips2026.common_backbones.winclip_vit import WinClipRawBackbone  # noqa: E402
from neurips2026.scripts.identity_residual_extractor import IdentityResidualExtractor  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
)
from utils.eval_utils import specify_resolution  # noqa: E402
from utils.metrics import metric_cal  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("One-class WinCLIP vs IdentityResidual textual replacement sanity check.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--ckpt_path", type=str, required=True)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--max_test_samples", type=int, default=-1)
    parser.add_argument("--k_shot", type=int, default=0)
    parser.add_argument("--fusion_mode", type=str, default="textual", choices=["textual", "harmonic"])
    parser.add_argument(
        "--adapter_mode",
        type=str,
        default="window_scatter",
        choices=["patch_map", "window_scatter"],
        help="How to inject IdentityResidual into the WinCLIP textual branch.",
    )
    parser.add_argument("--cal_pro", action="store_true")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--pixel_blur_sigma", type=float, default=0.0)
    parser.add_argument("--candidate_modes", type=str, default="replace")
    parser.add_argument("--alphas", type=str, default="1.0")
    parser.add_argument("--gate_quantile", type=float, default=0.9)
    parser.add_argument("--gate_temp", type=float, default=0.25)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="winclip_identity_residual_oneclass")
    return parser.parse_args()


def build_stock_winclip(args: argparse.Namespace, device: str) -> WinClipAD:
    model = WinClipAD(
        out_size_h=args.resolution,
        out_size_w=args.resolution,
        device=device,
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=tuple(args.scales),
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    ).to(device)
    model.eval_mode()
    model.fusion_version = "textual" if args.fusion_mode == "textual" else "textual_visual"
    model.build_text_feature_gallery(args.class_name)
    return model


def wrap_stock_backbone(model: WinClipAD, device: str) -> WinClipRawBackbone:
    return WinClipRawBackbone(
        clip_model=model.model,
        tokenizer=model.tokenizer,
        device=torch.device(device),
        image_transform=model.transform,
    )


def forward_up_to_layer(backbone: WinClipRawBackbone, image_t: torch.Tensor, layer_idx: int) -> torch.Tensor:
    seq = backbone.prepare_sequence(image_t)
    return backbone.run_blocks(seq, start_layer=1, end_layer=layer_idx)


def patchify_sequence(seq: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    seq_b = seq.permute(1, 0, 2)
    return seq_b[:, :1, :], seq_b[:, 1:, :]


class OfficialVisAWinClipDataset:
    def __init__(self, dataset_root: str, split_csv: str, class_name: str, split: str):
        self.root = Path(dataset_root)
        self.records = []
        with Path(split_csv).open(newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["object"] == class_name and row["split"] == split:
                    self.records.append(row)

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int):
        rec = self.records[idx]
        image = np.asarray(Image.open(self.root / rec["image"]).convert("RGB"))
        mask_path = rec.get("mask", "")
        if mask_path:
            mask = np.asarray(Image.open(self.root / mask_path).convert("L"))
        else:
            mask = np.zeros(image.shape[:2], dtype=np.uint8)
        label = 0 if rec["label"] == "normal" else 1
        return image, mask, label


def build_identity_prompt_bank(class_name: str) -> tuple[list[str], list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    normal_prompts = [
        normal_prompt,
        f"a close-up inspection photo of a flawless {cls} with intact shape and clean surface.",
        f"a close-up inspection photo of a normal {cls} with no visible damage or abnormality.",
        f"a close-up inspection photo of an intact {cls} with complete structure and undamaged appearance.",
    ]
    return normal_prompts, abnormal_prompts


def build_prompt_condition(backbone: WinClipRawBackbone, class_name: str, device: str) -> dict[str, torch.Tensor]:
    normal_prompts, abnormal_prompts = build_identity_prompt_bank(class_name)
    tokens_norm = backbone.tokenizer(normal_prompts).to(device)
    tokens_anom = backbone.tokenizer(abnormal_prompts).to(device)
    with torch.no_grad():
        e_norm = backbone.model.encode_text(tokens_norm).float()
        e_anom = backbone.model.encode_text(tokens_anom).float()
    e_norm = F.normalize(e_norm, dim=-1)
    e_anom = F.normalize(e_anom, dim=-1)
    return {"E_norm": e_norm, "E_anom": e_anom}


def patch_scores_to_pixel_map(scores: np.ndarray, target_size: int, blur_sigma: float) -> np.ndarray:
    side = int(round(math.sqrt(scores.shape[0])))
    if side * side != scores.shape[0]:
        raise ValueError(f"Cannot reshape patch scores of length {scores.shape[0]} into square grid.")
    score_t = torch.from_numpy(scores.reshape(1, 1, side, side)).float()
    pixel_map = F.interpolate(score_t, size=(target_size, target_size), mode="bilinear", align_corners=False)[
        0, 0
    ].cpu().numpy()
    if blur_sigma > 0:
        pixel_map = ndimage.gaussian_filter(pixel_map, sigma=float(blur_sigma))
    return pixel_map.astype(np.float32)


def extract_window_tokens(stock: WinClipAD, image_t: torch.Tensor) -> list[torch.Tensor]:
    visual_features = stock.encode_image(image_t)
    return [feat.float() for feat in visual_features]


def stack_window_tokens(window_features: list[torch.Tensor]) -> torch.Tensor:
    return torch.stack(window_features, dim=1)


def scatter_window_scores_to_textual_map(
    window_scores: np.ndarray,
    masks,
    scale_begin_indx,
    grid_size: tuple[int, int],
    resolution: int,
) -> np.ndarray:
    batch_size = window_scores.shape[0]
    num_patches = int(grid_size[0] * grid_size[1])
    token_scores = np.zeros((batch_size, num_patches), dtype=np.float32)
    token_weights = np.zeros((batch_size, num_patches), dtype=np.float32)
    scale_maps = []
    for idx, mask in enumerate(masks):
        patch_indices = np.asarray(mask).reshape(-1).astype(np.int64)
        if idx in scale_begin_indx[1:]:
            token_scores = token_scores / np.clip(token_weights, 1e-6, None)
            scale_maps.append(token_scores)
            token_scores = np.zeros((batch_size, num_patches), dtype=np.float32)
            token_weights = np.zeros((batch_size, num_patches), dtype=np.float32)
        if patch_indices.size == 0:
            continue
        token_scores[:, patch_indices] += window_scores[:, idx][:, None]
        token_weights[:, patch_indices] += 1.0
    token_scores = token_scores / np.clip(token_weights, 1e-6, None)
    scale_maps.append(token_scores)
    fused = np.stack(scale_maps, axis=0).mean(axis=0).reshape(batch_size, grid_size[0], grid_size[1])
    full_res = F.interpolate(
        torch.from_numpy(fused).unsqueeze(1),
        size=(resolution, resolution),
        mode="bilinear",
        align_corners=False,
    )[:, 0]
    return full_res.numpy().astype(np.float32)


def load_identity_residual_models(
    ckpt_path: str,
    dim: int,
    device: str,
) -> tuple[str, list[int], dict[int, IdentityResidualExtractor], IdentityResidualExtractor | None]:
    payload = torch.load(ckpt_path, map_location="cpu")
    if "state_dict" in payload:
        model = IdentityResidualExtractor(
            dim=dim,
            num_id_queries=32,
            num_res_queries=32,
            detach_residual_input=True,
        ).to(device)
        model.load_state_dict(payload["state_dict"], strict=True)
        model.eval()
        return "window", [], {}, model
    layers = sorted(int(layer) for layer in payload["layers"])
    models: dict[int, IdentityResidualExtractor] = {}
    for layer in layers:
        model = IdentityResidualExtractor(
            dim=dim,
            num_id_queries=32,
            num_res_queries=32,
            detach_residual_input=True,
        ).to(device)
        layer_state_dicts = payload["layer_state_dicts"]
        state = layer_state_dicts.get(layer)
        if state is None:
            state = layer_state_dicts.get(str(layer))
        if state is None:
            raise KeyError(f"Missing layer={layer} in checkpoint {ckpt_path}")
        model.load_state_dict(state, strict=True)
        model.eval()
        models[layer] = model
    return "layer", layers, models, None


def evaluate_oneclass(args: argparse.Namespace) -> tuple[dict[str, float], dict[str, float], dict[str, dict[str, float]]]:
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, args.class_name, "test")
    if args.max_test_samples > 0:
        normal_records = [rec for rec in ds.records if rec["label"] == "normal"]
        anomaly_records = [rec for rec in ds.records if rec["label"] != "normal"]
        half = max(1, args.max_test_samples // 2)
        ds.records = normal_records[:half] + anomaly_records[:half]

    stock = build_stock_winclip(args, device)
    backbone = wrap_stock_backbone(stock, device)
    cond = build_prompt_condition(backbone, args.class_name, device)
    dim = int(cond["E_norm"].shape[1])
    extractor_mode, layers, models, window_model = load_identity_residual_models(args.ckpt_path, dim=dim, device=device)

    if args.fusion_mode == "harmonic" and args.k_shot > 0:
        train_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, args.class_name, "train")
        train_imgs = []
        for rec in train_ds.records[: args.k_shot]:
            train_imgs.append(stock.transform(Image.open(rec["image_path"]).convert("RGB")))
        if train_imgs:
            gallery_batch = torch.stack(train_imgs, dim=0).to(
                device=device,
                dtype=stock.model.visual.conv1.weight.dtype,
            )
            stock.build_image_feature_gallery(gallery_batch)

    images = []
    gt_list = []
    gt_masks = []
    baseline_maps = []
    idres_maps = []

    for start in range(0, len(ds), args.batch_size):
        batch = [ds[i] for i in range(start, min(start + args.batch_size, len(ds)))]
        image_np_list = [item[0] for item in batch]
        mask_np_list = [item[1] for item in batch]
        label_list = [item[2] for item in batch]

        image_t = torch.stack([stock.transform(Image.fromarray(img)) for img in image_np_list], dim=0)
        image_t = image_t.to(device=device, dtype=stock.model.visual.conv1.weight.dtype)

        with torch.no_grad():
            baseline_batch = stock(image_t)
            if args.fusion_mode == "harmonic" and stock.visual_gallery is not None:
                visual_features = stock.encode_image(image_t)
                visual_batch = stock.calculate_visual_anomaly_score(visual_features)
                visual_batch = torch.nn.functional.interpolate(
                    visual_batch,
                    size=(args.resolution, args.resolution),
                    mode="bilinear",
                    align_corners=False,
                )[:, 0].cpu().numpy()
            else:
                visual_batch = None

            if extractor_mode == "window":
                if window_model is None:
                    raise RuntimeError("window_model is missing for window checkpoint")
                window_tokens = stack_window_tokens(extract_window_tokens(stock, image_t))
                outputs = window_model(window_tokens, cond["E_norm"], E_anom=cond["E_anom"], return_aux=False)
                fused_scores = outputs["score"].detach().cpu().numpy()
            else:
                layer_maps = []
                for layer in layers:
                    seq = forward_up_to_layer(backbone, image_t, layer)
                    _, patches = patchify_sequence(seq)
                    outputs = models[layer](patches, cond["E_norm"], E_anom=cond["E_anom"], return_aux=False)
                    layer_maps.append(outputs["score"].detach().cpu().numpy())
                layer_maps_np = np.stack(layer_maps, axis=0)
                fused_scores = layer_maps_np.mean(axis=0)

        if args.adapter_mode == "window_scatter" or extractor_mode == "window":
            fused_text_batch = scatter_window_scores_to_textual_map(
                fused_scores,
                stock.masks,
                stock.scale_begin_indx,
                stock.grid_size,
                args.resolution,
            )
        else:
            fused_text_batch = np.stack(
                [
                    patch_scores_to_pixel_map(
                        np.asarray(fused_scores[b_idx], dtype=np.float32),
                        target_size=args.resolution,
                        blur_sigma=args.pixel_blur_sigma,
                    )
                    for b_idx in range(fused_scores.shape[0])
                ],
                axis=0,
            )

        for b_idx, (image_np, mask_np, label) in enumerate(zip(image_np_list, mask_np_list, label_list)):
            images.append(image_np)
            gt_list.append(int(label != 0))
            mask_arr = np.asarray(mask_np)
            if mask_arr.ndim == 3:
                mask_arr = mask_arr[..., 0]
            mask_arr = (mask_arr > 0).astype(np.uint8)
            gt_masks.append(mask_arr)
            baseline_maps.append(np.asarray(baseline_batch[b_idx], dtype=np.float32))
            idres_text_map = np.asarray(fused_text_batch[b_idx], dtype=np.float32)
            if visual_batch is not None:
                visual_map = np.asarray(visual_batch[b_idx], dtype=np.float32)
                eps = 1e-6
                idres_map = 1.0 / (1.0 / np.clip(idres_text_map, eps, None) + 1.0 / np.clip(visual_map, eps, None))
            else:
                idres_map = idres_text_map
            idres_maps.append(idres_map.astype(np.float32))

    _, baseline_maps_rs, gt_masks_rs = specify_resolution(images, baseline_maps, gt_masks, resolution=(args.resolution, args.resolution))
    _, idres_maps_rs, _ = specify_resolution(images, idres_maps, gt_masks, resolution=(args.resolution, args.resolution))

    baseline_scores = np.stack(baseline_maps_rs, axis=0)
    idres_scores = np.stack(idres_maps_rs, axis=0)

    baseline_metrics = metric_cal(baseline_scores, gt_list, gt_masks_rs, cal_pro=args.cal_pro)
    idres_metrics = metric_cal(idres_scores, gt_list, gt_masks_rs, cal_pro=args.cal_pro)
    candidate_metrics = {}
    for mode in parse_str_list(args.candidate_modes):
        for alpha in parse_float_list(args.alphas):
            key = f"{mode}_alpha_{alpha:g}"
            candidate_scores = make_candidate_scores(
                baseline_scores,
                idres_scores,
                mode=mode,
                alpha=alpha,
                gate_quantile=float(args.gate_quantile),
                gate_temp=float(args.gate_temp),
            )
            candidate_metrics[key] = metric_cal(candidate_scores, gt_list, gt_masks_rs, cal_pro=args.cal_pro)
    return baseline_metrics, idres_metrics, candidate_metrics


def scatter_patch_scores_to_winclip_textual_map(
    patch_scores: np.ndarray,
    masks,
    scale_begin_indx,
    grid_size: tuple[int, int],
    resolution: int,
) -> np.ndarray:
    """Mimic WinCLIP textual scoring semantics using our patch-level anomaly score.

    WinCLIP textual branch is not a direct patch map; it builds a window-level score,
    scatters that score back to masked patches, averages across windows within each scale,
    then averages across scales. This keeps our injected map in the same score family as
    the stock textual branch.
    """
    batch_size, num_patches = patch_scores.shape
    token_scores = np.zeros((batch_size, num_patches), dtype=np.float32)
    token_weights = np.zeros((batch_size, num_patches), dtype=np.float32)
    scale_maps = []

    for idx, mask in enumerate(masks):
        mask_flat = np.asarray(mask).reshape(-1).astype(np.int64)
        if idx in scale_begin_indx[1:]:
            token_scores = token_scores / np.clip(token_weights, 1e-6, None)
            scale_maps.append(token_scores)
            token_scores = np.zeros((batch_size, num_patches), dtype=np.float32)
            token_weights = np.zeros((batch_size, num_patches), dtype=np.float32)

        if mask_flat.size > 0:
            window_score = patch_scores[:, mask_flat].mean(axis=1).astype(np.float32)
            token_scores[:, mask_flat] += window_score[:, None]
            token_weights[:, mask_flat] += 1.0

    token_scores = token_scores / np.clip(token_weights, 1e-6, None)
    scale_maps.append(token_scores)
    fused = np.stack(scale_maps, axis=0).mean(axis=0)  # [B, HW]
    fused = fused.reshape(batch_size, grid_size[0], grid_size[1])
    fused_t = torch.from_numpy(fused).unsqueeze(1)
    full_res = torch.nn.functional.interpolate(
        fused_t,
        size=(resolution, resolution),
        mode="bilinear",
        align_corners=False,
    )[:, 0]
    return full_res.numpy().astype(np.float32)


def parse_float_list(text: str) -> list[float]:
    return [float(x) for x in text.split(",") if x.strip()]


def parse_str_list(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def spatial_zscore_np(x: np.ndarray) -> np.ndarray:
    flat = x.reshape(x.shape[0], -1)
    mean = flat.mean(axis=1).reshape(-1, 1, 1)
    std = flat.std(axis=1).reshape(-1, 1, 1)
    return (x - mean) / np.clip(std, 1e-6, None)


def high_score_gate_np(x: np.ndarray, quantile: float, temp: float) -> np.ndarray:
    flat = x.reshape(x.shape[0], -1)
    threshold = np.quantile(flat, quantile, axis=1).reshape(-1, 1, 1)
    scale = flat.std(axis=1).reshape(-1, 1, 1)
    return 1.0 / (1.0 + np.exp(-((x - threshold) / (np.clip(scale, 1e-6, None) * temp + 1e-6))))


def make_candidate_scores(
    baseline_scores: np.ndarray,
    idres_scores: np.ndarray,
    mode: str,
    alpha: float,
    gate_quantile: float,
    gate_temp: float,
) -> np.ndarray:
    base = baseline_scores.astype(np.float32)
    residual = idres_scores.astype(np.float32)
    base_z = spatial_zscore_np(base)
    residual_z = spatial_zscore_np(residual)
    gate = high_score_gate_np(base_z, gate_quantile, gate_temp)
    if mode == "replace":
        return residual
    if mode == "blend":
        return ((1.0 - alpha) * base_z + alpha * residual_z).astype(np.float32)
    if mode == "residual":
        return (base_z + alpha * residual_z).astype(np.float32)
    if mode == "neg_residual":
        return (base_z - alpha * residual_z).astype(np.float32)
    if mode == "gate_residual":
        return (base_z + alpha * gate * residual_z).astype(np.float32)
    if mode == "gate_neg_residual":
        return (base_z - alpha * gate * residual_z).astype(np.float32)
    if mode == "max":
        return np.maximum(base_z, residual_z).astype(np.float32)
    raise ValueError(f"Unsupported candidate mode: {mode}")


def main() -> None:
    args = parse_args()
    baseline_metrics, idres_metrics, candidate_metrics = evaluate_oneclass(args)

    summary = {
        "class_name": args.class_name,
        "baseline_i_roc": float(baseline_metrics["i_roc"]),
        "baseline_p_roc": float(baseline_metrics["p_roc"]),
        "baseline_p_pro": float(baseline_metrics["p_pro"]),
        "idres_i_roc": float(idres_metrics["i_roc"]),
        "idres_p_roc": float(idres_metrics["p_roc"]),
        "idres_p_pro": float(idres_metrics["p_pro"]),
        "delta_i_roc": float(idres_metrics["i_roc"] - baseline_metrics["i_roc"]),
        "delta_p_roc": float(idres_metrics["p_roc"] - baseline_metrics["p_roc"]),
        "delta_p_pro": float(idres_metrics["p_pro"] - baseline_metrics["p_pro"]),
    }
    for key, metrics in candidate_metrics.items():
        summary[f"{key}_i_roc"] = float(metrics["i_roc"])
        summary[f"{key}_p_roc"] = float(metrics["p_roc"])
        summary[f"{key}_p_pro"] = float(metrics["p_pro"])
        summary[f"{key}_delta_i_roc"] = float(metrics["i_roc"] - baseline_metrics["i_roc"])
        summary[f"{key}_delta_p_roc"] = float(metrics["p_roc"] - baseline_metrics["p_roc"])
        summary[f"{key}_delta_p_pro"] = float(metrics["p_pro"] - baseline_metrics["p_pro"])

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{args.class_name}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary.keys()))
        writer.writeheader()
        writer.writerow(summary)
    with json_path.open("w") as f:
        json.dump(
            {
                "args": vars(args),
                "baseline_metrics": baseline_metrics,
                "idres_metrics": idres_metrics,
                "candidate_metrics": candidate_metrics,
                "summary": summary,
            },
            f,
            indent=2,
        )

    print(csv_path)
    print(json_path)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
