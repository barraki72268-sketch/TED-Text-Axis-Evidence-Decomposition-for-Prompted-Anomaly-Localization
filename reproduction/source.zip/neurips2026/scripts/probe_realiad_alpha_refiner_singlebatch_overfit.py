from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD
from ADPretrain.models.clip import ClipModel
from neurips2026.learned_refiner import AlphaSpaceKinematicRefiner
from neurips2026.learned_refiner.model import _prepare_patch_mask
from neurips2026.scripts.probe_realiad_alpha_refiner_clip_dryrun import (
    LAYER_IDS,
    build_mask_transform,
    build_normal_prompt_subspace,
    build_transform,
    collect_records_by_label,
    compute_patch_residual,
    dilate_mask_tensor,
    filter_trainable_anomalies,
    flatten_records,
    imagewise_mean,
    imagewise_mean_vec,
    load_mask_tensor,
    set_seed,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--clip_backbone", type=str, default="clip-large-336", choices=["clip-large-336"])
    parser.add_argument("--layer", type=int, default=12, choices=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=336)
    parser.add_argument("--imagesize", type=int, default=336)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--hidden_dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--batch_normals", type=int, default=4)
    parser.add_argument("--batch_anomalies", type=int, default=4)
    parser.add_argument("--scan_limit", type=int, default=400)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:1")
    parser.add_argument("--output_tag", type=str, default="realiad_clip_alpha_singlebatch_overfit")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def build_fixed_batch(
    normal_records: list[dict],
    anomaly_records: list[dict],
    num_normals: int,
    num_anomalies: int,
    rng: random.Random,
) -> list[dict]:
    batch = rng.sample(normal_records, num_normals) + rng.sample(anomaly_records, num_anomalies)
    rng.shuffle(batch)
    return batch


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    if args.resize != 336 or args.imagesize != 336:
        raise ValueError("Current ClipModel path is native 336 only for clip-large-336.")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_layer{args.layer}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    png_path = output_dir / f"{stem}_curves.png"

    transform = build_transform(args.resize, args.imagesize)
    mask_transform = build_mask_transform(args.imagesize)

    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.resize,
        crp_size=args.imagesize,
        msk_size=args.imagesize,
        msk_crp_size=args.imagesize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    records = flatten_records(dataset)
    normal_records, anomaly_records = collect_records_by_label(records)

    clip_model = ClipModel(args.clip_backbone, device=str(device)).eval()
    clip_model.visual_encoder = clip_model.visual_encoder.to(device)
    layer_index = LAYER_IDS.index(args.layer)
    token_side = args.imagesize // 14

    trainable_anomalies, trainable_meta = filter_trainable_anomalies(
        anomaly_records=anomaly_records,
        mask_transform=mask_transform,
        token_side=token_side,
        scan_limit=args.scan_limit,
        seed=args.seed,
        mask_dilate_kernel=args.mask_dilate_kernel,
    )
    if len(trainable_anomalies) < args.batch_anomalies:
        raise RuntimeError(
            f"Not enough trainable anomalies: need {args.batch_anomalies}, got {len(trainable_anomalies)}."
        )

    rng = random.Random(args.seed)
    batch = build_fixed_batch(
        normal_records=normal_records,
        anomaly_records=trainable_anomalies,
        num_normals=args.batch_normals,
        num_anomalies=args.batch_anomalies,
        rng=rng,
    )

    semantic_basis_by_class: dict[str, torch.Tensor] = {}
    images = []
    masks = []
    bases = []
    labels = []
    batch_records = []
    for rec in batch:
        images.append(transform(Image.open(rec["image_path"]).convert("RGB")))
        if int(rec["label"]) == 1:
            mask = dilate_mask_tensor(load_mask_tensor(rec["mask_path"], mask_transform), args.mask_dilate_kernel)
        else:
            mask = torch.zeros(1, args.imagesize, args.imagesize)
        masks.append(mask)
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = build_normal_prompt_subspace(rec["class_name"], clip_model, device)
        bases.append(semantic_basis_by_class[rec["class_name"]])
        labels.append(int(rec["label"]))
        batch_records.append(
            {
                "image_path": rec["image_path"],
                "mask_path": rec.get("mask_path"),
                "class_name": rec["class_name"],
                "anomaly_type": rec["anomaly_type"],
                "sample_id": rec["sample_id"],
                "label": int(rec["label"]),
            }
        )

    images_t = torch.stack(images, dim=0).to(device)
    masks_t = torch.stack(masks, dim=0).to(device)
    basis_t = torch.stack(bases, dim=0).to(device)

    with torch.no_grad():
        features = clip_model.encode_image_from_tensors(images_t, shape="img")[layer_index].float()

    model = AlphaSpaceKinematicRefiner(
        feature_dim=clip_model.feature_dimensions[layer_index],
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    anomaly_patch_mask = F.interpolate(masks_t.float(), size=(token_side, token_side), mode="nearest").reshape(len(batch), -1) > 0.5
    normal_patch_mask = ~anomaly_patch_mask

    step_rows = []
    for step in range(1, args.steps + 1):
        tic = time.time()
        out = model(features, semantic_basis=basis_t)
        alpha_flat = out.alpha.flatten(2).transpose(1, 2).squeeze(-1)
        alpha_n, valid_n = imagewise_mean(alpha_flat, normal_patch_mask)
        alpha_a, valid_a = imagewise_mean(alpha_flat, anomaly_patch_mask)

        if not valid_n.any() or not valid_a.any():
            raise RuntimeError("Single-batch overfit requires both valid normal and anomaly patch groups.")

        loss = -(alpha_n[valid_n].mean() - alpha_a[valid_a].mean())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        raw_tokens = features.flatten(2).transpose(1, 2)
        refined_tokens = out.refined.flatten(2).transpose(1, 2)
        local_mean_tokens = out.local_mean.flatten(2).transpose(1, 2)
        local_desc_tokens = out.local_descriptors.flatten(2).transpose(1, 2)

        raw_residual = compute_patch_residual(raw_tokens, local_mean_tokens)
        refined_residual = compute_patch_residual(refined_tokens, local_mean_tokens)
        raw_residual_n, _ = imagewise_mean(raw_residual, normal_patch_mask)
        raw_residual_a, _ = imagewise_mean(raw_residual, anomaly_patch_mask)
        refined_residual_n, _ = imagewise_mean(refined_residual, normal_patch_mask)
        refined_residual_a, _ = imagewise_mean(refined_residual, anomaly_patch_mask)
        desc_n, valid_desc_n = imagewise_mean_vec(local_desc_tokens, normal_patch_mask)
        desc_a, valid_desc_a = imagewise_mean_vec(local_desc_tokens, anomaly_patch_mask)

        alpha_std = alpha_flat.std(dim=1, unbiased=False).mean()
        row = {
            "step": step,
            "loss": float(loss.detach().item()),
            "alpha_normal_mean": float(alpha_n[valid_n].mean().detach().item()),
            "alpha_anomaly_mean": float(alpha_a[valid_a].mean().detach().item()),
            "alpha_gap": float(alpha_n[valid_n].mean().detach().item() - alpha_a[valid_a].mean().detach().item()),
            "alpha_std_mean": float(alpha_std.detach().item()),
            "input_l2_dist": float(
                torch.norm(desc_n[valid_desc_n].mean(dim=0) - desc_a[valid_desc_a].mean(dim=0), p=2).detach().item()
            ) if valid_desc_n.any() and valid_desc_a.any() else float("nan"),
            "raw_residual_normal": float(raw_residual_n.mean().detach().item()),
            "refined_residual_normal": float(refined_residual_n.mean().detach().item()),
            "raw_residual_anomaly": float(raw_residual_a.mean().detach().item()),
            "refined_residual_anomaly": float(refined_residual_a.mean().detach().item()),
            "elapsed_sec": float(time.time() - tic),
        }
        step_rows.append(row)
        print(
            f"[step {step}] loss={row['loss']:.4f} alpha_n={row['alpha_normal_mean']:.4f} "
            f"alpha_a={row['alpha_anomaly_mean']:.4f} gap={row['alpha_gap']:.4f} "
            f"alpha_std={row['alpha_std_mean']:.4f} in_l2={row['input_l2_dist']:.4f} "
            f"t={row['elapsed_sec']:.2f}s",
            flush=True,
        )

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(step_rows[0].keys()))
        writer.writeheader()
        writer.writerows(step_rows)

    summary = {
        "config": vars(args),
        "trainable_anomaly_pool": trainable_meta,
        "batch_records": batch_records,
        "final_step": step_rows[-1],
        "best_alpha_gap": float(max(row["alpha_gap"] for row in step_rows)),
        "best_alpha_normal": float(max(row["alpha_normal_mean"] for row in step_rows)),
        "best_alpha_anomaly": float(min(row["alpha_anomaly_mean"] for row in step_rows)),
    }
    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    steps = [row["step"] for row in step_rows]
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    axes[0, 0].plot(steps, [row["loss"] for row in step_rows])
    axes[0, 0].set_title("Overfit Loss")

    axes[0, 1].plot(steps, [row["alpha_normal_mean"] for row in step_rows], label="alpha_n")
    axes[0, 1].plot(steps, [row["alpha_anomaly_mean"] for row in step_rows], label="alpha_a")
    axes[0, 1].set_title("Alpha Means")
    axes[0, 1].legend()

    axes[1, 0].plot(steps, [row["alpha_gap"] for row in step_rows], label="gap")
    axes[1, 0].plot(steps, [row["alpha_std_mean"] for row in step_rows], label="alpha_std")
    axes[1, 0].set_title("Gap / Variance")
    axes[1, 0].legend()

    axes[1, 1].plot(steps, [row["refined_residual_normal"] for row in step_rows], label="normal")
    axes[1, 1].plot(steps, [row["refined_residual_anomaly"] for row in step_rows], label="anomaly")
    axes[1, 1].set_title("Refined Residual")
    axes[1, 1].legend()
    fig.tight_layout()
    fig.savefig(png_path, dpi=180)

    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_png={png_path}")
    print(json.dumps(summary["final_step"], indent=2))


if __name__ == "__main__":
    main()
