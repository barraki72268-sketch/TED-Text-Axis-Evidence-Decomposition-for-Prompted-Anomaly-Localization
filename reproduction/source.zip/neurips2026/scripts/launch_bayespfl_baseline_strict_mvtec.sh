#!/usr/bin/env bash
set -euo pipefail

GPU_ID="${1:-1}"

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
cd "$ROOT/neurips2026/Bayes-PFL"

SAVE_ROOT="$ROOT/neurips2026/results/bayespfl_strict_mvtec"
mkdir -p "$SAVE_ROOT"

CUDA_VISIBLE_DEVICES="$GPU_ID" /mnt/data/envs/patchcore-conda/bin/python train.py \
  --dataset mvtec \
  --train_data_path ./dataset/mvisa/data \
  --val_data_path ./dataset/mvisa/data \
  --save_path "$SAVE_ROOT" \
  --pretrained_path /mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt \
  --prompt_context_len 5 \
  --prompt_num 3 \
  --prompt_state_len 5 \
  --device_id 0 \
  --learning_rate 0.0001 \
  --features_list 6 12 18 24 \
  --pretrained openai \
  --image_size 518 \
  --batch_size 32 \
  --epochs 15 \
  --sample_num 5 \
  --num_flows 10 \
  --config_path ./open_clip_local/model_configs/ViT-L-14-336.json \
  --model ViT-L-14-336 \
  --seed 333 \
  --alpha 0.6 \
  --strict_source_only
