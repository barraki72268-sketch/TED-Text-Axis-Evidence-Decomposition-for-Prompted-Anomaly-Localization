from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


CLASSES = [
    "candle",
    "capsules",
    "cashew",
    "chewinggum",
    "fryum",
    "macaroni1",
    "macaroni2",
    "pcb1",
    "pcb2",
    "pcb3",
    "pcb4",
    "pipe_fryum",
]


def main() -> None:
    parser = argparse.ArgumentParser("Create AnomalyCLIP-style meta.json for official VisA 1cls split")
    parser.add_argument("--prepared_root", type=str, required=True, help="Prepared 1cls root, e.g. .../VisA_pytorch_official/1cls")
    parser.add_argument("--split_csv", type=str, required=True, help="Official split_csv/1cls.csv path from raw VisA")
    args = parser.parse_args()

    prepared_root = Path(args.prepared_root)
    split_csv = Path(args.split_csv)
    meta_path = prepared_root / "meta.json"

    info = {"train": {cls: [] for cls in CLASSES}, "test": {cls: [] for cls in CLASSES}}
    normal_samples = 0
    anomaly_samples = 0

    with split_csv.open("r", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            cls_name, split_name, label, image_path, mask_path = row
            if cls_name not in info[split_name]:
                continue
            is_anomaly = label == "anomaly"
            img_name = Path(image_path).name
            mask_name = Path(mask_path).name if is_anomaly else ""
            img_rel = f"{cls_name}/{split_name}/{'bad' if is_anomaly else 'good'}/{img_name}"
            mask_rel = f"{cls_name}/ground_truth/bad/{mask_name}" if is_anomaly else ""
            entry = {
                "img_path": img_rel,
                "mask_path": mask_rel,
                "cls_name": cls_name,
                "specie_name": "bad" if is_anomaly else "good",
                "anomaly": 1 if is_anomaly else 0,
            }
            info[split_name][cls_name].append(entry)
            if split_name == "test":
                if is_anomaly:
                    anomaly_samples += 1
                else:
                    normal_samples += 1

    with meta_path.open("w") as f:
        json.dump(info, f, indent=4)
        f.write("\n")

    print(
        json.dumps(
            {
                "prepared_root": str(prepared_root),
                "meta_path": str(meta_path),
                "normal_test_samples": normal_samples,
                "anomaly_test_samples": anomaly_samples,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
