from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from generate_anomalyclip_gtfree_overlap_figure import (  # noqa: E402
    DISCUSSION_SUMMARIES,
    PRESET_LABELS,
    collect_gtfree_topk_scores,
    compute_auc,
    histogram_overlap,
)


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"


def cohens_d(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    v1 = float(np.var(pos, ddof=1)) if pos.size > 1 else 0.0
    v0 = float(np.var(neg, ddof=1)) if neg.size > 1 else 0.0
    denom = (pos.size + neg.size - 2)
    if denom <= 0:
        return float("nan")
    pooled = math.sqrt(max(((pos.size - 1) * v1 + (neg.size - 1) * v0) / denom, 1e-12))
    return float((float(np.mean(pos)) - float(np.mean(neg))) / pooled)


def distribution_metrics(pos: np.ndarray, neg: np.ndarray) -> dict:
    _, _, _, ovl = histogram_overlap(pos, neg, bins=60)
    auc = compute_auc(pos, neg)
    mean_gap = float(np.mean(pos) - np.mean(neg))
    return {
        "auc": float(auc),
        "ovl": float(ovl),
        "bayes_error_lb": float(0.5 * ovl),
        "mean_gap": mean_gap,
        "cohens_d": cohens_d(pos, neg),
    }


def main() -> None:
    parser = argparse.ArgumentParser("Collect GT-free entanglement metrics for AnomalyCLIP")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--max_normal_images", type=int, default=64)
    parser.add_argument("--max_anomaly_images", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULTS / "anomalyclip_gtfree_entanglement"),
    )
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    arrays_manifest = {}
    for preset in DISCUSSION_SUMMARIES:
        arrays, payload = collect_gtfree_topk_scores(
            preset=preset,
            device=args.device,
            max_normal_images=args.max_normal_images,
            max_anomaly_images=args.max_anomaly_images,
            seed=args.seed,
        )
        raw = distribution_metrics(arrays["raw_anomaly"], arrays["raw_normal"])
        parallel = distribution_metrics(arrays["parallel_anomaly"], arrays["parallel_normal"])
        row = {
            "preset": preset,
            "preset_label": PRESET_LABELS[preset],
            "num_anomaly": int(payload["meta"]["num_anomaly"]),
            "num_normal": int(payload["meta"]["num_normal"]),
            "raw_auc": raw["auc"],
            "parallel_auc": parallel["auc"],
            "raw_ovl": raw["ovl"],
            "parallel_ovl": parallel["ovl"],
            "raw_bayes_error_lb": raw["bayes_error_lb"],
            "parallel_bayes_error_lb": parallel["bayes_error_lb"],
            "raw_mean_gap": raw["mean_gap"],
            "parallel_mean_gap": parallel["mean_gap"],
            "raw_cohens_d": raw["cohens_d"],
            "parallel_cohens_d": parallel["cohens_d"],
            "auc_gain": parallel["auc"] - raw["auc"],
            "ovl_reduction": raw["ovl"] - parallel["ovl"],
            "bayes_error_reduction": raw["bayes_error_lb"] - parallel["bayes_error_lb"],
        }
        rows.append(row)

        arrays_file = save_dir / f"{preset}_arrays.npz"
        np.savez_compressed(arrays_file, **arrays)
        arrays_manifest[preset] = str(arrays_file)
        print(json.dumps({"preset": preset, "auc_gain": row["auc_gain"], "ovl_reduction": row["ovl_reduction"]}), flush=True)

    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "arrays": arrays_manifest}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    labels = [r["preset_label"] for r in rows]
    y = np.arange(len(rows))
    raw_auc = [r["raw_auc"] for r in rows]
    par_auc = [r["parallel_auc"] for r in rows]
    raw_ovl = [r["raw_ovl"] for r in rows]
    par_ovl = [r["parallel_ovl"] for r in rows]

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.2), constrained_layout=True)
    ax0, ax1 = axes

    for i in range(len(rows)):
        ax0.plot([raw_auc[i], par_auc[i]], [i, i], color="#9A9A9A", lw=1.8)
        ax0.scatter(raw_auc[i], i, s=58, color="#D95F02", label="Baseline" if i == 0 else None)
        ax0.scatter(par_auc[i], i, s=58, color="#1B9E77", label="OURS" if i == 0 else None)
        ax0.text(max(raw_auc[i], par_auc[i]) + 0.01, i, f"{par_auc[i] - raw_auc[i]:+.2f}", va="center", fontsize=9)
    ax0.set_yticks(y, labels)
    ax0.set_xlim(0.0, 1.02)
    ax0.set_xlabel("AUC(Anomaly-image top-k > Normal-image top-k)")
    ax0.set_title("Ranking Separability")
    ax0.grid(axis="x", alpha=0.15)
    ax0.legend(frameon=False, loc="lower right")

    for i in range(len(rows)):
        ax1.plot([raw_ovl[i], par_ovl[i]], [i, i], color="#9A9A9A", lw=1.8)
        ax1.scatter(raw_ovl[i], i, s=58, color="#D95F02", label="Baseline" if i == 0 else None)
        ax1.scatter(par_ovl[i], i, s=58, color="#1B9E77", label="OURS" if i == 0 else None)
        ax1.text(max(raw_ovl[i], par_ovl[i]) + 0.01, i, f"{raw_ovl[i] - par_ovl[i]:+.2f}", va="center", fontsize=9)
    ax1.set_yticks(y, labels)
    ax1.set_xlim(0.0, 1.02)
    ax1.set_xlabel("Overlap Coefficient (OVL)")
    ax1.set_title("Entanglement")
    ax1.grid(axis="x", alpha=0.15)

    fig.suptitle("GT-free Entanglement Metrics for AnomalyCLIP", fontsize=13)
    fig.savefig(save_dir / "entanglement_summary.png", dpi=220, bbox_inches="tight")
    fig.savefig(save_dir / "entanglement_summary.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
