from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.ndimage import binary_dilation, binary_erosion, gaussian_filter, label
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner  # noqa: E402
from utils import get_transform  # noqa: E402


def build_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_text_features(model, params, checkpoint_path: Path, device: str) -> torch.Tensor:
    prompt_learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    prompt_learner.eval()
    model.to(device)
    model.eval()

    prompts, tokenized_prompts, compound_prompts_text = prompt_learner(cls_id=None)
    prompts = prompts.to(device)
    tokenized_prompts = tokenized_prompts.to(device)
    compound_prompts_text = [prompt.to(device) for prompt in compound_prompts_text]
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)
    return text_features


def compute_map(model, text_features: torch.Tensor, image: torch.Tensor, features_list: list[int], image_size: int, sigma: int):
    _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
    maps = []
    for patch_feature in patch_features:
        patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
        similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_features[0])
        similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], image_size)
        anomaly_map = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0
        maps.append(anomaly_map)
    anomaly_map = torch.stack(maps).sum(dim=0)[0].detach().cpu().numpy()
    return gaussian_filter(anomaly_map, sigma=sigma)


def safe_mean(arr: np.ndarray) -> float:
    return float(arr.mean()) if arr.size > 0 else 0.0


def topk_mean(vals: np.ndarray, frac: float) -> float:
    if vals.size == 0:
        return 0.0
    k = max(1, int(vals.size * frac))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def extract_region_descriptor(score_map: np.ndarray, region_mask: np.ndarray) -> dict[str, float]:
    vals = score_map[region_mask]
    area = int(vals.size)
    if area == 0:
        return {}
    ys, xs = np.where(region_mask)
    y0, y1 = ys.min(), ys.max()
    x0, x1 = xs.min(), xs.max()
    bbox_h = int(y1 - y0 + 1)
    bbox_w = int(x1 - x0 + 1)
    bbox_area = float(max(1, bbox_h * bbox_w))
    fill_ratio = float(area / bbox_area)

    eroded = binary_erosion(region_mask, structure=np.ones((3, 3), dtype=bool), border_value=0)
    boundary = region_mask & (~eroded)
    interior = region_mask & eroded

    dilated = binary_dilation(region_mask, structure=np.ones((5, 5), dtype=bool))
    ring = dilated & (~region_mask)

    peak = float(vals.max())
    mean = float(vals.mean())
    p90 = float(np.percentile(vals, 90))
    std = float(vals.std())
    top10 = topk_mean(vals, 0.1)
    boundary_mean = safe_mean(score_map[boundary])
    interior_mean = safe_mean(score_map[interior]) if interior.any() else mean
    ring_mean = safe_mean(score_map[ring]) if ring.any() else 0.0
    perimeter = float(boundary.sum())
    compactness = float((4.0 * math.pi * area) / max(perimeter * perimeter, 1e-8))
    peak_over_mean = float(peak / max(mean, 1e-8))
    top10_over_mean = float(top10 / max(mean, 1e-8))
    aspect_ratio = float(max(bbox_h, bbox_w) / max(1, min(bbox_h, bbox_w)))

    return {
        "peak": peak,
        "mean": mean,
        "top10_mean": top10,
        "p90": p90,
        "std": std,
        "area": float(area),
        "fill_ratio": fill_ratio,
        "compactness": compactness,
        "boundary_mean": boundary_mean,
        "interior_mean": interior_mean,
        "boundary_gap": float(interior_mean - boundary_mean),
        "ring_mean": ring_mean,
        "ring_contrast": float(mean - ring_mean),
        "peak_over_mean": peak_over_mean,
        "top10_over_mean": top10_over_mean,
        "aspect_ratio": aspect_ratio,
    }


def iterate_components(binary_mask: np.ndarray):
    labeled, num = label(binary_mask.astype(np.uint8), structure=np.ones((3, 3), dtype=np.uint8))
    for comp_idx in range(1, num + 1):
        yield labeled == comp_idx


def collect_fp_bank(
    model,
    text_features,
    data_root: str,
    image_size: int,
    features_list: list[int],
    sigma: int,
    device: str,
    top_fracs: list[float],
    min_area: int,
):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=data_root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode="train")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)
    rows = []
    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            cls_name = items["cls_name"][0]
            anomaly_map = compute_map(model, text_features, image, features_list, image_size, sigma)
            for frac in top_fracs:
                mask = top_fraction_mask(anomaly_map, frac)
                for comp in iterate_components(mask):
                    if int(comp.sum()) < min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    desc.update(
                        {
                            "bank": "fp",
                            "cls_name": cls_name,
                            "img_idx": img_idx,
                            "threshold_frac": frac,
                        }
                    )
                    rows.append(desc)
            if img_idx % 50 == 0:
                print(
                    json.dumps(
                        {
                            "stage": "fp_bank_progress",
                            "img_idx": img_idx,
                            "num_regions": len(rows),
                        }
                    ),
                    flush=True,
                )
    return rows


def collect_defect_bank(
    model,
    text_features,
    data_root: str,
    image_size: int,
    features_list: list[int],
    sigma: int,
    device: str,
    min_area: int,
):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=data_root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode="test")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)
    rows = []
    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            if int(items["anomaly"][0].item()) == 0:
                continue
            image = items["img"].to(device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            anomaly_map = compute_map(model, text_features, image, features_list, image_size, sigma)
            for comp in iterate_components(gt_mask):
                if int(comp.sum()) < min_area:
                    continue
                desc = extract_region_descriptor(anomaly_map, comp)
                if not desc:
                    continue
                desc.update(
                    {
                        "bank": "defect",
                        "cls_name": cls_name,
                        "img_idx": img_idx,
                        "threshold_frac": -1.0,
                    }
                )
                rows.append(desc)
            if img_idx % 50 == 0:
                print(
                    json.dumps(
                        {
                            "stage": "defect_bank_progress",
                            "img_idx": img_idx,
                            "num_regions": len(rows),
                        }
                    ),
                    flush=True,
                )
    return rows


def evaluate_descriptor_banks(fp_rows: list[dict], defect_rows: list[dict], save_dir: Path):
    feature_names = [
        "peak",
        "mean",
        "top10_mean",
        "p90",
        "std",
        "area",
        "fill_ratio",
        "compactness",
        "boundary_mean",
        "interior_mean",
        "boundary_gap",
        "ring_mean",
        "ring_contrast",
        "peak_over_mean",
        "top10_over_mean",
        "aspect_ratio",
    ]

    def rows_to_matrix(rows):
        return np.asarray([[float(r[f]) for f in feature_names] for r in rows], dtype=np.float32)

    X_fp = rows_to_matrix(fp_rows)
    X_def = rows_to_matrix(defect_rows)
    X = np.concatenate([X_fp, X_def], axis=0)
    y = np.concatenate([np.zeros(len(X_fp), dtype=np.int64), np.ones(len(X_def), dtype=np.int64)], axis=0)

    single = []
    for i, name in enumerate(feature_names):
        auc = roc_auc_score(y, X[:, i])
        eff_auc = max(float(auc), float(1.0 - auc))
        sign = "defect_high" if auc >= 0.5 else "fp_high"
        single.append({"feature": name, "auc_raw": float(auc), "auc_effective": eff_auc, "direction": sign})
    single.sort(key=lambda x: x["auc_effective"], reverse=True)

    combos = [
        ["peak", "area"],
        ["peak", "mean"],
        ["peak", "top10_mean"],
        ["peak", "fill_ratio"],
        ["peak", "compactness"],
        ["peak", "ring_contrast"],
        ["peak", "area", "fill_ratio"],
        ["peak", "mean", "area", "fill_ratio", "compactness", "ring_contrast"],
    ]

    name_to_idx = {name: i for i, name in enumerate(feature_names)}
    combo_rows = []
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
    for combo in combos:
        idxs = [name_to_idx[c] for c in combo]
        X_sel = X[:, idxs]
        pred = np.zeros(len(y), dtype=np.float64)
        for tr, te in cv.split(X_sel, y):
            clf = Pipeline(
                [
                    ("scaler", StandardScaler()),
                    ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
                ]
            )
            clf.fit(X_sel[tr], y[tr])
            pred[te] = clf.predict_proba(X_sel[te])[:, 1]
        auc = roc_auc_score(y, pred)
        combo_rows.append({"combo": "+".join(combo), "auc_cv": float(auc)})
    combo_rows.sort(key=lambda x: x["auc_cv"], reverse=True)

    summary = {
        "num_fp_regions": len(fp_rows),
        "num_defect_regions": len(defect_rows),
        "single_descriptor_auc": single,
        "combo_cv_auc": combo_rows,
    }

    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    with open(save_dir / "single_descriptor_auc.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["feature", "auc_raw", "auc_effective", "direction"])
        writer.writeheader()
        writer.writerows(single)
    with open(save_dir / "combo_cv_auc.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["combo", "auc_cv"])
        writer.writeheader()
        writer.writerows(combo_rows)

    plt.figure(figsize=(9, 4.8))
    top_single = single[:8]
    xs = np.arange(len(top_single))
    plt.bar(xs, [row["auc_effective"] for row in top_single], color="#1f77b4")
    plt.xticks(xs, [row["feature"] for row in top_single], rotation=35, ha="right")
    plt.ylim(0.5, 1.0)
    plt.ylabel("AUC")
    plt.title("Top Single Descriptors: FP vs Defect")
    plt.tight_layout()
    plt.savefig(save_dir / "single_descriptor_auc.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 4.8))
    top_combo = combo_rows[:8]
    xs = np.arange(len(top_combo))
    plt.bar(xs, [row["auc_cv"] for row in top_combo], color="#ff7f0e")
    plt.xticks(xs, [row["combo"] for row in top_combo], rotation=35, ha="right")
    plt.ylim(0.5, 1.0)
    plt.ylabel("CV AUC")
    plt.title("Descriptor Combo CV AUC: FP vs Defect")
    plt.tight_layout()
    plt.savefig(save_dir / "combo_cv_auc.png", dpi=180)
    plt.close()


def save_rows(rows: list[dict], path: Path):
    if not rows:
        return
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe AnomalyCLIP source region banks and descriptor separability")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--fp_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_source_region_bank_descriptor_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    text_features = load_text_features(model, params, Path(args.checkpoint_path), device)

    print(
        json.dumps(
            {
                "stage": "region_bank_start",
                "checkpoint_path": args.checkpoint_path,
                "fp_fracs": args.fp_fracs,
                "min_area": args.min_area,
            },
            indent=2,
        ),
        flush=True,
    )

    fp_rows = collect_fp_bank(
        model=model,
        text_features=text_features,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        sigma=args.sigma,
        device=device,
        top_fracs=args.fp_fracs,
        min_area=args.min_area,
    )
    print(json.dumps({"stage": "fp_bank_done", "num_regions": len(fp_rows)}, indent=2), flush=True)

    save_dir.mkdir(parents=True, exist_ok=True)
    save_rows(fp_rows, save_dir / "fp_bank.csv")
    print(json.dumps({"stage": "fp_bank_saved", "path": str(save_dir / "fp_bank.csv")}, indent=2), flush=True)

    defect_rows = collect_defect_bank(
        model=model,
        text_features=text_features,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        sigma=args.sigma,
        device=device,
        min_area=args.min_area,
    )
    print(json.dumps({"stage": "defect_bank_done", "num_regions": len(defect_rows)}, indent=2), flush=True)

    save_rows(fp_rows, save_dir / "fp_bank.csv")
    save_rows(defect_rows, save_dir / "defect_bank.csv")
    evaluate_descriptor_banks(fp_rows, defect_rows, save_dir)
    print(json.dumps({"stage": "region_bank_summary_saved", "save_dir": str(save_dir)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
