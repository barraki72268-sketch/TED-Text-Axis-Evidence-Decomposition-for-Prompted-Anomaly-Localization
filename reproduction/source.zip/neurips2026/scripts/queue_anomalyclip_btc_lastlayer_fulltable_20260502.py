#!/usr/bin/env python3
"""Queue AnomalyCLIP B/T/C runs for the host-wise result table.

This is the clean main-table protocol:
- B: official AnomalyCLIP local map from the official last-layer recipe.
- T: train-free TED on the same last-layer recipe.
- C: source-calibrated TED anchored to the host local score.

Runs are source-to-target transfers with three calibrator seeds. The queue can
wait for an upstream PID to avoid GPU contention and is intended to be launched
through the detached launcher.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_btc_lastlayer_autosign_fulltable_20260502"
LOG_ROOT = RESULT_ROOT / "_logs"
BANK_ROOT = RESULT_ROOT / "bank_cache"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")

MVTEC_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth")
VISA_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth")

TRANSFERS = {
    "visa2mvtec": {
        "source_root": VISA_ROOT,
        "source_dataset": "visa",
        "target_root": MVTEC_ROOT,
        "target_dataset": "mvtec",
        "checkpoint": VISA_CKPT,
    },
    "mvtec2visa": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": VISA_ROOT,
        "target_dataset": "visa",
        "checkpoint": MVTEC_CKPT,
    },
    "mvtec2mpdd": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": MPDD_ROOT,
        "target_dataset": "mpdd",
        "checkpoint": MVTEC_CKPT,
    },
    "mvtec2btad": {
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": BTAD_ROOT,
        "target_dataset": "btad",
        "checkpoint": MVTEC_CKPT,
    },
}


def live_pid(pid: int) -> bool:
    return pid > 0 and Path(f"/proc/{pid}").exists()


def wait_pid(pid: int) -> None:
    if not live_pid(pid):
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while live_pid(pid):
        time.sleep(60)
    print({"stage": "wait_pid_done", "pid": pid}, flush=True)


def parse_csv(raw: str) -> list[str]:
    return [x.strip() for x in raw.split(",") if x.strip()]


def build_cmd(name: str, transfer: dict[str, str], seed: int, device: str, force_bank: bool) -> list[str]:
    save_dir = RESULT_ROOT / f"{name}_seed{seed}"
    bank_path = BANK_ROOT / f"anomalyclip_{name}_lastlayer_withscores.pt"
    cmd = [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        transfer["checkpoint"],
        "--heldout_class",
        "none",
        "--source_root",
        transfer["source_root"],
        "--source_dataset",
        transfer["source_dataset"],
        "--target_root",
        transfer["target_root"],
        "--target_dataset",
        transfer["target_dataset"],
        "--target_mode",
        "test",
        "--baseline_features_list",
        "24",
        "--features_list",
        "24",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--ted_margin_sign",
        "auto_source",
        "--score_bank_cache_path",
        str(bank_path),
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if force_bank or not bank_path.exists():
        cmd.append("--refresh_bank_cache")
    return cmd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--transfers", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--force_bank", action="store_true")
    args = parser.parse_args()

    wait_pid(args.wait_pid)
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    BANK_ROOT.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.device_id)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-anomalyclip-btc-20260502")

    transfers = parse_csv(args.transfers)
    seeds = [int(x) for x in parse_csv(args.seeds)]
    unknown = [name for name in transfers if name not in TRANSFERS]
    if unknown:
        raise SystemExit(f"Unknown transfers {unknown}; allowed={sorted(TRANSFERS)}")

    for name in transfers:
        transfer = TRANSFERS[name]
        for seed in seeds:
            save_dir = RESULT_ROOT / f"{name}_seed{seed}"
            summary_path = save_dir / "summary.json"
            log_path = LOG_ROOT / f"{name}_seed{seed}.log"
            if summary_path.exists() and not args.force:
                print({"stage": "skip_completed", "transfer": name, "seed": seed, "summary": str(summary_path)}, flush=True)
                continue
            cmd = build_cmd(name, transfer, seed, "cuda:0", args.force_bank)
            print({"stage": "start", "transfer": name, "seed": seed, "log": str(log_path)}, flush=True)
            with log_path.open("w") as log_file:
                proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
            print({"stage": "done", "transfer": name, "seed": seed, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
            if proc.returncode != 0:
                return proc.returncode
    print({"stage": "done_all", "root": str(RESULT_ROOT)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
