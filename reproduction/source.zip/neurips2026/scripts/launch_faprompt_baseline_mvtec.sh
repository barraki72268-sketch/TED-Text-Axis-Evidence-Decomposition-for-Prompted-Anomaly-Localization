#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"
GPU_ID="${1:-0}"

export FAPROMPT_CACHE_DIR="/mnt/data/pilab-kingjinyoung/ADPretrain/FAPrompt/.cache/clip"

MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
SAVE_ROOT="${ROOT}/neurips2026/results/faprompt_baseline_mvtec"
CKPT_DIR="${SAVE_ROOT}/checkpoints"

mkdir -p "${CKPT_DIR}"

cd "${ROOT}/neurips2026/FAPrompt"

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" train.py \
  --dataset mvtecad \
  --train_data_path "${MVTEC_ROOT}" \
  --save_path "${CKPT_DIR}" \
  --features_list 6 12 18 24 \
  --image_size 518 \
  --batch_size 8 \
  --print_freq 1 \
  --epoch 15 \
  --save_freq 1 \
  --depth 9 \
  --n_ctx 12 \
  --t_n_ctx 4 \
  --seed 111
