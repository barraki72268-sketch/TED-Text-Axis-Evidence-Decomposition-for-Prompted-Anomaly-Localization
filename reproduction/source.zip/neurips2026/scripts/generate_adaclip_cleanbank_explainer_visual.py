from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

from official_parallel_test_adaclip import (
    build_model,
    build_target_dataset,
    compute_baseline_outputs,
    load_bank_cache,
    logmeanexp_negative_sqdist_1d,
    refine_layer_logits,
    smooth_map,
    layer_map_to_scalar_map,
)


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"
VISA_BANK = ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_visa_clean_multilayer.pt"
HAZELNUT_SUMMARY = ROOT / "neurips2026" / "results" / "official_parallel_test_adaclip_cleanbank_gate_hazelnut_v2" / "summary.json"

CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)


def safe_auc(score_map: np.ndarray, gt_mask: np.ndarray) -> float:
    pos = score_map[gt_mask]
    neg = score_map[~gt_mask]
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def tensor_to_rgb(img_tensor: torch.Tensor) -> np.ndarray:
    arr = img_tensor.detach().cpu().numpy().transpose(1, 2, 0)
    arr = arr * CLIP_STD + CLIP_MEAN
    return np.clip(arr, 0.0, 1.0)


def overlay_heatmap(rgb: np.ndarray, score_map: np.ndarray, alpha: float = 0.45) -> np.ndarray:
    norm = score_map.astype(np.float32)
    norm = norm - norm.min()
    if norm.max() > 1e-6:
        norm = norm / norm.max()
    cmap = plt.get_cmap("jet")
    heat = cmap(norm)[..., :3]
    return np.clip((1 - alpha) * rgb + alpha * heat, 0.0, 1.0)


def build_parallel_outputs(
    baseline: dict,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    image_size: int,
    tau: float,
    fp_weight: float,
    scoring_mode: str,
    refine_alpha: float,
    refine_beta: float,
    margin_norm_mode: str,
    sigma: float,
) -> dict:
    axis = baseline["axis"]
    device = axis.device
    qdef_layer_maps = []
    qfp_layer_maps = []
    margin_layer_maps = []
    refined_layer_logits = []

    for layer_idx, patch_feature in enumerate(baseline["patch_tokens"]):
        patch = patch_feature[0]
        fp_coeff = fp_banks[layer_idx].to(device) @ axis if fp_banks[layer_idx].numel() else torch.empty((0,), device=device)
        def_coeff = def_banks[layer_idx].to(device) @ axis if def_banks[layer_idx].numel() else torch.empty((0,), device=device)
        coeff = patch @ axis
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=tau)
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=tau)
        h = int(round(math.sqrt(patch.shape[0])))

        qfp_map = q_fp.reshape(1, 1, h, h)
        qdef_map = q_def.reshape(1, 1, h, h)
        margin_map = (q_def - fp_weight * q_fp).reshape(1, 1, h, h)

        qfp_map = F.interpolate(qfp_map, size=(image_size, image_size), mode="bilinear", align_corners=True)
        qdef_map = F.interpolate(qdef_map, size=(image_size, image_size), mode="bilinear", align_corners=True)
        margin_map = F.interpolate(margin_map, size=(image_size, image_size), mode="bilinear", align_corners=True)

        qfp_layer_maps.append(qfp_map)
        qdef_layer_maps.append(qdef_map)
        margin_layer_maps.append(margin_map)
        refined_layer_logits.append(
            refine_layer_logits(
                layer_logits=baseline["layer_logits"][layer_idx],
                margin_map=margin_map,
                scoring_mode=scoring_mode,
                refine_alpha=refine_alpha,
                refine_beta=refine_beta,
                margin_norm_mode=margin_norm_mode,
            )
        )

    qfp_map = torch.stack(qfp_layer_maps, dim=0).mean(dim=0)[:, 0]
    qdef_map = torch.stack(qdef_layer_maps, dim=0).mean(dim=0)[:, 0]
    margin_map = torch.stack(margin_layer_maps, dim=0).mean(dim=0)[:, 0]
    refined_logits = torch.stack(refined_layer_logits, dim=0).mean(dim=0)
    refined_probs = torch.softmax(refined_logits, dim=1)
    ours_map = layer_map_to_scalar_map(refined_probs)[:, 0]

    qfp_map = smooth_map(qfp_map, sigma=sigma)
    qdef_map = smooth_map(qdef_map, sigma=sigma)
    margin_map = smooth_map(margin_map, sigma=sigma)
    ours_map = smooth_map(ours_map, sigma=sigma)

    return {
        "qfp_map": qfp_map.detach().cpu().numpy()[0],
        "qdef_map": qdef_map.detach().cpu().numpy()[0],
        "margin_map": margin_map.detach().cpu().numpy()[0],
        "ours_map": ours_map.detach().cpu().numpy()[0],
    }


def main() -> None:
    parser = argparse.ArgumentParser("Generate AdaCLIP clean-bank explainer visual")
    parser.add_argument("--class_name", type=str, default="hazelnut")
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(MVTEC_ROOT))
    parser.add_argument("--target_dataset", type=str, default="mvtec")
    parser.add_argument("--bank_cache_path", type=str, default=str(VISA_BANK))
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--fp_weight", type=float, default=0.3)
    parser.add_argument("--scoring_mode", type=str, default="logit_gate_posneg")
    parser.add_argument("--refine_alpha", type=float, default=0.3)
    parser.add_argument("--refine_beta", type=float, default=0.15)
    parser.add_argument("--margin_norm_mode", type=str, default="spatial_tanh_zscore")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_cleanbank_explainer_hazelnut"),
    )
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    model = build_model(
        device=args.device,
        checkpoint_path=args.checkpoint_path,
        image_size=args.image_size,
        prompting_depth=4,
        prompting_length=5,
        prompting_branch="VL",
        prompting_type="SD",
        use_hsf=True,
        k_clusters=20,
    )
    fp_banks, def_banks, bank_stats, cache_meta = load_bank_cache(Path(args.bank_cache_path))
    dataset = build_target_dataset(args.target_root, args.target_dataset, model, training=False, class_name=args.class_name)

    best = None
    rows = []
    with torch.inference_mode():
        for idx in range(len(dataset)):
            item = dataset[idx]
            if int(item["anomaly"]) == 0:
                continue
            image = item["img"].unsqueeze(0).to(args.device)
            gt_mask = item["img_mask"].squeeze().detach().cpu().numpy() > 0.5
            if not gt_mask.any():
                continue

            baseline = compute_baseline_outputs(model, image, args.class_name, args.sigma)
            parallel = build_parallel_outputs(
                baseline=baseline,
                fp_banks=fp_banks,
                def_banks=def_banks,
                image_size=args.image_size,
                tau=args.tau,
                fp_weight=args.fp_weight,
                scoring_mode=args.scoring_mode,
                refine_alpha=args.refine_alpha,
                refine_beta=args.refine_beta,
                margin_norm_mode=args.margin_norm_mode,
                sigma=args.sigma,
            )
            baseline_map = baseline["baseline_map"].detach().cpu().numpy()[0]
            ours_map = parallel["ours_map"]
            baseline_auc = safe_auc(baseline_map, gt_mask)
            ours_auc = safe_auc(ours_map, gt_mask)
            delta_auc = ours_auc - baseline_auc
            row = {
                "dataset_index": idx,
                "img_path": item.get("img_path", ""),
                "baseline_local_auc": baseline_auc,
                "ours_local_auc": ours_auc,
                "delta_local_auc": delta_auc,
            }
            rows.append(row)
            if best is None or delta_auc > best["delta_local_auc"]:
                best = {
                    **row,
                    "baseline_map": baseline_map,
                    "ours_map": ours_map,
                    "qdef_map": parallel["qdef_map"],
                    "qfp_map": parallel["qfp_map"],
                    "margin_map": parallel["margin_map"],
                    "gt_mask": gt_mask,
                    "img_tensor": item["img"],
                }

    if best is None:
        raise RuntimeError(f"No anomaly sample found for class {args.class_name}")

    if best["img_path"]:
        rgb = np.asarray(Image.open(best["img_path"]).convert("RGB").resize((args.image_size, args.image_size))) / 255.0
    else:
        rgb = tensor_to_rgb(best["img_tensor"])

    fig, axes = plt.subplots(1, 6, figsize=(18, 3.6))
    panels = [
        ("Input", rgb),
        ("GT", best["gt_mask"].astype(np.float32)),
        (f"Baseline\nAUC {best['baseline_local_auc']:.3f}", overlay_heatmap(rgb, best["baseline_map"])),
        ("Defect Support $q_{def}$", overlay_heatmap(rgb, best["qdef_map"])),
        ("Hard-FP Support $q_{fp}$", overlay_heatmap(rgb, best["qfp_map"])),
        (f"Ours\nAUC {best['ours_local_auc']:.3f}", overlay_heatmap(rgb, best["ours_map"])),
    ]
    for ax, (title, panel) in zip(axes, panels):
        if panel.ndim == 2:
            ax.imshow(panel, cmap="gray")
        else:
            ax.imshow(panel)
        ax.set_title(title, fontsize=10)
        ax.axis("off")
    fig.suptitle(
        f"AdaCLIP clean-bank refinement on {args.class_name} "
        f"(best sample ΔAUC={best['delta_local_auc']:.3f})",
        fontsize=12,
    )
    fig.tight_layout()

    png_path = save_dir / f"{args.class_name}_explainer.png"
    pdf_path = save_dir / f"{args.class_name}_explainer.pdf"
    fig.savefig(png_path, dpi=200, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)

    class_summary = {}
    if HAZELNUT_SUMMARY.exists() and args.class_name == "hazelnut":
        class_summary = json.loads(HAZELNUT_SUMMARY.read_text())

    payload = {
        "settings": {
            "class_name": args.class_name,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "bank_cache_path": args.bank_cache_path,
            "scoring_mode": args.scoring_mode,
            "fp_weight": args.fp_weight,
            "refine_alpha": args.refine_alpha,
            "refine_beta": args.refine_beta,
            "margin_norm_mode": args.margin_norm_mode,
            "bank_stats": bank_stats,
            "cache_meta": cache_meta,
        },
        "best_sample": {
            "dataset_index": best["dataset_index"],
            "img_path": best["img_path"],
            "baseline_local_auc": best["baseline_local_auc"],
            "ours_local_auc": best["ours_local_auc"],
            "delta_local_auc": best["delta_local_auc"],
            "baseline_inside_mean": float(best["baseline_map"][best["gt_mask"]].mean()),
            "baseline_outside_mean": float(best["baseline_map"][~best["gt_mask"]].mean()),
            "ours_inside_mean": float(best["ours_map"][best["gt_mask"]].mean()),
            "ours_outside_mean": float(best["ours_map"][~best["gt_mask"]].mean()),
        },
        "all_samples": rows,
        "class_summary": class_summary,
        "files": {
            "png": str(png_path),
            "pdf": str(pdf_path),
        },
    }
    with open(save_dir / f"{args.class_name}_explainer.json", "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
