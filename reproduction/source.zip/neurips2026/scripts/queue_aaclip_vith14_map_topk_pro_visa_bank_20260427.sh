#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

PY="/mnt/data/envs/patchcore-conda/bin/python"
WAIT_PIDS="${WAIT_PIDS:-1558713 1579933}"

wait_for_gpu_pids() {
  for pid in "$@"; do
    [[ -z "${pid}" ]] && continue
    while nvidia-smi --query-compute-apps=pid --format=csv,noheader | tr -d ' ' | grep -qx "${pid}"; do
      echo "[$(date '+%F %T')] waiting for GPU pid ${pid}"
      sleep 60
    done
  done
}

run_vith() {
  local preset="$1"
  local save_dir="$2"
  echo "[$(date '+%F %T')] start AA-CLIP ViT-H ${preset} -> ${save_dir}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip.py \
    --preset "${preset}" \
    --model_name ViT-H-14 \
    --pretrained laion2b_s32b_b79k \
    --adapter_load_mode project_crop \
    --levels 8,16,24,32 \
    --img_size 224 \
    --batch_size 4 \
    --num_workers 4 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas=-0.5 \
    --blend_modes prescore_rectify \
    --candidate_topk_frac 0.10 \
    --gate_sharpness 3.0 \
    --candidate_image_mode map_topk \
    --cal_pro \
    --aupro_max_step 50 \
    --device cuda:1 \
    --save_dir "${save_dir}"
  echo "[$(date '+%F %T')] done AA-CLIP ViT-H ${preset}"
}

wait_for_gpu_pids ${WAIT_PIDS}

run_vith visa2mvtec neurips2026/results/aaclip_prescore_segtoken_vith14_visa2mvtec_img224_full_neg05_map_topk_pro_20260427
run_vith visa2mpdd neurips2026/results/aaclip_prescore_segtoken_vith14_visa2mpdd_img224_full_neg05_map_topk_pro_20260427
run_vith visa2btad neurips2026/results/aaclip_prescore_segtoken_vith14_visa2btad_img224_full_neg05_map_topk_pro_20260427

echo "[$(date '+%F %T')] AA-CLIP ViT-H map_topk P-PRO queue finished"
