#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

bash neurips2026/scripts/queue_aaclip_vith14_map_topk_pro_visa_bank_20260427.sh
WAIT_PIDS="" bash neurips2026/scripts/queue_dinov2_bridge_pro_visa_bank_20260427.sh
