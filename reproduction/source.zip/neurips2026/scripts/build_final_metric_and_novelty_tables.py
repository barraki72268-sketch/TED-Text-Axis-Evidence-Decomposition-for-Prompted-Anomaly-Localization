#!/usr/bin/env python3
from __future__ import annotations

import csv
import glob
import json
import math
import re
from collections import defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT_DIR = RESULTS / "final_metric_and_novelty_tables"

METRIC_ORDER = ["i_auc", "i_ap", "p_auc", "p_ap", "p_pro"]
METRIC_LABEL = {
    "i_auc": "I-AUROC",
    "i_ap": "I-AP",
    "p_auc": "P-AUROC",
    "p_ap": "P-AP",
    "p_pro": "P-PRO",
}


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def pct(value: Any) -> float | None:
    if value is None:
        return None
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(value):
        return None
    return value * 100.0 if abs(value) <= 1.5 else value


def as_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(value):
        return None
    return value


def metric_value(raw: dict[str, Any], keys: tuple[str, ...]) -> float | None:
    for key in keys:
        value = as_float(raw.get(key))
        if value is not None:
            return value
    return None


def fmt(value: float | None) -> str:
    return "--" if value is None else f"{value:.2f}"


def fmt_delta(value: float | None) -> str:
    if value is None:
        return "--"
    return f"{value:+.2f}"


def norm_metrics(raw: dict[str, Any]) -> dict[str, float | None]:
    scale_keys = [
        ("image_auroc", "image_auc"),
        ("pixel_auroc", "pixel_auc"),
        ("pixel_aupro", "pixel_pro"),
    ]
    scale_probe = [metric_value(raw, keys) for keys in scale_keys]
    already_percent = any(value is not None and abs(value) > 1.5 for value in scale_probe)

    def convert(value: Any) -> float | None:
        value = as_float(value)
        if value is None:
            return None
        return value if already_percent else value * 100.0

    return {
        "i_auc": convert(metric_value(raw, ("image_auroc", "image_auc"))),
        "i_ap": convert(raw.get("image_ap")),
        "p_auc": convert(metric_value(raw, ("pixel_auroc", "pixel_auc"))),
        "p_ap": convert(raw.get("pixel_ap")),
        "p_pro": convert(metric_value(raw, ("pixel_aupro", "pixel_pro"))),
    }


def mean_by_mode(path: Path) -> dict[str, dict[str, float | None]]:
    data = load_json(path)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in data.get("rows", []):
        grouped[str(row.get("mode"))].append(row)
    out: dict[str, dict[str, float | None]] = {}
    for mode, rows in grouped.items():
        raw: dict[str, float] = {}
        keys = [k for k in rows[0].keys() if k not in {"mode", "target_label"}]
        for key in keys:
            vals = [float(r[key]) for r in rows if r.get(key) is not None and not math.isnan(float(r[key]))]
            if vals:
                raw[key] = sum(vals) / len(vals)
        out[mode] = norm_metrics(raw)
    return out


def preset_from_name(name: str) -> str | None:
    match = re.search(r"(visa2mvtec|mvtec2visa|mvtec2mpdd|mvtec2btad|visa2mpdd|visa2btad)", name)
    return match.group(1) if match else None


def pretty_preset(preset: str | None) -> str:
    mapping = {
        "visa2mvtec": "VisA->MVTec",
        "mvtec2visa": "MVTec->VisA",
        "mvtec2mpdd": "MVTec->MPDD",
        "mvtec2btad": "MVTec->BTAD",
        "visa2mpdd": "VisA->MPDD",
        "visa2btad": "VisA->BTAD",
    }
    return mapping.get(preset or "", preset or "--")


def metric_gain(base: dict[str, float | None], ours: dict[str, float | None]) -> dict[str, float | None]:
    out: dict[str, float | None] = {}
    for key in METRIC_ORDER:
        out[key] = None if base.get(key) is None or ours.get(key) is None else ours[key] - base[key]  # type: ignore[operator]
    return out


def add_perf_row(
    rows: list[dict[str, Any]],
    host: str,
    backbone: str,
    transfer: str,
    baseline: dict[str, float | None],
    ours: dict[str, float | None],
    variant: str,
    source: str,
) -> None:
    gain = metric_gain(baseline, ours)
    row: dict[str, Any] = {
        "host": host,
        "backbone": backbone,
        "transfer": transfer,
        "ours_variant": variant,
        "source": source,
    }
    for key in METRIC_ORDER:
        row[f"baseline_{key}"] = baseline.get(key)
        row[f"ours_{key}"] = ours.get(key)
        row[f"delta_{key}"] = gain.get(key)
    rows.append(row)


def rawclip_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    paths = sorted(
        list(RESULTS.glob("official_parallel_test_rawclip_*_all/summary.json"))
        + list(RESULTS.glob("official_parallel_test_rawimagebind_*_all/summary.json"))
    )
    for path in paths:
        name = path.parent.name
        if "fp05_sig" in name:
            continue
        data = load_json(path)
        summary = data.get("summary", {})
        modes = mean_by_mode(path)
        base = modes.get("baseline_txt")
        ours = modes.get("parallel_margin")
        if not base or not ours:
            continue
        backbone = summary.get("backbone") or summary.get("pretrained_dataset") or "ImageBind"
        if name.startswith("official_parallel_test_rawimagebind"):
            backbone = "ImageBind-Huge"
        transfer = pretty_preset(preset_from_name(name))
        add_perf_row(rows, "Raw", str(backbone), transfer, base, ours, "parallel_margin", str(path))
    return rows


def official_host_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    specs = [
        ("AdaCLIP", sorted(RESULTS.glob("official_parallel_test_adaclip*_all*/summary.json"))),
        ("AdaptCLIP", sorted(RESULTS.glob("official_parallel_test_adaptclip*_all*/summary.json"))),
    ]
    # Prefer the most recent clean/vlrefine runs when duplicates exist for the same transfer.
    best_path: dict[tuple[str, str], Path] = {}
    for host, paths in specs:
        for path in paths:
            name = path.parent.name
            preset = preset_from_name(name)
            if not preset:
                continue
            key = (host, preset)
            old = best_path.get(key)
            if old is None:
                best_path[key] = path
                continue
            score = int("cleanbank_gate" in name) + int("vlrefine" in name) + int("_nw8" not in name)
            old_score = int("cleanbank_gate" in old.parent.name) + int("vlrefine" in old.parent.name) + int("_nw8" not in old.parent.name)
            if score > old_score:
                best_path[key] = path

    for (host, _preset), path in sorted(best_path.items()):
        data = load_json(path)
        summary = data.get("summary", {})
        modes = mean_by_mode(path)
        base = modes.get("baseline_txt")
        ours = modes.get("parallel_margin")
        if not base or not ours:
            continue
        if host == "AdaCLIP":
            backbone = "ViT-L/14@336"
        else:
            backbone = str(summary.get("pretrained_model", "ViT-L/14@336"))
        transfer = pretty_preset(preset_from_name(path.parent.name))
        add_perf_row(rows, host, backbone, transfer, base, ours, "parallel_margin", str(path))
    return rows


def anomalyclip_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(RESULTS.glob("anomalyclip_text_axis_decomposition_*discussion/summary.json")):
        data = load_json(path)
        learned = {(r.get("axis"), r.get("component")): r for r in data.get("rows", [])}
        base_raw = learned.get(("learned", "raw"))
        ours_raw = learned.get(("learned", "parallel"))
        if not base_raw or not ours_raw:
            continue
        base = norm_metrics(base_raw)
        ours = norm_metrics(ours_raw)
        transfer = pretty_preset(preset_from_name(path.parent.name))
        add_perf_row(rows, "AnomalyCLIP", "ViT-L/14@336", transfer, base, ours, "learned_parallel", str(path))
    return rows


def flatten_aaclip_variants(mean: dict[str, Any]) -> list[tuple[str, dict[str, float | None]]]:
    out: list[tuple[str, dict[str, float | None]]] = []
    for key, value in mean.items():
        if key == "baseline":
            continue
        if key == "candidates":
            for cand_key, cand_value in value.items():
                out.append((cand_key, norm_metrics(cand_value)))
        elif isinstance(value, dict):
            out.append((key, norm_metrics(value)))
    return out


def aaclip_rows() -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    patterns = [
        "aaclip_prescore_segtoken_*map_topk_pro_20260427/summary.json",
        "aaclip_dinov2base_bridge_*map_topk_pro_20260427/summary.json",
    ]
    for pattern in patterns:
        for path_str in glob.glob(str(RESULTS / pattern)):
            path = Path(path_str)
            if path.parent.name.startswith("_debug"):
                continue
            data = load_json(path)
            preset = str(data.get("preset") or preset_from_name(path.parent.name))
            model_name = str(data.get("model_name") or data.get("image_backbone") or "unknown")
            if "dinov2" in model_name.lower():
                backbone = "DINOv2-B bridge"
            elif "ViT-H" in model_name:
                backbone = "ViT-H/14"
            elif "ViT-L" in model_name:
                backbone = "ViT-L/14"
            else:
                backbone = "ViT-B/16+"
            key = (backbone, preset)
            mean = data.get("mean", {})
            base = norm_metrics(mean.get("baseline", {}))
            variants = flatten_aaclip_variants(mean)
            entry = grouped.setdefault(
                key,
                {"baseline": base, "variants": [], "paths": []},
            )
            entry["paths"].append(str(path))
            if base.get("p_auc") is not None:
                entry["baseline"] = base
            entry["variants"].extend((variant, metrics, str(path)) for variant, metrics in variants)

    rows: list[dict[str, Any]] = []
    for (backbone, preset), entry in sorted(grouped.items()):
        variants = entry["variants"]
        if not variants:
            continue
        variant, ours, source = max(variants, key=lambda x: x[1].get("p_auc") if x[1].get("p_auc") is not None else -1e9)
        add_perf_row(rows, "AA-CLIP", backbone, pretty_preset(preset), entry["baseline"], ours, variant, source)
    return rows


def faprompt_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    paths = sorted(
        list(RESULTS.glob("faprompt_backbone_swap_vitb_prescore_hostaxis_*full*/summary.json"))
        + list(RESULTS.glob("faprompt_official_vitl_prescore_hostaxis_*full*/summary.json"))
        + list(RESULTS.glob("faprompt_vitl14openai_prescore_hostaxis_*full*/summary.json"))
    )
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    for path in paths:
        data = load_json(path)
        mean = data.get("mean", {})
        if "baseline_official" not in mean or "parallel" not in mean:
            continue
        model = str(data.get("model_name", "unknown"))
        if "ViT-B" in model:
            backbone = "ViT-B/16+"
        elif "openai" in path.parent.name.lower():
            backbone = "ViT-L/14 OpenAI"
        elif "ViT-L" in model:
            backbone = "ViT-L/14@336"
        else:
            backbone = model
        preset = str(data.get("preset") or preset_from_name(path.parent.name))
        key = (backbone, preset)
        entry = grouped.setdefault(key, {"baseline": norm_metrics(mean["baseline_official"]), "variants": []})
        for variant, metrics in mean["parallel"].items():
            entry["variants"].append((variant, norm_metrics(metrics), str(path)))

    for (backbone, preset), entry in sorted(grouped.items()):
        variants = entry["variants"]
        if not variants:
            continue
        variant, ours, source = max(variants, key=lambda x: x[1].get("p_auc") if x[1].get("p_auc") is not None else -1e9)
        add_perf_row(rows, "FAPrompt", backbone, pretty_preset(preset), entry["baseline"], ours, variant, source)
    return rows


def performance_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    rows.extend(rawclip_rows())
    rows.extend(anomalyclip_rows())
    rows.extend(official_host_rows())
    rows.extend(aaclip_rows())
    rows.extend(faprompt_rows())
    host_order = {"Raw": 0, "AnomalyCLIP": 1, "AdaCLIP": 2, "AdaptCLIP": 3, "AA-CLIP": 4, "FAPrompt": 5}
    rows.sort(key=lambda r: (host_order.get(r["host"], 99), r["backbone"], r["transfer"]))
    return rows


def host_entanglement_rows() -> list[dict[str, Any]]:
    path = RESULTS / "quick_host_survey_20260425.json"
    data = load_json(path)["AD_host_map_separability"]
    rows = []
    for host in ["AnomalyCLIP", "AdaptCLIP", "AdaCLIP", "FAPrompt"]:
        r = data[host]
        rows.append(
            {
                "host": host,
                "baseline_pair_auc": r["baseline_true_vs_hardfp_auc"] * 100.0,
                "ours_pair_auc": r["matched_true_topk_vs_hardfp_topk_auc"] * 100.0,
                "delta_pair_auc": (r["matched_true_topk_vs_hardfp_topk_auc"] - r["baseline_true_vs_hardfp_auc"]) * 100.0,
                "baseline_mean_gap": r["baseline_gap"],
                "ours_mean_gap": r["matched_gap"],
                "delta_mean_gap": r["matched_gap"] - r["baseline_gap"],
                "baseline_p50_gap": r["baseline_p50_gap"],
            }
        )
    return rows


def candidate_entanglement_rows() -> list[dict[str, Any]]:
    rows = []
    for path in sorted(RESULTS.glob("candidate_entanglement_*_v1/summary.json")):
        data = load_json(path)
        mean = data.get("mean", {})
        base = mean.get("baseline", {})
        ours = mean.get("ours_residual", {})
        fused = mean.get("fused", {})
        rows.append(
            {
                "host": data.get("host"),
                "transfer": pretty_preset(data.get("preset")),
                "baseline_auc": pct(base.get("auc")),
                "ours_residual_auc": pct(ours.get("auc")),
                "fused_auc": pct(fused.get("auc")),
                "baseline_hardfp_above": pct(base.get("hardfp_above_defect_median")),
                "ours_hardfp_above": pct(ours.get("hardfp_above_defect_median")),
                "fused_hardfp_above": pct(fused.get("hardfp_above_defect_median")),
                "baseline_overlap_iqr": base.get("overlap_iqr"),
                "ours_overlap_iqr": ours.get("overlap_iqr"),
                "fused_overlap_iqr": fused.get("overlap_iqr"),
                "source": str(path),
            }
        )
    return rows


def faprompt_stress_rows() -> list[dict[str, Any]]:
    path = RESULTS / "faprompt_backbone_entanglement_figure" / "faprompt_entangle_rescue_story.json"
    data = load_json(path)
    rows = []
    official = norm_metrics(data["official_baseline"])
    swapped = norm_metrics(data["swapped_baseline"])
    ours = norm_metrics(data["swapped_ours"])
    for metric in ["p_auc", "p_pro", "p_ap"]:
        denom = None
        if official[metric] is not None and swapped[metric] is not None:
            denom = official[metric] - swapped[metric]  # type: ignore[operator]
        recovery = None
        if denom is not None and abs(denom) > 1e-12 and ours[metric] is not None:
            recovery = (ours[metric] - swapped[metric]) / denom * 100.0  # type: ignore[operator]
        rows.append(
            {
                "metric": METRIC_LABEL[metric],
                "official_vitl": official[metric],
                "swapped_vitb": swapped[metric],
                "swapped_ours": ours[metric],
                "drop": None if denom is None else -denom,
                "recovery_percent": recovery,
            }
        )
    hist = {
        "metric": "HardFP/Defect Pair AUC",
        "baseline": data["baseline_hist"]["auc"] * 100.0,
        "ours": data["ours_hist"]["auc"] * 100.0,
        "delta": (data["ours_hist"]["auc"] - data["baseline_hist"]["auc"]) * 100.0,
    }
    overlap = {
        "metric": "Distribution Overlap",
        "baseline": data["baseline_hist"]["overlap"],
        "ours": data["ours_hist"]["overlap"],
        "delta": data["ours_hist"]["overlap"] - data["baseline_hist"]["overlap"],
    }
    rescue = {
        "metric": "Net Pair Rescue",
        "baseline": 0.0,
        "ours": data["pairwise_rescue"]["net_pair_gain"] * 100.0,
        "delta": data["pairwise_rescue"]["net_pair_gain"] * 100.0,
    }
    return rows, [hist, overlap, rescue]


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})


def performance_markdown(rows: list[dict[str, Any]]) -> str:
    headers = ["Host", "Backbone", "Transfer"]
    for key in METRIC_ORDER:
        label = METRIC_LABEL[key]
        headers.extend([f"{label} Base", f"{label} Ours", "Delta"])
    headers.append("Variant")
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        cells = [row["host"], row["backbone"], row["transfer"]]
        for key in METRIC_ORDER:
            cells.extend([fmt(row[f"baseline_{key}"]), fmt(row[f"ours_{key}"]), fmt_delta(row[f"delta_{key}"])])
        cells.append(row["ours_variant"])
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def performance_latex(rows: list[dict[str, Any]]) -> str:
    cols = "lll" + "rrr" * len(METRIC_ORDER) + "l"
    lines = [
        "\\begin{tabular}{" + cols + "}",
        "\\toprule",
        "Host & Backbone & Transfer & "
        + " & ".join(
            f"{METRIC_LABEL[m]}$_b$ & {METRIC_LABEL[m]}$_o$ & $\\Delta$" for m in METRIC_ORDER
        )
        + " & Variant \\\\",
        "\\midrule",
    ]
    for row in rows:
        cells = [row["host"], row["backbone"], row["transfer"]]
        for key in METRIC_ORDER:
            cells.extend([fmt(row[f"baseline_{key}"]), fmt(row[f"ours_{key}"]), fmt_delta(row[f"delta_{key}"])])
        cells.append(row["ours_variant"].replace("_", "\\_"))
        lines.append(" & ".join(cells) + " \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    return "\n".join(lines)


def novelty_markdown(host_rows: list[dict[str, Any]], stress_rows: list[dict[str, Any]], trace_rows: list[dict[str, Any]], candidate_rows: list[dict[str, Any]]) -> str:
    lines = ["# Novelty Metrics\n"]
    lines.append("## Cross-host hard-FP / defect separability\n")
    lines.append("| Host | Pair AUC Base | Pair AUC Ours | Delta | Mean Gap Base | Mean Gap Ours | Delta |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for row in host_rows:
        lines.append(
            f"| {row['host']} | {row['baseline_pair_auc']:.2f} | {row['ours_pair_auc']:.2f} | {row['delta_pair_auc']:+.2f} | "
            f"{row['baseline_mean_gap']:.4f} | {row['ours_mean_gap']:.4f} | {row['delta_mean_gap']:+.4f} |"
        )
    lines.append("\n## FAPrompt backbone-stress recovery\n")
    lines.append("| Metric | Official ViT-L | Swapped ViT-B | Swapped+OURS | Recovery |")
    lines.append("|---|---:|---:|---:|---:|")
    for row in stress_rows:
        lines.append(
            f"| {row['metric']} | {fmt(row['official_vitl'])} | {fmt(row['swapped_vitb'])} | {fmt(row['swapped_ours'])} | {fmt(row['recovery_percent'])}% |"
        )
    lines.append("\n## Traced hard-FP / defect pair\n")
    lines.append("| Metric | Baseline | Ours | Delta |")
    lines.append("|---|---:|---:|---:|")
    for row in trace_rows:
        lines.append(f"| {row['metric']} | {fmt(row['baseline'])} | {fmt(row['ours'])} | {fmt_delta(row['delta'])} |")
    lines.append("\n## Candidate-region entanglement probes\n")
    lines.append("| Host | Transfer | AUC Base | AUC Ours-residual | AUC Fused | Hard-FP Above Base | Hard-FP Above Ours |")
    lines.append("|---|---|---:|---:|---:|---:|---:|")
    for row in candidate_rows:
        lines.append(
            f"| {row['host']} | {row['transfer']} | {fmt(row['baseline_auc'])} | {fmt(row['ours_residual_auc'])} | "
            f"{fmt(row['fused_auc'])} | {fmt(row['baseline_hardfp_above'])} | {fmt(row['ours_hardfp_above'])} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    perf = performance_rows()
    host_novel = host_entanglement_rows()
    candidate_novel = candidate_entanglement_rows()
    stress_rows, trace_rows = faprompt_stress_rows()

    perf_fields = ["host", "backbone", "transfer"]
    for key in METRIC_ORDER:
        perf_fields.extend([f"baseline_{key}", f"ours_{key}", f"delta_{key}"])
    perf_fields.extend(["ours_variant", "source"])
    write_csv(OUT_DIR / "performance_table.csv", perf, perf_fields)
    (OUT_DIR / "performance_table.md").write_text(performance_markdown(perf), encoding="utf-8")
    (OUT_DIR / "performance_table.tex").write_text(performance_latex(perf), encoding="utf-8")
    (OUT_DIR / "performance_table.json").write_text(json.dumps(perf, indent=2), encoding="utf-8")

    novelty = {
        "cross_host_entanglement": host_novel,
        "faprompt_backbone_stress": stress_rows,
        "faprompt_traced_pair": trace_rows,
        "candidate_region_entanglement": candidate_novel,
    }
    (OUT_DIR / "novelty_metrics.json").write_text(json.dumps(novelty, indent=2), encoding="utf-8")
    (OUT_DIR / "novelty_metrics.md").write_text(
        novelty_markdown(host_novel, stress_rows, trace_rows, candidate_novel),
        encoding="utf-8",
    )
    write_csv(
        OUT_DIR / "novelty_cross_host_entanglement.csv",
        host_novel,
        [
            "host",
            "baseline_pair_auc",
            "ours_pair_auc",
            "delta_pair_auc",
            "baseline_mean_gap",
            "ours_mean_gap",
            "delta_mean_gap",
            "baseline_p50_gap",
        ],
    )
    write_csv(
        OUT_DIR / "novelty_faprompt_backbone_stress.csv",
        stress_rows,
        ["metric", "official_vitl", "swapped_vitb", "swapped_ours", "drop", "recovery_percent"],
    )
    write_csv(
        OUT_DIR / "novelty_candidate_region_entanglement.csv",
        candidate_novel,
        [
            "host",
            "transfer",
            "baseline_auc",
            "ours_residual_auc",
            "fused_auc",
            "baseline_hardfp_above",
            "ours_hardfp_above",
            "fused_hardfp_above",
            "baseline_overlap_iqr",
            "ours_overlap_iqr",
            "fused_overlap_iqr",
            "source",
        ],
    )

    print(OUT_DIR / "performance_table.md")
    print(OUT_DIR / "performance_table.tex")
    print(OUT_DIR / "novelty_metrics.md")
    print(OUT_DIR / "novelty_metrics.json")


if __name__ == "__main__":
    main()
