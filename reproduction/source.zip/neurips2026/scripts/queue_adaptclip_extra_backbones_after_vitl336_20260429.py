from __future__ import annotations

import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
QUEUE = ROOT / "neurips2026" / "scripts" / "queue_adaptclip_dualbranch_20260429.py"
RESULTS = ROOT / "neurips2026" / "results"

CURRENT_BACKBONE = "vitl336"
TRANSFERS = ("mvtec2mpdd", "mvtec2btad", "visa2mvtec")
SEEDS = (0, 1, 2)


def expected_current_summaries() -> list[Path]:
    return [
        RESULTS / f"adaptclip_dualbranch_{CURRENT_BACKBONE}_{transfer}_seed{seed}_20260429" / "summary.json"
        for transfer in TRANSFERS
        for seed in SEEDS
    ]


def main() -> None:
    expected = expected_current_summaries()
    while True:
        missing = [path for path in expected if not path.exists()]
        if not missing:
            break
        print(
            f"[wait] vitl336 current queue: {len(expected) - len(missing)}/{len(expected)} summaries ready; "
            f"next missing={missing[0]}",
            flush=True,
        )
        time.sleep(60)

    cmd = [
        str(PYTHON),
        "-u",
        str(QUEUE),
        "--device",
        "cuda:0",
        "--backbones",
        "vitl14openai,vitb16plus,vith14",
        "--transfers",
        ",".join(TRANSFERS),
        "--seeds",
        "0,1,2",
    ]
    print("[run-extra] " + " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=str(ROOT), check=True)


if __name__ == "__main__":
    main()
