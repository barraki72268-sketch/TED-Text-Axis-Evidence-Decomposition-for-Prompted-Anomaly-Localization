from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from official_parallel_test_rawclip import (  # noqa: E402
    GenericMetaDataset,
    build_transforms,
    create_winclip_raw_backbone,
    encode_global_image_feature,
    encode_prompt_pair,
    load_bank_cache,
    logmeanexp_negative_sqdist_1d,
    smooth_map,
    topk_mean,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Generate a few raw-CLIP qualitative baseline vs ours visualizations")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default=str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"))
    parser.add_argument("--target_split", type=str, default="test")
    parser.add_argument("--class_name", type=str, nargs="+", default=["capsules"])
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--image_size", type=int, default=240)
    parser.add_argument("--prompt_mode", type=str, default="class")
    parser.add_argument("--features_list", type=int, nargs="+", default=[3, 6, 9, 12])
    parser.add_argument(
        "--bank_cache_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bank_cache" / "rawclip_ViT-B-16-plus-240_laion400m_e32_mvtec_mvtec_class_exclude-none_bda7638d347d.pt"),
    )
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--scan_good", type=int, default=24)
    parser.add_argument("--scan_bad", type=int, default=24)
    parser.add_argument("--only_anomaly", action="store_true")
    parser.add_argument("--examples_per_class", type=int, default=1)
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument(
        "--output_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "rawclip_qualitative_capsules"),
    )
    return parser.parse_args()


def overlay_heatmap(
    image_np: np.ndarray,
    score_map: np.ndarray,
    alpha: float = 0.45,
    cmap_name: str = "turbo",
    nonnegative_only: bool = False,
) -> np.ndarray:
    score = score_map.astype(np.float32)
    if score.shape[:2] != image_np.shape[:2]:
        score = np.array(
            Image.fromarray(score.astype(np.float32), mode="F").resize(
                (image_np.shape[1], image_np.shape[0]), resample=Image.BILINEAR
            )
        )
    if nonnegative_only:
        score = np.clip(score, 0.0, None)
    lo = float(np.percentile(score, 2))
    hi = float(np.percentile(score, 98))
    if hi <= lo:
        hi = lo + 1e-6
    score = np.clip((score - lo) / (hi - lo), 0.0, 1.0)
    cmap = plt.get_cmap(cmap_name)
    heat = cmap(score)[..., :3]
    image_f = image_np.astype(np.float32) / 255.0
    out = (1.0 - alpha) * image_f + alpha * heat
    return np.clip(out * 255.0, 0, 255).astype(np.uint8)


def overlay_gt(image_np: np.ndarray, mask_np: np.ndarray, alpha: float = 0.55) -> np.ndarray:
    mask = mask_np.astype(np.float32)
    if mask.shape[:2] != image_np.shape[:2]:
        mask = np.array(
            Image.fromarray(mask.astype(np.float32), mode="F").resize(
                (image_np.shape[1], image_np.shape[0]), resample=Image.NEAREST
            )
        )
    mask = (mask > 0.5).astype(np.float32)
    image_f = image_np.astype(np.float32) / 255.0
    overlay = image_f.copy()
    red = np.zeros_like(image_f)
    red[..., 0] = 1.0
    overlay = image_f * (1.0 - alpha * mask[..., None]) + red * (alpha * mask[..., None])
    return np.clip(overlay * 255.0, 0, 255).astype(np.uint8)


def resize_score_map(score_map: np.ndarray, target_hw: tuple[int, int]) -> np.ndarray:
    if score_map.shape[:2] == target_hw:
        return score_map.astype(np.float32)
    return np.array(
        Image.fromarray(score_map.astype(np.float32), mode="F").resize(
            (target_hw[1], target_hw[0]), resample=Image.BILINEAR
        )
    ).astype(np.float32)


def compute_per_image_pro(score_map: np.ndarray, mask_bool: np.ndarray, n_thresh: int = 100) -> float | None:
    if mask_bool.sum() == 0 or (~mask_bool).sum() == 0:
        return None
    labeled, n_comp = ndimage.label(mask_bool.astype(np.uint8))
    if n_comp == 0:
        return None
    thresholds = np.linspace(float(score_map.min()), float(score_map.max()), n_thresh)
    fprs = []
    pros = []
    neg = ~mask_bool
    neg_count = max(int(neg.sum()), 1)
    for thr in thresholds[::-1]:
        pred = score_map >= thr
        fp = np.logical_and(pred, neg).sum()
        fpr = fp / neg_count
        comp_overlaps = []
        for comp_id in range(1, n_comp + 1):
            comp = labeled == comp_id
            comp_size = int(comp.sum())
            if comp_size == 0:
                continue
            comp_overlaps.append(np.logical_and(pred, comp).sum() / comp_size)
        if comp_overlaps:
            fprs.append(fpr)
            pros.append(float(np.mean(comp_overlaps)))
    if len(fprs) < 2:
        return None
    order = np.argsort(fprs)
    fprs = np.asarray(fprs)[order]
    pros = np.asarray(pros)[order]
    max_fpr = 0.3
    keep = fprs <= max_fpr
    if keep.sum() < 2:
        return None
    fprs = fprs[keep]
    pros = pros[keep]
    return float(np.trapz(pros, fprs) / max_fpr)


def compute_pixel_metrics(score_map: np.ndarray, mask_np: np.ndarray) -> dict[str, float | None]:
    mask_bool = mask_np > 0.5
    if mask_bool.sum() == 0 or (~mask_bool).sum() == 0:
        return {"auroc": None, "ap": None, "pro": None}
    y_true = mask_bool.reshape(-1).astype(np.uint8)
    y_score = score_map.reshape(-1).astype(np.float32)
    auroc = float(roc_auc_score(y_true, y_score))
    ap = float(average_precision_score(y_true, y_score))
    pro = compute_per_image_pro(score_map, mask_bool)
    return {"auroc": auroc, "ap": ap, "pro": pro}


def fmt_metric_triplet(metrics: dict[str, float | None]) -> str:
    def _fmt(v: float | None) -> str:
        return "--" if v is None else f"{v:.3f}"
    return f"pAUC={_fmt(metrics['auroc'])}  pPRO={_fmt(metrics['pro'])}  pAP={_fmt(metrics['ap'])}"


def compute_maps(backbone, item: dict, fp_banks: dict[int, torch.Tensor], def_banks: dict[int, torch.Tensor], args: argparse.Namespace):
    image = item["img"].unsqueeze(0).to(backbone.device)
    cls_name = item["cls_name"]
    text_pair = encode_prompt_pair(backbone, cls_name, args.prompt_mode)
    image_feature = encode_global_image_feature(backbone, image)
    img_logits = image_feature @ torch.stack([text_pair["norm_img"], text_pair["anom_img"]], dim=1)
    global_anom_prob = float((img_logits / 0.07).softmax(dim=-1)[0, 1].item())

    patch_dict = backbone.extract_layer_patch_tokens(image, target_layers=args.features_list)
    baseline_layer_maps = []
    parallel_layer_maps = []
    for out_idx, layer in enumerate(args.features_list):
        patch = F.normalize(patch_dict[layer][0].float(), dim=-1)
        logits = patch @ torch.stack([text_pair["norm_tok"], text_pair["anom_tok"]], dim=1)
        probs = (logits / 0.07).softmax(dim=-1)[:, 1]
        h, w = backbone.grid_size
        if patch.shape[0] != h * w:
            h = int(round(patch.shape[0] ** 0.5))
            w = patch.shape[0] // h
        baseline_map = probs.reshape(1, 1, h, w)
        baseline_map = F.interpolate(baseline_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
        baseline_layer_maps.append(baseline_map)

        axis = text_pair["axis_tok"]
        coeff = patch @ axis
        fp_coeff = fp_banks[out_idx].to(backbone.device) @ axis if fp_banks[out_idx].numel() else torch.empty((0,), device=backbone.device)
        def_coeff = def_banks[out_idx].to(backbone.device) @ axis if def_banks[out_idx].numel() else torch.empty((0,), device=backbone.device)
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=args.tau)
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=args.tau)
        parallel_map = (q_def - q_fp).reshape(1, 1, h, w)
        parallel_map = F.interpolate(parallel_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
        parallel_layer_maps.append(parallel_map)

    baseline_map = smooth_map(torch.stack(baseline_layer_maps).mean(dim=0), sigma=args.sigma)[0].numpy()
    parallel_map = smooth_map(torch.stack(parallel_layer_maps).mean(dim=0), sigma=args.sigma)[0].numpy()
    baseline_img_score = 0.5 * global_anom_prob + 0.5 * topk_mean(baseline_map.reshape(-1), args.image_score_topk)
    ours_img_score = 0.5 * global_anom_prob + 0.5 * topk_mean(parallel_map.reshape(-1), args.image_score_topk)
    return baseline_map, parallel_map, baseline_img_score, ours_img_score


def score_class_items(backbone, args: argparse.Namespace, image_transform, mask_transform, fp_banks, def_banks, cls_name: str):
    ds = GenericMetaDataset(
        root=args.target_root,
        image_transform=image_transform,
        mask_transform=mask_transform,
        split=args.target_split,
        class_name=cls_name,
    )

    good_candidates = []
    bad_candidates = []
    for item in ds.items:
        if int(item["anomaly"]) == 0 and len(good_candidates) < args.scan_good:
            good_candidates.append(item)
        elif int(item["anomaly"]) == 1 and len(bad_candidates) < args.scan_bad:
            bad_candidates.append(item)
        if len(good_candidates) >= args.scan_good and len(bad_candidates) >= args.scan_bad:
            break

    def materialize(meta_item: dict) -> dict:
        img_path = Path(args.target_root) / meta_item["img_path"]
        img = Image.open(img_path).convert("RGB")
        anomaly = int(meta_item["anomaly"])
        mask_path = meta_item.get("mask_path")
        if anomaly == 0 or not mask_path:
            mask = Image.fromarray(np.zeros((img.size[1], img.size[0]), dtype=np.uint8), mode="L")
        else:
            raw_mask = np.array(Image.open(Path(args.target_root) / mask_path).convert("L")) > 0
            mask = Image.fromarray(raw_mask.astype(np.uint8) * 255, mode="L")
        return {
            "img": image_transform(img),
            "img_mask": mask_transform(mask),
            "cls_name": meta_item["cls_name"],
            "anomaly": anomaly,
            "img_path": str(img_path),
            "raw_image": np.array(img),
        }

    scored_good = []
    for meta_item in good_candidates:
        item = materialize(meta_item)
        baseline_map, parallel_map, baseline_img_score, ours_img_score = compute_maps(backbone, item, fp_banks, def_banks, args)
        scored_good.append(
            {
                "role": "normal",
                "item": item,
                "baseline_map": baseline_map,
                "ours_map": parallel_map,
                "baseline_img_score": baseline_img_score,
                "ours_img_score": ours_img_score,
                "mask_area": 0.0,
            }
        )

    scored_bad = []
    for meta_item in bad_candidates:
        item = materialize(meta_item)
        baseline_map, parallel_map, baseline_img_score, ours_img_score = compute_maps(backbone, item, fp_banks, def_banks, args)
        mask_area = float(item["img_mask"].numpy().sum())
        scored_bad.append(
            {
                "role": "anomaly",
                "item": item,
                "baseline_map": baseline_map,
                "ours_map": parallel_map,
                "baseline_img_score": baseline_img_score,
                "ours_img_score": ours_img_score,
                "mask_area": mask_area,
            }
        )
    return scored_good, scored_bad


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=args.device,
        img_resize=args.image_size,
        img_cropsize=args.image_size,
    )
    image_transform, mask_transform = build_transforms(args.image_size)
    fp_banks, def_banks, _, _ = load_bank_cache(Path(args.bank_cache_path))
    class_names = args.class_name
    selected = []
    for cls_name in class_names:
        scored_good, scored_bad = score_class_items(backbone, args, image_transform, mask_transform, fp_banks, def_banks, cls_name)
        if args.only_anomaly:
            for rec in scored_bad:
                gt_mask = rec["item"]["img_mask"][0].numpy()
                ours_pos = np.clip(rec["ours_map"], 0.0, None)
                ours_metrics = compute_pixel_metrics(resize_score_map(ours_pos, gt_mask.shape), gt_mask)
                rec["_selection_ap"] = -1.0 if ours_metrics["ap"] is None else float(ours_metrics["ap"])
                rec["_selection_auroc"] = -1.0 if ours_metrics["auroc"] is None else float(ours_metrics["auroc"])
            ranked_bad = sorted(
                scored_bad,
                key=lambda x: (x["_selection_ap"], x["_selection_auroc"], x["mask_area"]),
                reverse=True,
            )
            selected.extend(ranked_bad[: args.examples_per_class])
        else:
            hard_fp = max(scored_good, key=lambda x: x["baseline_img_score"])
            anomaly_large = max(scored_bad, key=lambda x: x["mask_area"])
            anomaly_strong = max(scored_bad, key=lambda x: x["baseline_img_score"])
            selected.extend([hard_fp, anomaly_large])
            if anomaly_strong["item"]["img_path"] != anomaly_large["item"]["img_path"]:
                selected.append(anomaly_strong)
            else:
                selected.append(sorted(scored_bad, key=lambda x: x["baseline_img_score"], reverse=True)[1])

    fig, axes = plt.subplots(len(selected), 4, figsize=(19.5, 4.8 * len(selected)), constrained_layout=True)
    if len(selected) == 1:
        axes = np.expand_dims(axes, 0)

    col_titles = ["Input + GT", "Baseline", "Ours (D-S)", "Score Histogram"]
    for j, title in enumerate(col_titles):
        axes[0, j].set_title(title, fontsize=18, fontweight="bold")

    summary_rows = []
    for row_idx, rec in enumerate(selected):
        raw_img = rec["item"]["raw_image"]
        gt_mask = rec["item"]["img_mask"][0].numpy()
        gt_overlay = overlay_gt(raw_img, gt_mask)
        base_overlay = overlay_heatmap(raw_img, rec["baseline_map"], cmap_name="magma")
        ours_pos = np.clip(rec["ours_map"], 0.0, None)
        ours_pos_overlay = overlay_heatmap(raw_img, ours_pos, cmap_name="Reds", nonnegative_only=True)
        baseline_score = resize_score_map(rec["baseline_map"], gt_mask.shape)
        ours_score = resize_score_map(ours_pos, gt_mask.shape)
        baseline_metrics = compute_pixel_metrics(baseline_score, gt_mask)
        ours_pos_metrics = compute_pixel_metrics(ours_score, gt_mask)

        panels = [gt_overlay, base_overlay, ours_pos_overlay]
        for col_idx, panel in enumerate(panels):
            axes[row_idx, col_idx].imshow(panel)
            axes[row_idx, col_idx].axis("off")

        label = f"{rec['item']['cls_name']} | {Path(rec['item']['img_path']).name}"
        axes[row_idx, 0].set_ylabel(label, fontsize=16, fontweight="bold")

        axm = axes[row_idx, 3]
        axm.axis("off")
        top = axm.inset_axes([0.08, 0.56, 0.84, 0.34])
        bot = axm.inset_axes([0.08, 0.12, 0.84, 0.34])
        bins = 24
        mask_bool = gt_mask > 0.5
        base_pos = baseline_score[mask_bool].reshape(-1)
        base_neg = baseline_score[~mask_bool].reshape(-1)
        ours_pos_vals = ours_score[mask_bool].reshape(-1)
        ours_neg_vals = ours_score[~mask_bool].reshape(-1)

        for axh, pos_vals, neg_vals, title, method_color in [
            (top, base_pos, base_neg, "Baseline", "#5c5c5c"),
            (bot, ours_pos_vals, ours_neg_vals, "Ours (D-S)", "#b8322f"),
        ]:
            lo = float(min(pos_vals.min(initial=0.0), neg_vals.min(initial=0.0)))
            hi = float(max(pos_vals.max(initial=1.0), neg_vals.max(initial=1.0)))
            if hi <= lo:
                hi = lo + 1e-6
            axh.hist(
                neg_vals,
                bins=bins,
                range=(lo, hi),
                density=True,
                color="#4b74b2",
                alpha=0.45,
                edgecolor="none",
                label="GT-",
            )
            axh.hist(
                pos_vals,
                bins=bins,
                range=(lo, hi),
                density=True,
                color=method_color,
                alpha=0.55,
                edgecolor="none",
                label="GT+",
            )
            axh.set_title(title, fontsize=11, fontweight="bold", pad=2)
            axh.tick_params(axis="both", labelsize=9)
            axh.grid(axis="y", linestyle="--", alpha=0.2)
            for spine in ["top", "right"]:
                axh.spines[spine].set_visible(False)
        top.set_xticklabels([])
        bot.set_xlabel("score", fontsize=10, fontweight="bold")
        top.set_ylabel("dens.", fontsize=9)
        bot.set_ylabel("dens.", fontsize=9)
        if row_idx == 0:
            top.legend(loc="upper right", fontsize=9, frameon=False)

        summary_rows.append(
            {
                "role": rec["role"],
                "img_path": rec["item"]["img_path"],
                "baseline_img_score": rec["baseline_img_score"],
                "ours_img_score": rec["ours_img_score"],
                "mask_area": rec["mask_area"],
                "baseline_pixel_metrics": baseline_metrics,
                "ours_defect_support_pixel_metrics": ours_pos_metrics,
            }
        )

    png_path = out_dir / "rawclip_capsules_qualitative.png"
    pdf_path = out_dir / "rawclip_capsules_qualitative.pdf"
    json_path = out_dir / "rawclip_capsules_qualitative.json"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    json_path.write_text(json.dumps({"selected": summary_rows}, indent=2))
    print(json.dumps({"png": str(png_path), "pdf": str(pdf_path), "json": str(json_path), "selected": summary_rows}, indent=2))


if __name__ == "__main__":
    main()
