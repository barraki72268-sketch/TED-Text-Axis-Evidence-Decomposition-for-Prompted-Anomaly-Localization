#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "neurips2026" / "results" / "faprompt_ted_story_vitl336_visa2mvtec_metal_nut_alpha15"
FIG = ROOT / "figure"

RED = "#d84a2f"
BLUE = "#2a78a6"
BLACK = "#111111"


def auc_from_scores(pos: np.ndarray, neg: np.ndarray) -> float:
    scores = np.concatenate([pos, neg])
    labels = np.concatenate([np.ones(pos.size, dtype=np.int64), np.zeros(neg.size, dtype=np.int64)])
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, scores.size + 1, dtype=np.float64)
    pos_ranks = ranks[labels == 1]
    return float((pos_ranks.sum() - pos.size * (pos.size + 1) / 2.0) / (pos.size * neg.size))


def overlap_coeff(pos: np.ndarray, neg: np.ndarray, bins: np.ndarray) -> float:
    hp, _ = np.histogram(pos, bins=bins, density=True)
    hn, _ = np.histogram(neg, bins=bins, density=True)
    widths = np.diff(bins)
    return float(np.sum(np.minimum(hp, hn) * widths))


def setup_rc() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.weight": "bold",
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def style_axis(ax: plt.Axes) -> None:
    ax.tick_params(axis="both", labelsize=19, width=1.8, length=6)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("bold")
    ax.grid(alpha=0.18, linewidth=1.0)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    for spine in ["left", "bottom"]:
        ax.spines[spine].set_linewidth(1.8)


def density_panel(ax: plt.Axes, defect: np.ndarray, hard: np.ndarray, xlabel: str, box_text: str) -> None:
    lo = float(min(np.quantile(defect, 0.005), np.quantile(hard, 0.005)))
    hi = float(max(np.quantile(defect, 0.995), np.quantile(hard, 0.995)))
    bins = np.linspace(lo, hi, 58)
    ax.hist(hard, bins=bins, density=True, histtype="stepfilled", alpha=0.20, color=BLUE)
    ax.hist(defect, bins=bins, density=True, histtype="stepfilled", alpha=0.18, color=RED)
    ax.hist(hard, bins=bins, density=True, histtype="step", linewidth=3.0, color=BLUE, label="hard normal")
    ax.hist(defect, bins=bins, density=True, histtype="step", linewidth=3.0, linestyle="--", color=RED, label="defect")
    ax.axvline(np.median(hard), color=BLUE, linewidth=2.8, alpha=0.95)
    ax.axvline(np.median(defect), color=RED, linewidth=2.8, linestyle="--", alpha=0.95)
    ax.set_xlabel(xlabel, fontsize=22, labelpad=8)
    ax.set_ylabel("Density", fontsize=22, labelpad=8)
    ax.text(
        0.04,
        0.93,
        box_text,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=18,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#dddddd", "alpha": 0.92, "pad": 4.0},
    )
    style_axis(ax)


def save_histogram(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    defect_b = data["baseline"][labels == 1]
    hard_b = data["baseline"][labels == 0]
    defect_t = data["train_free"][labels == 1]
    hard_t = data["train_free"][labels == 0]

    b_bins = np.linspace(
        min(np.quantile(defect_b, 0.005), np.quantile(hard_b, 0.005)),
        max(np.quantile(defect_b, 0.995), np.quantile(hard_b, 0.995)),
        58,
    )
    t_bins = np.linspace(
        min(np.quantile(defect_t, 0.005), np.quantile(hard_t, 0.005)),
        max(np.quantile(defect_t, 0.995), np.quantile(hard_t, 0.995)),
        58,
    )
    b_auc = float(meta["hist_stats"]["baseline"]["auc"])
    t_auc = float(meta["hist_stats"]["train_free"]["auc"])
    b_ov = float(meta["hist_stats"]["baseline"]["overlap"])
    t_ov = float(meta["hist_stats"]["train_free"]["overlap"])

    fig = plt.figure(figsize=(12.6, 3.85), constrained_layout=False)
    ax0 = fig.add_axes([0.105, 0.24, 0.385, 0.69])
    ax1 = fig.add_axes([0.585, 0.24, 0.385, 0.69])
    density_panel(ax0, defect_b, hard_b, "host top-k patch score", f"AUC {b_auc:.3f}\nOverlap {b_ov:.3f}")
    density_panel(ax1, defect_t, hard_t, "decomposition score", f"AUC {t_auc:.3f}\nOverlap {t_ov:.3f}")
    ax1.set_ylabel("")
    ax1.legend(frameon=False, fontsize=18, loc="upper right", handlelength=2.2)
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_histogram_bigfont.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_histogram_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_scatter(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    xy = data["xy"]
    xy_after = data["xy_after"]
    selected = meta["selected"]
    d_xy = np.asarray(selected["defect"]["xy"], dtype=np.float32)
    h_xy = np.asarray(selected["hard_normal"]["xy"], dtype=np.float32)
    d_after = np.asarray(selected["defect"]["xy_after"], dtype=np.float32)
    h_after = np.asarray(selected["hard_normal"]["xy_after"], dtype=np.float32)
    rank = meta["figures"]["story"]["rank_lift"]

    fig = plt.figure(figsize=(12.4, 3.95), constrained_layout=False)
    ax0 = fig.add_axes([0.105, 0.22, 0.385, 0.69])
    ax1 = fig.add_axes([0.585, 0.22, 0.385, 0.69])

    def draw(ax: plt.Axes, arr: np.ndarray, p_def: np.ndarray, p_hard: np.ndarray, box_text: str) -> None:
        hard = labels == 0
        defect = labels == 1
        ax.scatter(arr[hard, 0], arr[hard, 1], s=46, alpha=0.55, color=BLUE, edgecolors="none")
        ax.scatter(arr[defect, 0], arr[defect, 1], s=58, alpha=0.60, marker="^", color=RED, edgecolors="none")
        ax.scatter([p_hard[0]], [p_hard[1]], s=210, color=BLUE, edgecolor=BLACK, linewidth=2.0, zorder=5)
        ax.scatter([p_def[0]], [p_def[1]], s=230, marker="^", color=RED, edgecolor=BLACK, linewidth=2.0, zorder=5)
        ax.plot([p_hard[0], p_def[0]], [p_hard[1], p_def[1]], color="#555555", linewidth=3.0, zorder=4)
        ax.axhline(0.0, color="#777777", linewidth=1.2, alpha=0.45)
        ax.axvline(0.0, color="#777777", linewidth=1.2, alpha=0.25)
        ax.text(
            0.04,
            0.94,
            box_text,
            transform=ax.transAxes,
            ha="left",
            va="top",
            fontsize=18,
            fontweight="bold",
            bbox={"facecolor": "white", "edgecolor": "#dddddd", "alpha": 0.92, "pad": 4.0},
        )
        ax.set_xlabel("text-axis coordinate", fontsize=21, labelpad=8)
        style_axis(ax)

    draw(ax0, xy, d_xy, h_xy, f"Rank-1 AUC {rank['axis_auc']:.3f}")
    draw(ax1, xy_after, d_after, h_after, f"Rank-r AUC {rank['residual_auc']:.3f}")
    ax0.set_ylabel("subspace residual", fontsize=21, labelpad=8)
    ax1.set_ylabel("")
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_scatter_bigfont.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_scatter_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def add_image_axis(fig: plt.Figure, rect: list[float], path: Path, edge: str) -> plt.Axes:
    ax = fig.add_axes(rect)
    ax.imshow(Image.open(path).convert("RGB"))
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(5.0)
        spine.set_color(edge)
    return ax


def save_trace_pair(meta: dict) -> None:
    selected = meta["selected"]
    defect_full = ROOT / selected["defect"]["full_box_path"]
    defect_crop = ROOT / selected["defect"]["crop_path"]
    hard_full = ROOT / selected["hard_normal"]["full_box_path"]
    hard_crop = ROOT / selected["hard_normal"]["crop_path"]
    pair = meta["pair_info"]

    fig = plt.figure(figsize=(7.9, 4.55), constrained_layout=False)
    fig.text(0.045, 0.735, "defect", color=RED, fontsize=24, fontweight="bold", ha="left", va="center")
    fig.text(0.045, 0.325, "hard normal", color=BLUE, fontsize=24, fontweight="bold", ha="left", va="center")
    add_image_axis(fig, [0.355, 0.55, 0.245, 0.36], defect_full, RED)
    add_image_axis(fig, [0.665, 0.55, 0.245, 0.36], defect_crop, RED)
    add_image_axis(fig, [0.355, 0.14, 0.245, 0.36], hard_full, BLUE)
    add_image_axis(fig, [0.665, 0.14, 0.245, 0.36], hard_crop, BLUE)
    fig.text(
        0.555,
        0.045,
        f"B gap {pair['baseline_gap']:+.4f}  |  C-TED gap {pair['calibrated_final_gap']:+.4f}",
        fontsize=16,
        fontweight="bold",
        ha="center",
        va="bottom",
    )
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_traced_patch_pair_bigfont.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_traced_patch_pair_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def main() -> int:
    setup_rc()
    FIG.mkdir(parents=True, exist_ok=True)
    data = np.load(SRC / "scores_with_trace_vitl336.npz", allow_pickle=True)
    meta = json.loads((SRC / "selected_pair.json").read_text(encoding="utf-8"))
    save_histogram(data, meta)
    save_scatter(data, meta)
    save_trace_pair(meta)
    print(FIG / "results_mainfig_histogram_bigfont.pdf")
    print(FIG / "results_mainfig_scatter_bigfont.pdf")
    print(FIG / "results_mainfig_traced_patch_pair_bigfont.pdf")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
