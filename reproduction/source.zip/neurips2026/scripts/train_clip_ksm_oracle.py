from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Single-layer KSM oracle fit on frozen CLIP.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--class_specs",
        nargs="+",
        default=["fryum:6:9", "capsules:9:6"],
        help="Entries: class_name:train_layer:transfer_layer",
    )
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240", "ViT-L-14:laion400m_e32:224"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--target_layer", type=int, default=12)
    parser.add_argument("--gate_modes", nargs="+", default=["scalar", "channelwise"])
    parser.add_argument("--gamma_cap", type=float, default=0.2)
    parser.add_argument("--epochs", type=int, default=4)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=20)
    parser.add_argument("--train_anomaly_images", type=int, default=20)
    parser.add_argument("--eval_normal_images", type=int, default=20)
    parser.add_argument("--eval_anomaly_images", type=int, default=20)
    parser.add_argument("--max_anomaly_patches", type=int, default=4096)
    parser.add_argument("--subspace_k", type=int, default=4)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--lambda_preserve", type=float, default=0.5)
    parser.add_argument("--lambda_gate", type=float, default=1e-4)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_ksm_oracle")
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def build_recent_general_prompt_bank(class_name: str) -> tuple[str, list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt = (
        f"a close-up inspection photo of a {cls} that is intact, complete, clean, "
        f"and free of visible damage, defects, cracks, missing parts, contamination, "
        f"deformation, discoloration, or abnormal surface patterns."
    )
    abnormal_prompts = [
        (
            f"a close-up inspection photo of a {cls} showing visible damage, cracks, holes, "
            f"broken regions, missing material, or structural defects."
        ),
        (
            f"a close-up inspection photo of a {cls} with scratches, dents, tears, surface flaws, "
            f"contamination, stains, discoloration, or abnormal marks."
        ),
        (
            f"a close-up inspection photo of a {cls} whose shape, texture, edge, or surface pattern "
            f"looks irregular, deformed, incomplete, or visibly defective."
        ),
        (
            f"a detailed inspection photo of a {cls} with missing parts, broken edges, foreign material, "
            f"local damage, or manufacturing defects."
        ),
        (
            f"a detailed inspection photo of a {cls} that appears damaged, defective, incomplete, "
            f"deformed, contaminated, or inconsistent with a normal intact item."
        ),
        (
            f"a close-up inspection photo of a {cls} with visible surface damage, structural breakage, "
            f"missing components, contamination, or abnormal appearance."
        ),
    ]
    return normal_prompt, abnormal_prompts


def encode_text_features(backbone, prompts: list[str]) -> torch.Tensor:
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = l2_normalize(text_features, dim=-1)
    proj = getattr(backbone.visual, "proj", None)
    if proj is not None:
        text_features = (proj.detach().float().to(text_features.device) @ text_features.T).T
        text_features = l2_normalize(text_features, dim=-1)
    return text_features


def build_text_workspace(backbone, abnormal_prompts: list[str], p_norm: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    p_anom_raw = encode_text_features(backbone, abnormal_prompts)
    delta_p = p_anom_raw - p_norm.unsqueeze(0)
    delta_p_center = delta_p - delta_p.mean(dim=0, keepdim=True)
    U_t, _, _ = torch.linalg.svd(delta_p_center.T, full_matrices=False)
    U_text = U_t[:, : delta_p.shape[0]]
    return delta_p, U_text


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = l2_normalize(p_norm, dim=0)
    return v.float() - (v.float() @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)


def reconstruct_optimal_text_axis(U_text: torch.Tensor, V_anom: torch.Tensor) -> tuple[torch.Tensor, float]:
    M = U_text.T @ V_anom
    X, S, _ = torch.linalg.svd(M, full_matrices=False)
    x1 = X[:, 0]
    delta_p_recon = U_text @ x1
    delta_p_recon = l2_normalize(delta_p_recon, dim=0)
    return delta_p_recon, float(S[0].item())


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int]) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .numpy()
        .astype(np.int64)
    )


@dataclass
class Record:
    image_t: torch.Tensor
    patch_mask: np.ndarray
    label: int
    name: str


def collect_oracle_records(backbone, class_name: str, args: argparse.Namespace) -> tuple[list[Record], list[Record]]:
    train_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "train")
    test_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")

    train_norm_idx = list(range(min(args.train_normal_images, len(train_ds.records))))
    test_norm_idx = [i for i, rec in enumerate(test_ds.records) if rec["label"] == "normal"][: args.eval_normal_images]
    test_anom_all = [i for i, rec in enumerate(test_ds.records) if rec["label"] != "normal"]
    train_anom_idx = test_anom_all[: args.train_anomaly_images]
    eval_anom_idx = test_anom_all[args.train_anomaly_images : args.train_anomaly_images + args.eval_anomaly_images]

    def make_record(ds, idx: int) -> Record:
        image_np, mask_np, label, name, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).cpu()
        return Record(
            image_t=image_t,
            patch_mask=to_patch_mask(mask_np, backbone.grid_size),
            label=int(label != 0),
            name=name,
        )

    train_records = [make_record(train_ds, i) for i in train_norm_idx] + [make_record(test_ds, i) for i in train_anom_idx]
    eval_records = [make_record(test_ds, i) for i in test_norm_idx] + [make_record(test_ds, i) for i in eval_anom_idx]
    return train_records, eval_records


def maybe_subsample(tokens: torch.Tensor, max_count: int) -> torch.Tensor:
    if max_count <= 0 or tokens.shape[0] <= max_count:
        return tokens
    idx = torch.linspace(0, tokens.shape[0] - 1, steps=max_count, device=tokens.device).round().long()
    return tokens[idx]


def extract_anomaly_subspace(backbone, records: list[Record], p_norm: torch.Tensor, target_layer: int, max_patches: int, k: int, device: str) -> torch.Tensor:
    chunks: list[torch.Tensor] = []
    for rec in records:
        if rec.label != 1:
            continue
        image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens = backbone.extract_layer_patch_tokens(image_t, target_layers=[target_layer])[target_layer][0]
        pos = torch.from_numpy(rec.patch_mask > 0).to(tokens.device)
        if int(pos.sum().item()) == 0:
            continue
        chunks.append(tokens[pos].detach())
    if not chunks:
        raise RuntimeError("No anomaly patches for subspace extraction.")
    patches = maybe_subsample(torch.cat(chunks, dim=0), max_patches)
    residual = get_null_space_residual(l2_normalize(patches, dim=-1), p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    k_eff = min(k, int(vh.shape[0]))
    return vh[:k_eff].T.contiguous()


def compute_block_attention_distribution(block, seq: torch.Tensor) -> torch.Tensor:
    x = block.ln_1(seq)
    L, N, C = x.shape
    mha = block.attn
    qkv = F.linear(x, mha.in_proj_weight, mha.in_proj_bias)
    q, k, _ = qkv.chunk(3, dim=-1)
    head_dim = C // mha.num_heads
    q = q.view(L, N, mha.num_heads, head_dim).permute(1, 2, 0, 3)
    k = k.view(L, N, mha.num_heads, head_dim).permute(1, 2, 0, 3)
    attn = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(head_dim)
    attn = attn.softmax(dim=-1)
    cls_to_patch = attn[:, :, 0, 1:].mean(dim=1)
    cls_to_patch = cls_to_patch / cls_to_patch.sum(dim=-1, keepdim=True).clamp_min(1e-8)
    return cls_to_patch


def kl_divergence(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    return (p * (p.log() - q.log())).sum(dim=-1)


def topk_overlap(p: torch.Tensor, q: torch.Tensor, k: int = 10) -> torch.Tensor:
    k = min(k, p.shape[-1])
    p_top = torch.topk(p, k=k, dim=-1).indices
    q_top = torch.topk(q, k=k, dim=-1).indices
    out = []
    for i in range(p.shape[0]):
        a = set(p_top[i].tolist())
        b = set(q_top[i].tolist())
        out.append(len(a & b) / float(k))
    return torch.tensor(out, dtype=torch.float32)


class SingleLayerKSM(nn.Module):
    def __init__(self, dim: int, text_bank: torch.Tensor, p_norm: torch.Tensor, gate_mode: str = "scalar", gamma_cap: float = 0.2):
        super().__init__()
        if gate_mode not in {"scalar", "channelwise"}:
            raise ValueError(f"Unsupported gate mode: {gate_mode}")
        self.dim = int(dim)
        self.gate_mode = gate_mode
        self.gamma_cap = float(gamma_cap)
        self.q_proj = nn.Linear(2 * self.dim, self.dim, bias=True)
        nn.init.xavier_uniform_(self.q_proj.weight, gain=0.5)
        nn.init.zeros_(self.q_proj.bias)
        self.register_buffer("p_norm", l2_normalize(p_norm.detach().float(), dim=0))
        text_bank = l2_normalize(text_bank.detach().float(), dim=-1)
        text_bank_null = get_null_space_residual(text_bank, self.p_norm)
        text_bank_null = l2_normalize(text_bank_null, dim=-1)
        self.register_buffer("text_key", text_bank)
        self.register_buffer("text_value", text_bank_null)
        if gate_mode == "scalar":
            self.gate_raw = nn.Parameter(torch.zeros(1, dtype=torch.float32))
        else:
            self.gate_raw = nn.Parameter(torch.zeros(self.dim, dtype=torch.float32))

    def effective_gate(self) -> torch.Tensor:
        return self.gamma_cap * torch.tanh(self.gate_raw)

    def forward(self, patches: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        dtype = patches.dtype
        patches_f = patches.float()
        global_mean = patches_f.mean(dim=1, keepdim=True).expand(-1, patches_f.shape[1], -1)
        q = self.q_proj(torch.cat([patches_f, global_mean], dim=-1))
        logits = torch.matmul(q, self.text_key.T) / math.sqrt(self.dim)
        attn = logits.softmax(dim=-1)
        delta_raw = attn @ self.text_value
        gate = self.effective_gate()
        if self.gate_mode == "scalar":
            delta_gate = delta_raw * gate.view(1, 1, 1)
        else:
            delta_gate = delta_raw * gate.view(1, 1, -1)
        delta_final = get_null_space_residual(delta_gate.view(-1, self.dim), self.p_norm).view_as(delta_gate)
        out = patches_f + delta_final
        return out.to(dtype=dtype), attn


def final_patch_tokens(backbone, sequence: torch.Tensor) -> torch.Tensor:
    final = sequence.permute(1, 0, 2)
    final = backbone.visual.ln_post(final)[:, 1:, :].float()
    return final


def forward_with_optional_ksm(backbone, image_t: torch.Tensor, inject_layer: int | None, ksm: SingleLayerKSM | None, return_attn: bool = False) -> tuple[torch.Tensor, torch.Tensor | None]:
    sequence = backbone.prepare_sequence(image_t)
    downstream_layer = None if inject_layer is None else inject_layer + 1
    attn_out = None

    def callback(block_idx: int, x: torch.Tensor) -> torch.Tensor:
        nonlocal attn_out
        if inject_layer is not None and block_idx == inject_layer and ksm is not None:
            xb = x.permute(1, 0, 2)
            cls = xb[:, :1, :]
            patches = xb[:, 1:, :]
            patches_out, _ = ksm(patches)
            xb = torch.cat([cls, patches_out.to(cls.dtype)], dim=1)
            x = xb.permute(1, 0, 2)
        if return_attn and downstream_layer is not None and block_idx == downstream_layer:
            block = backbone.visual.transformer.resblocks[block_idx - 1]
            attn_out = compute_block_attention_distribution(block, x).detach()
        return x

    out = backbone.run_blocks(sequence, start_layer=1, end_layer=backbone.num_layers, layer_callback=callback)
    return final_patch_tokens(backbone, out)[0], attn_out[0] if attn_out is not None else None


def anomaly_alignment_loss(v_final: torch.Tensor, patch_mask: np.ndarray, p_norm: torch.Tensor, delta_p_recon: torch.Tensor) -> torch.Tensor:
    pos = torch.from_numpy(patch_mask > 0).to(v_final.device)
    if int(pos.sum().item()) == 0:
        return torch.zeros([], device=v_final.device)
    residual = get_null_space_residual(l2_normalize(v_final, dim=-1), p_norm)
    delta = delta_p_recon.view(1, -1).expand(int(pos.sum().item()), -1)
    cos = F.cosine_similarity(residual[pos], delta, dim=-1)
    return 1.0 - cos.mean()


def preservation_loss(v_final: torch.Tensor, base_final: torch.Tensor, patch_mask: np.ndarray | None = None) -> torch.Tensor:
    v_ref = l2_normalize(base_final, dim=-1)
    v_cur = l2_normalize(v_final, dim=-1)
    if patch_mask is None:
        return 1.0 - F.cosine_similarity(v_cur, v_ref, dim=-1).mean()
    neg = torch.from_numpy(patch_mask <= 0).to(v_final.device)
    if int(neg.sum().item()) == 0:
        return torch.zeros([], device=v_final.device)
    return 1.0 - F.cosine_similarity(v_cur[neg], v_ref[neg], dim=-1).mean()


def train_one_epoch(backbone, ksm: SingleLayerKSM, inject_layer: int, train_records: list[Record], p_norm: torch.Tensor, delta_p_recon: torch.Tensor, args: argparse.Namespace, optimizer: torch.optim.Optimizer, device: str) -> dict[str, float]:
    ksm.train()
    losses = []
    loss_anom_vals = []
    loss_pres_vals = []
    for rec in train_records:
        image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            base_final, _ = forward_with_optional_ksm(backbone, image_t, inject_layer=None, ksm=None, return_attn=False)
        out_final, _ = forward_with_optional_ksm(backbone, image_t, inject_layer=inject_layer, ksm=ksm, return_attn=False)

        if rec.label == 1:
            loss_anom = anomaly_alignment_loss(out_final, rec.patch_mask, p_norm, delta_p_recon)
            loss_pres = preservation_loss(out_final, base_final, rec.patch_mask)
        else:
            loss_anom = torch.zeros([], device=device)
            loss_pres = preservation_loss(out_final, base_final, None)

        gate_pen = ksm.effective_gate().pow(2).mean()
        loss = loss_anom + args.lambda_preserve * loss_pres + args.lambda_gate * gate_pen

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

        losses.append(float(loss.item()))
        loss_anom_vals.append(float(loss_anom.item()))
        loss_pres_vals.append(float(loss_pres.item()))

    return {
        "train_loss": float(np.mean(losses)) if losses else float("nan"),
        "train_loss_anom": float(np.mean(loss_anom_vals)) if loss_anom_vals else float("nan"),
        "train_loss_pres": float(np.mean(loss_pres_vals)) if loss_pres_vals else float("nan"),
    }


def evaluate_module(backbone, ksm: SingleLayerKSM, eval_layer: int, eval_records: list[Record], p_norm: torch.Tensor, delta_p_recon: torch.Tensor, topk_ratio: float, device: str) -> dict[str, float]:
    ksm.eval()
    patch_labels: list[int] = []
    base_patch_scores: list[float] = []
    ksm_patch_scores: list[float] = []
    image_labels: list[int] = []
    base_image_scores: list[float] = []
    ksm_image_scores: list[float] = []
    sem_drop_vals: list[float] = []
    align_base_vals: list[float] = []
    align_ksm_vals: list[float] = []
    kl_vals: list[float] = []
    overlap_vals: list[float] = []

    with torch.no_grad():
        for rec in eval_records:
            image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            base_final, attn_base = forward_with_optional_ksm(backbone, image_t, inject_layer=None, ksm=None, return_attn=eval_layer < backbone.num_layers)
            out_final, attn_ksm = forward_with_optional_ksm(backbone, image_t, inject_layer=eval_layer, ksm=ksm, return_attn=eval_layer < backbone.num_layers)

            base_res = get_null_space_residual(l2_normalize(base_final, dim=-1), p_norm)
            out_res = get_null_space_residual(l2_normalize(out_final, dim=-1), p_norm)
            base_scores = (base_res @ delta_p_recon).cpu().numpy()
            out_scores = (out_res @ delta_p_recon).cpu().numpy()
            patch_labels.extend(rec.patch_mask.astype(np.int64).tolist())
            base_patch_scores.extend(base_scores.tolist())
            ksm_patch_scores.extend(out_scores.tolist())
            image_labels.append(rec.label)
            base_image_scores.append(topk_mean(base_scores, topk_ratio))
            ksm_image_scores.append(topk_mean(out_scores, topk_ratio))
            sem_drop_vals.append(float((l2_normalize(out_final, dim=-1) @ p_norm).mean().item() - (l2_normalize(base_final, dim=-1) @ p_norm).mean().item()))
            align_base_vals.append(float(F.cosine_similarity(base_res, delta_p_recon.view(1, -1), dim=-1).mean().item()))
            align_ksm_vals.append(float(F.cosine_similarity(out_res, delta_p_recon.view(1, -1), dim=-1).mean().item()))

            if attn_base is not None and attn_ksm is not None:
                kl_vals.append(float(kl_divergence(attn_base.unsqueeze(0), attn_ksm.unsqueeze(0)).mean().item()))
                overlap_vals.append(float(topk_overlap(attn_base.unsqueeze(0), attn_ksm.unsqueeze(0), k=10).mean().item()))

    return {
        "base_patch_auc": safe_auc(patch_labels, base_patch_scores),
        "ksm_patch_auc": safe_auc(patch_labels, ksm_patch_scores),
        "patch_auc_delta": safe_auc(patch_labels, ksm_patch_scores) - safe_auc(patch_labels, base_patch_scores),
        "base_image_auc": safe_auc(image_labels, base_image_scores),
        "ksm_image_auc": safe_auc(image_labels, ksm_image_scores),
        "image_auc_delta": safe_auc(image_labels, ksm_image_scores) - safe_auc(image_labels, base_image_scores),
        "semantic_drop_mean": float(np.mean(sem_drop_vals)) if sem_drop_vals else float("nan"),
        "align_delta_mean": (float(np.mean(align_ksm_vals)) - float(np.mean(align_base_vals))) if align_base_vals else float("nan"),
        "attn_kl_mean": float(np.mean(kl_vals)) if kl_vals else float("nan"),
        "attn_top10_overlap_mean": float(np.mean(overlap_vals)) if overlap_vals else float("nan"),
        "gate_abs_mean": float(ksm.effective_gate().abs().mean().item()),
        "gate_l2": float(ksm.effective_gate().pow(2).sum().sqrt().item()),
    }


def build_ksm(text_bank: torch.Tensor, p_norm: torch.Tensor, gate_mode: str, gamma_cap: float, device: str) -> SingleLayerKSM:
    ksm = SingleLayerKSM(text_bank.shape[1], text_bank, p_norm, gate_mode=gate_mode, gamma_cap=gamma_cap)
    return ksm.to(device)


def parse_class_spec(spec: str) -> tuple[str, int, int]:
    class_name, train_layer, transfer_layer = spec.split(":")
    return class_name, int(train_layer), int(transfer_layer)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, float | str]] = []
    details: list[dict] = []
    skipped: list[dict[str, str]] = []

    class_specs = [parse_class_spec(spec) for spec in args.class_specs]

    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        backbone.eval()
        for param in backbone.parameters():
            param.requires_grad_(False)

        for class_name, train_layer, transfer_layer in class_specs:
            try:
                train_records, eval_records = collect_oracle_records(backbone, class_name, args)
                normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
                p_norm = encode_text_features(backbone, [normal_prompt])[0]
                delta_bank, U_text = build_text_workspace(backbone, abnormal_prompts, p_norm)
                V_anom = extract_anomaly_subspace(backbone, train_records, p_norm, args.target_layer, args.max_anomaly_patches, args.subspace_k, device)
                delta_p_recon, sigma1 = reconstruct_optimal_text_axis(U_text.to(V_anom.device), V_anom)
            except RuntimeError as exc:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": str(exc)})
                continue

            for gate_mode in args.gate_modes:
                ksm = build_ksm(delta_bank.to(device), p_norm.to(device), gate_mode, args.gamma_cap, device)
                optimizer = torch.optim.AdamW(ksm.parameters(), lr=args.lr)
                best_state = None
                best_metric = -float("inf")
                history: list[dict[str, float]] = []

                for epoch in range(1, args.epochs + 1):
                    train_stats = train_one_epoch(backbone, ksm, train_layer, train_records, p_norm.to(device), delta_p_recon.to(device), args, optimizer, device)
                    eval_same = evaluate_module(backbone, ksm, train_layer, eval_records, p_norm.to(device), delta_p_recon.to(device), args.topk_ratio, device)
                    metric = eval_same["ksm_image_auc"]
                    history.append({"epoch": epoch, **train_stats, **eval_same})
                    if metric > best_metric:
                        best_metric = metric
                        best_state = {k: v.detach().cpu() for k, v in ksm.state_dict().items()}

                if best_state is None:
                    skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": f"No best state for {gate_mode}"})
                    continue

                ksm.load_state_dict(best_state)
                same_eval = evaluate_module(backbone, ksm, train_layer, eval_records, p_norm.to(device), delta_p_recon.to(device), args.topk_ratio, device)
                transfer_eval = evaluate_module(backbone, ksm, transfer_layer, eval_records, p_norm.to(device), delta_p_recon.to(device), args.topk_ratio, device)

                row_same = {
                    "backbone": backbone_name,
                    "pretrained": pretrained_name,
                    "img_size": img_size_i,
                    "class_name": class_name,
                    "gate_mode": gate_mode,
                    "train_layer": train_layer,
                    "eval_layer": train_layer,
                    "transfer_eval": 0,
                    "sigma1": sigma1,
                    "subspace_k": int(V_anom.shape[1]),
                    "epochs": args.epochs,
                    **history[-1],
                    **same_eval,
                }
                row_transfer = {
                    "backbone": backbone_name,
                    "pretrained": pretrained_name,
                    "img_size": img_size_i,
                    "class_name": class_name,
                    "gate_mode": gate_mode,
                    "train_layer": train_layer,
                    "eval_layer": transfer_layer,
                    "transfer_eval": 1,
                    "sigma1": sigma1,
                    "subspace_k": int(V_anom.shape[1]),
                    "epochs": args.epochs,
                    **history[-1],
                    **transfer_eval,
                }
                rows.extend([row_same, row_transfer])
                details.append(
                    {
                        "backbone": backbone_name,
                        "pretrained": pretrained_name,
                        "img_size": img_size_i,
                        "class_name": class_name,
                        "gate_mode": gate_mode,
                        "train_layer": train_layer,
                        "transfer_layer": transfer_layer,
                        "history": history,
                    }
                )

    stem = f"{args.output_tag}_{'-'.join(s.split(':')[0] for s in args.class_specs)}_{'-'.join(spec.split(':')[0] for spec in args.backbones)}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()}) if rows else []
    with csv_path.open("w", newline="") as f:
        if fieldnames:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"rows": rows, "details": details, "skipped": skipped}, f, indent=2)
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
