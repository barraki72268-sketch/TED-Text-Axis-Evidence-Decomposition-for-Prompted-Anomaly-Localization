from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaptclip_vlrefine.py"
MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"
BANK_ROOT = ROOT / "neurips2026" / "results" / "bank_cache"
RESULTS_ROOT = ROOT / "neurips2026" / "results"


def base_cmd(
    source_root: Path,
    source_dataset: str,
    target_root: Path,
    target_dataset: str,
    ckpt: Path,
    save_dir: Path,
    bank_cache: Path,
    seed: int,
    device: str,
    pretrained_model: str,
    checkpoint_load_mode: str,
    features_list: list[int],
) -> list[str]:
    return [
        str(PYTHON),
        str(SCRIPT),
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(ckpt),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank_cache),
        "--pretrained_model",
        pretrained_model,
        "--checkpoint_load_mode",
        checkpoint_load_mode,
        "--features_list",
        *[str(x) for x in features_list],
        "--image_size",
        "518",
        "--batch_size",
        "8",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--corr_alpha",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--seed",
        str(seed),
        "--device",
        device,
        "--num_workers",
        "4",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
    ]


def cases(
    device: str,
    pretrained_model: str,
    result_prefix: str,
    bank_tag: str,
    checkpoint_load_mode: str,
    features_list: list[int],
) -> list[tuple[str, Path, list[str]]]:
    out = []
    for seed in (0, 1, 2):
        mvtec_bank = BANK_ROOT / f"adaptclip_ted_mvtec_vl_{bank_tag}_seed{seed}.pt"
        visa_bank = BANK_ROOT / f"adaptclip_ted_visa_vl_{bank_tag}_seed{seed}.pt"
        specs = [
            ("mvtec2visa", MVTEC_ROOT, "mvtec", VISA_ROOT, "visa", MVTEC_CKPT, mvtec_bank),
            ("mvtec2mpdd", MVTEC_ROOT, "mvtec", MPDD_ROOT, "mpdd", MVTEC_CKPT, mvtec_bank),
            ("mvtec2btad", MVTEC_ROOT, "mvtec", BTAD_ROOT, "btad", MVTEC_CKPT, mvtec_bank),
            ("visa2mvtec", VISA_ROOT, "visa", MVTEC_ROOT, "mvtec", VISA_CKPT, visa_bank),
        ]
        for tag, source_root, source_dataset, target_root, target_dataset, ckpt, bank in specs:
            save_dir = RESULTS_ROOT / f"{result_prefix}_{tag}_seed{seed}_20260428"
            out.append(
                (
                    f"{tag}_seed{seed}",
                    save_dir,
                    base_cmd(
                        source_root,
                        source_dataset,
                        target_root,
                        target_dataset,
                        ckpt,
                        save_dir,
                        bank,
                        seed,
                        device,
                        pretrained_model,
                        checkpoint_load_mode,
                        features_list,
                    ),
                )
            )
    return out


def main() -> None:
    parser = argparse.ArgumentParser("Direct Python AdaptCLIP TED queue; avoids bash CUDA visibility issues.")
    parser.add_argument("--device", default="cuda:1")
    parser.add_argument("--pretrained_model", default="ViT-L/14@336px")
    parser.add_argument("--checkpoint_load_mode", default="strict", choices=["strict", "compatible"])
    parser.add_argument("--features_list", type=int, nargs="+", default=[24])
    parser.add_argument("--result_prefix", default="adaptclip_ted_vlcalib")
    parser.add_argument("--bank_tag", default="lastlayer")
    parser.add_argument("--wait_summary", default="")
    parser.add_argument("--wait_timeout_sec", type=int, default=43200)
    args = parser.parse_args()

    if args.wait_summary:
        wait_path = Path(args.wait_summary)
        start = time.time()
        while not wait_path.exists():
            if time.time() - start > args.wait_timeout_sec:
                raise TimeoutError(f"Timed out waiting for {wait_path}")
            print(f"[wait] {wait_path}", flush=True)
            time.sleep(60)

    for tag, save_dir, cmd in cases(
        args.device,
        args.pretrained_model,
        args.result_prefix,
        args.bank_tag,
        args.checkpoint_load_mode,
        args.features_list,
    ):
        summary_path = save_dir / "summary.json"
        if summary_path.exists():
            print(f"[skip] {tag}: {summary_path}", flush=True)
            continue
        print(f"[run] {tag}: {save_dir}", flush=True)
        subprocess.run(cmd, cwd=str(ROOT), check=True)


if __name__ == "__main__":
    main()
