from __future__ import annotations

import argparse
import gc
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402
from common_failure_metrics import (  # noqa: E402
    BTAD_ROOT,
    MPDD_ROOT,
    MVTEC_ROOT,
    OFFICIAL_VISA_ROOT,
    build_rows_and_summary,
    current_rss_mb,
    init_per_class,
    reached_cap,
    save_outputs,
    update_per_class,
    validate_visa_root,
    write_progress,
)
from dataset import Dataset  # noqa: E402
from utils import get_transform  # noqa: E402


VISA_CKPT = ROOT / "neurips2026" / "FAPrompt" / "checkpoints" / "trained_on_visa" / "epoch_15.pth"
MVTEC_CKPT = ROOT / "neurips2026" / "FAPrompt" / "checkpoints" / "trained_on_mvtecad" / "epoch_15.pth"


def resolve_preset(args) -> None:
    if args.preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtecad"
    elif args.preset == "mvtec2visa":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif args.preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif args.preset == "mvtec2btad":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {args.preset}")


def cleanup(device: str) -> None:
    gc.collect()
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()


def main() -> None:
    parser = argparse.ArgumentParser("Collect common dense-failure metrics for FAPrompt")
    parser.add_argument("--preset", required=True, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=-1)
    parser.add_argument("--max_normal_images_per_class", type=int, default=-1)
    parser.add_argument("--progress_every", type=int, default=50)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "common_failure_faprompt"),
    )
    args = parser.parse_args()

    resolve_preset(args)
    validate_visa_root(args.target_root, "visa" if args.target_dataset == "visa" else args.target_dataset)
    save_dir = Path(args.save_dir)

    params = {
        "Prompt_length": args.n_ctx,
        "learnabel_text_embedding_depth": args.depth,
        "learnabel_text_embedding_length": args.t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=args.device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    prompt_learner = FAPrompt(model.to("cpu"), params)
    checkpoint = torch.load(args.checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(args.device).eval()
    model.to(args.device).eval()

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.target_root, transform=preprocess, target_transform=target_transform, dataset_name=args.target_dataset)
    per_class = init_per_class(list(dataset.obj_list))

    write_progress(
        save_dir,
        {
            "event": "start",
            "pid": os.getpid(),
            "preset": args.preset,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "rss_mb": round(current_rss_mb(), 2),
        },
    )

    with torch.inference_mode():
        for idx in range(len(dataset)):
            item = dataset[idx]
            cls_name = item["cls_name"]
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            is_anomaly = int(anomaly_flag) == 1
            stats = per_class[cls_name]
            if is_anomaly and reached_cap(int(stats["num_anomaly"]), args.max_anomaly_images_per_class):
                continue
            if (not is_anomaly) and reached_cap(int(stats["num_normal"]), args.max_normal_images_per_class):
                continue

            image = item["img"].unsqueeze(0).to(args.device)
            mask_tensor = item["img_mask"]
            gt_mask = (mask_tensor.squeeze().detach().cpu().numpy() > 0.5) if torch.is_tensor(mask_tensor) else (np.asarray(mask_tensor).squeeze() > 0.5)

            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True)
            patch_features = patch_features / patch_features.norm(dim=-1, keepdim=True)

            prompts_pos, prompts_neg, tokenized_pos, tokenized_neg, compound_prompts_text, _ = prompt_learner.forward()
            text_features_pos = model.encode_text_learn(prompts_pos, tokenized_pos, compound_prompts_text).float()
            text_features_neg = model.encode_text_learn(prompts_neg, tokenized_neg, compound_prompts_text).float()
            text_features_neg = torch.mean(text_features_neg, dim=0, keepdim=True)
            text_features = torch.cat([text_features_pos, text_features_neg])
            text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

            similarity, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_features[0])
            similarity_map1 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], args.image_size).squeeze(0)

            num = min(10, similarity[1:, :, 1].shape[0])
            pk_indx = torch.topk(similarity[1:, :, 1], k=num, dim=0, largest=True, sorted=True).indices
            pk_indx = pk_indx.permute(1, 0)
            selected_tokens = []
            for i in range(len(pk_indx)):
                selected_tokens_i = []
                for k in range(len(pk_indx[0])):
                    selected_tokens_i.append(patch_features[1:, :, :].permute(1, 0, 2)[i, k, :])
                selected_tokens.append(torch.stack(selected_tokens_i))
            selected_tokens = torch.stack(selected_tokens)

            text_features_list = []
            for i in range(selected_tokens.shape[0]):
                p_pos, p_neg, tok_pos, tok_neg, comp_text, _ = prompt_learner.forward(selected_tokens=selected_tokens[i])
                tf_pos = model.encode_text_learn(p_pos, tok_pos, comp_text).float()
                tf_neg = model.encode_text_learn(p_neg, tok_neg, comp_text).float()
                tf_neg = torch.mean(tf_neg, dim=0, keepdim=True)
                text_features_list.append(torch.cat([tf_pos, tf_neg]))
            text_features = torch.stack(text_features_list)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

            similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_features, text_features)
            similarity_map2 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], args.image_size).squeeze(0)
            anomaly_map = (similarity_map1[1, :] + 1 - similarity_map1[0, :] + similarity_map2[1, :] + 1 - similarity_map2[0, :]) / 4.0
            anomaly_map = gaussian_filter(anomaly_map.detach().cpu().numpy(), sigma=args.sigma)
            update_per_class(stats, anomaly_map, gt_mask, is_anomaly, args.topk_frac)

            if args.progress_every > 0 and (idx + 1) % args.progress_every == 0:
                print(
                    json.dumps(
                        {
                            "event": "progress",
                            "preset": args.preset,
                            "dataset_index": idx,
                            "rss_mb": round(current_rss_mb(), 2),
                        }
                    ),
                    flush=True,
                )
                write_progress(
                    save_dir,
                    {
                        "event": "progress",
                        "pid": os.getpid(),
                        "preset": args.preset,
                        "dataset_index": idx,
                        "rss_mb": round(current_rss_mb(), 2),
                    },
                )
            cleanup(args.device)

    rows, summary = build_rows_and_summary(per_class)
    settings = {
        "host": "FAPrompt",
        "preset": args.preset,
        "checkpoint_path": args.checkpoint_path,
        "target_root": args.target_root,
        "target_dataset": args.target_dataset,
        "image_size": args.image_size,
        "sigma": args.sigma,
        "features_list": args.features_list,
        "topk_frac": args.topk_frac,
        "max_anomaly_images_per_class": args.max_anomaly_images_per_class,
        "max_normal_images_per_class": args.max_normal_images_per_class,
    }
    save_outputs(save_dir, settings, summary, rows)
    print(json.dumps({"settings": settings, "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
