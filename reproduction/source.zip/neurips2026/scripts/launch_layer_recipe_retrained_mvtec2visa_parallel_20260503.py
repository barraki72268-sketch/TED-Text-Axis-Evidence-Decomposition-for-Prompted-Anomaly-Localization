#!/usr/bin/env python3
"""Launch MVTec->VisA layer-recipe retrain queues in host-level parallel.

This wrapper keeps the exact data/bank/evaluation settings from
queue_layer_recipe_retrained_mvtec2visa_20260503.py, but runs separate host
queues concurrently so the bidirectional layer-recipe table can be completed
without waiting for unrelated downstream queues.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
QUEUE = ROOT / "neurips2026/scripts/queue_layer_recipe_retrained_mvtec2visa_20260503.py"
OUT = ROOT / "neurips2026/results/layer_recipe_retrained_mvtec2visa_20260503"
LOG = OUT / "logs"


def parse_csv(raw: str) -> list[str]:
    return [x.strip() for x in raw.split(",") if x.strip()]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--hosts", default="adaclip,anomalyclip,faprompt")
    parser.add_argument("--recipes", default="all4,last,last2,mid2,earlylate")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)

    hosts = parse_csv(args.hosts)
    procs: dict[str, subprocess.Popen[object]] = {}
    logs: dict[str, Path] = {}

    for host in hosts:
        log_path = LOG / f"parallel_host_{host}.log"
        cmd = [
            str(PY),
            "-u",
            str(QUEUE),
            "--device_id",
            str(args.device_id),
            "--hosts",
            host,
            "--recipes",
            args.recipes,
            "--wait_pids",
            "",
        ]
        print({"stage": "launch_host", "host": host, "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
        f = log_path.open("w")
        proc = subprocess.Popen(cmd, cwd=str(ROOT), stdout=f, stderr=subprocess.STDOUT, text=True)
        procs[host] = proc
        logs[host] = log_path
        # Avoid simultaneous CLIP model initialization spikes.
        time.sleep(20)

    failed: list[tuple[str, int, Path]] = []
    for host, proc in procs.items():
        rc = proc.wait()
        print({"stage": "host_done", "host": host, "returncode": rc, "log": str(logs[host])}, flush=True)
        if rc != 0:
            failed.append((host, rc, logs[host]))

    if failed:
        for host, rc, log in failed:
            print({"stage": "host_failed", "host": host, "returncode": rc, "log": str(log)}, flush=True)
        return 1

    print({"stage": "done", "root": str(OUT), "hosts": hosts, "recipes": parse_csv(args.recipes)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
