from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["fryum", "capsules"])
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240", "ViT-L-14:laion400m_e32:224"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--target_layer", type=int, default=12)
    parser.add_argument("--inject_layers", nargs="+", type=int, default=[3, 6, 9, 12])
    parser.add_argument("--alphas", nargs="+", type=float, default=[0.01, 0.05, 0.1, 0.5, 1.0])
    parser.add_argument("--subspace_k", type=int, default=4)
    parser.add_argument("--fit_anomaly_images", type=int, default=5)
    parser.add_argument("--eval_anomaly_images", type=int, default=5)
    parser.add_argument("--eval_normal_images", type=int, default=5)
    parser.add_argument("--max_anomaly_patches", type=int, default=4096)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_steering_sensitivity")
    return parser.parse_args()


def build_recent_general_prompt_bank(class_name: str) -> tuple[str, list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt = (
        f"a close-up inspection photo of a {cls} that is intact, complete, clean, "
        f"and free of visible damage, defects, cracks, missing parts, contamination, "
        f"deformation, discoloration, or abnormal surface patterns."
    )
    abnormal_prompts = [
        (
            f"a close-up inspection photo of a {cls} showing visible damage, cracks, holes, "
            f"broken regions, missing material, or structural defects."
        ),
        (
            f"a close-up inspection photo of a {cls} with scratches, dents, tears, surface flaws, "
            f"contamination, stains, discoloration, or abnormal marks."
        ),
        (
            f"a close-up inspection photo of a {cls} whose shape, texture, edge, or surface pattern "
            f"looks irregular, deformed, incomplete, or visibly defective."
        ),
        (
            f"a detailed inspection photo of a {cls} with missing parts, broken edges, foreign material, "
            f"local damage, or manufacturing defects."
        ),
        (
            f"a detailed inspection photo of a {cls} that appears damaged, defective, incomplete, "
            f"deformed, contaminated, or inconsistent with a normal intact item."
        ),
        (
            f"a close-up inspection photo of a {cls} with visible surface damage, structural breakage, "
            f"missing components, contamination, or abnormal appearance."
        ),
    ]
    return normal_prompt, abnormal_prompts


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def encode_text_features(backbone, prompts: list[str]) -> torch.Tensor:
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = l2_normalize(text_features, dim=-1)
    proj = getattr(backbone.visual, "proj", None)
    if proj is not None:
        text_features = (proj.detach().float().to(text_features.device) @ text_features.T).T
        text_features = l2_normalize(text_features, dim=-1)
    return text_features


def build_text_workspace(backbone, abnormal_prompts: list[str], p_norm: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    p_anom_raw = encode_text_features(backbone, abnormal_prompts)
    delta_p = p_anom_raw - p_norm.unsqueeze(0)
    delta_p = delta_p - delta_p.mean(dim=0, keepdim=True)
    U_t, _, _ = torch.linalg.svd(delta_p.T, full_matrices=False)
    U_text = U_t[:, : delta_p.shape[0]]
    return delta_p, U_text


def reconstruct_optimal_text_axis(U_text: torch.Tensor, V_anom: torch.Tensor) -> tuple[torch.Tensor, float]:
    M = U_text.T @ V_anom
    X, S, _ = torch.linalg.svd(M, full_matrices=False)
    x1 = X[:, 0]
    delta_p_recon = U_text @ x1
    delta_p_recon = l2_normalize(delta_p_recon, dim=0)
    return delta_p_recon, float(S[0].item())


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = l2_normalize(p_norm, dim=0)
    return v.float() - (v @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def maybe_subsample(tokens: torch.Tensor, max_count: int) -> torch.Tensor:
    if max_count <= 0 or tokens.shape[0] <= max_count:
        return tokens
    idx = torch.linspace(0, tokens.shape[0] - 1, steps=max_count, device=tokens.device).round().long()
    return tokens[idx]


def extract_anomaly_subspace(backbone, records: list[dict], fit_indices: list[int], p_norm: torch.Tensor, target_layer: int, max_patches: int, k: int) -> torch.Tensor:
    chunks: list[torch.Tensor] = []
    for idx in fit_indices:
        rec = records[idx]
        image_t = rec["image_t"]
        with torch.no_grad():
            tokens = backbone.extract_layer_patch_tokens(image_t, target_layers=[target_layer])[target_layer][0]
        pos = torch.from_numpy(rec["patch_mask"] > 0).to(tokens.device)
        if int(pos.sum().item()) == 0:
            continue
        chunks.append(tokens[pos].detach())
    if not chunks:
        raise RuntimeError("No anomaly patches for subspace extraction.")
    patches = maybe_subsample(torch.cat(chunks, dim=0), max_patches)
    residual = get_null_space_residual(l2_normalize(patches, dim=-1), p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:k].T.contiguous()


def prepare_sequence(backbone, image_t: torch.Tensor) -> torch.Tensor:
    return backbone.prepare_sequence(image_t)


def compute_block_attention_distribution(block, seq: torch.Tensor) -> torch.Tensor:
    x = block.ln_1(seq)
    L, N, C = x.shape
    mha = block.attn
    qkv = F.linear(x, mha.in_proj_weight, mha.in_proj_bias)
    q, k, _ = qkv.chunk(3, dim=-1)
    head_dim = C // mha.num_heads
    q = q.view(L, N, mha.num_heads, head_dim).permute(1, 2, 0, 3)
    k = k.view(L, N, mha.num_heads, head_dim).permute(1, 2, 0, 3)
    attn = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(head_dim)
    attn = attn.softmax(dim=-1)  # [N, H, L, L]
    # CLS query -> spatial keys, averaged over heads.
    cls_to_patch = attn[:, :, 0, 1:].mean(dim=1)  # [N, P]
    cls_to_patch = cls_to_patch / cls_to_patch.sum(dim=-1, keepdim=True).clamp_min(1e-8)
    return cls_to_patch


def kl_divergence(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    return (p * (p.log() - q.log())).sum(dim=-1)


def topk_overlap(p: torch.Tensor, q: torch.Tensor, k: int = 10) -> torch.Tensor:
    k = min(k, p.shape[-1])
    p_top = torch.topk(p, k=k, dim=-1).indices
    q_top = torch.topk(q, k=k, dim=-1).indices
    out = []
    for i in range(p.shape[0]):
        a = set(p_top[i].tolist())
        b = set(q_top[i].tolist())
        out.append(len(a & b) / float(k))
    return torch.tensor(out, dtype=torch.float32)


def score_tokens(v_final: torch.Tensor, p_norm: torch.Tensor, delta_p: torch.Tensor) -> np.ndarray:
    residual = get_null_space_residual(l2_normalize(v_final, dim=-1), p_norm)
    return (residual @ delta_p).detach().cpu().numpy()


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def run_with_steering(backbone, image_t: torch.Tensor, inject_layer: int, steer_vec: torch.Tensor | None, alpha: float):
    sequence = prepare_sequence(backbone, image_t)
    attn_block = inject_layer + 1 if inject_layer < backbone.num_layers else None
    attn_orig = None
    attn_steer = None
    x_base = sequence.clone()
    x_steer = sequence.clone()

    for block_idx, block in enumerate(backbone.visual.transformer.resblocks, start=1):
        if block_idx == attn_block:
            attn_orig = compute_block_attention_distribution(block, x_base)
            attn_steer = compute_block_attention_distribution(block, x_steer)
        out_base = block(x_base, attn_mask=None)
        x_base = out_base[0] if isinstance(out_base, tuple) else out_base
        out_steer = block(x_steer, attn_mask=None)
        x_steer = out_steer[0] if isinstance(out_steer, tuple) else out_steer

        if block_idx == inject_layer and steer_vec is not None:
            xb = x_steer.permute(1, 0, 2)
            xb[:, 1:, :] = xb[:, 1:, :] + float(alpha) * steer_vec.view(1, 1, -1)
            x_steer = xb.permute(1, 0, 2)

    final_base = x_base.permute(1, 0, 2)
    final_steer = x_steer.permute(1, 0, 2)
    final_base = backbone.visual.ln_post(final_base)[:, 1:, :].float()
    final_steer = backbone.visual.ln_post(final_steer)[:, 1:, :].float()
    return final_base[0], final_steer[0], attn_orig, attn_steer


def collect_records(backbone, class_name: str, args: argparse.Namespace, device: str) -> tuple[list[dict], list[int], list[int]]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    normal_idx = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"]
    anomaly_idx = [i for i, rec in enumerate(ds.records) if rec["label"] != "normal"]
    fit_anom = anomaly_idx[: args.fit_anomaly_images]
    eval_anom = anomaly_idx[args.fit_anomaly_images : args.fit_anomaly_images + args.eval_anomaly_images]
    eval_norm = normal_idx[: args.eval_normal_images]

    records: list[dict] = []
    for idx in sorted(set(fit_anom + eval_anom + eval_norm)):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        records.append(
            {
                "index": idx,
                "label": int(label != 0),
                "name": name,
                "img_type": img_type,
                "image_t": image_t,
                "patch_mask": to_patch_mask(mask_np, backbone.grid_size, device),
            }
        )
    idx_to_pos = {rec["index"]: i for i, rec in enumerate(records)}
    fit_pos = [idx_to_pos[i] for i in fit_anom if i in idx_to_pos]
    eval_pos = [idx_to_pos[i] for i in (eval_norm + eval_anom) if i in idx_to_pos]
    return records, fit_pos, eval_pos


def evaluate_setting(backbone, class_name: str, p_norm: torch.Tensor, delta_p_recon: torch.Tensor, inject_layer: int, alpha: float, records: list[dict], eval_pos: list[int], topk_ratio: float) -> dict[str, float]:
    patch_labels: list[int] = []
    base_patch_scores: list[float] = []
    steer_patch_scores: list[float] = []
    image_labels: list[int] = []
    base_image_scores: list[float] = []
    steer_image_scores: list[float] = []
    kl_vals: list[float] = []
    overlap_vals: list[float] = []
    base_align_vals: list[float] = []
    steer_align_vals: list[float] = []
    base_sem_vals: list[float] = []
    steer_sem_vals: list[float] = []

    steer_vec = get_null_space_residual(delta_p_recon.unsqueeze(0), p_norm).squeeze(0)
    steer_vec = l2_normalize(steer_vec, dim=0)

    for pos in eval_pos:
        rec = records[pos]
        v_base, v_steer, attn_orig, attn_steer = run_with_steering(backbone, rec["image_t"], inject_layer, steer_vec, alpha)
        base_scores = score_tokens(v_base, p_norm, delta_p_recon)
        steer_scores = score_tokens(v_steer, p_norm, delta_p_recon)
        labels_patch = rec["patch_mask"].astype(np.int64)

        patch_labels.extend(labels_patch.tolist())
        base_patch_scores.extend(base_scores.tolist())
        steer_patch_scores.extend(steer_scores.tolist())
        image_labels.append(rec["label"])
        base_image_scores.append(topk_mean(base_scores, topk_ratio))
        steer_image_scores.append(topk_mean(steer_scores, topk_ratio))

        if attn_orig is not None and attn_steer is not None:
            kl_vals.append(float(kl_divergence(attn_orig, attn_steer).mean().item()))
            overlap_vals.append(float(topk_overlap(attn_orig, attn_steer, k=10).mean().item()))
        else:
            kl_vals.append(float("nan"))
            overlap_vals.append(float("nan"))

        r_base = get_null_space_residual(l2_normalize(v_base, dim=-1), p_norm)
        r_steer = get_null_space_residual(l2_normalize(v_steer, dim=-1), p_norm)
        base_align_vals.append(float(F.cosine_similarity(r_base, delta_p_recon.unsqueeze(0), dim=-1).nanmean().item()))
        steer_align_vals.append(float(F.cosine_similarity(r_steer, delta_p_recon.unsqueeze(0), dim=-1).nanmean().item()))
        base_sem_vals.append(float((l2_normalize(v_base, dim=-1) @ p_norm).mean().item()))
        steer_sem_vals.append(float((l2_normalize(v_steer, dim=-1) @ p_norm).mean().item()))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    steer_patch_auc = safe_auc(patch_labels, steer_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    steer_image_auc = safe_auc(image_labels, steer_image_scores)

    return {
        "class_name": class_name,
        "inject_layer": inject_layer,
        "alpha": float(alpha),
        "base_patch_auc": base_patch_auc,
        "steer_patch_auc": steer_patch_auc,
        "patch_auc_delta": steer_patch_auc - base_patch_auc,
        "base_image_auc": base_image_auc,
        "steer_image_auc": steer_image_auc,
        "image_auc_delta": steer_image_auc - base_image_auc,
        "base_align_mean": float(np.nanmean(np.asarray(base_align_vals, dtype=np.float64))),
        "steer_align_mean": float(np.nanmean(np.asarray(steer_align_vals, dtype=np.float64))),
        "align_delta": float(np.nanmean(np.asarray(steer_align_vals, dtype=np.float64)) - np.nanmean(np.asarray(base_align_vals, dtype=np.float64))),
        "base_semantic_mean": float(np.nanmean(np.asarray(base_sem_vals, dtype=np.float64))),
        "steer_semantic_mean": float(np.nanmean(np.asarray(steer_sem_vals, dtype=np.float64))),
        "semantic_drop": float(np.nanmean(np.asarray(steer_sem_vals, dtype=np.float64)) - np.nanmean(np.asarray(base_sem_vals, dtype=np.float64))),
        "attn_kl_mean": float(np.nanmean(np.asarray(kl_vals, dtype=np.float64))),
        "attn_top10_overlap_mean": float(np.nanmean(np.asarray(overlap_vals, dtype=np.float64))),
    }


def plot_curves(rows: list[dict[str, float | str]], out_dir: Path, stem: str) -> None:
    classes = sorted({str(r["class_name"]) for r in rows})
    backbones = sorted({str(r["backbone"]) for r in rows})
    inject_layers = sorted({int(r["inject_layer"]) for r in rows})
    metric_specs = [
        ("image_auc_delta", "Image AUC Delta"),
        ("patch_auc_delta", "Patch AUC Delta"),
        ("align_delta", "Alignment Delta"),
        ("attn_kl_mean", "Attention KL"),
        ("attn_top10_overlap_mean", "Attention Top10 Overlap"),
        ("semantic_drop", "Semantic Drop"),
    ]
    for metric_key, title in metric_specs:
        for backbone in backbones:
            plt.figure(figsize=(7.0, 4.5))
            for class_name in classes:
                for layer in inject_layers:
                    subset = [
                        r for r in rows
                        if str(r["backbone"]) == backbone
                        and str(r["class_name"]) == class_name
                        and int(r["inject_layer"]) == layer
                    ]
                    subset = sorted(subset, key=lambda x: float(x["alpha"]))
                    xs = [float(r["alpha"]) for r in subset]
                    ys = [float(r[metric_key]) for r in subset]
                    plt.plot(xs, ys, marker="o", label=f"{class_name}-L{layer}")
            plt.xscale("log")
            plt.xlabel("lambda")
            plt.ylabel(title)
            plt.title(f"{title} | {backbone}")
            plt.grid(alpha=0.25)
            plt.legend(fontsize=8, ncol=2)
            plt.tight_layout()
            safe_name = backbone.replace("/", "_").replace(":", "_")
            plt.savefig(out_dir / f"{stem}_{safe_name}_{metric_key}.png", dpi=200)
            plt.close()


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    rows: list[dict[str, float | str]] = []
    skipped: list[dict[str, str]] = []

    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )

        for class_name in args.class_names:
            try:
                normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
                p_norm = encode_text_features(backbone, [normal_prompt])[0]
                records, fit_pos, eval_pos = collect_records(backbone, class_name, args, device)
                V_anom = extract_anomaly_subspace(backbone, records, fit_pos, p_norm, args.target_layer, args.max_anomaly_patches, args.subspace_k)
                _, U_text = build_text_workspace(backbone, abnormal_prompts, p_norm)
                delta_p_recon, sigma1 = reconstruct_optimal_text_axis(U_text, V_anom.to(U_text.device))
            except RuntimeError as exc:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": str(exc)})
                continue

            for inject_layer in args.inject_layers:
                for alpha in args.alphas:
                    row = evaluate_setting(backbone, class_name, p_norm, delta_p_recon, inject_layer, alpha, records, eval_pos, args.topk_ratio)
                    row["backbone"] = backbone_name
                    row["pretrained"] = pretrained_name
                    row["img_size"] = img_size_i
                    row["sigma1"] = sigma1
                    row["subspace_k"] = args.subspace_k
                    rows.append(row)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    backbone_tag = "-".join([spec.split(":")[0] for spec in args.backbones])
    stem = f"{args.output_tag}_{class_tag}_{backbone_tag}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump({"config": vars(args), "skipped": skipped, "rows": rows}, f, indent=2)
    plot_curves(rows, out_dir, stem)
    print(csv_path)
    print(json_path)
    print(json.dumps({"skipped": skipped, "rows": rows[:8]}, indent=2))


if __name__ == "__main__":
    main()
