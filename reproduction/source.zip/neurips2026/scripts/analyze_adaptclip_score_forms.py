from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADAPT_ROOT = ROOT / "neurips2026" / "AdaptCLIP"
if str(ADAPT_ROOT) not in sys.path:
    sys.path.insert(0, str(ADAPT_ROOT))
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(1, str(SCRIPT_ROOT))

from official_parallel_test_adaptclip import (  # noqa: E402
    Evaluator,
    activate_margin_map,
    aggregate_results,
    build_dataset,
    build_model,
    compute_baseline_outputs,
    decision_axis,
    fusion_fun,
    get_or_collect_source_patch_banks,
    logmeanexp_negative_sqdist_1d,
    resize_map,
    smooth_map,
)


def append_result(results: dict, mode: str, sample_id: str, cls_name: str, query_path: str, gt_mask: torch.Tensor, gt_anomaly: torch.Tensor, pr_map: torch.Tensor, pr_score: torch.Tensor):
    results[mode]["sample_ids"].append(sample_id)
    results[mode]["cls_names"].append(cls_name)
    results[mode]["query_paths"].append(query_path)
    results[mode]["gt_masks"].append(gt_mask.detach().cpu().int())
    results[mode]["pr_masks"].append(pr_map.detach().cpu())
    results[mode]["gt_anomalys"].append(gt_anomaly.detach().cpu())
    results[mode]["pr_anomalys"].append(pr_score.detach().cpu())


def record_patch_stats(stats: dict, key: str, values: torch.Tensor, mask: torch.Tensor):
    mask = mask.bool()
    pos = values[mask]
    neg = values[~mask]
    topk = max(1, int(neg.numel() * 0.01)) if neg.numel() else 1
    hard_neg = neg[torch.topk(neg, k=min(topk, neg.numel()), largest=True).indices] if neg.numel() else neg
    stats[key] = {
        "pos_mean": float(pos.mean().item()) if pos.numel() else float("nan"),
        "neg_mean": float(neg.mean().item()) if neg.numel() else float("nan"),
        "hard_neg_mean": float(hard_neg.mean().item()) if hard_neg.numel() else float("nan"),
    }


def official_refuse(vl_map: torch.Tensor, tl_map: torch.Tensor, sigma: float, fusion_type: str) -> torch.Tensor:
    fused = fusion_fun([vl_map, tl_map], fusion_type=fusion_type)
    return smooth_map(fused, sigma=sigma).to(vl_map.device)


def main():
    parser = argparse.ArgumentParser("AdaptCLIP candidate score-form analysis")
    parser.add_argument("--source_root", type=str, required=True)
    parser.add_argument("--source_dataset", type=str, required=True)
    parser.add_argument("--target_root", type=str, required=True)
    parser.add_argument("--target_dataset", type=str, required=True)
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument("--save_path", type=str, required=True)
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--fusion_type", type=str, default="average_mean")
    parser.add_argument("--bank_score_source", type=str, choices=["baseline", "tl"], default="tl")
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--bank_cache_path", type=str, required=True)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--max_eval_images", type=int, default=None)
    args = parser.parse_args()

    save_path = Path(args.save_path)
    save_path.parent.mkdir(parents=True, exist_ok=True)

    model, textual_learner, visual_learner, learned_text_features, dpam_layer = build_model(
        args.device,
        args.checkpoint_path,
        args.image_size,
        args.n_ctx,
        args.vl_reduction,
        args.pretrained_model,
    )
    axis = decision_axis(learned_text_features).to(args.device)

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        textual_learner=textual_learner,
        visual_learner=visual_learner,
        learned_text_features=learned_text_features,
        source_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        dpam_layer=dpam_layer,
        sigma=args.sigma,
        fusion_type=args.fusion_type,
        device=args.device,
        source_exclude_class=None,
        bank_score_source=args.bank_score_source,
        hard_frac=args.hard_frac,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.bank_cache_path,
        refresh_bank_cache=False,
    )

    projected_banks = {
        layer_idx: {
            "fp": (fp_banks[layer_idx].to(args.device) @ axis) if fp_banks[layer_idx].numel() else torch.empty((0,), device=args.device),
            "defect": (def_banks[layer_idx].to(args.device) @ axis) if def_banks[layer_idx].numel() else torch.empty((0,), device=args.device),
        }
        for layer_idx in range(len(args.features_list))
    }

    dataset = build_dataset(
        args.target_root,
        args.image_size,
        args.target_dataset,
        "test",
        str(ROOT / "neurips2026" / "results" / "_tmp"),
        class_name=args.class_name,
    )
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
    evaluator = Evaluator("cpu", metrics=["I-AUROC", "I-AP", "P-AUROC", "P-AP"], sample_level=False)

    modes = [
        "baseline_txt",
        "vl_map",
        "tl_map",
        "def_sig",
        "margin_fp05_sig",
        "margin_fp03_sig",
        "hybrid_tl_margin_fp05_w07",
        "hybrid_tl_margin_fp03_w07",
        "corr_baseline_def_a03",
        "corr_baseline_margin_fp03_a03",
        "mul_baseline_def_b10",
        "mul_baseline_margin_fp03_b10",
        "mul_baseline_margin_fp03_b20",
        "mul_tl_def_b10",
        "refuse_add_def_a03",
        "refuse_add_margin_fp03_a03",
        "refuse_mul_def_b10",
        "refuse_mul_margin_fp03_b10",
    ]
    results = {
        mode: {"sample_ids": [], "gt_masks": [], "pr_masks": [], "cls_names": [], "gt_anomalys": [], "pr_anomalys": [], "query_paths": []}
        for mode in modes
    }
    patch_stats = []

    with torch.no_grad():
        for idx, items in enumerate(loader, start=1):
            if args.max_eval_images is not None and idx > args.max_eval_images:
                break

            image = items["img"].to(args.device)
            cls_name = items["cls_name"][0]
            sample_id = f"{cls_name}_{idx}"
            query_path = items["img_path"][0]
            gt_mask = items["img_mask"][:, 0].clone().to(args.device)
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask = gt_mask.int()
            gt_anomaly = items["anomaly"].to(args.device).int()

            baseline = compute_baseline_outputs(
                model,
                textual_learner,
                visual_learner,
                learned_text_features,
                image,
                args.features_list,
                dpam_layer,
                args.image_size,
                args.sigma,
                args.fusion_type,
            )

            tl_map = smooth_map(baseline["local_tl_map"], sigma=args.sigma).to(args.device)
            tl_map = resize_map(tl_map, args.image_size)
            vl_map = smooth_map(baseline["local_vl_map"], sigma=args.sigma).to(args.device)
            vl_map = resize_map(vl_map, args.image_size)
            raw_tl_map = baseline["local_tl_map"]
            raw_vl_map = baseline["local_vl_map"]

            def_maps = []
            fp_maps = []
            margin05_maps = []
            margin03_maps = []

            sample_patch_stats = {"query_path": query_path}
            for layer_idx, patch_feature in enumerate(baseline["query_patch_feats"]):
                patch = torch.nn.functional.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                coeff = patch @ axis
                q_fp = logmeanexp_negative_sqdist_1d(coeff, projected_banks[layer_idx]["fp"], tau=args.tau)
                q_def = logmeanexp_negative_sqdist_1d(coeff, projected_banks[layer_idx]["defect"], tau=args.tau)
                h = int(round(patch.shape[0] ** 0.5))
                q_def_map = q_def.reshape(1, 1, h, h)
                q_fp_map = q_fp.reshape(1, 1, h, h)
                m05_map = (q_def - 0.5 * q_fp).reshape(1, 1, h, h)
                m03_map = (q_def - 0.3 * q_fp).reshape(1, 1, h, h)

                q_def_map = torch.nn.functional.interpolate(q_def_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
                q_fp_map = torch.nn.functional.interpolate(q_fp_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
                m05_map = torch.nn.functional.interpolate(m05_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
                m03_map = torch.nn.functional.interpolate(m03_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]

                def_maps.append(q_def_map)
                fp_maps.append(q_fp_map)
                margin05_maps.append(m05_map)
                margin03_maps.append(m03_map)

                gt_small = torch.nn.functional.interpolate(gt_mask[:, None].float(), size=(h, h), mode="nearest")[:, 0].reshape(-1) > 0.5
                record_patch_stats(sample_patch_stats, f"layer{layer_idx}_q_def", q_def, gt_small)
                record_patch_stats(sample_patch_stats, f"layer{layer_idx}_q_fp", q_fp, gt_small)
                record_patch_stats(sample_patch_stats, f"layer{layer_idx}_m05", q_def - 0.5 * q_fp, gt_small)
                record_patch_stats(sample_patch_stats, f"layer{layer_idx}_m03", q_def - 0.3 * q_fp, gt_small)

            patch_stats.append(sample_patch_stats)

            def_map = smooth_map(torch.stack(def_maps, dim=0).mean(dim=0), sigma=args.sigma).to(args.device)
            fp_map = smooth_map(torch.stack(fp_maps, dim=0).mean(dim=0), sigma=args.sigma).to(args.device)
            margin05 = smooth_map(torch.stack(margin05_maps, dim=0).mean(dim=0), sigma=args.sigma).to(args.device)
            margin03 = smooth_map(torch.stack(margin03_maps, dim=0).mean(dim=0), sigma=args.sigma).to(args.device)

            def_sig = activate_margin_map(def_map, "sigmoid", 1.0)
            margin05_sig = activate_margin_map(margin05, "sigmoid", 1.0)
            margin03_sig = activate_margin_map(margin03, "sigmoid", 1.0)
            hybrid_tl_m05 = 0.7 * tl_map + 0.3 * margin05_sig
            hybrid_tl_m03 = 0.7 * tl_map + 0.3 * margin03_sig
            corr_baseline_def = torch.clamp(baseline["baseline_map"] + 0.3 * (def_sig - 0.5), 0.0, 1.0)
            corr_baseline_m03 = torch.clamp(baseline["baseline_map"] + 0.3 * (margin03_sig - 0.5), 0.0, 1.0)
            mul_baseline_def_b10 = torch.clamp(baseline["baseline_map"] * (1.0 + (def_sig - 0.5)), 0.0, 1.0)
            mul_baseline_m03_b10 = torch.clamp(baseline["baseline_map"] * (1.0 + (margin03_sig - 0.5)), 0.0, 1.0)
            mul_baseline_m03_b20 = torch.clamp(baseline["baseline_map"] * (1.0 + 2.0 * (margin03_sig - 0.5)), 0.0, 1.0)
            mul_tl_def_b10 = torch.clamp(tl_map * (1.0 + (def_sig - 0.5)), 0.0, 1.0)
            tl_ref_add_def = torch.clamp(raw_tl_map + 0.3 * (def_sig - 0.5), 0.0, 1.0)
            tl_ref_add_m03 = torch.clamp(raw_tl_map + 0.3 * (margin03_sig - 0.5), 0.0, 1.0)
            tl_ref_mul_def = torch.clamp(raw_tl_map * (1.0 + (def_sig - 0.5)), 0.0, 1.0)
            tl_ref_mul_m03 = torch.clamp(raw_tl_map * (1.0 + (margin03_sig - 0.5)), 0.0, 1.0)
            refuse_add_def = official_refuse(raw_vl_map, tl_ref_add_def, sigma=args.sigma, fusion_type=args.fusion_type)
            refuse_add_m03 = official_refuse(raw_vl_map, tl_ref_add_m03, sigma=args.sigma, fusion_type=args.fusion_type)
            refuse_mul_def = official_refuse(raw_vl_map, tl_ref_mul_def, sigma=args.sigma, fusion_type=args.fusion_type)
            refuse_mul_m03 = official_refuse(raw_vl_map, tl_ref_mul_m03, sigma=args.sigma, fusion_type=args.fusion_type)

            score_map = {
                "baseline_txt": baseline["baseline_map"],
                "vl_map": vl_map,
                "tl_map": tl_map,
                "def_sig": def_sig,
                "margin_fp05_sig": margin05_sig,
                "margin_fp03_sig": margin03_sig,
                "hybrid_tl_margin_fp05_w07": hybrid_tl_m05,
                "hybrid_tl_margin_fp03_w07": hybrid_tl_m03,
                "corr_baseline_def_a03": corr_baseline_def,
                "corr_baseline_margin_fp03_a03": corr_baseline_m03,
                "mul_baseline_def_b10": mul_baseline_def_b10,
                "mul_baseline_margin_fp03_b10": mul_baseline_m03_b10,
                "mul_baseline_margin_fp03_b20": mul_baseline_m03_b20,
                "mul_tl_def_b10": mul_tl_def_b10,
                "refuse_add_def_a03": refuse_add_def,
                "refuse_add_margin_fp03_a03": refuse_add_m03,
                "refuse_mul_def_b10": refuse_mul_def,
                "refuse_mul_margin_fp03_b10": refuse_mul_m03,
            }

            global_vl = baseline["global_vl_score"]
            global_tl = baseline["global_tl_score"]
            for mode, map_tensor in score_map.items():
                anomaly_map_max, _ = torch.max(map_tensor.view(image.shape[0], -1), dim=1)
                img_score = fusion_fun([global_vl, global_tl, anomaly_map_max], fusion_type=args.fusion_type)
                append_result(results, mode, sample_id, cls_name, query_path, gt_mask, gt_anomaly, map_tensor, img_score)

    metrics = {}
    for mode in modes:
        result_mode = aggregate_results(results[mode])
        metric_results = evaluator.run(result_mode, args.class_name)
        metrics[mode] = {
            "image_auroc": float(metric_results["I-AUROC"]),
            "image_ap": float(metric_results["I-AP"]),
            "pixel_auroc": float(metric_results["P-AUROC"]),
            "pixel_ap": float(metric_results["P-AP"]),
        }

    output = {
        "class_name": args.class_name,
        "bank_score_source": args.bank_score_source,
        "bank_stats": bank_stats,
        "bank_cache_path": str(bank_cache_path),
        "bank_cache_meta": bank_cache_meta,
        "metrics": metrics,
        "patch_stats": patch_stats,
    }
    save_path.write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
