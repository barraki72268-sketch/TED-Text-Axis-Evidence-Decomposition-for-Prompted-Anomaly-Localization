from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)


RECIPES = ["Full", "EL", "M2", "L2", "L"]

LAYER_GAINS = {
    "Ada PRO": [47.97 - 44.03, 26.25 - 18.18, 25.42 - 23.50, 22.78 - 15.19, 46.27 - 34.83],
    "Ada AP": [41.85 - 41.60, 23.81 - 22.40, 36.40 - 36.18, 39.28 - 36.35, 36.77 - 35.78],
    "FA PRO": [76.83 - 73.57, 77.16 - 74.70, 76.54 - 74.35, 76.63 - 72.73, 76.08 - 74.01],
    "FA AP": [30.94 - 22.35, 32.40 - 23.58, 31.46 - 22.58, 31.07 - 22.33, 31.68 - 23.01],
}

BACKBONE_GAINS = [
    ("Ada", 21.43 - 19.74, 4.46 - 4.27),
    ("Adapt", 44.17 - 43.40, 15.92 - 15.22),
    ("Anom.", 38.10 - 27.83, 5.23 - 5.06),
    ("FA", 37.96 - 35.51, 17.22 - 8.78),
]


BLUE = "#1B5E8A"
ORANGE = "#B45F06"
GRID = "#D8D8D8"


def style_axes(ax):
    ax.axhline(0, color="#555555", linewidth=0.9)
    ax.grid(axis="y", color=GRID, linewidth=0.75)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_ylim(-0.8, 12.6)


def draw_layer_panel(ax, *, show_title=True):
    colors = {
        "Ada PRO": BLUE,
        "Ada AP": BLUE,
        "FA PRO": ORANGE,
        "FA AP": ORANGE,
    }
    markers = {"Ada PRO": "o", "Ada AP": "s", "FA PRO": "o", "FA AP": "s"}
    linestyles = {"Ada PRO": "-", "Ada AP": "--", "FA PRO": "-", "FA AP": "--"}

    x = np.arange(len(RECIPES))
    for name, y in LAYER_GAINS.items():
        ax.plot(
            x,
            y,
            color=colors[name],
            marker=markers[name],
            linestyle=linestyles[name],
            linewidth=2.3,
            markersize=5.5,
        )
        ax.text(
            x[-1] + 0.14,
            y[-1],
            name,
            color=colors[name],
            fontsize=8.4,
            fontweight="bold",
            va="center",
        )

    if show_title:
        ax.set_title("(a) Layer-wise retraining", fontweight="bold", pad=6)
    ax.set_ylabel("C-TED gain over B")
    ax.set_xticks(x)
    ax.set_xticklabels(RECIPES)
    for tick in ax.get_xticklabels():
        tick.set_fontsize(12)
        tick.set_fontweight("bold")
    ax.set_xlim(-0.25, len(RECIPES) + 0.18)
    style_axes(ax)


def draw_backbone_panel(ax, *, show_title=True):
    labels = [v[0] for v in BACKBONE_GAINS]
    pro = np.asarray([v[1] for v in BACKBONE_GAINS])
    ap = np.asarray([v[2] for v in BACKBONE_GAINS])
    x = np.arange(len(labels))
    w = 0.34

    bars_pro = ax.bar(x - w / 2, pro, width=w, color=BLUE, alpha=0.94)
    bars_ap = ax.bar(x + w / 2, ap, width=w, color=ORANGE, alpha=0.94)
    for bars, color in [(bars_pro, BLUE), (bars_ap, ORANGE)]:
        for bar in bars:
            h = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                h + 0.28,
                f"{h:.1f}",
                ha="center",
                va="bottom",
                fontsize=8.3,
                fontweight="bold",
                color=color,
            )

    # Compact in-axis legend with colored blocks.
    ax.add_patch(Rectangle((0.05, 0.895), 0.035, 0.045, transform=ax.transAxes, color=BLUE, clip_on=False))
    ax.text(0.095, 0.918, "PRO", transform=ax.transAxes, ha="left", va="center", fontsize=8.8, fontweight="bold")
    ax.add_patch(Rectangle((0.05, 0.805), 0.035, 0.045, transform=ax.transAxes, color=ORANGE, clip_on=False))
    ax.text(0.095, 0.828, "AP", transform=ax.transAxes, ha="left", va="center", fontsize=8.8, fontweight="bold")

    if show_title:
        ax.set_title("(b) Backbone-wise retraining", fontweight="bold", pad=6)
    ax.set_ylabel("C-TED gain over B")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=22, ha="right")
    for tick in ax.get_xticklabels():
        tick.set_fontsize(11)
        tick.set_fontweight("bold")
    style_axes(ax)


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.titlesize": 14,
            "axes.labelsize": 11,
            "xtick.labelsize": 12,
            "ytick.labelsize": 10,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(7.55, 2.95),
        gridspec_kw={"width_ratios": [1.15, 0.92]},
    )
    draw_layer_panel(axes[0])
    draw_backbone_panel(axes[1])
    fig.tight_layout(w_pad=1.6, pad=0.25)

    pdf = FIG_DIR / "recipe_retrain_ab_combined_20260503.pdf"
    png = FIG_DIR / "recipe_retrain_ab_combined_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(1, 1, figsize=(4.55, 2.95))
    draw_layer_panel(ax, show_title=False)
    fig.tight_layout(pad=0.25)
    layer_pdf = FIG_DIR / "recipe_retrain_layerwise_20260503_notitle.pdf"
    layer_png = FIG_DIR / "recipe_retrain_layerwise_20260503_notitle.png"
    fig.savefig(layer_pdf, bbox_inches="tight")
    fig.savefig(layer_png, dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(1, 1, figsize=(3.65, 2.95))
    draw_backbone_panel(ax, show_title=False)
    fig.tight_layout(pad=0.25)
    backbone_pdf = FIG_DIR / "recipe_retrain_backbonewise_20260503_notitle.pdf"
    backbone_png = FIG_DIR / "recipe_retrain_backbonewise_20260503_notitle.png"
    fig.savefig(backbone_pdf, bbox_inches="tight")
    fig.savefig(backbone_png, dpi=300, bbox_inches="tight")
    plt.close(fig)

    tex = OUT_DIR / "recipe_retrain_ab_combined_20260503.tex"
    tex.write_text(
        r"""\begin{figure*}[t]
\centering
\includegraphics[width=0.82\textwidth]{figure/recipe_retrain_ab_combined_20260503.pdf}
\caption{
Recipe-retraining diagnostics.
(a) Feature-layer recipes are retrained before evaluation, but C-TED still improves local PRO/AP over the retrained baseline.
(b) Backbone-wise retraining changes the host geometry; C-TED is evaluated after rebuilding source banks for the retrained backbone.
}
\label{fig:recipe_retrain_ab}
\end{figure*}
""",
        encoding="utf-8",
    )

    print(pdf)
    print(png)
    print(layer_pdf)
    print(layer_png)
    print(backbone_pdf)
    print(backbone_png)
    print(tex)


if __name__ == "__main__":
    main()
