#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
CONTROL = RESULTS / "source_bank_control_20260504"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR = ROOT / "figure"


def load(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    return json.loads(path.read_text())


def pct(x: float | None) -> float | None:
    if x is None:
        return None
    val = float(x)
    return 100.0 * val if abs(val) <= 1.5 else val


def faprompt_metrics(summary: dict[str, Any] | None, variant: str) -> dict[str, float] | None:
    if summary is None:
        return None
    mean = summary.get("mean", {})
    if variant == "baseline":
        m = mean.get("baseline_official", {})
    else:
        parallel = mean.get("parallel", {})
        candidates = [k for k in parallel if k.startswith("branch_calibrated_alpha_")]
        if not candidates:
            return None
        best = max(candidates, key=lambda k: float(parallel[k].get("pixel_ap", float("-inf"))))
        m = parallel[best]
    return {
        "P-AUC": pct(m.get("pixel_auc")),
        "PRO": pct(m.get("pixel_aupro")),
        "AP": pct(m.get("pixel_ap")),
    }


def aaclip_metrics(summary: dict[str, Any] | None, variant: str) -> dict[str, float] | None:
    if summary is None:
        return None
    mean = summary.get("mean", {})
    if variant == "baseline":
        m = mean.get("baseline", {})
    else:
        candidates = mean.get("candidates", {})
        m = candidates.get("prescore_calibrated_alpha_1", mean.get("parallel", {}))
    return {
        "P-AUC": pct(m.get("pixel_auc")),
        "PRO": pct(m.get("pixel_pro") if "pixel_pro" in m else m.get("pixel_aupro")),
        "AP": pct(m.get("pixel_ap")),
    }


HOSTS = {
    "AA-CLIP": {
        "extract": aaclip_metrics,
        "baseline_full": RESULTS / "aaclip_hostres_official_vitl_openai224_mvtec2btad_seed0_pro_20260428" / "summary.json",
        "variants": {
            "Full\nhard-FP": RESULTS / "aaclip_hostres_official_vitl_openai224_mvtec2btad_seed0_pro_20260428" / "summary.json",
            "w/o\nhard-FP": RESULTS / "ablation_ted_aaclip_vitl_openai224_mvtec2btad_no_hardfp_seed0_20260503" / "summary.json",
            "Random\nnormal": CONTROL / "aaclip_vitl_openai224_mvtec2btad_random_normal_seed0" / "summary.json",
            "Easy\nnormal": CONTROL / "aaclip_vitl_openai224_mvtec2btad_easy_normal_seed0" / "summary.json",
        },
    },
    "FAPrompt": {
        "extract": faprompt_metrics,
        "baseline_full": RESULTS
        / "faprompt_branchcal_vitl14_336_f6-12-18-24_dpam20_mvtec2btad_rank4_a02_officialimg_seed0_20260428"
        / "summary.json",
        "variants": {
            "Full\nhard-FP": RESULTS
            / "faprompt_branchcal_vitl14_336_f6-12-18-24_dpam20_mvtec2btad_rank4_a02_officialimg_seed0_20260428"
            / "summary.json",
            "w/o\nhard-FP": RESULTS / "ablation_ted_faprompt_vitl336_mvtec2btad_no_hardfp_seed0_20260430" / "summary.json",
            "Random\nnormal": CONTROL / "faprompt_vitl336_mvtec2btad_random_normal_seed0" / "summary.json",
            "Easy\nnormal": CONTROL / "faprompt_vitl336_mvtec2btad_easy_normal_seed0" / "summary.json",
        },
    },
}


def collect_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for host, cfg in HOSTS.items():
        extract = cfg["extract"]
        base_summary = load(cfg["baseline_full"])
        base = extract(base_summary, "baseline")
        for label, path in cfg["variants"].items():
            summary = load(path)
            vals = extract(summary, "full")
            row: dict[str, Any] = {"host": host, "variant": label.replace("\n", " "), "path": str(path)}
            for metric in ["P-AUC", "PRO", "AP"]:
                row[f"base_{metric}"] = None if base is None else base.get(metric)
                row[f"value_{metric}"] = None if vals is None else vals.get(metric)
                if row[f"base_{metric}"] is None or row[f"value_{metric}"] is None:
                    row[f"delta_{metric}"] = None
                else:
                    row[f"delta_{metric}"] = row[f"value_{metric}"] - row[f"base_{metric}"]
            rows.append(row)
    return rows


def save_table(rows: list[dict[str, Any]]) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    md = OUT_DIR / "source_bank_control_values_20260504.md"
    lines = [
        "# Source-Bank Control",
        "",
        "Values are C-TED minus the official host baseline on MVTec->BTAD.",
        "",
        "| Host | Variant | Delta P-AUC | Delta PRO | Delta AP |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in rows:
        def fmt(x: float | None) -> str:
            return "--" if x is None else f"{x:+.2f}"

        lines.append(
            f"| {row['host']} | {row['variant']} | {fmt(row['delta_P-AUC'])} | {fmt(row['delta_PRO'])} | {fmt(row['delta_AP'])} |"
        )
    md.write_text("\n".join(lines) + "\n")


def plot(rows: list[dict[str, Any]]) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    hosts = list(HOSTS)
    metrics = ["PRO", "AP"]
    colors = {"PRO": "#2667A6", "AP": "#D67B2A"}
    variants = list(next(iter(HOSTS.values()))["variants"])

    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.45), sharey=False)
    for ax, host in zip(axes, hosts):
        host_rows = [r for r in rows if r["host"] == host]
        x = np.arange(len(variants))
        width = 0.34
        for mi, metric in enumerate(metrics):
            values = []
            missing = []
            for variant in variants:
                row = next(r for r in host_rows if r["variant"] == variant.replace("\n", " "))
                val = row[f"delta_{metric}"]
                values.append(0.0 if val is None else float(val))
                missing.append(val is None)
            offset = (mi - 0.5) * width
            bars = ax.bar(x + offset, values, width=width, color=colors[metric], label=metric, alpha=0.92)
            for bar, is_missing in zip(bars, missing):
                if is_missing:
                    bar.set_facecolor("#D8D8D8")
                    bar.set_hatch("//")
                    bar.set_edgecolor("#888888")
                else:
                    h = bar.get_height()
                    ax.text(
                        bar.get_x() + bar.get_width() / 2,
                        h + (0.6 if h >= 0 else -0.9),
                        f"{h:+.1f}",
                        ha="center",
                        va="bottom" if h >= 0 else "top",
                        fontsize=7,
                        fontweight="bold",
                    )
        ax.axhline(0, color="#333333", lw=0.8)
        ax.set_title(host, fontsize=10, fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels(variants, fontsize=8, fontweight="bold")
        ax.tick_params(axis="y", labelsize=8)
        ax.grid(axis="y", color="#E5E5E5", lw=0.6)
        ax.set_axisbelow(True)
    axes[0].set_ylabel("Gain over baseline", fontsize=9, fontweight="bold")
    axes[1].legend(loc="upper right", fontsize=8, frameon=False, ncol=2)
    fig.suptitle("Source-bank evidence control", fontsize=11, fontweight="bold", y=1.02)
    fig.tight_layout(pad=0.6, w_pad=1.0)
    for ext in ["pdf", "png"]:
        fig.savefig(FIG_DIR / f"source_bank_control_20260504.{ext}", bbox_inches="tight", dpi=240)
    plt.close(fig)


def main() -> int:
    rows = collect_rows()
    save_table(rows)
    plot(rows)
    print(json.dumps({"stage": "source_bank_control_figure", "rows": rows, "figure": str(FIG_DIR / "source_bank_control_20260504.pdf")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
