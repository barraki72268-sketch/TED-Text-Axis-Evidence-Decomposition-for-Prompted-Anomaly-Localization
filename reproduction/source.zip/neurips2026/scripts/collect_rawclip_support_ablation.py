from __future__ import annotations

import argparse
import csv
import gc
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from official_parallel_test_rawclip import (  # noqa: E402
    GenericMetaDataset,
    activate_margin_map,
    build_dataset,
    build_transforms,
    encode_global_image_feature,
    encode_prompt_pair,
    farthest_point_subsample,
    load_bank_cache,
    logmeanexp_negative_sqdist_1d,
    smooth_map,
    topk_mean,
)


PRESET_LABELS = {
    "visa2mvtec": "VisA→MVTec",
    "mvtec2visa": "MVTec→VisA",
    "mvtec2mpdd": "MVTec→MPDD",
    "mvtec2btad": "MVTec→BTAD",
}

TARGET_ROOTS = {
    "visa2mvtec": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
    "mvtec2visa": ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls",
    "mvtec2mpdd": Path("/mnt/data/MPDD"),
    "mvtec2btad": ROOT / "neurips2026" / "data" / "BTAD_official",
}

MODEL_SPECS = {
    "rawclip_vitb": {
        "display_name": "RawCLIP ViT-B",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitb_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2btad_all" / "summary.json",
        },
    },
    "rawclip_vitl": {
        "display_name": "RawCLIP ViT-L",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitl_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitl_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitl_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitl_mvtec2btad_all" / "summary.json",
        },
    },
    "rawclip_vitl14openai": {
        "display_name": "RawCLIP ViT-L OpenAI",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitl14openai_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitl14openai_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitl14openai_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitl14openai_mvtec2btad_all" / "summary.json",
        },
    },
    "rawclip_vith14": {
        "display_name": "RawCLIP ViT-H",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vith14_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vith14_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vith14_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vith14_mvtec2btad_all" / "summary.json",
        },
    },
}


def load_json(path: Path) -> dict:
    with path.open("r") as f:
        return json.load(f)


def compute_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    labels = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    scores = np.concatenate([pos, neg])
    order = np.argsort(scores)
    ranks = np.empty_like(order)
    ranks[order] = np.arange(order.size)
    pos_ranks = ranks[: pos.size]
    u = float(pos_ranks.sum() - pos.size * (pos.size - 1) / 2.0)
    return float(u / max(pos.size * neg.size, 1))


def cohens_d(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    v1 = float(np.var(pos, ddof=1)) if pos.size > 1 else 0.0
    v0 = float(np.var(neg, ddof=1)) if neg.size > 1 else 0.0
    denom = pos.size + neg.size - 2
    if denom <= 0:
        return float("nan")
    pooled = math.sqrt(max(((pos.size - 1) * v1 + (neg.size - 1) * v0) / denom, 1e-12))
    return float((float(np.mean(pos)) - float(np.mean(neg))) / pooled)


def logmeanexp_negative_sqdist_nd(feat: torch.Tensor, bank: torch.Tensor, tau: float) -> torch.Tensor:
    if bank.numel() == 0:
        return feat.new_zeros((feat.shape[0],))
    dist2 = torch.cdist(feat, bank, p=2.0) ** 2
    logits = -dist2 / tau
    return torch.logsumexp(logits, dim=-1) - math.log(bank.shape[0])


def distribution_metrics(pos: np.ndarray, neg: np.ndarray) -> dict:
    auc = compute_auc(pos, neg)
    return {
        "auc": float(auc),
        "wrong_pair_rate": float(1.0 - auc),
        "mean_gap": float(np.mean(pos) - np.mean(neg)),
        "cohens_d": cohens_d(pos, neg),
    }


def collect_pure_visual_source_patch_banks(
    backbone,
    source_root: str,
    image_transform,
    mask_transform,
    features_list: list[int],
    heldout_class: str | None,
    max_good_per_class: int,
    max_defect_per_class: int,
    hard_frac: float,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
):
    train_ds = build_dataset(source_root, image_transform, mask_transform, "train")
    test_ds = build_dataset(source_root, image_transform, mask_transform, "test")

    fp_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    def_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    per_good = {cls_name: 0 for cls_name in train_ds.obj_list}
    per_defect = {cls_name: 0 for cls_name in test_ds.obj_list}

    # First pass: estimate per-class visual prototypes from normal source patches only.
    proto_sum: dict[tuple[str, int], torch.Tensor] = {}
    proto_count: dict[tuple[str, int], int] = {}
    selected_train_indices: list[int] = []

    with torch.no_grad():
        for idx in range(len(train_ds)):
            item = train_ds[idx]
            cls_name = item["cls_name"]
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_good[cls_name] >= max_good_per_class:
                continue
            per_good[cls_name] += 1
            selected_train_indices.append(idx)

            image = item["img"].unsqueeze(0).to(backbone.device)
            patch_dict = backbone.extract_layer_patch_tokens(image, target_layers=features_list)
            for out_idx, layer in enumerate(features_list):
                patch = F.normalize(patch_dict[layer][0].float(), dim=-1)
                key = (cls_name, out_idx)
                proto_sum[key] = patch.sum(dim=0) if key not in proto_sum else proto_sum[key] + patch.sum(dim=0)
                proto_count[key] = proto_count.get(key, 0) + int(patch.shape[0])

        prototypes: dict[tuple[str, int], torch.Tensor] = {}
        for key, vec in proto_sum.items():
            prototypes[key] = F.normalize(vec / max(proto_count[key], 1), dim=0)

        # Second pass: choose visually outlier normal patches relative to the class prototype.
        for idx in selected_train_indices:
            item = train_ds[idx]
            cls_name = item["cls_name"]
            image = item["img"].unsqueeze(0).to(backbone.device)
            patch_dict = backbone.extract_layer_patch_tokens(image, target_layers=features_list)
            for out_idx, layer in enumerate(features_list):
                patch = F.normalize(patch_dict[layer][0].float(), dim=-1)
                proto = prototypes[(cls_name, out_idx)]
                outlier_score = 1.0 - (patch @ proto)
                k = max(1, int(outlier_score.numel() * hard_frac))
                top_idx = torch.topk(outlier_score, k=k, largest=True).indices
                selected = patch[top_idx]
                if selected.shape[0] > max_fp_per_image:
                    selected = farthest_point_subsample(selected, max_fp_per_image)
                fp_chunks[out_idx].append(selected.cpu())

        for idx in range(len(test_ds)):
            item = test_ds[idx]
            cls_name = item["cls_name"]
            anomaly_flag = int(item["anomaly"])
            if anomaly_flag == 0:
                continue
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_defect[cls_name] >= max_defect_per_class:
                continue
            per_defect[cls_name] += 1

            image = item["img"].unsqueeze(0).to(backbone.device)
            gt_mask = item["img_mask"].unsqueeze(0).to(backbone.device).float()
            patch_dict = backbone.extract_layer_patch_tokens(image, target_layers=features_list)
            for out_idx, layer in enumerate(features_list):
                patch = F.normalize(patch_dict[layer][0].float(), dim=-1)
                h = backbone.grid_size[0] if patch.shape[0] == backbone.grid_size[0] * backbone.grid_size[1] else int(round(patch.shape[0] ** 0.5))
                w = patch.shape[0] // h
                gt_small = F.interpolate(gt_mask, size=(h, w), mode="nearest")[0, 0].reshape(-1) > 0.5
                if int(gt_small.sum().item()) == 0:
                    continue
                selected = patch[gt_small]
                if selected.shape[0] > max_defect_per_image:
                    selected = farthest_point_subsample(selected, max_defect_per_image)
                def_chunks[out_idx].append(selected.cpu())

    fp_banks: dict[int, torch.Tensor] = {}
    def_banks: dict[int, torch.Tensor] = {}
    token_dim = backbone.visual.class_embedding.shape[0]
    bank_stats: dict[int, dict] = {}
    for out_idx in range(len(features_list)):
        fp_bank = torch.cat(fp_chunks[out_idx], dim=0) if fp_chunks[out_idx] else torch.empty((0, token_dim))
        def_bank = torch.cat(def_chunks[out_idx], dim=0) if def_chunks[out_idx] else torch.empty((0, token_dim))
        if fp_bank.shape[0] > max_bank_per_layer:
            fp_bank = farthest_point_subsample(fp_bank, max_bank_per_layer)
        if def_bank.shape[0] > max_bank_per_layer:
            def_bank = farthest_point_subsample(def_bank, max_bank_per_layer)
        fp_banks[out_idx] = F.normalize(fp_bank.float(), dim=-1) if fp_bank.numel() else fp_bank.float()
        def_banks[out_idx] = F.normalize(def_bank.float(), dim=-1) if def_bank.numel() else def_bank.float()
        bank_stats[out_idx] = {"num_fp": int(fp_banks[out_idx].shape[0]), "num_defect": int(def_banks[out_idx].shape[0])}
    return fp_banks, def_banks, bank_stats


def compute_three_scores(
    backbone,
    item: dict,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    meta: dict,
    image_fusion_weight_override: float | None = None,
) -> tuple[float, float, float]:
    fp_weight = float(meta.get("fp_weight", 1.0))
    map_activation = meta.get("map_activation", "identity")
    map_temperature = float(meta.get("map_temperature", 1.0))
    hybrid_source = meta.get("hybrid_source", "none")
    hybrid_weight = float(meta.get("hybrid_weight", 0.0))
    image = item["img"].unsqueeze(0).to(backbone.device)
    cls_name = item["cls_name"]
    text_pair = encode_prompt_pair(backbone, cls_name, meta["prompt_mode"])
    image_feature = encode_global_image_feature(backbone, image)
    img_logits = image_feature @ torch.stack([text_pair["norm_img"], text_pair["anom_img"]], dim=1)
    global_anom_prob = (img_logits / 0.07).softmax(dim=-1)[0, 1].item()

    patch_dict = backbone.extract_layer_patch_tokens(image, target_layers=meta["features_list"])
    baseline_layer_maps = []
    visual_layer_maps = []
    text_layer_maps = []
    for out_idx, layer in enumerate(meta["features_list"]):
        patch = F.normalize(patch_dict[layer][0].float(), dim=-1)
        logits = patch @ torch.stack([text_pair["norm_tok"], text_pair["anom_tok"]], dim=1)
        probs = (logits / 0.07).softmax(dim=-1)[:, 1]
        h, w = backbone.grid_size
        if patch.shape[0] != h * w:
            h = int(round(patch.shape[0] ** 0.5))
            w = patch.shape[0] // h
        baseline_map = probs.reshape(1, 1, h, w)
        baseline_map = F.interpolate(baseline_map, size=(int(meta["image_size"]), int(meta["image_size"])), mode="bilinear", align_corners=False)[:, 0]
        baseline_layer_maps.append(baseline_map)

        fp_bank = fp_banks[out_idx].to(backbone.device)
        def_bank = def_banks[out_idx].to(backbone.device)

        q_fp_visual = logmeanexp_negative_sqdist_nd(patch, fp_bank, tau=float(meta["tau"]))
        q_def_visual = logmeanexp_negative_sqdist_nd(patch, def_bank, tau=float(meta["tau"]))
        visual_map = (q_def_visual - fp_weight * q_fp_visual).reshape(1, 1, h, w)
        visual_map = F.interpolate(visual_map, size=(int(meta["image_size"]), int(meta["image_size"])), mode="bilinear", align_corners=False)[:, 0]
        visual_layer_maps.append(visual_map)

        axis = text_pair["axis_tok"]
        coeff = patch @ axis
        fp_coeff = fp_bank @ axis if fp_bank.numel() else torch.empty((0,), device=backbone.device)
        def_coeff = def_bank @ axis if def_bank.numel() else torch.empty((0,), device=backbone.device)
        q_fp_text = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=float(meta["tau"]))
        q_def_text = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=float(meta["tau"]))
        text_map = (q_def_text - fp_weight * q_fp_text).reshape(1, 1, h, w)
        text_map = F.interpolate(text_map, size=(int(meta["image_size"]), int(meta["image_size"])), mode="bilinear", align_corners=False)[:, 0]
        text_layer_maps.append(text_map)

    baseline_map = smooth_map(torch.stack(baseline_layer_maps).mean(dim=0), sigma=float(meta["sigma"]))
    visual_map = smooth_map(torch.stack(visual_layer_maps).mean(dim=0), sigma=float(meta["sigma"]))
    text_map = smooth_map(torch.stack(text_layer_maps).mean(dim=0), sigma=float(meta["sigma"]))
    visual_map = activate_margin_map(visual_map, activation=map_activation, temperature=map_temperature)
    text_map = activate_margin_map(text_map, activation=map_activation, temperature=map_temperature)
    if hybrid_source != "none" and hybrid_weight > 0:
        if hybrid_source == "baseline":
            visual_map = (1.0 - hybrid_weight) * visual_map + hybrid_weight * baseline_map
            text_map = (1.0 - hybrid_weight) * text_map + hybrid_weight * baseline_map
        else:
            raise ValueError(f"Unsupported hybrid_source: {hybrid_source}")

    image_fusion_weight = float(meta["image_fusion_weight"]) if image_fusion_weight_override is None else float(image_fusion_weight_override)

    baseline_score = image_fusion_weight * global_anom_prob + (1.0 - image_fusion_weight) * topk_mean(
        baseline_map[0].numpy(), float(meta["image_score_topk"])
    )
    visual_score = image_fusion_weight * global_anom_prob + (1.0 - image_fusion_weight) * topk_mean(
        visual_map[0].numpy(), float(meta["image_score_topk"])
    )
    text_score = image_fusion_weight * global_anom_prob + (1.0 - image_fusion_weight) * topk_mean(
        text_map[0].numpy(), float(meta["image_score_topk"])
    )
    return baseline_score, visual_score, text_score


def build_backbone_and_meta(model_key: str, preset: str, device: str, bank_selection_mode: str, bank_override: dict | None = None):
    spec = MODEL_SPECS[model_key]
    summary_path = spec["summaries"][preset]
    meta = load_json(summary_path)["summary"]
    backbone = create_winclip_raw_backbone(
        backbone=meta["backbone"],
        pretrained_dataset=meta["pretrained_dataset"],
        device=device,
        img_resize=int(meta["image_size"]),
        img_cropsize=int(meta["image_size"]),
    )
    if bank_selection_mode == "text_selected":
        fp_banks, def_banks, _, _ = load_bank_cache(Path(meta["bank_cache_path"]))
    elif bank_selection_mode == "pure_visual":
        cache_meta = meta["bank_cache_meta"]
        cfg = dict(cache_meta)
        if bank_override:
            cfg.update({k: v for k, v in bank_override.items() if v is not None})
        image_transform, mask_transform = build_transforms(int(meta["image_size"]))
        fp_banks, def_banks, _, = collect_pure_visual_source_patch_banks(
            backbone=backbone,
            source_root=str(cfg["source_root"]),
            image_transform=image_transform,
            mask_transform=mask_transform,
            features_list=list(meta["features_list"]),
            heldout_class=cfg.get("heldout_class"),
            max_good_per_class=int(cfg["max_good_per_class"]),
            max_defect_per_class=int(cfg["max_defect_per_class"]),
            hard_frac=float(cfg["hard_frac"]),
            max_bank_per_layer=int(cfg["max_bank_per_layer"]),
            max_fp_per_image=int(cfg["max_fp_per_image"]),
            max_defect_per_image=int(cfg["max_defect_per_image"]),
        )
    else:
        raise ValueError(f"Unsupported bank_selection_mode: {bank_selection_mode}")
    return backbone, fp_banks, def_banks, meta, summary_path


def collect_subset_scores(
    model_key: str,
    preset: str,
    device: str,
    max_normal_images: int,
    max_anomaly_images: int,
    seed: int,
    bank_selection_mode: str,
    bank_override: dict | None = None,
    image_fusion_weight_override: float | None = None,
) -> tuple[dict[str, np.ndarray], dict]:
    backbone, fp_banks, def_banks, meta, summary_path = build_backbone_and_meta(
        model_key, preset, device, bank_selection_mode, bank_override=bank_override
    )
    image_transform, mask_transform = build_transforms(int(meta["image_size"]))
    ds = GenericMetaDataset(
        root=str(TARGET_ROOTS[preset]),
        image_transform=image_transform,
        mask_transform=mask_transform,
        split="test",
    )
    rng = np.random.default_rng(seed)
    normal_indices = [idx for idx, item in enumerate(ds.items) if int(item["anomaly"]) == 0]
    anomaly_indices = [idx for idx, item in enumerate(ds.items) if int(item["anomaly"]) == 1]
    if len(normal_indices) > max_normal_images:
        normal_indices = rng.choice(normal_indices, size=max_normal_images, replace=False).tolist()
    if len(anomaly_indices) > max_anomaly_images:
        anomaly_indices = rng.choice(anomaly_indices, size=max_anomaly_images, replace=False).tolist()
    selected_indices = sorted(normal_indices + anomaly_indices)

    out = {
        "raw_anomaly": [],
        "raw_normal": [],
        "visual_anomaly": [],
        "visual_normal": [],
        "text_anomaly": [],
        "text_normal": [],
    }
    records = []

    with torch.no_grad():
        for idx in selected_indices:
            item = ds[idx]
            anomaly_flag = int(item["anomaly"])
            raw_score, visual_score, text_score = compute_three_scores(
                backbone,
                item,
                fp_banks,
                def_banks,
                meta,
                image_fusion_weight_override=image_fusion_weight_override,
            )
            suffix = "anomaly" if anomaly_flag == 1 else "normal"
            out[f"raw_{suffix}"].append(raw_score)
            out[f"visual_{suffix}"].append(visual_score)
            out[f"text_{suffix}"].append(text_score)
            records.append(
                {
                    "image_path": item["img_path"],
                    "cls_name": item["cls_name"],
                    "anomaly": anomaly_flag,
                    "raw_score": float(raw_score),
                    "visual_score": float(visual_score),
                    "text_score": float(text_score),
                }
            )

    arrays = {k: np.asarray(v, dtype=np.float32) for k, v in out.items()}
    payload = {
        "meta": {
            "model_key": model_key,
            "model_label": MODEL_SPECS[model_key]["display_name"],
            "preset": preset,
            "preset_label": PRESET_LABELS[preset],
            "summary_path": str(summary_path),
            "num_anomaly": int(arrays["raw_anomaly"].size),
            "num_normal": int(arrays["raw_normal"].size),
            "bank_selection_mode": bank_selection_mode,
            "bank_override": bank_override or {},
            "image_fusion_weight_override": image_fusion_weight_override,
        },
        "records": records,
    }

    del backbone
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return arrays, payload


def save_figure(rows: list[dict], model_label: str, save_dir: Path) -> None:
    labels = [r["preset_label"] for r in rows]
    y = np.arange(len(rows))
    raw = [r["raw_wrong_pair_rate"] for r in rows]
    visual = [r["visual_wrong_pair_rate"] for r in rows]
    text = [r["text_wrong_pair_rate"] for r in rows]

    fig, ax = plt.subplots(1, 1, figsize=(8.2, 4.8), constrained_layout=True)
    for i in range(len(rows)):
        ax.plot([raw[i], visual[i], text[i]], [i, i, i], color="#B0B0B0", lw=1.8)
        ax.scatter(raw[i], i, s=60, color="#D95F02", label="Raw score" if i == 0 else None)
        ax.scatter(visual[i], i, s=60, color="#7570B3", label="Visual support only" if i == 0 else None)
        ax.scatter(text[i], i, s=60, color="#1B9E77", label="Text-conditioned support" if i == 0 else None)
        ax.text(text[i] + 0.015, i, f"{text[i]-visual[i]:+.2f}", va="center", fontsize=9)
    ax.set_yticks(y, labels)
    ax.set_xlim(0.0, 0.85)
    ax.set_xlabel("Wrong pair rate")
    ax.grid(axis="x", alpha=0.15)
    ax.legend(frameon=False, loc="lower right")
    fig.savefig(save_dir / "support_ablation.png", dpi=220, bbox_inches="tight")
    fig.savefig(save_dir / "support_ablation.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser("RawCLIP support ablation: raw vs visual-only vs text-conditioned")
    parser.add_argument("--model_keys", type=str, default="rawclip_vitb,rawclip_vitl,rawclip_vitl14openai,rawclip_vith14")
    parser.add_argument("--presets", type=str, default=",".join(PRESET_LABELS.keys()))
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--max_normal_images", type=int, default=64)
    parser.add_argument("--max_anomaly_images", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--bank_selection_mode", type=str, default="text_selected", choices=["text_selected", "pure_visual"])
    parser.add_argument("--override_max_good_per_class", type=int, default=None)
    parser.add_argument("--override_max_defect_per_class", type=int, default=None)
    parser.add_argument("--override_max_bank_per_layer", type=int, default=None)
    parser.add_argument("--override_max_fp_per_image", type=int, default=None)
    parser.add_argument("--override_max_defect_per_image", type=int, default=None)
    parser.add_argument("--override_hard_frac", type=float, default=None)
    parser.add_argument("--image_fusion_weight_override", type=float, default=None)
    parser.add_argument("--save_root", type=str, default=str(RESULTS / "rawclip_support_ablation"))
    args = parser.parse_args()

    model_keys = [k.strip() for k in args.model_keys.split(",") if k.strip()]
    presets = [k.strip() for k in args.presets.split(",") if k.strip()]
    bank_override = {
        "max_good_per_class": args.override_max_good_per_class,
        "max_defect_per_class": args.override_max_defect_per_class,
        "max_bank_per_layer": args.override_max_bank_per_layer,
        "max_fp_per_image": args.override_max_fp_per_image,
        "max_defect_per_image": args.override_max_defect_per_image,
        "hard_frac": args.override_hard_frac,
    }
    save_root = Path(args.save_root)
    save_root.mkdir(parents=True, exist_ok=True)

    manifest = {}
    for model_key in model_keys:
        spec = MODEL_SPECS[model_key]
        model_dir = save_root / model_key
        model_dir.mkdir(parents=True, exist_ok=True)
        rows = []
        arrays_manifest = {}
        for preset in presets:
            arrays, payload = collect_subset_scores(
                model_key=model_key,
                preset=preset,
                device=args.device,
                max_normal_images=args.max_normal_images,
                max_anomaly_images=args.max_anomaly_images,
                seed=args.seed,
                bank_selection_mode=args.bank_selection_mode,
                bank_override=bank_override,
                image_fusion_weight_override=args.image_fusion_weight_override,
            )
            raw = distribution_metrics(arrays["raw_anomaly"], arrays["raw_normal"])
            visual = distribution_metrics(arrays["visual_anomaly"], arrays["visual_normal"])
            text = distribution_metrics(arrays["text_anomaly"], arrays["text_normal"])
            row = {
                "model_key": model_key,
                "model_label": spec["display_name"],
                "preset": preset,
                "preset_label": PRESET_LABELS[preset],
                "num_anomaly": int(payload["meta"]["num_anomaly"]),
                "num_normal": int(payload["meta"]["num_normal"]),
                "raw_auc": raw["auc"],
                "visual_auc": visual["auc"],
                "text_auc": text["auc"],
                "raw_wrong_pair_rate": raw["wrong_pair_rate"],
                "visual_wrong_pair_rate": visual["wrong_pair_rate"],
                "text_wrong_pair_rate": text["wrong_pair_rate"],
                "raw_d": raw["cohens_d"],
                "visual_d": visual["cohens_d"],
                "text_d": text["cohens_d"],
            }
            rows.append(row)
            arrays_file = model_dir / f"{preset}_arrays.npz"
            np.savez_compressed(arrays_file, **arrays)
            arrays_manifest[preset] = str(arrays_file)
            print(
                json.dumps(
                    {
                        "model_key": model_key,
                        "preset": preset,
                        "raw_wrong_pair_rate": row["raw_wrong_pair_rate"],
                        "visual_wrong_pair_rate": row["visual_wrong_pair_rate"],
                        "text_wrong_pair_rate": row["text_wrong_pair_rate"],
                    }
                ),
                flush=True,
            )

        with (model_dir / "metrics.json").open("w") as f:
            json.dump({"rows": rows, "arrays": arrays_manifest}, f, indent=2)
        with (model_dir / "metrics.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        save_figure(rows, spec["display_name"], model_dir)
        manifest[model_key] = {
            "display_name": spec["display_name"],
            "metrics_json": str(model_dir / "metrics.json"),
            "figure_png": str(model_dir / "support_ablation.png"),
        }

    with (save_root / "manifest.json").open("w") as f:
        json.dump(manifest, f, indent=2)


if __name__ == "__main__":
    main()
