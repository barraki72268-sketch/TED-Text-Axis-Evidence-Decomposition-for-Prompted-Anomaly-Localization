#!/usr/bin/env python3
"""Detached backbone-retrained stress queue for extra hosts.

Protocol:
1. replace the visual backbone with ViT-B/16+,
2. retrain the host baseline on VisA 1cls,
3. rebuild source evidence banks from the retrained checkpoint,
4. evaluate B / T-TED / C-TED on VisA -> MVTec.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT = ROOT / "neurips2026/results/backbone_retrained_extra_hosts_20260503"
LOG = OUT / "logs"
BANK = OUT / "bank_cache"

VISA = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def wait_pids(pids: list[int], log) -> None:
    remaining = [pid for pid in pids if pid > 0]
    while remaining:
        alive = [pid for pid in remaining if pid_alive(pid)]
        done = sorted(set(remaining) - set(alive))
        for pid in done:
            print(json.dumps({"stage": "wait_pid_done", "pid": pid}), file=log, flush=True)
        remaining = alive
        if remaining:
            print(json.dumps({"stage": "wait_pid", "pids": remaining}), file=log, flush=True)
            time.sleep(60)


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print(json.dumps({"stage": "run", "log": str(log_path), "cmd": cmd}), flush=True)
    with log_path.open("w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print(json.dumps({"stage": "done", "log": str(log_path), "returncode": proc.returncode}), flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def train_adaptclip(env: dict[str, str]) -> Path:
    ckpt_dir = OUT / "adaptclip_vitbplus_visa_ckpt"
    ckpt = ckpt_dir / "epoch_15.pth"
    if ckpt.exists():
        print(json.dumps({"stage": "skip_train", "host": "AdaptCLIP", "checkpoint": str(ckpt)}), flush=True)
        return ckpt
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "visa",
            "--train_data_path",
            str(VISA),
            "--save_path",
            str(ckpt_dir),
            "--pretrained_model",
            "VITB16_PLUS_240",
            "--features_list",
            "3",
            "6",
            "9",
            "12",
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--seed",
            "10",
            "--n_ctx",
            "12",
            "--vl_reduction",
            "4",
            "--pq_mid_dim",
            "128",
            "--visual_learner",
            "--textual_learner",
            "--pq_learner",
            "--pq_context",
        ],
        ROOT / "neurips2026/AdaptCLIP",
        LOG / "adaptclip_train_vitbplus_visa.log",
        env,
    )
    return ckpt


def eval_adaptclip(ckpt: Path, env: dict[str, str]) -> None:
    save_dir = OUT / "adaptclip_vitbplus_visa2mvtec_eval"
    summary = save_dir / "summary.json"
    if summary.exists():
        print(json.dumps({"stage": "skip_eval", "host": "AdaptCLIP", "summary": str(summary)}), flush=True)
        return
    run(
        [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/official_parallel_test_adaptclip_vlrefine.py"),
            "--source_root",
            str(VISA),
            "--source_dataset",
            "visa",
            "--target_root",
            str(MVTEC),
            "--target_dataset",
            "mvtec",
            "--checkpoint_path",
            str(ckpt),
            "--save_dir",
            str(save_dir),
            "--bank_cache_path",
            str(BANK / "adaptclip_vitbplus_visa_vl.pt"),
            "--tl_bank_cache_path",
            str(BANK / "adaptclip_vitbplus_visa_tl.pt"),
            "--pretrained_model",
            "VITB16_PLUS_240",
            "--checkpoint_load_mode",
            "strict",
            "--features_list",
            "3",
            "6",
            "9",
            "12",
            "--image_size",
            "518",
            "--batch_size",
            "1",
            "--n_ctx",
            "12",
            "--sigma",
            "4",
            "--vl_reduction",
            "4",
            "--fusion_type",
            "average_mean",
            "--max_good_per_class",
            "2",
            "--max_defect_per_class",
            "4",
            "--max_bank_points",
            "512",
            "--max_fp_per_image",
            "64",
            "--max_defect_per_image",
            "64",
            "--tau",
            "20.0",
            "--fp_weight",
            "0.3",
            "--corr_alpha",
            "0.3",
            "--map_activation",
            "sigmoid",
            "--map_temperature",
            "1.0",
            "--trainfree_score_mode",
            "rankr_density",
            "--vl_gate_mode",
            "host",
            "--vl_gate_quantile",
            "0.9",
            "--vl_gate_temp",
            "0.25",
            "--ted_insertion",
            "dual_branch",
            "--calib_epochs",
            "30",
            "--calib_hardpair_frac",
            "0.75",
            "--calib_subspace_rank",
            "2",
            "--calib_lambda",
            "0.005",
            "--calib_score_mode",
            "rankr_density",
            "--calib_rankr_tau",
            "0.1",
            "--calib_apply_mode",
            "add",
            "--eval_metrics",
            "I-AUROC",
            "I-AP",
            "P-AUROC",
            "P-AP",
            "P-AUPRO",
            "--aupro_max_step",
            "200",
            "--aupro_expect_fpr",
            "0.3",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--num_workers",
            "4",
        ],
        ROOT,
        LOG / "adaptclip_eval_vitbplus_visa2mvtec.log",
        env,
    )


def train_faprompt(env: dict[str, str]) -> Path:
    ckpt_dir = OUT / "faprompt_vitbplus_visa_ckpt"
    ckpt = ckpt_dir / "epoch_15.pth"
    if ckpt.exists():
        print(json.dumps({"stage": "skip_train", "host": "FAPrompt", "checkpoint": str(ckpt)}), flush=True)
        return ckpt
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "visa",
            "--train_data_path",
            str(VISA),
            "--save_path",
            str(ckpt_dir),
            "--model_name",
            "ViT-B-16-plus-240",
            "--dpam_layer",
            "10",
            "--features_list",
            "3",
            "6",
            "9",
            "12",
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ],
        ROOT / "neurips2026/FAPrompt",
        LOG / "faprompt_train_vitbplus_visa.log",
        env,
    )
    return ckpt


def eval_faprompt(ckpt: Path, env: dict[str, str]) -> None:
    save_dir = OUT / "faprompt_vitbplus_visa2mvtec_eval"
    summary = save_dir / "summary.json"
    if summary.exists():
        print(json.dumps({"stage": "skip_eval", "host": "FAPrompt", "summary": str(summary)}), flush=True)
        return
    run(
        [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/official_parallel_test_faprompt.py"),
            "--preset",
            "visa2mvtec",
            "--checkpoint_path",
            str(ckpt),
            "--save_dir",
            str(save_dir),
            "--model_name",
            "ViT-B-16-plus-240",
            "--prompt_load_mode",
            "strict",
            "--features_list",
            "3",
            "6",
            "9",
            "12",
            "--image_size",
            "518",
            "--batch_size",
            "2",
            "--num_workers",
            "4",
            "--dap_token_mode",
            "official_firstk",
            "--dpam_layer",
            "10",
            "--max_fp_per_class",
            "512",
            "--max_defect_per_class",
            "512",
            "--max_fp_total",
            "4096",
            "--max_defect_total",
            "4096",
            "--normal_topk_frac",
            "0.01",
            "--tau",
            "0.1",
            "--fp_weight",
            "1.0",
            "--alphas",
            "0.5,1.0",
            "--ours_image_score_mode",
            "official",
            "--insert_modes",
            "support_only,branch_calibrated",
            "--prescore_calib_epochs",
            "30",
            "--prescore_calib_lr",
            "0.02",
            "--prescore_calib_max_train_points",
            "2048",
            "--prescore_calib_alpha_init",
            "0.05",
            "--prescore_calib_alpha_max",
            "0.2",
            "--prescore_calib_subspace_rank",
            "4",
            "--aupro_max_step",
            "50",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--force_rebuild_bank",
        ],
        ROOT,
        LOG / "faprompt_eval_vitbplus_visa2mvtec.log",
        env,
    )


def run_job(name: str, fn, status: list[dict]) -> None:
    try:
        fn()
    except Exception as exc:  # keep later jobs alive and persist the failure.
        row = {"name": name, "status": "failed", "error": repr(exc)}
        status.append(row)
        (OUT / "status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
        print(json.dumps({"stage": "job_failed", **row}), flush=True)
        return
    row = {"name": name, "status": "done"}
    status.append(row)
    (OUT / "status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(json.dumps({"stage": "job_done", **row}), flush=True)


def run_queue(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    BANK.mkdir(parents=True, exist_ok=True)
    log_path = OUT / "master.log"
    status: list[dict] = []
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-backbone-retrained-extra-hosts-20260503")

    with log_path.open("a", encoding="utf-8") as log:
        print(json.dumps({"stage": "queue_start", "gpu": args.gpu, "wait_pids": args.wait_pids}), file=log, flush=True)
        wait_pids(args.wait_pids, log)

    def adaptclip_job() -> None:
        eval_adaptclip(train_adaptclip(env), env)

    def faprompt_job() -> None:
        eval_faprompt(train_faprompt(env), env)

    run_job("adaptclip_vitbplus_retrain_visa2mvtec", adaptclip_job, status)
    run_job("faprompt_vitbplus_retrain_visa2mvtec", faprompt_job, status)

    failed = [row for row in status if row["status"] != "done"]
    return 1 if failed else 0


def detach(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(Path(__file__).resolve()),
        "--gpu",
        str(args.gpu),
    ]
    for pid in args.wait_pids:
        cmd.extend(["--wait-pid", str(pid)])
    log_path = OUT / "detached.log"
    pid_path = OUT / "detached.pid"
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    log = log_path.open("a", encoding="utf-8")
    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        close_fds=True,
    )
    pid_path.write_text(str(proc.pid), encoding="utf-8")
    print(json.dumps({"stage": "detached_started", "pid": proc.pid, "log": str(log_path), "pid_file": str(pid_path)}), flush=True)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", default="1")
    parser.add_argument("--wait-pid", dest="wait_pids", type=int, action="append", default=[])
    parser.add_argument("--detach", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.detach:
        return detach(args)
    return run_queue(args)


if __name__ == "__main__":
    raise SystemExit(main())
