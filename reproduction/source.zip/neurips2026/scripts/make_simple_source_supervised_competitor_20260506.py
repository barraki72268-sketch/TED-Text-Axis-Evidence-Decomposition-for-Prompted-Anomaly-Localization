#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results" / "simple_source_supervised_competitor_20260506"
OUT_DIR = ROOT / "supp_fig"
CSV_OUT = OUT_DIR / "simple_source_supervised_competitor_20260506.csv"
TEX_OUT = OUT_DIR / "simple_source_supervised_competitor_20260506.tex"


def pct(x: float) -> float:
    return 100.0 * x if abs(x) <= 1.5 else x


def metric_triplet(blob: dict, *, pro_key: str) -> tuple[float, float, float]:
    return (
        pct(float(blob.get("pixel_auc", float("nan")))),
        pct(float(blob.get(pro_key, blob.get("pixel_aupro", float("nan"))))),
        pct(float(blob.get("pixel_ap", float("nan")))),
    )


def delta_triplet(candidate: tuple[float, float, float], base: tuple[float, float, float]) -> tuple[float, float, float]:
    return tuple(c - b for c, b in zip(candidate, base))


def delta_loc(delta: tuple[float, float, float]) -> float:
    return 0.5 * (delta[1] + delta[2])


def best_key(candidates: dict, prefixes: tuple[str, ...]) -> str | None:
    keys = [k for k in candidates if any(k.startswith(prefix) for prefix in prefixes)]
    if not keys:
        return None
    return sorted(keys)[0]


def parse_summary(path: Path) -> dict | None:
    data = json.load(path.open())
    name = path.parent.name
    if name.startswith("faprompt_"):
        host = "FAPrompt"
        mean = data.get("mean", {})
        base_blob = mean.get("baseline_official")
        candidates = mean.get("parallel", {})
        pro_key = "pixel_aupro"
        replace_key = best_key(candidates, ("plugin_replace_alpha_",))
        residual_key = best_key(candidates, ("plugin_residual_alpha_",))
        cted_key = best_key(candidates, ("branch_calibrated_alpha_",))
    elif name.startswith("aaclip_"):
        host = "AA-CLIP"
        mean = data.get("mean", {})
        base_blob = mean.get("baseline")
        candidates = mean.get("candidates", {})
        pro_key = "pixel_pro"
        replace_key = best_key(candidates, ("plugin_replace_alpha_",))
        residual_key = best_key(candidates, ("plugin_residual_alpha_",))
        cted_key = best_key(candidates, ("prescore_calibrated_alpha_",))
    elif name.startswith("adaclip_"):
        return parse_row_summary(
            data=data,
            name=name,
            host="AdaCLIP",
            base_mode="baseline_txt",
            replace_mode="scalar_replace",
            residual_mode="scalar_residual",
            cted_mode="ted_calibrated",
        )
    elif name.startswith("adaptclip_"):
        return parse_row_summary(
            data=data,
            name=name,
            host="AdaptCLIP",
            base_mode="baseline_txt",
            replace_mode="scalar_replace_vl",
            residual_mode="scalar_residual_vl",
            cted_mode="ted_calibrated_vl",
        )
    else:
        return None
    if not base_blob or not replace_key or not residual_key or not cted_key:
        return None
    base = metric_triplet(base_blob, pro_key=pro_key)
    row = {
        "host": host,
        "setting": name,
        "baseline_p_auc": base[0],
        "baseline_pro": base[1],
        "baseline_ap": base[2],
        "replace_key": replace_key,
        "residual_key": residual_key,
        "cted_key": cted_key,
    }
    for label, key in [("scalar_replace", replace_key), ("scalar_residual", residual_key), ("cted", cted_key)]:
        candidate = metric_triplet(candidates[key], pro_key=pro_key)
        d = delta_triplet(candidate, base)
        row[f"{label}_delta_p_auc"] = d[0]
        row[f"{label}_delta_pro"] = d[1]
        row[f"{label}_delta_ap"] = d[2]
        row[f"{label}_delta_loc"] = delta_loc(d)
    return row


def parse_row_summary(
    data: dict,
    name: str,
    host: str,
    base_mode: str,
    replace_mode: str,
    residual_mode: str,
    cted_mode: str,
) -> dict | None:
    if int(data.get("summary", {}).get("max_eval_images", 0) or 0) > 0:
        return None
    mean_rows = {
        row.get("mode"): row
        for row in data.get("rows", [])
        if row.get("target_label") == "mean"
    }
    required = [base_mode, replace_mode, residual_mode, cted_mode]
    if any(mode not in mean_rows for mode in required):
        return None

    def triplet(row: dict) -> tuple[float, float, float]:
        return (
            pct(float(row.get("pixel_auroc", float("nan")))),
            pct(float(row.get("pixel_aupro", float("nan")))),
            pct(float(row.get("pixel_ap", float("nan")))),
        )

    base = triplet(mean_rows[base_mode])
    row = {
        "host": host,
        "setting": name,
        "baseline_p_auc": base[0],
        "baseline_pro": base[1],
        "baseline_ap": base[2],
        "replace_key": replace_mode,
        "residual_key": residual_mode,
        "cted_key": cted_mode,
    }
    for label, mode in [("scalar_replace", replace_mode), ("scalar_residual", residual_mode), ("cted", cted_mode)]:
        d = delta_triplet(triplet(mean_rows[mode]), base)
        row[f"{label}_delta_p_auc"] = d[0]
        row[f"{label}_delta_pro"] = d[1]
        row[f"{label}_delta_ap"] = d[2]
        row[f"{label}_delta_loc"] = delta_loc(d)
    return row


def fmt(x: float) -> str:
    if math.isnan(x):
        return "--"
    return f"{x:+.1f}"


def aggregate(rows: list[dict]) -> list[dict]:
    out = []
    for host in ["FAPrompt", "AA-CLIP", "AdaCLIP", "AdaptCLIP"]:
        sub = [r for r in rows if r["host"] == host]
        if not sub:
            continue
        agg = {"scope": host, "n": len(sub)}
        for key in ["scalar_replace", "scalar_residual", "cted"]:
            for metric in ["delta_p_auc", "delta_pro", "delta_ap", "delta_loc"]:
                vals = [float(r[f"{key}_{metric}"]) for r in sub]
                agg[f"{key}_{metric}"] = float(np.mean(vals))
        out.append(agg)
    if rows:
        agg = {"scope": "Mean", "n": len(rows)}
        for key in ["scalar_replace", "scalar_residual", "cted"]:
            for metric in ["delta_p_auc", "delta_pro", "delta_ap", "delta_loc"]:
                vals = [float(r[f"{key}_{metric}"]) for r in rows]
                agg[f"{key}_{metric}"] = float(np.mean(vals))
        out.append(agg)
    return out


def write_csv(rows: list[dict]) -> None:
    CSV_OUT.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "host",
        "setting",
        "baseline_p_auc",
        "baseline_pro",
        "baseline_ap",
        "scalar_replace_delta_p_auc",
        "scalar_replace_delta_pro",
        "scalar_replace_delta_ap",
        "scalar_replace_delta_loc",
        "scalar_residual_delta_p_auc",
        "scalar_residual_delta_pro",
        "scalar_residual_delta_ap",
        "scalar_residual_delta_loc",
        "cted_delta_p_auc",
        "cted_delta_pro",
        "cted_delta_ap",
        "cted_delta_loc",
        "replace_key",
        "residual_key",
        "cted_key",
    ]
    with CSV_OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fields})


def write_tex(aggs: list[dict]) -> None:
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Simple source-supervised readout control.",
        r"All variants use the same source defect and hard-normal banks.",
        r"The scalar readouts train a source-only logistic classifier on text-axis support features and either replace the local map or add a residual to the host map.",
        r"Values are gains over the corresponding host baseline; $\Delta$Loc is the mean of $\Delta$PRO and $\Delta$AP.",
        r"}",
        r"\label{tab:simple_source_supervised_competitor}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.8pt}",
        r"\renewcommand{\arraystretch}{1.06}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lcccc}",
        r"\toprule",
        r"Scope & $n$ & Scalar replace $\Delta$Loc & Scalar residual $\Delta$Loc & C-TED $\Delta$Loc \\",
        r"\midrule",
    ]
    for row in aggs:
        lines.append(
            f"{row['scope']} & {row['n']} & "
            f"{fmt(row['scalar_replace_delta_loc'])} & "
            f"{fmt(row['scalar_residual_delta_loc'])} & "
            f"{fmt(row['cted_delta_loc'])} \\\\"
        )
    lines += [
        r"\bottomrule",
        r"\end{tabular*}",
        r"\end{table}",
        "",
    ]
    TEX_OUT.write_text("\n".join(lines))


def main() -> int:
    rows = []
    for path in sorted(RESULTS.glob("*/summary.json")):
        row = parse_summary(path)
        if row is not None:
            rows.append(row)
    write_csv(rows)
    aggs = aggregate(rows)
    write_tex(aggs)
    print(json.dumps({"rows": len(rows), "csv": str(CSV_OUT.relative_to(ROOT)), "tex": str(TEX_OUT.relative_to(ROOT)), "aggregate": aggs}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
