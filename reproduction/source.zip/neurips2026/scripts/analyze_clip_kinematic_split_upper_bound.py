from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--summary_csv",
        type=str,
        default="neurips2026/results/clip_kin_split_allvisa_allvisa_layers3-6-9-12_summary.csv",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="neurips2026/results/clip_kin_split_allvisa_analysis",
    )
    parser.add_argument("--top_n", type=int, default=3)
    return parser.parse_args()


def load_rows(path: str) -> list[dict]:
    rows = list(csv.DictReader(open(path)))
    parsed: list[dict] = []
    for row in rows:
        out: dict = {}
        for k, v in row.items():
            try:
                out[k] = float(v)
            except (TypeError, ValueError):
                out[k] = v
        out["layer"] = int(out["layer"])
        parsed.append(out)
    return parsed


def get_best_records(rows: list[dict]) -> list[dict]:
    by_class: dict[str, list[dict]] = {}
    for row in rows:
        by_class.setdefault(row["class_name"], []).append(row)

    best_records: list[dict] = []
    for class_name, class_rows in by_class.items():
        best = max(class_rows, key=lambda r: r["best_mean_auc"])
        best_k = int(best["best_k_by_mean_auc"])
        record = {
            "class_name": class_name,
            "best_layer": int(best["layer"]),
            "best_mean_auc": float(best["best_mean_auc"]),
            "best_k": best_k,
            "plateau_k": int(best["plateau_k_min"]) if math.isfinite(best["plateau_k_min"]) else None,
            "principal_sigma_mean_at_bestk": float(best[f"principal_sigma_mean_k{best_k}_mean"]),
            "principal_sigma_min_at_bestk": float(best[f"principal_sigma_min_k{best_k}_mean"]),
            "num_anom_imgs": int(best["num_anomaly_images"]),
            "num_anom_patches": int(best["num_anomaly_patches"]),
        }
        if record["best_mean_auc"] >= 0.9 and record["principal_sigma_mean_at_bestk"] >= 0.7:
            record["group"] = "strong"
        elif record["best_mean_auc"] < 0.75 or record["principal_sigma_mean_at_bestk"] < 0.55:
            record["group"] = "weak"
        else:
            record["group"] = "mid"
        best_records.append(record)
    best_records.sort(key=lambda r: r["best_mean_auc"], reverse=True)
    return best_records


def save_best_summary(best_records: list[dict], out_dir: Path) -> None:
    out_path = out_dir / "class_best_summary.csv"
    with out_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(best_records[0].keys()))
        writer.writeheader()
        writer.writerows(best_records)


def plot_scatter(best_records: list[dict], out_dir: Path) -> None:
    colors = {"strong": "#1b9e77", "mid": "#7570b3", "weak": "#d95f02"}
    fig, ax = plt.subplots(figsize=(8, 6))
    for group in ["strong", "mid", "weak"]:
        pts = [r for r in best_records if r["group"] == group]
        if not pts:
            continue
        x = [r["principal_sigma_mean_at_bestk"] for r in pts]
        y = [r["best_mean_auc"] for r in pts]
        s = [max(40, min(240, r["num_anom_patches"] * 0.5)) for r in pts]
        ax.scatter(x, y, s=s, c=colors[group], label=group, alpha=0.85, edgecolors="black", linewidths=0.5)
        for r in pts:
            ax.text(r["principal_sigma_mean_at_bestk"] + 0.005, r["best_mean_auc"] + 0.003, r["class_name"], fontsize=8)
    ax.axhline(0.9, color="gray", linestyle="--", linewidth=1)
    ax.axvline(0.7, color="gray", linestyle="--", linewidth=1)
    ax.set_xlabel("Principal Sigma Mean at Best k")
    ax.set_ylabel("Best Out-of-Sample AUC")
    ax.set_title("Class-Level Defect Subspace Stability vs Generalization")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "scatter_best_auc_vs_sigma.png", dpi=200)
    plt.close(fig)


def plot_heatmap(rows: list[dict], best_records: list[dict], out_dir: Path) -> None:
    classes = [r["class_name"] for r in best_records]
    layers = sorted({int(r["layer"]) for r in rows})
    mat = np.full((len(classes), len(layers)), np.nan, dtype=np.float64)
    for i, cls in enumerate(classes):
        class_rows = [r for r in rows if r["class_name"] == cls]
        for j, layer in enumerate(layers):
            row = next(r for r in class_rows if int(r["layer"]) == layer)
            mat[i, j] = float(row["best_mean_auc"])
    fig, ax = plt.subplots(figsize=(7, max(5, 0.45 * len(classes))))
    im = ax.imshow(mat, aspect="auto", cmap="viridis", vmin=0.35, vmax=0.95)
    ax.set_xticks(range(len(layers)))
    ax.set_xticklabels([f"L{l}" for l in layers])
    ax.set_yticks(range(len(classes)))
    ax.set_yticklabels(classes)
    ax.set_title("Best Split-AUC per Layer")
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            ax.text(j, i, f"{mat[i,j]:.2f}", ha="center", va="center", color="white", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(out_dir / "heatmap_best_auc_by_class_layer.png", dpi=200)
    plt.close(fig)


def plot_selected_curves(rows: list[dict], best_records: list[dict], out_dir: Path, top_n: int) -> None:
    strong = [r["class_name"] for r in best_records if r["group"] == "strong"][:top_n]
    weak = [r["class_name"] for r in best_records if r["group"] == "weak"][:top_n]
    selected = strong + weak
    if not selected:
        return

    auc_fig, auc_axes = plt.subplots(len(selected), 1, figsize=(8, 3.2 * len(selected)), squeeze=False)
    sig_fig, sig_axes = plt.subplots(len(selected), 1, figsize=(8, 3.2 * len(selected)), squeeze=False)

    for idx, cls in enumerate(selected):
        best = next(r for r in best_records if r["class_name"] == cls)
        row = next(r for r in rows if r["class_name"] == cls and int(r["layer"]) == int(best["best_layer"]))
        ks = []
        aucs = []
        sig_means = []
        sig_mins = []
        for k in range(1, int(row["max_k"]) + 1):
            ks.append(k)
            aucs.append(float(row[f"auc_k{k}_mean"]))
            sig_means.append(float(row[f"principal_sigma_mean_k{k}_mean"]))
            sig_mins.append(float(row[f"principal_sigma_min_k{k}_mean"]))

        ax = auc_axes[idx, 0]
        ax.plot(ks, aucs, marker="o", color="#1f77b4")
        ax.axvline(int(best["best_k"]), color="gray", linestyle="--", linewidth=1)
        ax.set_ylim(0.35, 0.98)
        ax.set_ylabel("AUC")
        ax.set_title(f"{cls} | best layer L{int(best['best_layer'])} | group={best['group']}")
        ax.grid(alpha=0.25)

        ax2 = sig_axes[idx, 0]
        ax2.plot(ks, sig_means, marker="o", color="#2ca02c", label="sigma mean")
        ax2.plot(ks, sig_mins, marker="s", color="#d62728", label="sigma min")
        ax2.axvline(int(best["best_k"]), color="gray", linestyle="--", linewidth=1)
        ax2.set_ylim(0.0, 1.02)
        ax2.set_ylabel("Principal Sigma")
        ax2.set_title(f"{cls} | best layer L{int(best['best_layer'])}")
        ax2.grid(alpha=0.25)
        ax2.legend(frameon=False, loc="lower right")

    auc_axes[-1, 0].set_xlabel("k")
    sig_axes[-1, 0].set_xlabel("k")
    auc_fig.tight_layout()
    sig_fig.tight_layout()
    auc_fig.savefig(out_dir / "selected_auc_curves.png", dpi=200)
    sig_fig.savefig(out_dir / "selected_sigma_curves.png", dpi=200)
    plt.close(auc_fig)
    plt.close(sig_fig)


def main() -> None:
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = load_rows(args.summary_csv)
    best_records = get_best_records(rows)
    save_best_summary(best_records, out_dir)
    plot_scatter(best_records, out_dir)
    plot_heatmap(rows, best_records, out_dir)
    plot_selected_curves(rows, best_records, out_dir, args.top_n)
    print(out_dir)


if __name__ == "__main__":
    main()
