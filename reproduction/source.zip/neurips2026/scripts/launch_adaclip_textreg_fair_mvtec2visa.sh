#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"
GPU_ID="${1:-0}"

export ADACLIP_MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
export ADACLIP_VISA_ROOT="/mnt/data/gijeong/MMAD_new/VisA"

SAVE_ROOT="${ROOT}/neurips2026/results/adaclip_textreg_fair_mvtec2visa"
TEST_ROOT="${ROOT}/neurips2026/results/adaclip_textreg_fair_mvtec2visa_eval"

mkdir -p "${SAVE_ROOT}" "${TEST_ROOT}"

cd "${ROOT}/neurips2026/AdaCLIP"

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" train.py \
  --training_data mvtec \
  --testing_data visa \
  --save_path "${SAVE_ROOT}" \
  --model ViT-L-14-336 \
  --epoch 5 \
  --learning_rate 0.01 \
  --batch_size 1 \
  --image_size 518 \
  --print_freq 1 \
  --valid_freq 1 \
  --prompting_depth 4 \
  --prompting_length 5 \
  --prompting_type SD \
  --prompting_branch VL \
  --use_hsf True \
  --k_clusters 20 \
  --target_val_during_train False \
  --save_last_ckpt True \
  --text_leakage_reg True \
  --text_ortho_weight 0.01 \
  --text_anchor_weight 0.05

CKPT_PATH="$(find "${SAVE_ROOT}/models" -maxdepth 1 -name '*_last.pth' | sort | tail -n 1)"
if [[ -z "${CKPT_PATH}" ]]; then
  echo "Failed to locate final checkpoint under ${SAVE_ROOT}/models" >&2
  exit 1
fi

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" test.py \
  --testing_model dataset \
  --testing_data visa \
  --ckt_path "${CKPT_PATH}" \
  --save_path "${TEST_ROOT}" \
  --model ViT-L-14-336 \
  --batch_size 1 \
  --image_size 518 \
  --prompting_depth 4 \
  --prompting_length 5 \
  --prompting_type SD \
  --prompting_branch VL \
  --use_hsf True \
  --k_clusters 20
