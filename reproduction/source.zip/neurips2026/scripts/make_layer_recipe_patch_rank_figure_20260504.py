#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
CASE_DIR = ROOT / "neurips2026" / "results" / "layer_recipe_entanglement_heatmap_20260503"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")

HEATMAP_SCRIPT = ROOT / "neurips2026/scripts/make_layer_recipe_entanglement_heatmap_20260503.py"

RECIPES = ["Full", "EL", "L2", "L"]
BASE_AUC = np.array([58.12, 60.18, 57.51, 57.92])
CTED_AUC = np.array([60.59, 61.96, 59.66, 60.12])

C_DEFECT = "#D64A2F"
C_FP = "#1B5E8A"
C_BASE = "#8C939B"
C_CTED = "#1B5E8A"
GRID = "#D7DADF"


def load_case() -> dict:
    path = CASE_DIR / "selected_case.json"
    if not path.exists():
        raise FileNotFoundError(f"Run {HEATMAP_SCRIPT} first")
    return json.loads(path.read_text(encoding="utf-8"))


def crop_square(arr: np.ndarray, x: int, y: int, size: int = 92) -> np.ndarray:
    h, w = arr.shape[:2]
    half = size // 2
    x0 = max(0, min(w - size, x - half))
    y0 = max(0, min(h - size, y - half))
    return arr[y0 : y0 + size, x0 : x0 + size]


def add_panel_label(ax, label: str) -> None:
    ax.text(
        0.0,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=10.2,
        fontweight="bold",
        color="#222222",
    )


def draw_case(ax_img, ax_def, ax_fp, case: dict) -> None:
    img_path = MVTEC_ROOT / case["case"]["img_path"]
    img = Image.open(img_path).convert("RGB").resize((518, 518), Image.BICUBIC)
    arr = np.asarray(img)
    dx, dy = case["case"]["defect"]
    hx, hy = case["case"]["hard_fp"]
    ax_img.imshow(arr)
    for (x, y, color, label) in [(dx, dy, C_DEFECT, "D"), (hx, hy, C_FP, "H")]:
        rect = plt.Rectangle((x - 24, y - 24), 48, 48, fill=False, ec=color, lw=2.2)
        ax_img.add_patch(rect)
        ax_img.text(
            x - 22,
            y - 29,
            label,
            fontsize=8.4,
            fontweight="bold",
            color="white",
            bbox=dict(boxstyle="round,pad=0.12", fc=color, ec="none", alpha=0.95),
        )
    ax_img.set_xticks([])
    ax_img.set_yticks([])
    for spine in ax_img.spines.values():
        spine.set_linewidth(0.8)
        spine.set_edgecolor("#333333")

    for ax, crop, color, title in [
        (ax_def, crop_square(arr, dx, dy), C_DEFECT, "defect"),
        (ax_fp, crop_square(arr, hx, hy), C_FP, "hard-FP"),
    ]:
        ax.imshow(crop)
        ax.text(
            0.04,
            0.08,
            title,
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=7.0,
            fontweight="bold",
            color="white",
            bbox=dict(boxstyle="round,pad=0.12", fc=color, ec="none", alpha=0.9),
        )
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_linewidth(2.0)
            spine.set_edgecolor(color)


def draw_patch_gap(
    ax,
    b_gap: np.ndarray,
    c_gap: np.ndarray,
    *,
    show_title: bool = True,
    show_legend: bool = False,
) -> None:
    b_gap = 100.0 * b_gap
    c_gap = 100.0 * c_gap
    y = np.arange(len(RECIPES))[::-1]
    if show_title:
        ax.set_title("(b) patch-rank margin", fontweight="bold", pad=3)
    for i, recipe in enumerate(RECIPES):
        yi = y[i]
        ax.plot([b_gap[i], c_gap[i]], [yi, yi], color=C_CTED, lw=2.4, alpha=0.72)
        ax.scatter(b_gap[i], yi, s=42, color=C_BASE, edgecolor="white", linewidth=0.7, zorder=3)
        ax.scatter(c_gap[i], yi, s=46, color=C_CTED, edgecolor="white", linewidth=0.7, zorder=4)
        ax.text(
            c_gap[i] + 0.45,
            yi,
            f"+{(c_gap[i] - b_gap[i]):.1f}",
            ha="left",
            va="center",
            fontsize=8.2,
            fontweight="bold",
            color=C_CTED,
        )
    ax.set_yticks(y)
    ax.set_yticklabels(RECIPES, fontweight="bold")
    ax.set_xlabel("")
    ax.set_xlim(0.0, 14.5)
    ax.set_ylim(-0.55, len(RECIPES) - 0.45)
    ax.grid(axis="x", color=GRID, lw=0.75, alpha=0.9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if show_legend:
        ax.scatter([], [], s=42, color=C_BASE, edgecolor="white", linewidth=0.7, label="B")
        ax.scatter([], [], s=46, color=C_CTED, edgecolor="white", linewidth=0.7, label="C-TED")
        ax.legend(
            frameon=False,
            loc="upper right",
            fontsize=8.2,
            handletextpad=0.35,
            borderpad=0.1,
            labelspacing=0.25,
        )


def draw_auc_summary(ax, *, show_title: bool = True) -> None:
    x = np.arange(len(RECIPES))
    ax.plot(x, BASE_AUC, color=C_BASE, marker="o", lw=2.0, ms=5.2, label="B")
    ax.plot(x, CTED_AUC, color=C_CTED, marker="o", lw=2.4, ms=5.2, label="C-TED")
    for xi, b, c in zip(x, BASE_AUC, CTED_AUC):
        ax.plot([xi, xi], [b, c], color=C_CTED, lw=1.2, alpha=0.33)
    if show_title:
        ax.set_title("(c) aggregate", fontweight="bold", pad=3)
    ax.set_xticks(x)
    ax.set_xticklabels(RECIPES, fontweight="bold")
    ax.set_ylabel("D vs H-FP AUC")
    ax.set_ylim(55.5, 62.8)
    ax.grid(axis="y", color=GRID, lw=0.75, alpha=0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, loc="lower right", fontsize=8.0, handlelength=1.1, borderpad=0.1)


def save_split_panels(case: dict, b_gap: np.ndarray, c_gap: np.ndarray) -> None:
    split_specs = []

    fig = plt.figure(figsize=(2.42, 1.56))
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1.25, 0.76, 0.76], wspace=0.05)
    draw_case(fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[0, 2]), case)
    fig.subplots_adjust(left=0.01, right=0.99, bottom=0.02, top=0.98)
    split_specs.append((fig, "layer_recipe_patch_rank_traced_patches_20260504"))

    fig = plt.figure(figsize=(3.22, 1.56))
    ax = fig.add_subplot(111)
    draw_patch_gap(ax, b_gap, c_gap, show_title=False, show_legend=True)
    fig.subplots_adjust(left=0.12, right=0.98, bottom=0.18, top=0.97)
    split_specs.append((fig, "layer_recipe_patch_rank_patch_margin_20260504"))

    fig = plt.figure(figsize=(2.36, 1.56))
    ax = fig.add_subplot(111)
    draw_auc_summary(ax, show_title=False)
    fig.subplots_adjust(left=0.20, right=0.98, bottom=0.18, top=0.97)
    split_specs.append((fig, "layer_recipe_patch_rank_aggregate_auc_20260504"))

    for fig, stem in split_specs:
        pdf = FIG_DIR / f"{stem}.pdf"
        png = FIG_DIR / f"{stem}.png"
        fig.savefig(pdf)
        fig.savefig(png, dpi=300)
        plt.close(fig)
        print(pdf)
        print(png)


def main() -> int:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    case = load_case()
    b_gap = np.asarray(case["patch_percentile_gaps"]["B"], dtype=np.float32)
    c_gap = np.asarray(case["patch_percentile_gaps"]["C-TED"], dtype=np.float32)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8.8,
            "axes.titlesize": 10.0,
            "axes.labelsize": 8.8,
            "xtick.labelsize": 8.4,
            "ytick.labelsize": 8.4,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig = plt.figure(figsize=(7.25, 1.72))
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1.75, 2.15, 1.45], wspace=0.34)
    case_gs = gs[0, 0].subgridspec(1, 3, width_ratios=[1.25, 0.76, 0.76], wspace=0.05)
    ax_img = fig.add_subplot(case_gs[0, 0])
    ax_def = fig.add_subplot(case_gs[0, 1])
    ax_fp = fig.add_subplot(case_gs[0, 2])
    ax_rank = fig.add_subplot(gs[0, 1])
    ax_auc = fig.add_subplot(gs[0, 2])

    draw_case(ax_img, ax_def, ax_fp, case)
    add_panel_label(ax_img, "(a) traced patches")
    draw_patch_gap(ax_rank, b_gap, c_gap)
    draw_auc_summary(ax_auc)

    fig.subplots_adjust(left=0.015, right=0.988, bottom=0.16, top=0.82, wspace=0.34)
    pdf = FIG_DIR / "layer_recipe_patch_rank_20260504.pdf"
    png = FIG_DIR / "layer_recipe_patch_rank_20260504.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    plt.close(fig)

    save_split_panels(case, b_gap, c_gap)

    tex = OUT_DIR / "layer_recipe_patch_rank_20260504.tex"
    tex.write_text(
        r"""\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{figure/layer_recipe_patch_rank_20260504.pdf}
\caption{
Patch-level evidence competition under recipe-consistent retraining.
The same defect and hard-FP patches are traced across retrained layer recipes.
C-TED increases the defect-versus-hard-FP patch-rank margin, reported in percentile points, and improves aggregate defect-versus-hard-FP separation.
This indicates that recipe search changes the host response but does not remove the evidence-decoding problem.
}
\label{fig:layer_recipe_patch_rank}
\end{figure*}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
