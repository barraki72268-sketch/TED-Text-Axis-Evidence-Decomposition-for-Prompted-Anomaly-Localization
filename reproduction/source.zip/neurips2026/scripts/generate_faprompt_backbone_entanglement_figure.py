#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from sklearn.metrics import roc_auc_score


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT_DIR = RESULTS / "faprompt_backbone_entanglement_figure"
LEGACY_SCORE_NPZ = RESULTS / "candidate_score_arrays_faprompt_visa2mvtec_cable_v1" / "scores_cable.npz"
TRACE_DIR = RESULTS / "faprompt_patch_trace_visa2mvtec_cable_vitb_v1"
TRACE_SCORE_NPZ = TRACE_DIR / "scores_with_trace.npz"
TRACE_PAIR_JSON = TRACE_DIR / "selected_pair.json"
C_DEFECT = "#D64A2F"
C_HARD = "#2878A7"
C_OURS = "#1B8A6B"
C_GRAY = "#B8B8B8"
C_DARK = "#222222"


def load_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def best_prescore(mean: dict, metric: str = "pixel_auc") -> tuple[str, dict]:
    candidates = {k: v for k, v in mean["parallel"].items() if k.startswith("prescore_rectify")}
    key = max(candidates, key=lambda k: candidates[k][metric])
    return key, candidates[key]


def hist_overlap(pos: np.ndarray, neg: np.ndarray, bins: int = 64) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    lo = float(min(pos.min(), neg.min()))
    hi = float(max(pos.max(), neg.max()))
    if hi <= lo:
        hi = lo + 1e-6
    edges = np.linspace(lo, hi, bins + 1)
    hp, _ = np.histogram(pos, bins=edges, density=True)
    hn, _ = np.histogram(neg, bins=edges, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    ov = np.minimum(hp, hn)
    return centers, hp, hn, float(np.sum(ov * np.diff(edges)))


def smooth(y: np.ndarray, sigma: float = 1.5, radius: int = 6) -> np.ndarray:
    x = np.arange(-radius, radius + 1, dtype=np.float32)
    k = np.exp(-(x * x) / (2.0 * sigma * sigma))
    k /= k.sum()
    return np.convolve(y, k, mode="same")


def auc_pos_vs_neg(pos: np.ndarray, neg: np.ndarray) -> float:
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def resolve_path(path: str | Path) -> Path:
    path = Path(path)
    if path.is_absolute():
        return path
    return ROOT / path


def pairwise_rescue_stats(base_pos: np.ndarray, base_neg: np.ndarray, ours_pos: np.ndarray, ours_neg: np.ndarray) -> dict:
    base_correct = base_pos[:, None] > base_neg[None, :]
    ours_correct = ours_pos[:, None] > ours_neg[None, :]
    rescued = (~base_correct) & ours_correct
    damaged = base_correct & (~ours_correct)

    lo = max(float(np.quantile(base_pos, 0.25)), float(np.quantile(base_neg, 0.25)))
    hi = min(float(np.quantile(base_pos, 0.75)), float(np.quantile(base_neg, 0.75)))
    band = (
        (base_pos[:, None] >= lo)
        & (base_pos[:, None] <= hi)
        & (base_neg[None, :] >= lo)
        & (base_neg[None, :] <= hi)
    )
    if not np.any(band):
        band = np.ones_like(base_correct, dtype=bool)

    return {
        "n_defect": int(base_pos.shape[0]),
        "n_hard_normal": int(base_neg.shape[0]),
        "baseline_pair_auc": float(base_correct.mean()),
        "ours_pair_auc": float(ours_correct.mean()),
        "rescued_wrong_pairs": float(rescued.mean()),
        "damaged_correct_pairs": float(damaged.mean()),
        "net_pair_gain": float(rescued.mean() - damaged.mean()),
        "overlap_band_low": lo,
        "overlap_band_high": hi,
        "overlap_band_pair_fraction": float(band.mean()),
        "overlap_band_baseline_pair_auc": float(base_correct[band].mean()),
        "overlap_band_ours_pair_auc": float(ours_correct[band].mean()),
        "overlap_band_rescued": float(rescued[band].mean()),
        "overlap_band_damaged": float(damaged[band].mean()),
        "overlap_band_net_gain": float(rescued[band].mean() - damaged[band].mean()),
    }


def draw_hist(
    ax,
    pos: np.ndarray,
    neg: np.ndarray,
    title: str,
    xlab: str,
    show_legend: bool = False,
    inline_legend: bool = False,
    selected: dict | None = None,
) -> dict:
    centers, hp, hn, ovl = hist_overlap(pos, neg)
    hp = smooth(hp)
    hn = smooth(hn)
    ov = np.minimum(hp, hn)
    dx = centers[1] - centers[0] if len(centers) > 1 else 1.0
    ovl = float(np.sum(ov) * dx)
    auc = auc_pos_vs_neg(pos, neg)
    gap = float(np.median(pos) - np.median(neg))
    hard_above = float((neg > np.median(pos)).mean())

    ax.fill_between(centers, hp, color=C_DEFECT, alpha=0.32)
    ax.fill_between(centers, hn, color=C_HARD, alpha=0.28)
    ax.plot(centers, hp, color=C_DEFECT, lw=3.2, ls="--", label="defect")
    ax.plot(centers, hn, color=C_HARD, lw=3.2, ls="-", label="hard normal")
    ax.fill_between(centers, ov, color="#5B5B5B", alpha=0.16, hatch="///", edgecolor="#5B5B5B", linewidth=0.0)
    ax.axvline(float(np.median(pos)), color=C_DEFECT, lw=2.2, ls="--", alpha=0.95)
    ax.axvline(float(np.median(neg)), color=C_HARD, lw=2.2, ls="--", alpha=0.95)
    if selected is not None:
        y_marker = 0.06 * max(float(hp.max()), float(hn.max()), 1e-6)
        ax.scatter(
            [selected["defect"], selected["hard_normal"]],
            [y_marker, y_marker],
            s=95,
            marker="^",
            color=[C_DEFECT, C_HARD],
            edgecolor="white",
            linewidth=1.1,
            zorder=10,
        )
    ax.set_title(title, fontsize=18, fontweight="bold", pad=12)
    ax.set_xlabel(xlab, fontsize=13, fontweight="bold", labelpad=8)
    ax.set_ylabel("Density", fontsize=13, fontweight="bold", labelpad=7)
    ax.tick_params(axis="both", labelsize=11, width=1.3)
    ax.grid(alpha=0.14)
    ax.text(
        0.04,
        0.94,
        f"AUC {auc:.3f}\nOverlap {ovl:.3f}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold",
        linespacing=1.2,
        bbox={"facecolor": "white", "edgecolor": "#DDDDDD", "alpha": 0.90, "pad": 4},
    )
    if show_legend:
        ax.legend(frameon=False, fontsize=12, loc="upper right", handlelength=2.8)
    if inline_legend:
        x0, x1 = 0.68, 0.76
        y_def, y_hard = 0.86, 0.785
        ax.plot([x0, x1], [y_def, y_def], transform=ax.transAxes, color=C_DEFECT, lw=3.0, ls="--", clip_on=False)
        ax.text(0.785, y_def, "defect", transform=ax.transAxes, ha="left", va="center", fontsize=11, fontweight="bold")
        ax.plot([x0, x1], [y_hard, y_hard], transform=ax.transAxes, color=C_HARD, lw=3.0, ls="-", clip_on=False)
        ax.text(0.785, y_hard, "hard normal", transform=ax.transAxes, ha="left", va="center", fontsize=11, fontweight="bold")
    return {"auc": auc, "overlap": ovl, "median_gap": gap, "hardfp_above_defect_median": hard_above}


def draw_metric_panel(ax, official_base: dict, swapped_base: dict, swapped_ours: dict) -> None:
    metrics = [
        ("P-AUROC", "pixel_auc"),
        ("P-PRO", "pixel_aupro"),
        ("P-AP", "pixel_ap"),
    ]
    x = np.arange(len(metrics))
    width = 0.25
    official_vals = [official_base[k] * 100.0 for _, k in metrics]
    swap_vals = [swapped_base[k] * 100.0 for _, k in metrics]
    ours_vals = [swapped_ours[k] * 100.0 for _, k in metrics]
    ax.bar(x - width, official_vals, width, color=C_GRAY, label="official ViT-L")
    ax.bar(x, swap_vals, width, color=C_HARD, label="swapped ViT-B")
    ax.bar(x + width, ours_vals, width, color=C_DEFECT, label="swapped + OURS")
    for vals, dx in [(official_vals, -width), (swap_vals, 0.0), (ours_vals, width)]:
        for xi, yi in zip(x, vals):
            ax.text(xi + dx, yi + 1.4, f"{yi:.1f}", ha="center", va="bottom", fontsize=11, fontweight="bold")
    ax.set_xticks(x, [m[0] for m in metrics], fontsize=12, fontweight="bold")
    ax.set_ylim(0, 103)
    ax.set_ylabel("Score (%)", fontsize=13, fontweight="bold")
    ax.set_title("Backbone Stress", fontsize=18, fontweight="bold", pad=12)
    ax.tick_params(axis="y", labelsize=11, width=1.3)
    ax.grid(axis="y", alpha=0.14)
    ax.legend(frameon=False, fontsize=10, loc="upper right")


def draw_pairwise_panel(ax, stats: dict) -> None:
    vals = np.array(
        [
            stats["rescued_wrong_pairs"] * 100.0,
            stats["damaged_correct_pairs"] * 100.0,
            stats["net_pair_gain"] * 100.0,
        ],
        dtype=np.float32,
    )
    labels = ["rescued", "damaged", "net gain"]
    colors = [C_OURS, "#7A7A7A", C_DEFECT]
    x = np.arange(len(vals))
    ax.bar(x, vals, color=colors, width=0.66)
    for xi, yi in zip(x, vals):
        ax.text(xi, yi + 1.1, f"+{yi:.1f} pp" if xi == 2 else f"{yi:.1f}%", ha="center", va="bottom", fontsize=14, fontweight="bold")
    ax.set_xticks(x, labels, fontsize=12, fontweight="bold")
    ax.set_ylim(0, max(42.0, float(vals.max()) + 6.0))
    ax.set_ylabel("Pair fraction (%)", fontsize=13, fontweight="bold")
    ax.set_title("Mis-ranked Pair Correction", fontsize=18, fontweight="bold", pad=12)
    ax.tick_params(axis="y", labelsize=11, width=1.3)
    ax.grid(axis="y", alpha=0.14)


def draw_trace_panel(ax, trace: dict | None) -> None:
    ax.axis("off")
    ax.set_title("Traced Patch Pair", fontsize=18, fontweight="bold", pad=12)
    if trace is None:
        ax.text(0.5, 0.5, "trace not collected", ha="center", va="center", fontsize=12, fontweight="bold")
        return

    rows = [
        ("defect", trace["selected"]["defect"], C_DEFECT),
        ("hard normal", trace["selected"]["hard_normal"], C_HARD),
    ]
    y0s = [0.54, 0.05]
    for (name, rec, color), y0 in zip(rows, y0s):
        full = np.asarray(Image.open(resolve_path(rec["full_box_path"])).convert("RGB"))
        crop = np.asarray(Image.open(resolve_path(rec["crop_path"])).convert("RGB"))
        ax_full = ax.inset_axes([0.02, y0 + 0.08, 0.42, 0.34])
        ax_crop = ax.inset_axes([0.47, y0 + 0.08, 0.24, 0.34])
        ax_full.imshow(full)
        ax_crop.imshow(crop)
        for child_ax in (ax_full, ax_crop):
            child_ax.set_xticks([])
            child_ax.set_yticks([])
            for spine in child_ax.spines.values():
                spine.set_linewidth(2.4)
                spine.set_edgecolor(color)
        ax.text(0.02, y0 + 0.44, name, transform=ax.transAxes, ha="left", va="bottom", fontsize=13, fontweight="bold", color=color)
        ax.text(
            0.74,
            y0 + 0.30,
            f"base {rec['baseline']:.3f}\nOURS {rec['fused']:.3f}\npatch ({rec['patch_row']},{rec['patch_col']})",
            transform=ax.transAxes,
            ha="left",
            va="center",
            fontsize=10.5,
            fontweight="bold",
            linespacing=1.25,
        )


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    official = load_json(RESULTS / "faprompt_official_vitl_prescore_hostaxis_visa2mvtec_full_v1" / "summary.json")
    swapped = load_json(RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2mvtec_full_v1" / "summary.json")
    best_key, swapped_ours = best_prescore(swapped["mean"], "pixel_auc")
    official_base = official["mean"]["baseline_official"]
    swapped_base = swapped["mean"]["baseline_official"]

    score_path = TRACE_SCORE_NPZ if TRACE_SCORE_NPZ.exists() else LEGACY_SCORE_NPZ
    trace = load_json(TRACE_PAIR_JSON) if TRACE_PAIR_JSON.exists() else None
    score_npz = np.load(score_path)
    labels = score_npz["labels"].astype(np.int64)
    baseline = score_npz["baseline"].astype(np.float32)
    residual = score_npz["residual"].astype(np.float32)
    fused = score_npz["fused"].astype(np.float32)

    base_pos = baseline[labels == 1]
    base_neg = baseline[labels == 0]
    ours_pos = fused[labels == 1]
    ours_neg = fused[labels == 0]
    pair_stats = pairwise_rescue_stats(base_pos, base_neg, ours_pos, ours_neg)

    plt.rcParams.update(
        {
            "axes.linewidth": 1.4,
            "font.family": "DejaVu Sans",
        }
    )
    fig = plt.figure(figsize=(19.2, 5.0), constrained_layout=False)
    gs = fig.add_gridspec(1, 4, width_ratios=[1.03, 1.35, 1.12, 1.35])
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax4 = fig.add_subplot(gs[0, 2])
    ax3 = fig.add_subplot(gs[0, 3])

    draw_metric_panel(ax0, official_base, swapped_base, swapped_ours)

    base_stats = draw_hist(
        ax1,
        base_pos,
        base_neg,
        "Baseline Entanglement",
        "FAPrompt patch anomaly score",
        show_legend=False,
        inline_legend=True,
        selected=(
            {
                "defect": trace["selected"]["defect"]["baseline"],
                "hard_normal": trace["selected"]["hard_normal"]["baseline"],
            }
            if trace is not None
            else None
        ),
    )
    ours_stats = draw_hist(
        ax3,
        ours_pos,
        ours_neg,
        "OURS Support Separation",
        "corrected support score",
        show_legend=False,
        selected=(
            {
                "defect": trace["selected"]["defect"]["fused"],
                "hard_normal": trace["selected"]["hard_normal"]["fused"],
            }
            if trace is not None
            else None
        ),
    )
    ax3.set_ylabel("")
    draw_trace_panel(ax4, trace)
    fig.subplots_adjust(left=0.038, right=0.992, top=0.86, bottom=0.20, wspace=0.34)

    payload = {
        "official_baseline": official_base,
        "swapped_baseline": swapped_base,
        "swapped_ours_key": best_key,
        "swapped_ours": swapped_ours,
        "candidate_source": str(score_path.relative_to(RESULTS)),
        "trace_source": str(TRACE_PAIR_JSON.relative_to(RESULTS)) if TRACE_PAIR_JSON.exists() else None,
        "baseline_hist": base_stats,
        "pairwise_rescue": pair_stats,
        "ours_hist": ours_stats,
    }
    (OUT_DIR / "faprompt_entangle_rescue_story.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    fig.savefig(OUT_DIR / "faprompt_entangle_rescue_story.png", dpi=260, bbox_inches="tight")
    fig.savefig(OUT_DIR / "faprompt_entangle_rescue_story.pdf", bbox_inches="tight")
    fig.savefig(OUT_DIR / "faprompt_backbone_entanglement.png", dpi=260, bbox_inches="tight")
    fig.savefig(OUT_DIR / "faprompt_backbone_entanglement.pdf", bbox_inches="tight")
    plt.close(fig)
    print(
        json.dumps(
            {
                "png": str(OUT_DIR / "faprompt_entangle_rescue_story.png"),
                "pdf": str(OUT_DIR / "faprompt_entangle_rescue_story.pdf"),
                "legacy_png": str(OUT_DIR / "faprompt_backbone_entanglement.png"),
                "legacy_pdf": str(OUT_DIR / "faprompt_backbone_entanglement.pdf"),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
