from __future__ import annotations

import argparse
import sys
from pathlib import Path


REPO_ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
BAYES_ROOT = REPO_ROOT / "neurips2026" / "Bayes-PFL"
if str(BAYES_ROOT / "dataset") not in sys.path:
    sys.path.insert(0, str(BAYES_ROOT / "dataset"))

from datasets.MVTec import Mvtec_dataset  # noqa: E402
from make_meta import metaSolver  # noqa: E402
import cv2  # noqa: E402


def prepare_mvtec(src_root: Path, dst_root: Path) -> None:
    dataset = Mvtec_dataset(str(src_root))
    dataset.make_VAND(binary=True, to_255=True, des_path_root=str(dst_root), id=0)
    metaSolver(
        root=str(dst_root),
        meta_path=str(dst_root.parent / "meta_mvtec.json"),
        datasets="mvtec",
    ).run()


def prepare_visa(src_root: Path, dst_root: Path) -> None:
    cls_names = [
        "candle", "capsules", "cashew", "chewinggum", "fryum",
        "macaroni1", "macaroni2", "pcb1", "pcb2", "pcb3",
        "pcb4", "pipe_fryum",
    ]
    if dst_root.exists():
        import shutil
        shutil.rmtree(dst_root)
    for cls_name in cls_names:
        for rel in [
            ("train", "good"),
            ("test", "good"),
            ("test", "anomaly"),
            ("ground_truth", "anomaly"),
        ]:
            (dst_root / cls_name / rel[0] / rel[1]).mkdir(parents=True, exist_ok=True)

    idx = 0
    for cls_name in cls_names:
        src_cls = src_root / cls_name
        for img_path in sorted((src_cls / "train" / "good").glob("*.JPG")):
            stem = img_path.stem
            out_name = f"visa_{stem}_{idx:06d}.bmp"
            raw_img = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
            cv2.imwrite(str(dst_root / cls_name / "train" / "good" / out_name), raw_img)
            idx += 1

        for img_path in sorted((src_cls / "test" / "good").glob("*.JPG")):
            stem = img_path.stem
            out_name = f"visa_{stem}_{idx:06d}.bmp"
            raw_img = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
            cv2.imwrite(str(dst_root / cls_name / "test" / "good" / out_name), raw_img)
            idx += 1

        for img_path in sorted((src_cls / "test" / "bad").glob("*.JPG")):
            stem = img_path.stem
            out_img_name = f"visa_{stem}_{idx:06d}.bmp"
            out_mask_name = f"visa_{stem}_{idx:06d}.png"
            raw_img = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
            mask_path = src_cls / "ground_truth" / "bad" / f"{stem}.png"
            raw_mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
            raw_mask = (raw_mask > 0).astype("uint8") * 255
            cv2.imwrite(str(dst_root / cls_name / "test" / "anomaly" / out_img_name), raw_img)
            cv2.imwrite(str(dst_root / cls_name / "ground_truth" / "anomaly" / out_mask_name), raw_mask)
            idx += 1

    metaSolver(
        root=str(dst_root),
        meta_path=str(dst_root.parent / "meta_visa.json"),
        datasets="visa",
    ).run()


def main() -> None:
    parser = argparse.ArgumentParser("Prepare Bayes-PFL standardized mvtec/visa datasets")
    parser.add_argument(
        "--mvtec_src",
        type=str,
        default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
    )
    parser.add_argument(
        "--visa_src",
        type=str,
        default="/mnt/data/gijeong/MMAD_new/VisA",
    )
    parser.add_argument(
        "--dst_root",
        type=str,
        default=str(BAYES_ROOT / "dataset" / "mvisa" / "data"),
    )
    parser.add_argument(
        "--only",
        type=str,
        default="both",
        choices=["both", "mvtec", "visa"],
    )
    args = parser.parse_args()

    dst_root = Path(args.dst_root)
    dst_root.mkdir(parents=True, exist_ok=True)

    if args.only in {"both", "mvtec"}:
        prepare_mvtec(Path(args.mvtec_src), dst_root / "mvtec")
    if args.only in {"both", "visa"}:
        prepare_visa(Path(args.visa_src), dst_root / "visa")

    print(f"Prepared datasets under {dst_root}")


if __name__ == "__main__":
    main()
