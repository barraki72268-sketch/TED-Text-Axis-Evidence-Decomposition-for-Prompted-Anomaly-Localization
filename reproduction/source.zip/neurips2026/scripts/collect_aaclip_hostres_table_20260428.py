#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"

BACKBONES = {
    "vitbplus": "ViT-B/16+",
    "vitl_openai224": "ViT-L/14 OpenAI",
    "vitl336": "ViT-L/14-336",
    "vith14": "ViT-H/14",
}
PRESETS = {
    "mvtec2visa": "VisA",
    "mvtec2mpdd": "MPDD",
    "mvtec2btad": "BTAD",
}
METRICS = ["pixel_auc", "pixel_ap", "pixel_pro", "image_auc"]


def summary_path(tag: str, preset: str, seed: int) -> Path:
    return RESULTS / f"aaclip_hostres_official_{tag}_{preset}_seed{seed}_pro_20260428" / "summary.json"


def legacy_path(tag: str, preset: str, seed: int) -> Path | None:
    if tag == "vitbplus" and preset == "mvtec2btad" and seed == 0:
        path = RESULTS / "aaclip_vitbplus_l3-6-9-12_mvtec2btad_subspace_hostres_rank8_preserve1_pro_20260428" / "summary.json"
        return path
    return None


def load_metrics(tag: str, preset: str, seed: int) -> tuple[list[float], list[float]] | None:
    path = summary_path(tag, preset, seed)
    if not path.exists():
        alt = legacy_path(tag, preset, seed)
        if alt is not None and alt.exists():
            path = alt
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    base = data["mean"]["baseline"]
    cand = data["mean"]["candidates"]["prescore_calibrated_alpha_1"]
    return [float(base[m]) for m in METRICS], [float(cand[m]) for m in METRICS]


def mean_std(values: list[list[float]]) -> tuple[list[float], list[float]]:
    means = []
    stds = []
    for i in range(len(METRICS)):
        xs = [v[i] for v in values]
        means.append(statistics.mean(xs))
        stds.append(statistics.stdev(xs) if len(xs) > 1 else 0.0)
    return means, stds


def fmt(vals: list[float], stds: list[float] | None, show_std: bool) -> str:
    if show_std and stds is not None:
        return " / ".join(f"{v:.2f}\\scriptsize{{±{s:.2f}}}" for v, s in zip(vals, stds))
    return " / ".join(f"{v:.2f}" for v in vals)


def bold_better(base: list[float], ours: list[float], base_s: list[float] | None, ours_s: list[float] | None, show_std: bool) -> tuple[str, str]:
    base_parts = []
    ours_parts = []
    for i, (b, o) in enumerate(zip(base, ours)):
        bs = 0.0 if base_s is None else base_s[i]
        os = 0.0 if ours_s is None else ours_s[i]
        b_txt = f"{b:.2f}" + (f"\\scriptsize{{±{bs:.2f}}}" if show_std else "")
        o_txt = f"{o:.2f}" + (f"\\scriptsize{{±{os:.2f}}}" if show_std else "")
        if o > b:
            o_txt = f"\\textbf{{{o_txt}}}"
        elif b > o:
            b_txt = f"\\textbf{{{b_txt}}}"
        base_parts.append(b_txt)
        ours_parts.append(o_txt)
    return " / ".join(base_parts), " / ".join(ours_parts)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--show_std", action="store_true")
    args = ap.parse_args()
    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]

    missing = []
    rows = []
    for tag, label in BACKBONES.items():
        base_by_dataset = []
        ours_by_dataset = []
        for preset in PRESETS:
            seed_values = [load_metrics(tag, preset, seed) for seed in seeds]
            seed_values = [v for v in seed_values if v is not None]
            if not seed_values:
                missing.append((tag, preset))
                base_by_dataset.append(None)
                ours_by_dataset.append(None)
                continue
            bases, ourses = zip(*seed_values)
            base_m, base_s = mean_std(list(bases))
            ours_m, ours_s = mean_std(list(ourses))
            base_by_dataset.append((base_m, base_s))
            ours_by_dataset.append((ours_m, ours_s))
        rows.append((tag, label, base_by_dataset, ours_by_dataset))

    print("% Each cell reports P-AUROC / P-AP / P-PRO / I-AUROC.")
    print("\\begin{table*}[t]")
    print("\\centering")
    print("\\caption{AA-CLIP with host-anchored residual subspace correction under MVTec-source transfer.}")
    print("\\label{tab:aaclip_hostres_official}")
    print("\\resizebox{\\textwidth}{!}{")
    print("\\begin{tabular}{llcccccc}")
    print("\\toprule")
    print("& & \\multicolumn{2}{c}{VisA} & \\multicolumn{2}{c}{MPDD} & \\multicolumn{2}{c}{BTAD} \\\\")
    print("\\cmidrule(lr){3-4} \\cmidrule(lr){5-6} \\cmidrule(lr){7-8}")
    print("Host & Backbone & Base & OURS & Base & OURS & Base & OURS \\\\")
    print("\\midrule")
    print("\\multirow{4}{*}{AA-CLIP}")
    for ri, (_tag, label, base_cells, ours_cells) in enumerate(rows):
        parts = ["", label]
        for base_cell, ours_cell in zip(base_cells, ours_cells):
            if base_cell is None or ours_cell is None:
                parts.extend(["--.-- / --.-- / --.-- / --.--", "--.-- / --.-- / --.-- / --.--"])
            else:
                base_txt, ours_txt = bold_better(
                    base_cell[0],
                    ours_cell[0],
                    base_cell[1],
                    ours_cell[1],
                    show_std=args.show_std and len(seeds) > 1,
                )
                parts.extend([base_txt, ours_txt])
        print(" & ".join(parts) + " \\\\")
    print("\\bottomrule")
    print("\\end{tabular}")
    print("}")
    print("\\end{table*}")
    if missing:
        print("\n% Missing:")
        for tag, preset in missing:
            print(f"% - {tag} {preset}")


if __name__ == "__main__":
    main()
