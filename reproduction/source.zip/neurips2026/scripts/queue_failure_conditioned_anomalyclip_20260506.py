#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
PROBE = ROOT / "neurips2026" / "scripts" / "probe_anomalyclip_text_decomposition_score.py"
RESULTS = ROOT / "neurips2026" / "results" / "failure_conditioned_separability_anomalyclip_20260506"
LOGS = ROOT / "neurips2026" / "logs" / "failure_conditioned_separability_anomalyclip_20260506"
BANK = RESULTS / "bank_cache"

MVTEC_ROOT = ROOT.parent / "ijepa" / "data" / "mvtec"
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

MVTEC_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"

TRANSFERS = {
    "visa2mvtec": (VISA_ROOT, "visa", MVTEC_ROOT, "mvtec", VISA_CKPT),
    "mvtec2visa": (MVTEC_ROOT, "mvtec", VISA_ROOT, "visa", MVTEC_CKPT),
    "mvtec2mpdd": (MVTEC_ROOT, "mvtec", MPDD_ROOT, "mpdd", MVTEC_CKPT),
    "mvtec2btad": (MVTEC_ROOT, "mvtec", BTAD_ROOT, "btad", MVTEC_CKPT),
}

BACKBONES = {
    "vitl336": {
        "model_name_or_path": "ViT-L/14@336px",
        "image_size": "518",
        "dpam_layer": "20",
        "features": ["24"],
        "allow_prompt_projection": False,
    },
}


def csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_cmd(transfer: str, backbone: str, seed: int, device: str) -> tuple[list[str], Path, Path]:
    source_root, source_dataset, target_root, target_dataset, checkpoint = TRANSFERS[transfer]
    cfg = BACKBONES[backbone]
    save_dir = RESULTS / f"anomalyclip_{backbone}_{transfer}_seed{seed}"
    bank_path = BANK / f"anomalyclip_{backbone}_{transfer}_last_withscores.pt"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        str(PROBE.relative_to(ROOT)),
        "--device",
        device,
        "--checkpoint_path",
        str(checkpoint),
        "--model_name_or_path",
        cfg["model_name_or_path"],
        "--heldout_class",
        "none",
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--target_mode",
        "test",
        "--baseline_features_list",
        *cfg["features"],
        "--features_list",
        *cfg["features"],
        "--dpam_layer",
        cfg["dpam_layer"],
        "--image_size",
        cfg["image_size"],
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--ted_margin_sign",
        "fp_minus_def",
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(bank_path),
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "40",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.2",
        "--calib_lambda",
        "0.03",
        "--calib_map_anchor",
        "trainfree",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "0.2",
        "--calibrated_image_fusion_weight",
        "0.02",
        "--aupro_max_step",
        "200",
        "--save_dir",
        str(save_dir),
    ]
    if cfg["allow_prompt_projection"]:
        cmd.extend(["--allow_prompt_projection", "--prompt_projection_ridge", "1e-3"])
    return cmd, save_dir, log_path


def worker_script(jobs: list[tuple[list[str], Path, Path]], worker_id: int) -> Path:
    path = LOGS / f"anomalyclip_worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        "jobs = [",
    ]
    for cmd, save_dir, log_path in jobs:
        lines.append(f"    ({cmd!r}, {str(save_dir)!r}, {str(log_path)!r}),")
    lines += [
        "]",
        "for cmd, save_dir, log_path in jobs:",
        "    summary = Path(save_dir) / 'summary.json'",
        "    Path(log_path).parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists():",
        "        print({'stage': 'skip', 'summary': str(summary)}, flush=True)",
        "        continue",
        "    print({'stage': 'run', 'save_dir': save_dir, 'log': log_path}, flush=True)",
        "    with open(log_path, 'w') as f:",
        "        subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, check=False)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    path.write_text("\n".join(lines))
    return path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--transfers", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--backbones", default="vitl336")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    args = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    BANK.mkdir(parents=True, exist_ok=True)
    transfers = csv(args.transfers)
    backbones = csv(args.backbones)
    seeds = [int(x) for x in csv(args.seeds)]
    devices = csv(args.devices)

    all_jobs: list[tuple[list[str], Path, Path]] = []
    for seed in seeds:
        for backbone in backbones:
            if backbone not in BACKBONES:
                raise SystemExit(f"Unknown backbone={backbone}; allowed={sorted(BACKBONES)}")
            for transfer in transfers:
                if transfer not in TRANSFERS:
                    raise SystemExit(f"Unknown transfer={transfer}; allowed={sorted(TRANSFERS)}")
                device = devices[len(all_jobs) % len(devices)]
                all_jobs.append(build_cmd(transfer, backbone, seed, device))

    buckets = [[] for _ in devices]
    for idx, job in enumerate(all_jobs):
        buckets[idx % len(devices)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        script = worker_script(bucket, worker_id)
        log = LOGS / f"anomalyclip_worker_{worker_id}.log"
        with log.open("a") as f:
            proc = subprocess.Popen([str(PY), str(script)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "log": str(log), "script": str(script)})
    print(json.dumps({"stage": "queued_failure_conditioned_anomalyclip", "launched": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
