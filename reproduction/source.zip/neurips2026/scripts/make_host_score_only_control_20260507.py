#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results" / "host_score_only_control_20260507"
OUT_DIR = ROOT / "supp_fig"
CSV_OUT = OUT_DIR / "host_score_only_control_20260507.csv"
TEX_OUT = OUT_DIR / "host_score_only_control_20260507.tex"


def pct(x: float) -> float:
    return 100.0 * x if abs(x) <= 1.5 else x


def fmt(x: float) -> str:
    if math.isnan(x):
        return "--"
    return f"{x:+.1f}"


def best_key(candidates: dict, prefixes: tuple[str, ...]) -> str | None:
    keys = [k for k in candidates if any(k.startswith(prefix) for prefix in prefixes)]
    return sorted(keys)[0] if keys else None


def triplet(blob: dict, pro_key: str) -> tuple[float, float, float]:
    return (
        pct(float(blob.get("pixel_auc", float("nan")))),
        pct(float(blob.get(pro_key, blob.get("pixel_aupro", float("nan"))))),
        pct(float(blob.get("pixel_ap", float("nan")))),
    )


def parse_summary(path: Path) -> dict | None:
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError:
        return None
    name = path.parent.name
    if name.startswith("faprompt_"):
        host = "FAPrompt"
        mean = data.get("mean", {})
        base_blob = mean.get("baseline_official")
        candidates = mean.get("parallel", {})
        pro_key = "pixel_aupro"
        replace_key = best_key(candidates, ("plugin_replace_alpha_",))
        residual_key = best_key(candidates, ("plugin_residual_alpha_",))
        cted_key = best_key(candidates, ("branch_calibrated_alpha_",))
    elif name.startswith("aaclip_"):
        host = "AA-CLIP"
        mean = data.get("mean", {})
        base_blob = mean.get("baseline")
        candidates = mean.get("candidates", {})
        pro_key = "pixel_pro"
        replace_key = best_key(candidates, ("plugin_replace_alpha_",))
        residual_key = best_key(candidates, ("plugin_residual_alpha_",))
        cted_key = best_key(candidates, ("prescore_calibrated_alpha_",))
    elif name.startswith("adaclip_") or name.startswith("adaptclip_"):
        host = "AdaCLIP" if name.startswith("adaclip_") else "AdaptCLIP"
        mean_rows = {row.get("mode"): row for row in data.get("rows", []) if row.get("target_label") == "mean"}
        base_mode = "baseline_txt"
        if name.startswith("adaptclip_"):
            replace_key = "scalar_replace_vl"
            residual_key = "scalar_residual_vl"
            cted_key = "ted_calibrated_vl"
        else:
            replace_key = "scalar_replace"
            residual_key = "scalar_residual"
            cted_key = "ted_calibrated"
        if any(mode not in mean_rows for mode in [base_mode, replace_key, residual_key, cted_key]):
            return None

        def row_triplet(row: dict) -> tuple[float, float, float]:
            return (
                pct(float(row.get("pixel_auroc", float("nan")))),
                pct(float(row.get("pixel_aupro", float("nan")))),
                pct(float(row.get("pixel_ap", float("nan")))),
            )

        base = row_triplet(mean_rows[base_mode])
        row = {
            "host": host,
            "setting": name,
            "baseline_p_auc": base[0],
            "baseline_pro": base[1],
            "baseline_ap": base[2],
            "replace_key": replace_key,
            "residual_key": residual_key,
            "cted_key": cted_key,
        }
        for label, key in [("host_replace", replace_key), ("host_residual", residual_key), ("cted", cted_key)]:
            cand = row_triplet(mean_rows[key])
            d_auc = cand[0] - base[0]
            d_pro = cand[1] - base[1]
            d_ap = cand[2] - base[2]
            row[f"{label}_delta_p_auc"] = d_auc
            row[f"{label}_delta_pro"] = d_pro
            row[f"{label}_delta_ap"] = d_ap
            row[f"{label}_delta_loc"] = 0.5 * (d_pro + d_ap)
        return row
    else:
        return None
    if not base_blob or not replace_key or not residual_key or not cted_key:
        return None
    base = triplet(base_blob, pro_key)
    row = {
        "host": host,
        "setting": name,
        "baseline_p_auc": base[0],
        "baseline_pro": base[1],
        "baseline_ap": base[2],
        "replace_key": replace_key,
        "residual_key": residual_key,
        "cted_key": cted_key,
    }
    for label, key in [("host_replace", replace_key), ("host_residual", residual_key), ("cted", cted_key)]:
        cand = triplet(candidates[key], pro_key)
        d_auc = cand[0] - base[0]
        d_pro = cand[1] - base[1]
        d_ap = cand[2] - base[2]
        row[f"{label}_delta_p_auc"] = d_auc
        row[f"{label}_delta_pro"] = d_pro
        row[f"{label}_delta_ap"] = d_ap
        row[f"{label}_delta_loc"] = 0.5 * (d_pro + d_ap)
    return row


def aggregate(rows: list[dict]) -> list[dict]:
    out = []
    for host in ["AA-CLIP", "FAPrompt", "AdaCLIP", "AdaptCLIP"]:
        sub = [r for r in rows if r["host"] == host]
        if not sub:
            continue
        out.append(_aggregate_one(host, sub))
    if rows:
        out.append(_aggregate_one("Mean", rows))
    return out


def _aggregate_one(scope: str, rows: list[dict]) -> dict:
    out = {"scope": scope, "n": len(rows)}
    for key in ["host_replace", "host_residual", "cted"]:
        for metric in ["delta_p_auc", "delta_pro", "delta_ap", "delta_loc"]:
            out[f"{key}_{metric}"] = float(np.mean([float(r[f"{key}_{metric}"]) for r in rows]))
    return out


def write_csv(rows: list[dict]) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fields = [
        "host",
        "setting",
        "baseline_p_auc",
        "baseline_pro",
        "baseline_ap",
        "host_replace_delta_p_auc",
        "host_replace_delta_pro",
        "host_replace_delta_ap",
        "host_replace_delta_loc",
        "host_residual_delta_p_auc",
        "host_residual_delta_pro",
        "host_residual_delta_ap",
        "host_residual_delta_loc",
        "cted_delta_p_auc",
        "cted_delta_pro",
        "cted_delta_ap",
        "cted_delta_loc",
        "replace_key",
        "residual_key",
        "cted_key",
    ]
    with CSV_OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fields})


def write_tex(aggs: list[dict]) -> None:
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Host-score-only calibration control.",
        r"Controls train a source-only rank readout using only the host local score on source defect and hard-FP patches, without source defect/hard-FP support features.",
        r"Values are gains over the corresponding host baseline; $\Delta$Loc is the mean of $\Delta$PRO and $\Delta$AP.",
        r"}",
        r"\label{tab:supp_host_score_only_control}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.0pt}",
        r"\renewcommand{\arraystretch}{1.05}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lcccc}",
        r"\toprule",
        r"Scope & $n$ & Host replace & Host residual & C-TED \\",
        r"\midrule",
    ]
    for row in aggs:
        lines.append(
            f"{row['scope']} & {row['n']} & "
            f"{fmt(row['host_replace_delta_loc'])} & "
            f"{fmt(row['host_residual_delta_loc'])} & "
            f"\\textbf{{{fmt(row['cted_delta_loc'])}}} \\\\"
        )
    lines += [
        r"\bottomrule",
        r"\end{tabular*}",
        r"\end{table}",
        "",
    ]
    TEX_OUT.write_text("\n".join(lines))


def main() -> int:
    rows = [row for path in sorted(RESULTS.glob("*/summary.json")) if (row := parse_summary(path)) is not None]
    write_csv(rows)
    write_tex(aggregate(rows))
    print(json.dumps({"rows": len(rows), "csv": str(CSV_OUT.relative_to(ROOT)), "tex": str(TEX_OUT.relative_to(ROOT))}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
