#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

TARGETS = ("MVTec", "VisA", "MPDD", "BTAD")
METRICS = ("i_auc", "p_auc", "p_pro", "p_ap")
METRIC_LABEL = {
    "i_auc": "I-AUC",
    "p_auc": "P-AUC",
    "p_pro": "P-PRO",
    "p_ap": "P-AP",
}


def load(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(v, already_percent: bool = False) -> float | None:
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    v = float(v)
    if already_percent:
        return v
    return v * 100.0 if abs(v) <= 1.5 else v


def vals(d: dict | None) -> dict[str, float | None] | None:
    if not isinstance(d, dict):
        return None
    probes = [
        d.get("image_auroc", d.get("image_auc")),
        d.get("pixel_auroc", d.get("pixel_auc")),
    ]
    already_percent = any(
        v is not None and not (isinstance(v, float) and math.isnan(v)) and abs(float(v)) > 1.5
        for v in probes
    )
    return {
        "i_auc": pct(d.get("image_auroc", d.get("image_auc")), already_percent),
        "p_auc": pct(d.get("pixel_auroc", d.get("pixel_auc")), already_percent),
        "p_pro": pct(d.get("pixel_aupro", d.get("pixel_pro")), already_percent),
        "p_ap": pct(d.get("pixel_ap"), already_percent),
    }


def fmt(v: float | None) -> str:
    return "--.--" if v is None else f"{v:.2f}"


def tex_escape(s: str | None) -> str:
    if not s:
        return "--"
    return s.replace("\\", r"\textbackslash{}").replace("_", r"\_")


FAPROMPT_TTED_SPECS = [
    ("ViT-B/16+", "MVTec", "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2mvtec_full_v1"),
    ("ViT-B/16+", "VisA", "faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2visa_full_20260427"),
    ("ViT-B/16+", "MPDD", "faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2mpdd_full_20260427"),
    ("ViT-B/16+", "BTAD", "faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2btad_full_20260427"),
    ("ViT-L/14", "MVTec", "faprompt_vitl14openai_prescore_hostaxis_visa2mvtec_fast_20260427"),
    ("ViT-L/14", "VisA", "faprompt_vitl14openai_prescore_hostaxis_mvtec2visa_fast_20260427"),
    ("ViT-L/14", "MPDD", "faprompt_vitl14openai_prescore_hostaxis_visa2mpdd_fast_20260427"),
    ("ViT-L/14", "BTAD", "faprompt_vitl14openai_prescore_hostaxis_visa2btad_fast_20260427"),
    ("ViT-L/14-336", "MVTec", None),
    ("ViT-L/14-336", "VisA", None),
    ("ViT-L/14-336", "MPDD", None),
    ("ViT-L/14-336", "BTAD", None),
    ("ViT-H/14", "MVTec", "faprompt_vith14_prescore_hostaxis_visa2mvtec_fast_20260427"),
    ("ViT-H/14", "VisA", "faprompt_vith14_prescore_hostaxis_mvtec2visa_fast_20260427"),
    ("ViT-H/14", "MPDD", "faprompt_vith14_prescore_hostaxis_visa2mpdd_fast_20260427"),
    ("ViT-H/14", "BTAD", "faprompt_vith14_prescore_hostaxis_visa2btad_fast_20260427"),
]


def export_faprompt_tted() -> list[dict]:
    rows: list[dict] = []
    for backbone, target, dirname in FAPROMPT_TTED_SPECS:
        base_vals = None
        t_vals = None
        selected = None
        source = None
        if dirname is not None:
            path = RESULTS / dirname / "summary.json"
            summary = load(path)
            if summary is not None:
                mean = summary.get("mean", {})
                base_vals = vals(mean.get("baseline_official") or mean.get("baseline"))
                candidates = []
                for key, value in mean.get("parallel", {}).items():
                    if key.startswith("prescore_rectify_alpha_"):
                        parsed = vals(value)
                        if parsed is not None and parsed["p_pro"] is not None:
                            candidates.append((parsed["p_pro"], key, parsed))
                if candidates:
                    _, selected, t_vals = max(candidates, key=lambda x: x[0])
                    source = dirname

        row = {
            "host": "FAPrompt",
            "backbone": backbone,
            "target": target,
            "selected_variant": selected,
            "source": source,
        }
        for prefix, data in (("baseline", base_vals), ("t_ted", t_vals)):
            for metric in METRICS:
                row[f"{prefix}_{metric}"] = None if data is None else data.get(metric)
        rows.append(row)

    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / "faprompt_t_ted_prescore_separate_20260502.csv"
    fields = [
        "host",
        "backbone",
        "target",
        "selected_variant",
        "baseline_i_auc",
        "baseline_p_auc",
        "baseline_p_pro",
        "baseline_p_ap",
        "t_ted_i_auc",
        "t_ted_p_auc",
        "t_ted_p_pro",
        "t_ted_p_ap",
        "source",
    ]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    tex_path = OUT / "faprompt_t_ted_prescore_separate_20260502.tex"
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Standalone FAPrompt train-free TED prescore results. These runs are reported separately from the source-calibrated FAPrompt table because they use the prescore T-TED protocol rather than the branch-calibrated C-TED protocol.}",
        r"\label{tab:faprompt_tted_prescore_separate}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\renewcommand{\arraystretch}{1.05}",
        r"\resizebox{\textwidth}{!}{",
        r"\begin{tabular}{lllc cccc cccc}",
        r"\toprule",
        r"Backbone & Target & Variant & Source & \multicolumn{4}{c}{Base} & \multicolumn{4}{c}{T-TED} \\",
        r"\cmidrule(lr){5-8} \cmidrule(lr){9-12}",
        r"& & & & I-AUC & P-AUC & P-PRO & P-AP & I-AUC & P-AUC & P-PRO & P-AP \\",
        r"\midrule",
    ]
    for row in rows:
        source_label = "--" if row["source"] is None else "prescore"
        lines.append(
            " & ".join(
                [
                    row["backbone"],
                    row["target"],
                    tex_escape(row["selected_variant"]),
                    source_label,
                    fmt(row["baseline_i_auc"]),
                    fmt(row["baseline_p_auc"]),
                    fmt(row["baseline_p_pro"]),
                    fmt(row["baseline_p_ap"]),
                    fmt(row["t_ted_i_auc"]),
                    fmt(row["t_ted_p_auc"]),
                    fmt(row["t_ted_p_pro"]),
                    fmt(row["t_ted_p_ap"]),
                ]
            )
            + r" \\"
        )
    lines += [r"\bottomrule", r"\end{tabular}", r"}", r"\end{table*}", ""]
    tex_path.write_text("\n".join(lines))

    md_path = OUT / "faprompt_t_ted_prescore_separate_20260502.md"
    md_lines = [
        "# FAPrompt T-TED Prescore Results",
        "",
        "These are kept separate from the branch-calibrated FAPrompt C-TED table because the baseline protocol is not identical.",
        "",
        "| Backbone | Target | Variant | B P-PRO | T P-PRO | B P-AUC | T P-AUC | B P-AP | T P-AP |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        md_lines.append(
            f"| {row['backbone']} | {row['target']} | {row['selected_variant'] or '--'} | "
            f"{fmt(row['baseline_p_pro'])} | {fmt(row['t_ted_p_pro'])} | "
            f"{fmt(row['baseline_p_auc'])} | {fmt(row['t_ted_p_auc'])} | "
            f"{fmt(row['baseline_p_ap'])} | {fmt(row['t_ted_p_ap'])} |"
        )
    md_path.write_text("\n".join(md_lines) + "\n")
    return rows


def read_compact_records() -> list[dict]:
    path = OUT / "adapted_host_b_t_c_records_20260502.csv"
    rows: list[dict] = []
    with path.open("r") as f:
        for row in csv.DictReader(f):
            out = dict(row)
            for key in ("baseline", "t_ted", "c_ted", "delta_t", "delta_c"):
                out[key] = None if row[key] in ("", "None") else float(row[key])
            rows.append(out)
    return rows


def mean(values: list[float | None]) -> float | None:
    clean = [v for v in values if v is not None and not math.isnan(v)]
    return None if not clean else sum(clean) / len(clean)


def near_zero(v: float | None, eps: float = 0.05) -> bool:
    return v is not None and abs(v) < eps


def delta_label(v: float | None) -> str:
    if v is None:
        return "--"
    if near_zero(v):
        return "0.0"
    return f"{v:+.1f}"


def win(values: list[float | None]) -> float | None:
    clean = [v for v in values if v is not None and not math.isnan(v)]
    return None if not clean else 100.0 * sum(v > 0 for v in clean) / len(clean)


def grouped_delta(rows: list[dict], group_key: str, metric: str, method: str) -> tuple[list[str], list[float | None], list[int]]:
    groups = sorted({r[group_key] for r in rows})
    values = []
    ns = []
    delta_key = "delta_t" if method == "t" else "delta_c"
    for group in groups:
        subset = [r for r in rows if r[group_key] == group and r["metric"] == metric]
        deltas = [r[delta_key] for r in subset]
        values.append(mean(deltas))
        ns.append(sum(v is not None for v in deltas))
    return groups, values, ns


def make_main_figure() -> None:
    rows = read_compact_records()
    FIG.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig, axs = plt.subplots(
        1,
        4,
        figsize=(7.25, 2.15),
        constrained_layout=True,
        gridspec_kw={"width_ratios": [2.05, 1.05, 1.0, 1.0]},
    )
    ax_heat, ax_win, ax_backbone, ax_target = axs

    color_c = "#256D85"
    color_pos = "#256D85"
    color_neg = "#B75D3A"

    host_order = ["AA-CLIP", "FAPrompt", "AdaCLIP", "AdaptCLIP", "BayesPFL", "AnomalyCLIP"]
    metric_order = ["p_auc", "p_pro", "p_ap", "i_auc"]
    heat = np.full((len(host_order), len(metric_order)), np.nan)
    for i, host in enumerate(host_order):
        for j, metric in enumerate(metric_order):
            subset = [r for r in rows if r["host"] == host and r["metric"] == metric]
            heat[i, j] = np.nan if not subset else mean([r["delta_c"] for r in subset]) or np.nan
    vmax = float(np.nanmax(np.abs(heat))) if np.isfinite(heat).any() else 1.0
    im = ax_heat.imshow(heat, cmap="RdBu", vmin=-vmax, vmax=vmax, aspect="auto")
    for i in range(len(host_order)):
        for j in range(len(metric_order)):
            value = heat[i, j]
            text = "--" if not np.isfinite(value) else delta_label(float(value))
            ax_heat.text(j, i, text, ha="center", va="center", fontsize=6.5, color="#111111")
    ax_heat.set_title("(a) C-TED gain profile")
    ax_heat.set_xticks(np.arange(len(metric_order)))
    ax_heat.set_xticklabels([METRIC_LABEL[m] for m in metric_order], rotation=35, ha="right")
    ax_heat.set_yticks(np.arange(len(host_order)))
    ax_heat.set_yticklabels(host_order)
    ax_heat.tick_params(length=0)
    cbar = fig.colorbar(im, ax=ax_heat, fraction=0.046, pad=0.02)
    cbar.ax.set_ylabel("Delta", rotation=270, labelpad=8)
    cbar.ax.tick_params(labelsize=6)

    pixel_metrics = {"p_auc", "p_pro", "p_ap"}
    win_vals = []
    for host in host_order:
        deltas = [r["delta_c"] for r in rows if r["host"] == host and r["metric"] in pixel_metrics and r["delta_c"] is not None]
        win_vals.append(win(deltas))
    x = np.arange(len(host_order))
    ax_win.bar(x, [0 if v is None else v for v in win_vals], color=[color_pos if v is not None else "#D8D8D8" for v in win_vals], width=0.62)
    for xi, val in zip(x, win_vals):
        ax_win.text(xi, 2 if val is None else min(val + 2.5, 98), "--" if val is None else f"{val:.0f}%", ha="center", va="bottom", fontsize=6.5)
    ax_win.set_title("(b) Pixel win-rate")
    ax_win.set_ylim(0, 105)
    ax_win.set_xticks(x)
    ax_win.set_xticklabels(host_order, rotation=35, ha="right")

    def grouped_pixel_delta(group_key: str):
        groups = sorted({r[group_key] for r in rows})
        values = []
        for group in groups:
            subset = [
                r
                for r in rows
                if r[group_key] == group and r["metric"] in pixel_metrics and r["delta_c"] is not None
            ]
            values.append(mean([r["delta_c"] for r in subset]))
        return groups, values

    backbones, bvals = grouped_pixel_delta("backbone")
    short_backbones = [b.replace("ViT-L/14-336", "L/14-336").replace("ViT-L/14", "L/14").replace("ViT-B/16+", "B/16+").replace("ViT-H/14", "H/14") for b in backbones]
    x = np.arange(len(backbones))
    ax_backbone.bar(x, [0 if v is None else v for v in bvals], color=["#BFBFBF" if near_zero(v) else (color_pos if (v or 0) > 0 else color_neg) for v in bvals], width=0.62)
    for xi, val in zip(x, bvals):
        if val is not None:
            ax_backbone.text(xi, val + (0.75 if val >= 0 else -0.75), delta_label(val), ha="center", va="bottom" if val >= 0 else "top")
    ax_backbone.axhline(0, color="#333333", lw=0.7)
    ax_backbone.set_title("(c) Backbone avg.")
    ax_backbone.set_ylabel(r"$\Delta$ pixel metrics")
    bclean = [v for v in bvals if v is not None]
    if bclean:
        ax_backbone.set_ylim(min(-0.8, min(bclean) - 1.3), max(bclean) + 2.2)
    ax_backbone.set_xticks(x)
    ax_backbone.set_xticklabels(short_backbones, rotation=25, ha="right")

    target_order = ["MVTec", "VisA", "MPDD", "BTAD"]
    target_vals = []
    for target in target_order:
        subset = [r for r in rows if r["target"] == target and r["metric"] in pixel_metrics]
        target_vals.append(mean([r["delta_c"] for r in subset]))
    x = np.arange(len(target_order))
    ax_target.bar(x, [0 if v is None else v for v in target_vals], color=["#BFBFBF" if near_zero(v) else (color_pos if (v or 0) > 0 else color_neg) for v in target_vals], width=0.62)
    for xi, val in zip(x, target_vals):
        if val is not None:
            ax_target.text(xi, val + (0.75 if val >= 0 else -0.75), delta_label(val), ha="center", va="bottom" if val >= 0 else "top")
    ax_target.axhline(0, color="#333333", lw=0.7)
    ax_target.set_title("(d) Target avg.")
    ax_target.set_ylabel(r"$\Delta$ pixel metrics")
    tclean = [v for v in target_vals if v is not None]
    if tclean:
        ax_target.set_ylim(min(-0.8, min(tclean) - 1.3), max(tclean) + 2.2)
    ax_target.set_xticks(x)
    ax_target.set_xticklabels(target_order, rotation=20, ha="right")

    for ax in axs:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        if ax is not ax_heat:
            ax.grid(axis="y", color="#E6E6E6", linewidth=0.6)
        ax.set_axisbelow(True)

    pdf = FIG / "adapted_host_compact_summary_20260502.pdf"
    png = FIG / "adapted_host_compact_summary_20260502.png"
    pdf_1row = FIG / "adapted_host_compact_summary_1row_20260502.pdf"
    png_1row = FIG / "adapted_host_compact_summary_1row_20260502.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    fig.savefig(pdf_1row, bbox_inches="tight")
    fig.savefig(png_1row, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print({"figure_pdf": str(pdf), "figure_png": str(png), "figure_1row_pdf": str(pdf_1row), "figure_1row_png": str(png_1row)})


def main() -> int:
    rows = export_faprompt_tted()
    make_main_figure()
    print(
        {
            "faprompt_tted_rows": len(rows),
            "faprompt_tted_csv": str(OUT / "faprompt_t_ted_prescore_separate_20260502.csv"),
            "faprompt_tted_tex": str(OUT / "faprompt_t_ted_prescore_separate_20260502.tex"),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
