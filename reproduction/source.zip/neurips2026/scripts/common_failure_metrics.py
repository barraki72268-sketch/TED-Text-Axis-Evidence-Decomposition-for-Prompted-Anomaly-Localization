from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026" / "results"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
PRESET_LABELS = ["VisA→MVTec", "MVTec→VisA", "MVTec→MPDD", "MVTec→BTAD"]


def validate_visa_root(root: str, dataset_name: str) -> None:
    if dataset_name.lower() != "visa":
        return
    resolved = Path(root).resolve()
    official = OFFICIAL_VISA_ROOT.resolve()
    if resolved != official:
        raise ValueError(f"VisA experiments must use the official root only: {official}. Got: {resolved}")


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = np.asarray(arr, dtype=np.float32).reshape(-1)
    if flat.size == 0:
        return float("nan")
    k = max(1, int(np.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def current_rss_mb() -> float:
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    parts = line.split()
                    if len(parts) >= 2:
                        return float(parts[1]) / 1024.0
    except OSError:
        pass
    return float("nan")


def init_per_class(class_names: list[str]) -> dict[str, dict[str, float]]:
    return {
        class_name: {
            "num_anomaly": 0,
            "num_normal": 0,
            "inside_sum": 0.0,
            "outside_sum": 0.0,
            "ratio_sum": 0.0,
            "normal_topk_sum": 0.0,
            "normal_mean_sum": 0.0,
        }
        for class_name in class_names
    }


def reached_cap(current: int, cap: int) -> bool:
    return cap >= 0 and current >= cap


def update_per_class(
    stats: dict[str, float],
    anomaly_map: np.ndarray,
    gt_mask: np.ndarray,
    is_anomaly: bool,
    topk_frac: float,
) -> None:
    if is_anomaly and gt_mask.any():
        inside = float(anomaly_map[gt_mask].mean())
        outside = float(anomaly_map[~gt_mask].mean())
        stats["num_anomaly"] += 1
        stats["inside_sum"] += inside
        stats["outside_sum"] += outside
        stats["ratio_sum"] += outside / max(inside, 1e-8)
        return

    stats["num_normal"] += 1
    stats["normal_topk_sum"] += topk_mean(anomaly_map, topk_frac)
    stats["normal_mean_sum"] += float(np.asarray(anomaly_map, dtype=np.float32).mean())


def build_rows_and_summary(per_class: dict[str, dict[str, float]]) -> tuple[list[dict], dict]:
    rows: list[dict] = []
    for class_name, stats in per_class.items():
        if stats["num_anomaly"] == 0 and stats["num_normal"] == 0:
            continue
        row = {
            "class_name": class_name,
            "num_anomaly": int(stats["num_anomaly"]),
            "num_normal": int(stats["num_normal"]),
            "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
            "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
            "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
            "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
            "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
            "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
        }
        rows.append(row)

    if not rows:
        summary = {
            "num_classes": 0,
            "num_anomaly": 0,
            "num_normal": 0,
            "inside_mean": float("nan"),
            "outside_mean": float("nan"),
            "inside_outside_gap": float("nan"),
            "outside_inside_ratio": float("nan"),
            "normal_topk_mean": float("nan"),
            "normal_map_mean": float("nan"),
        }
        return rows, summary

    summary = {
        "num_classes": len(rows),
        "num_anomaly": int(sum(r["num_anomaly"] for r in rows)),
        "num_normal": int(sum(r["num_normal"] for r in rows)),
        "inside_mean": float(np.mean([r["inside_mean"] for r in rows])),
        "outside_mean": float(np.mean([r["outside_mean"] for r in rows])),
        "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in rows])),
        "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in rows])),
        "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in rows])),
        "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in rows])),
    }
    mean_row = {
        "class_name": "mean",
        "num_anomaly": summary["num_anomaly"],
        "num_normal": summary["num_normal"],
        "inside_mean": summary["inside_mean"],
        "outside_mean": summary["outside_mean"],
        "inside_outside_gap": summary["inside_outside_gap"],
        "outside_inside_ratio": summary["outside_inside_ratio"],
        "normal_topk_mean": summary["normal_topk_mean"],
        "normal_map_mean": summary["normal_map_mean"],
    }
    rows_with_mean = rows + [mean_row]
    return rows_with_mean, summary


def save_outputs(save_dir: Path, settings: dict, summary: dict, rows: list[dict]) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"settings": settings, "summary": summary, "rows": rows}, f, indent=2)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump(rows, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def write_progress(save_dir: Path, payload: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "progress.json", "w") as f:
        json.dump(payload, f, indent=2)
