#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_adaptclip.py"
CKPT="${ROOT}/neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_mvtec_3adpaters_batch8/epoch_15.pth"
SOURCE_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
SOURCE_DATASET="mvtec"
export MPLCONFIGDIR="/tmp/matplotlib-adaptclip-gpu0"

run_one() {
  local target_root="$1"
  local target_dataset="$2"
  local save_dir="$3"
  local bank_cache="$4"

  CUDA_VISIBLE_DEVICES=0 "${PYTHON}" "${SCRIPT}" \
    --source_root "${SOURCE_ROOT}" \
    --source_dataset "${SOURCE_DATASET}" \
    --target_root "${target_root}" \
    --target_dataset "${target_dataset}" \
    --checkpoint_path "${CKPT}" \
    --save_dir "${save_dir}" \
    --bank_cache_path "${bank_cache}" \
    --pretrained_model "ViT-L/14@336px" \
    --features_list 6 12 18 24 \
    --image_size 518 \
    --batch_size 8 \
    --n_ctx 12 \
    --sigma 4 \
    --vl_reduction 4 \
    --fusion_type average_mean \
    --max_good_per_class 2 \
    --max_defect_per_class 4 \
    --max_bank_per_layer 512 \
    --max_fp_per_image 64 \
    --max_defect_per_image 64 \
    --device cuda:0
}

run_one \
  "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  "visa" \
  "${ROOT}/neurips2026/results/official_parallel_test_adaptclip_mvtec2visa_all" \
  "${ROOT}/neurips2026/results/bank_cache/adaptclip_mvtec_full_multilayer.pt"

run_one \
  "/mnt/data/MPDD" \
  "mpdd" \
  "${ROOT}/neurips2026/results/official_parallel_test_adaptclip_mvtec2mpdd_all" \
  "${ROOT}/neurips2026/results/bank_cache/adaptclip_mvtec_full_multilayer.pt"

run_one \
  "${ROOT}/neurips2026/data/BTAD_official" \
  "btad" \
  "${ROOT}/neurips2026/results/official_parallel_test_adaptclip_mvtec2btad_all" \
  "${ROOT}/neurips2026/results/bank_cache/adaptclip_mvtec_full_multilayer.pt"
