from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from official_parallel_test_adaclip import (  # noqa: E402
    build_model,
    build_target_dataset,
    decision_axis,
    load_bank_cache,
    logmeanexp_negative_sqdist_1d,
    refine_layer_logits,
    smooth_map,
)


MVTEC_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"
MPDD_ROOT = Path("/mnt/data/MPDD")
DEFAULT_BANK = ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"


def sync_if_needed(device: str) -> None:
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.synchronize(device=device)


def timed(fn, device: str):
    sync_if_needed(device)
    start = time.perf_counter()
    out = fn()
    sync_if_needed(device)
    return out, time.perf_counter() - start


def pick_item(dataset, class_name: str | None, anomaly_only: bool):
    for idx in range(len(dataset)):
        item = dataset[idx]
        if class_name is not None and item["cls_name"] != class_name:
            continue
        anomaly_flag = item["anomaly"]
        if hasattr(anomaly_flag, "item"):
            anomaly_flag = anomaly_flag.item()
        is_anomaly = int(anomaly_flag) == 1
        if anomaly_only and not is_anomaly:
            continue
        return idx, item
    raise RuntimeError(f"No sample found for class_name={class_name!r}, anomaly_only={anomaly_only}")


def profile_once(
    model,
    item: dict,
    fp_banks_gpu: dict[int, torch.Tensor],
    def_banks_gpu: dict[int, torch.Tensor],
    image_size: int,
    sigma: float,
    tau: float,
    fp_weight: float,
    scoring_mode: str,
    refine_alpha: float,
    refine_beta: float,
    margin_norm_mode: str,
    device: str,
) -> dict[str, float]:
    timings: dict[str, float] = {}
    image, timings["to_device_s"] = timed(lambda: item["img"].unsqueeze(0).to(device), device)
    cls_name = item["cls_name"]

    def do_extract():
        return model.clip_model.extract_feat(image, [cls_name])

    (image_features, patch_tokens, text_features), timings["extract_feat_s"] = timed(do_extract, device)

    def do_vl_similarity():
        return model.clip_model.visual_text_similarity(image_features, patch_tokens, text_features, aggregation=True)

    (anomaly_map, anomaly_score), timings["baseline_similarity_s"] = timed(do_vl_similarity, device)
    timings["baseline_score_read_s"] = 0.0
    axis, timings["decision_axis_s"] = timed(lambda: decision_axis(text_features).to(device), device)

    anomaly_map = anomaly_map.squeeze(1)
    _, timings["baseline_smooth_s"] = timed(lambda: smooth_map(anomaly_map, sigma=sigma), device)
    timings["baseline_total_s"] = (
        timings["extract_feat_s"]
        + timings["baseline_similarity_s"]
        + timings["decision_axis_s"]
        + timings["baseline_smooth_s"]
    )

    layer_projection_total = 0.0
    layer_refine_total = 0.0
    layer_reshape_total = 0.0
    parallel_layer_maps = []
    refined_layer_logits = []
    patch_tokens = [F.normalize(x.float(), dim=-1) for x in patch_tokens]

    for layer_idx, patch_feature in enumerate(patch_tokens):
        patch = patch_feature[0]
        fp_bank = fp_banks_gpu[layer_idx]
        def_bank = def_banks_gpu[layer_idx]

        def project_layer():
            fp_coeff = fp_bank @ axis if fp_bank.numel() else torch.empty((0,), device=device)
            def_coeff = def_bank @ axis if def_bank.numel() else torch.empty((0,), device=device)
            coeff = patch @ axis
            q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=tau)
            q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=tau)
            h = int(round(patch.shape[0] ** 0.5))
            parallel_map = (q_def - fp_weight * q_fp).reshape(1, 1, h, h)
            parallel_map = F.interpolate(
                parallel_map,
                size=(image_size, image_size),
                mode="bilinear",
                align_corners=True,
            )
            return parallel_map

        parallel_map, layer_projection_s = timed(project_layer, device)
        parallel_layer_maps.append(parallel_map)
        layer_projection_total += layer_projection_s

        def do_layer_logits():
            layer_logit = 100.0 * patch_feature @ text_features
            bsz, num_tokens, _ = layer_logit.shape
            h = int(round(num_tokens ** 0.5))
            layer_logit = layer_logit.permute(0, 2, 1).view(bsz, 2, h, h)
            return F.interpolate(layer_logit, size=(image_size, image_size), mode="bilinear", align_corners=True)

        layer_logit, layer_reshape_s = timed(do_layer_logits, device)
        layer_reshape_total += layer_reshape_s

        if scoring_mode != "replace":
            refined, layer_refine_s = timed(
                lambda: refine_layer_logits(
                    layer_logits=layer_logit,
                    margin_map=parallel_map,
                    scoring_mode=scoring_mode,
                    refine_alpha=refine_alpha,
                    refine_beta=refine_beta,
                    margin_norm_mode=margin_norm_mode,
                ),
                device,
            )
            refined_layer_logits.append(refined)
            layer_refine_total += layer_refine_s

    timings["layer_projection_total_s"] = layer_projection_total
    timings["layer_textlogit_total_s"] = layer_reshape_total
    timings["layer_refine_total_s"] = layer_refine_total

    def aggregate():
        if scoring_mode == "replace":
            return torch.stack(parallel_layer_maps, dim=0).mean(dim=0)[:, 0]
        aggregated_refined_logits = torch.stack(refined_layer_logits, dim=0).mean(dim=0)
        aggregated_refined_probs = torch.softmax(aggregated_refined_logits, dim=1)
        return (aggregated_refined_probs[:, 1:2] + 1 - aggregated_refined_probs[:, 0:1])[:, 0] / 2.0

    parallel_map, timings["aggregate_s"] = timed(aggregate, device)
    parallel_map, timings["parallel_smooth_s"] = timed(lambda: smooth_map(parallel_map, sigma=sigma), device)
    _, timings["cpu_copy_s"] = timed(
        lambda: (
            parallel_map.detach().cpu(),
            anomaly_score.detach().cpu(),
        ),
        device,
    )
    timings["parallel_total_s"] = (
        timings["layer_projection_total_s"]
        + timings["layer_textlogit_total_s"]
        + timings["layer_refine_total_s"]
        + timings["aggregate_s"]
        + timings["parallel_smooth_s"]
    )
    timings["total_image_loop_s"] = (
        timings["to_device_s"]
        + timings["baseline_total_s"]
        + timings["parallel_total_s"]
        + timings["cpu_copy_s"]
    )
    return timings


def main() -> None:
    parser = argparse.ArgumentParser("Profile a single AdaCLIP MPDD sample and break down time by stage")
    parser.add_argument("--device", type=str, default="cuda:1" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--class_name", type=str, default="metal_plate")
    parser.add_argument("--checkpoint_path", type=str, default=str(MVTEC_CKPT))
    parser.add_argument("--target_root", type=str, default=str(MPDD_ROOT))
    parser.add_argument("--target_dataset", type=str, default="mpdd")
    parser.add_argument("--bank_cache_path", type=str, default=str(DEFAULT_BANK))
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--fp_weight", type=float, default=0.3)
    parser.add_argument("--scoring_mode", type=str, default="logit_gate_posneg")
    parser.add_argument("--refine_alpha", type=float, default=0.3)
    parser.add_argument("--refine_beta", type=float, default=0.15)
    parser.add_argument("--margin_norm_mode", type=str, default="spatial_tanh_zscore")
    parser.add_argument("--prompting_depth", type=int, default=4)
    parser.add_argument("--prompting_length", type=int, default=5)
    parser.add_argument("--prompting_branch", type=str, default="VL")
    parser.add_argument("--prompting_type", type=str, default="SD")
    parser.add_argument("--use_hsf", type=lambda x: x.lower() in {"1", "true", "yes"}, default=True)
    parser.add_argument("--k_clusters", type=int, default=20)
    parser.add_argument("--cpu_threads", type=int, default=1)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--repeat", type=int, default=3)
    args = parser.parse_args()

    torch.set_num_threads(max(1, int(args.cpu_threads)))
    try:
        torch.set_num_interop_threads(max(1, int(args.cpu_threads)))
    except RuntimeError:
        pass

    model = build_model(
        device=args.device,
        checkpoint_path=args.checkpoint_path,
        image_size=args.image_size,
        prompting_depth=args.prompting_depth,
        prompting_length=args.prompting_length,
        prompting_branch=args.prompting_branch,
        prompting_type=args.prompting_type,
        use_hsf=args.use_hsf,
        k_clusters=args.k_clusters,
    )
    dataset = build_target_dataset(args.target_root, args.target_dataset, model, training=False, class_name=None)
    item_idx, item = pick_item(dataset, args.class_name, anomaly_only=True)

    fp_banks, def_banks, _, _ = load_bank_cache(Path(args.bank_cache_path))
    fp_banks_gpu = {layer_idx: bank.to(args.device) for layer_idx, bank in fp_banks.items()}
    def_banks_gpu = {layer_idx: bank.to(args.device) for layer_idx, bank in def_banks.items()}

    for _ in range(max(0, args.warmup)):
        _ = profile_once(
            model=model,
            item=item,
            fp_banks_gpu=fp_banks_gpu,
            def_banks_gpu=def_banks_gpu,
            image_size=args.image_size,
            sigma=args.sigma,
            tau=args.tau,
            fp_weight=args.fp_weight,
            scoring_mode=args.scoring_mode,
            refine_alpha=args.refine_alpha,
            refine_beta=args.refine_beta,
            margin_norm_mode=args.margin_norm_mode,
            device=args.device,
        )

    measurements = []
    for _ in range(max(1, args.repeat)):
        measurements.append(
            profile_once(
                model=model,
                item=item,
                fp_banks_gpu=fp_banks_gpu,
                def_banks_gpu=def_banks_gpu,
                image_size=args.image_size,
                sigma=args.sigma,
                tau=args.tau,
                fp_weight=args.fp_weight,
                scoring_mode=args.scoring_mode,
                refine_alpha=args.refine_alpha,
                refine_beta=args.refine_beta,
                margin_norm_mode=args.margin_norm_mode,
                device=args.device,
            )
        )

    keys = list(measurements[0].keys())
    mean_timings = {key: float(sum(m[key] for m in measurements) / len(measurements)) for key in keys}

    payload = {
        "sample": {
            "dataset_index": item_idx,
            "class_name": item["cls_name"],
            "img_path": item["img_path"],
            "anomaly": int(item["anomaly"].item() if hasattr(item["anomaly"], "item") else item["anomaly"]),
        },
        "settings": {
            "device": args.device,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "bank_cache_path": args.bank_cache_path,
            "warmup": args.warmup,
            "repeat": args.repeat,
            "scoring_mode": args.scoring_mode,
            "fp_weight": args.fp_weight,
        },
        "mean_timings_sec": mean_timings,
        "measurements_sec": measurements,
    }
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
