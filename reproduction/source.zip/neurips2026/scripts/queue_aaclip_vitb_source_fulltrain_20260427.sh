#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP/neurips2026/AA-CLIP

PY="/mnt/data/envs/patchcore-conda/bin/python"
export AACLIP_VISA_ROOT="/mnt/data/VisA_20220922"
export AACLIP_MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"

DATASET="${1:?dataset required: VisA or MVTec}"
GPU_ID="${2:?gpu id required}"
SAVE_PATH="${3:?save path required}"

mkdir -p "${SAVE_PATH}"

echo "[$(date '+%F %T')] start AA-CLIP ViT-B/16+ source full train dataset=${DATASET} gpu=${GPU_ID}"
CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" -u train.py \
  --dataset "${DATASET}" \
  --training_mode full_shot \
  --model_name ViT-B-16-plus-240 \
  --pretrained laion400m_e32 \
  --levels 6,12 \
  --surgery_until_layer 12 \
  --img_size 518 \
  --text_batch_size 32 \
  --image_batch_size 8 \
  --text_epoch 5 \
  --image_epoch 20 \
  --save_path "${SAVE_PATH}"
echo "[$(date '+%F %T')] done AA-CLIP ViT-B/16+ source full train dataset=${DATASET}"
