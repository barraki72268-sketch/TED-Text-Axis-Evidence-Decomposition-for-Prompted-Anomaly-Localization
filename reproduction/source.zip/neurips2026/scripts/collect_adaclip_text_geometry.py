from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ADACLIP_ROOT = ROOT / "neurips2026" / "AdaCLIP"
VISA_ROOT = "/mnt/data/gijeong/MMAD_new/VisA"
if str(ADACLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ADACLIP_ROOT))

from method import AdaCLIP_Trainer  # noqa: E402
from dataset.visa import VISA_CLS_NAMES, VisaDataset  # noqa: E402


def cosine(a: torch.Tensor, b: torch.Tensor) -> float:
    a = F.normalize(a.float(), dim=-1)
    b = F.normalize(b.float(), dim=-1)
    return float((a * b).sum().item())


def normal_basis(text_bank: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    text_bank = F.normalize(text_bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(text_bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return text_bank.new_zeros((text_bank.shape[-1], 0))
    return vh[:rank].transpose(0, 1).contiguous()


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = vec @ basis
    return float(coeff.pow(2).sum().item())


def build_model(device: str, use_text_leakage_reg: bool):
    model = AdaCLIP_Trainer(
        backbone="ViT-L-14-336",
        feat_list=[6, 12, 18, 24],
        input_dim=1024,
        output_dim=768,
        learning_rate=0.01,
        device=device,
        image_size=518,
        prompting_depth=4,
        prompting_length=5,
        prompting_branch="VL",
        prompting_type="SD",
        use_hsf=True,
        k_clusters=20,
        use_ir_scorer=False,
        ir_ortho_weight=0.1,
        text_leakage_reg=use_text_leakage_reg,
        text_ortho_weight=0.01,
        text_anchor_weight=0.05,
    ).to(device)
    model.eval()
    return model


def build_normal_bank(clip_model, cls_name: str, device: str):
    layer = clip_model.static_text_embedding_layer
    text = cls_name.replace("-", " ")
    prompted_state = [state.format(text) for state in layer.prompt_normal]
    prompted_sentence = []
    for s in prompted_state:
        for template in layer.prompt_templates:
            prompted_sentence.append(template.format(s))
    prompted_sentence = layer.tokenize(prompted_sentence, context_length=77).to(device)
    prompt_enabled = clip_model.text_prompter.enabled
    clip_model.text_prompter.enabled = False
    try:
        class_embeddings = clip_model.encode_text(prompted_sentence)
        class_embeddings = class_embeddings / class_embeddings.norm(dim=-1, keepdim=True)
    finally:
        clip_model.text_prompter.enabled = prompt_enabled
    return class_embeddings


def get_static_text_features(clip_model, cls_name: list[str], device: str):
    prompt_enabled = clip_model.text_prompter.enabled
    clip_model.text_prompter.enabled = False
    try:
        clip_model.static_text_embedding_layer.ensemble_text_features.clear()
        static = clip_model.static_text_embedding_layer(clip_model, cls_name, device)
        return F.normalize(static.float(), dim=1)
    finally:
        clip_model.text_prompter.enabled = prompt_enabled


def collect_host(ckpt_path: Path, series: str, device: str, use_text_leakage_reg: bool):
    model = build_model(device, use_text_leakage_reg=use_text_leakage_reg)
    model.load(str(ckpt_path))
    clip_model = model.clip_model

    test_data = VisaDataset(
        transform=model.preprocess,
        target_transform=model.transform,
        root=VISA_ROOT,
        clsnames=VISA_CLS_NAMES,
        training=False,
    )
    loader = torch.utils.data.DataLoader(test_data, batch_size=1, shuffle=False, num_workers=0)

    per_class = {
        cls_name: {
            "count": 0,
            "overlap_cos": 0.0,
            "proj_energy_to_normal": 0.0,
            "anchor_retention_norm": 0.0,
            "anchor_retention_anom": 0.0,
        }
        for cls_name in VISA_CLS_NAMES
    }

    clip_model.eval()
    with torch.no_grad():
        for items in loader:
            image = items["img"].to(device)
            cls_name_list = items["cls_name"]
            _, _, text_features = clip_model.extract_feat(image, cls_name_list)
            learned = F.normalize(text_features.float(), dim=1)
            static = get_static_text_features(clip_model, cls_name_list, device)

            cls_name = cls_name_list[0]
            e_norm = learned[0, :, 0]
            e_anom = learned[0, :, 1]
            e_norm_anchor = static[0, :, 0]
            e_anom_anchor = static[0, :, 1]
            normal_bank = build_normal_bank(clip_model, cls_name, device)
            basis = normal_basis(normal_bank).to(device)

            stats = per_class[cls_name]
            stats["count"] += 1
            stats["overlap_cos"] += cosine(e_anom, e_norm)
            stats["proj_energy_to_normal"] += projection_energy(e_anom, basis)
            stats["anchor_retention_norm"] += cosine(e_norm, e_norm_anchor)
            stats["anchor_retention_anom"] += cosine(e_anom, e_anom_anchor)

    class_rows = []
    for cls_name in VISA_CLS_NAMES:
        stats = per_class[cls_name]
        if stats["count"] == 0:
            continue
        class_rows.append(
            {
                "series": series,
                "class_name": cls_name,
                "overlap_cos": stats["overlap_cos"] / stats["count"],
                "proj_energy_to_normal": stats["proj_energy_to_normal"] / stats["count"],
                "anchor_retention_norm": stats["anchor_retention_norm"] / stats["count"],
                "anchor_retention_anom": stats["anchor_retention_anom"] / stats["count"],
            }
        )

    mean_row = {
        "series": series,
        "class_name": "mean",
        "overlap_cos": sum(row["overlap_cos"] for row in class_rows) / len(class_rows),
        "proj_energy_to_normal": sum(row["proj_energy_to_normal"] for row in class_rows) / len(class_rows),
        "anchor_retention_norm": sum(row["anchor_retention_norm"] for row in class_rows) / len(class_rows),
        "anchor_retention_anom": sum(row["anchor_retention_anom"] for row in class_rows) / len(class_rows),
    }
    class_rows.append(mean_row)
    return class_rows


def save_rows(rows, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump(rows, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "series",
                "class_name",
                "overlap_cos",
                "proj_energy_to_normal",
                "anchor_retention_norm",
                "anchor_retention_anom",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Collect AdaCLIP text-geometry metrics")
    parser.add_argument(
        "--baseline_ckpt",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_fair_baseline_mvtec2visa" / "models" / "0s-pretrained-['mvtec']-ViT-L-14-336-SD-VL-D4-L5-HSF-K20_last.pth"),
    )
    parser.add_argument(
        "--ours_ckpt",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_textreg_fair_mvtec2visa" / "models" / "0s-pretrained-['mvtec']-ViT-L-14-336-SD-VL-D4-L5-HSF-K20_last.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_text_geometry"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    rows = []
    baseline_ckpt = Path(args.baseline_ckpt)
    if baseline_ckpt.exists():
        rows.extend(collect_host(baseline_ckpt, "baseline", args.device, use_text_leakage_reg=False))

    ours_ckpt = Path(args.ours_ckpt)
    if ours_ckpt.exists():
        rows.extend(collect_host(ours_ckpt, "ours", args.device, use_text_leakage_reg=True))

    save_rows(rows, Path(args.save_dir))
    print(json.dumps({"num_rows": len(rows), "save_dir": args.save_dir}, indent=2))


if __name__ == "__main__":
    main()
