#!/usr/bin/env python3
"""Queue all layer-recipe retraining rows for the retrain-only table.

This queue is intentionally separated from the fixed-checkpoint layer-stress
sweeps. Each retrained row trains a host checkpoint under the specified layer
recipe, rebuilds the source evidence bank for that checkpoint/recipe, and then
evaluates B / T / C on VisA -> MVTec.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")

OUT = ROOT / "neurips2026/results/layer_recipe_retrained_all_20260502"
LOG = OUT / "logs"
BANK = OUT / "bank_cache"

VISA_1CLS = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
CLINICDB = Path("/mnt/data/CVC-ClinicDB")
COLONDB = Path("/mnt/data/CVC-ColonDB")

ADACLIP_ROOT = ROOT / "neurips2026/AdaCLIP"
ADACLIP_OFFICIAL_VISA = ADACLIP_ROOT / "ckpt/pretrained_visa_clinicdb.pth"
ADACLIP_EVAL = ROOT / "neurips2026/scripts/official_parallel_test_adaclip.py"

ANOMALY_ROOT = ROOT / "neurips2026/AnomalyCLIP"
ANOMALY_OFFICIAL_VISA = ANOMALY_ROOT / "checkpoints/9_12_4_multiscale_visa/epoch_15.pth"
ANOMALY_EVAL = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"

ADACLIP_RETRAIN_RECIPES = ("earlylate", "mid2", "last2", "last")
ANOMALY_RETRAIN_RECIPES = ("earlylate", "mid2", "last2", "last", "all4")

ANOMALY_FEATURES = {
    "all4": [6, 12, 18, 24],
    "earlylate": [6, 24],
    "mid2": [12, 18],
    "last2": [18, 24],
    "last": [24],
}


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def latest_checkpoint(save_root: Path) -> Path:
    candidates = sorted(save_root.rglob("*_last.pth"), key=lambda p: p.stat().st_mtime)
    if not candidates:
        candidates = sorted(save_root.rglob("*.pth"), key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise FileNotFoundError(f"No checkpoint found under {save_root}")
    return candidates[-1]


def adaclip_env(base_env: dict[str, str]) -> dict[str, str]:
    env = dict(base_env)
    env["ADACLIP_VISA_ROOT"] = str(VISA_1CLS)
    env["ADACLIP_CLINICDB_ROOT"] = str(CLINICDB)
    env["ADACLIP_COLONDB_ROOT"] = str(COLONDB)
    env["ADACLIP_MVTEC_ROOT"] = str(MVTEC)
    return env


def eval_adaclip(recipe: str, checkpoint: Path, save_dir: Path, env: dict[str, str]) -> None:
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "summary": str(save_dir / "summary.json")}, flush=True)
        return
    run(
        [
            str(PY),
            "-u",
            str(ADACLIP_EVAL),
            "--source_root",
            str(VISA_1CLS),
            "--source_dataset",
            "visa",
            "--target_root",
            str(MVTEC),
            "--target_dataset",
            "mvtec",
            "--checkpoint_path",
            str(checkpoint),
            "--save_dir",
            str(save_dir),
            "--bank_cache_path",
            str(BANK / f"adaclip_visa_{recipe}_retrained.pt"),
            "--refresh_bank_cache",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--batch_size",
            "1",
            "--num_workers",
            "4",
            "--cpu_threads",
            "4",
            "--backbone",
            "ViT-L-14-336",
            "--checkpoint_load_mode",
            "strict",
            "--model_layer_recipe",
            recipe,
            "--layer_recipe",
            "all4",
            "--enable_calibrator",
            "--calib_epochs",
            "30",
            "--calib_subspace_rank",
            "8",
            "--calib_insertion_mode",
            "prescore_rectify",
            "--calib_train_score_space",
            "cache_prob",
            "--calib_lambda",
            "0.3",
            "--calib_eta_max",
            "1.0",
            "--scoring_mode",
            "logit_gate_posneg",
            "--ours_image_score_mode",
            "official_plus_map_topk",
            "--eval_metrics",
            "I-AUROC",
            "I-AP",
            "P-AUROC",
            "P-AP",
            "P-AUPRO",
            "--aupro_max_step",
            "200",
        ],
        ROOT,
        LOG / f"adaclip_eval_visa_{recipe}.log",
        env,
    )


def run_adaclip(base_env: dict[str, str]) -> None:
    env = adaclip_env(base_env)

    # Official baseline row, rebuilt here so the table root is self-contained.
    eval_adaclip("all4", ADACLIP_OFFICIAL_VISA, OUT / "adaclip_visa_all4_baseline_eval", env)

    for recipe in ADACLIP_RETRAIN_RECIPES:
        train_root = OUT / f"adaclip_visa_{recipe}_ckpt"
        try:
            ckpt = latest_checkpoint(train_root)
            print({"stage": "skip_train", "checkpoint": str(ckpt)}, flush=True)
        except FileNotFoundError:
            run(
                [
                    str(PY),
                    "-u",
                    "train.py",
                    "--save_fig",
                    "False",
                    "--training_data",
                    "visa",
                    "clinicdb",
                    "--testing_data",
                    "mvtec",
                    "--save_path",
                    str(train_root),
                    "--model",
                    "ViT-L-14-336",
                    "--layer_recipe",
                    recipe,
                    "--target_val_during_train",
                    "False",
                    "--save_last_ckpt",
                    "True",
                    "--epoch",
                    "5",
                    "--batch_size",
                    "1",
                    "--image_size",
                    "518",
                    "--prompting_depth",
                    "4",
                    "--prompting_length",
                    "5",
                    "--prompting_branch",
                    "VL",
                    "--prompting_type",
                    "SD",
                    "--use_hsf",
                    "True",
                    "--k_clusters",
                    "20",
                ],
                ADACLIP_ROOT,
                LOG / f"adaclip_train_visa_{recipe}.log",
                env,
            )
            ckpt = latest_checkpoint(train_root)
        eval_adaclip(recipe, ckpt, OUT / f"adaclip_visa_{recipe}_eval", env)


def train_anomalyclip(recipe: str, env: dict[str, str]) -> Path:
    features = ANOMALY_FEATURES[recipe]
    ckpt_dir = OUT / f"anomalyclip_visa_{recipe}_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if ckpt_path.exists():
        print({"stage": "skip_train", "checkpoint": str(ckpt_path)}, flush=True)
        return ckpt_path

    feature_map_layer = [str(i) for i in range(len(features))]
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "visa",
            "--train_data_path",
            str(VISA_1CLS),
            "--save_path",
            str(ckpt_dir),
            "--features_list",
            *[str(x) for x in features],
            "--feature_map_layer",
            *feature_map_layer,
            "--model_name_or_path",
            "ViT-L/14@336px",
            "--dpam_layer",
            "20",
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ],
        ANOMALY_ROOT,
        LOG / f"anomalyclip_train_visa_{recipe}.log",
        env,
    )
    return ckpt_path


def eval_anomalyclip(recipe: str, checkpoint: Path, save_dir: Path, env: dict[str, str]) -> None:
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "summary": str(save_dir / "summary.json")}, flush=True)
        return

    features = ANOMALY_FEATURES[recipe]
    run(
        [
            str(PY),
            "-u",
            str(ANOMALY_EVAL),
            "--device",
            "cuda:0",
            "--checkpoint_path",
            str(checkpoint),
            "--model_name_or_path",
            "ViT-L/14@336px",
            "--heldout_class",
            "none",
            "--source_root",
            str(VISA_1CLS),
            "--source_dataset",
            "visa",
            "--target_root",
            str(MVTEC),
            "--target_dataset",
            "mvtec",
            "--target_mode",
            "test",
            "--baseline_features_list",
            *[str(x) for x in features],
            "--features_list",
            *[str(x) for x in features],
            "--dpam_layer",
            "20",
            "--image_size",
            "518",
            "--sigma",
            "4",
            "--host_patch_score_mode",
            "prob",
            "--baseline_patch_score_mode",
            "prob",
            "--hard_frac",
            "0.01",
            "--max_good_per_class",
            "8",
            "--max_defect_per_class",
            "8",
            "--max_bank_per_layer",
            "2048",
            "--max_fp_per_image",
            "64",
            "--max_defect_per_image",
            "64",
            "--score_bank_cache_path",
            str(BANK / f"anomalyclip_visa_{recipe}_withscores.pt"),
            "--refresh_bank_cache",
            "--enable_calibrator",
            "--calib_seed",
            "0",
            "--calib_epochs",
            "80",
            "--calib_subspace_rank",
            "8",
            "--calib_eta_max",
            "0.5",
            "--calib_lambda",
            "0.1",
            "--calib_map_anchor",
            "host",
            "--ted_image_score_mode",
            "host_plus_norm_topk",
            "--parallel_image_fusion_weight",
            "-0.2",
            "--calibrated_image_fusion_weight",
            "-0.02",
            "--skip_separability_metrics",
            "--save_dir",
            str(save_dir),
        ],
        ROOT,
        LOG / f"anomalyclip_eval_visa_{recipe}.log",
        env,
    )


def run_anomalyclip(env: dict[str, str]) -> None:
    # Official full-layer baseline row.
    eval_anomalyclip("all4", ANOMALY_OFFICIAL_VISA, OUT / "anomalyclip_visa_all4_baseline_eval", env)

    for recipe in ANOMALY_RETRAIN_RECIPES:
        ckpt = train_anomalyclip(recipe, env)
        eval_anomalyclip(recipe, ckpt, OUT / f"anomalyclip_visa_{recipe}_eval", env)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    BANK.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-layer-retrained-all-20260502")

    run_adaclip(env)
    run_anomalyclip(env)
    print({"stage": "done", "root": str(OUT)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
