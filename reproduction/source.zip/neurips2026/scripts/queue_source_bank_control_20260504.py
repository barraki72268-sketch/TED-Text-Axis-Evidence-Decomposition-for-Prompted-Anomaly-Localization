#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "source_bank_control_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "source_bank_control_20260504"


def faprompt_cmd(mode: str, device: str, seed: int, preset: str) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"faprompt_vitl336_{preset}_{mode}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        mode,
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir


def aaclip_cmd(mode: str, device: str, seed: int, preset: str) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"aaclip_vith14_{preset}_{mode}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-H-14",
        "--pretrained",
        "laion2b_s32b_b79k",
        "--adapter_load_mode",
        "project_crop",
        "--levels",
        "8,16,24,32",
        "--img_size",
        "224",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        mode,
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir


def aaclip_official_cmd(mode: str, device: str, seed: int, preset: str) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_{mode}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        mode,
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir


def launch(cmd: list[str], save_dir: Path, log_path: Path, force: bool) -> dict:
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        return {"stage": "skip_done", "summary": str(summary)}
    save_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = log_path.open("ab", buffering=0)
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        stdout=log_f,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {"stage": "launched", "pid": proc.pid, "save_dir": str(save_dir), "log": str(log_path)}


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="aaclip,faprompt")
    ap.add_argument("--presets", default="mvtec2btad")
    ap.add_argument("--modes", default="random_normal,easy_normal")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = parse_csv(args.hosts)
    presets = parse_csv(args.presets)
    modes = parse_csv(args.modes)
    devices = parse_csv(args.devices)
    if not devices:
        raise SystemExit("--devices cannot be empty")
    for mode in modes:
        if mode not in {"random_normal", "easy_normal"}:
            raise SystemExit(f"Unsupported control mode: {mode}")

    jobs = []
    for host in hosts:
        for preset in presets:
            for mode in modes:
                device = devices[len(jobs) % len(devices)]
                if host == "aaclip":
                    cmd, save_dir = aaclip_cmd(mode, device, args.seed, preset)
                elif host in {"aaclip_official", "aaclip_vitl_openai224"}:
                    cmd, save_dir = aaclip_official_cmd(mode, device, args.seed, preset)
                elif host == "faprompt":
                    cmd, save_dir = faprompt_cmd(mode, device, args.seed, preset)
                else:
                    raise SystemExit(f"Unsupported host: {host}")
                log_path = LOGS / f"{host}_{preset}_{mode}_seed{args.seed}.log"
                jobs.append((cmd, save_dir, log_path))

    launched = [launch(cmd, save_dir, log_path, args.force) for cmd, save_dir, log_path in jobs]
    print(json.dumps({"stage": "source_bank_control_queue", "jobs": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
