from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)


RECIPES = ["Full(B)", "EL-r", "M2-r", "L2-r", "L-r"]


DATA = {
    "VisA to MVTec": {
        "AdaCLIP": {
            "Full(B)": {"B": {"PRO": 44.03, "AP": 41.60}, "C": {"PRO": 47.97, "AP": 41.85}},
            "EL-r": {"B": {"PRO": 18.18, "AP": 22.40}, "C": {"PRO": 26.25, "AP": 23.81}},
            "M2-r": {"B": {"PRO": 23.50, "AP": 36.18}, "C": {"PRO": 25.42, "AP": 36.40}},
            "L2-r": {"B": {"PRO": 15.19, "AP": 36.35}, "C": {"PRO": 22.78, "AP": 39.28}},
            "L-r": {"B": {"PRO": 34.83, "AP": 35.78}, "C": {"PRO": 46.27, "AP": 36.77}},
        },
        "FAPrompt": {
            "Full(B)": {"B": {"PRO": 73.57, "AP": 22.35}, "C": {"PRO": 76.83, "AP": 30.94}},
            "EL-r": {"B": {"PRO": 74.70, "AP": 23.58}, "C": {"PRO": 77.16, "AP": 32.40}},
            "M2-r": {"B": {"PRO": 74.35, "AP": 22.58}, "C": {"PRO": 76.54, "AP": 31.46}},
            "L2-r": {"B": {"PRO": 72.73, "AP": 22.33}, "C": {"PRO": 76.63, "AP": 31.07}},
            "L-r": {"B": {"PRO": 74.01, "AP": 23.01}, "C": {"PRO": 76.08, "AP": 31.68}},
        },
    },
    "MVTec to VisA": {
        "AdaCLIP": {
            "Full(B)": {"B": {"PRO": 54.13, "AP": 31.48}, "C": {"PRO": 65.18, "AP": 31.32}},
            "L2-r": {"B": {"PRO": 63.13, "AP": 22.25}, "C": {"PRO": 68.26, "AP": 22.61}},
            "L-r": {"B": {"PRO": 50.61, "AP": 21.52}, "C": {"PRO": 58.91, "AP": 21.05}},
        },
        "FAPrompt": {
            "Full(B)": {"B": {"PRO": 79.34, "AP": 13.61}, "C": {"PRO": 82.08, "AP": 19.23}},
            "L-r": {"B": {"PRO": 77.29, "AP": 13.46}, "C": {"PRO": 81.29, "AP": 18.71}},
        },
    },
}


STYLE = {
    ("AdaCLIP", "PRO"): dict(color="#1B5E8A", marker="o", linestyle="-", label="AdaCLIP PRO"),
    ("AdaCLIP", "AP"): dict(color="#1B5E8A", marker="s", linestyle="--", label="AdaCLIP AP"),
    ("FAPrompt", "PRO"): dict(color="#B45F06", marker="o", linestyle="-", label="FAPrompt PRO"),
    ("FAPrompt", "AP"): dict(color="#B45F06", marker="s", linestyle="--", label="FAPrompt AP"),
}


def gains(direction, host, metric):
    values = []
    for recipe in RECIPES:
        item = DATA[direction].get(host, {}).get(recipe)
        if item is None:
            values.append(np.nan)
            continue
        values.append(item["C"][metric] - item["B"][metric])
    return np.asarray(values, dtype=float)


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 12,
            "axes.titlesize": 15,
            "axes.labelsize": 13,
            "xtick.labelsize": 12,
            "ytick.labelsize": 12,
            "legend.fontsize": 11,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig, ax = plt.subplots(1, 1, figsize=(5.8, 3.55))
    x = np.arange(len(RECIPES))

    direction = "VisA to MVTec"
    for host in ["AdaCLIP", "FAPrompt"]:
        for metric in ["PRO", "AP"]:
            y = gains(direction, host, metric)
            style = STYLE[(host, metric)]
            ax.plot(x, y, linewidth=2.6, markersize=6.5, **style)

    ax.axhline(0, color="#555555", linewidth=1.0)
    ax.set_title("(a) Layer-wise retraining", fontweight="bold", pad=8)
    ax.set_xticks(x)
    ax.set_xticklabels(RECIPES, rotation=28, ha="right")
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_xlim(-0.35, len(RECIPES) - 0.65)
    ax.set_ylim(-1.4, 12.6)
    ax.set_ylabel("C-TED gain over B")

    handles, labels = ax.get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 1.08),
        frameon=False,
        ncol=2,
        handlelength=2.2,
        columnspacing=1.4,
    )

    fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.94))
    pdf = FIG_DIR / "layer_recipe_retrain_ab_20260503.pdf"
    png = FIG_DIR / "layer_recipe_retrain_ab_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")

    tex = OUT_DIR / "layer_recipe_retrain_ab_figure_20260503.tex"
    tex.write_text(
        r"""\begin{figure}[t]
\centering
\includegraphics[width=0.82\linewidth]{figure/layer_recipe_retrain_ab_20260503.pdf}
\caption{
Layer-wise retraining diagnostic on VisA$\rightarrow$MVTec.
Each point reports the source-calibrated TED gain over the retrained host baseline for PRO and AP.
Even after retraining the host for each layer recipe, the local ranking remains recipe-sensitive and C-TED provides a source-only correction.
}
\label{fig:layer_recipe_retrain_ab}
\end{figure}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)


if __name__ == "__main__":
    main()
