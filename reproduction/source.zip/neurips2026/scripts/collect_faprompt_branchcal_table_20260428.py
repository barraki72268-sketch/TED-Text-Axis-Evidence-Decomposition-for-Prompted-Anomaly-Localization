#!/usr/bin/env python3
"""Collect FAPrompt branch-calibrated transfer results into LaTeX rows.

The main table keeps FAPrompt's official image-level score unchanged for OURS
and reports the corrected map only for pixel-level metrics. This separates the
image-score aggregation rule from the localization correction.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import mean, pstdev


TARGETS = [
    ("visa2mvtec", "MVTec"),
    ("mvtec2visa", "VisA"),
    ("mvtec2mpdd", "MPDD"),
    ("mvtec2btad", "BTAD"),
]

BACKBONES = [
    (
        "vitb16plus",
        "ViT-B/16+",
        "faprompt_branchcal_vitb16plus_f3-6-9-12_dpam10_{preset}_rank4_a02_{img}_seed{seed}_20260428",
    ),
    (
        "vitl14openai",
        "ViT-L/14 OpenAI",
        "faprompt_branchcal_vitl14openai_f6-12-18-24_dpam20_{preset}_rank4_a02_{img}_seed{seed}_20260428",
    ),
    (
        "vitl14_336",
        "ViT-L/14-336",
        "faprompt_branchcal_vitl14_336_f6-12-18-24_dpam20_{preset}_rank4_a02_{img}_seed{seed}_20260428",
    ),
    (
        "vith14",
        "ViT-H/14",
        "faprompt_branchcal_vith14_f8-16-24-32_dpam27_{preset}_rank4_a02_{img}_seed{seed}_20260428",
    ),
]

METRICS = [
    ("image_auc", "I-AUROC"),
    ("pixel_auc", "P-AUROC"),
    ("pixel_aupro", "P-PRO"),
    ("pixel_ap", "P-AP"),
]


def load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def find_summary(root: Path, template: str, preset: str, seed: int) -> tuple[Path | None, dict | None]:
    # Prefer official-image-score runs. Fall back to older corrected_topk runs:
    # pixel metrics are identical for the same corrected map; image score is
    # explicitly overwritten from the official baseline in collect_metrics().
    for img in ("officialimg", "topkimg"):
        path = root / template.format(preset=preset, img=img, seed=seed) / "summary.json"
        data = load_json(path)
        if data is not None:
            return path, data
    return None, None


def get_alpha_result(summary: dict, alpha: float) -> dict:
    key = f"branch_calibrated_alpha_{alpha:g}"
    if key in summary.get("parallel", {}):
        return summary["parallel"][key]
    # JSON keys sometimes preserve one decimal place.
    key = f"branch_calibrated_alpha_{alpha:.1f}"
    if key in summary.get("parallel", {}):
        return summary["parallel"][key]
    raise KeyError(f"Missing alpha result: {key}")


def collect_metrics(summary: dict, alpha: float, official_image: bool) -> tuple[dict, dict]:
    if "mean" in summary:
        summary = summary["mean"]
    base = summary["baseline_official"]
    ours = dict(get_alpha_result(summary, alpha))
    if official_image:
        ours["image_auc"] = base["image_auc"]
    return base, ours


def fmt_stat(values: list[float], bold: bool = False) -> str:
    if not values:
        return "--.--"
    m = mean(values) * 100.0
    s = pstdev(values) * 100.0 if len(values) > 1 else 0.0
    body = f"{m:.2f}{{\\scriptsize $\\pm${s:.2f}}}"
    return f"\\textbf{{{body}}}" if bold else body


def fmt_row(
    host: str,
    backbone: str,
    target: str,
    method: str,
    metric_values: dict[str, list[float]],
    bold_mask: dict[str, bool],
    first_host: bool,
    first_backbone: bool,
    target_rule: str,
) -> str:
    host_cell = host if first_host else ""
    backbone_cell = backbone if first_backbone else ""
    metrics = " & ".join(
        fmt_stat(metric_values[name], bold=bold_mask.get(name, False)) for name, _ in METRICS
    )
    return f"{host_cell} & {backbone_cell} & {target} & {method} & {metrics} \\\\"


def emit_table(args: argparse.Namespace) -> None:
    root = Path(args.results_root)
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    alpha = float(args.alpha)
    official_image = args.image_rule == "official"

    print(r"\begin{table*}[t]")
    print(r"\centering")
    print(
        "\\caption{FAPrompt with host-anchored branch residual subspace correction "
        f"($\\alpha={alpha:g}$). OURS keeps the official image score and corrects only "
        "the localization map. Each entry is mean{\\scriptsize $\\pm$std}.}"
    )
    print(r"\label{tab:faprompt_hostres_branch_datasetwise}")
    print(r"\small")
    print(r"\setlength{\tabcolsep}{4pt}")
    print(r"\renewcommand{\arraystretch}{1.08}")
    print(r"\resizebox{\textwidth}{!}{")
    print(r"\begin{tabular}{lllc cccc}")
    print(r"\toprule")
    print(r"Host & Backbone & Target & Method & I-AUROC & P-AUROC & P-PRO & P-AP \\")
    print(r"\midrule")

    total_backbone_rows = len(BACKBONES) * len(TARGETS) * 2
    host_printed = False
    for b_idx, (_, backbone_label, template) in enumerate(BACKBONES):
        for t_idx, (preset, target_label) in enumerate(TARGETS):
            base_values = {name: [] for name, _ in METRICS}
            ours_values = {name: [] for name, _ in METRICS}
            used_seeds = []
            missing = []
            for seed in seeds:
                path, summary = find_summary(root, template, preset, seed)
                if summary is None:
                    missing.append(seed)
                    continue
                base, ours = collect_metrics(summary, alpha=alpha, official_image=official_image)
                for name, _ in METRICS:
                    base_values[name].append(float(base[name]))
                    ours_values[name].append(float(ours[name]))
                used_seeds.append(seed)

            bold_base = {}
            bold_ours = {}
            for name, _ in METRICS:
                if base_values[name] and ours_values[name]:
                    mb = mean(base_values[name])
                    mo = mean(ours_values[name])
                    bold_base[name] = mb > mo
                    bold_ours[name] = mo > mb

            host_cell = rf"\multirow{{{total_backbone_rows}}}{{*}}{{FAPrompt}}" if not host_printed else ""
            backbone_cell = rf"\multirow{{{len(TARGETS) * 2}}}{{*}}{{{backbone_label}}}" if t_idx == 0 else ""
            target_rule = ""
            if missing:
                target_rule = f"missing seeds: {','.join(map(str, missing))}"

            print(
                fmt_row(
                    host_cell,
                    backbone_cell,
                    rf"\multirow{{2}}{{*}}{{{target_label}}}",
                    "Base",
                    base_values,
                    bold_base,
                    first_host=True,
                    first_backbone=True,
                    target_rule=target_rule,
                )
            )
            print(
                fmt_row(
                    "",
                    "",
                    "",
                    "OURS",
                    ours_values,
                    bold_ours,
                    first_host=True,
                    first_backbone=True,
                    target_rule=f"alpha={alpha:g}, seeds={','.join(map(str, used_seeds))}",
                )
            )
            if t_idx != len(TARGETS) - 1:
                print(r"\cmidrule(lr){3-8}")
            host_printed = True
        if b_idx != len(BACKBONES) - 1:
            print(r"\midrule")

    print(r"\bottomrule")
    print(r"\end{tabular}")
    print(r"}")
    print(r"\end{table*}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results_root", default="neurips2026/results")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--alpha", default="0.5")
    ap.add_argument("--image_rule", choices=["official", "corrected_topk"], default="official")
    ap.add_argument("--backbones", default="vitb16plus,vitl14openai,vitl14_336,vith14")
    args = ap.parse_args()
    keep = {x.strip() for x in args.backbones.split(",") if x.strip()}
    global BACKBONES
    BACKBONES = [entry for entry in BACKBONES if entry[0] in keep]
    emit_table(args)


if __name__ == "__main__":
    main()
