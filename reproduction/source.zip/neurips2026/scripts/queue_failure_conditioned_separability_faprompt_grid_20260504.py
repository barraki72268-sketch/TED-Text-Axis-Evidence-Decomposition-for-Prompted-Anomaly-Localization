#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_faprompt.py"
RESULTS = ROOT / "neurips2026" / "results" / "failure_conditioned_separability_grid_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "failure_conditioned_separability_grid_20260504"

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]

BACKBONES = {
    "vitl336": {
        "model_name": "ViT-L/14@336px",
        "prompt_load_mode": "strict",
        "features": [6, 12, 18, 24],
        "dpam_layer": 20,
        "batch_size": 4,
    },
    "vitl_openai": {
        "model_name": "ViT-L/14",
        "prompt_load_mode": "strict",
        "features": [6, 12, 18, 24],
        "dpam_layer": 20,
        "batch_size": 4,
    },
    "vith14": {
        "model_name": "ViT-H-14",
        "prompt_load_mode": "project_crop",
        "features": [8, 16, 24, 32],
        "dpam_layer": 30,
        "batch_size": 4,
    },
}


def build_cmd(backbone: str, preset: str, device: str) -> tuple[list[str], Path, Path]:
    cfg = BACKBONES[backbone]
    save_dir = RESULTS / f"faprompt_{backbone}_{preset}"
    log_path = LOGS / f"faprompt_{backbone}_{preset}.log"
    cmd = [
        str(PY),
        "-u",
        str(SCRIPT.relative_to(ROOT)),
        "--preset",
        preset,
        "--model_name",
        cfg["model_name"],
        "--prompt_load_mode",
        cfg["prompt_load_mode"],
        "--features_list",
        *[str(x) for x in cfg["features"]],
        "--image_size",
        "518",
        "--batch_size",
        str(cfg["batch_size"]),
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        str(cfg["dpam_layer"]),
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        "0",
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def worker_script(jobs: list[tuple[str, str, str]], worker_id: int) -> Path:
    script = LOGS / f"worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        "jobs = [",
    ]
    for backbone, preset, device in jobs:
        cmd, save_dir, log_path = build_cmd(backbone, preset, device)
        lines.append(f"    ({cmd!r}, {str(save_dir)!r}, {str(log_path)!r}),")
    lines += [
        "]",
        "for cmd, save_dir, log_path in jobs:",
        "    summary = Path(save_dir) / 'summary.json'",
        "    Path(log_path).parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists():",
        "        print({'stage': 'skip', 'summary': str(summary)}, flush=True)",
        "        continue",
        "    print({'stage': 'run', 'save_dir': save_dir, 'log': log_path}, flush=True)",
        "    with open(log_path, 'w') as f:",
        "        subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, check=False)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    script.write_text("\n".join(lines))
    return script


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--backbones", default="vitl_openai,vith14")
    ap.add_argument("--include_vitl336", action="store_true")
    args = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    devices = [x.strip() for x in args.devices.split(",") if x.strip()]
    backbones = [x.strip() for x in args.backbones.split(",") if x.strip()]
    if args.include_vitl336 and "vitl336" not in backbones:
        backbones = ["vitl336", *backbones]

    jobs = []
    for backbone in backbones:
        if backbone not in BACKBONES:
            raise SystemExit(f"Unknown backbone {backbone}; allowed={sorted(BACKBONES)}")
        for preset in PRESETS:
            jobs.append((backbone, preset, devices[len(jobs) % len(devices)]))

    buckets = [[] for _ in devices]
    for i, job in enumerate(jobs):
        buckets[i % len(devices)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        script = worker_script(bucket, worker_id)
        log = LOGS / f"worker_{worker_id}.log"
        with log.open("a") as f:
            proc = subprocess.Popen([str(PY), str(script)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "log": str(log), "script": str(script)})

    print(json.dumps({"stage": "queued_faprompt_grid", "launched": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
