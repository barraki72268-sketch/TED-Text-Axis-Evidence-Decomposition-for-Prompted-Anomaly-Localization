from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_wrongclass_semantic_collapse import (  # noqa: E402
    MVTED_CKPT,
    MVTED_ROOT,
    OFFICIAL_VISA_ROOT,
    BTAD_ROOT,
    MPDD_ROOT,
    aggregate_map_from_patch_features,
    build_eval_dataset,
    build_model,
    build_reference_text_model,
    get_learned_text_pair,
    global_image_score,
    load_prompt_learner,
    mask_overlap,
    safe_auc,
    safe_corr,
    static_text_pair_for_class,
    top_fraction_mask,
)


PRESET_TO_RESULT = {
    "visa2mvtec": ROOT / "neurips2026" / "results" / "anomalyclip_wrongclass_semantic_collapse_visa2mvtec_x1_rerun2",
    "mvtec2visa": ROOT / "neurips2026" / "results" / "anomalyclip_wrongclass_semantic_collapse_mvtec2visa_x1_rerun2",
    "mvtec2mpdd": ROOT / "neurips2026" / "results" / "anomalyclip_wrongclass_semantic_collapse_mvtec2mpdd_x1_rerun2",
    "mvtec2btad": ROOT / "neurips2026" / "results" / "anomalyclip_wrongclass_semantic_collapse_mvtec2btad_x1_rerun2",
}

PRESET_TO_TARGET = {
    "visa2mvtec": (str(MVTED_ROOT), "mvtec"),
    "mvtec2visa": (str(OFFICIAL_VISA_ROOT), "visa"),
    "mvtec2mpdd": (str(MPDD_ROOT), "mpdd"),
    "mvtec2btad": (str(BTAD_ROOT), "btad"),
}

PRESET_TO_CKPT = {
    "visa2mvtec": ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth",
    "mvtec2visa": MVTED_CKPT,
    "mvtec2mpdd": MVTED_CKPT,
    "mvtec2btad": MVTED_CKPT,
}

PROMPT_NOTE = (
    "Static prompt ensemble per class:\n"
    "normal states = {c}, flawless {c}, perfect {c}, {c} without defect, ...\n"
    "abnormal states = damaged {c}, broken {c}, {c} with flaw/defect/damage, ...\n"
    "Each state is wrapped by 35 CLIP templates and averaged."
)


def load_rows(metrics_path: Path) -> list[dict]:
    return [json.loads(line) for line in metrics_path.read_text().splitlines() if line.strip()]


def collapse_score(row: dict) -> float:
    return (
        row["mean_true_wrong_corr"]
        + row["mean_true_wrong_topk_overlap"]
        + (row["learned_vs_mean_wrong_topk_overlap"] - row["learned_vs_true_topk_overlap"])
        - row["true_minus_wrong_mean_local_auc"]
    )


def normalize_img(t: torch.Tensor) -> np.ndarray:
    img = t.detach().cpu().numpy().transpose(1, 2, 0)
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = img * std + mean
    return np.clip(img, 0.0, 1.0)


def choose_wrong_prompt(
    candidate_classes: list[str],
    cls_name: str,
    learned_map: np.ndarray,
    true_map: np.ndarray,
    gt_mask: np.ndarray,
    prompt_maps: dict[str, np.ndarray],
    prompt_image_scores: dict[str, float],
    prompt_local_auc: dict[str, float],
    map_topk: float,
) -> tuple[str, dict]:
    true_mask = top_fraction_mask(true_map, map_topk)
    learned_mask = top_fraction_mask(learned_map, map_topk)
    best_name = None
    best_info = None
    best_score = -1e9
    for wrong_cls in candidate_classes:
        if wrong_cls == cls_name:
            continue
        wrong_map = prompt_maps[wrong_cls]
        wrong_mask = top_fraction_mask(wrong_map, map_topk)
        info = {
            "corr_true_wrong": safe_corr(true_map, wrong_map),
            "overlap_true_wrong": mask_overlap(true_mask, wrong_mask),
            "iou_true_wrong": float(np.logical_and(true_mask, wrong_mask).sum()) / max(
                1.0, float(np.logical_or(true_mask, wrong_mask).sum())
            ),
            "learned_vs_wrong_corr": safe_corr(learned_map, wrong_map),
            "learned_vs_wrong_overlap": mask_overlap(learned_mask, wrong_mask),
            "wrong_image_score": prompt_image_scores[wrong_cls],
            "wrong_local_auc": prompt_local_auc[wrong_cls],
            "wrong_minus_true_local_auc": prompt_local_auc[wrong_cls] - prompt_local_auc[cls_name],
        }
        score = (
            info["corr_true_wrong"]
            + info["overlap_true_wrong"]
            + info["learned_vs_wrong_overlap"]
            + max(0.0, info["wrong_minus_true_local_auc"])
        )
        if score > best_score:
            best_score = score
            best_name = wrong_cls
            best_info = info
    assert best_name is not None and best_info is not None
    return best_name, best_info


def overlay_heatmap(ax, image: np.ndarray, heatmap: np.ndarray, title: str) -> None:
    ax.imshow(image)
    ax.imshow(heatmap, cmap="turbo", alpha=0.55, vmin=float(np.min(heatmap)), vmax=float(np.max(heatmap)))
    ax.set_title(title, fontsize=10)
    ax.axis("off")


def overlay_mask(ax, image: np.ndarray, mask: np.ndarray, title: str) -> None:
    ax.imshow(image)
    ax.imshow(np.ma.masked_where(~mask, mask), cmap="Reds", alpha=0.45)
    ax.set_title(title, fontsize=10)
    ax.axis("off")


def metric_box_text(preset: str, cls_name: str, true_info: dict, wrong_name: str, wrong_info: dict) -> str:
    return (
        f"{preset}\n"
        f"true class: {cls_name}\n"
        f"wrong class: {wrong_name}\n\n"
        f"image score\n"
        f" true = {true_info['true_image_score']:.3f}\n"
        f" wrong = {wrong_info['wrong_image_score']:.3f}\n\n"
        f"local AUC\n"
        f" true = {true_info['true_local_auc']:.3f}\n"
        f" wrong = {wrong_info['wrong_local_auc']:.3f}\n\n"
        f"true vs wrong\n"
        f" corr = {wrong_info['corr_true_wrong']:.3f}\n"
        f" overlap = {wrong_info['overlap_true_wrong']:.3f}\n\n"
        f"learned vs true\n"
        f" corr = {true_info['learned_vs_true_corr']:.3f}\n"
        f" overlap = {true_info['learned_vs_true_overlap']:.3f}\n\n"
        f"learned vs wrong\n"
        f" corr = {wrong_info['learned_vs_wrong_corr']:.3f}\n"
        f" overlap = {wrong_info['learned_vs_wrong_overlap']:.3f}"
    )


def main() -> None:
    parser = argparse.ArgumentParser("Generate semantic-collapse qualitative figure")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_semantic_collapse_figure"),
    )
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    selections = {}
    for preset, result_dir in PRESET_TO_RESULT.items():
        rows = load_rows(result_dir / "metrics.jsonl")
        best = max(rows, key=collapse_score)
        selections[preset] = best

    fig, axes = plt.subplots(4, 5, figsize=(20, 15))
    fig.subplots_adjust(top=0.88, hspace=0.28, wspace=0.05)
    fig.suptitle(
        "Semantic Collapse in Dense Anomaly Localization\n"
        "True-class prompt vs most-confusing wrong-class prompt vs learned AD map",
        fontsize=18,
        y=0.97,
    )
    fig.text(0.02, 0.905, PROMPT_NOTE, fontsize=10, va="top", family="monospace")

    metadata = {"prompt_note": PROMPT_NOTE, "selections": {}}

    for row_idx, (preset, best_row) in enumerate(selections.items()):
        target_root, target_dataset = PRESET_TO_TARGET[preset]
        checkpoint = PRESET_TO_CKPT[preset]
        dataset = build_eval_dataset(target_root, target_dataset, args.image_size, mode="test")
        item = dataset[best_row["image_id"]]
        cls_name = item["cls_name"]
        image = item["img"].unsqueeze(0).to(args.device)
        image_np = normalize_img(item["img"])
        mask_tensor = item["img_mask"]
        gt_mask = (mask_tensor.squeeze().detach().cpu().numpy() > 0.5) if torch.is_tensor(mask_tensor) else (np.asarray(mask_tensor).squeeze() > 0.5)

        model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
        learner = load_prompt_learner(model, params, Path(checkpoint), args.device)
        learned_pair = get_learned_text_pair(model, learner).to(args.device)
        reference_model = build_reference_text_model(args.device)
        candidate_classes = list(dataset.obj_list)

        with torch.inference_mode():
            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            learned_map = aggregate_map_from_patch_features(patch_features, learned_pair, args.image_size, args.sigma)

            prompt_maps = {}
            prompt_image_scores = {}
            prompt_local_auc = {}
            for prompt_cls in candidate_classes:
                pair = static_text_pair_for_class(reference_model, prompt_cls, args.device)
                score_map = aggregate_map_from_patch_features(patch_features, pair, args.image_size, args.sigma)
                prompt_maps[prompt_cls] = score_map
                prompt_image_scores[prompt_cls] = global_image_score(image_features, pair)
                prompt_local_auc[prompt_cls] = safe_auc(score_map[gt_mask], score_map[~gt_mask])
                del pair

        true_map = prompt_maps[cls_name]
        wrong_name, wrong_info = choose_wrong_prompt(
            candidate_classes,
            cls_name,
            learned_map,
            true_map,
            gt_mask,
            prompt_maps,
            prompt_image_scores,
            prompt_local_auc,
            args.map_topk,
        )
        true_mask = top_fraction_mask(true_map, args.map_topk)
        learned_mask = top_fraction_mask(learned_map, args.map_topk)
        true_info = {
            "true_image_score": prompt_image_scores[cls_name],
            "true_local_auc": prompt_local_auc[cls_name],
            "learned_vs_true_corr": safe_corr(learned_map, true_map),
            "learned_vs_true_overlap": mask_overlap(learned_mask, true_mask),
        }

        overlay_mask(axes[row_idx, 0], image_np, gt_mask, f"{preset}\ninput + GT")
        overlay_heatmap(axes[row_idx, 1], image_np, true_map, f"true prompt: {cls_name}")
        overlay_heatmap(axes[row_idx, 2], image_np, prompt_maps[wrong_name], f"wrong prompt: {wrong_name}")
        overlay_heatmap(axes[row_idx, 3], image_np, learned_map, "learned AD map")
        axes[row_idx, 4].axis("off")
        axes[row_idx, 4].text(
            0.0,
            1.0,
            metric_box_text(preset, cls_name, true_info, wrong_name, wrong_info),
            va="top",
            ha="left",
            fontsize=9,
            family="monospace",
        )

        metadata["selections"][preset] = {
            "image_id": int(best_row["image_id"]),
            "class_name": cls_name,
            "wrong_class": wrong_name,
            "collapse_score": float(collapse_score(best_row)),
            "metrics": {
                **true_info,
                **wrong_info,
            },
            "img_path": item["img_path"],
        }

        del model, params, learner, learned_pair, reference_model, image, image_features, patch_features
        torch.cuda.empty_cache()

    png_path = save_dir / "semantic_collapse_4preset_examples.png"
    pdf_path = save_dir / "semantic_collapse_4preset_examples.pdf"
    json_path = save_dir / "semantic_collapse_4preset_examples.json"
    fig.savefig(png_path, dpi=200, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    json_path.write_text(json.dumps(metadata, indent=2))
    print(json.dumps({"png": str(png_path), "pdf": str(pdf_path), "json": str(json_path)}, indent=2))


if __name__ == "__main__":
    main()
