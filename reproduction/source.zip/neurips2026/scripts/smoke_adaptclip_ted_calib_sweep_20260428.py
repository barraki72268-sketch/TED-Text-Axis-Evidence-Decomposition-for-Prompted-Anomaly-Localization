from __future__ import annotations

import json
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaptclip_vlrefine.py"
CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
BANK = ROOT / "neurips2026" / "results" / "bank_cache" / "adaptclip_ted_mvtec_vl_lastlayer_seed0.pt"
OUT_ROOT = ROOT / "neurips2026" / "results"


BASE_ARGS = [
    str(PYTHON),
    str(SCRIPT),
    "--source_root",
    str(MVTEC_ROOT),
    "--source_dataset",
    "mvtec",
    "--target_root",
    str(VISA_ROOT),
    "--target_dataset",
    "visa",
    "--checkpoint_path",
    str(CKPT),
    "--bank_cache_path",
    str(BANK),
    "--class_name",
    "candle",
    "--pretrained_model",
    "ViT-L/14@336px",
    "--features_list",
    "24",
    "--image_size",
    "518",
    "--batch_size",
    "8",
    "--n_ctx",
    "12",
    "--sigma",
    "4",
    "--vl_reduction",
    "4",
    "--fusion_type",
    "average_mean",
    "--tau",
    "20.0",
    "--fp_weight",
    "0.3",
    "--corr_alpha",
    "0.3",
    "--map_activation",
    "sigmoid",
    "--map_temperature",
    "1.0",
    "--vl_gate_mode",
    "host",
    "--vl_gate_quantile",
    "0.9",
    "--vl_gate_temp",
    "0.25",
    "--max_good_per_class",
    "2",
    "--max_defect_per_class",
    "4",
    "--max_bank_points",
    "512",
    "--max_fp_per_image",
    "64",
    "--max_defect_per_image",
    "64",
    "--calib_epochs",
    "30",
    "--calib_lr",
    "0.02",
    "--calib_max_train_points",
    "2048",
    "--calib_rank_margin",
    "0.05",
    "--calib_rank_temp",
    "0.05",
    "--calib_eta_init",
    "0.2",
    "--calib_eta_reg",
    "0.001",
    "--calib_fp_weight_init",
    "1.0",
    "--calib_hardpair_frac",
    "0.75",
    "--calib_subspace_rank",
    "8",
    "--seed",
    "0",
    "--eval_metrics",
    "I-AUROC",
    "I-AP",
    "P-AUROC",
    "P-AP",
    "--device",
    "cuda:1",
    "--num_workers",
    "4",
]


VARIANTS = [
    {
        "name": "keep1_lam03_eta1",
        "extra": ["--calib_eta_max", "1.0", "--calib_preserve_host_margin_weight", "1.0", "--calib_lambda", "0.3"],
    },
    {
        "name": "keep0_lam03_eta1",
        "extra": ["--calib_eta_max", "1.0", "--calib_preserve_host_margin_weight", "0.0", "--calib_lambda", "0.3"],
    },
    {
        "name": "keep0_lam05_eta2",
        "extra": ["--calib_eta_max", "2.0", "--calib_preserve_host_margin_weight", "0.0", "--calib_lambda", "0.5"],
    },
    {
        "name": "keep0_lam05_eta2_learnfp",
        "extra": [
            "--calib_eta_max",
            "2.0",
            "--calib_preserve_host_margin_weight",
            "0.0",
            "--calib_lambda",
            "0.5",
            "--calib_learn_fp_weight",
        ],
    },
]


def mean_rows(summary_path: Path) -> dict[str, dict]:
    data = json.load(open(summary_path))
    rows = {}
    for row in data["rows"]:
        if row["target_label"] == "mean":
            rows[row["mode"]] = row
    return rows


def fmt(row: dict) -> str:
    return (
        f"I={row['image_auroc']*100:.2f} "
        f"P={row['pixel_auroc']*100:.2f} "
        f"PRO={row['pixel_aupro']*100:.2f} "
        f"AP={row['pixel_ap']*100:.2f}"
    )


def main() -> None:
    for variant in VARIANTS:
        save_dir = OUT_ROOT / f"adaptclip_smoke_mvtec2visa_candle_gated_{variant['name']}_20260428"
        summary = save_dir / "summary.json"
        if not summary.exists():
            cmd = BASE_ARGS + ["--save_dir", str(save_dir)] + variant["extra"]
            print(f"[run] {variant['name']}", flush=True)
            subprocess.run(cmd, cwd=str(ROOT), check=True)
        rows = mean_rows(summary)
        print(f"\n[{variant['name']}]", flush=True)
        for mode in ("baseline_txt", "ted_trainfree_vl", "ted_calibrated_vl"):
            if mode in rows:
                print(f"{mode}: {fmt(rows[mode])}", flush=True)


if __name__ == "__main__":
    main()
