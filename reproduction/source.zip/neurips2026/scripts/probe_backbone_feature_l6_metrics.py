from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import RiemannianLowRankRefiner
from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader
from utils.eval_utils import specify_resolution
from utils.metrics import metric_cal


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--refiner_ckpt", type=str, required=True)
    parser.add_argument("--target_layer", type=int, default=6)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=1)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--no_pro", action="store_true")
    parser.add_argument("--output_tag", type=str, default="backbone_l6_feature_metrics")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(backbone, batch_np) -> torch.Tensor:
    imgs = [backbone.transform_pil(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(backbone.device)


def load_refiner(ckpt_path: str, device: torch.device) -> tuple[RiemannianLowRankRefiner, dict]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload["refiner_config"]
    refiner = RiemannianLowRankRefiner(
        feature_dim=int(config["feature_dim"]),
        kernel_size=int(config["kernel_size"]),
        topk_ratio=float(config["topk_ratio"]),
        rank=int(config["rank"]),
        hidden_dim=int(config["hidden_dim"]),
        dropout=float(config["dropout"]),
        lambda_max=float(config.get("lambda_max", 2.0)),
    ).to(device)
    refiner.load_state_dict(payload["model_state_dict"], strict=True)
    refiner.eval()
    return refiner, config


@torch.no_grad()
def build_class_prototype(backbone, loader, target_layer: int) -> torch.Tensor:
    feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        images = _preprocess_batch(backbone, data)
        tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        feats.append(F.normalize(tokens[normal_idx].float(), dim=-1))
    if not feats:
        raise RuntimeError("No normal train features found for prototype.")
    proto = torch.cat(feats, dim=0).mean(dim=0, keepdim=True)  # [1, N, D]
    proto = F.normalize(proto, dim=-1)
    return proto


@torch.no_grad()
def evaluate_variant(
    backbone,
    loader,
    target_layer: int,
    prototype: torch.Tensor,
    refiner: RiemannianLowRankRefiner | None,
    num_steps: int = 2,
    resolution: int = 400,
    cal_pro: bool = True,
) -> dict[str, float]:
    scores = []
    test_imgs = []
    gt_list = []
    gt_mask_list = []

    for data, mask, label, _name, _img_type in loader:
        for f in data:
            test_imgs.append(f.numpy())
        images = _preprocess_batch(backbone, data)
        tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        if refiner is not None:
            out = refiner(tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps)
            tokens = out.refined
        tokens = F.normalize(tokens.float(), dim=-1)
        proto = prototype.to(tokens.device, dtype=tokens.dtype).expand(tokens.shape[0], -1, -1)
        score_map = 1.0 - F.cosine_similarity(tokens, proto, dim=-1)
        side = backbone.grid_size[0]
        score_map = score_map.view(tokens.shape[0], side, side).cpu().numpy()
        scores += [s for s in score_map]
        for l, m in zip(label, mask):
            gt_list.append(int(l.numpy() if hasattr(l, "numpy") else l))
            gt_mask_list.append((m.numpy() > 0).astype(np.uint8))

    test_imgs, scores, gt_mask_list = specify_resolution(
        test_imgs,
        scores,
        gt_mask_list,
        resolution=(resolution, resolution),
    )
    metrics = metric_cal(np.array(scores), gt_list, gt_mask_list, cal_pro=cal_pro)
    return {
        "i_roc": float(metrics["i_roc"]),
        "p_roc": float(metrics["p_roc"]),
        "p_pro": float(metrics["p_pro"]),
    }


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu")

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    refiner, config = load_refiner(args.refiner_ckpt, device)
    num_steps = int(config.get("num_steps", 2))

    rows = []
    for class_name in args.class_names:
        train_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "train", args.batch_size)
        test_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)
        prototype = build_class_prototype(backbone, train_loader, args.target_layer)

        raw_metrics = evaluate_variant(
            backbone=backbone,
            loader=test_loader,
            target_layer=args.target_layer,
            prototype=prototype,
            refiner=None,
            resolution=args.resolution,
            cal_pro=not args.no_pro,
        )
        refined_metrics = evaluate_variant(
            backbone=backbone,
            loader=test_loader,
            target_layer=args.target_layer,
            prototype=prototype,
            refiner=refiner,
            num_steps=num_steps,
            resolution=args.resolution,
            cal_pro=not args.no_pro,
        )
        row = {
            "class_name": class_name,
            "target_layer": args.target_layer,
            "raw_i_roc": raw_metrics["i_roc"],
            "raw_p_roc": raw_metrics["p_roc"],
            "raw_p_pro": raw_metrics["p_pro"],
            "refined_i_roc": refined_metrics["i_roc"],
            "refined_p_roc": refined_metrics["p_roc"],
            "refined_p_pro": refined_metrics["p_pro"],
            "delta_i_roc": refined_metrics["i_roc"] - raw_metrics["i_roc"],
            "delta_p_roc": refined_metrics["p_roc"] - raw_metrics["p_roc"],
            "delta_p_pro": refined_metrics["p_pro"] - raw_metrics["p_pro"],
        }
        rows.append(row)
        print(
            f"{class_name} | raw->refined L{args.target_layer} | "
            f"dI={row['delta_i_roc']:.2f} dP={row['delta_p_roc']:.2f} dPRO={row['delta_p_pro']:.2f}",
            flush=True,
        )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(rows, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
