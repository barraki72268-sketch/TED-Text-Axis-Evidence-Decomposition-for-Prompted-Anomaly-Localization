from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import (
    build_model,
    get_learned_text_pair,
    load_prompt_learner,
    load_static_anomaly_text,
)  # noqa: E402
from probe_anomalyclip_text_competitive_holdout import build_dataset, collect_source_patch_banks, logmeanexp_negative_sqdist, whiten_features  # noqa: E402
from utils import get_transform  # noqa: E402


def get_counterfactual_text_pairs(model, learner, device: str) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    learned_pair = get_learned_text_pair(model, learner).to(device)
    # Keep the learned normal anchor fixed and only swap the anomaly axis.
    static_anomaly = load_static_anomaly_text().to(device)
    static_pair = torch.stack([learned_pair[0], static_anomaly], dim=0)
    static_pair = F.normalize(static_pair, dim=-1)
    return learned_pair, static_pair, static_anomaly


def anomaly_score_map(patch_feature: torch.Tensor, text_pair: torch.Tensor) -> torch.Tensor:
    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
    return ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)


def anomaly_text_score_map(patch_feature: torch.Tensor, anomaly_text: torch.Tensor) -> torch.Tensor:
    patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
    anomaly_text = F.normalize(anomaly_text.float(), dim=-1)
    return (patch @ anomaly_text).reshape(-1)


def build_eval_dataset(root: str, dataset_name: str, image_size: int, mode: str = "test"):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name=dataset_name, mode=mode)


def percentile_map(arr: np.ndarray) -> np.ndarray:
    flat = arr.reshape(-1)
    order = np.argsort(flat, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float32)
    n = max(1, flat.size)
    ranks[order] = (np.arange(flat.size, dtype=np.float32) + 1.0) / float(n)
    return ranks.reshape(arr.shape)


def sample_joint(mask: np.ndarray, arrays: dict[str, np.ndarray], max_points: int, rng: np.random.Generator) -> dict[str, np.ndarray]:
    idx = np.flatnonzero(mask.reshape(-1))
    if idx.size == 0:
        return {k: np.empty((0,), dtype=np.float32) for k in arrays}
    if idx.size > max_points:
        idx = rng.choice(idx, size=max_points, replace=False)
    out = {}
    for key, arr in arrays.items():
        out[key] = arr.reshape(-1)[idx].astype(np.float32, copy=False)
    return out


def concat_group(group: dict[str, list[np.ndarray]]) -> dict[str, np.ndarray]:
    out = {}
    for key, chunks in group.items():
        out[key] = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
    return out


def safe_mean(arr: np.ndarray) -> float:
    return float(arr.mean()) if arr.size else float("nan")


def safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 2 or y.size < 2:
        return float("nan")
    sx = float(np.std(x))
    sy = float(np.std(y))
    if sx < 1e-12 or sy < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    return float(np.mean(np.partition(flat, -k)[-k:]))


def top_fraction_ratio(score_map: np.ndarray, target_mask: np.ndarray, frac: float) -> float:
    flat = score_map.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    thresh = np.partition(flat, -k)[-k]
    top_mask = score_map >= thresh
    denom = int(top_mask.sum())
    if denom == 0:
        return float("nan")
    return float((top_mask & target_mask).sum() / denom)


def save_outputs(summary: dict, rows: list[dict], scatter_rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    if scatter_rows:
        with open(save_dir / "scatter_sample.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(scatter_rows[0].keys()))
            writer.writeheader()
            writer.writerows(scatter_rows)


def main():
    parser = argparse.ArgumentParser("Counterfactual static-vs-learned text swap audit for AnomalyCLIP")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default=None)
    parser.add_argument("--target_dataset", type=str, default="mvtec")
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_counterfactual_text_swap_epoch5"),
    )
    parser.add_argument("--heldout_class", type=str, default="bottle")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--normal_hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=128)
    parser.add_argument("--max_defect_per_image", type=int, default=128)
    parser.add_argument("--max_bg_per_image", type=int, default=128)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--ridge", type=float, default=1e-4)
    parser.add_argument("--per_image_inside_samples", type=int, default=1024)
    parser.add_argument("--per_image_outside_samples", type=int, default=2048)
    parser.add_argument("--per_image_fpoutside_samples", type=int, default=1024)
    parser.add_argument("--per_image_normal_hard_samples", type=int, default=1024)
    parser.add_argument("--scatter_max_rows", type=int, default=40000)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--top_comp_frac", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    device = args.device

    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    learned_pair, static_pair, static_anom = get_counterfactual_text_pairs(model, learner, device)

    fp_banks, def_banks, bg_models, bank_stats = collect_source_patch_banks(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        device=device,
        heldout_class=args.heldout_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        max_bg_per_image=args.max_bg_per_image,
        tau=args.tau,
        ridge=args.ridge,
    )

    target_root = args.target_root or args.source_root
    dataset = build_eval_dataset(target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    target_class_filter = set(args.target_classes) if args.target_classes else None

    groups = {
        "inside": {k: [] for k in ["static", "learned", "delta", "margin", "static_pct", "learned_pct"]},
        "outside": {k: [] for k in ["static", "learned", "delta", "margin", "static_pct", "learned_pct"]},
        "fp_supported_outside": {k: [] for k in ["static", "learned", "delta", "margin", "static_pct", "learned_pct"]},
        "normal_hardfp": {k: [] for k in ["static", "learned", "delta", "margin", "static_pct", "learned_pct"]},
    }

    image_rows = []
    scatter_rows = []
    top_comp_rows = []

    with torch.no_grad():
        for idx in range(len(dataset)):
            item = dataset[idx]
            if args.target_dataset == "mvtec" and item["cls_name"] != args.heldout_class:
                continue
            if target_class_filter is not None and item["cls_name"] not in target_class_filter:
                continue

            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"].unsqueeze(0).clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask_np = gt_mask[0, 0].numpy().astype(bool)
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            learned_maps = []
            static_maps = []
            learned_full_maps = []
            static_full_maps = []
            margin_maps = []
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                learned_scores = anomaly_text_score_map(patch_feature, learned_pair[1])
                static_scores = anomaly_text_score_map(patch_feature, static_anom)
                learned_full_scores = anomaly_score_map(patch_feature, learned_pair)
                static_full_scores = anomaly_score_map(patch_feature, static_pair)

                mu_bg = bg_models[layer_idx]["mu_bg"].to(patch.device)
                whitening = bg_models[layer_idx]["whitening"].to(patch.device)
                patch_w = whiten_features(patch, mu_bg, whitening)
                q_fp = logmeanexp_negative_sqdist(patch_w, fp_banks[layer_idx].to(patch.device), tau=args.tau)
                q_def = logmeanexp_negative_sqdist(patch_w, def_banks[layer_idx].to(patch.device), tau=args.tau)
                margin = q_def - q_fp

                h = int(round(learned_scores.shape[0] ** 0.5))
                learned_maps.append(learned_scores.reshape(h, h).detach().cpu().numpy())
                static_maps.append(static_scores.reshape(h, h).detach().cpu().numpy())
                learned_full_maps.append(learned_full_scores.reshape(h, h).detach().cpu().numpy())
                static_full_maps.append(static_full_scores.reshape(h, h).detach().cpu().numpy())
                margin_maps.append(margin.reshape(h, h).detach().cpu().numpy())

            learned_map = np.mean(np.stack(learned_maps, axis=0), axis=0)
            static_map = np.mean(np.stack(static_maps, axis=0), axis=0)
            learned_full_map = np.mean(np.stack(learned_full_maps, axis=0), axis=0)
            static_full_map = np.mean(np.stack(static_full_maps, axis=0), axis=0)
            margin_map = np.mean(np.stack(margin_maps, axis=0), axis=0)

            H, W = gt_mask_np.shape
            learned_map = (
                F.interpolate(torch.from_numpy(learned_map).unsqueeze(0).unsqueeze(0).float(), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
                .cpu()
                .numpy()
            )
            static_map = (
                F.interpolate(torch.from_numpy(static_map).unsqueeze(0).unsqueeze(0).float(), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
                .cpu()
                .numpy()
            )
            learned_full_map = (
                F.interpolate(torch.from_numpy(learned_full_map).unsqueeze(0).unsqueeze(0).float(), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
                .cpu()
                .numpy()
            )
            static_full_map = (
                F.interpolate(torch.from_numpy(static_full_map).unsqueeze(0).unsqueeze(0).float(), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
                .cpu()
                .numpy()
            )
            margin_map = (
                F.interpolate(torch.from_numpy(margin_map).unsqueeze(0).unsqueeze(0).float(), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
                .cpu()
                .numpy()
            )

            delta_map = learned_map - static_map
            static_pct = percentile_map(static_map)
            learned_pct = percentile_map(learned_map)

            image_rows.append(
                {
                    "image_id": int(idx),
                    "anomaly": anomaly_flag,
                    "static_topk": topk_mean(static_full_map, args.image_score_topk),
                    "learned_topk": topk_mean(learned_full_map, args.image_score_topk),
                    "margin_topk": topk_mean(margin_map, args.image_score_topk),
                }
            )

            arrays = {
                "static": static_map,
                "learned": learned_map,
                "delta": delta_map,
                "margin": margin_map,
                "static_pct": static_pct,
                "learned_pct": learned_pct,
            }

            if anomaly_flag == 1:
                inside_mask = gt_mask_np
                outside_mask = ~gt_mask_np
                fp_supported_mask = outside_mask & (margin_map < 0.0)
                top_comp_rows.append(
                    {
                        "image_id": int(idx),
                        "static_top_fp_ratio": top_fraction_ratio(static_map, fp_supported_mask, args.top_comp_frac),
                        "learned_top_fp_ratio": top_fraction_ratio(learned_map, fp_supported_mask, args.top_comp_frac),
                        "static_top_inside_ratio": top_fraction_ratio(static_map, inside_mask, args.top_comp_frac),
                        "learned_top_inside_ratio": top_fraction_ratio(learned_map, inside_mask, args.top_comp_frac),
                    }
                )

                for name, mask, cap in [
                    ("inside", inside_mask, args.per_image_inside_samples),
                    ("outside", outside_mask, args.per_image_outside_samples),
                    ("fp_supported_outside", fp_supported_mask, args.per_image_fpoutside_samples),
                ]:
                    sampled = sample_joint(mask, arrays, cap, rng)
                    for key, vals in sampled.items():
                        groups[name][key].append(vals)

                    if name == "fp_supported_outside" and sampled["margin"].size:
                        take = min(sampled["margin"].size, max(1, args.scatter_max_rows // 20))
                        idx_take = np.arange(sampled["margin"].size)
                        if idx_take.size > take:
                            idx_take = rng.choice(idx_take, size=take, replace=False)
                        for j in idx_take:
                            scatter_rows.append(
                                {
                                    "group": name,
                                    "image_id": int(idx),
                                    "margin": float(sampled["margin"][j]),
                                    "delta": float(sampled["delta"][j]),
                                    "static_score": float(sampled["static"][j]),
                                    "learned_score": float(sampled["learned"][j]),
                                    "static_pct": float(sampled["static_pct"][j]),
                                    "learned_pct": float(sampled["learned_pct"][j]),
                                }
                            )
            else:
                flat_learned = learned_map.reshape(-1)
                k = max(1, int(math.ceil(flat_learned.size * args.normal_hard_frac)))
                thresh = np.partition(flat_learned, -k)[-k]
                normal_hard_mask = learned_map >= thresh
                sampled = sample_joint(normal_hard_mask, arrays, args.per_image_normal_hard_samples, rng)
                for key, vals in sampled.items():
                    groups["normal_hardfp"][key].append(vals)
                if sampled["margin"].size:
                    take = min(sampled["margin"].size, max(1, args.scatter_max_rows // 20))
                    idx_take = np.arange(sampled["margin"].size)
                    if idx_take.size > take:
                        idx_take = rng.choice(idx_take, size=take, replace=False)
                    for j in idx_take:
                        scatter_rows.append(
                            {
                                "group": "normal_hardfp",
                                "image_id": int(idx),
                                "margin": float(sampled["margin"][j]),
                                "delta": float(sampled["delta"][j]),
                                "static_score": float(sampled["static"][j]),
                                "learned_score": float(sampled["learned"][j]),
                                "static_pct": float(sampled["static_pct"][j]),
                                "learned_pct": float(sampled["learned_pct"][j]),
                            }
                        )

    concat = {name: concat_group(group) for name, group in groups.items()}

    static_img_auc = safe_auc(
        np.array([r["static_topk"] for r in image_rows if r["anomaly"] == 1], dtype=np.float32),
        np.array([r["static_topk"] for r in image_rows if r["anomaly"] == 0], dtype=np.float32),
    )
    learned_img_auc = safe_auc(
        np.array([r["learned_topk"] for r in image_rows if r["anomaly"] == 1], dtype=np.float32),
        np.array([r["learned_topk"] for r in image_rows if r["anomaly"] == 0], dtype=np.float32),
    )
    margin_img_auc = safe_auc(
        np.array([r["margin_topk"] for r in image_rows if r["anomaly"] == 1], dtype=np.float32),
        np.array([r["margin_topk"] for r in image_rows if r["anomaly"] == 0], dtype=np.float32),
    )
    static_top_fp_ratio = np.array([r["static_top_fp_ratio"] for r in top_comp_rows], dtype=np.float32)
    learned_top_fp_ratio = np.array([r["learned_top_fp_ratio"] for r in top_comp_rows], dtype=np.float32)
    static_top_inside_ratio = np.array([r["static_top_inside_ratio"] for r in top_comp_rows], dtype=np.float32)
    learned_top_inside_ratio = np.array([r["learned_top_inside_ratio"] for r in top_comp_rows], dtype=np.float32)

    metrics = {
        "image_auc_static_topk": static_img_auc,
        "image_auc_learned_topk": learned_img_auc,
        "image_auc_margin_topk": margin_img_auc,
        "inside_vs_outside_auc_static": safe_auc(concat["inside"]["static"], concat["outside"]["static"]),
        "inside_vs_outside_auc_learned": safe_auc(concat["inside"]["learned"], concat["outside"]["learned"]),
        "inside_vs_fpoutside_auc_static": safe_auc(concat["inside"]["static"], concat["fp_supported_outside"]["static"]),
        "inside_vs_fpoutside_auc_learned": safe_auc(concat["inside"]["learned"], concat["fp_supported_outside"]["learned"]),
        "fpoutside_outrank_rate_static": 1.0 - safe_auc(concat["inside"]["static"], concat["fp_supported_outside"]["static"]),
        "fpoutside_outrank_rate_learned": 1.0 - safe_auc(concat["inside"]["learned"], concat["fp_supported_outside"]["learned"]),
        "fpoutside_outrank_rate_delta": (1.0 - safe_auc(concat["inside"]["learned"], concat["fp_supported_outside"]["learned"]))
        - (1.0 - safe_auc(concat["inside"]["static"], concat["fp_supported_outside"]["static"])),
        "mean_delta_inside": safe_mean(concat["inside"]["delta"]),
        "mean_delta_outside": safe_mean(concat["outside"]["delta"]),
        "mean_delta_fp_supported_outside": safe_mean(concat["fp_supported_outside"]["delta"]),
        "mean_delta_normal_hardfp": safe_mean(concat["normal_hardfp"]["delta"]),
        "mean_pct_shift_fp_supported_outside": safe_mean(concat["fp_supported_outside"]["learned_pct"] - concat["fp_supported_outside"]["static_pct"]),
        "mean_pct_shift_normal_hardfp": safe_mean(concat["normal_hardfp"]["learned_pct"] - concat["normal_hardfp"]["static_pct"]),
        "frac_positive_pct_shift_fp_supported_outside": float(np.mean((concat["fp_supported_outside"]["learned_pct"] - concat["fp_supported_outside"]["static_pct"]) > 0))
        if concat["fp_supported_outside"]["learned_pct"].size
        else float("nan"),
        "top_1pct_fp_ratio_static": safe_mean(static_top_fp_ratio),
        "top_1pct_fp_ratio_learned": safe_mean(learned_top_fp_ratio),
        "top_1pct_fp_ratio_delta": safe_mean(learned_top_fp_ratio - static_top_fp_ratio),
        "top_1pct_inside_ratio_static": safe_mean(static_top_inside_ratio),
        "top_1pct_inside_ratio_learned": safe_mean(learned_top_inside_ratio),
        "top_1pct_inside_ratio_delta": safe_mean(learned_top_inside_ratio - static_top_inside_ratio),
        "corr_delta_vs_margin_outside": safe_corr(concat["outside"]["delta"], concat["outside"]["margin"]),
        "corr_delta_vs_neg_margin_outside": safe_corr(concat["outside"]["delta"], -concat["outside"]["margin"]),
        "corr_delta_vs_margin_fp_supported_outside": safe_corr(concat["fp_supported_outside"]["delta"], concat["fp_supported_outside"]["margin"]),
        "corr_delta_vs_neg_margin_fp_supported_outside": safe_corr(concat["fp_supported_outside"]["delta"], -concat["fp_supported_outside"]["margin"]),
        "margin_inside_mean": safe_mean(concat["inside"]["margin"]),
        "margin_outside_mean": safe_mean(concat["outside"]["margin"]),
        "margin_fp_supported_outside_mean": safe_mean(concat["fp_supported_outside"]["margin"]),
        "num_inside": int(concat["inside"]["margin"].size),
        "num_outside": int(concat["outside"]["margin"].size),
        "num_fp_supported_outside": int(concat["fp_supported_outside"]["margin"].size),
        "num_normal_hardfp": int(concat["normal_hardfp"]["margin"].size),
    }

    rows = [{"metric": k, "value": v} for k, v in metrics.items()]
    summary = {
        "settings": {
            "heldout_class": args.heldout_class,
            "checkpoint_path": args.checkpoint_path,
            "source_root": args.source_root,
            "target_root": target_root,
            "target_dataset": args.target_dataset,
            "target_mode": args.target_mode,
            "target_classes": sorted(target_class_filter) if target_class_filter is not None else "all",
            "tau": args.tau,
            "ridge": args.ridge,
            "hard_frac": args.hard_frac,
            "normal_hard_frac": args.normal_hard_frac,
            "normal_axis": "learned_fixed",
            "anomaly_axis": "static_vs_learned",
        },
        "bank_stats": bank_stats,
        "metrics": metrics,
        "image_rows": image_rows,
    }
    save_outputs(summary, rows, scatter_rows[: args.scatter_max_rows], Path(args.save_dir))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
