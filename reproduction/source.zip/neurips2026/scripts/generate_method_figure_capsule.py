from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
from PIL import Image


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec/capsule")
OUT_DIR = ROOT / "neurips2026" / "results" / "method_figure_capsule"
OUT_DIR.mkdir(parents=True, exist_ok=True)


COLORS = {
    "fp": "#2B6CB0",
    "def": "#C44536",
    "qry": "#2F855A",
    "axis": "#2D3748",
    "soft_red": "#F6AD9C",
    "soft_blue": "#90CDF4",
    "soft_green": "#9AE6B4",
}


NORMAL_PATH = MVTEC / "train/good/000.png"
DEFECT_PATH = MVTEC / "test/crack/000.png"
DEFECT_MASK_PATH = MVTEC / "ground_truth/crack/000_mask.png"
QUERY_PATH = MVTEC / "test/faulty_imprint/000.png"

FP_BOXES = [
    {"xywh": (180, 315, 250, 185), "label": "structured logo"},
    {"xywh": (500, 275, 250, 205), "label": "printed text"},
]
DEFECT_BOXES = [
    {"xywh": (690, 555, 150, 95), "label": "defect patch 1"},
    {"xywh": (760, 545, 150, 95), "label": "defect patch 2"},
]
QUERY_BOX = {"xywh": (535, 285, 160, 160), "label": "query patch"}


def load_rgb(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"))


def load_mask(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L")) > 0


def crop_with_box(image: np.ndarray, xywh: tuple[int, int, int, int]) -> np.ndarray:
    x, y, w, h = xywh
    return image[y : y + h, x : x + w]


def draw_image(ax, image: np.ndarray, title: str, title_color: str = "#111111") -> None:
    ax.imshow(image)
    ax.set_title(title, fontsize=20, fontweight="bold", color=title_color, pad=10)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def add_box(ax, xywh: tuple[int, int, int, int], color: str, lw: float = 4.0, linestyle: str = "-") -> None:
    x, y, w, h = xywh
    rect = patches.Rectangle((x, y), w, h, linewidth=lw, edgecolor=color, facecolor="none", linestyle=linestyle)
    ax.add_patch(rect)


def add_crop_panel(ax, crops: list[np.ndarray], color: str, title: str) -> None:
    ax.axis("off")
    ax.set_title(title, fontsize=17, fontweight="bold", pad=6)
    n = len(crops)
    for i, crop in enumerate(crops):
        inset = ax.inset_axes([0.03 + i * (0.47 if n == 2 else 0.32), 0.08, 0.44 if n == 2 else 0.29, 0.82])
        inset.imshow(crop)
        inset.set_xticks([])
        inset.set_yticks([])
        for spine in inset.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(4)
            spine.set_edgecolor(color)


def add_axis_panel(ax) -> None:
    ax.axis("off")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.text(0.03, 0.96, "3. Score a patch", fontsize=19, fontweight="bold", ha="left", va="top")
    ax.text(0.03, 0.86, "text-guided axis", fontsize=16, fontweight="bold", ha="left", va="top")
    ax.text(0.03, 0.76, r"$u=\frac{e_a-e_n}{\|e_a-e_n\|_2}$", fontsize=18)
    ax.text(0.03, 0.65, r"$c_i^{(\ell)}=\langle v_i^{(\ell)},u\rangle$", fontsize=18)

    y = 0.44
    ax.plot([0.12, 0.92], [y, y], color=COLORS["axis"], lw=4, solid_capstyle="round")
    ax.text(0.1, y - 0.08, "normal", fontsize=14, fontweight="bold", ha="center")
    ax.text(0.93, y - 0.08, "anomaly", fontsize=14, fontweight="bold", ha="center")

    fp_x = np.array([0.42, 0.47, 0.50, 0.54])
    def_x = np.array([0.62, 0.67, 0.72, 0.77])
    qry_x = 0.66
    ax.scatter(fp_x, np.full_like(fp_x, y), s=170, c=COLORS["soft_blue"], edgecolors=COLORS["fp"], linewidths=2.5, zorder=3)
    ax.scatter(def_x, np.full_like(def_x, y), s=170, c=COLORS["soft_red"], edgecolors=COLORS["def"], linewidths=2.5, zorder=3)
    ax.scatter([qry_x], [y], s=240, c=COLORS["soft_green"], edgecolors=COLORS["qry"], linewidths=3, zorder=4)
    ax.annotate("", xy=(qry_x, y - 0.02), xytext=(qry_x, y + 0.18), arrowprops=dict(arrowstyle="-|>", lw=2.8, color=COLORS["qry"]))
    ax.text(qry_x, y + 0.21, "query patch", fontsize=14, fontweight="bold", ha="center", color=COLORS["qry"])

    ax.text(0.12, 0.27, "hard-FP support", fontsize=14, fontweight="bold", color=COLORS["fp"])
    ax.text(0.61, 0.27, "defect support", fontsize=14, fontweight="bold", color=COLORS["def"])
    ax.text(0.18, 0.16, r"$q_{\mathrm{fp}}^{(\ell)}(v_i)$", fontsize=18, color=COLORS["fp"])
    ax.text(0.58, 0.16, r"$q_{\mathrm{def}}^{(\ell)}(v_i)$", fontsize=18, color=COLORS["def"])

    ax.text(0.03, 0.03, r"$r_{\parallel}^{(\ell)}(v_i)=q_{\mathrm{def}}^{(\ell)}(v_i)-q_{\mathrm{fp}}^{(\ell)}(v_i)$", fontsize=18, fontweight="bold")


def add_query_repeat_panel(ax, query_img: np.ndarray) -> None:
    draw_image(ax, query_img, "4. Dense scoring")

    # faint patch grid
    h, w = query_img.shape[:2]
    step = 150
    for x in range(step, w, step):
        ax.plot([x, x], [0, h], color="white", alpha=0.22, lw=1.0)
    for y in range(step, h, step):
        ax.plot([0, w], [y, y], color="white", alpha=0.22, lw=1.0)

    add_box(ax, QUERY_BOX["xywh"], COLORS["qry"], lw=4.5)
    add_box(ax, (465, 275, 115, 120), COLORS["fp"], lw=3.2, linestyle="--")
    add_box(ax, (610, 275, 115, 120), COLORS["def"], lw=3.2, linestyle="--")

    ax.text(0.03, 0.05, r"$r_{\parallel}(v_i)$ per patch", transform=ax.transAxes, fontsize=14, fontweight="bold", color="white",
            bbox=dict(facecolor=(0, 0, 0, 0.45), edgecolor="none", boxstyle="round,pad=0.3"))
    ax.text(0.98, 0.05, r"reshape $\rightarrow M(x,y)$", transform=ax.transAxes, fontsize=14, fontweight="bold", color="white",
            ha="right", bbox=dict(facecolor=(0, 0, 0, 0.45), edgecolor="none", boxstyle="round,pad=0.3"))


def generate() -> None:
    normal = load_rgb(NORMAL_PATH)
    defect = load_rgb(DEFECT_PATH)
    defect_mask = load_mask(DEFECT_MASK_PATH)
    query = load_rgb(QUERY_PATH)

    overlay = defect.copy().astype(np.float32)
    overlay[defect_mask] = 0.6 * overlay[defect_mask] + 0.4 * np.array([255, 85, 85], dtype=np.float32)
    overlay = np.clip(overlay, 0, 255).astype(np.uint8)

    fp_crops = [crop_with_box(normal, box["xywh"]) for box in FP_BOXES]
    def_crops = [crop_with_box(defect, box["xywh"]) for box in DEFECT_BOXES]

    fig = plt.figure(figsize=(18.5, 8.2))
    gs = fig.add_gridspec(
        2,
        4,
        height_ratios=[3.4, 1.2],
        width_ratios=[1.15, 1.15, 1.0, 1.1],
        wspace=0.22,
        hspace=0.10,
    )

    ax_norm = fig.add_subplot(gs[0, 0])
    draw_image(ax_norm, normal, "1. Collect hard-FP bank")
    for box in FP_BOXES:
        add_box(ax_norm, box["xywh"], COLORS["fp"])

    ax_def = fig.add_subplot(gs[0, 1])
    draw_image(ax_def, overlay, "2. Collect defect bank")
    for box in DEFECT_BOXES:
        add_box(ax_def, box["xywh"], COLORS["def"])

    ax_axis = fig.add_subplot(gs[0, 2])
    add_axis_panel(ax_axis)

    ax_query = fig.add_subplot(gs[0, 3])
    add_query_repeat_panel(ax_query, query)

    ax_fp_crops = fig.add_subplot(gs[1, 0])
    add_crop_panel(ax_fp_crops, fp_crops, COLORS["fp"], "Hard-FP bank examples")

    ax_def_crops = fig.add_subplot(gs[1, 1])
    add_crop_panel(ax_def_crops, def_crops, COLORS["def"], "Defect bank examples")

    ax_note = fig.add_subplot(gs[1, 2:])
    ax_note.axis("off")
    ax_note.text(0.02, 0.74, "Method overview using actual MVTec capsule images", fontsize=19, fontweight="bold")
    ax_note.text(0.02, 0.48, "Source normal patches with high baseline response form the hard-FP bank.", fontsize=16)
    ax_note.text(0.02, 0.28, "Source anomaly patches overlapping the mask form the defect bank.", fontsize=16)
    ax_note.text(0.02, 0.08, "Each query patch is projected onto the learned text axis and scored by defect support minus hard-FP support.", fontsize=16)

    png_path = OUT_DIR / "method_figure_capsule.png"
    pdf_path = OUT_DIR / "method_figure_capsule.pdf"
    meta_path = OUT_DIR / "method_figure_capsule.json"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)

    meta = {
        "normal_path": str(NORMAL_PATH),
        "defect_path": str(DEFECT_PATH),
        "defect_mask_path": str(DEFECT_MASK_PATH),
        "query_path": str(QUERY_PATH),
        "fp_boxes": FP_BOXES,
        "defect_boxes": DEFECT_BOXES,
        "query_box": QUERY_BOX,
    }
    meta_path.write_text(json.dumps(meta, indent=2))
    print(json.dumps({"png": str(png_path), "pdf": str(pdf_path), "meta": str(meta_path)}, indent=2))


if __name__ == "__main__":
    generate()
