#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_rawclip.py"
export MPLCONFIGDIR="/tmp/matplotlib-rawclip-vith14-gpu1"

CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" \
  --source_root "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  --source_dataset visa \
  --target_root "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  --target_dataset mvtec \
  --save_dir "${ROOT}/neurips2026/results/official_parallel_test_rawclip_vith14_visa2mvtec_all" \
  --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/rawclip_vith14_visa_multilayer.pt" \
  --backbone "ViT-H-14" \
  --pretrained_dataset "laion2b_s32b_b79k" \
  --image_size 224 \
  --prompt_mode class \
  --sigma 4 \
  --max_good_per_class 2 \
  --max_defect_per_class 4 \
  --max_bank_per_layer 512 \
  --max_fp_per_image 64 \
  --max_defect_per_image 64 \
  --device cuda:0
