#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
PROBE = ROOT / "neurips2026" / "scripts" / "probe_winclip_ted_smoke.py"
RESULTS = ROOT / "neurips2026" / "results"

VISA_CLASSES = [
    "candle",
    "capsules",
    "cashew",
    "chewinggum",
    "fryum",
    "macaroni1",
    "macaroni2",
    "pcb1",
    "pcb2",
    "pcb3",
    "pcb4",
    "pipe_fryum",
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=str, default="cuda:1")
    parser.add_argument("--tag", type=str, default="lam8")
    parser.add_argument("--classes", nargs="*", default=VISA_CLASSES)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    root_out = RESULTS / f"winclip_ted_refined_scalewise_mvtec2visa_perclass_{args.tag}_20260430"
    root_out.mkdir(parents=True, exist_ok=True)
    manifest = []
    for cls_name in args.classes:
        save_dir = root_out / cls_name
        summary_path = save_dir / "summary.json"
        if summary_path.exists() and not args.force:
            print(json.dumps({"stage": "skip_existing", "class": cls_name, "summary": str(summary_path)}), flush=True)
            manifest.append({"class": cls_name, "summary": str(summary_path), "status": "skipped"})
            continue
        cmd = [
            str(PYTHON),
            "-u",
            str(PROBE),
            "--target_class",
            cls_name,
            "--max_normal_eval",
            "0",
            "--max_anomaly_eval",
            "0",
            "--max_good",
            "16",
            "--max_defect",
            "16",
            "--max_bank",
            "1024",
            "--defect_overlap_min",
            "0.25",
            "--max_windows_per_image_scale",
            "32",
            "--margin_sign",
            "def_minus_fp",
            "--enable_calibrated",
            "--calib_fusion_level",
            "window",
            "--calib_score_source",
            "rankr_density",
            "--calib_rank",
            "8",
            "--calib_rankr_tau",
            "0.1",
            "--calib_lambda",
            "8.0",
            "--calib_eta_max",
            "1.0",
            "--calib_gate_quantile",
            "0.75",
            "--calib_gate_temp",
            "0.5",
            "--calib_image_score_mode",
            "baseline",
            "--calib_scalewise",
            "--save_dir",
            str(save_dir),
            "--device",
            args.device,
        ]
        print(json.dumps({"stage": "start_class", "class": cls_name, "save_dir": str(save_dir)}), flush=True)
        ret = subprocess.run(cmd, cwd=str(ROOT))
        status = "completed" if ret.returncode == 0 and summary_path.exists() else "failed"
        manifest.append({"class": cls_name, "summary": str(summary_path), "status": status, "returncode": ret.returncode})
        with (root_out / "manifest.json").open("w") as f:
            json.dump(manifest, f, indent=2)
        print(json.dumps({"stage": "done_class", "class": cls_name, "status": status, "returncode": ret.returncode}), flush=True)
        if ret.returncode != 0:
            return ret.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
