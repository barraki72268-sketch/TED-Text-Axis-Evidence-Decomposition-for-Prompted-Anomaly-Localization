from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner, encode_text_prompt_bank  # noqa: E402
from utils import get_transform  # noqa: E402


def normal_basis(bank: torch.Tensor, eps: float = 1e-6) -> tuple[torch.Tensor, torch.Tensor]:
    bank = F.normalize(bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return bank.new_zeros((bank.shape[-1], 0)), s
    return vh[:rank].transpose(0, 1).contiguous(), s


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = vec @ basis
    return float(coeff.pow(2).sum().item())


def build_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_learned_text(model, params, checkpoint_path: Path, device: str) -> torch.Tensor:
    learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    learner.load_state_dict(checkpoint["prompt_learner"])
    learner.to(device)
    learner.eval()
    model.to(device)
    model.eval()
    prompts, tokenized_prompts, compound_prompts_text = learner(cls_id=None)
    prompts = prompts.to(device)
    tokenized_prompts = tokenized_prompts.to(device)
    compound_prompts_text = [prompt.to(device) for prompt in compound_prompts_text]
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = F.normalize(text_features, dim=-1)
    return text_features[0, 1].detach().cpu()


def collect_normal_patches(model, data_path: str, image_size: int, max_per_class: int, device: str) -> torch.Tensor:
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=data_path, transform=preprocess, target_transform=target_transform, dataset_name="visa")

    per_class_count: dict[str, int] = {obj: 0 for obj in dataset.obj_list}
    kept_indices = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        cls_name = item["cls_name"]
        anomaly_flag = item["anomaly"]
        if hasattr(anomaly_flag, "item"):
            anomaly_flag = anomaly_flag.item()
        if int(anomaly_flag) != 0:
            continue
        if per_class_count[cls_name] >= max_per_class:
            continue
        per_class_count[cls_name] += 1
        kept_indices.append(idx)

    subset = torch.utils.data.Subset(dataset, kept_indices)
    loader = torch.utils.data.DataLoader(subset, batch_size=1, shuffle=False, num_workers=0)

    patches = []
    print(
        json.dumps(
            {
                "stage": "collect_normal_patches",
                "num_selected_images": len(kept_indices),
                "max_normal_per_class": max_per_class,
            }
        ),
        flush=True,
    )
    with torch.no_grad():
        for idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            _, patch_features = model.encode_image(image, [24], DPAM_layer=20)
            patch = F.normalize(patch_features[0][:, 1:, :].reshape(-1, patch_features[0].shape[-1]).float(), dim=-1)
            patches.append(patch.cpu())
            if idx % 16 == 0 or idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "collect_normal_patches_progress",
                            "images_done": idx,
                            "images_total": len(loader),
                            "patches_so_far": int(sum(p.shape[0] for p in patches)),
                        }
                    ),
                    flush=True,
                )
    return torch.cat(patches, dim=0)


def corrcoef(x: np.ndarray, y: np.ndarray) -> float:
    if x.std() < 1e-8 or y.std() < 1e-8:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def main():
    parser = argparse.ArgumentParser("Analyze whether visual-tail leakage could justify joint text+visual projection")
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--data_path", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--max_normal_per_class", type=int, default=32)
    parser.add_argument("--save_path", type=str, required=True)
    args = parser.parse_args()

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learned_anom = load_learned_text(model, params, Path(args.checkpoint_path), args.device)

    reference_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=None)
    reference_model.eval()
    _, anomaly_bank = encode_text_prompt_bank(reference_model, "object", "cpu")
    anomaly_bank = F.normalize(anomaly_bank.float(), dim=-1).detach()
    static_anom = F.normalize(anomaly_bank.mean(dim=0), dim=-1).detach()

    normal_patches = collect_normal_patches(model, args.data_path, args.image_size, args.max_normal_per_class, args.device)
    print(json.dumps({"stage": "svd_start", "num_patches": int(normal_patches.shape[0]), "dim": int(normal_patches.shape[1])}), flush=True)
    vis_basis, s = normal_basis(normal_patches)
    print(json.dumps({"stage": "svd_done", "rank": int(vis_basis.shape[1])}), flush=True)
    s2 = (s**2) / torch.clamp((s**2).sum(), min=1e-8)
    cum = torch.cumsum(s2, dim=0)

    rows = {
        "num_normal_patches": int(normal_patches.shape[0]),
        "dim": int(normal_patches.shape[1]),
        "vis_rank": int(vis_basis.shape[1]),
        "sv_cum_top1": float(cum[min(0, len(cum)-1)].item()) if len(cum) else 0.0,
        "sv_cum_top5": float(cum[min(4, len(cum)-1)].item()) if len(cum) else 0.0,
        "sv_cum_top10": float(cum[min(9, len(cum)-1)].item()) if len(cum) else 0.0,
        "skip_stats": {},
    }

    z = normal_patches.detach()
    z_np = z.numpy()
    learned_np = F.normalize(learned_anom, dim=-1).detach().numpy()
    static_np = F.normalize(static_anom, dim=-1).detach().numpy()

    for skip_topk in [1, 5, 10]:
        if vis_basis.shape[1] <= skip_topk:
            continue
        top = vis_basis[:, :skip_topk]
        tail = vis_basis[:, skip_topk:]

        e_top = top @ (top.t() @ F.normalize(learned_anom, dim=-1))
        e_tail = tail @ (tail.t() @ F.normalize(learned_anom, dim=-1))
        e_top_np = e_top.detach().numpy()
        e_tail_np = e_tail.detach().numpy()

        total_score = z_np @ learned_np
        top_score = z_np @ e_top_np
        tail_score = z_np @ e_tail_np
        tail_energy = np.sum((z_np @ tail.detach().numpy()) ** 2, axis=1)

        k = max(1, int(0.01 * len(total_score)))
        top_idx = np.argpartition(total_score, -k)[-k:]

        rows["skip_stats"][str(skip_topk)] = {
            "learned_vis_tail_proj": projection_energy(learned_anom, tail),
            "static_vis_tail_proj": projection_energy(static_anom, tail),
            "learned_vis_top_proj": projection_energy(learned_anom, top),
            "static_vis_top_proj": projection_energy(static_anom, top),
            "corr_total_score_vs_tail_energy": corrcoef(total_score, tail_energy),
            "all_mean_total_score": float(total_score.mean()),
            "all_mean_top_score": float(top_score.mean()),
            "all_mean_tail_score": float(tail_score.mean()),
            "fp_top1pct_mean_total_score": float(total_score[top_idx].mean()),
            "fp_top1pct_mean_top_score": float(top_score[top_idx].mean()),
            "fp_top1pct_mean_tail_score": float(tail_score[top_idx].mean()),
            "fp_top1pct_mean_tail_energy": float(tail_energy[top_idx].mean()),
            "all_mean_tail_energy": float(tail_energy.mean()),
        }

    save_path = Path(args.save_path)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    with open(save_path, "w") as f:
        json.dump(rows, f, indent=2)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
