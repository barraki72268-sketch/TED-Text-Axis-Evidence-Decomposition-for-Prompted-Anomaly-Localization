#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FormatStrFormatter, MaxNLocator


ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "neurips2026" / "results" / "discussion_axis_entanglement_mvtec2visa_capsules"
FIG = ROOT / "figure"
JSON_PATH = SRC / "axis_entanglement_mvtec2visa.json"

COL_IN = "#d55e00"
COL_FP = "#0072b2"
COL_OUT = "#009e73"


def setup_rc() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.weight": "bold",
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    scores = np.concatenate([pos, neg])
    labels = np.concatenate([np.ones(pos.size, dtype=np.int64), np.zeros(neg.size, dtype=np.int64)])
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, scores.size + 1, dtype=np.float64)
    pos_ranks = ranks[labels == 1]
    return float((pos_ranks.sum() - pos.size * (pos.size + 1) / 2.0) / (pos.size * neg.size))


def sample_array(vals: np.ndarray, max_n: int, seed: int) -> np.ndarray:
    vals = vals.reshape(-1)
    if vals.size <= max_n:
        return vals
    rng = np.random.default_rng(seed)
    return vals[rng.choice(vals.size, size=max_n, replace=False)]


def style_axis(ax: plt.Axes, *, ticksize: int = 14, labelsize: int = 15) -> None:
    ax.tick_params(axis="both", labelsize=ticksize, width=1.4, length=4.5)
    for t in ax.get_xticklabels() + ax.get_yticklabels():
        t.set_fontweight("bold")
    for spine in ax.spines.values():
        spine.set_linewidth(1.45)
    ax.xaxis.label.set_size(labelsize)
    ax.yaxis.label.set_size(labelsize)
    ax.xaxis.label.set_fontweight("bold")
    ax.yaxis.label.set_fontweight("bold")


def draw_panel(
    ax: plt.Axes,
    groups: dict[str, np.ndarray],
    keys: tuple[str, str, str],
    xlabel: str,
    *,
    show_ylabel: bool,
    show_legend: bool,
    show_auc: bool,
    seed_base: int,
) -> None:
    vals_in = groups[keys[0]]
    vals_fp = groups[keys[1]]
    vals_out = groups[keys[2]]
    arrs = [vals_in, vals_fp, vals_out]
    non_empty = [a for a in arrs if a.size > 0]
    lo = float(min(a.min() for a in non_empty))
    hi = float(max(a.max() for a in non_empty))
    if np.isclose(lo, hi):
        hi = lo + 1e-6
    bins = np.linspace(lo, hi, 126)

    styles = [
        ("Inside", COL_IN, "-"),
        ("Hard-FP", COL_FP, "--"),
        ("Outside", COL_OUT, ":"),
    ]
    for i, ((label, color, ls), vals) in enumerate(zip(styles, arrs)):
        vals = sample_array(vals, 120000, seed_base + i)
        _, _, patches = ax.hist(vals, bins=bins, density=True, histtype="step", linewidth=2.4, color=color, label=label)
        for p in patches:
            p.set_linestyle(ls)

    ax.set_xlabel(xlabel, labelpad=5)
    ax.set_ylabel("Density" if show_ylabel else "", labelpad=5)
    value_range = hi - lo
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
    if value_range < 0.005:
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.4f"))
    elif value_range < 0.05:
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.3f"))
    else:
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))

    if show_legend:
        ax.legend(frameon=False, loc="upper left", fontsize=11.4, handlelength=1.7, borderaxespad=0.1)
    if show_auc:
        auc_if = safe_auc(vals_in, vals_fp)
        auc_io = safe_auc(vals_in, vals_out)
        ax.text(
            0.98,
            0.96,
            f"AUC(in/fp)={auc_if:.3f}\nAUC(in/out)={auc_io:.3f}",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=12.2,
            fontweight="bold",
            bbox={"boxstyle": "round,pad=0.22", "facecolor": "white", "edgecolor": "black", "alpha": 0.90},
        )
    style_axis(ax)


def save_separate(groups: dict[str, np.ndarray]) -> None:
    panel_defs = [
        ("axis_entanglement_onaxis_wideslim", ("coeff_inside", "coeff_hard_fp", "coeff_outside"), "On-axis coefficient"),
        ("axis_entanglement_residual_wideslim", ("perp_inside", "perp_hard_fp", "perp_outside"), "Residual score"),
        ("axis_entanglement_margin_wideslim", ("parallel_inside", "parallel_hard_fp", "parallel_outside"), "Margin score"),
    ]
    for i, (name, keys, xlabel) in enumerate(panel_defs):
        fig = plt.figure(figsize=(5.8, 2.20), constrained_layout=False)
        ax = fig.add_axes([0.140, 0.245, 0.835, 0.715])
        draw_panel(
            ax,
            groups,
            keys,
            xlabel,
            show_ylabel=(i == 0),
            show_legend=(i == 0),
            show_auc=True,
            seed_base=100 + i * 10,
        )
        for out in (FIG, SRC):
            fig.savefig(out / f"{name}.pdf", pad_inches=0.0)
            fig.savefig(out / f"{name}.png", dpi=260, pad_inches=0.0)
        plt.close(fig)


def save_combined(groups: dict[str, np.ndarray]) -> None:
    fig = plt.figure(figsize=(14.8, 2.10), constrained_layout=False)
    axes = [
        fig.add_axes([0.055, 0.265, 0.285, 0.685]),
        fig.add_axes([0.370, 0.265, 0.285, 0.685]),
        fig.add_axes([0.685, 0.265, 0.285, 0.685]),
    ]
    panel_defs = [
        (("coeff_inside", "coeff_hard_fp", "coeff_outside"), "On-axis coefficient"),
        (("perp_inside", "perp_hard_fp", "perp_outside"), "Residual score"),
        (("parallel_inside", "parallel_hard_fp", "parallel_outside"), "Margin score"),
    ]
    for i, (ax, (keys, xlabel)) in enumerate(zip(axes, panel_defs)):
        draw_panel(
            ax,
            groups,
            keys,
            xlabel,
            show_ylabel=(i == 0),
            show_legend=(i == 0),
            show_auc=True,
            seed_base=200 + i * 10,
        )
    for out in (FIG, SRC):
        fig.savefig(out / "axis_entanglement_mvtec2visa_wideslim.pdf", pad_inches=0.0)
        fig.savefig(out / "axis_entanglement_mvtec2visa_wideslim.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def main() -> int:
    setup_rc()
    FIG.mkdir(parents=True, exist_ok=True)
    raw = json.loads(JSON_PATH.read_text(encoding="utf-8"))
    groups = {k: np.asarray(v, dtype=np.float32) for k, v in raw["groups"].items()}
    save_separate(groups)
    save_combined(groups)
    print(FIG / "axis_entanglement_mvtec2visa_wideslim.pdf")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
