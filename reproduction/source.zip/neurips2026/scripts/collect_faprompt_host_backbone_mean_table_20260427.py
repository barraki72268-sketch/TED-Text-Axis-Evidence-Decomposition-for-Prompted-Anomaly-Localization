#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"

METRICS = ("pixel_auc", "pixel_ap", "pixel_aupro", "image_auc")
PRESETS = ("visa2mvtec", "mvtec2visa", "visa2mpdd", "visa2btad")

ROWS = {
    "ViT-B/16+": {
        "visa2mvtec": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2mvtec_full_v1" / "summary.json",
        "mvtec2visa": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2visa_full_20260427" / "summary.json",
        "visa2mpdd": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2mpdd_full_20260427" / "summary.json",
        "visa2btad": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2btad_full_20260427" / "summary.json",
    },
    "ViT-H/14": {
        preset: RESULTS / f"faprompt_vith14_prescore_hostaxis_{preset}_fast_20260427" / "summary.json"
        for preset in PRESETS
    },
    "ViT-L/14 OpenAI": {
        preset: RESULTS / f"faprompt_vitl14openai_prescore_hostaxis_{preset}_fast_20260427" / "summary.json"
        for preset in PRESETS
    },
}


def fmt(value: float) -> str:
    return f"{100.0 * value:.2f}"


def metric_tuple(metrics: dict[str, float]) -> str:
    return " / ".join(fmt(metrics[m]) for m in METRICS)


def better_fmt(base: dict[str, float], ours: dict[str, float], ours_side: bool) -> str:
    values = []
    for metric in METRICS:
        value = ours[metric] if ours_side else base[metric]
        text = fmt(value)
        if (ours[metric] > base[metric]) == ours_side:
            text = rf"\textbf{{{text}}}"
        values.append(text)
    return " / ".join(values)


def load_best(path: Path) -> tuple[dict[str, float], str, dict[str, float]]:
    data = json.loads(path.read_text())
    mean = data["mean"]
    base = mean["baseline_official"]
    candidates = {
        key: value
        for key, value in mean["parallel"].items()
        if key.startswith("prescore_rectify_alpha_")
    }
    if not candidates:
        raise ValueError(f"No prescore_rectify candidate in {path}")
    best_name, best_metrics = max(candidates.items(), key=lambda item: item[1]["pixel_auc"])
    return base, best_name, best_metrics


def average(items: list[dict[str, float]]) -> dict[str, float]:
    return {metric: sum(item[metric] for item in items) / len(items) for metric in METRICS}


def main() -> int:
    print("FAPrompt target-wise best alpha")
    print("=" * 34)
    all_rows: dict[str, tuple[dict[str, float], dict[str, float]]] = {}
    pending: list[str] = []

    for backbone, preset_paths in ROWS.items():
        bases: list[dict[str, float]] = []
        ours_list: list[dict[str, float]] = []
        print(f"\n{backbone}")
        for preset in PRESETS:
            path = preset_paths[preset]
            if not path.exists():
                print(f"  {preset}: pending {path}")
                pending.append(f"{backbone} {preset}")
                continue
            base, best_name, ours = load_best(path)
            bases.append(base)
            ours_list.append(ours)
            print(f"  {preset}: {best_name}")
            print(f"    base {metric_tuple(base)}")
            print(f"    ours {metric_tuple(ours)}")
        if len(bases) == len(PRESETS):
            all_rows[backbone] = (average(bases), average(ours_list))

    print("\nLaTeX rows")
    print("=" * 10)
    print(r"\multirow{3}{*}{FAPrompt}")
    for idx, backbone in enumerate(ROWS):
        prefix = "  &" if idx else "  &"
        if backbone in all_rows:
            base, ours = all_rows[backbone]
            print(f"{prefix} {backbone}")
            print(f"  & {better_fmt(base, ours, ours_side=False)}")
            print(f"  & {better_fmt(base, ours, ours_side=True)} \\\\")
        else:
            print(f"{prefix} {backbone}")
            print("  & --.-- / --.-- / --.-- / --.--")
            print("  & --.-- / --.-- / --.-- / --.-- \\\\")

    if pending:
        print("\nPending")
        print("=" * 7)
        for item in pending:
            print(item)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
