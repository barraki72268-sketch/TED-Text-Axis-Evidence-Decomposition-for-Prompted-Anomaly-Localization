from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from prompt_ensemble import tokenize  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    decision_axis,
    load_source_patch_banks_cache,
    logmeanexp_negative_sqdist_1d,
    project_bank,
)
from probe_anomalyclip_wrongclass_semantic_collapse import (  # noqa: E402
    MVTED_CKPT,
    VISA_CKPT,
    aggregate_map_from_patch_features,
    build_eval_dataset,
    global_image_score,
    mask_overlap,
    safe_auc,
    safe_corr,
    top_fraction_mask,
)


def resolve_preset(args) -> None:
    if args.preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtec"
    elif args.preset == "mvtec2visa":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif args.preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif args.preset == "mvtec2btad":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {args.preset}")


def pick_anomaly_sample(dataset, cls_name: str, sample_index: int):
    matches = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        if item["cls_name"] != cls_name:
            continue
        anomaly_flag = item["anomaly"]
        if hasattr(anomaly_flag, "item"):
            anomaly_flag = anomaly_flag.item()
        if int(anomaly_flag) != 1:
            continue
        matches.append(item)
    if sample_index >= len(matches):
        raise IndexError(f"sample_index={sample_index} out of range for class={cls_name}, anomaly_count={len(matches)}")
    return matches[sample_index]


def learned_context_text_pair_for_class(model, learner, cls_name: str, device: str) -> torch.Tensor:
    dtype = model.transformer.get_cast_dtype()
    cls_name = cls_name.replace("_", " ")
    prompt_prefix_pos = " ".join(["X"] * learner.n_ctx_pos)
    prompt_prefix_neg = " ".join(["X"] * learner.n_ctx_neg)

    prompts_pos_text = [prompt_prefix_pos + " " + template.format(cls_name) + "." for template in learner.state_normal_list]
    prompts_neg_text = [prompt_prefix_neg + " " + template.format(cls_name) + "." for template in learner.state_anomaly_list]

    tokenized_prompts_pos = torch.cat([tokenize(p) for p in prompts_pos_text], dim=0).to(device)
    tokenized_prompts_neg = torch.cat([tokenize(p) for p in prompts_neg_text], dim=0).to(device)

    with torch.no_grad():
        embedding_pos = model.token_embedding(tokenized_prompts_pos).type(dtype)
        embedding_neg = model.token_embedding(tokenized_prompts_neg).type(dtype)

    ctx_pos = learner.ctx_pos[0].to(device=device, dtype=dtype)
    ctx_neg = learner.ctx_neg[0].to(device=device, dtype=dtype)

    prompts_pos = []
    for idx in range(embedding_pos.shape[0]):
        prefix = embedding_pos[idx : idx + 1, :1, :]
        suffix = embedding_pos[idx : idx + 1, 1 + learner.n_ctx_pos :, :]
        prompts_pos.append(torch.cat([prefix, ctx_pos[idx : idx + 1], suffix], dim=1))

    prompts_neg = []
    for idx in range(embedding_neg.shape[0]):
        prefix = embedding_neg[idx : idx + 1, :1, :]
        suffix = embedding_neg[idx : idx + 1, 1 + learner.n_ctx_neg :, :]
        prompts_neg.append(torch.cat([prefix, ctx_neg[idx : idx + 1], suffix], dim=1))

    prompts = torch.cat(prompts_pos + prompts_neg, dim=0)
    tokenized_prompts = torch.cat([tokenized_prompts_pos, tokenized_prompts_neg], dim=0)
    compound_prompts_text = [prompt.to(device) for prompt in learner.compound_prompts_text]

    with torch.no_grad():
        text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
        text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
        text_features = F.normalize(text_features, dim=-1)
    return text_features[0]


def compute_parallel_map(
    patch_features: list[torch.Tensor],
    axis: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    image_size: int,
    sigma: float,
    tau: float,
) -> np.ndarray:
    layers = []
    for layer_idx, patch_feature in enumerate(patch_features):
        patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
        coeff = patch @ axis
        fp_coeff, _ = project_bank(fp_banks[layer_idx].to(axis.device), axis)
        def_coeff, _ = project_bank(def_banks[layer_idx].to(axis.device), axis)
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=tau)
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=tau)
        h = int(round(math.sqrt(patch.shape[0])))
        margin = F.interpolate(
            (q_def - q_fp).reshape(1, 1, h, h),
            size=(image_size, image_size),
            mode="bilinear",
            align_corners=False,
        )[0, 0]
        layers.append(margin.detach().cpu().numpy())
    return gaussian_filter(np.mean(np.stack(layers, axis=0), axis=0), sigma=sigma)


def denormalize_image(img_tensor: torch.Tensor) -> np.ndarray:
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = np.transpose(img_tensor.cpu().numpy(), (1, 2, 0))
    img = np.clip((img * std + mean) * 255.0, 0, 255).astype(np.uint8)
    return img


def apply_score_overlay(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.52) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, cv2.COLORMAP_JET)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return np.clip(alpha * image.astype(np.float32) + (1.0 - alpha) * scoremap.astype(np.float32), 0, 255).astype(np.uint8)


def overlay_binary_mask(image: np.ndarray, mask: np.ndarray, color=(255, 80, 40), alpha: float = 0.55) -> np.ndarray:
    out = image.astype(np.float32).copy()
    color_arr = np.array(color, dtype=np.float32)
    out[mask] = (1 - alpha) * out[mask] + alpha * color_arr
    return np.clip(out, 0, 255).astype(np.uint8)


def percentile_bounds(arr: np.ndarray, lo: float = 1.0, hi: float = 99.0) -> tuple[float, float]:
    lo_v = float(np.percentile(arr, lo))
    hi_v = float(np.percentile(arr, hi))
    if hi_v <= lo_v:
        lo_v = float(arr.min())
        hi_v = float(arr.max())
    return lo_v, hi_v


def normalize_map(arr: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((arr - vmin) / denom, 0.0, 1.0)


def normalize_abs_map(arr: np.ndarray, q: float = 99.0) -> np.ndarray:
    bound = max(float(np.percentile(np.abs(arr), q)), 1e-8)
    return np.clip(np.abs(arr) / bound, 0.0, 1.0)


def main() -> None:
    parser = argparse.ArgumentParser("Generate AnomalyCLIP learned-context + class-token swap figure")
    parser.add_argument("--preset", required=True, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--class_name", required=True)
    parser.add_argument("--wrong_class", type=str, default=None)
    parser.add_argument("--sample_index", type=int, default=0)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--save_dir", type=str, required=True)
    args = parser.parse_args()

    resolve_preset(args)
    dataset = build_eval_dataset(args.target_root, args.target_dataset, args.image_size, mode="test")
    item = pick_anomaly_sample(dataset, args.class_name, args.sample_index)

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    image = item["img"].unsqueeze(0).to(args.device)
    gt_mask = item["img_mask"].squeeze().detach().cpu().numpy() > 0.5
    input_img = denormalize_image(item["img"])

    if args.bank_cache_path is None:
        raise ValueError("--bank_cache_path is required for OURS evaluation in this figure.")
    fp_banks, def_banks, bank_stats, cache_meta = load_source_patch_banks_cache(Path(args.bank_cache_path))

    with torch.inference_mode():
        image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)

        learned_pair = get_learned_text_pair(model, learner).to(args.device)
        host_learned_map = aggregate_map_from_patch_features(patch_features, learned_pair, args.image_size, args.sigma)
        host_learned_auc = safe_auc(host_learned_map[gt_mask], host_learned_map[~gt_mask])

        true_pair = learned_context_text_pair_for_class(model, learner, args.class_name, args.device)
        true_map = aggregate_map_from_patch_features(patch_features, true_pair, args.image_size, args.sigma)
        true_auc = safe_auc(true_map[gt_mask], true_map[~gt_mask])
        true_img_score = global_image_score(image_features, true_pair)
        true_ours = compute_parallel_map(
            patch_features,
            decision_axis(true_pair).to(args.device),
            fp_banks,
            def_banks,
            args.image_size,
            args.sigma,
            args.tau,
        )
        true_ours_auc = safe_auc(true_ours[gt_mask], true_ours[~gt_mask])

        if args.wrong_class is None:
            wrong_candidates = []
            for prompt_cls in dataset.obj_list:
                if prompt_cls == args.class_name:
                    continue
                pair = learned_context_text_pair_for_class(model, learner, prompt_cls, args.device)
                score_map = aggregate_map_from_patch_features(patch_features, pair, args.image_size, args.sigma)
                ours_map = compute_parallel_map(
                    patch_features,
                    decision_axis(pair).to(args.device),
                    fp_banks,
                    def_banks,
                    args.image_size,
                    args.sigma,
                    args.tau,
                )
                wrong_candidates.append(
                    {
                        "class": prompt_cls,
                        "map": score_map,
                        "auc": safe_auc(score_map[gt_mask], score_map[~gt_mask]),
                        "image_score": global_image_score(image_features, pair),
                        "ours_map": ours_map,
                        "ours_auc": safe_auc(ours_map[gt_mask], ours_map[~gt_mask]),
                    }
                )
            wrong_candidates.sort(key=lambda row: row["auc"], reverse=True)
            wrong = wrong_candidates[0]
        else:
            pair = learned_context_text_pair_for_class(model, learner, args.wrong_class, args.device)
            score_map = aggregate_map_from_patch_features(patch_features, pair, args.image_size, args.sigma)
            ours_map = compute_parallel_map(
                patch_features,
                decision_axis(pair).to(args.device),
                fp_banks,
                def_banks,
                args.image_size,
                args.sigma,
                args.tau,
            )
            wrong = {
                "class": args.wrong_class,
                "map": score_map,
                "auc": safe_auc(score_map[gt_mask], score_map[~gt_mask]),
                "image_score": global_image_score(image_features, pair),
                "ours_map": ours_map,
                "ours_auc": safe_auc(ours_map[gt_mask], ours_map[~gt_mask]),
            }

    wrong_map = wrong["map"]
    wrong_auc = wrong["auc"]
    wrong_img_score = wrong["image_score"]
    wrong_ours = wrong["ours_map"]
    wrong_ours_auc = wrong["ours_auc"]
    corr = safe_corr(true_map, wrong_map)
    overlap = mask_overlap(top_fraction_mask(true_map, args.map_topk), top_fraction_mask(wrong_map, args.map_topk))
    generic_true_corr = safe_corr(host_learned_map, true_map)
    generic_wrong_corr = safe_corr(host_learned_map, wrong_map)
    ours_corr = safe_corr(true_ours, wrong_ours)
    ours_overlap = mask_overlap(top_fraction_mask(true_ours, args.map_topk), top_fraction_mask(wrong_ours, args.map_topk))

    vmin, vmax = percentile_bounds(
        np.concatenate(
            [
                host_learned_map.reshape(-1),
                true_map.reshape(-1),
                wrong_map.reshape(-1),
            ],
            axis=0,
        )
    )
    ours_vmin, ours_vmax = percentile_bounds(
        np.concatenate(
            [
                true_ours.reshape(-1),
                wrong_ours.reshape(-1),
            ],
            axis=0,
        )
    )

    panels = {
        "input": input_img,
        "gt": overlay_binary_mask(input_img, gt_mask),
        "generic": apply_score_overlay(input_img, normalize_map(host_learned_map, vmin, vmax)),
        "true": apply_score_overlay(input_img, normalize_map(true_map, vmin, vmax)),
        "wrong": apply_score_overlay(input_img, normalize_map(wrong_map, vmin, vmax)),
        "delta": normalize_abs_map(true_map - wrong_map),
        "ours_true": apply_score_overlay(input_img, normalize_map(true_ours, ours_vmin, ours_vmax)),
        "ours_wrong": apply_score_overlay(input_img, normalize_map(wrong_ours, ours_vmin, ours_vmax)),
        "ours_delta": normalize_abs_map(true_ours - wrong_ours),
    }

    fig, axes = plt.subplots(2, 5, figsize=(18, 8), constrained_layout=True)
    layout = [
        ("input", "Input"),
        ("gt", "GT"),
        ("generic", f"Host Learned\n(object)\nAUC={host_learned_auc:.3f}"),
        ("true", f"LearnedCtx(True)\n{args.class_name}\nimg={true_img_score:.3f}\nAUC={true_auc:.3f}"),
        ("wrong", f"LearnedCtx(Wrong)\n{wrong['class']}\nimg={wrong_img_score:.3f}\nAUC={wrong_auc:.3f}"),
        ("delta", f"|LC true-wrong|\ncorr={corr:.3f}\noverlap={overlap:.3f}"),
        ("ours_true", f"OURS(True)\n{args.class_name}\nAUC={true_ours_auc:.3f}"),
        ("ours_wrong", f"OURS(Wrong)\n{wrong['class']}\nAUC={wrong_ours_auc:.3f}"),
        ("ours_delta", f"|O true-wrong|\ncorr={ours_corr:.3f}\noverlap={ours_overlap:.3f}"),
        ("input", ""),
    ]
    for ax, (key, title) in zip(axes.flatten(), layout):
        if key == "input" and title == "":
            ax.axis("off")
            summary_lines = [
                f"learnedctx gap: {true_auc - wrong_auc:+.3f}",
                f"ours gap: {true_ours_auc - wrong_ours_auc:+.3f}",
                f"generic→true corr: {generic_true_corr:.3f}",
                f"generic→wrong corr: {generic_wrong_corr:.3f}",
                f"lc corr/ov: {corr:.3f}/{overlap:.3f}",
                f"ours corr/ov: {ours_corr:.3f}/{ours_overlap:.3f}",
                f"bank: {Path(args.bank_cache_path).name}",
            ]
            ax.text(0.02, 0.95, "\n".join(summary_lines), va="top", ha="left", fontsize=11, family="monospace")
            continue
        img = panels[key]
        if img.ndim == 2:
            ax.imshow(img, cmap="magma")
        else:
            ax.imshow(img)
        ax.set_title(title, fontsize=11)
        ax.axis("off")

    fig.suptitle(
        f"AnomalyCLIP learned-context class-token swap | preset={args.preset} | class={args.class_name}",
        fontsize=14,
    )

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    png_path = save_dir / f"{args.class_name}_learnedctx_classswap.png"
    pdf_path = save_dir / f"{args.class_name}_learnedctx_classswap.pdf"
    json_path = save_dir / f"{args.class_name}_learnedctx_classswap.json"
    fig.savefig(png_path, dpi=220)
    fig.savefig(pdf_path)
    plt.close(fig)

    payload = {
        "preset": args.preset,
        "checkpoint_path": args.checkpoint_path,
        "target_root": args.target_root,
        "target_dataset": args.target_dataset,
        "class_name": args.class_name,
        "wrong_class": wrong["class"],
        "sample_index": args.sample_index,
        "img_path": item["img_path"],
        "host_learned": {
            "auc": host_learned_auc,
        },
        "learned_context_true": {
            "image_score": true_img_score,
            "auc": true_auc,
        },
        "learned_context_wrong": {
            "image_score": wrong_img_score,
            "auc": wrong_auc,
        },
        "ours_true": {
            "auc": true_ours_auc,
        },
        "ours_wrong": {
            "auc": wrong_ours_auc,
        },
        "swap": {
            "learnedctx_auc_gap": true_auc - wrong_auc,
            "learnedctx_corr": corr,
            "learnedctx_topk_overlap": overlap,
            "ours_auc_gap": true_ours_auc - wrong_ours_auc,
            "ours_corr": ours_corr,
            "ours_topk_overlap": ours_overlap,
            "generic_true_corr": generic_true_corr,
            "generic_wrong_corr": generic_wrong_corr,
        },
        "bank_cache_path": args.bank_cache_path,
        "bank_cache_meta": cache_meta,
        "bank_stats": bank_stats,
        "artifacts": {
            "png": str(png_path),
            "pdf": str(pdf_path),
        },
    }
    with open(json_path, "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
