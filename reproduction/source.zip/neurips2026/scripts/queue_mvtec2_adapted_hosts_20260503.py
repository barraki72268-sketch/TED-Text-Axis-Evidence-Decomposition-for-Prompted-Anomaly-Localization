#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "adapted_hosts_mvtec2_20260503"
LOG = RESULTS / "logs"


def run_process(name: str, cmd: list[str], env: dict[str, str]) -> tuple[subprocess.Popen, Path]:
    LOG.mkdir(parents=True, exist_ok=True)
    log_path = LOG / f"{name}.log"
    out = open(log_path, "w", encoding="utf-8")
    print({"stage": "launch", "name": name, "log": str(log_path), "cmd": cmd}, flush=True)
    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        stdout=out,
        stderr=subprocess.STDOUT,
        env=env,
        text=True,
    )
    return proc, log_path


def aaclip_cmd(seed: int, device: str, force: bool) -> tuple[str, list[str]]:
    save_dir = RESULTS / f"aaclip_vitl336_mvtec2mvtecad2_seed{seed}"
    if force and (save_dir / "summary.json").exists():
        (save_dir / "summary.json").unlink()
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/run_aaclip_mvtec2_custom.py",
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    return "aaclip_mvtec2", cmd


def faprompt_cmd(seed: int, device: str, force: bool) -> tuple[str, list[str]]:
    save_dir = RESULTS / f"faprompt_vitl336_mvtec2mvtecad2_seed{seed}"
    if force and (save_dir / "summary.json").exists():
        (save_dir / "summary.json").unlink()
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/run_faprompt_mvtec2_custom.py",
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    return "faprompt_mvtec2", cmd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--hosts", default="aaclip,faprompt")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-adapted-hosts-mvtec2-20260503")
    env.setdefault("TRANSFORMERS_CACHE", "/mnt/data/hf-cache")

    builders = {
        "aaclip": aaclip_cmd,
        "faprompt": faprompt_cmd,
    }
    procs: list[tuple[str, subprocess.Popen, Path]] = []
    for host in [h.strip() for h in args.hosts.split(",") if h.strip()]:
        if host not in builders:
            raise SystemExit(f"unknown host {host}; choices={sorted(builders)}")
        name, cmd = builders[host](args.seed, args.device, args.force)
        save_arg = cmd[cmd.index("--save_dir") + 1]
        if (Path(save_arg) / "summary.json").exists() and not args.force:
            print({"stage": "skip", "name": name, "summary": str(Path(save_arg) / "summary.json")}, flush=True)
            continue
        proc, log_path = run_process(name, cmd, env)
        procs.append((name, proc, log_path))
        time.sleep(5)

    failed = 0
    for name, proc, log_path in procs:
        rc = proc.wait()
        print({"stage": "finished", "name": name, "returncode": rc, "log": str(log_path)}, flush=True)
        failed += int(rc != 0)
    print({"stage": "done", "failed": failed}, flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
