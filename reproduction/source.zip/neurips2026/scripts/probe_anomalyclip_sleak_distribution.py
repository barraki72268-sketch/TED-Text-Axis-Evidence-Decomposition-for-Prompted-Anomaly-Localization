from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner  # noqa: E402
from utils import get_transform  # noqa: E402


def build_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_prompt_learner(model, params, checkpoint_path: Path, device: str):
    learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    learner.load_state_dict(checkpoint["prompt_learner"])
    learner.to(device)
    learner.eval()
    model.to(device)
    model.eval()
    return learner


def load_basis_cache(cache_path: Path) -> tuple[dict[int, torch.Tensor], dict]:
    payload = torch.load(cache_path, map_location="cpu")
    tail_bases = {int(k): v.float() for k, v in payload["tail_bases"].items()}
    basis_stats = payload["basis_stats"]
    return tail_bases, basis_stats


def build_target_loader(target_root: str, image_size: int):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=target_root, transform=preprocess, target_transform=target_transform, dataset_name="visa")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
    return dataset, loader


def score_stats(arr: np.ndarray) -> dict[str, float]:
    if arr.size == 0:
        return {
            "count": 0,
            "mean": 0.0,
            "std": 0.0,
            "p05": 0.0,
            "p25": 0.0,
            "p50": 0.0,
            "p75": 0.0,
            "p95": 0.0,
        }
    return {
        "count": int(arr.size),
        "mean": float(arr.mean()),
        "std": float(arr.std()),
        "p05": float(np.percentile(arr, 5)),
        "p25": float(np.percentile(arr, 25)),
        "p50": float(np.percentile(arr, 50)),
        "p75": float(np.percentile(arr, 75)),
        "p95": float(np.percentile(arr, 95)),
    }


def hist_panel(groups: dict[str, np.ndarray], save_path: Path) -> None:
    plt.figure(figsize=(8, 5))
    bins = np.linspace(0.0, 1.0, 101)
    colors = {
        "normal": "#1f77b4",
        "outside": "#ff7f0e",
        "inside": "#2ca02c",
    }
    labels = {
        "normal": "Normal (good)",
        "outside": "Outside (anomaly bg)",
        "inside": "Inside (gt defect)",
    }
    for key in ["normal", "outside", "inside"]:
        vals = groups[key]
        if vals.size == 0:
            continue
        plt.hist(
            vals,
            bins=bins,
            density=True,
            histtype="step",
            linewidth=2.0,
            color=colors[key],
            label=f"{labels[key]} | mean={vals.mean():.3f}",
        )
    plt.xlabel(r"$S_{leak}(v)$")
    plt.ylabel("Density")
    plt.title("Patch-wise Visual Tail Leakage Score Distribution")
    plt.legend()
    plt.tight_layout()
    save_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=180)
    plt.close()


def main():
    parser = argparse.ArgumentParser("Probe S_leak distribution for baseline AnomalyCLIP")
    parser.add_argument(
        "--target_root",
        type=str,
        default="/mnt/data/gijeong/MMAD_new/VisA",
    )
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--basis_cache",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_source_visual_tail_basis_skip1.pt"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_sleak_distribution_baseline_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--mask_thresh", type=float, default=0.01)
    parser.add_argument("--max_group_points", type=int, default=200000)
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    _ = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    tail_bases, basis_stats = load_basis_cache(Path(args.basis_cache))
    _, loader = build_target_loader(args.target_root, args.image_size)

    per_group: dict[str, list[np.ndarray]] = {"normal": [], "outside": [], "inside": []}
    per_layer_group: dict[int, dict[str, list[np.ndarray]]] = {}

    print(
        json.dumps(
            {
                "stage": "sleak_distribution_start",
                "num_target_images": len(loader.dataset),
                "checkpoint_path": args.checkpoint_path,
                "basis_cache": args.basis_cache,
                "mask_thresh": args.mask_thresh,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            gt_mask = items["img_mask"].to(device)
            is_anomaly = int(items["anomaly"][0].item())

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)

            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < args.feature_map_layer[0]:
                    continue

                patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True).clamp_min(1e-6)
                patch_tok = patch_feature[:, 1:, :]
                n_patch = patch_tok.shape[1]
                side = int(round(math.sqrt(n_patch)))
                if side * side != n_patch:
                    raise RuntimeError(f"Unexpected non-square patch grid: {n_patch}")

                tail = tail_bases[layer_idx].to(device=device, dtype=patch_tok.dtype)
                coeff = torch.matmul(patch_tok, tail)
                leak = coeff.pow(2).sum(dim=-1)
                denom = patch_tok.pow(2).sum(dim=-1).clamp_min(1e-8)
                leak = (leak / denom).reshape(1, 1, side, side)

                mask_small = F.interpolate(gt_mask.float(), size=(side, side), mode="bilinear", align_corners=False)
                mask_bool = (mask_small[0, 0] > args.mask_thresh).detach().cpu().numpy()
                leak_np = leak[0, 0].detach().cpu().numpy()

                layer_store = per_layer_group.setdefault(layer_idx, {"normal": [], "outside": [], "inside": []})
                if is_anomaly and mask_bool.any():
                    outside = leak_np[~mask_bool]
                    inside = leak_np[mask_bool]
                    if outside.size:
                        per_group["outside"].append(outside)
                        layer_store["outside"].append(outside)
                    if inside.size:
                        per_group["inside"].append(inside)
                        layer_store["inside"].append(inside)
                else:
                    vals = leak_np.reshape(-1)
                    per_group["normal"].append(vals)
                    layer_store["normal"].append(vals)

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "sleak_distribution_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    groups_np: dict[str, np.ndarray] = {}
    for key, chunks in per_group.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        if vals.size > args.max_group_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(vals.size, size=args.max_group_points, replace=False)
            vals = vals[idx]
        groups_np[key] = vals.astype(np.float32, copy=False)

    per_layer_summary = {}
    for layer_idx, stores in per_layer_group.items():
        per_layer_summary[str(layer_idx)] = {}
        for key, chunks in stores.items():
            vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
            per_layer_summary[str(layer_idx)][key] = score_stats(vals)

    summary = {
        "checkpoint_path": args.checkpoint_path,
        "basis_cache": args.basis_cache,
        "target_root": args.target_root,
        "mask_thresh": args.mask_thresh,
        "basis_stats": basis_stats,
        "overall": {key: score_stats(vals) for key, vals in groups_np.items()},
        "per_layer": per_layer_summary,
    }

    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    hist_panel(groups_np, save_dir / "sleak_hist.png")
    print(json.dumps(summary["overall"], indent=2))


if __name__ == "__main__":
    main()
