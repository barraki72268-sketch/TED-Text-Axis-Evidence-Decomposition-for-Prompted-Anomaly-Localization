from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANOMALYCLIP_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANOMALYCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ANOMALYCLIP_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner  # noqa: E402
from utils import get_transform  # noqa: E402


def setup_seed(seed: int) -> None:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def apply_ad_scoremap(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.5) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, cv2.COLORMAP_JET)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return (alpha * image.astype(float) + (1 - alpha) * scoremap.astype(float)).astype(np.uint8)


def load_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_prompt_learner(model, params, checkpoint_path: Path, device: str):
    learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    learner.load_state_dict(checkpoint["prompt_learner"])
    learner.to(device)
    learner.eval()
    model.to(device)
    model.eval()
    return learner


@torch.no_grad()
def compute_anomaly_map(model, learner, image_path: Path, image_size: int, sigma: int, features_list: list[int], feature_map_layer: list[int]):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, _ = get_transform(args)

    img = Image.open(image_path).convert("RGB")
    np_img = np.array(img.resize((image_size, image_size)))
    tensor = preprocess(img).reshape(1, 3, image_size, image_size).to(next(model.parameters()).device)

    prompts, tokenized_prompts, compound_prompts_text = learner(cls_id=None)
    dev = next(model.parameters()).device
    prompts = prompts.to(dev)
    tokenized_prompts = tokenized_prompts.to(dev)
    compound_prompts_text = [prompt.to(dev) for prompt in compound_prompts_text]
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = F.normalize(text_features, dim=-1)

    _, patch_features = model.encode_image(tensor, features_list, DPAM_layer=20)
    anomaly_map_list = []
    for idx, patch_feature in enumerate(patch_features):
        if idx >= feature_map_layer[0]:
            patch_feature = F.normalize(patch_feature, dim=-1)
            similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_features[0])
            similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], image_size)
            anomaly_map = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0
            anomaly_map_list.append(anomaly_map)

    anomaly_map = torch.stack(anomaly_map_list).sum(dim=0)
    anomaly_map = torch.stack(
        [torch.from_numpy(gaussian_filter(i, sigma=sigma)) for i in anomaly_map.detach().cpu()],
        dim=0,
    )[0].numpy()
    return np_img, anomaly_map


def normalize_with_bounds(x: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((x - vmin) / denom, 0.0, 1.0)


def save_panel(save_path: Path, image: np.ndarray, maps: dict[str, np.ndarray]) -> None:
    labels = list(maps.keys())
    values = list(maps.values())
    vmin = min(float(v.min()) for v in values)
    vmax = max(float(v.max()) for v in values)

    fig, axes = plt.subplots(2, len(labels) + 1, figsize=(4 * (len(labels) + 1), 8))
    axes[0, 0].imshow(image)
    axes[0, 0].set_title("input")
    axes[0, 0].axis("off")
    axes[1, 0].axis("off")

    for idx, label in enumerate(labels, start=1):
        norm_map = normalize_with_bounds(maps[label], vmin, vmax)
        overlay = apply_ad_scoremap(image, norm_map)
        axes[0, idx].imshow(overlay)
        axes[0, idx].set_title(f"{label} overlay")
        axes[0, idx].axis("off")
        im = axes[1, idx].imshow(norm_map, cmap="jet", vmin=0.0, vmax=1.0)
        axes[1, idx].set_title(f"{label} heatmap")
        axes[1, idx].axis("off")

    cbar = fig.colorbar(im, ax=axes[1, 1:].ravel().tolist(), fraction=0.02, pad=0.02)
    cbar.set_label("normalized anomaly score")
    fig.tight_layout()
    save_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser("Generate same-epoch AnomalyCLIP L_proj comparison visuals")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--seed", type=int, default=111)
    parser.add_argument("--save_dir", type=str, required=True)
    parser.add_argument("--series", action="append", required=True, help="label=/abs/path/to/epoch_X.pth")
    parser.add_argument("--image", action="append", required=True, help="image path")
    args = parser.parse_args()

    setup_seed(args.seed)
    model, params = load_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)

    learners = {}
    for item in args.series:
        label, ckpt = item.split("=", 1)
        learners[label] = load_prompt_learner(model, params, Path(ckpt), args.device)

    save_dir = Path(args.save_dir)
    for image_path in args.image:
        image_path = Path(image_path)
        maps = {}
        np_img = None
        for label, learner in learners.items():
            np_img, amap = compute_anomaly_map(
                model,
                learner,
                image_path,
                args.image_size,
                args.sigma,
                args.features_list,
                args.feature_map_layer,
            )
            maps[label] = amap
        assert np_img is not None
        save_name = f"{image_path.parent.parent.parent.name}_{image_path.parent.parent.name}_{image_path.name.rsplit('.', 1)[0]}.png"
        save_panel(save_dir / save_name, np_img, maps)


if __name__ == "__main__":
    main()
