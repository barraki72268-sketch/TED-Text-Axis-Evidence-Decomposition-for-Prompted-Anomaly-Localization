#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"


def load(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(x: float | None) -> str:
    if x is None:
        return "--.--"
    val = float(x)
    return f"{100.0 * val:.2f}" if abs(val) <= 1.5 else f"{val:.2f}"


def anomalyclip_row(summary: dict[str, Any] | None, mode: str) -> tuple[float | None, ...]:
    if summary is None:
        return (None, None, None, None)
    mode_name = {
        "baseline": "baseline_txt",
        "trainfree": "parallel_margin",
        "calibrated": "ted_calibrated",
    }[mode]
    candidates = [
        row
        for row in summary.get("rows", [])
        if row.get("target_label") == "mean" and row.get("mode") == mode_name
    ]
    if not candidates:
        return (None, None, None, None)
    row = candidates[0]
    return (
        row.get("image_auroc"),
        row.get("pixel_auroc"),
        row.get("pixel_aupro"),
        row.get("pixel_ap"),
    )


def variant_summary(variant: str) -> dict[str, Any] | None:
    return load(RESULTS / f"ablation_ted_anomalyclip_vitl336_mvtec2btad_{variant}_seed0_20260501" / "summary.json")


def print_row(label: str, values: tuple[float | None, ...]) -> None:
    print(f"{label} & " + " & ".join(pct(v) for v in values) + r" \\")


def main() -> int:
    full = variant_summary("rank8")
    if full is None:
        full = load(RESULTS / "anomalyclip_ted_trainfree_anchor_seeded_20260430" / "mvtec2btad_seed0" / "summary.json")

    print("% AnomalyCLIP / ViT-L-14-336 / MVTec->BTAD")
    print("% Metrics: I-AUROC / P-AUROC / P-PRO / P-AP")
    print_row("Baseline", anomalyclip_row(full, "baseline"))
    print_row("Train-free TED", anomalyclip_row(full, "trainfree"))
    print_row("Full TED", anomalyclip_row(full, "calibrated"))
    for variant, label in [
        ("no_hardfp", "w/o hard-FP support"),
        ("no_preserve", "w/o host-margin preserve"),
        ("rank1", "$r=1$"),
        ("rank2", "$r=2$"),
        ("rank4", "$r=4$"),
        ("rank8", "$r=8$"),
    ]:
        summary = variant_summary(variant)
        if variant == "rank8" and summary is None:
            summary = full
        print_row(label, anomalyclip_row(summary, "calibrated"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
