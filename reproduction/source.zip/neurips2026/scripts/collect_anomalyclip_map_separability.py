from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from common_map_group_separability import (  # noqa: E402
    best_component_stats,
    plot_hist,
    save_summary,
    summarize_groups,
    top_fraction_mask,
    topk_mean_masked,
)
from dataset import Dataset  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner  # noqa: E402
from utils import get_transform  # noqa: E402


def build_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_text_features(model, params, checkpoint_path: Path, device: str) -> torch.Tensor:
    prompt_learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    prompt_learner.eval()
    model.to(device)
    model.eval()

    prompts, tokenized_prompts, compound_prompts_text = prompt_learner(cls_id=None)
    prompts = prompts.to(device)
    tokenized_prompts = tokenized_prompts.to(device)
    compound_prompts_text = [prompt.to(device) for prompt in compound_prompts_text]
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)
    return text_features


def main():
    parser = argparse.ArgumentParser("Collect Normal / Hard FP / True Defect separability for AnomalyCLIP")
    parser.add_argument("--data_path", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_points", type=int, default=200000)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_map_separability_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    text_features = load_text_features(model, params, Path(args.checkpoint_path), device)

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.data_path, transform=preprocess, target_transform=target_transform, dataset_name=args.dataset)
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    groups = {"normal": [], "hard_fp": [], "true_defect": [], "outside": []}
    matched = {
        "hard_fp_topk": [],
        "true_defect_topk": [],
        "outside_topk": [],
        "hard_fp_comp_peak": [],
        "hard_fp_comp_mean": [],
        "hard_fp_comp_area": [],
        "true_defect_comp_peak": [],
        "true_defect_comp_mean": [],
        "true_defect_comp_area": [],
        "outside_comp_peak": [],
        "outside_comp_mean": [],
        "outside_comp_area": [],
    }

    print(
        json.dumps(
            {
                "stage": "map_separability_start",
                "num_images": len(dataset),
                "hard_frac": args.hard_frac,
                "checkpoint_path": args.checkpoint_path,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            maps = []
            for idx, patch_feature in enumerate(patch_features):
                if idx < args.feature_map_layer[0]:
                    continue
                patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_features[0])
                similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], args.image_size)
                anomaly_map = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0
                maps.append(anomaly_map)

            anomaly_map = torch.stack(maps).sum(dim=0)[0].detach().cpu().numpy()
            anomaly_map = gaussian_filter(anomaly_map, sigma=args.sigma)
            score_mask = top_fraction_mask(anomaly_map, args.hard_frac)

            if is_anomaly and gt_mask.any():
                groups["true_defect"].append(anomaly_map[gt_mask].reshape(-1))
                groups["outside"].append(anomaly_map[~gt_mask].reshape(-1))
                matched["true_defect_topk"].append(topk_mean_masked(anomaly_map, gt_mask, args.hard_frac))
                matched["outside_topk"].append(topk_mean_masked(anomaly_map, ~gt_mask, args.hard_frac))
                defect_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="inside")
                outside_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="outside")
                if defect_comp is not None:
                    matched["true_defect_comp_peak"].append(defect_comp["peak"])
                    matched["true_defect_comp_mean"].append(defect_comp["mean"])
                    matched["true_defect_comp_area"].append(defect_comp["area"])
                if outside_comp is not None:
                    matched["outside_comp_peak"].append(outside_comp["peak"])
                    matched["outside_comp_mean"].append(outside_comp["mean"])
                    matched["outside_comp_area"].append(outside_comp["area"])
            else:
                hard_mask = score_mask
                groups["hard_fp"].append(anomaly_map[hard_mask].reshape(-1))
                groups["normal"].append(anomaly_map[~hard_mask].reshape(-1))
                matched["hard_fp_topk"].append(float(anomaly_map[hard_mask].mean()))
                hard_comp = best_component_stats(anomaly_map, score_mask)
                if hard_comp is not None:
                    matched["hard_fp_comp_peak"].append(hard_comp["peak"])
                    matched["hard_fp_comp_mean"].append(hard_comp["mean"])
                    matched["hard_fp_comp_area"].append(hard_comp["area"])

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "map_separability_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    groups_np = {}
    for key, chunks in groups.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        if vals.size > args.max_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(vals.size, size=args.max_points, replace=False)
            vals = vals[idx]
        groups_np[key] = vals.astype(np.float32, copy=False)

    summary = {
        "host": "AnomalyCLIP",
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "num_images": len(dataset),
        "summary": summarize_groups(groups_np, max_summary_points=args.max_points),
    }
    matched_np = {
        key: np.asarray([v for v in vals if np.isfinite(v)], dtype=np.float32)
        for key, vals in matched.items()
    }
    summary["matched_summary"] = summarize_groups(
        matched_np,
        max_summary_points=args.max_points,
        pairs=[
            ("true_defect_topk", "hard_fp_topk"),
            ("true_defect_topk", "outside_topk"),
            ("true_defect_comp_peak", "hard_fp_comp_peak"),
            ("true_defect_comp_peak", "outside_comp_peak"),
            ("true_defect_comp_mean", "hard_fp_comp_mean"),
            ("true_defect_comp_mean", "outside_comp_mean"),
        ],
    )
    save_dir = Path(args.save_dir)
    save_summary(summary, save_dir)
    plot_hist(groups_np, save_dir / "hist.png", "AnomalyCLIP Map Separability")
    plot_hist(
        {
            "hard_fp_topk": matched_np["hard_fp_topk"],
            "true_defect_topk": matched_np["true_defect_topk"],
            "outside_topk": matched_np["outside_topk"],
        },
        save_dir / "matched_topk_hist.png",
        "AnomalyCLIP Matched Top-k Separability",
    )
    plot_hist(
        {
            "hard_fp_comp_peak": matched_np["hard_fp_comp_peak"],
            "true_defect_comp_peak": matched_np["true_defect_comp_peak"],
            "outside_comp_peak": matched_np["outside_comp_peak"],
        },
        save_dir / "matched_component_peak_hist.png",
        "AnomalyCLIP Component Peak Separability",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
