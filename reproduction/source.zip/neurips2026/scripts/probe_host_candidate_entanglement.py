#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[2]
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))


def safe_auc(labels: np.ndarray, scores: np.ndarray) -> float:
    labels = np.asarray(labels).astype(np.int64)
    if labels.size == 0 or len(np.unique(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(labels, scores))


def safe_ap(labels: np.ndarray, scores: np.ndarray) -> float:
    labels = np.asarray(labels).astype(np.int64)
    if labels.size == 0 or len(np.unique(labels)) < 2:
        return float("nan")
    return float(average_precision_score(labels, scores))


def summarize_binary_scores(labels: np.ndarray, scores: np.ndarray) -> dict:
    labels = np.asarray(labels).astype(np.int64)
    scores = np.asarray(scores).astype(np.float32)
    pos = scores[labels == 1]
    neg = scores[labels == 0]
    if pos.size == 0 or neg.size == 0:
        return {
            "auc": float("nan"),
            "ap": float("nan"),
            "pos_mean": float("nan"),
            "neg_mean": float("nan"),
            "gap": float("nan"),
            "hardfp_above_defect_median": float("nan"),
            "overlap_iqr": float("nan"),
        }
    q25_pos, q50_pos, q75_pos = np.quantile(pos, [0.25, 0.5, 0.75])
    q25_neg, q50_neg, q75_neg = np.quantile(neg, [0.25, 0.5, 0.75])
    return {
        "auc": safe_auc(labels, scores),
        "ap": safe_ap(labels, scores),
        "pos_mean": float(pos.mean()),
        "neg_mean": float(neg.mean()),
        "gap": float(pos.mean() - neg.mean()),
        "pos_median": float(q50_pos),
        "neg_median": float(q50_neg),
        "hardfp_above_defect_median": float((neg > q50_pos).mean()),
        "overlap_iqr": float(max(0.0, min(q75_pos, q75_neg) - max(q25_pos, q25_neg))),
    }


def top_indices(scores: torch.Tensor, frac: float, cap: int | None = None) -> torch.Tensor:
    k = max(1, int(math.ceil(scores.numel() * frac)))
    if cap is not None:
        k = min(k, cap)
    return torch.topk(scores, k=k, largest=True).indices


def downsample_mask_to_patch(mask: torch.Tensor, side: int) -> torch.Tensor:
    ds = F.interpolate(mask.float(), size=(side, side), mode="nearest")
    return ds[:, 0].reshape(mask.shape[0], -1) > 0.5


def zscore_1d(x: torch.Tensor) -> torch.Tensor:
    return (x - x.mean()) / x.std().clamp_min(1e-6)


def collect_scores_faprompt(args) -> dict:
    from official_parallel_test_faprompt import (
        PRESET_CONFIGS,
        MetaDataset,
        build_model,
        compute_faprompt_outputs,
        get_or_collect_source_banks,
        learned_text_pair,
        logmeanexp_negative_sqdist_1d,
    )

    cfg = dict(PRESET_CONFIGS[args.preset])
    device = torch.device(args.device)
    model, prompt_learner = build_model(
        device=device,
        checkpoint_path=cfg["checkpoint_path"],
        depth=args.depth,
        n_ctx=args.n_ctx,
        t_n_ctx=args.t_n_ctx,
    )
    banks = get_or_collect_source_banks(
        model=model,
        prompt_learner=prompt_learner,
        preset=args.preset,
        source_root=cfg["source_root"],
        checkpoint_path=cfg["checkpoint_path"],
        cache_dir=ROOT / "neurips2026" / "results" / "bank_cache",
        image_size=args.image_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=device,
        features_list=args.features_list,
        sigma=args.sigma,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_fp_total=args.max_fp_total,
        max_defect_total=args.max_defect_total,
        normal_topk_frac=args.bank_normal_topk_frac,
        seed=args.seed,
        force_rebuild_bank=False,
    )
    base_text_pair = learned_text_pair(model, prompt_learner)
    axis = F.normalize(base_text_pair[1] - base_text_pair[0], dim=0)
    fp_proj = banks["fp"].to(device) @ axis
    def_proj = banks["defect"].to(device) @ axis
    target_meta = json.loads((Path(cfg["target_root"]) / "meta.json").read_text())
    class_names = sorted(target_meta["test"].keys())
    if args.class_name:
        class_names = [c for c in class_names if c == args.class_name]

    rows = []
    for class_name in class_names:
        ds = MetaDataset(cfg["target_root"], args.image_size, split="test", class_name=class_name)
        if args.target_limit_per_class and args.target_limit_per_class < len(ds):
            rng = random.Random(args.seed)
            idxs = list(range(len(ds)))
            rng.shuffle(idxs)
            ds = torch.utils.data.Subset(ds, idxs[: args.target_limit_per_class])
        dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=torch.cuda.is_available())
        labels: List[int] = []
        baseline_scores: List[float] = []
        residual_scores: List[float] = []
        fused_scores: List[float] = []
        num_norm = 0
        num_anom = 0
        with torch.no_grad():
            for batch in dl:
                image = batch["image"].to(device)
                mask = batch["mask"].to(device)
                label = batch["label"].cpu().numpy()
                out = compute_faprompt_outputs(model, prompt_learner, image, args.features_list, args.image_size, args.sigma, base_text_pair)
                tokens = out["patch_tokens"]
                baseline = out["token_score"]
                q = tokens @ axis
                q_def = logmeanexp_negative_sqdist_1d(q, def_proj, tau=args.tau, chunk=args.bank_chunk)
                q_fp = logmeanexp_negative_sqdist_1d(q, fp_proj, tau=args.tau, chunk=args.bank_chunk)
                residual = q_def - args.fp_weight * q_fp
                side = int(round(math.sqrt(tokens.shape[1])))
                patch_mask = downsample_mask_to_patch(mask, side)
                for bi in range(tokens.shape[0]):
                    if int(label[bi]) == 0:
                        idx = top_indices(baseline[bi], args.candidate_topk_frac, args.max_candidates_per_image)
                        y = 0
                        num_norm += 1
                    else:
                        pos_idx = torch.nonzero(patch_mask[bi], as_tuple=False).flatten()
                        if pos_idx.numel() == 0:
                            continue
                        idx_local = top_indices(baseline[bi, pos_idx], args.candidate_topk_frac, args.max_candidates_per_image)
                        idx = pos_idx[idx_local]
                        y = 1
                        num_anom += 1
                    b = baseline[bi, idx].detach().float()
                    r = residual[bi, idx].detach().float()
                    f = zscore_1d(b) + args.alpha * zscore_1d(r) if idx.numel() > 1 else b + args.alpha * r
                    labels.extend([y] * idx.numel())
                    baseline_scores.extend(b.cpu().tolist())
                    residual_scores.extend(r.cpu().tolist())
                    fused_scores.extend(f.cpu().tolist())
        row = {
            "class_name": class_name,
            "num_normal_images": num_norm,
            "num_anomaly_images": num_anom,
            "num_candidates": len(labels),
            "baseline": summarize_binary_scores(np.asarray(labels), np.asarray(baseline_scores)),
            "ours_residual": summarize_binary_scores(np.asarray(labels), np.asarray(residual_scores)),
            "fused": summarize_binary_scores(np.asarray(labels), np.asarray(fused_scores)),
        }
        if args.save_score_arrays:
            score_dir = Path(args.save_dir)
            score_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(
                score_dir / f"scores_{class_name}.npz",
                labels=np.asarray(labels, dtype=np.int64),
                baseline=np.asarray(baseline_scores, dtype=np.float32),
                residual=np.asarray(residual_scores, dtype=np.float32),
                fused=np.asarray(fused_scores, dtype=np.float32),
            )
        rows.append(row)
        print(json.dumps({"stage": "class_done", "host": "faprompt", "preset": args.preset, "class_name": class_name, "num_candidates": len(labels)}), flush=True)
    return {
        "host": "faprompt",
        "preset": args.preset,
        "source_dataset": cfg["source_dataset"],
        "target_dataset": cfg["target_dataset"],
        "rows": rows,
    }


def collect_scores_aaclip(args) -> dict:
    from official_parallel_test_aaclip import (
        PRESET_CONFIGS,
        GenericMetaDataset,
        build_transforms,
        collect_source_banks,
        get_bank_cache_path,
        get_or_collect_source_banks,
        logmeanexp_negative_sqdist_1d,
        patch_score_grid,
        setup_seed,
    )

    setup_seed(args.seed)
    import official_parallel_test_aaclip as aa

    aa._add_aaclip_to_syspath()
    aa.ensure_aaclip_pretrained_weight()
    from model.adapter import AdaptedCLIP
    from model.clip import create_model
    from forward_utils import get_adapted_text_embedding

    cfg = dict(PRESET_CONFIGS[args.preset])
    device = torch.device(args.device)
    clip_model = create_model(
        model_name="ViT-L-14-336",
        img_size=args.image_size,
        device=device,
        pretrained="openai",
        require_pretrained=True,
    )
    clip_model.eval()
    model = AdaptedCLIP(
        clip_model=clip_model,
        text_adapt_weight=0.1,
        image_adapt_weight=0.1,
        text_adapt_until=3,
        image_adapt_until=6,
        relu=False,
    ).to(device)
    image_ckpt = os.path.join(cfg["ckpt_dir"], "image_adapter.pth")
    ckpt = torch.load(image_ckpt, map_location="cpu")
    model.image_adapter.load_state_dict(ckpt["image_adapter"], strict=True)
    text_ckpt = os.path.join(cfg["ckpt_dir"], "text_adapter.pth")
    if os.path.exists(text_ckpt):
        ckpt_t = torch.load(text_ckpt, map_location="cpu")
        model.text_adapter.load_state_dict(ckpt_t["text_adapter"], strict=True)
    model.eval()
    for p in model.parameters():
        p.requires_grad = False

    banks = get_or_collect_source_banks(
        model=model,
        preset=args.preset,
        source_dataset=cfg["source_dataset"],
        source_root=cfg["source_root"],
        ckpt_dir=cfg["ckpt_dir"],
        cache_dir=ROOT / "neurips2026" / "results" / "bank_cache",
        img_size=args.image_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=device,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        normal_topk_frac=args.bank_normal_topk_frac,
        defect_topk_frac=args.bank_defect_topk_frac,
        seed=args.seed,
        source_limit_per_class=None,
    )

    image_transform, mask_transform = build_transforms(args.image_size)
    text_embeddings = get_adapted_text_embedding(model, cfg["target_dataset"], device)
    target_meta = json.loads((Path(cfg["target_root"]) / "meta.json").read_text())
    class_names = sorted(target_meta["test"].keys())
    if args.class_name:
        class_names = [c for c in class_names if c == args.class_name]
    rows = []
    for class_name in class_names:
        ds = GenericMetaDataset(cfg["target_root"], image_transform, mask_transform, split="test", class_name=class_name)
        if args.target_limit_per_class and args.target_limit_per_class < len(ds):
            rng = random.Random(args.seed)
            idxs = list(range(len(ds)))
            rng.shuffle(idxs)
            ds = torch.utils.data.Subset(ds, idxs[: args.target_limit_per_class])
        dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=torch.cuda.is_available())
        text_feature = text_embeddings[class_name]
        axis = F.normalize(text_feature[:, 1] - text_feature[:, 0], dim=0)
        fp_proj = [F.normalize(t.to(device), dim=-1) @ axis for t in banks["fp"]]
        def_proj = [F.normalize(t.to(device), dim=-1) @ axis for t in banks["defect"]]
        labels: List[int] = []
        baseline_scores: List[float] = []
        residual_scores: List[float] = []
        fused_scores: List[float] = []
        num_norm = 0
        num_anom = 0
        with torch.no_grad():
            for batch in dl:
                image = batch["image"].to(device)
                mask = batch["mask"].to(device)
                label = batch["label"].cpu().numpy()
                seg_tokens, _ = model(image)
                layer_baseline = []
                layer_residual = []
                for li, tokens in enumerate(seg_tokens):
                    layer_baseline.append(patch_score_grid(tokens, text_feature))
                    q = tokens @ axis
                    q_def = logmeanexp_negative_sqdist_1d(q, def_proj[li], tau=args.tau)
                    q_fp = logmeanexp_negative_sqdist_1d(q, fp_proj[li], tau=args.tau)
                    layer_residual.append(q_def - args.fp_weight * q_fp)
                baseline = torch.stack(layer_baseline, dim=0).sum(0)
                residual = torch.stack(layer_residual, dim=0).mean(0)
                side = int(round(math.sqrt(baseline.shape[1])))
                patch_mask = downsample_mask_to_patch(mask, side)
                for bi in range(baseline.shape[0]):
                    if int(label[bi]) == 0:
                        idx = top_indices(baseline[bi], args.candidate_topk_frac, args.max_candidates_per_image)
                        y = 0
                        num_norm += 1
                    else:
                        pos_idx = torch.nonzero(patch_mask[bi], as_tuple=False).flatten()
                        if pos_idx.numel() == 0:
                            continue
                        idx_local = top_indices(baseline[bi, pos_idx], args.candidate_topk_frac, args.max_candidates_per_image)
                        idx = pos_idx[idx_local]
                        y = 1
                        num_anom += 1
                    b = baseline[bi, idx].detach().float()
                    r = residual[bi, idx].detach().float()
                    f = zscore_1d(b) + args.alpha * zscore_1d(r) if idx.numel() > 1 else b + args.alpha * r
                    labels.extend([y] * idx.numel())
                    baseline_scores.extend(b.cpu().tolist())
                    residual_scores.extend(r.cpu().tolist())
                    fused_scores.extend(f.cpu().tolist())
        row = {
            "class_name": class_name,
            "num_normal_images": num_norm,
            "num_anomaly_images": num_anom,
            "num_candidates": len(labels),
            "baseline": summarize_binary_scores(np.asarray(labels), np.asarray(baseline_scores)),
            "ours_residual": summarize_binary_scores(np.asarray(labels), np.asarray(residual_scores)),
            "fused": summarize_binary_scores(np.asarray(labels), np.asarray(fused_scores)),
        }
        if args.save_score_arrays:
            score_dir = Path(args.save_dir)
            score_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(
                score_dir / f"scores_{class_name}.npz",
                labels=np.asarray(labels, dtype=np.int64),
                baseline=np.asarray(baseline_scores, dtype=np.float32),
                residual=np.asarray(residual_scores, dtype=np.float32),
                fused=np.asarray(fused_scores, dtype=np.float32),
            )
        rows.append(row)
        print(json.dumps({"stage": "class_done", "host": "aaclip", "preset": args.preset, "class_name": class_name, "num_candidates": len(labels)}), flush=True)
    return {
        "host": "aaclip",
        "preset": args.preset,
        "source_dataset": cfg["source_dataset"],
        "target_dataset": cfg["target_dataset"],
        "rows": rows,
    }


def add_mean_summary(result: dict) -> dict:
    rows = result["rows"]
    keys = ["baseline", "ours_residual", "fused"]
    summary = {}
    for key in keys:
        summary[key] = {}
        for metric in ["auc", "ap", "gap", "hardfp_above_defect_median", "overlap_iqr"]:
            vals = [r[key][metric] for r in rows if not np.isnan(r[key][metric])]
            summary[key][metric] = float(np.mean(vals)) if vals else float("nan")
    result["mean"] = summary
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", type=str, required=True, choices=["faprompt", "aaclip"])
    ap.add_argument("--preset", type=str, required=True)
    ap.add_argument("--save_dir", type=str, required=True)
    ap.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--image_size", type=int, default=518)
    ap.add_argument("--batch_size", type=int, default=1)
    ap.add_argument("--num_workers", type=int, default=2)
    ap.add_argument("--class_name", type=str, default="")
    ap.add_argument("--target_limit_per_class", type=int, default=0)
    ap.add_argument("--candidate_topk_frac", type=float, default=0.01)
    ap.add_argument("--max_candidates_per_image", type=int, default=16)
    ap.add_argument("--alpha", type=float, default=0.25)
    ap.add_argument("--tau", type=float, default=0.1)
    ap.add_argument("--fp_weight", type=float, default=1.0)
    ap.add_argument("--bank_chunk", type=int, default=2048)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    ap.add_argument("--depth", type=int, default=9)
    ap.add_argument("--n_ctx", type=int, default=12)
    ap.add_argument("--t_n_ctx", type=int, default=4)
    ap.add_argument("--sigma", type=int, default=4)
    ap.add_argument("--max_fp_per_class", type=int, default=512)
    ap.add_argument("--max_defect_per_class", type=int, default=512)
    ap.add_argument("--max_fp_total", type=int, default=4096)
    ap.add_argument("--max_defect_total", type=int, default=4096)
    ap.add_argument("--bank_normal_topk_frac", type=float, default=0.01)
    ap.add_argument("--bank_defect_topk_frac", type=float, default=0.25)
    ap.add_argument("--save_score_arrays", action="store_true")
    args = ap.parse_args()

    if args.host == "faprompt":
        result = collect_scores_faprompt(args)
    else:
        result = collect_scores_aaclip(args)
    result.update(
        {
            "candidate_topk_frac": args.candidate_topk_frac,
            "max_candidates_per_image": args.max_candidates_per_image,
            "alpha": args.alpha,
            "tau": args.tau,
            "fp_weight": args.fp_weight,
        }
    )
    result = add_mean_summary(result)
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    out = save_dir / "summary.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result["mean"], indent=2), flush=True)
    print(f"[OK] wrote {out}", flush=True)


if __name__ == "__main__":
    main()
