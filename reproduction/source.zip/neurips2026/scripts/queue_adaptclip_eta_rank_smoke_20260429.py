from __future__ import annotations

import argparse
import json
import math
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaptclip_vlrefine.py"
CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
BANK = ROOT / "neurips2026" / "results" / "bank_cache" / "adaptclip_ted_mvtec_vl_lastlayer_fastaupro_seed0.pt"
OUT_ROOT = ROOT / "neurips2026" / "results"
TABLE_DIR = OUT_ROOT / "tables"


CLASSES = ["pipe_fryum", "cashew", "fryum", "candle", "pcb1"]
RANKS = [2, 4, 8, 16]
ETA_MAXES = [0.2, 0.5, 1.0]


def base_cmd(cls_name: str, rank: int, eta_max: float, device: str, save_dir: Path) -> list[str]:
    return [
        str(PYTHON),
        str(SCRIPT),
        "--source_root",
        str(MVTEC_ROOT),
        "--source_dataset",
        "mvtec",
        "--target_root",
        str(VISA_ROOT),
        "--target_dataset",
        "visa",
        "--checkpoint_path",
        str(CKPT),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(BANK),
        "--class_name",
        cls_name,
        "--pretrained_model",
        "ViT-L/14@336px",
        "--features_list",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "1",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--corr_alpha",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        str(eta_max),
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        str(rank),
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--seed",
        "0",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "--device",
        device,
        "--num_workers",
        "4",
    ]


def mean_rows(summary_path: Path) -> dict[str, dict]:
    data = json.load(open(summary_path))
    return {row["mode"]: row for row in data["rows"] if row.get("target_label") == "mean"}


def metric_tuple(row: dict) -> tuple[float, float, float]:
    return (
        100.0 * float(row.get("image_auroc", float("nan"))),
        100.0 * float(row.get("pixel_auroc", float("nan"))),
        100.0 * float(row.get("pixel_ap", float("nan"))),
    )


def fmt(x: float) -> str:
    return "--.--" if math.isnan(x) else f"{x:.2f}"


def collect() -> list[dict]:
    records = []
    for cls_name in CLASSES:
        for rank in RANKS:
            for eta_max in ETA_MAXES:
                eta_tag = str(eta_max).replace(".", "p")
                save_dir = OUT_ROOT / f"adaptclip_eta_rank_smoke_vitl336_mvtec2visa_{cls_name}_r{rank}_eta{eta_tag}_seed0_20260429"
                summary = save_dir / "summary.json"
                if not summary.exists():
                    continue
                rows = mean_rows(summary)
                if "baseline_txt" not in rows or "ted_calibrated_vl" not in rows:
                    continue
                b_i, b_p, b_ap = metric_tuple(rows["baseline_txt"])
                c_i, c_p, c_ap = metric_tuple(rows["ted_calibrated_vl"])
                t_i, t_p, t_ap = metric_tuple(rows.get("ted_trainfree_vl", rows["baseline_txt"]))
                records.append(
                    {
                        "class": cls_name,
                        "rank": rank,
                        "eta_max": eta_max,
                        "base_i": b_i,
                        "base_p": b_p,
                        "base_ap": b_ap,
                        "trainfree_i_delta": t_i - b_i,
                        "trainfree_p_delta": t_p - b_p,
                        "trainfree_ap_delta": t_ap - b_ap,
                        "calib_i_delta": c_i - b_i,
                        "calib_p_delta": c_p - b_p,
                        "calib_ap_delta": c_ap - b_ap,
                    }
                )
    return records


def write_summary(records: list[dict]) -> None:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    out_json = TABLE_DIR / "adaptclip_eta_rank_smoke_20260429.json"
    out_json.write_text(json.dumps(records, indent=2))
    if not records:
        print(json.dumps({"records": 0, "out_json": str(out_json)}, indent=2), flush=True)
        return
    grouped = {}
    for rec in records:
        key = (rec["rank"], rec["eta_max"])
        grouped.setdefault(key, []).append(rec)
    rows = []
    for (rank, eta_max), vals in sorted(grouped.items()):
        rows.append(
            {
                "rank": rank,
                "eta_max": eta_max,
                "classes": len(vals),
                "mean_calib_ap_delta": sum(v["calib_ap_delta"] for v in vals) / len(vals),
                "mean_calib_p_delta": sum(v["calib_p_delta"] for v in vals) / len(vals),
                "min_calib_ap_delta": min(v["calib_ap_delta"] for v in vals),
                "mean_trainfree_ap_delta": sum(v["trainfree_ap_delta"] for v in vals) / len(vals),
            }
        )
    out_summary = TABLE_DIR / "adaptclip_eta_rank_smoke_summary_20260429.json"
    out_summary.write_text(json.dumps(rows, indent=2))
    print(json.dumps({"records": len(records), "summary": rows, "out_json": str(out_json)}, indent=2), flush=True)


def main() -> None:
    global CLASSES, RANKS, ETA_MAXES
    parser = argparse.ArgumentParser("AdaptCLIP calibrator rank/eta smoke sweep.")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--classes", default=",".join(CLASSES))
    parser.add_argument("--ranks", default=",".join(str(x) for x in RANKS))
    parser.add_argument("--eta_maxes", default=",".join(str(x) for x in ETA_MAXES))
    parser.add_argument("--collect_only", action="store_true")
    args = parser.parse_args()

    CLASSES = [x.strip() for x in args.classes.split(",") if x.strip()]
    RANKS = [int(x) for x in args.ranks.split(",") if x.strip()]
    ETA_MAXES = [float(x) for x in args.eta_maxes.split(",") if x.strip()]

    if not args.collect_only:
        for cls_name in CLASSES:
            for rank in RANKS:
                for eta_max in ETA_MAXES:
                    eta_tag = str(eta_max).replace(".", "p")
                    save_dir = OUT_ROOT / f"adaptclip_eta_rank_smoke_vitl336_mvtec2visa_{cls_name}_r{rank}_eta{eta_tag}_seed0_20260429"
                    summary = save_dir / "summary.json"
                    if summary.exists():
                        print(f"[skip] {save_dir}", flush=True)
                        continue
                    print(f"[run] class={cls_name} rank={rank} eta_max={eta_max}", flush=True)
                    cmd = base_cmd(cls_name, rank, eta_max, args.device, save_dir)
                    subprocess.run(cmd, cwd=str(ROOT), check=True)
    write_summary(collect())


if __name__ == "__main__":
    main()
