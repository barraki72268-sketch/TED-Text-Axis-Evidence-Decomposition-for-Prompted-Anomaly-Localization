from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"
OUT_DIR = RESULTS / "entanglement_story_4subplot_figure"

HOST_ORDER = ["AnomalyCLIP", "AdaptCLIP", "AdaCLIP", "FAPrompt"]
HOST_SHORT = {
    "AnomalyCLIP": "Anomaly",
    "AdaptCLIP": "Adapt",
    "AdaCLIP": "Ada",
    "FAPrompt": "FA",
}
HOST_COLORS = {
    "AnomalyCLIP": "#24455C",
    "AdaptCLIP": "#2A7F62",
    "AdaCLIP": "#C06C2B",
    "FAPrompt": "#B0433A",
}
RAW_ORDER = [
    ("RawCLIP ViT-B", RESULTS / "rawclip_vitb_gtfree_entanglement" / "metrics.json"),
    ("RawCLIP ViT-L", RESULTS / "rawfamily_gtfree_entanglement" / "rawclip_vitl" / "metrics.json"),
    ("RawCLIP ViT-L OpenAI", RESULTS / "rawfamily_gtfree_entanglement" / "rawclip_vitl14openai" / "metrics.json"),
    ("RawCLIP ViT-H", RESULTS / "rawfamily_gtfree_entanglement" / "rawclip_vith14" / "metrics.json"),
    ("RawImageBind", RESULTS / "rawfamily_gtfree_entanglement" / "rawimagebind" / "metrics.json"),
]
RAW_SHORT = {
    "RawCLIP ViT-B": "ViT-B",
    "RawCLIP ViT-L": "ViT-L",
    "RawCLIP ViT-L OpenAI": "ViT-L OA",
    "RawCLIP ViT-H": "ViT-H",
    "RawImageBind": "ImageBind",
}
RAW_COLORS = {
    "RawCLIP ViT-B": "#6B8E23",
    "RawCLIP ViT-L": "#2E7D6B",
    "RawCLIP ViT-L OpenAI": "#1F5C99",
    "RawCLIP ViT-H": "#A85D2A",
    "RawImageBind": "#7A5EA8",
}


def load_json(path: Path) -> dict:
    with path.open("r") as f:
        return json.load(f)


def load_raw_rows() -> list[dict]:
    rows = []
    for label, path in RAW_ORDER:
        data = load_json(path)
        metrics = data["rows"]
        raw_auc = float(np.mean([r["raw_auc"] for r in metrics]))
        ours_auc = float(np.mean([r["parallel_auc"] for r in metrics]))
        auc_gain = ours_auc - raw_auc
        rows.append(
            {
                "model": label,
                "raw_auc": raw_auc,
                "ours_auc": ours_auc,
                "auc_gain": auc_gain,
            }
        )
    return rows


def load_inheritance_rows() -> list[dict]:
    data = load_json(RESULTS / "rawhost_inheritance_vitl_to_anomalyclip" / "metrics.json")
    return data["rows"]


def load_host_rows() -> list[dict]:
    data = load_json(RESULTS / "host_entanglement_correction_figure" / "host_entanglement_correction.json")
    base = {row["host"]: row for row in data["rows"] if row["host"] in HOST_ORDER}
    survey = load_json(RESULTS / "quick_host_survey_20260425.json")["AD_host_map_separability"]
    rows = []
    for host in HOST_ORDER:
        row = dict(base[host])
        row["baseline_p50_gap"] = survey[host]["baseline_p50_gap"]
        rows.append(row)
    return rows


def style_axis(ax) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(1.2)
    ax.spines["bottom"].set_linewidth(1.2)
    ax.tick_params(labelsize=11, width=1.1)
    ax.grid(axis="y", alpha=0.14, linewidth=0.8)


def spread_positions(values: list[float], min_gap: float, low: float, high: float) -> list[float]:
    order = np.argsort(values)
    out = np.array(values, dtype=float)
    last = low - min_gap
    for idx in order:
        out[idx] = max(values[idx], last + min_gap)
        last = out[idx]
    if len(out) and out.max() > high:
        shift = out.max() - high
        out -= shift
        for idx in order:
            if out[idx] < low:
                out[idx] = low
    return out.tolist()


def plot_raw_panel(ax, raw_rows: list[dict]) -> None:
    x0, x1 = 0.0, 1.0
    values_right = [1.0 - row["ours_auc"] for row in raw_rows]
    label_y = spread_positions(values_right, min_gap=0.035, low=0.05, high=0.78)
    for row in raw_rows:
        color = RAW_COLORS[row["model"]]
        ax.plot([x0, x1], [1.0 - row["raw_auc"], 1.0 - row["ours_auc"]], color=color, lw=2.8, alpha=0.95)
        ax.scatter([x0, x1], [1.0 - row["raw_auc"], 1.0 - row["ours_auc"]], color=color, s=58, zorder=3)
    for i, row in enumerate(raw_rows):
        color = RAW_COLORS[row["model"]]
        ax.text(
            x1 + 0.10,
            label_y[i],
            f"{RAW_SHORT[row['model']]}  {1.0 - row['ours_auc']:.2f}",
            fontsize=11,
            color=color,
            va="center",
            fontweight="bold",
        )
    ax.set_xlim(-0.10, 1.75)
    ax.set_ylim(0.0, 0.82)
    ax.set_xticks([x0, x1], ["Raw", "Ours"], fontweight="bold")
    ax.set_ylabel("Wrong pair rate", fontsize=12, fontweight="bold")
    style_axis(ax)


def plot_inheritance_panel(ax, inh_rows: list[dict]) -> None:
    del inh_rows
    raise RuntimeError("plot_inheritance_panel is no longer used")


def plot_host_vs_raw_panel(ax, raw_rows: list[dict], host_rows: list[dict]) -> None:
    raw_mis = [1.0 - r["raw_auc"] for r in raw_rows]
    host_mis = [1.0 - r["baseline_auc"] for r in host_rows]
    raw_min = min(raw_mis)
    raw_max = max(raw_mis)
    raw_mean = float(np.mean(raw_mis))
    x = np.arange(len(host_rows))
    colors = [HOST_COLORS[r["host"]] for r in host_rows]

    ax.axhspan(raw_min, raw_max, color="#D9D9D9", alpha=0.45, zorder=0)
    ax.axhline(raw_mean, color="#8A8A8A", linestyle="--", linewidth=1.4, zorder=1)
    ax.bar(x, host_mis, color=colors, width=0.66, zorder=2)

    for i, (row, val) in enumerate(zip(host_rows, host_mis)):
        ax.text(i, val + 0.03, f"{val:.2f}", ha="center", va="bottom", fontsize=11, color=colors[i], fontweight="bold")

    ax.text(
        0.02,
        0.03,
        "raw range",
        transform=ax.transAxes,
        va="bottom",
        fontsize=10,
        color="#6F6F6F",
        fontweight="bold",
    )
    ax.set_xticks(x, [HOST_SHORT[r["host"]] for r in host_rows], fontweight="bold")
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Wrong pair rate", fontsize=12, fontweight="bold")
    style_axis(ax)


def plot_host_baseline_panel(ax, host_rows: list[dict]) -> None:
    x = np.arange(len(host_rows))
    values = [-r["baseline_p50_gap"] for r in host_rows]
    colors = [HOST_COLORS[r["host"]] for r in host_rows]
    ax.bar(x, values, color=colors, width=0.66)
    for i, (row, val) in enumerate(zip(host_rows, values)):
        ax.text(i, val + 0.01, f"{val:.2f}", ha="center", va="bottom", fontsize=11, color=colors[i], fontweight="bold")
    ax.axhline(0.0, color="#666666", linestyle="--", linewidth=1.0, alpha=0.8)
    ax.set_xticks(x, [HOST_SHORT[r["host"]] for r in host_rows], fontweight="bold")
    ax.set_ylim(0.0, 0.18)
    ax.set_ylabel("Hard normal - defect\n(median)", fontsize=12, fontweight="bold")
    style_axis(ax)


def plot_host_correction_panel(ax, host_rows: list[dict]) -> None:
    x0, x1 = 0.0, 1.0
    values_left = [1.0 - row["baseline_auc"] for row in host_rows]
    values_right = [1.0 - row["matched_auc"] for row in host_rows]
    label_y = spread_positions(values_right, min_gap=0.045, low=0.02, high=0.88)
    for row in host_rows:
        color = HOST_COLORS[row["host"]]
        ax.plot([x0, x1], [1.0 - row["baseline_auc"], 1.0 - row["matched_auc"]], color=color, lw=2.8)
        ax.scatter([x0, x1], [1.0 - row["baseline_auc"], 1.0 - row["matched_auc"]], color=color, s=60, zorder=3)
    for i, row in enumerate(host_rows):
        color = HOST_COLORS[row["host"]]
        ax.text(
            x1 + 0.10,
            label_y[i],
            f"{HOST_SHORT[row['host']]}  {1.0 - row['matched_auc']:.2f}",
            fontsize=11,
            color=color,
            va="center",
            fontweight="bold",
        )
    ax.text(0.03, 0.97, "With support", transform=ax.transAxes, va="top", fontsize=12, fontweight="bold")
    ax.set_xlim(-0.10, 1.72)
    ax.set_ylim(0.0, 1.02)
    ax.set_xticks([x0, x1], ["Base", "Ours"], fontweight="bold")
    ax.set_ylabel("Wrong pair rate", fontsize=12, fontweight="bold")
    style_axis(ax)


def main() -> None:
    raw_rows = load_raw_rows()
    host_rows = load_host_rows()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.size": 11,
            "font.weight": "bold",
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
        }
    )
    fig, axes = plt.subplots(1, 4, figsize=(22.0, 4.8), constrained_layout=True)

    plot_raw_panel(axes[0], raw_rows)
    plot_host_vs_raw_panel(axes[1], raw_rows, host_rows)
    plot_host_baseline_panel(axes[2], host_rows)
    plot_host_correction_panel(axes[3], host_rows)

    out = {
        "raw_rows": raw_rows,
        "host_rows": host_rows,
    }

    png_path = OUT_DIR / "entanglement_story_4subplot.png"
    pdf_path = OUT_DIR / "entanglement_story_4subplot.pdf"
    json_path = OUT_DIR / "entanglement_story_4subplot.json"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    json_path.write_text(json.dumps(out, indent=2))
    print(png_path)
    print(pdf_path)
    print(json_path)


if __name__ == "__main__":
    main()
