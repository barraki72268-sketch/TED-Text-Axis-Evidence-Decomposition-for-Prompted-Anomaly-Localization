#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"

MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT="/mnt/data/gijeong/MMAD_new/VisA"

PRETRAINED_MODEL="ViT-L/14@336px"
FEATURES=(6 12 18 24)
IMAGE_SIZE=518
BATCH_SIZE=8
EPOCHS=15
N_CTX=12
VL_REDUCTION=4
PQ_MID_DIM=128
SEED=10
IR_ORTHO_WEIGHT=0.1
GPU_ID="${1:-1}"

BASE_DIR="adaptclip_ir_vitl336_mvtec2visa_seed${SEED}"
CKPT_DIR="${ROOT}/neurips2026/results/${BASE_DIR}/checkpoints"
TEST_DIR="${ROOT}/neurips2026/results/${BASE_DIR}/test_visa_0shot"

mkdir -p "${CKPT_DIR}" "${TEST_DIR}"

cd "${ROOT}/neurips2026/AdaptCLIP"

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" train.py \
  --dataset mvtec \
  --train_data_path "${MVTEC_ROOT}" \
  --save_path "${CKPT_DIR}" \
  --pretrained_model "${PRETRAINED_MODEL}" \
  --features_list "${FEATURES[@]}" \
  --image_size "${IMAGE_SIZE}" \
  --batch_size "${BATCH_SIZE}" \
  --print_freq 1 \
  --epoch "${EPOCHS}" \
  --save_freq 1 \
  --seed "${SEED}" \
  --n_ctx "${N_CTX}" \
  --vl_reduction "${VL_REDUCTION}" \
  --pq_mid_dim "${PQ_MID_DIM}" \
  --ir_ortho_weight "${IR_ORTHO_WEIGHT}" \
  --visual_learner \
  --ir_textual_learner \
  --pq_learner \
  --pq_context

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" test.py \
  --dataset visa \
  --test_data_path "${VISA_ROOT}" \
  --checkpoint_path "${CKPT_DIR}/epoch_${EPOCHS}.pth" \
  --save_path "${TEST_DIR}" \
  --pretrained_model "${PRETRAINED_MODEL}" \
  --features_list "${FEATURES[@]}" \
  --image_size "${IMAGE_SIZE}" \
  --batch_size "${BATCH_SIZE}" \
  --seed "${SEED}" \
  --k_shots 0 \
  --n_ctx "${N_CTX}" \
  --vl_reduction "${VL_REDUCTION}" \
  --pq_mid_dim "${PQ_MID_DIM}" \
  --visual_learner \
  --ir_textual_learner \
  --pq_learner \
  --pq_context
