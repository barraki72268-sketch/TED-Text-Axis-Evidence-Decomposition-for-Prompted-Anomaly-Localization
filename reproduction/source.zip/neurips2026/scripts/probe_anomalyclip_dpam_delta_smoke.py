from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import build_dataset  # noqa: E402
from probe_anomalyclip_text_decomposition_score import (  # noqa: E402
    calculate_fast_aupro,
    farthest_point_subsample_indices,
    patch_text_score,
    precompute_aupro_regions,
)


def parse_ints(raw: str | None, default: list[int]) -> list[int]:
    if not raw:
        return list(default)
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


def resize_map(arr: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    return (
        F.interpolate(
            torch.from_numpy(arr).unsqueeze(0).unsqueeze(0).float(),
            size=size,
            mode="bilinear",
            align_corners=False,
        )[0, 0]
        .cpu()
        .numpy()
    )


def normalize_tokens(tokens: torch.Tensor) -> torch.Tensor:
    return F.normalize(tokens[:, 1:, :].reshape(-1, tokens.shape[-1]).float(), dim=-1)


def dpam_and_original_patches(
    model,
    image: torch.Tensor,
    features_list: list[int],
    ffn: bool = False,
) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
    """Return projected layer tokens from DPAM and its original-attention branch.

    AnomalyCLIP's public visual forward only returns the DPAM layer tokens when
    DPAM is enabled.  For this probe we need the paired original-attention tokens
    from the same forward trajectory, so we mirror the official visual forward
    and record both branches at the requested layers.
    """
    visual = model.visual
    x = image.type(model.dtype)
    x = visual.conv1(x)
    x = x.reshape(x.shape[0], x.shape[1], -1)
    x = x.permute(0, 2, 1)
    x = torch.cat(
        [
            visual.class_embedding.to(x.dtype)
            + torch.zeros(x.shape[0], 1, x.shape[-1], dtype=x.dtype, device=x.device),
            x,
        ],
        dim=1,
    )

    side = int((visual.positional_embedding.shape[0] - 1) ** 0.5)
    new_side = int((x.shape[1] - 1) ** 0.5)
    if side != new_side:
        new_pos = visual.positional_embedding[1:, :].reshape(-1, side, side, x.shape[-1]).permute(0, 3, 1, 2)
        new_pos = torch.nn.functional.interpolate(new_pos, (new_side, new_side), mode="bilinear")
        new_pos = new_pos.reshape(-1, x.shape[-1], new_side * new_side).transpose(1, 2)
        visual.positional_embedding.data = torch.cat([visual.positional_embedding[:1, :], new_pos[0]], 0)

    x = x + visual.positional_embedding.to(x.dtype)
    x = visual.ln_pre(x)
    x = x.permute(1, 0, 2)

    dpam_tokens = []
    ori_tokens = []
    wanted = set(features_list)
    for layer_idx, block in enumerate(visual.transformer.resblocks, start=1):
        x = block(x, ffn=ffn)
        if layer_idx in wanted:
            if isinstance(x, list):
                dpam_tokens.append(x[0].clone())
                ori_tokens.append(x[1].clone())
            else:
                dpam_tokens.append(x.clone())
                ori_tokens.append(x.clone())

    def project(tokens: torch.Tensor) -> torch.Tensor:
        return visual.ln_post(tokens.permute(1, 0, 2)) @ visual.proj

    return [project(t) for t in dpam_tokens], [project(t) for t in ori_tokens]


def dpam_delta_tokens(
    model,
    image: torch.Tensor,
    features_list: list[int],
    dpam_layer: int,
) -> tuple[list[torch.Tensor], list[torch.Tensor], list[torch.Tensor]]:
    # ``dpam_layer`` is kept as an argument so the CLI explicitly records the
    # official DPAM setting.  The model has already had DPAM attention modules
    # installed by ``build_model``; we record both branches from that path.
    del dpam_layer
    dpam_patches, ori_patches = dpam_and_original_patches(model, image, features_list)
    dpam_tokens = [normalize_tokens(p) for p in dpam_patches]
    ori_tokens = [normalize_tokens(p) for p in ori_patches]
    delta_tokens = [F.normalize(d - o, dim=-1) for d, o in zip(dpam_tokens, ori_tokens)]
    return dpam_patches, delta_tokens, ori_tokens


def host_patch_maps(
    patch_features: list[torch.Tensor],
    text_pair: torch.Tensor,
    mode: str,
) -> list[np.ndarray]:
    maps = []
    for patch_feature in patch_features:
        scores = patch_text_score(patch_feature, text_pair, mode=mode)
        h = int(round(scores.numel() ** 0.5))
        maps.append(scores.reshape(h, h).detach().cpu().numpy())
    return maps


def collect_delta_banks(
    model,
    text_pair: torch.Tensor,
    source_root: str,
    source_dataset: str,
    image_size: int,
    features_list: list[int],
    active_layer_indices: list[int],
    dpam_layer: int,
    host_patch_score_mode: str,
    hard_frac: float,
    max_good_per_class: int,
    max_defect_per_class: int,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    device: str,
) -> tuple[dict[int, torch.Tensor], dict[int, torch.Tensor], dict[int, dict]]:
    train_ds = build_dataset(source_root, source_dataset, image_size, mode="train")
    test_ds = build_dataset(source_root, source_dataset, image_size, mode="test")
    fp_chunks = {idx: [] for idx in active_layer_indices}
    def_chunks = {idx: [] for idx in active_layer_indices}
    fp_score_chunks = {idx: [] for idx in active_layer_indices}
    def_score_chunks = {idx: [] for idx in active_layer_indices}
    good_seen = {cls_name: 0 for cls_name in train_ds.obj_list}
    defect_seen = {cls_name: 0 for cls_name in test_ds.obj_list}

    with torch.no_grad():
        for idx in range(len(train_ds)):
            if all(v >= max_good_per_class for v in good_seen.values()):
                break
            item = train_ds[idx]
            cls_name = item["cls_name"]
            if good_seen[cls_name] >= max_good_per_class:
                continue
            good_seen[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            dpam_patches, delta_tokens, _ = dpam_delta_tokens(model, image, features_list, dpam_layer)
            for layer_idx in active_layer_indices:
                scores = patch_text_score(dpam_patches[layer_idx], text_pair, mode=host_patch_score_mode)
                k = max(1, int(scores.numel() * hard_frac))
                top_idx = torch.topk(scores, k=k, largest=True).indices
                selected = delta_tokens[layer_idx][top_idx]
                selected_scores = scores[top_idx]
                if selected.shape[0] > max_fp_per_image:
                    keep = farthest_point_subsample_indices(selected.detach().cpu(), max_fp_per_image).to(selected.device)
                    selected = selected[keep]
                    selected_scores = selected_scores[keep]
                fp_chunks[layer_idx].append(selected.cpu())
                fp_score_chunks[layer_idx].append(selected_scores.detach().cpu())

        for idx in range(len(test_ds)):
            if all(v >= max_defect_per_class for v in defect_seen.values()):
                break
            item = test_ds[idx]
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0:
                continue
            cls_name = item["cls_name"]
            if defect_seen[cls_name] >= max_defect_per_class:
                continue
            defect_seen[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"].unsqueeze(0).to(device).float()
            dpam_patches, delta_tokens, _ = dpam_delta_tokens(model, image, features_list, dpam_layer)
            for layer_idx in active_layer_indices:
                scores = patch_text_score(dpam_patches[layer_idx], text_pair, mode=host_patch_score_mode)
                h = int(round(scores.numel() ** 0.5))
                gt_small = F.interpolate(gt_mask, size=(h, h), mode="nearest")[0, 0].reshape(-1) > 0.5
                if int(gt_small.sum().item()) == 0:
                    continue
                selected = delta_tokens[layer_idx][gt_small]
                selected_scores = scores[gt_small]
                if selected.shape[0] > max_defect_per_image:
                    keep = farthest_point_subsample_indices(selected.detach().cpu(), max_defect_per_image).to(selected.device)
                    selected = selected[keep]
                    selected_scores = selected_scores[keep]
                def_chunks[layer_idx].append(selected.cpu())
                def_score_chunks[layer_idx].append(selected_scores.detach().cpu())

    fp_banks: dict[int, torch.Tensor] = {}
    def_banks: dict[int, torch.Tensor] = {}
    stats: dict[int, dict] = {}
    for layer_idx in active_layer_indices:
        fp = torch.cat(fp_chunks[layer_idx], dim=0) if fp_chunks[layer_idx] else torch.empty((0, 768))
        defect = torch.cat(def_chunks[layer_idx], dim=0) if def_chunks[layer_idx] else torch.empty((0, 768))
        fp_scores = torch.cat(fp_score_chunks[layer_idx], dim=0) if fp_score_chunks[layer_idx] else torch.empty((0,))
        def_scores = torch.cat(def_score_chunks[layer_idx], dim=0) if def_score_chunks[layer_idx] else torch.empty((0,))
        if fp.shape[0] > max_bank_per_layer:
            keep = farthest_point_subsample_indices(fp, max_bank_per_layer)
            fp = fp[keep]
            fp_scores = fp_scores[keep]
        if defect.shape[0] > max_bank_per_layer:
            keep = farthest_point_subsample_indices(defect, max_bank_per_layer)
            defect = defect[keep]
            def_scores = def_scores[keep]
        fp_banks[layer_idx] = F.normalize(fp.float(), dim=-1)
        def_banks[layer_idx] = F.normalize(defect.float(), dim=-1)
        stats[layer_idx] = {
            "num_fp": int(fp.shape[0]),
            "num_defect": int(defect.shape[0]),
            "fp_host_score_mean": float(fp_scores.mean().item()) if fp_scores.numel() else float("nan"),
            "defect_host_score_mean": float(def_scores.mean().item()) if def_scores.numel() else float("nan"),
        }
    return fp_banks, def_banks, stats


def fit_pca_basis(fp: torch.Tensor, defect: torch.Tensor, rank: int, device: str) -> tuple[torch.Tensor, torch.Tensor]:
    x = torch.cat([fp, defect], dim=0).float().to(device)
    mean = x.mean(dim=0, keepdim=True)
    xc = x - mean
    try:
        _, _, vh = torch.linalg.svd(xc, full_matrices=False)
        basis = vh[: max(1, min(rank, vh.shape[0]))].t().contiguous()
    except RuntimeError:
        basis = torch.eye(x.shape[1], device=device)[:, : max(1, rank)]
    return mean.to(device), basis


def support_score(query: torch.Tensor, bank: torch.Tensor, tau: float, chunk: int = 4096) -> torch.Tensor:
    vals = []
    bank = bank.float()
    for q in query.float().split(chunk, dim=0):
        dist2 = torch.cdist(q, bank).pow(2)
        vals.append(torch.logsumexp(-dist2 / float(tau), dim=1) - np.log(max(int(bank.shape[0]), 1)))
    return torch.cat(vals, dim=0)


def compute_metrics(labels: np.ndarray, masks: np.ndarray, maps: np.ndarray, image_scores: np.ndarray, aupro_max_step: int) -> dict:
    flat_gt = masks.reshape(-1).astype(np.uint8)
    flat_pr = maps.reshape(-1).astype(np.float32)
    pre = precompute_aupro_regions(masks)
    return {
        "image_auroc": float(roc_auc_score(labels, image_scores)) if len(np.unique(labels)) > 1 else float("nan"),
        "pixel_auroc": float(roc_auc_score(flat_gt, flat_pr)) if len(np.unique(flat_gt)) > 1 else float("nan"),
        "pixel_aupro": float(calculate_fast_aupro(masks, maps, max_step=aupro_max_step, precomputed=pre)),
        "pixel_ap": float(average_precision_score(flat_gt, flat_pr)) if len(np.unique(flat_gt)) > 1 else float("nan"),
    }


def main() -> int:
    parser = argparse.ArgumentParser("DPAM-aware AnomalyCLIP TED smoke")
    parser.add_argument("--source_root", required=True)
    parser.add_argument("--source_dataset", required=True)
    parser.add_argument("--target_root", required=True)
    parser.add_argument("--target_dataset", required=True)
    parser.add_argument("--checkpoint_path", required=True)
    parser.add_argument("--save_dir", required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--model_name_or_path", default="ViT-L/14@336px")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--dpam_layer", type=int, default=20)
    parser.add_argument("--features_list", default="6,12,18,24")
    parser.add_argument("--baseline_features_list", default="6,12,18,24")
    parser.add_argument("--active_layer_indices", default="3")
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--host_patch_score_mode", default="prob", choices=["prob", "logit_margin", "neg_logit_margin", "cos_margin", "neg_cos_margin"])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=1)
    parser.add_argument("--max_defect_per_class", type=int, default=2)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--rank", type=int, default=8)
    parser.add_argument("--tau", type=float, default=0.5)
    parser.add_argument("--gate_quantile", type=float, default=0.75)
    parser.add_argument("--gate_temp", type=float, default=0.25)
    parser.add_argument("--eta_values", default="0,0.02,0.05,0.1,0.2,0.5")
    parser.add_argument("--max_normal_eval_images", type=int, default=20)
    parser.add_argument("--max_anomaly_eval_images", type=int, default=20)
    parser.add_argument("--aupro_max_step", type=int, default=50)
    parser.add_argument("--sigma", type=float, default=4.0)
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    features_list = parse_ints(args.features_list, [6, 12, 18, 24])
    baseline_features_list = parse_ints(args.baseline_features_list, features_list)
    active_layer_indices = parse_ints(args.active_layer_indices, [len(features_list) - 1])
    eta_values = [float(x.strip()) for x in args.eta_values.split(",") if x.strip()]

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx, args.model_name_or_path, args.dpam_layer)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    text_pair = get_learned_text_pair(model, learner).to(args.device)

    fp_banks, def_banks, bank_stats = collect_delta_banks(
        model=model,
        text_pair=text_pair,
        source_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=features_list,
        active_layer_indices=active_layer_indices,
        dpam_layer=args.dpam_layer,
        host_patch_score_mode=args.host_patch_score_mode,
        hard_frac=args.hard_frac,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        device=args.device,
    )
    pca = {}
    for layer_idx in active_layer_indices:
        mean, basis = fit_pca_basis(fp_banks[layer_idx], def_banks[layer_idx], args.rank, args.device)
        pca[layer_idx] = {
            "mean": mean,
            "basis": basis,
            "fp_z": (fp_banks[layer_idx].to(args.device) - mean) @ basis,
            "def_z": (def_banks[layer_idx].to(args.device) - mean) @ basis,
        }

    target_ds = build_dataset(args.target_root, args.target_dataset, args.image_size, mode="test")
    obj_list = list(target_ds.obj_list)
    results = {eta: {obj: {"labels": [], "image_scores": [], "masks": [], "maps": []} for obj in obj_list} for eta in eta_values}
    counts = {obj: {"normal": 0, "anomaly": 0} for obj in obj_list}
    with torch.no_grad():
        for idx in range(len(target_ds)):
            item = target_ds[idx]
            obj = item["cls_name"]
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            key = "anomaly" if anomaly_flag else "normal"
            limit = args.max_anomaly_eval_images if anomaly_flag else args.max_normal_eval_images
            if limit is not None and counts[obj][key] >= limit:
                continue
            counts[obj][key] += 1

            image = item["img"].unsqueeze(0).to(args.device)
            gt = item["img_mask"].unsqueeze(0).float()
            gt[gt > 0.5], gt[gt <= 0.5] = 1, 0
            target_size = tuple(gt.shape[-2:])
            image_features, dpam_patches = model.encode_image(image, baseline_features_list, DPAM_layer=args.dpam_layer)
            image_features = F.normalize(image_features.float(), dim=-1)
            image_score = float(((image_features @ text_pair.t()) / 0.07).softmax(dim=-1)[0, 1].item())
            base_maps = host_patch_maps(dpam_patches, text_pair, args.host_patch_score_mode)
            base_map = resize_map(np.mean(np.stack(base_maps, axis=0), axis=0), target_size)
            base_map = gaussian_filter(base_map, sigma=args.sigma)

            dpam_patches_full, delta_tokens, _ = dpam_delta_tokens(model, image, features_list, args.dpam_layer)
            penalty_maps = []
            for layer_idx in active_layer_indices:
                z = (delta_tokens[layer_idx].to(args.device) - pca[layer_idx]["mean"]) @ pca[layer_idx]["basis"]
                q_fp = support_score(z, pca[layer_idx]["fp_z"], tau=args.tau)
                q_def = support_score(z, pca[layer_idx]["def_z"], tau=args.tau)
                penalty = F.relu(q_fp - q_def)
                h = int(round(penalty.numel() ** 0.5))
                penalty_map = penalty.reshape(h, h).detach().cpu().numpy()
                penalty_maps.append(resize_map(penalty_map, target_size))
            penalty_map = np.mean(np.stack(penalty_maps, axis=0), axis=0)
            penalty_map = gaussian_filter(penalty_map, sigma=args.sigma)
            penalty_z = (penalty_map - float(penalty_map.mean())) / (float(penalty_map.std()) + 1e-6)
            penalty_z = np.maximum(penalty_z, 0.0)
            base_z = (base_map - float(base_map.mean())) / (float(base_map.std()) + 1e-6)
            gate_th = float(np.quantile(base_z, args.gate_quantile))
            gate = 1.0 / (1.0 + np.exp(-(base_z - gate_th) / max(float(args.gate_temp), 1e-6)))
            scale = float(base_map.std()) + 1e-6

            for eta in eta_values:
                out_map = base_map if eta == 0 else base_map - float(eta) * scale * gate * penalty_z
                results[eta][obj]["labels"].append(anomaly_flag)
                results[eta][obj]["image_scores"].append(image_score)
                results[eta][obj]["masks"].append(gt[0, 0].numpy())
                results[eta][obj]["maps"].append(out_map.astype(np.float32, copy=False))

            if sum(c["normal"] + c["anomaly"] for c in counts.values()) % 40 == 0:
                print({"stage": "eval_progress", "images_done": sum(c["normal"] + c["anomaly"] for c in counts.values())}, flush=True)

    rows = []
    for eta in eta_values:
        metric_rows = []
        for obj in obj_list:
            if not results[eta][obj]["labels"]:
                continue
            labels = np.asarray(results[eta][obj]["labels"], dtype=np.int64)
            masks = np.asarray(results[eta][obj]["masks"], dtype=np.float32)
            maps = np.asarray(results[eta][obj]["maps"], dtype=np.float32)
            image_scores = np.asarray(results[eta][obj]["image_scores"], dtype=np.float32)
            row = {"eta": eta, "target_label": obj}
            row.update(compute_metrics(labels, masks, maps, image_scores, args.aupro_max_step))
            rows.append(row)
            metric_rows.append(row)
        if metric_rows:
            rows.append(
                {
                    "eta": eta,
                    "target_label": "mean",
                    "image_auroc": float(np.nanmean([r["image_auroc"] for r in metric_rows])),
                    "pixel_auroc": float(np.nanmean([r["pixel_auroc"] for r in metric_rows])),
                    "pixel_aupro": float(np.nanmean([r["pixel_aupro"] for r in metric_rows])),
                    "pixel_ap": float(np.nanmean([r["pixel_ap"] for r in metric_rows])),
                }
            )

    summary = {
        "source_root": args.source_root,
        "source_dataset": args.source_dataset,
        "target_root": args.target_root,
        "target_dataset": args.target_dataset,
        "checkpoint_path": args.checkpoint_path,
        "features_list": features_list,
        "baseline_features_list": baseline_features_list,
        "active_layer_indices": active_layer_indices,
        "active_feature_layers": [features_list[i] for i in active_layer_indices],
        "mode": "dpam_delta_hardfp_penalty",
        "eta_values": eta_values,
        "rank": args.rank,
        "tau": args.tau,
        "gate_quantile": args.gate_quantile,
        "gate_temp": args.gate_temp,
        "counts": counts,
        "bank_stats": {str(k): v for k, v in bank_stats.items()},
    }
    with (save_dir / "summary.json").open("w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    with (save_dir / "metrics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
