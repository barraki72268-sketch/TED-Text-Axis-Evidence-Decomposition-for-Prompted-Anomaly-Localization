from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.train_clip_aqm_oracle import (
    AnomalyQueryModuleV1,
    compute_aqm_loss,
    entropy_beta,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    forward_up_to_layer,
    patchify_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.scripts.train_clip_ksm_v3_mvtec_to_visa import (
    PromptCondition,
    build_prompt_condition,
    collect_mvtec_train_records,
    collect_visa_eval_records,
    materialize_record_batch,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("AQM mixed-source MVTec -> VisA prompt-centric transfer pilot.")
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument(
        "--target_classes",
        nargs="+",
        default=[
            "chewinggum",
            "pipe_fryum",
            "pcb4",
            "macaroni2",
            "cashew",
            "pcb1",
            "macaroni1",
            "fryum",
            "pcb2",
            "capsules",
            "candle",
            "pcb3",
        ],
    )
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--layer", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_simplex_tokens", type=int, default=32)
    parser.add_argument("--num_subspace_tokens", type=int, default=32)
    parser.add_argument("--gamma_init", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=8)
    parser.add_argument("--train_anomaly_images", type=int, default=8)
    parser.add_argument("--train_batch_size", type=int, default=64)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--entropy_beta_max", type=float, default=0.05)
    parser.add_argument("--entropy_hold_epochs", type=int, default=2)
    parser.add_argument("--entropy_decay_epochs", type=int, default=3)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_aqm_mvtec2visa")
    return parser.parse_args()


def train_one_epoch(
    backbone,
    aqm: AnomalyQueryModuleV1,
    prompt_cache: dict[str, PromptCondition],
    train_records,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    aqm.train()
    beta = entropy_beta(epoch_idx, args.entropy_beta_max, args.entropy_hold_epochs, args.entropy_decay_epochs)
    loss_vals = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []
    l_s_vals = []
    l_u_vals = []
    l_router_vals = []
    l_zero_s_vals = []
    l_zero_u_vals = []

    records_by_class: dict[str, list] = {}
    for rec in train_records:
        records_by_class.setdefault(rec.class_name, []).append(rec)
    rng = np.random.default_rng(epoch_idx)
    class_order = list(records_by_class.keys())
    rng.shuffle(class_order)

    for class_name in class_order:
        cond = prompt_cache[class_name]
        class_records = records_by_class[class_name]
        order = rng.permutation(len(class_records))
        for start in range(0, len(order), args.train_batch_size):
            batch_idx = order[start : start + args.train_batch_size]
            batch_records = [class_records[int(i)] for i in batch_idx]
            image_t_cpu, patch_mask = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            mask = torch.from_numpy(patch_mask.astype(np.int64)).to(device)
            seq = forward_up_to_layer(backbone, image_t, args.layer)
            _, patches = patchify_sequence(seq)
            _, aux = aqm(patches, cond.p_norm, return_aux=True)
            loss, parts = compute_aqm_loss(
                aux,
                cond.prompt_features,
                mask,
                hard_neg_ratio=args.hard_neg_ratio,
                topk_anom_ratio=args.topk_anom_ratio,
            )
            loss = parts["l_s"] + parts["l_u"] + parts["l_router"] + float(args.lambda_zero) * (
                parts["l_zero_s"] + parts["l_zero_u"]
            )
            alpha_c = aux["alpha_tensor"].clamp(1e-6, 1.0 - 1e-6)
            l_entropy = (alpha_c * torch.log(alpha_c) + (1.0 - alpha_c) * torch.log(1.0 - alpha_c)).mean()
            loss = loss + beta * l_entropy

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()

            loss_vals.append(float(loss.item()))
            alpha_vals.append(aux["alpha_mean"])
            gamma_s_vals.append(aux["gamma_simplex_abs"])
            gamma_u_vals.append(aux["gamma_subspace_abs"])
            l_s_vals.append(float(parts["l_s"].item()))
            l_u_vals.append(float(parts["l_u"].item()))
            l_router_vals.append(float(parts["l_router"].item()))
            l_zero_s_vals.append(float(parts["l_zero_s"].item()))
            l_zero_u_vals.append(float(parts["l_zero_u"].item()))

    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "train_loss_s": float(np.mean(l_s_vals)) if l_s_vals else float("nan"),
        "train_loss_u": float(np.mean(l_u_vals)) if l_u_vals else float("nan"),
        "train_loss_router": float(np.mean(l_router_vals)) if l_router_vals else float("nan"),
        "train_loss_zero_s": float(np.mean(l_zero_s_vals)) if l_zero_s_vals else float("nan"),
        "train_loss_zero_u": float(np.mean(l_zero_u_vals)) if l_zero_u_vals else float("nan"),
        "alpha_mean": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
        "entropy_beta": float(beta),
    }


def evaluate_target_class(
    backbone,
    aqm: AnomalyQueryModuleV1,
    cond: PromptCondition,
    eval_records,
    layer_idx: int,
    topk_ratio: float,
    eval_batch_size: int,
    device: str,
) -> dict[str, float]:
    aqm.eval()
    patch_labels = []
    base_patch_scores = []
    mix_patch_scores = []
    simplex_patch_scores = []
    subspace_patch_scores = []
    image_labels = []
    base_image_scores = []
    mix_image_scores = []
    simplex_image_scores = []
    subspace_image_scores = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []

    with torch.no_grad():
        for start in range(0, len(eval_records), eval_batch_size):
            batch_records = eval_records[start : start + eval_batch_size]
            image_t_cpu, patch_masks = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            _, patches = patchify_sequence(seq)
            _, aux = aqm(patches, cond.p_norm, return_aux=True)

            base_scores = score_promptmax(patches, cond.p_norm, cond.prompt_features)
            mix_scores = score_promptmax(aux["mixed_feat"], cond.p_norm, cond.prompt_features)
            simplex_scores = score_promptmax(aux["simplex_feat"], cond.p_norm, cond.prompt_features)
            subspace_scores = score_promptmax(aux["subspace_feat"], cond.p_norm, cond.prompt_features)

            for rec, patch_mask, bs, ms, ss, us in zip(
                batch_records,
                patch_masks,
                base_scores,
                mix_scores,
                simplex_scores,
                subspace_scores,
            ):
                patch_labels.extend(patch_mask.astype(np.int64).tolist())
                base_patch_scores.extend(bs.tolist())
                mix_patch_scores.extend(ms.tolist())
                simplex_patch_scores.extend(ss.tolist())
                subspace_patch_scores.extend(us.tolist())
                image_labels.append(rec.label)
                base_image_scores.append(topk_mean(np.asarray(bs), topk_ratio))
                mix_image_scores.append(topk_mean(np.asarray(ms), topk_ratio))
                simplex_image_scores.append(topk_mean(np.asarray(ss), topk_ratio))
                subspace_image_scores.append(topk_mean(np.asarray(us), topk_ratio))

            alpha_vals.extend(aux["alpha_tensor"].view(-1).detach().cpu().tolist())
            gamma_s_vals.extend([aux["gamma_simplex_abs"]] * len(batch_records))
            gamma_u_vals.extend([aux["gamma_subspace_abs"]] * len(batch_records))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    mix_patch_auc = safe_auc(patch_labels, mix_patch_scores)
    simplex_patch_auc = safe_auc(patch_labels, simplex_patch_scores)
    subspace_patch_auc = safe_auc(patch_labels, subspace_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    mix_image_auc = safe_auc(image_labels, mix_image_scores)
    simplex_image_auc = safe_auc(image_labels, simplex_image_scores)
    subspace_image_auc = safe_auc(image_labels, subspace_image_scores)
    return {
        "base_prompt_patch_auc": base_patch_auc,
        "aqm_prompt_patch_auc": mix_patch_auc,
        "prompt_patch_auc_delta": mix_patch_auc - base_patch_auc,
        "simplex_prompt_patch_auc_delta": simplex_patch_auc - base_patch_auc,
        "subspace_prompt_patch_auc_delta": subspace_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "aqm_prompt_image_auc": mix_image_auc,
        "prompt_image_auc_delta": mix_image_auc - base_image_auc,
        "simplex_prompt_image_auc_delta": simplex_image_auc - base_image_auc,
        "subspace_prompt_image_auc_delta": subspace_image_auc - base_image_auc,
        "alpha_mean_eval": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean_eval": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean_eval": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for p in backbone.parameters():
        p.requires_grad_(False)

    train_records = collect_mvtec_train_records(backbone, args)
    source_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.source_classes
    }
    target_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.target_classes
    }

    aqm = AnomalyQueryModuleV1(
        dim=int(next(iter(source_prompt_cache.values())).prompt_features.shape[1]),
        num_simplex_tokens=args.num_simplex_tokens,
        num_subspace_tokens=args.num_subspace_tokens,
        gamma_init=args.gamma_init,
    ).to(device)
    token_params = [aqm.simplex_tokens, aqm.subspace_tokens]
    other_params = [p for n, p in aqm.named_parameters() if n not in {"simplex_tokens", "subspace_tokens"}]
    optimizer = torch.optim.AdamW(
        [
            {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
            {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
        ]
    )

    print(
        f"[setup] source_dataset=mvtec source_classes={len(args.source_classes)} "
        f"source_records={len(train_records)} target_classes={len(args.target_classes)} layer=L{args.layer}"
    )

    history = []
    for epoch in range(1, args.epochs + 1):
        stats = train_one_epoch(backbone, aqm, source_prompt_cache, train_records, args, optimizer, device, epoch)
        history.append({"epoch": epoch, **stats})
        print(
            f"[epoch {epoch}/{args.epochs}] loss={stats['train_loss']:.6f} "
            f"alpha={stats['alpha_mean']:.6f} "
            f"gamma_s={stats['gamma_simplex_abs_mean']:.6f} "
            f"gamma_u={stats['gamma_subspace_abs_mean']:.6f} "
            f"beta={stats['entropy_beta']:.6f}"
        )

    rows = []
    for class_name in args.target_classes:
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(
            backbone,
            aqm,
            target_prompt_cache[class_name],
            eval_records,
            args.layer,
            args.topk_ratio,
            args.eval_batch_size,
            device,
        )
        rows.append(
            {
                "class_name": class_name,
                "layer": args.layer,
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "img_size": args.img_size,
                "epochs": args.epochs,
                "gamma_init": args.gamma_init,
                "num_simplex_tokens": args.num_simplex_tokens,
                "num_subspace_tokens": args.num_subspace_tokens,
                "source_dataset": "mvtec",
                "source_classes": len(args.source_classes),
                "source_train_records": len(train_records),
                "text_rank": target_prompt_cache[class_name].text_rank,
                **history[-1],
                **eval_stats,
            }
        )

    stem = f"{args.output_tag}_{args.backbone}_L{args.layer}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump(
            {
                "args": vars(args),
                "history": history,
                "rows": rows,
                "source_classes": args.source_classes,
                "target_classes": args.target_classes,
            },
            f,
            indent=2,
        )
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
