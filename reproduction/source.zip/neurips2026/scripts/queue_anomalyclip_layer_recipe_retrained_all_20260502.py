#!/usr/bin/env python3
"""Queue AnomalyCLIP layer-recipe retraining and B/T/C evaluation.

Each row retrains the AnomalyCLIP prompt learner with a specific feature-layer
recipe on VisA, rebuilds the source evidence bank for that retrained checkpoint,
and evaluates on MVTec. The queue is host-specific so it can run independently
from the AdaCLIP layer-recipe queue.
"""

from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")

OUT = ROOT / "neurips2026/results/anomalyclip_layer_recipe_retrained_corrected_20260503"
LOG = OUT / "logs"
BANK = OUT / "bank_cache"

VISA_1CLS = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")

ANOMALY_ROOT = ROOT / "neurips2026/AnomalyCLIP"
ANOMALY_OFFICIAL_VISA = ANOMALY_ROOT / "checkpoints/9_12_4_multiscale_visa/epoch_15.pth"
ANOMALY_EVAL = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"

FEATURES = {
    "all4": [6, 12, 18, 24],
    "earlylate": [6, 24],
    "mid2": [12, 18],
    "last2": [18, 24],
    "last": [24],
}

DEFAULT_RECIPES = ("all4", "last", "last2", "mid2", "earlylate")


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def parse_recipes(raw: str) -> list[str]:
    recipes = [x.strip() for x in raw.split(",") if x.strip()]
    unknown = [x for x in recipes if x not in FEATURES]
    if unknown:
        raise SystemExit(f"Unknown recipes {unknown}; allowed={sorted(FEATURES)}")
    return recipes


def train_anomalyclip(recipe: str, env: dict[str, str], force_train: bool = False) -> Path:
    features = FEATURES[recipe]
    ckpt_dir = OUT / f"anomalyclip_visa_{recipe}_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if ckpt_path.exists() and not force_train:
        print({"stage": "skip_train", "recipe": recipe, "checkpoint": str(ckpt_path)}, flush=True)
        return ckpt_path

    feature_map_layer = [str(i) for i in range(len(features))]
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "visa",
            "--train_data_path",
            str(VISA_1CLS),
            "--save_path",
            str(ckpt_dir),
            "--features_list",
            *[str(x) for x in features],
            "--feature_map_layer",
            *feature_map_layer,
            "--model_name_or_path",
            "ViT-L/14@336px",
            "--dpam_layer",
            "20",
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ],
        ANOMALY_ROOT,
        LOG / f"anomalyclip_train_visa_{recipe}.log",
        env,
    )
    return ckpt_path


def eval_anomalyclip(
    recipe: str,
    checkpoint: Path,
    save_dir: Path,
    env: dict[str, str],
    force_eval: bool = False,
    force_bank: bool = False,
) -> None:
    summary_path = save_dir / "summary.json"
    if summary_path.exists() and not force_eval:
        print({"stage": "skip_eval", "recipe": recipe, "summary": str(summary_path)}, flush=True)
        return

    features = FEATURES[recipe]
    cmd = [
        str(PY),
        "-u",
        str(ANOMALY_EVAL),
        "--device",
        "cuda:0",
        "--checkpoint_path",
        str(checkpoint),
        "--model_name_or_path",
        "ViT-L/14@336px",
        "--heldout_class",
        "none",
        "--source_root",
        str(VISA_1CLS),
        "--source_dataset",
        "visa",
        "--target_root",
        str(MVTEC),
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--baseline_features_list",
        *[str(x) for x in features],
        "--features_list",
        *[str(x) for x in features],
        "--dpam_layer",
        "20",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--ted_margin_sign",
        "fp_minus_def",
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(BANK / f"anomalyclip_visa_{recipe}_retrained_withscores.pt"),
        "--enable_calibrator",
        "--calib_seed",
        "0",
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.2",
        "--calib_lambda",
        "0.03",
        "--calib_map_anchor",
        "trainfree",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "0.2",
        "--calibrated_image_fusion_weight",
        "0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if force_bank:
        cmd.append("--refresh_bank_cache")
    run(cmd, ROOT, LOG / f"anomalyclip_eval_visa_{recipe}.log", env)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--recipes", default=",".join(DEFAULT_RECIPES))
    parser.add_argument("--force_train", action="store_true")
    parser.add_argument("--force_eval", action="store_true")
    parser.add_argument("--force_bank", action="store_true")
    parser.add_argument("--skip_official", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    BANK.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.device_id)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-anomalyclip-layer-retrained-corrected-20260503")

    recipes = parse_recipes(args.recipes)
    if not args.skip_official and "all4" in recipes:
        eval_anomalyclip(
            "all4",
            ANOMALY_OFFICIAL_VISA,
            OUT / "anomalyclip_visa_all4_official_eval",
            env,
            force_eval=args.force_eval,
            force_bank=args.force_bank,
        )

    for recipe in recipes:
        ckpt = train_anomalyclip(recipe, env, force_train=args.force_train)
        eval_anomalyclip(
            recipe,
            ckpt,
            OUT / f"anomalyclip_visa_{recipe}_eval",
            env,
            force_eval=args.force_eval,
            force_bank=args.force_bank,
        )

    print({"stage": "done", "root": str(OUT), "recipes": recipes}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
