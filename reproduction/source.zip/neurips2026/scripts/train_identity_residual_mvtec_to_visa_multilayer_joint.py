from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.identity_residual_extractor import IdentityResidualExtractor
from neurips2026.scripts.kinematic_text_axis_reconstruction import (
    build_recent_general_prompt_bank,
    encode_text_features,
)
from neurips2026.scripts.train_clip_aqm_oracle import (
    compute_consensus_loss,
    compute_zero_signal_loss,
    normalize_feat,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    forward_up_to_layer,
    patchify_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.scripts.train_clip_ksm_v3_mvtec_to_visa import (
    collect_mvtec_train_records,
    collect_realiad_train_records,
    collect_visa_eval_records,
    materialize_record_batch,
)
from utils.metrics import cal_pro_metric


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Identity-Residual joint multilayer MVTec -> VisA transfer.")
    parser.add_argument("--source_dataset", type=str, default="mvtec", choices=["mvtec", "realiad"])
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--realiad_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument(
        "--target_classes",
        nargs="+",
        default=[
            "chewinggum",
            "pipe_fryum",
            "pcb4",
            "macaroni2",
            "cashew",
            "pcb1",
            "macaroni1",
            "fryum",
            "pcb2",
            "capsules",
            "candle",
            "pcb3",
        ],
    )
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--layers", nargs="+", type=int, default=[3, 6, 9, 12])
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_id_queries", type=int, default=32)
    parser.add_argument("--num_res_queries", type=int, default=32)
    parser.add_argument("--train_normal_images", type=int, default=8)
    parser.add_argument("--train_anomaly_images", type=int, default=8)
    parser.add_argument("--train_batch_size", type=int, default=64)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_id", type=float, default=1.0)
    parser.add_argument("--lambda_res", type=float, default=1.0)
    parser.add_argument("--lambda_ortho", type=float, default=1.0)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--pixel_blur_sigma", type=float, default=4.0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_identity_residual_mvtec2visa_joint4")
    return parser.parse_args()


def build_identity_prompt_bank(class_name: str) -> tuple[list[str], list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    normal_prompts = [
        normal_prompt,
        f"a close-up inspection photo of a flawless {cls} with intact shape and clean surface.",
        f"a close-up inspection photo of a normal {cls} with no visible damage or abnormality.",
        f"a close-up inspection photo of an intact {cls} with complete structure and undamaged appearance.",
    ]
    return normal_prompts, abnormal_prompts


def build_prompt_condition(backbone, class_name: str, device: str) -> dict[str, torch.Tensor]:
    normal_prompts, abnormal_prompts = build_identity_prompt_bank(class_name)
    E_norm = encode_text_features(backbone, backbone.tokenizer, normal_prompts).to(device)
    E_anom = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts).to(device)
    return {"E_norm": E_norm, "E_anom": E_anom}


def compute_identity_support_loss(
    f_id: torch.Tensor,
    raw_patches: torch.Tensor,
    E_norm: torch.Tensor,
) -> torch.Tensor:
    raw_support = torch.matmul(normalize_feat(raw_patches), normalize_feat(E_norm).T).max(dim=-1).values.detach()
    raw_support = raw_support.clamp_min(0.0)
    if float(raw_support.sum().item()) <= 0.0:
        return torch.zeros([], device=f_id.device)
    id_support = torch.matmul(normalize_feat(f_id), normalize_feat(E_norm).T).max(dim=-1).values.clamp_min(0.0)
    return 1.0 - (id_support * raw_support).sum() / raw_support.sum().clamp_min(1e-6)


def compute_loss(
    outputs: dict[str, torch.Tensor],
    raw_patches: torch.Tensor,
    E_norm: torch.Tensor,
    E_anom: torch.Tensor,
    mask: torch.Tensor,
    topk_anom_ratio: float,
    hard_neg_ratio: float,
    lambda_id: float,
    lambda_res: float,
    lambda_ortho: float,
    lambda_zero: float,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    f_id = outputs["f_id"]
    f_res = outputs["f_res"]
    l_id = compute_identity_support_loss(f_id, raw_patches, E_norm)
    l_res = compute_consensus_loss(normalize_feat(f_res), normalize_feat(E_anom), mask, topk_ratio=topk_anom_ratio)
    l_ortho = outputs["loss_ortho"]
    l_zero = compute_zero_signal_loss(f_res, mask, hard_neg_ratio)
    total = (
        float(lambda_id) * l_id
        + float(lambda_res) * l_res
        + float(lambda_ortho) * l_ortho
        + float(lambda_zero) * l_zero
    )
    return total, {"l_id": l_id, "l_res": l_res, "l_ortho": l_ortho, "l_zero": l_zero}


def patch_scores_to_pixel_map(scores: np.ndarray, target_size: int, blur_sigma: float) -> np.ndarray:
    side = int(round(math.sqrt(scores.shape[0])))
    if side * side != scores.shape[0]:
        raise ValueError(f"Cannot reshape patch scores of length {scores.shape[0]} into square grid.")
    score_t = torch.from_numpy(scores.reshape(1, 1, side, side)).float()
    pixel_map = F.interpolate(score_t, size=(target_size, target_size), mode="bilinear", align_corners=False)[
        0, 0
    ].cpu().numpy()
    if blur_sigma > 0:
        pixel_map = ndimage.gaussian_filter(pixel_map, sigma=float(blur_sigma))
    return pixel_map.astype(np.float32)


def safe_pixel_auc(score_maps: list[np.ndarray], gt_masks: list[np.ndarray]) -> float:
    if not score_maps or not gt_masks:
        return float("nan")
    score_arr = np.stack(score_maps, axis=0)
    gt_arr = np.stack(gt_masks, axis=0).astype(np.uint8)
    flat_gt = gt_arr.ravel()
    if flat_gt.min() == flat_gt.max():
        return float("nan")
    try:
        return float(roc_auc_score(flat_gt, score_arr.ravel()))
    except Exception:
        return float("nan")


def safe_pro(score_maps: list[np.ndarray], gt_masks: list[np.ndarray]) -> float:
    if not score_maps or not gt_masks:
        return float("nan")
    gt_arr = np.stack(gt_masks, axis=0).astype(np.uint8)
    if gt_arr.max() <= 0:
        return float("nan")
    score_arr = np.stack(score_maps, axis=0).astype(np.float32)
    try:
        return float(cal_pro_metric(gt_arr, score_arr, fpr_thresh=0.3))
    except Exception:
        return float("nan")


def train_one_epoch(
    backbone,
    models: dict[int, IdentityResidualExtractor],
    prompt_cache: dict[str, dict[str, torch.Tensor]],
    train_records,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    for model in models.values():
        model.train()

    loss_vals = []
    layer_loss_vals = {layer: [] for layer in args.layers}

    records_by_class: dict[str, list] = {}
    for rec in train_records:
        records_by_class.setdefault(rec.class_name, []).append(rec)
    rng = np.random.default_rng(epoch_idx)
    class_order = list(records_by_class.keys())
    rng.shuffle(class_order)

    for class_name in class_order:
        cond = prompt_cache[class_name]
        class_records = records_by_class[class_name]
        order = rng.permutation(len(class_records))
        for start in range(0, len(order), args.train_batch_size):
            batch_idx = order[start : start + args.train_batch_size]
            batch_records = [class_records[int(i)] for i in batch_idx]
            image_t_cpu, patch_mask = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            mask = torch.from_numpy(patch_mask.astype(np.int64)).to(device)

            total_loss = torch.zeros([], device=device)
            for layer in args.layers:
                seq = forward_up_to_layer(backbone, image_t, layer)
                _, patches = patchify_sequence(seq)
                outputs = models[layer](patches, cond["E_norm"], E_anom=cond["E_anom"], return_aux=True)
                layer_loss, _ = compute_loss(
                    outputs,
                    patches,
                    cond["E_norm"],
                    cond["E_anom"],
                    mask,
                    topk_anom_ratio=args.topk_anom_ratio,
                    hard_neg_ratio=args.hard_neg_ratio,
                    lambda_id=args.lambda_id,
                    lambda_res=args.lambda_res,
                    lambda_ortho=args.lambda_ortho,
                    lambda_zero=args.lambda_zero,
                )
                total_loss = total_loss + layer_loss
                layer_loss_vals[layer].append(float(layer_loss.item()))

            total_loss = total_loss / float(len(args.layers))
            optimizer.zero_grad(set_to_none=True)
            total_loss.backward()
            optimizer.step()
            loss_vals.append(float(total_loss.item()))

    stats = {"train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan")}
    for layer in args.layers:
        vals = layer_loss_vals[layer]
        stats[f"train_loss_L{layer}"] = float(np.mean(vals)) if vals else float("nan")
    return stats


def evaluate_target_class(
    backbone,
    models: dict[int, IdentityResidualExtractor],
    cond: dict[str, torch.Tensor],
    eval_records,
    layers: list[int],
    img_size: int,
    topk_ratio: float,
    eval_batch_size: int,
    pixel_blur_sigma: float,
    device: str,
) -> dict[str, float]:
    for model in models.values():
        model.eval()

    patch_labels = []
    base_patch_scores = []
    model_patch_scores = []
    image_labels = []
    base_image_scores = []
    model_image_scores = []
    gt_masks = []
    base_pixel_maps = []
    model_pixel_maps = []
    ortho_vals = {layer: [] for layer in layers}

    with torch.no_grad():
        for start in range(0, len(eval_records), eval_batch_size):
            batch_records = eval_records[start : start + eval_batch_size]
            image_t_cpu, patch_masks = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)

            layer_base_scores = {}
            layer_model_scores = {}
            for layer in layers:
                seq = forward_up_to_layer(backbone, image_t, layer)
                _, patches = patchify_sequence(seq)
                outputs = models[layer](patches, cond["E_norm"], E_anom=cond["E_anom"], return_aux=True)
                layer_model_scores[layer] = outputs["score"].detach().cpu().numpy()
                layer_base_scores[layer] = score_promptmax(patches, cond["E_norm"].mean(dim=0), cond["E_anom"])
                ortho_vals[layer].append(float(outputs["loss_ortho"].item()))

            for rec_idx, (rec, rec_mask) in enumerate(zip(batch_records, patch_masks)):
                base_maps = [np.asarray(layer_base_scores[layer][rec_idx], dtype=np.float32) for layer in layers]
                model_maps = [np.asarray(layer_model_scores[layer][rec_idx], dtype=np.float32) for layer in layers]
                fused_base = np.mean(np.stack(base_maps, axis=0), axis=0)
                fused_model = np.mean(np.stack(model_maps, axis=0), axis=0)

                patch_labels.extend(rec_mask.astype(np.int64).tolist())
                base_patch_scores.extend(fused_base.tolist())
                model_patch_scores.extend(fused_model.tolist())
                image_labels.append(rec.label)
                base_image_scores.append(topk_mean(fused_base, topk_ratio))
                model_image_scores.append(topk_mean(fused_model, topk_ratio))

                if rec.mask_path is None:
                    gt_mask = np.zeros((img_size, img_size), dtype=np.uint8)
                else:
                    gt_mask = np.asarray(Image.open(rec.mask_path))
                    if gt_mask.ndim == 3:
                        gt_mask = gt_mask[..., 0]
                    gt_mask = (gt_mask > 0).astype(np.uint8)
                    if gt_mask.shape != (img_size, img_size):
                        gt_mask = np.asarray(
                            Image.fromarray(gt_mask * 255).resize((img_size, img_size), resample=Image.NEAREST),
                            dtype=np.uint8,
                        )
                        gt_mask = (gt_mask > 0).astype(np.uint8)
                gt_masks.append(gt_mask)
                base_pixel_maps.append(patch_scores_to_pixel_map(fused_base, img_size, pixel_blur_sigma))
                model_pixel_maps.append(patch_scores_to_pixel_map(fused_model, img_size, pixel_blur_sigma))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    model_patch_auc = safe_auc(patch_labels, model_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    model_image_auc = safe_auc(image_labels, model_image_scores)
    base_pixel_auc = safe_pixel_auc(base_pixel_maps, gt_masks)
    model_pixel_auc = safe_pixel_auc(model_pixel_maps, gt_masks)
    base_p_pro = safe_pro(base_pixel_maps, gt_masks)
    model_p_pro = safe_pro(model_pixel_maps, gt_masks)

    stats = {
        "base_prompt_patch_auc": base_patch_auc,
        "idres_prompt_patch_auc": model_patch_auc,
        "prompt_patch_auc_delta": model_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "idres_prompt_image_auc": model_image_auc,
        "prompt_image_auc_delta": model_image_auc - base_image_auc,
        "base_prompt_pixel_auc": base_pixel_auc,
        "idres_prompt_pixel_auc": model_pixel_auc,
        "prompt_pixel_auc_delta": model_pixel_auc - base_pixel_auc,
        "base_prompt_p_pro": base_p_pro,
        "idres_prompt_p_pro": model_p_pro,
        "prompt_p_pro_delta": model_p_pro - base_p_pro,
    }
    for layer in layers:
        vals = ortho_vals[layer]
        stats[f"eval_loss_ortho_L{layer}"] = float(np.mean(vals)) if vals else float("nan")
    return stats


def main() -> None:
    args = parse_args()
    args.layers = sorted(set(int(layer) for layer in args.layers))
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for p in backbone.parameters():
        p.requires_grad_(False)

    if args.source_dataset == "mvtec":
        train_records = collect_mvtec_train_records(backbone, args)
        source_class_names = list(args.source_classes)
    else:
        train_records = collect_realiad_train_records(backbone, args)
        source_class_names = sorted({rec.class_name for rec in train_records})

    source_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, device) for class_name in source_class_names
    }
    target_prompt_cache = {class_name: build_prompt_condition(backbone, class_name, device) for class_name in args.target_classes}

    dim = int(next(iter(source_prompt_cache.values()))["E_norm"].shape[1])
    models = {
        layer: IdentityResidualExtractor(
            dim=dim,
            num_id_queries=args.num_id_queries,
            num_res_queries=args.num_res_queries,
            detach_residual_input=True,
        ).to(device)
        for layer in args.layers
    }

    token_params = []
    other_params = []
    for model in models.values():
        token_params.extend([model.query_id, model.query_res])
        other_params.extend([p for n, p in model.named_parameters() if n not in {"query_id", "query_res"}])
    optimizer = torch.optim.AdamW(
        [
            {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
            {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
        ]
    )

    layer_str = "-".join(str(layer) for layer in args.layers)
    print(
        f"[setup] source_dataset={args.source_dataset} source_classes={len(source_class_names)} "
        f"source_records={len(train_records)} target_classes={len(args.target_classes)} "
        f"layers=L{layer_str}"
    )

    history = []
    for epoch in range(1, args.epochs + 1):
        stats = train_one_epoch(
            backbone,
            models,
            source_prompt_cache,
            train_records,
            args,
            optimizer,
            device,
            epoch,
        )
        history.append({"epoch": epoch, **stats})
        layer_msg = " ".join(f"L{layer}={stats[f'train_loss_L{layer}']:.6f}" for layer in args.layers)
        print(f"[epoch {epoch}/{args.epochs}] loss={stats['train_loss']:.6f} {layer_msg}")

    rows = []
    for class_name in args.target_classes:
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(
            backbone,
            models,
            target_prompt_cache[class_name],
            eval_records,
            args.layers,
            args.img_size,
            args.topk_ratio,
            args.eval_batch_size,
            args.pixel_blur_sigma,
            device,
        )
        rows.append(
            {
                "class_name": class_name,
                "layers": layer_str,
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "img_size": args.img_size,
                "epochs": args.epochs,
                "num_id_queries": args.num_id_queries,
                "num_res_queries": args.num_res_queries,
                "lambda_id": args.lambda_id,
                "lambda_res": args.lambda_res,
                "lambda_ortho": args.lambda_ortho,
                "lambda_zero": args.lambda_zero,
                "source_dataset": args.source_dataset,
                "source_classes": len(source_class_names),
                "source_train_records": len(train_records),
                **history[-1],
                **eval_stats,
            }
        )

    stem = f"{args.output_tag}_{args.backbone}_L{layer_str}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    ckpt_path = out_dir / f"{stem}_checkpoint.pt"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"args": vars(args), "history": history, "rows": rows, "target_classes": args.target_classes}, f, indent=2)
    torch.save(
        {
            "args": vars(args),
            "history": history,
            "layers": args.layers,
            "layer_state_dicts": {int(layer): model.state_dict() for layer, model in models.items()},
        },
        ckpt_path,
    )
    print(csv_path)
    print(json_path)
    print(ckpt_path)


if __name__ == "__main__":
    main()
