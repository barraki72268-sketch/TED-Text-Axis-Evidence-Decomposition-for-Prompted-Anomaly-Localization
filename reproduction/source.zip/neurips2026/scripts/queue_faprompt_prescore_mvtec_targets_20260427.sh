#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

WAIT_PID="${WAIT_PID:-1528500}"
PY="/mnt/data/envs/patchcore-conda/bin/python"
LOG_DIR="neurips2026/results/queue_logs"
mkdir -p "${LOG_DIR}"

wait_for_pid() {
  local pid="$1"
  if [[ -z "${pid}" ]]; then
    return 0
  fi
  while ps -p "${pid}" >/dev/null 2>&1; do
    echo "[$(date '+%F %T')] waiting for existing FAPrompt pid ${pid}"
    sleep 60
  done
}

run_faprompt() {
  local preset="$1"
  local save_dir="$2"
  echo "[$(date '+%F %T')] start FAPrompt ${preset} -> ${save_dir}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_faprompt.py \
    --preset "${preset}" \
    --model_name ViT-B-16-plus-240 \
    --prompt_load_mode project_crop \
    --features_list 6 12 \
    --image_size 518 \
    --batch_size 8 \
    --num_workers 4 \
    --dap_token_mode official_firstk \
    --dpam_layer 12 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --max_fp_total 4096 \
    --max_defect_total 4096 \
    --normal_topk_frac 0.01 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas 0.02,0.05,0.1,0.2 \
    --ours_image_score_mode official \
    --rectifier_gate_mode support_mass \
    --rectifier_gate_sharpness 3.0 \
    --rectifier_direction_mode host_axis \
    --bank_chunk 4096 \
    --aupro_max_step 50 \
    --insert_modes prescore_rectify \
    --device cuda:0 \
    --save_dir "${save_dir}"
  echo "[$(date '+%F %T')] done FAPrompt ${preset}"
}

wait_for_pid "${WAIT_PID}"

run_faprompt mvtec2visa neurips2026/results/faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2visa_full_20260427
run_faprompt mvtec2mpdd neurips2026/results/faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2mpdd_full_20260427
run_faprompt mvtec2btad neurips2026/results/faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2btad_full_20260427

echo "[$(date '+%F %T')] all FAPrompt queued targets finished"
