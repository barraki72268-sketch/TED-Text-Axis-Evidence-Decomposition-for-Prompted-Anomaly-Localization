#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results"
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_faprompt.py"

ALPHAS = "-0.2,-0.1,-0.05,-0.02,-0.01,0.005,0.01,0.02,0.05,0.1,0.2"
PRESETS = ["visa2mvtec", "mvtec2visa", "visa2mpdd", "visa2btad"]


def run_job(job: dict[str, object]) -> None:
    save_dir = RESULTS / str(job["save_name"])
    summary = save_dir / "summary.json"
    if summary.exists():
        print(f"[skip] {save_dir}", flush=True)
        return
    save_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(SCRIPT),
        "--preset",
        str(job["preset"]),
        "--model_name",
        str(job["model_name"]),
        "--prompt_load_mode",
        str(job["prompt_load_mode"]),
        "--features_list",
        *[str(x) for x in job["features_list"]],
        "--image_size",
        "518",
        "--batch_size",
        str(job["batch_size"]),
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        str(job["dpam_layer"]),
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        f"--alphas={ALPHAS}",
        "--ours_image_score_mode",
        "official",
        "--rectifier_gate_mode",
        "support_mass",
        "--rectifier_gate_sharpness",
        "3.0",
        "--rectifier_direction_mode",
        "host_axis",
        "--bank_chunk",
        "4096",
        "--aupro_max_step",
        "50",
        "--insert_modes",
        "prescore_rectify",
        "--device",
        str(job["device"]),
        "--save_dir",
        str(save_dir),
    ]
    print(f"[run] {save_dir}", flush=True)
    print(" ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def main() -> int:
    jobs: list[dict[str, object]] = []
    for preset in PRESETS:
        jobs.append(
            {
                "preset": preset,
                "save_name": f"faprompt_vith14_prescore_hostaxis_{preset}_wide_20260427",
                "model_name": "ViT-H-14",
                "prompt_load_mode": "project_crop",
                "features_list": [8, 16, 24, 32],
                "dpam_layer": 30,
                "batch_size": 4,
                "device": "cuda:0",
            }
        )
    for preset in PRESETS:
        jobs.append(
            {
                "preset": preset,
                "save_name": f"faprompt_vitl14openai_prescore_hostaxis_{preset}_wide_20260427",
                "model_name": "ViT-L/14",
                "prompt_load_mode": "strict",
                "features_list": [6, 12, 18, 24],
                "dpam_layer": 20,
                "batch_size": 8,
                "device": "cuda:0",
            }
        )

    for job in jobs:
        run_job(job)
    print("[done] FAPrompt host/backbone alpha sweeps", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
