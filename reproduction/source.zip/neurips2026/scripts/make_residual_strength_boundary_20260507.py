#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results" / "residual_strength_boundary_20260507"
OUT_TEX = ROOT / "supp_fig" / "residual_strength_boundary_20260507.tex"
OUT_CSV = ROOT / "supp_fig" / "residual_strength_boundary_20260507.csv"


def metric_blob(summary: dict, key: str) -> dict | None:
    mean = summary.get("mean", {})
    cand = mean.get("candidates", {}) or mean.get("parallel", {})
    return cand.get(key)


def baseline_blob(summary: dict) -> dict | None:
    mean = summary.get("mean", {})
    return mean.get("baseline_official") or mean.get("baseline")


def loc_delta(base: dict, cand: dict) -> tuple[float, float, float]:
    pro_key = "pixel_aupro" if "pixel_aupro" in cand else "pixel_pro"
    pauc_key = "pixel_auroc" if "pixel_auroc" in cand else "pixel_auc"
    d_pauc = float(cand[pauc_key]) - float(base[pauc_key])
    d_pro = float(cand[pro_key]) - float(base[pro_key])
    d_ap = float(cand["pixel_ap"]) - float(base["pixel_ap"])
    return d_pauc, d_pro, d_ap


def parse_alpha(key: str) -> float | None:
    m = re.search(r"_alpha_(-?\d+(?:\.\d+)?)$", key)
    return None if m is None else float(m.group(1))


def parse_summary(path: Path) -> list[dict]:
    data = json.loads(path.read_text())
    base = baseline_blob(data)
    if not base:
        return []
    name = path.parent.name
    host = "FAPrompt" if name.startswith("faprompt") else "AA-CLIP" if name.startswith("aaclip") else "Host"
    transfer = name
    for prefix in ("faprompt_vitl336_", "aaclip_vitl_openai224_"):
        transfer = transfer.replace(prefix, "")
    transfer = transfer.replace("_strength_seed0", "")
    mean = data.get("mean", {})
    cand = mean.get("candidates", {}) or mean.get("parallel", {})
    rows = []
    for key, blob in sorted(cand.items()):
        if host == "FAPrompt" and not key.startswith("branch_calibrated_alpha_"):
            continue
        if host == "AA-CLIP" and not key.startswith("prescore_calibrated_residual_alpha_"):
            continue
        alpha = parse_alpha(key)
        if alpha is None:
            continue
        d_pauc, d_pro, d_ap = loc_delta(base, blob)
        rows.append({
            "host": host,
            "transfer": transfer,
            "alpha": alpha,
            "delta_pauc": d_pauc,
            "delta_pro": d_pro,
            "delta_ap": d_ap,
            "delta_loc": 0.5 * (d_pro + d_ap),
            "path": str(path.relative_to(ROOT)),
        })
    return rows


def collect() -> list[dict]:
    rows = []
    if RESULTS.exists():
        for path in sorted(RESULTS.glob("*/summary.json")):
            rows.extend(parse_summary(path))
    return rows


def fmt(x: float) -> str:
    return f"{x:+.1f}"


def aggregate(rows: list[dict]) -> list[dict]:
    buckets: dict[tuple[str, float], list[dict]] = defaultdict(list)
    for row in rows:
        buckets[(row["host"], float(row["alpha"]))].append(row)
        buckets[("Mean", float(row["alpha"]))].append(row)
    out = []
    for (host, alpha), items in sorted(buckets.items(), key=lambda x: (x[0][0] == "Mean", x[0][0], x[0][1])):
        out.append({
            "scope": host,
            "alpha": alpha,
            "n": len(items),
            "delta_pauc": float(np.mean([r["delta_pauc"] for r in items])),
            "delta_pro": float(np.mean([r["delta_pro"] for r in items])),
            "delta_ap": float(np.mean([r["delta_ap"] for r in items])),
            "delta_loc": float(np.mean([r["delta_loc"] for r in items])),
        })
    return out


def write_csv(rows: list[dict], aggs: list[dict]) -> None:
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    fields = ["host", "transfer", "alpha", "delta_pauc", "delta_pro", "delta_ap", "delta_loc", "path"]
    with OUT_CSV.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    with OUT_CSV.with_suffix(".summary.csv").open("w", newline="") as f:
        fields2 = ["scope", "alpha", "n", "delta_pauc", "delta_pro", "delta_ap", "delta_loc"]
        writer = csv.DictWriter(f, fieldnames=fields2)
        writer.writeheader()
        writer.writerows(aggs)


def write_tex(aggs: list[dict]) -> None:
    OUT_TEX.parent.mkdir(parents=True, exist_ok=True)
    scopes = [s for s in ("AA-CLIP", "FAPrompt", "Mean") if any(r["scope"] == s for r in aggs)]
    alphas = sorted({float(r["alpha"]) for r in aggs})
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Residual-strength boundary diagnostic.",
        r"The source calibrator and evaluation protocol are fixed while only the residual insertion strength $\alpha$ is varied.",
        r"Values are $\Delta$Loc, the mean of $\Delta$PRO and $\Delta$AP over the host baseline.",
        r"}",
        r"\label{tab:supp_residual_strength_boundary}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.0pt}",
        r"\renewcommand{\arraystretch}{1.05}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}l" + "c" * (len(alphas) + 1) + r"}",
        r"\toprule",
        "Scope & $n$ & " + " & ".join([f"$\\alpha={a:g}$" for a in alphas]) + r" \\",
        r"\midrule",
    ]
    by = {(r["scope"], float(r["alpha"])): r for r in aggs}
    for scope in scopes:
        ns = [by[(scope, a)]["n"] for a in alphas if (scope, a) in by]
        n = max(ns) if ns else 0
        vals = []
        locs = [by[(scope, a)]["delta_loc"] for a in alphas if (scope, a) in by]
        best = max(locs) if locs else None
        for a in alphas:
            item = by.get((scope, a))
            if item is None:
                vals.append("--")
                continue
            val = fmt(item["delta_loc"])
            if best is not None and abs(item["delta_loc"] - best) < 1e-8:
                val = rf"\textbf{{{val}}}"
            vals.append(val)
        lines.append(f"{scope} & {n} & " + " & ".join(vals) + r" \\")
    lines += [
        r"\bottomrule",
        r"\end{tabular*}",
        r"\end{table}",
    ]
    OUT_TEX.write_text("\n".join(lines) + "\n")


def main() -> int:
    rows = collect()
    aggs = aggregate(rows)
    write_csv(rows, aggs)
    write_tex(aggs)
    print(json.dumps({"rows": len(rows), "settings": len({(r["host"], r["transfer"]) for r in rows}), "tex": str(OUT_TEX.relative_to(ROOT)), "csv": str(OUT_CSV.relative_to(ROOT))}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
