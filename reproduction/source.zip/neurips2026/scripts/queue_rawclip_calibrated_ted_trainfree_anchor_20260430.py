from __future__ import annotations

from pathlib import Path

import queue_rawclip_calibrated_ted_20260430 as base


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026/results/rawclip_calibrated_ted_trainfree_anchor_20260430"
LOG_ROOT = RESULT_ROOT / "_logs"


def clip_cmd(backbone: dict[str, str], transfer: dict[str, str]) -> list[str]:
    cmd = base.clip_cmd(backbone, transfer)
    cmd[cmd.index("--save_dir") + 1] = str(RESULT_ROOT / f"rawclip_{backbone['tag']}_{transfer['name']}")
    cmd.extend(["--calib_anchor", "trainfree"])
    return cmd


def imagebind_cmd(transfer: dict[str, str]) -> list[str]:
    cmd = base.imagebind_cmd(transfer)
    cmd[cmd.index("--save_dir") + 1] = str(RESULT_ROOT / f"rawimagebind_{transfer['name']}")
    cmd.extend(["--calib_anchor", "trainfree"])
    return cmd


def main() -> None:
    base.RESULT_ROOT = RESULT_ROOT
    base.LOG_ROOT = LOG_ROOT
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    for backbone in base.CLIP_BACKBONES:
        for transfer in base.TRANSFERS:
            base.run_one(f"rawclip_{backbone['tag']}_{transfer['name']}", clip_cmd(backbone, transfer))
    for transfer in base.TRANSFERS:
        base.run_one(f"rawimagebind_{transfer['name']}", imagebind_cmd(transfer))


if __name__ == "__main__":
    main()
