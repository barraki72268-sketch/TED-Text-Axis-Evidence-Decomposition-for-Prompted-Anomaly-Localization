#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "weak_source_robustness_20260506"
LOGS = ROOT / "neurips2026" / "logs" / "weak_source_robustness_20260506"


AACLP_PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
AACLP_SOURCE_LIMITS = [1, 2, 4, 0]
FAPROMPT_PRESETS = ["mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
FAPROMPT_BANK_BUDGETS = [8, 16, 32, 64]


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def aaclip_cmd(preset: str, source_limit: int, device: str, seed: int) -> tuple[list[str], Path, Path]:
    tag = "all" if source_limit <= 0 else str(source_limit)
    save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_sourcelimit{tag}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--source_limit_per_class",
        str(source_limit),
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "replace,prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def faprompt_cmd(preset: str, budget: int, device: str, seed: int) -> tuple[list[str], Path, Path]:
    total = max(2 * int(budget), int(budget))
    save_dir = RESULTS / f"faprompt_vitl336_{preset}_bank{budget}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        str(budget),
        "--max_defect_per_class",
        str(budget),
        "--max_fp_total",
        str(total),
        "--max_defect_total",
        str(total),
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "support_only,branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def build_jobs(hosts: list[str], devices: list[str], seed: int) -> list[dict]:
    jobs: list[dict] = []
    if "aaclip" in hosts:
        for preset in AACLP_PRESETS:
            for limit in AACLP_SOURCE_LIMITS:
                device = devices[len(jobs) % len(devices)]
                cmd, save_dir, log_path = aaclip_cmd(preset, limit, device, seed)
                jobs.append(
                    {
                        "kind": "source_image_limit",
                        "host": "aaclip",
                        "preset": preset,
                        "budget": limit,
                        "device": device,
                        "cmd": cmd,
                        "save_dir": str(save_dir),
                        "log_path": str(log_path),
                    }
                )
    if "faprompt" in hosts:
        for preset in FAPROMPT_PRESETS:
            for budget in FAPROMPT_BANK_BUDGETS:
                device = devices[len(jobs) % len(devices)]
                cmd, save_dir, log_path = faprompt_cmd(preset, budget, device, seed)
                jobs.append(
                    {
                        "kind": "retained_bank_budget",
                        "host": "faprompt",
                        "preset": preset,
                        "budget": budget,
                        "device": device,
                        "cmd": cmd,
                        "save_dir": str(save_dir),
                        "log_path": str(log_path),
                    }
                )
    return jobs


def write_worker(worker_id: int, jobs: list[dict], force: bool, wait_pids: list[int]) -> Path:
    worker_path = LOGS / f"worker_{worker_id}.py"
    payload = {
        "root": str(ROOT),
        "jobs": jobs,
        "force": bool(force),
        "wait_pids": [int(p) for p in wait_pids],
    }
    worker_path.write_text(
        "from __future__ import annotations\n"
        "import json, os, subprocess, time\n"
        "from pathlib import Path\n\n"
        f"PAYLOAD = json.loads({json.dumps(json.dumps(payload))})\n"
        "root = Path(PAYLOAD['root'])\n"
        "for pid in PAYLOAD['wait_pids']:\n"
        "    while True:\n"
        "        try:\n"
        "            os.kill(int(pid), 0)\n"
        "        except ProcessLookupError:\n"
        "            break\n"
        "        except PermissionError:\n"
        "            break\n"
        "        print(json.dumps({'stage': 'waiting_for_pid', 'pid': int(pid)}), flush=True)\n"
        "        time.sleep(60)\n"
        "for job in PAYLOAD['jobs']:\n"
        "    save_dir = Path(job['save_dir'])\n"
        "    summary = save_dir / 'summary.json'\n"
        "    if summary.exists() and not PAYLOAD['force']:\n"
        "        print(json.dumps({'stage': 'skip_done', **{k: job[k] for k in ['kind','host','preset','budget']}, 'summary': str(summary)}), flush=True)\n"
        "        continue\n"
        "    save_dir.mkdir(parents=True, exist_ok=True)\n"
        "    log_path = Path(job['log_path'])\n"
        "    log_path.parent.mkdir(parents=True, exist_ok=True)\n"
        "    print(json.dumps({'stage': 'job_start', **{k: job[k] for k in ['kind','host','preset','budget','device']}, 'save_dir': str(save_dir), 'log': str(log_path)}), flush=True)\n"
        "    start = time.time()\n"
        "    with log_path.open('w') as f:\n"
        "        proc = subprocess.run(job['cmd'], cwd=root, stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)\n"
        "    print(json.dumps({'stage': 'job_done', **{k: job[k] for k in ['kind','host','preset','budget']}, 'returncode': proc.returncode, 'elapsed_sec': time.time() - start}), flush=True)\n"
        "print(json.dumps({'stage': 'worker_done'}), flush=True)\n"
    )
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="aaclip,faprompt")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--wait_pids", default="")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = [x.strip().lower() for x in args.hosts.split(",") if x.strip()]
    devices = parse_csv(args.devices)
    wait_pids = [int(x) for x in parse_csv(args.wait_pids)]
    unknown = set(hosts) - {"aaclip", "faprompt"}
    if unknown:
        raise SystemExit(f"Unknown hosts={sorted(unknown)}")
    if not devices:
        raise SystemExit("No devices provided")

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    jobs = build_jobs(hosts, devices, args.seed)
    buckets: list[list[dict]] = [[] for _ in devices]
    for idx, job in enumerate(jobs):
        buckets[idx % len(buckets)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        worker_path = write_worker(worker_id, bucket, args.force, wait_pids)
        worker_log = LOGS / f"worker_{worker_id}.log"
        with worker_log.open("a") as f:
            proc = subprocess.Popen([str(PY), "-u", str(worker_path)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "worker": str(worker_path), "log": str(worker_log)})
    print(json.dumps({"stage": "queued_weak_source_robustness", "num_jobs": len(jobs), "launched": launched}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
