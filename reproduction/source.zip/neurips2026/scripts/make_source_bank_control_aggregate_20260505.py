#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
SOURCE = RESULTS / "source_bank_control_20260504"
TRAINING = RESULTS / "training_control_20260504"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

METRICS = ("P-AUC", "PRO", "AP")


def pct(x: Any) -> float | None:
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    if not np.isfinite(v):
        return None
    return v * 100.0 if abs(v) <= 1.5 else v


def metric_blob(blob: dict[str, Any] | None) -> dict[str, float] | None:
    if not blob:
        return None
    return {
        "P-AUC": pct(blob.get("pixel_auc", blob.get("pixel_auroc"))),
        "PRO": pct(blob.get("pixel_pro", blob.get("pixel_aupro"))),
        "AP": pct(blob.get("pixel_ap")),
    }


def row_mean_metrics(rows: list[dict[str, Any]], mode: str) -> dict[str, float] | None:
    for row in rows:
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return metric_blob(row)
    return None


def first_value(mapping: dict[str, Any] | None, preferred: str | None = None) -> dict[str, Any] | None:
    if not isinstance(mapping, dict) or not mapping:
        return None
    if preferred and preferred in mapping:
        return mapping[preferred]
    return mapping[sorted(mapping.keys())[0]]


def extract_metrics(summary_path: Path) -> tuple[dict[str, float], dict[str, float]] | None:
    data = json.loads(summary_path.read_text())

    if "mean" in data:
        mean = data["mean"]
        if "baseline" in mean:
            baseline = metric_blob(mean.get("baseline"))
            cted = metric_blob(first_value(mean.get("candidates"), "prescore_calibrated_alpha_1"))
            if baseline and cted:
                return baseline, cted
        if "baseline_official" in mean:
            baseline = metric_blob(mean.get("baseline_official"))
            cted = metric_blob(first_value(mean.get("parallel"), "branch_calibrated_alpha_0.5"))
            if baseline and cted:
                return baseline, cted

    rows = data.get("rows")
    if isinstance(rows, list):
        baseline = row_mean_metrics(rows, "baseline_txt")
        cted = row_mean_metrics(rows, "ted_calibrated")
        if baseline and cted:
            return baseline, cted

    return None


def parse_source_name(name: str) -> tuple[str, str, str] | None:
    patterns = [
        (r"^aaclip_vitl_openai224_(.+)_(random_normal|easy_normal)_seed\d+$", "AA-CLIP"),
        (r"^faprompt_vitl336_(.+)_(random_normal|easy_normal)_seed\d+$", "FAPrompt"),
        (r"^adaclip_vitl336_(.+)_(random_normal|easy_normal)_seed\d+$", "AdaCLIP"),
    ]
    for pattern, host in patterns:
        match = re.match(pattern, name)
        if match:
            transfer, mode = match.groups()
            return host, transfer, mode
    return None


def parse_training_name(name: str) -> tuple[str, str] | None:
    patterns = [
        (r"^aaclip_vitl_openai224_(.+)_correct_seed\d+$", "AA-CLIP"),
        (r"^faprompt_vitl336_(.+)_correct_seed\d+$", "FAPrompt"),
        (r"^adaclip_vitl336_(.+)_correct_seed\d+$", "AdaCLIP"),
    ]
    for pattern, host in patterns:
        match = re.match(pattern, name)
        if match:
            return host, match.group(1)
    return None


def delta_row(host: str, transfer: str, variant: str, summary_path: Path) -> dict[str, Any] | None:
    extracted = extract_metrics(summary_path)
    if extracted is None:
        return None
    baseline, cted = extracted
    row: dict[str, Any] = {
        "host": host,
        "transfer": transfer,
        "variant": variant,
        "path": str(summary_path.relative_to(ROOT)),
    }
    for metric in METRICS:
        b = baseline.get(metric)
        c = cted.get(metric)
        row[f"delta_{metric}"] = None if b is None or c is None else c - b
    vals = [row[f"delta_{m}"] for m in ("PRO", "AP") if row[f"delta_{m}"] is not None]
    row["delta_Loc"] = float(np.mean(vals)) if vals else None
    return row


def collect_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    for path in sorted(SOURCE.glob("*/summary.json")):
        parsed = parse_source_name(path.parent.name)
        if parsed is None:
            continue
        host, transfer, mode = parsed
        label = "Random normal" if mode == "random_normal" else "Easy normal"
        row = delta_row(host, transfer, label, path)
        if row:
            rows.append(row)

    for path in sorted(TRAINING.glob("*/summary.json")):
        parsed = parse_training_name(path.parent.name)
        if parsed is None:
            continue
        host, transfer = parsed
        # Keep only settings that also have source-bank controls for the same host/transfer.
        has_source_control = any(r["host"] == host and r["transfer"] == transfer for r in rows)
        if not has_source_control:
            continue
        row = delta_row(host, transfer, "Hard-FP", path)
        if row:
            rows.append(row)

    return rows


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["delta_Loc"] is not None:
            groups[(row["host"], row["variant"])].append(row)

    summary: list[dict[str, Any]] = []
    for (host, variant), items in sorted(groups.items()):
        entry: dict[str, Any] = {"host": host, "variant": variant, "n": len(items)}
        for metric in (*METRICS, "Loc"):
            vals = np.array([r[f"delta_{metric}"] for r in items if r[f"delta_{metric}"] is not None], dtype=float)
            entry[f"mean_{metric}"] = float(vals.mean()) if vals.size else np.nan
            entry[f"std_{metric}"] = float(vals.std(ddof=0)) if vals.size else np.nan
        summary.append(entry)
    return summary


def write_csvs(rows: list[dict[str, Any]], summary: list[dict[str, Any]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "source_bank_control_aggregate_rows_20260505.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with (OUT / "source_bank_control_aggregate_summary_20260505.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)


def write_tex(summary: list[dict[str, Any]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    def fmt(x: float) -> str:
        if not np.isfinite(x):
            return "--"
        return f"{x:+.2f}"

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Source-bank control across hosts. Values are gains over each host baseline, averaged over completed transfer settings. $\Delta$Loc is the mean of $\Delta$PRO and $\Delta$AP.}",
        r"\label{tab:source_bank_control_aggregate}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\renewcommand{\arraystretch}{1.08}",
        r"\begin{tabular}{llrrrr}",
        r"\toprule",
        r"Host & Bank & $n$ & $\Delta$P-AUC & $\Delta$PRO & $\Delta$AP \\",
        r"\midrule",
    ]
    order = {"Hard-FP": 0, "Random normal": 1, "Easy normal": 2}
    for row in sorted(summary, key=lambda r: (r["host"], order.get(r["variant"], 9))):
        lines.append(
            f"{row['host']} & {row['variant']} & {row['n']} & "
            f"{fmt(row['mean_P-AUC'])} & {fmt(row['mean_PRO'])} & {fmt(row['mean_AP'])} \\\\"
        )
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    (OUT / "source_bank_control_aggregate_table_20260505.tex").write_text("\n".join(lines))


def plot(summary: list[dict[str, Any]]) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    hosts = ["AA-CLIP", "FAPrompt", "AdaCLIP"]
    variants = ["Hard-FP", "Random normal", "Easy normal"]
    colors = {"Hard-FP": "#2F6F73", "Random normal": "#B86B4B", "Easy normal": "#6F5C8C"}
    hatches = {"Hard-FP": "", "Random normal": "", "Easy normal": ""}

    lookup = {(r["host"], r["variant"]): r for r in summary}
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.35), sharey=True)
    for ax, host in zip(axes, hosts):
        vals = []
        errs = []
        ns = []
        for variant in variants:
            row = lookup.get((host, variant))
            vals.append(0.0 if row is None else float(row["mean_Loc"]))
            errs.append(0.0 if row is None else float(row["std_Loc"]))
            ns.append(0 if row is None else int(row["n"]))
        x = np.arange(len(variants))
        bars = ax.bar(
            x,
            vals,
            yerr=errs,
            capsize=2.5,
            color=[colors[v] for v in variants],
            edgecolor="#222222",
            linewidth=0.45,
        )
        for bar, variant in zip(bars, variants):
            bar.set_hatch(hatches[variant])
        for i, (v, n) in enumerate(zip(vals, ns)):
            ax.text(
                i,
                v + (0.55 if v >= 0 else -0.75),
                f"{v:+.1f}\nn={n}",
                ha="center",
                va="bottom" if v >= 0 else "top",
                fontsize=7.2,
                fontweight="bold",
            )
        ax.axhline(0, color="#333333", lw=0.8)
        ax.set_title(host, fontsize=10.5, fontweight="bold", pad=2)
        ax.set_xticks(x)
        ax.set_xticklabels(["Hard-FP", "Random", "Easy"], rotation=25, ha="right", fontsize=8.0, fontweight="bold")
        ax.grid(axis="y", color="#E6E1D8", lw=0.65)
        ax.set_axisbelow(True)
        ax.tick_params(axis="y", labelsize=8)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
    axes[0].set_ylabel(r"Avg. $\Delta$Loc", fontsize=9.5, fontweight="bold")
    fig.suptitle("Source-bank controls across hosts", fontsize=11.0, fontweight="bold", y=1.03)
    fig.tight_layout(pad=0.55, w_pad=0.75)
    fig.savefig(FIG / "source_bank_control_aggregate_20260505.pdf", bbox_inches="tight")
    fig.savefig(FIG / "source_bank_control_aggregate_20260505.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    rows = collect_rows()
    summary = summarize(rows)
    write_csvs(rows, summary)
    write_tex(summary)
    plot(summary)
    print(
        json.dumps(
            {
                "rows": len(rows),
                "summary_rows": len(summary),
                "figure": "figure/source_bank_control_aggregate_20260505.pdf",
                "table": "neurips2026/results/final_metric_and_novelty_tables/source_bank_control_aggregate_table_20260505.tex",
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
