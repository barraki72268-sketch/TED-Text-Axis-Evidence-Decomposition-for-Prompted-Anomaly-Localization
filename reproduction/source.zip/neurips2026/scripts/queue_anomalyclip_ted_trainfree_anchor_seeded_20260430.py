from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_ted_trainfree_anchor_seeded_20260430"
LOG_ROOT = RESULT_ROOT / "_logs"
CUDA_VISIBLE_DEVICES = "1"


MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")

MVTEC_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth")
VISA_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth")


TRANSFERS = [
    {
        "name": "visa2mvtec",
        "source_root": VISA_ROOT,
        "source_dataset": "visa",
        "target_root": MVTEC_ROOT,
        "target_dataset": "mvtec",
        "checkpoint": VISA_CKPT,
    },
    {
        "name": "mvtec2visa",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": VISA_ROOT,
        "target_dataset": "visa",
        "checkpoint": MVTEC_CKPT,
    },
    {
        "name": "mvtec2mpdd",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": MPDD_ROOT,
        "target_dataset": "mpdd",
        "checkpoint": MVTEC_CKPT,
    },
    {
        "name": "mvtec2btad",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": BTAD_ROOT,
        "target_dataset": "btad",
        "checkpoint": MVTEC_CKPT,
    },
]


def build_cmd(transfer: dict[str, str], seed: int) -> list[str]:
    save_dir = RESULT_ROOT / f"{transfer['name']}_seed{seed}"
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        "cuda:0",
        "--checkpoint_path",
        transfer["checkpoint"],
        "--heldout_class",
        "none",
        "--source_root",
        transfer["source_root"],
        "--source_dataset",
        transfer["source_dataset"],
        "--target_root",
        transfer["target_root"],
        "--target_dataset",
        transfer["target_dataset"],
        "--target_mode",
        "test",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "trainfree",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]


def main() -> None:
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = CUDA_VISIBLE_DEVICES
    for transfer in TRANSFERS:
        for seed in (0, 1, 2):
            save_dir = RESULT_ROOT / f"{transfer['name']}_seed{seed}"
            summary_path = save_dir / "summary.json"
            log_path = LOG_ROOT / f"{transfer['name']}_seed{seed}.log"
            if summary_path.exists():
                print(
                    {
                        "stage": "skip_completed",
                        "transfer": transfer["name"],
                        "seed": seed,
                        "summary": str(summary_path),
                    },
                    flush=True,
                )
                continue
            cmd = build_cmd(transfer, seed)
            print({"stage": "start", "transfer": transfer["name"], "seed": seed, "log": str(log_path)}, flush=True)
            with log_path.open("w") as log_file:
                proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
            print(
                {
                    "stage": "done",
                    "transfer": transfer["name"],
                    "seed": seed,
                    "returncode": proc.returncode,
                    "log": str(log_path),
                },
                flush=True,
            )
            if proc.returncode != 0:
                raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
