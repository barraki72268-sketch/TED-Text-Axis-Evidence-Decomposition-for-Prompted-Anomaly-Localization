from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_bayespfl_ted_smoke.py"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")
CKPT = str(ROOT / "neurips2026/results/bayespfl_strict_mvtec/epoch_post_15_1.pth")

TARGETS = [
    {"name": "mvtec", "dataset": "mvtec", "root": MVTEC_ROOT},
    {"name": "visa", "dataset": "visa", "root": VISA_ROOT},
    {"name": "mpdd", "dataset": "mpdd", "root": MPDD_ROOT},
    {"name": "btad", "dataset": "btad", "root": BTAD_ROOT},
]

BACKBONES = {
    "vitb_plus": {
        "result_root": ROOT / "neurips2026/results/bayespfl_ted_vitbplus_swap_seeded_20260501",
        "config": ROOT / "neurips2026/Bayes-PFL/open_clip_local/model_configs/ViT-B-16-plus-240.json",
        "pretrained": Path("/home/jinyoung/.cache/clip/vit_b_16_plus_240-laion400m_e32-699c4b84.pt"),
        "image_size": 240,
        "features": [3, 6, 9, 12],
    },
    "vith14": {
        "result_root": ROOT / "neurips2026/results/bayespfl_ted_vith14_swap_seeded_20260501",
        "config": ROOT / "neurips2026/Bayes-PFL/open_clip_local/model_configs/ViT-H-14.json",
        "pretrained": Path(
            "/mnt/data/hf-cache/hub/models--laion--CLIP-ViT-H-14-laion2B-s32B-b79K/"
            "snapshots/1c2b8495b28150b8a4922ee1c8edee224c284c0c/open_clip_pytorch_model.bin"
        ),
        "image_size": 224,
        "features": [8, 16, 24, 32],
    },
}


def build_cmd(backbone: dict, target: dict[str, str], seed: int, save_dir: Path) -> list[str]:
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--dataset",
        "mvtec",
        "--data_path",
        MVTEC_ROOT,
        "--target_dataset",
        target["dataset"],
        "--target_data_path",
        target["root"],
        "--target_class",
        "",
        "--checkpoint_path",
        CKPT,
        "--checkpoint_load_mode",
        "compatible",
        "--config_path",
        str(backbone["config"]),
        "--pretrained_path",
        str(backbone["pretrained"]),
        "--image_size",
        str(backbone["image_size"]),
        "--features_list",
        *[str(v) for v in backbone["features"]],
        "--device_id",
        "0",
        "--seed",
        str(seed),
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--hard_frac",
        "0.01",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--margin_sign",
        "def_minus_fp",
        "--map_activation",
        "sigmoid",
        "--ted_combine",
        "residual",
        "--ted_alpha",
        "0.05",
        "--enable_calibrator",
        "--calib_epochs",
        "80",
        "--calib_lr",
        "0.02",
        "--calib_eta_init",
        "0.01",
        "--calib_eta_max",
        "0.05",
        "--calib_eta_reg",
        "1e-3",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_hard_frac",
        "0.01",
        "--calib_max_good_per_class",
        "8",
        "--calib_max_defect_per_class",
        "8",
        "--calib_max_fp_per_image",
        "64",
        "--calib_max_defect_per_image",
        "128",
        "--calib_max_train_points",
        "8192",
        "--image_topk",
        "0.01",
        "--aupro_max_step",
        "200",
        "--max_normal_eval",
        "0",
        "--max_anomaly_eval",
        "0",
        "--save_dir",
        str(save_dir),
    ]


def main() -> None:
    parser = argparse.ArgumentParser("Queue BayesPFL TED backbone-swap seeded runs.")
    parser.add_argument("--backbone", choices=sorted(BACKBONES), required=True)
    parser.add_argument("--gpu", type=str, default="0")
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    args = parser.parse_args()

    backbone = BACKBONES[args.backbone]
    result_root = Path(backbone["result_root"])
    log_root = result_root / "_logs"
    log_root.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = args.gpu

    for target in TARGETS:
        for seed in args.seeds:
            save_dir = result_root / f"mvtec2{target['name']}_seed{seed}"
            if (save_dir / "summary.json").exists():
                print({"stage": "skip_existing", "backbone": args.backbone, "target": target["name"], "seed": seed}, flush=True)
                continue
            log_path = log_root / f"mvtec2{target['name']}_seed{seed}.log"
            cmd = build_cmd(backbone, target, seed, save_dir)
            print(
                {
                    "stage": "start",
                    "backbone": args.backbone,
                    "target": target["name"],
                    "seed": seed,
                    "gpu": args.gpu,
                    "log": str(log_path),
                },
                flush=True,
            )
            with log_path.open("w") as log_file:
                proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
            print(
                {
                    "stage": "done",
                    "backbone": args.backbone,
                    "target": target["name"],
                    "seed": seed,
                    "returncode": proc.returncode,
                    "log": str(log_path),
                },
                flush=True,
            )
            if proc.returncode != 0:
                raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
