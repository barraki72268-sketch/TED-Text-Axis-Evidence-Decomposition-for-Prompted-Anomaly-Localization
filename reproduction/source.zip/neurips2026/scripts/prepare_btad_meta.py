from __future__ import annotations

import argparse
import base64
import json
import zlib
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def decode_bitmap(bitmap: dict, height: int, width: int) -> np.ndarray:
    raw = zlib.decompress(base64.b64decode(bitmap["data"]))
    rgba = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if rgba is None:
        raise RuntimeError("Failed to decode BTAD annotation bitmap")

    if rgba.ndim == 2:
        local_mask = rgba > 0
    elif rgba.shape[-1] == 4:
        local_mask = rgba[:, :, 3] > 0
    else:
        local_mask = np.any(rgba > 0, axis=-1)

    canvas = np.zeros((height, width), dtype=np.uint8)
    x0, y0 = bitmap["origin"]
    h, w = local_mask.shape
    canvas[y0 : y0 + h, x0 : x0 + w] |= local_mask.astype(np.uint8) * 255
    return canvas


def build_item(img_path: Path, split: str, mask_root: Path, ann_root: Path) -> dict:
    name = img_path.name
    cls_name, status, _ = name.split("_", 2)
    anomaly = int(status == "ko")
    item = {
        "img_path": str(img_path.resolve()),
        "mask_path": "",
        "cls_name": cls_name,
        "specie_name": "defect" if anomaly else "good",
        "anomaly": anomaly,
    }
    if anomaly == 0:
        return item

    ann_path = ann_root / f"{name}.json"
    ann = json.loads(ann_path.read_text())
    height = int(ann["size"]["height"])
    width = int(ann["size"]["width"])
    canvas = np.zeros((height, width), dtype=np.uint8)
    for obj in ann.get("objects", []):
        canvas |= decode_bitmap(obj["bitmap"], height, width)

    mask_dir = mask_root / split / cls_name
    mask_dir.mkdir(parents=True, exist_ok=True)
    mask_path = mask_dir / f"{img_path.stem}.png"
    Image.fromarray(canvas, mode="L").save(mask_path)
    item["mask_path"] = str(mask_path.resolve())
    return item


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_root", type=str, required=True)
    parser.add_argument("--output_root", type=str, required=True)
    args = parser.parse_args()

    input_root = Path(args.input_root)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    mask_root = output_root / "masks"

    meta = {"train": {"01": [], "02": [], "03": []}, "test": {"01": [], "02": [], "03": []}}

    for split in ("train", "test"):
        img_root = input_root / split / "img"
        ann_root = input_root / split / "ann"
        for img_path in sorted(p for p in img_root.iterdir() if p.is_file()):
            item = build_item(img_path, split, mask_root, ann_root)
            meta[split][item["cls_name"]].append(item)

    (output_root / "meta.json").write_text(json.dumps(meta, indent=2))
    counts = {
        split: {cls_name: len(items) for cls_name, items in split_meta.items()}
        for split, split_meta in meta.items()
    }
    print(json.dumps({"output_root": str(output_root), "counts": counts}, indent=2))


if __name__ == "__main__":
    main()
