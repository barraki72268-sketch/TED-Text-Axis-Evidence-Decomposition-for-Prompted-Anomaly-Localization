#!/usr/bin/env python3
"""Detached master queue for backbone-retrained TED stress runs.

Protocol covered by the child queues:
1. replace the visual backbone,
2. retrain the host baseline on the source recipe,
3. rebuild source banks from that retrained checkpoint,
4. evaluate TED on the retrained host.

The child queues are idempotent: existing summaries/checkpoints are skipped.
This wrapper only coordinates waiting and detaches the work from Codex.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT = ROOT / "neurips2026/results/backbone_retrained_master_20260503"

CHILDREN = [
    {
        "name": "aaclip_vitbplus_vith14",
        "cmd": [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/queue_aaclip_backbone_retrained_stress_20260502.py"),
            "--device_id",
            "{gpu}",
            "--backbones",
            "vitbplus,vith14",
        ],
    },
    {
        "name": "adaclip_anomalyclip_vitb_vith",
        "cmd": [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/queue_backbone_retrained_stress_20260501.py"),
            "{gpu}",
        ],
    },
]


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def wait_pids(pids: list[int], log) -> None:
    remaining = [pid for pid in pids if pid > 0]
    while remaining:
        alive = [pid for pid in remaining if pid_alive(pid)]
        done = sorted(set(remaining) - set(alive))
        for pid in done:
            print(json.dumps({"stage": "wait_pid_done", "pid": pid}), file=log, flush=True)
        remaining = alive
        if remaining:
            print(json.dumps({"stage": "wait_pid", "pids": remaining}), file=log, flush=True)
            time.sleep(60)


def run_master(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    log_path = OUT / "master.log"
    status_path = OUT / "status.json"
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-backbone-retrained-master-20260503")

    status: list[dict] = []
    with log_path.open("a", encoding="utf-8") as log:
        print(json.dumps({"stage": "master_start", "gpu": args.gpu, "wait_pids": args.wait_pids}), file=log, flush=True)
        wait_pids(args.wait_pids, log)

        for child in CHILDREN:
            cmd = [part.format(gpu=str(args.gpu)) for part in child["cmd"]]
            child_log_path = OUT / f"{child['name']}.log"
            print(json.dumps({"stage": "child_start", "name": child["name"], "cmd": cmd, "log": str(child_log_path)}), file=log, flush=True)
            with child_log_path.open("a", encoding="utf-8") as child_log:
                proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=child_log, stderr=subprocess.STDOUT, text=True)
            row = {"name": child["name"], "returncode": proc.returncode, "log": str(child_log_path)}
            status.append(row)
            status_path.write_text(json.dumps(status, indent=2), encoding="utf-8")
            print(json.dumps({"stage": "child_done", **row}), file=log, flush=True)
            if proc.returncode != 0:
                return proc.returncode

        print(json.dumps({"stage": "master_done", "status": str(status_path)}), file=log, flush=True)
    return 0


def detach(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(Path(__file__).resolve()),
        "--gpu",
        str(args.gpu),
    ]
    for pid in args.wait_pids:
        cmd.extend(["--wait-pid", str(pid)])
    log_path = OUT / "detached.log"
    pid_path = OUT / "detached.pid"
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    log = log_path.open("a", encoding="utf-8")
    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        close_fds=True,
    )
    pid_path.write_text(str(proc.pid), encoding="utf-8")
    print(json.dumps({"stage": "detached_started", "pid": proc.pid, "log": str(log_path), "pid_file": str(pid_path)}), flush=True)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", default="1")
    parser.add_argument("--wait-pid", dest="wait_pids", type=int, action="append", default=[])
    parser.add_argument("--detach", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.detach:
        return detach(args)
    return run_master(args)


if __name__ == "__main__":
    raise SystemExit(main())
