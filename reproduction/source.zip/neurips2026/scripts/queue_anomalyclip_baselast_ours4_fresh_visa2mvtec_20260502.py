#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_baselast_ours4_fresh_visa2mvtec_20260502"
LOG_ROOT = RESULT_ROOT / "_logs"

VISA_ROOT = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_CKPT = ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth"


def build_cmd(seed: int, device: str, force_refresh_bank: bool) -> list[str]:
    save_dir = RESULT_ROOT / f"visa2mvtec_seed{seed}"
    bank_cache = RESULT_ROOT / "visa2mvtec_ours4_scorebank.pt"
    cmd = [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        str(VISA_CKPT),
        "--model_name_or_path",
        "ViT-L/14@336px",
        "--heldout_class",
        "none",
        "--source_root",
        str(VISA_ROOT),
        "--source_dataset",
        "visa",
        "--target_root",
        str(MVTEC_ROOT),
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--baseline_features_list",
        "24",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--dpam_layer",
        "20",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(bank_cache),
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if force_refresh_bank:
        cmd.append("--refresh_bank_cache")
    return cmd


def parse_seeds(raw: str) -> list[int]:
    return [int(seed.strip()) for seed in raw.split(",") if seed.strip()]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    if args.device.startswith("cuda:"):
        env["CUDA_VISIBLE_DEVICES"] = args.device.split(":", 1)[1]
        device = "cuda:0"
    else:
        device = args.device

    seeds = parse_seeds(args.seeds)
    for idx, seed in enumerate(seeds):
        save_dir = RESULT_ROOT / f"visa2mvtec_seed{seed}"
        summary_path = save_dir / "summary.json"
        log_path = LOG_ROOT / f"visa2mvtec_seed{seed}.log"
        if summary_path.exists() and not args.force:
            print({"stage": "skip_completed", "seed": seed, "summary": str(summary_path)}, flush=True)
            continue
        cmd = build_cmd(seed=seed, device=device, force_refresh_bank=(idx == 0 or args.force))
        print({"stage": "start", "seed": seed, "log": str(log_path), "cmd": cmd}, flush=True)
        with log_path.open("w") as log_file:
            proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
        print({"stage": "done", "seed": seed, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
        if proc.returncode != 0:
            return proc.returncode

    print(
        json.dumps(
            {
                "stage": "all_done",
                "result_root": str(RESULT_ROOT),
                "seeds": seeds,
                "rule": "AnomalyCLIP baseline uses last layer [24]; TED source bank and OURS use [6,12,18,24].",
            }
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
