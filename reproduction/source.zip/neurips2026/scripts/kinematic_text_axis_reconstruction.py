from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Callable

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dummy", action="store_true", default=True)
    parser.add_argument("--class_name", type=str, default="chewinggum")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--text_workspace_rank", type=int, default=6)
    parser.add_argument("--visual_subspace_rank", type=int, default=4)
    parser.add_argument("--num_test_tokens", type=int, default=225)
    parser.add_argument("--feature_dim", type=int, default=896)
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def build_recent_general_prompt_bank(class_name: str) -> tuple[str, list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt = (
        f"a close-up inspection photo of a {cls} that is intact, complete, clean, "
        f"and free of visible damage, defects, cracks, missing parts, contamination, "
        f"deformation, discoloration, or abnormal surface patterns."
    )

    abnormal_prompts = [
        (
            f"a close-up inspection photo of a {cls} showing visible damage, cracks, holes, "
            f"broken regions, missing material, or structural defects."
        ),
        (
            f"a close-up inspection photo of a {cls} with scratches, dents, tears, surface flaws, "
            f"contamination, stains, discoloration, or abnormal marks."
        ),
        (
            f"a close-up inspection photo of a {cls} whose shape, texture, edge, or surface pattern "
            f"looks irregular, deformed, incomplete, or visibly defective."
        ),
        (
            f"a detailed inspection photo of a {cls} with missing parts, broken edges, foreign material, "
            f"local damage, or manufacturing defects."
        ),
        (
            f"a detailed inspection photo of a {cls} that appears damaged, defective, incomplete, "
            f"deformed, contaminated, or inconsistent with a normal intact item."
        ),
        (
            f"a close-up inspection photo of a {cls} with visible surface damage, structural breakage, "
            f"missing components, contamination, or abnormal appearance."
        ),
    ]
    return normal_prompt, abnormal_prompts


def encode_text_features(
    model,
    tokenizer: Callable[[list[str]], torch.Tensor],
    prompts: list[str],
) -> torch.Tensor:
    device = next(model.parameters()).device
    tokens = tokenizer(prompts).to(device)
    with torch.no_grad():
        text_features = model.encode_text(tokens).float()
    text_features = l2_normalize(text_features, dim=-1)

    proj = getattr(getattr(model, "visual", None), "proj", None)
    if proj is not None:
        text_features = (proj.detach().float().to(text_features.device) @ text_features.T).T
        text_features = l2_normalize(text_features, dim=-1)
    return text_features


def build_text_workspace(model, tokenizer, text_prompts: list[str], p_norm: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    p_norm = l2_normalize(p_norm, dim=0)
    P_anom_raw = encode_text_features(model, tokenizer, text_prompts)
    Delta_P = P_anom_raw - p_norm.unsqueeze(0)
    Delta_P = Delta_P - Delta_P.mean(dim=0, keepdim=True)

    u_t, _, _ = torch.linalg.svd(Delta_P.T, full_matrices=False)
    rank = min(u_t.shape[1], Delta_P.shape[0])
    U_text = u_t[:, :rank].contiguous()
    return U_text, Delta_P


def reconstruct_optimal_text_axis(U_text: torch.Tensor, V_anom: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    U_text = l2_normalize(U_text, dim=0)
    V_anom = l2_normalize(V_anom, dim=0)
    M = U_text.T @ V_anom
    X, S, _ = torch.linalg.svd(M, full_matrices=False)
    x_1 = X[:, 0]
    delta_p_recon = U_text @ x_1
    delta_p_recon = l2_normalize(delta_p_recon, dim=0)
    return delta_p_recon, M, S


def evaluate_reconstructed_axis(v_test: torch.Tensor, p_norm: torch.Tensor, delta_p_recon: torch.Tensor) -> torch.Tensor:
    v_test = l2_normalize(v_test, dim=-1)
    p_norm = l2_normalize(p_norm, dim=0)
    delta_p_recon = l2_normalize(delta_p_recon, dim=0)
    V_proj = (v_test @ p_norm).unsqueeze(1) * p_norm.unsqueeze(0)
    r_test = v_test - V_proj
    return r_test @ delta_p_recon


def run_dummy(args: argparse.Namespace) -> None:
    torch.manual_seed(0)
    D = args.feature_dim
    m = args.text_workspace_rank
    k = args.visual_subspace_rank
    N = args.num_test_tokens

    p_norm = l2_normalize(torch.randn(D), dim=0)
    P_anom_raw = l2_normalize(torch.randn(m, D), dim=-1)
    Delta_P = P_anom_raw - p_norm.unsqueeze(0)
    Delta_P = Delta_P - Delta_P.mean(dim=0, keepdim=True)
    u_t, _, _ = torch.linalg.svd(Delta_P.T, full_matrices=False)
    U_text = u_t[:, :m].contiguous()

    q, _ = torch.linalg.qr(torch.randn(D, k), mode="reduced")
    V_anom = q[:, :k].contiguous()

    delta_p_recon, M, S = reconstruct_optimal_text_axis(U_text, V_anom)
    v_test = l2_normalize(torch.randn(N, D), dim=-1)
    scores = evaluate_reconstructed_axis(v_test, p_norm, delta_p_recon)

    print("dummy")
    print("U_text shape:", tuple(U_text.shape))
    print("M shape:", tuple(M.shape))
    print("delta_p_recon shape:", tuple(delta_p_recon.shape))
    print("singular values shape:", tuple(S.shape))
    print("scores shape:", tuple(scores.shape))
    print("delta_p_recon norm:", float(torch.linalg.vector_norm(delta_p_recon).item()))


def run_real_prompt_demo(args: argparse.Namespace) -> None:
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
    )
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(args.class_name)

    p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0]
    U_text, Delta_P = build_text_workspace(backbone, backbone.tokenizer, abnormal_prompts, p_norm)

    D = p_norm.shape[0]
    k = min(args.visual_subspace_rank, D)
    q, _ = torch.linalg.qr(torch.randn(D, k, device=p_norm.device), mode="reduced")
    V_anom = q[:, :k]

    delta_p_recon, M, S = reconstruct_optimal_text_axis(U_text, V_anom)
    print("real_prompt_demo")
    print("class_name:", args.class_name)
    print("normal_prompt:", normal_prompt)
    print("num_abnormal_prompts:", len(abnormal_prompts))
    print("Delta_P shape:", tuple(Delta_P.shape))
    print("U_text shape:", tuple(U_text.shape))
    print("M shape:", tuple(M.shape))
    print("delta_p_recon shape:", tuple(delta_p_recon.shape))
    print("top singular value:", float(S[0].item()) if S.numel() else float("nan"))


def main() -> None:
    args = parse_args()
    run_dummy(args)
    run_real_prompt_demo(args)


if __name__ == "__main__":
    main()
