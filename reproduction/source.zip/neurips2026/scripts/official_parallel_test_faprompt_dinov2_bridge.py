#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))

from ADPretrain.models.dino import DinoModel  # noqa: E402
from neurips2026.scripts.official_parallel_test_dinov2_bridge import (  # noqa: E402
    DualMetaDataset,
    build_dino_transform,
    extract_dino_layers,
    fit_ridge_bridge,
    mask_transform,
    project_dino,
    topk_mean_np,
)
from neurips2026.scripts.official_parallel_test_faprompt import (  # noqa: E402
    PRESET_CONFIGS,
    build_model,
    calculate_aupro,
    downsample_mask_to_patch,
    learned_text_pair,
    rectify_faprompt_patch_features,
    setup_seed,
)
from utils import get_transform  # noqa: E402
import AnomalyCLIP_lib  # noqa: E402


class ArgsProxy:
    pass


def build_fap_transform(image_size: int):
    args = ArgsProxy()
    args.image_size = image_size
    image_transform, _ = get_transform(args)
    return image_transform


def safe_auc_percent(y_true: np.ndarray, y_score: np.ndarray) -> float:
    y_true = y_true.astype(np.uint8).reshape(-1)
    y_score = y_score.astype(np.float32).reshape(-1)
    if y_true.size == 0 or y_true.min() == y_true.max():
        return 0.0
    return float(roc_auc_score(y_true, y_score) * 100.0)


def safe_ap_percent(y_true: np.ndarray, y_score: np.ndarray) -> float:
    y_true = y_true.astype(np.uint8).reshape(-1)
    y_score = y_score.astype(np.float32).reshape(-1)
    if y_true.size == 0 or y_true.min() == y_true.max():
        return 0.0
    return float(average_precision_score(y_true, y_score) * 100.0)


def compute_metrics_percent(masks: np.ndarray, labels: np.ndarray, maps: np.ndarray, img_scores: np.ndarray, aupro_max_step: int) -> dict:
    return {
        "pixel_auc": safe_auc_percent(masks.reshape(-1), maps.reshape(-1)),
        "pixel_ap": safe_ap_percent(masks.reshape(-1), maps.reshape(-1)),
        "pixel_pro": calculate_aupro(masks, maps, max_step=aupro_max_step) * 100.0,
        "image_auc": safe_auc_percent(labels, img_scores),
        "image_ap": safe_ap_percent(labels, img_scores),
    }


def make_patch_features(tokens: torch.Tensor) -> torch.Tensor:
    # FAPrompt similarity functions expect [1 + spatial_tokens, batch, dim].
    global_token = F.normalize(tokens.mean(dim=1, keepdim=True), dim=-1)
    return torch.cat([global_token, tokens], dim=1).permute(1, 0, 2).contiguous()


@torch.no_grad()
def faprompt_from_projected_tokens(
    tokens: torch.Tensor,
    model,
    prompt_learner,
    image_size: int,
    sigma: int,
    dap_token_mode: str,
    base_text_pair: torch.Tensor,
) -> tuple[np.ndarray, torch.Tensor]:
    patch_features = make_patch_features(tokens)
    text_pair = base_text_pair
    similarity1, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_pair)
    similarity_map1 = AnomalyCLIP_lib.get_similarity_map(similarity1[1:, :], image_size)
    num_top = min(10, similarity1[1:, :, 1].shape[0])
    pk_idx = torch.topk(similarity1[1:, :, 1], k=num_top, dim=0, largest=True, sorted=True).indices.permute(1, 0)
    patch_by_batch = patch_features[1:, :, :].permute(1, 0, 2).contiguous()
    if dap_token_mode == "topk":
        selected = torch.stack([patch_by_batch[bi, pk_idx[bi], :] for bi in range(pk_idx.shape[0])], dim=0)
    elif dap_token_mode == "official_firstk":
        selected = patch_by_batch[:, :num_top, :]
    else:
        raise ValueError(f"Unknown dap_token_mode: {dap_token_mode}")

    text_features_list = []
    for bi in range(selected.shape[0]):
        p_pos, p_neg, tok_pos, tok_neg, comp_text, _ = prompt_learner.forward(selected_tokens=selected[bi])
        tf_pos = model.encode_text_learn(p_pos, tok_pos, comp_text).float()
        tf_neg = model.encode_text_learn(p_neg, tok_neg, comp_text).float()
        tf_neg = torch.mean(tf_neg, dim=0, keepdim=True)
        text_features_list.append(torch.cat([tf_pos, tf_neg]))
    text_features = F.normalize(torch.stack(text_features_list, dim=0), dim=-1)
    similarity2, _ = AnomalyCLIP_lib.compute_similarity(patch_features, text_features)
    similarity_map2 = AnomalyCLIP_lib.get_similarity_map(similarity2[1:, :], image_size)
    anomaly_map = (similarity_map1[:, 1, :] + 1.0 - similarity_map1[:, 0, :] + similarity_map2[:, 1, :] + 1.0 - similarity_map2[:, 0, :]) / 4.0
    anomaly_np = anomaly_map.detach().cpu().numpy()
    if sigma > 0:
        from scipy.ndimage import gaussian_filter

        anomaly_np = gaussian_filter(anomaly_np, sigma=sigma)
    token_score = 0.5 * (similarity1[1:, :, 1] + similarity2[1:, :, 1])
    return anomaly_np.astype(np.float32), token_score.permute(1, 0).contiguous()


@torch.no_grad()
def collect_bridge_pairs(
    dino: DinoModel,
    model,
    ds: DualMetaDataset,
    dino_layers: list[int],
    fap_layers: list[int],
    dpam_layer: int,
    device: torch.device,
    max_fit_per_class: int,
    max_patches_per_image: int,
    seed: int,
) -> dict[int, tuple[torch.Tensor, torch.Tensor]]:
    rng = random.Random(seed)
    per_class = {cls: 0 for cls in ds.obj_list}
    xs = {i: [] for i in range(len(dino_layers))}
    ys = {i: [] for i in range(len(dino_layers))}
    for idx, item_meta in enumerate(ds.items):
        if all(count >= max_fit_per_class for count in per_class.values()):
            break
        cls = item_meta["cls_name"]
        if per_class[cls] >= max_fit_per_class:
            continue
        per_class[cls] += 1
        item = ds[idx]
        dino_img = item["dino"].unsqueeze(0).to(device)
        fap_img = item["clip"].unsqueeze(0).to(device)
        dino_out = extract_dino_layers(dino, dino_img, dino_layers)
        _, fap_patches = model.encode_image(fap_img, fap_layers, DPAM_layer=dpam_layer)
        fap_tokens = F.normalize(fap_patches[1:, 0].float(), dim=-1)
        for i, layer in enumerate(dino_layers):
            x = F.normalize(dino_out[layer][0].float(), dim=-1).cpu()
            y = fap_tokens.cpu()
            n = min(x.shape[0], y.shape[0], max_patches_per_image)
            sample_idx = torch.tensor(rng.sample(range(min(x.shape[0], y.shape[0])), n), dtype=torch.long)
            xs[i].append(x[sample_idx])
            ys[i].append(y[sample_idx])
    return {i: (torch.cat(xs[i], dim=0), torch.cat(ys[i], dim=0)) for i in xs}


@torch.no_grad()
def collect_source_banks(
    dino: DinoModel,
    model,
    prompt_learner,
    source_root: str,
    dino_transform,
    fap_transform,
    mask_t,
    bridges: dict[int, torch.Tensor],
    dino_layers: list[int],
    device: torch.device,
    image_size: int,
    sigma: int,
    dap_token_mode: str,
    max_fp_per_class: int,
    max_defect_per_class: int,
    normal_topk_frac: float,
    defect_topk_frac: float,
    source_limit_per_class: int,
) -> dict:
    meta = json.loads((Path(source_root) / "meta.json").read_text())
    class_names = sorted(meta["train"].keys())
    base_text_pair = learned_text_pair(model, prompt_learner)
    bank_fp = {i: [] for i in range(len(dino_layers))}
    bank_def = {i: [] for i in range(len(dino_layers))}
    for cls in class_names:
        normal_ds = DualMetaDataset(source_root, dino_transform, fap_transform, mask_t, "train", class_name=cls, normal_only=True)
        anomaly_ds = DualMetaDataset(source_root, dino_transform, fap_transform, mask_t, "test", class_name=cls, anomaly_only=True)
        if source_limit_per_class > 0:
            normal_ds.items = normal_ds.items[:source_limit_per_class]
            anomaly_ds.items = anomaly_ds.items[:source_limit_per_class]
        fp_parts = {i: [] for i in range(len(dino_layers))}
        def_parts = {i: [] for i in range(len(dino_layers))}
        for item in normal_ds:
            dino_out = extract_dino_layers(dino, item["dino"].unsqueeze(0).to(device), dino_layers)
            for i, layer in enumerate(dino_layers):
                z = project_dino(dino_out[layer][0], bridges[i]).unsqueeze(0)
                _, score = faprompt_from_projected_tokens(z, model, prompt_learner, image_size, sigma, dap_token_mode, base_text_pair)
                k = max(1, int(math.ceil(score.shape[1] * normal_topk_frac)))
                fp_parts[i].append(z[0, torch.topk(score[0], k=k, largest=True).indices].detach().cpu())
        for item in anomaly_ds:
            dino_out = extract_dino_layers(dino, item["dino"].unsqueeze(0).to(device), dino_layers)
            mask = item["mask"].unsqueeze(0).to(device)
            for i, layer in enumerate(dino_layers):
                z = project_dino(dino_out[layer][0], bridges[i]).unsqueeze(0)
                _, score = faprompt_from_projected_tokens(z, model, prompt_learner, image_size, sigma, dap_token_mode, base_text_pair)
                side = int(round(math.sqrt(z.shape[1])))
                pos = torch.nonzero(downsample_mask_to_patch(mask, side)[0], as_tuple=False).flatten()
                if pos.numel() == 0:
                    continue
                k = max(1, int(math.ceil(pos.numel() * defect_topk_frac)))
                k = min(k, pos.numel())
                top_pos = pos[torch.topk(score[0, pos], k=k, largest=True).indices]
                def_parts[i].append(z[0, top_pos].detach().cpu())
        for i in range(len(dino_layers)):
            fp = torch.cat(fp_parts[i], dim=0) if fp_parts[i] else torch.empty(0, bridges[i].shape[1])
            de = torch.cat(def_parts[i], dim=0) if def_parts[i] else torch.empty(0, bridges[i].shape[1])
            if fp.shape[0] > max_fp_per_class:
                fp = fp[torch.randperm(fp.shape[0])[:max_fp_per_class]]
            if de.shape[0] > max_defect_per_class:
                de = de[torch.randperm(de.shape[0])[:max_defect_per_class]]
            bank_fp[i].append(fp)
            bank_def[i].append(de)
        print(json.dumps({"stage": "source_class_done", "class_name": cls}), flush=True)
    return {
        "fp": [F.normalize(torch.cat(bank_fp[i], dim=0).float(), dim=-1) for i in range(len(dino_layers))],
        "defect": [F.normalize(torch.cat(bank_def[i], dim=0).float(), dim=-1) for i in range(len(dino_layers))],
    }


@torch.no_grad()
def evaluate_target(
    dino: DinoModel,
    model,
    prompt_learner,
    target_root: str,
    dino_transform,
    fap_transform,
    mask_t,
    bridges: dict[int, torch.Tensor],
    banks: dict,
    dino_layers: list[int],
    device: torch.device,
    image_size: int,
    sigma: int,
    dap_token_mode: str,
    alphas: list[float],
    tau: float,
    fp_weight: float,
    gate_sharpness: float,
    image_score_topk: float,
    aupro_max_step: int,
    target_limit_per_class: int,
) -> dict:
    ds = DualMetaDataset(target_root, dino_transform, fap_transform, mask_t, "test")
    if target_limit_per_class > 0:
        kept = []
        counts = {cls: 0 for cls in ds.obj_list}
        for item in ds.items:
            cls = item["cls_name"]
            if counts[cls] < target_limit_per_class:
                kept.append(item)
                counts[cls] += 1
        ds.items = kept
    base_text_pair = learned_text_pair(model, prompt_learner)
    axis = F.normalize(base_text_pair[1] - base_text_pair[0], dim=0)
    results = {
        "baseline": {cls: {"maps": [], "imgs": [], "labels": [], "masks": []} for cls in ds.obj_list},
        **{f"prescore_rectify_alpha_{a:g}": {cls: {"maps": [], "imgs": [], "labels": [], "masks": []} for cls in ds.obj_list} for a in alphas},
    }
    for item in ds:
        cls = item["class_name"]
        label = int(item["label"].item())
        mask = item["mask"].numpy()[0].astype(np.float32)
        dino_out = extract_dino_layers(dino, item["dino"].unsqueeze(0).to(device), dino_layers)
        base_layers = []
        rect_layers = {a: [] for a in alphas}
        for i, layer in enumerate(dino_layers):
            z = project_dino(dino_out[layer][0], bridges[i]).unsqueeze(0)
            base_map, _ = faprompt_from_projected_tokens(z, model, prompt_learner, image_size, sigma, dap_token_mode, base_text_pair)
            base_layers.append(base_map)
            pseudo_patch = make_patch_features(z)
            for alpha in alphas:
                rect_patch = rectify_faprompt_patch_features(
                    pseudo_patch,
                    defect_bank=banks["defect"][i].to(device),
                    fp_bank=banks["fp"][i].to(device),
                    strength=alpha,
                    tau=tau,
                    fp_weight=fp_weight,
                    gate_sharpness=gate_sharpness,
                    gate_mode="support_mass",
                    direction_mode="host_axis",
                    axis=axis,
                )
                rect_tokens = rect_patch[1:].permute(1, 0, 2).contiguous()
                rect_map, _ = faprompt_from_projected_tokens(rect_tokens, model, prompt_learner, image_size, sigma, dap_token_mode, base_text_pair)
                rect_layers[alpha].append(rect_map)
        base_np = np.mean(np.concatenate(base_layers, axis=0), axis=0, keepdims=True)
        results["baseline"][cls]["maps"].append(base_np[0])
        results["baseline"][cls]["imgs"].append(topk_mean_np(base_np, image_score_topk)[0])
        results["baseline"][cls]["labels"].append(label)
        results["baseline"][cls]["masks"].append(mask)
        for alpha in alphas:
            rect_np = np.mean(np.concatenate(rect_layers[alpha], axis=0), axis=0, keepdims=True)
            key = f"prescore_rectify_alpha_{alpha:g}"
            results[key][cls]["maps"].append(rect_np[0])
            results[key][cls]["imgs"].append(topk_mean_np(rect_np, image_score_topk)[0])
            results[key][cls]["labels"].append(label)
            results[key][cls]["masks"].append(mask)
    rows = []
    mean = {}
    for mode, by_cls in results.items():
        vals = []
        for cls, pack in by_cls.items():
            maps = np.stack(pack["maps"], axis=0).astype(np.float32)
            masks = np.stack(pack["masks"], axis=0).astype(np.float32)
            labels = np.asarray(pack["labels"], dtype=np.int64)
            imgs = np.asarray(pack["imgs"], dtype=np.float32)
            metrics = compute_metrics_percent(masks, labels, maps, imgs, aupro_max_step)
            rows.append({"mode": mode, "class_name": cls, **metrics})
            vals.append(metrics)
        mean[mode] = {k: float(np.nanmean([v[k] for v in vals])) for k in vals[0]}
    return {"rows": rows, "mean": mean}


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", required=True, choices=sorted(PRESET_CONFIGS))
    ap.add_argument("--dino_backbone", default="dinov2-base", choices=["dinov2-base", "dinov2-large"])
    ap.add_argument("--dino_layers", default="6,12")
    ap.add_argument("--model_name", default="ViT-L/14@336px")
    ap.add_argument("--prompt_load_mode", default="strict", choices=["strict", "project_crop"])
    ap.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    ap.add_argument("--image_size", type=int, default=518)
    ap.add_argument("--dpam_layer", type=int, default=20)
    ap.add_argument("--depth", type=int, default=9)
    ap.add_argument("--n_ctx", type=int, default=12)
    ap.add_argument("--t_n_ctx", type=int, default=4)
    ap.add_argument("--sigma", type=int, default=10)
    ap.add_argument("--dap_token_mode", default="official_firstk", choices=["topk", "official_firstk"])
    ap.add_argument("--fit_max_per_class", type=int, default=2)
    ap.add_argument("--fit_max_patches_per_image", type=int, default=128)
    ap.add_argument("--ridge", type=float, default=1e-3)
    ap.add_argument("--max_fp_per_class", type=int, default=256)
    ap.add_argument("--max_defect_per_class", type=int, default=256)
    ap.add_argument("--source_limit_per_class", type=int, default=64)
    ap.add_argument("--target_limit_per_class", type=int, default=0)
    ap.add_argument("--normal_topk_frac", type=float, default=0.01)
    ap.add_argument("--defect_topk_frac", type=float, default=0.25)
    ap.add_argument("--tau", type=float, default=0.1)
    ap.add_argument("--fp_weight", type=float, default=1.0)
    ap.add_argument("--gate_sharpness", type=float, default=3.0)
    ap.add_argument("--alphas", default="0.02,0.05,0.1,0.2")
    ap.add_argument("--image_score_topk", type=float, default=0.10)
    ap.add_argument("--aupro_max_step", type=int, default=50)
    ap.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--save_dir", required=True)
    return ap.parse_args()


def main():
    args = parse_args()
    setup_seed(args.seed)
    cfg = dict(PRESET_CONFIGS[args.preset])
    device = torch.device(args.device)
    dino_layers = [int(x) for x in args.dino_layers.split(",") if x.strip()]
    if len(dino_layers) != len(args.features_list):
        raise ValueError("--dino_layers and --features_list must have the same length")
    dino = DinoModel(args.dino_backbone, device=str(device)).eval()
    dino.visual_encoder = dino.visual_encoder.to(device)
    model, prompt_learner, info = build_model(
        device=device,
        checkpoint_path=cfg["checkpoint_path"],
        model_name=args.model_name,
        prompt_load_mode=args.prompt_load_mode,
        dpam_layer=args.dpam_layer,
        depth=args.depth,
        n_ctx=args.n_ctx,
        t_n_ctx=args.t_n_ctx,
    )
    dino_t = build_dino_transform(args.image_size)
    fap_t = build_fap_transform(args.image_size)
    mask_t = mask_transform(args.image_size)
    fit_ds = DualMetaDataset(cfg["source_root"], dino_t, fap_t, mask_t, "train", normal_only=True)
    pairs = collect_bridge_pairs(
        dino=dino,
        model=model,
        ds=fit_ds,
        dino_layers=dino_layers,
        fap_layers=args.features_list,
        dpam_layer=info["effective_dpam_layer"],
        device=device,
        max_fit_per_class=args.fit_max_per_class,
        max_patches_per_image=args.fit_max_patches_per_image,
        seed=args.seed,
    )
    bridges = {i: fit_ridge_bridge(x, y, args.ridge).to(device) for i, (x, y) in pairs.items()}
    print(json.dumps({"stage": "bridge_fit_done", "dino_layers": dino_layers, "features_list": args.features_list}), flush=True)
    banks = collect_source_banks(
        dino=dino,
        model=model,
        prompt_learner=prompt_learner,
        source_root=cfg["source_root"],
        dino_transform=dino_t,
        fap_transform=fap_t,
        mask_t=mask_t,
        bridges=bridges,
        dino_layers=dino_layers,
        device=device,
        image_size=args.image_size,
        sigma=args.sigma,
        dap_token_mode=args.dap_token_mode,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        normal_topk_frac=args.normal_topk_frac,
        defect_topk_frac=args.defect_topk_frac,
        source_limit_per_class=args.source_limit_per_class,
    )
    print(json.dumps({"stage": "source_bank_done"}), flush=True)
    alphas = [float(x) for x in args.alphas.split(",") if x.strip()]
    result = evaluate_target(
        dino=dino,
        model=model,
        prompt_learner=prompt_learner,
        target_root=cfg["target_root"],
        dino_transform=dino_t,
        fap_transform=fap_t,
        mask_t=mask_t,
        bridges=bridges,
        banks=banks,
        dino_layers=dino_layers,
        device=device,
        image_size=args.image_size,
        sigma=args.sigma,
        dap_token_mode=args.dap_token_mode,
        alphas=alphas,
        tau=args.tau,
        fp_weight=args.fp_weight,
        gate_sharpness=args.gate_sharpness,
        image_score_topk=args.image_score_topk,
        aupro_max_step=args.aupro_max_step,
        target_limit_per_class=args.target_limit_per_class,
    )
    result.update(
        {
            "preset": args.preset,
            "source_dataset": cfg["source_dataset"],
            "target_dataset": cfg["target_dataset"],
            "host": "FAPrompt",
            "image_backbone": args.dino_backbone,
            "bridge_target": args.model_name,
            "dino_layers": dino_layers,
            "features_list": args.features_list,
            "image_size": args.image_size,
            "alphas": alphas,
            "image_score_mode": "map_topk",
            "aupro_max_step": args.aupro_max_step,
            "source_limit_per_class": args.source_limit_per_class,
            "target_limit_per_class": args.target_limit_per_class,
        }
    )
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    out = save_dir / "summary.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result["mean"], indent=2), flush=True)
    print(f"[OK] wrote {out}", flush=True)


if __name__ == "__main__":
    main()
