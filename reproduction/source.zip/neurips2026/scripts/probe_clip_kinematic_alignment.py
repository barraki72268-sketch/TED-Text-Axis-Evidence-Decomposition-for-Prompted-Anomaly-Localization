from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_abnormal_prompts,
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument("--target_layers", nargs="*", type=int, default=[3, 6, 9, 12])
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--max_normal_images", type=int, default=10)
    parser.add_argument("--max_anomaly_images", type=int, default=10)
    parser.add_argument("--max_patches_per_set", type=int, default=4096)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_kinematic_alignment")
    return parser.parse_args()


def build_text_anchor(backbone, class_name: str, abnormal: bool) -> torch.Tensor:
    state_prompts = state_level_abnormal_prompts if abnormal else state_level_normal_prompts
    class_text = class_name.replace("_", " ")
    prompts: list[str] = []
    for template in template_level_prompts:
        for state_prompt in state_prompts:
            prompts.append(template.format(state_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = getattr(backbone.visual, "proj", None)
    if proj is None:
        return text_anchor.cpu()
    token_anchor = proj.detach().float().to(text_anchor.device) @ text_anchor
    return F.normalize(token_anchor, dim=0).cpu()


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def maybe_subsample(tokens: torch.Tensor, max_count: int) -> torch.Tensor:
    if max_count <= 0 or tokens.shape[0] <= max_count:
        return tokens
    idx = torch.linspace(0, tokens.shape[0] - 1, steps=max_count, device=tokens.device).round().long()
    return tokens[idx]


def collect_patch_sets(backbone, class_name: str, layers: list[int], args: argparse.Namespace, device: str):
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    normal_indices = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"][: args.max_normal_images]
    anomaly_indices = [i for i, rec in enumerate(ds.records) if rec["label"] != "normal"][: args.max_anomaly_images]

    norm_by_layer: dict[int, list[torch.Tensor]] = {layer: [] for layer in layers}
    anom_by_layer: dict[int, list[torch.Tensor]] = {layer: [] for layer in layers}

    for idx in normal_indices + anomaly_indices:
        image_np, mask_np, label, _, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens_by_layer = backbone.extract_layer_patch_tokens(image_t, target_layers=layers)
        patch_mask = to_patch_mask(mask_np, backbone.grid_size, device)
        for layer in layers:
            tokens = F.normalize(tokens_by_layer[layer][0].float(), dim=-1)
            if label == 0:
                norm_by_layer[layer].append(tokens.cpu())
            else:
                pos = torch.from_numpy(patch_mask > 0).to(tokens.device)
                if int(pos.sum().item()) > 0:
                    anom_by_layer[layer].append(tokens[pos].cpu())

    out_norm: dict[int, torch.Tensor] = {}
    out_anom: dict[int, torch.Tensor] = {}
    for layer in layers:
        norm = torch.cat(norm_by_layer[layer], dim=0) if norm_by_layer[layer] else torch.empty(0, backbone.token_dim)
        anom = torch.cat(anom_by_layer[layer], dim=0) if anom_by_layer[layer] else torch.empty(0, backbone.token_dim)
        out_norm[layer] = maybe_subsample(norm, args.max_patches_per_set)
        out_anom[layer] = maybe_subsample(anom, args.max_patches_per_set)
    return out_norm, out_anom


def matrix_rank_stats(x: torch.Tensor) -> tuple[int, float, float]:
    if x.numel() == 0:
        return 0, float("nan"), float("nan")
    x = x.float() - x.float().mean(dim=0, keepdim=True)
    sv = torch.linalg.svdvals(x)
    sv = sv[sv > 1e-8]
    if sv.numel() == 0:
        return 0, float("nan"), float("nan")
    sv2 = sv.pow(2)
    prob = sv2 / sv2.sum()
    effective_rank = float(torch.exp(-(prob * prob.clamp_min(1e-12).log()).sum()).item())
    top1_var_ratio = float((sv2[0] / sv2.sum()).item())
    return int(sv.numel()), effective_rank, top1_var_ratio


def safe_auc_from_scores(norm_scores: torch.Tensor, anom_scores: torch.Tensor) -> float:
    if norm_scores.numel() == 0 or anom_scores.numel() == 0:
        return float("nan")
    y_true = np.concatenate(
        [
            np.zeros(norm_scores.shape[0], dtype=np.int64),
            np.ones(anom_scores.shape[0], dtype=np.int64),
        ]
    )
    y_score = np.concatenate(
        [
            norm_scores.detach().cpu().numpy().astype(np.float64),
            anom_scores.detach().cpu().numpy().astype(np.float64),
        ]
    )
    return float(roc_auc_score(y_true, y_score))


def analyze_alignment(v_norm_patches: torch.Tensor, v_anom_patches: torch.Tensor, p_norm: torch.Tensor, p_anom: torch.Tensor) -> dict[str, float]:
    p_norm = F.normalize(p_norm.float(), dim=0)
    p_anom = F.normalize(p_anom.float(), dim=0)
    delta_p = F.normalize(p_anom - p_norm, dim=0)

    def project_to_null_space(v: torch.Tensor, p_base: torch.Tensor) -> torch.Tensor:
        v_proj = (v @ p_base).unsqueeze(1) * p_base.unsqueeze(0)
        return v - v_proj

    r_norm = project_to_null_space(v_norm_patches.float(), p_norm)
    r_anom = project_to_null_space(v_anom_patches.float(), p_norm)

    r_anom_centered = r_anom - r_anom.mean(dim=0, keepdim=True)
    _, s, vh = torch.linalg.svd(r_anom_centered, full_matrices=False)
    v_axis = vh[0]
    if (r_anom.mean(dim=0) @ v_axis) < 0:
        v_axis = -v_axis

    variance_ratio = float((s[0].pow(2) / s.pow(2).sum()).item()) if s.numel() > 0 and float(s.pow(2).sum().item()) > 0 else float("nan")
    ub1_norm_scores = r_norm @ v_axis
    ub1_anom_scores = r_anom @ v_axis
    ub1_auc = safe_auc_from_scores(ub1_norm_scores, ub1_anom_scores)
    ub1_norm_mean = float(ub1_norm_scores.mean().item())
    ub1_anom_mean = float(ub1_anom_scores.mean().item())

    max_k = min(4, int(vh.shape[0]))
    if max_k > 1:
        v_subspace = vh[:max_k].T
        ubk_norm_scores = torch.linalg.vector_norm(r_norm @ v_subspace, dim=-1)
        ubk_anom_scores = torch.linalg.vector_norm(r_anom @ v_subspace, dim=-1)
        ubk_auc = safe_auc_from_scores(ubk_norm_scores, ubk_anom_scores)
        ubk_norm_mean = float(ubk_norm_scores.mean().item())
        ubk_anom_mean = float(ubk_anom_scores.mean().item())
    else:
        ubk_auc = float("nan")
        ubk_norm_mean = float("nan")
        ubk_anom_mean = float("nan")

    ortho_check_mean = float(torch.abs(r_anom.mean(dim=0) @ p_norm).item())
    ortho_check_absmean = float(torch.abs(r_anom @ p_norm).mean().item())
    ortho_check_absmax = float(torch.abs(r_anom @ p_norm).max().item())
    v_axis_ortho_check = float(torch.abs(v_axis @ p_norm).item())
    alignment_score = float(F.cosine_similarity(v_axis.unsqueeze(0), delta_p.unsqueeze(0)).item())

    norm_residual_delta_cos = float(F.cosine_similarity(r_norm, delta_p.unsqueeze(0).expand_as(r_norm), dim=-1, eps=1e-8).mean().item())
    anom_residual_delta_cos = float(F.cosine_similarity(r_anom, delta_p.unsqueeze(0).expand_as(r_anom), dim=-1, eps=1e-8).mean().item())

    return {
        "normal_anchor_norm": float(torch.linalg.vector_norm(p_norm).item()),
        "abnormal_anchor_norm": float(torch.linalg.vector_norm(p_anom).item()),
        "delta_anchor_norm": float(torch.linalg.vector_norm(delta_p).item()),
        "variance_ratio": variance_ratio,
        "residual_ortho_mean_check": ortho_check_mean,
        "residual_ortho_absmean_check": ortho_check_absmean,
        "residual_ortho_absmax_check": ortho_check_absmax,
        "v_axis_ortho_check": v_axis_ortho_check,
        "alignment_score": alignment_score,
        "normal_residual_delta_cos_mean": norm_residual_delta_cos,
        "anomaly_residual_delta_cos_mean": anom_residual_delta_cos,
        "upper_bound_auc_k1": ub1_auc,
        "upper_bound_norm_score_mean_k1": ub1_norm_mean,
        "upper_bound_anom_score_mean_k1": ub1_anom_mean,
        "upper_bound_auc_k4": ubk_auc,
        "upper_bound_norm_score_mean_k4": ubk_norm_mean,
        "upper_bound_anom_score_mean_k4": ubk_anom_mean,
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    layers = sorted({int(x) for x in args.target_layers})
    p_norm = build_text_anchor(backbone, args.class_name, abnormal=False).to(torch.float32)
    p_anom = build_text_anchor(backbone, args.class_name, abnormal=True).to(torch.float32)
    norm_by_layer, anom_by_layer = collect_patch_sets(backbone, args.class_name, layers, args, device)

    rows: list[dict] = []
    for layer in layers:
        v_norm = norm_by_layer[layer]
        v_anom = anom_by_layer[layer]
        if v_norm.numel() == 0 or v_anom.numel() == 0:
            row = {
                "class_name": args.class_name,
                "layer": layer,
                "num_normal_patches": int(v_norm.shape[0]),
                "num_anomaly_patches": int(v_anom.shape[0]),
            }
        else:
            rank_num, eff_rank, top1 = matrix_rank_stats(v_norm)
            row = {
                "class_name": args.class_name,
                "layer": layer,
                "num_normal_patches": int(v_norm.shape[0]),
                "num_anomaly_patches": int(v_anom.shape[0]),
                "normal_numeric_rank": rank_num,
                "normal_effective_rank": eff_rank,
                "normal_top1_var_ratio": top1,
            }
            row.update(analyze_alignment(v_norm, v_anom, p_norm, p_anom))
        rows.append(row)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    layer_tag = "-".join(str(x) for x in layers)
    stem = f"{args.output_tag}_{args.class_name}_layers{layer_tag}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump({"rows": rows}, f, indent=2)
    print(csv_path)
    print(json_path)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
