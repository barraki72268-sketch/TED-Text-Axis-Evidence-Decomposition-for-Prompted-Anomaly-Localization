#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
cd "$ROOT"

WAIT_PID="${1:-1533831}"
GPU_ID="${2:-1}"

while kill -0 "$WAIT_PID" 2>/dev/null; do
  sleep 60
done

exec /mnt/data/envs/patchcore-conda/bin/python -u neurips2026/scripts/train_identity_residual_mvtec_to_visa_multilayer_joint.py \
  --source_dataset mvtec \
  --epochs 10 \
  --layers 3 6 9 12 \
  --train_normal_images -1 \
  --train_anomaly_images -1 \
  --train_batch_size 256 \
  --eval_batch_size 256 \
  --gpu_id "$GPU_ID" \
  --output_tag clip_identity_residual_mvtec2visa_joint4_full_e10
