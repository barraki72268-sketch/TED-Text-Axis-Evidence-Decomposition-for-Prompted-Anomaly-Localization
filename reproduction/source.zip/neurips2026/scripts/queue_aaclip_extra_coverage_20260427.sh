#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

WAIT_PID="${WAIT_PID:-1550476}"
PY="/mnt/data/envs/patchcore-conda/bin/python"

wait_for_pid() {
  local pid="$1"
  if [[ -z "${pid}" ]]; then
    return 0
  fi
  while ps -p "${pid}" >/dev/null 2>&1; do
    echo "[$(date '+%F %T')] waiting for AA-CLIP pid ${pid}"
    sleep 60
  done
}

run_aaclip() {
  local preset="$1"
  local alphas="$2"
  local save_dir="$3"
  echo "[$(date '+%F %T')] start AA-CLIP ${preset} alphas=${alphas} -> ${save_dir}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip.py \
    --preset "${preset}" \
    --model_name ViT-B-16-plus-240 \
    --pretrained laion400m_e32 \
    --adapter_load_mode project_crop \
    --levels 6,12 \
    --img_size 518 \
    --batch_size 16 \
    --num_workers 4 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas="${alphas}" \
    --blend_modes prescore_rectify \
    --candidate_topk_frac 0.10 \
    --gate_sharpness 3.0 \
    --candidate_image_mode baseline \
    --device cuda:1 \
    --save_dir "${save_dir}"
  echo "[$(date '+%F %T')] done AA-CLIP ${preset}"
}

wait_for_pid "${WAIT_PID}"

run_aaclip visa2btad -0.5 neurips2026/results/aaclip_prescore_segtoken_vitbplus_visa2btad_img518_full_neg05_20260427
run_aaclip mvtec2visa -1.0,-0.75,-0.5,-0.25,0.25,0.5 neurips2026/results/aaclip_prescore_segtoken_vitbplus_mvtec2visa_img518_alpha_sweep_20260427

echo "[$(date '+%F %T')] AA-CLIP extra coverage finished"
