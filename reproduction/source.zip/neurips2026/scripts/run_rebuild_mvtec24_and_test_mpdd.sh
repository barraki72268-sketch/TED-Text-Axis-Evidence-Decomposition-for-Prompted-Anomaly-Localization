#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
cd "$ROOT"

PY="/mnt/data/envs/patchcore-conda/bin/python"
CKPT="neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth"
BANK_CACHE="neurips2026/results/bank_cache/anomalyclip_mvtec_full_epoch15_multiscale_visa_f24.pt"

"$PY" neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py \
  --device cuda:0 \
  --checkpoint_path "$CKPT" \
  --heldout_class none \
  --source_root /mnt/data/pilab-kingjinyoung/ijepa/data/mvtec \
  --source_dataset mvtec \
  --features_list 24 \
  --bank_cache_path "$BANK_CACHE" \
  --refresh_bank_cache \
  --prepare_bank_only

"$PY" neurips2026/scripts/official_parallel_test.py \
  --device cuda:0 \
  --checkpoint_path "$CKPT" \
  --source_root /mnt/data/pilab-kingjinyoung/ijepa/data/mvtec \
  --source_dataset mvtec \
  --target_root /mnt/data/MPDD \
  --target_dataset mpdd \
  --target_mode test \
  --features_list 24 \
  --feature_map_layer 0 \
  --bank_cache_path "$BANK_CACHE" \
  --save_dir neurips2026/results/official_parallel_test_mvtec2mpdd_epoch15_f24
