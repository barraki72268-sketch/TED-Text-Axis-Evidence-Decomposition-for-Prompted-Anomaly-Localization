from __future__ import annotations

import argparse
import copy
import csv
import json
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD
from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import AlphaSpaceKinematicRefiner, AlphaSpaceObjective
from neurips2026.scripts.probe_realiad_alpha_refiner_winclip_dryrun import (
    _audit_cache_path,
    _load_cached_json,
    _trainable_cache_path,
    audit_dataset,
    build_mask_transform,
    collect_records_by_label,
    cosine_decay_lr,
    dilate_mask_tensor,
    filter_trainable_anomalies,
    flatten_records,
    load_mask_tensor,
    sample_balanced_batch,
    set_seed,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--target_layers", nargs="+", type=int, default=[6, 9])
    parser.add_argument("--init_refiner_ckpts", nargs="*", default=[])
    parser.add_argument("--freeze_layers", nargs="*", type=int, default=[])
    parser.add_argument("--detach_between_seams", action="store_true")
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--hidden_dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--basis_rank", type=int, default=4)
    parser.add_argument("--gate_temperature", type=float, default=0.25)
    parser.add_argument("--lambda_contrast", type=float, default=1.0)
    parser.add_argument("--lambda_sem", type=float, default=1.0)
    parser.add_argument("--lambda_orth", type=float, default=0.01)
    parser.add_argument("--contrastive_temp", type=float, default=0.1)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--steps", type=int, default=40)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--probe_normals", type=int, default=8)
    parser.add_argument("--probe_anomalies", type=int, default=8)
    parser.add_argument("--probe_sem_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_target", type=float, default=0.35)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--audit_verify_limit", type=int, default=4000)
    parser.add_argument("--mask_audit_limit", type=int, default=4000)
    parser.add_argument("--reuse_dataset_cache", action="store_true", default=True)
    parser.add_argument("--lr_decay_start", type=int, default=20)
    parser.add_argument("--lr_min_ratio", type=float, default=0.1)
    parser.add_argument("--eval_interval", type=int, default=10)
    parser.add_argument("--checkpoint_steps", nargs="*", type=int, default=[])
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--output_tag", type=str, default="realiad_winclip_backbone_alpha_multiseam")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


class MultiSeamRefiner(nn.Module):
    def __init__(
        self,
        feature_dim: int,
        target_layers: list[int],
        kernel_size: int,
        topk_ratio: float,
        hidden_dim: int,
        dropout: float,
        basis_rank: int,
        gate_temperature: float,
    ) -> None:
        super().__init__()
        self.target_layers = [int(x) for x in target_layers]
        self.refiners = nn.ModuleDict(
            {
                str(layer): AlphaSpaceKinematicRefiner(
                    feature_dim=feature_dim,
                    kernel_size=kernel_size,
                    topk_ratio=topk_ratio,
                    hidden_dim=hidden_dim,
                    dropout=dropout,
                    basis_rank=basis_rank,
                    gate_temperature=gate_temperature,
                )
                for layer in self.target_layers
            }
        )

    def forward_layer(
        self,
        layer: int,
        tokens: torch.Tensor,
        semantic_basis: torch.Tensor,
        spatial_shape: tuple[int, int],
    ):
        return self.refiners[str(int(layer))](tokens, semantic_basis=semantic_basis, spatial_shape=spatial_shape)


def parse_init_ckpts(items: list[str]) -> dict[int, str]:
    mapping: dict[int, str] = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"Invalid --init_refiner_ckpts item: {item}. Expected <layer>=<path>.")
        key, path = item.split("=", 1)
        mapping[int(key)] = path
    return mapping


def load_initial_refiners(model: MultiSeamRefiner, ckpt_map: dict[int, str]) -> None:
    for layer, path in ckpt_map.items():
        key = str(int(layer))
        if key not in model.refiners:
            continue
        payload = torch.load(path, map_location="cpu")
        state_dict = payload.get("model_state_dict", payload)
        model.refiners[key].load_state_dict(state_dict, strict=True)


def freeze_refiners(model: MultiSeamRefiner, freeze_layers: list[int]) -> None:
    freeze_set = {str(int(layer)) for layer in freeze_layers}
    for key, refiner in model.refiners.items():
        requires_grad = key not in freeze_set
        refiner.train(requires_grad)
        for param in refiner.parameters():
            param.requires_grad = requires_grad


def build_checkpoint_payload(
    model: MultiSeamRefiner,
    *,
    feature_dim: int,
    args: argparse.Namespace,
) -> dict:
    return {
        "model_state_dict": copy.deepcopy(model.state_dict()),
        "refiner_config": {
            "feature_dim": feature_dim,
            "kernel_size": args.kernel_size,
            "topk_ratio": args.topk_ratio,
            "hidden_dim": args.hidden_dim,
            "dropout": args.dropout,
            "basis_rank": args.basis_rank,
            "gate_temperature": args.gate_temperature,
            "target_layers": args.target_layers,
            "route": "raw_backbone",
        },
        "target_layers": args.target_layers,
        "route": "raw_backbone",
    }


def build_batch_tensors_backbone(
    batch: list[dict],
    backbone,
    mask_transform,
    semantic_basis_by_class: dict[str, torch.Tensor],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, list[int]]:
    images = torch.stack(
        [backbone.transform_pil(Image.open(rec["image_path"]).convert("RGB")) for rec in batch],
        dim=0,
    ).to(device)
    masks = []
    basis = []
    labels = []
    for rec in batch:
        if int(rec["label"]) == 1:
            mask = dilate_mask_tensor(load_mask_tensor(rec["mask_path"], mask_transform), args.mask_dilate_kernel)
        else:
            mask = torch.zeros(1, args.img_cropsize, args.img_cropsize)
        masks.append(mask)
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = backbone.build_prompt_token_basis(rec["class_name"])
        basis.append(semantic_basis_by_class[rec["class_name"]])
        labels.append(int(rec["label"]))
    return images, torch.stack(masks, dim=0).to(device), torch.stack(basis, dim=0).to(device), labels


def extract_backbone_groups_multiseam(
    backbone,
    images: torch.Tensor,
    patch_mask_flat: torch.Tensor,
    basis_t: torch.Tensor,
    target_layers: list[int],
    model: MultiSeamRefiner,
    detach_between_seams: bool = False,
) -> dict[int, list[dict[str, torch.Tensor | int]]]:
    target_layers = sorted(int(x) for x in target_layers)
    groups: dict[int, list[dict[str, torch.Tensor | int]]] = {layer: [] for layer in target_layers}
    side = backbone.grid_size[0]
    flat = backbone.prepare_sequence(images)

    def layer_callback(block_idx: int, seq: torch.Tensor) -> torch.Tensor:
        if block_idx not in groups:
            return seq
        flat_nld = seq.permute(1, 0, 2)
        raw_patch = flat_nld[:, 1:, :].float()
        out = model.forward_layer(block_idx, raw_patch, semantic_basis=basis_t, spatial_shape=(side, side))
        refined_patch = out.refined.to(dtype=flat_nld.dtype)
        forward_patch = refined_patch.detach() if detach_between_seams else refined_patch
        groups[block_idx].append(
            {
                "raw_tokens": raw_patch,
                "refined_tokens": out.refined,
                "alpha": out.alpha,
                "delta": out.delta,
                "gate": out.gate,
                "patch_mask": patch_mask_flat,
                "basis_group": basis_t,
                "side": side,
            }
        )
        return torch.cat([flat_nld[:, :1, :], forward_patch], dim=1).permute(1, 0, 2)

    backbone.run_blocks(
        flat,
        start_layer=1,
        end_layer=max(target_layers),
        layer_callback=layer_callback,
    )
    return groups


def aggregate_probe_metrics(
    *,
    model: MultiSeamRefiner,
    objective: AlphaSpaceObjective,
    backbone,
    probe_batch: list[dict],
    semantic_basis_by_class: dict[str, torch.Tensor],
    mask_transform,
    args: argparse.Namespace,
    device: torch.device,
) -> dict[str, float]:
    images, masks_t, basis_t, _ = build_batch_tensors_backbone(
        probe_batch, backbone, mask_transform, semantic_basis_by_class, args, device
    )
    patch_mask_flat = (
        F.interpolate(masks_t.float(), size=backbone.grid_size, mode="nearest")[:, 0].reshape(len(probe_batch), -1)
        > 0.5
    )
    groups_by_layer = extract_backbone_groups_multiseam(
        backbone,
        images,
        patch_mask_flat,
        basis_t,
        args.target_layers,
        model,
        args.detach_between_seams,
    )

    probe_gap_acc = 0.0
    probe_sem_acc = 0.0
    probe_anom_acc = 0.0
    layer_count = 0
    metrics: dict[str, float] = {}
    with torch.no_grad():
        for layer in args.target_layers:
            layer_groups = groups_by_layer[int(layer)]
            total_units = sum(int(group["raw_tokens"].shape[0]) for group in layer_groups)
            alpha_n_acc = 0.0
            alpha_a_acc = 0.0
            sem_acc = 0.0
            delta_acc = 0.0
            gate_peak_acc = 0.0
            weight_acc = 0.0
            for group in layer_groups:
                loss_stats = objective(
                    raw_features=group["raw_tokens"],
                    refined_features=group["refined_tokens"],
                    alpha=group["alpha"],
                    anomaly_mask=group["patch_mask"],
                    semantic_basis=group["basis_group"],
                    spatial_shape=(int(group["side"]), int(group["side"])),
                    basis_bank=model.refiners[str(int(layer))].transport_basis,
                )
                weight = float(group["raw_tokens"].shape[0]) / float(max(total_units, 1))
                alpha_n_acc += weight * float(loss_stats["alpha_normal_mean"].item())
                alpha_a_acc += weight * float(loss_stats["alpha_anomaly_mean"].item())
                sem_acc += weight * float(loss_stats["loss_sem"].item())
                delta_acc += weight * float(group["delta"].float().norm(dim=-1).mean().item())
                gate_peak_acc += weight * float(group["gate"].float().amax(dim=-1).mean().item())
                weight_acc += weight

            alpha_n = alpha_n_acc / max(weight_acc, 1e-8)
            alpha_a = alpha_a_acc / max(weight_acc, 1e-8)
            sem = sem_acc / max(weight_acc, 1e-8)
            delta_norm = delta_acc / max(weight_acc, 1e-8)
            gate_peak = gate_peak_acc / max(weight_acc, 1e-8)
            gap = alpha_n - alpha_a
            metrics[f"probe_alpha_gap_l{layer}"] = float(gap)
            metrics[f"probe_alpha_normal_l{layer}"] = float(alpha_n)
            metrics[f"probe_alpha_anomaly_l{layer}"] = float(alpha_a)
            metrics[f"probe_sem_l{layer}"] = float(sem)
            metrics[f"probe_delta_norm_l{layer}"] = float(delta_norm)
            metrics[f"probe_gate_peak_l{layer}"] = float(gate_peak)
            probe_gap_acc += gap
            probe_sem_acc += sem
            probe_anom_acc += max(0.0, alpha_a - args.probe_alphaa_target)
            layer_count += 1

    mean_gap = probe_gap_acc / max(layer_count, 1)
    mean_sem = probe_sem_acc / max(layer_count, 1)
    mean_anom_pen = probe_anom_acc / max(layer_count, 1)
    metrics["probe_alpha_gap_mean"] = float(mean_gap)
    metrics["probe_sem_mean"] = float(mean_sem)
    metrics["probe_score"] = float(
        mean_gap - args.probe_sem_penalty * mean_sem - args.probe_alphaa_penalty * mean_anom_pen
    )
    return metrics


def main() -> None:
    args = parse_args()
    args.target_layers = [int(x) for x in args.target_layers]
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    backbone_tag = args.backbone.replace("-", "").replace("+", "plus").lower()
    layer_tag = "-".join(str(x) for x in args.target_layers)
    stem = f"{args.output_tag}_{backbone_tag}_layers{layer_tag}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    ckpt_path = output_dir / f"{stem}_best.pt"
    png_path = output_dir / f"{stem}_curves.png"
    checkpoint_steps = sorted({int(x) for x in args.checkpoint_steps if int(x) >= 1})
    checkpoint_dir = output_dir / f"{stem}_checkpoints"
    if checkpoint_steps:
        checkpoint_dir.mkdir(parents=True, exist_ok=True)

    mask_transform = build_mask_transform(args.img_cropsize)
    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.img_resize,
        crp_size=args.img_cropsize,
        msk_size=args.img_cropsize,
        msk_crp_size=args.img_cropsize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    records = flatten_records(dataset)
    normal_records, anomaly_records = collect_records_by_label(records)
    records_by_image_path = {rec["image_path"]: rec for rec in records}

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    for layer in args.target_layers:
        if not (1 <= layer <= backbone.num_layers):
            raise ValueError(f"target_layer={layer} outside [1, {backbone.num_layers}] for backbone {args.backbone}.")
    token_side = backbone.grid_size[0]

    audit_cache_path = _audit_cache_path(output_dir, args)
    audit = _load_cached_json(audit_cache_path) if args.reuse_dataset_cache else None
    if audit is None:
        audit = audit_dataset(
            records=records,
            mask_transform=mask_transform,
            image_size=args.img_cropsize,
            token_side=token_side,
            verify_limit=args.audit_verify_limit,
            mask_audit_limit=args.mask_audit_limit,
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with audit_cache_path.open("w") as f:
            json.dump(audit, f, indent=2)

    shared_trainable_cache_path = _trainable_cache_path(output_dir, args, token_side)
    trainable_anomalies = None
    trainable_meta = None
    if args.reuse_dataset_cache:
        cached_trainable = _load_cached_json(shared_trainable_cache_path)
        if cached_trainable is not None:
            cached_records = []
            for rec in cached_trainable.get("records", []):
                current = records_by_image_path.get(rec["image_path"])
                if current is not None:
                    cached_records.append(current)
            if cached_records:
                trainable_anomalies = cached_records
                trainable_meta = cached_trainable.get("pool_meta", {})
    if trainable_anomalies is None or trainable_meta is None:
        trainable_anomalies, trainable_meta = filter_trainable_anomalies(
            anomaly_records=anomaly_records,
            mask_transform=mask_transform,
            token_side=token_side,
            scan_limit=max(args.mask_audit_limit, args.batch_size * args.steps * 4),
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with shared_trainable_cache_path.open("w") as f:
            json.dump(
                {
                    "config": {
                        "mask_dilate_kernel": args.mask_dilate_kernel,
                        "token_side": token_side,
                        "scan_limit": max(args.mask_audit_limit, args.batch_size * args.steps * 4),
                    },
                    "pool_meta": trainable_meta,
                    "records": [
                        {
                            "image_path": rec["image_path"],
                            "mask_path": rec["mask_path"],
                            "class_name": rec["class_name"],
                            "anomaly_type": rec["anomaly_type"],
                            "sample_id": rec["sample_id"],
                        }
                        for rec in trainable_anomalies
                    ],
                },
                f,
                indent=2,
            )
    if not trainable_anomalies:
        raise RuntimeError("No trainable anomaly samples survived token-grid downsampling.")

    semantic_basis_by_class: dict[str, torch.Tensor] = {}
    feature_dim = backbone.token_dim
    model = MultiSeamRefiner(
        feature_dim=feature_dim,
        target_layers=args.target_layers,
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
        basis_rank=args.basis_rank,
        gate_temperature=args.gate_temperature,
    ).to(device)
    init_ckpt_map = parse_init_ckpts(args.init_refiner_ckpts)
    if init_ckpt_map:
        load_initial_refiners(model, init_ckpt_map)
    freeze_refiners(model, args.freeze_layers)
    objective = AlphaSpaceObjective(
        lambda_contrast=args.lambda_contrast,
        lambda_sem=args.lambda_sem,
        lambda_orth=args.lambda_orth,
        contrastive_temp=args.contrastive_temp,
    ).to(device)
    trainable_params = [param for param in model.parameters() if param.requires_grad]
    if not trainable_params:
        raise RuntimeError("No trainable refiner parameters remain after --freeze_layers.")
    optimizer = torch.optim.AdamW(trainable_params, lr=args.lr, weight_decay=args.weight_decay)

    rng = random.Random(args.seed)
    probe_rng = random.Random(args.seed + 101)
    probe_batch = probe_rng.sample(normal_records, min(len(normal_records), args.probe_normals))
    probe_batch += probe_rng.sample(trainable_anomalies, min(len(trainable_anomalies), args.probe_anomalies))
    probe_rng.shuffle(probe_batch)
    for rec in probe_batch:
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = backbone.build_prompt_token_basis(rec["class_name"])

    best_probe_score = -float("inf")
    best_probe_step = -1
    step_rows = []

    for step in range(1, args.steps + 1):
        tic = time.time()
        current_lr = cosine_decay_lr(
            step=step,
            total_steps=args.steps,
            base_lr=args.lr,
            start_step=max(1, args.lr_decay_start),
            min_ratio=args.lr_min_ratio,
        )
        for group in optimizer.param_groups:
            group["lr"] = current_lr

        batch = sample_balanced_batch(normal_records, trainable_anomalies, args.batch_size, rng)
        images, masks_t, basis_t, _ = build_batch_tensors_backbone(
            batch, backbone, mask_transform, semantic_basis_by_class, args, device
        )
        patch_mask_flat = (
            F.interpolate(masks_t.float(), size=backbone.grid_size, mode="nearest")[:, 0].reshape(len(batch), -1) > 0.5
        )
        groups_by_layer = extract_backbone_groups_multiseam(
            backbone,
            images,
            patch_mask_flat,
            basis_t,
            args.target_layers,
            model,
            args.detach_between_seams,
        )

        optimizer.zero_grad()
        total_units = sum(
            int(group["raw_tokens"].shape[0])
            for layer in args.target_layers
            for group in groups_by_layer[int(layer)]
        )
        total_loss = 0.0
        row: dict[str, float] = {"step": float(step), "lr_current": float(current_lr)}
        gap_acc = 0.0
        layer_count = 0

        for layer_idx, layer in enumerate(args.target_layers):
            layer_groups = groups_by_layer[int(layer)]
            weight_acc = 0.0
            alpha_n_acc = 0.0
            alpha_a_acc = 0.0
            sem_acc = 0.0
            contrast_acc = 0.0
            orth_acc = 0.0
            delta_acc = 0.0
            gate_peak_acc = 0.0
            for group_idx, group in enumerate(layer_groups):
                loss_stats = objective(
                    raw_features=group["raw_tokens"],
                    refined_features=group["refined_tokens"],
                    alpha=group["alpha"],
                    anomaly_mask=group["patch_mask"],
                    semantic_basis=group["basis_group"],
                    spatial_shape=(int(group["side"]), int(group["side"])),
                    basis_bank=model.refiners[str(int(layer))].transport_basis,
                )
                weight = float(group["raw_tokens"].shape[0]) / float(max(total_units, 1))
                scaled = loss_stats["loss"] * weight
                retain_graph = not (layer_idx == len(args.target_layers) - 1 and group_idx == len(layer_groups) - 1)
                scaled.backward(retain_graph=retain_graph)
                total_loss += float(scaled.detach().item())
                alpha_n_acc += weight * float(loss_stats["alpha_normal_mean"].item())
                alpha_a_acc += weight * float(loss_stats["alpha_anomaly_mean"].item())
                sem_acc += weight * float(loss_stats["loss_sem"].item())
                contrast_acc += weight * float(loss_stats["loss_contrast"].item())
                orth_acc += weight * float(loss_stats["loss_orth"].item())
                delta_acc += weight * float(group["delta"].float().norm(dim=-1).mean().item())
                gate_peak_acc += weight * float(group["gate"].float().amax(dim=-1).mean().item())
                weight_acc += weight

            alpha_n = alpha_n_acc / max(weight_acc, 1e-8)
            alpha_a = alpha_a_acc / max(weight_acc, 1e-8)
            sem = sem_acc / max(weight_acc, 1e-8)
            contrast = contrast_acc / max(weight_acc, 1e-8)
            orth = orth_acc / max(weight_acc, 1e-8)
            delta_norm = delta_acc / max(weight_acc, 1e-8)
            gate_peak = gate_peak_acc / max(weight_acc, 1e-8)
            gap = alpha_n - alpha_a
            row[f"alpha_gap_l{layer}"] = float(gap)
            row[f"alpha_normal_l{layer}"] = float(alpha_n)
            row[f"alpha_anomaly_l{layer}"] = float(alpha_a)
            row[f"loss_sem_l{layer}"] = float(sem)
            row[f"loss_contrast_l{layer}"] = float(contrast)
            row[f"loss_orth_l{layer}"] = float(orth)
            row[f"delta_norm_l{layer}"] = float(delta_norm)
            row[f"gate_peak_l{layer}"] = float(gate_peak)
            gap_acc += gap
            layer_count += 1

        optimizer.step()
        row["loss"] = float(total_loss)
        row["alpha_gap_mean"] = float(gap_acc / max(layer_count, 1))

        if step % args.eval_interval == 0 or step == 1 or step == args.steps:
            probe_metrics = aggregate_probe_metrics(
                model=model,
                objective=objective,
                backbone=backbone,
                probe_batch=probe_batch,
                semantic_basis_by_class=semantic_basis_by_class,
                mask_transform=mask_transform,
                args=args,
                device=device,
            )
            row.update(probe_metrics)
            if probe_metrics["probe_score"] > best_probe_score:
                best_probe_score = probe_metrics["probe_score"]
                best_probe_step = step
                torch.save(build_checkpoint_payload(model, feature_dim=feature_dim, args=args), ckpt_path)

        if step in checkpoint_steps:
            torch.save(
                build_checkpoint_payload(model, feature_dim=feature_dim, args=args),
                checkpoint_dir / f"step_{step}.pt",
            )

        step_rows.append(row)
        layer_bits = " ".join(
            f"L{layer}={row.get(f'alpha_gap_l{layer}', float('nan')):.4f}" for layer in args.target_layers
        )
        print(
            f"[step {step}] loss={row['loss']:.4f} gap_mean={row['alpha_gap_mean']:.4f} "
            f"{layer_bits} lr={row['lr_current']:.5f} t={time.time() - tic:.2f}s",
            flush=True,
        )

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(step_rows[0].keys()))
        writer.writeheader()
        writer.writerows(step_rows)

    summary = {
        "config": vars(args),
        "route": "raw_backbone",
        "dataset_audit": audit,
        "trainable_anomaly_pool": trainable_meta,
        "best_probe_step": best_probe_step,
        "best_probe_score": best_probe_score,
        "checkpoint_path": str(ckpt_path),
        "checkpoint_steps": checkpoint_steps,
        "checkpoint_dir": str(checkpoint_dir) if checkpoint_steps else "",
        "final_step": step_rows[-1],
    }
    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    steps = [row["step"] for row in step_rows]
    gap_mean = [row["alpha_gap_mean"] for row in step_rows]
    probe_gap = [row.get("probe_alpha_gap_mean", float("nan")) for row in step_rows]
    fig, ax = plt.subplots(1, 1, figsize=(7, 4))
    ax.plot(steps, gap_mean, label="train gap mean")
    ax.plot(steps, probe_gap, label="probe gap mean")
    ax.set_xlabel("step")
    ax.set_ylabel("alpha gap")
    ax.legend()
    ax.grid(True, alpha=0.2)
    fig.tight_layout()
    fig.savefig(png_path, dpi=200)

    print(f"saved_ckpt={ckpt_path}")
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_png={png_path}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
