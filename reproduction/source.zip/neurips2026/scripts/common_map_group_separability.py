from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import label


def top_fraction_mask(arr: np.ndarray, frac: float) -> np.ndarray:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    mask = np.zeros_like(flat, dtype=bool)
    mask[idx] = True
    return mask.reshape(arr.shape)


def topk_mean_masked(arr: np.ndarray, mask: np.ndarray, frac: float) -> float:
    vals = arr[mask]
    if vals.size == 0:
        return float("nan")
    k = max(1, int(vals.size * frac))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def best_component_stats(
    arr: np.ndarray,
    binary_mask: np.ndarray,
    gt_mask: np.ndarray | None = None,
    overlap_mode: str = "any",
) -> dict[str, float] | None:
    labeled, num = label(binary_mask.astype(np.uint8), structure=np.ones((3, 3), dtype=np.uint8))
    best = None
    for comp_idx in range(1, num + 1):
        comp = labeled == comp_idx
        if gt_mask is not None:
            overlaps = bool(np.any(comp & gt_mask))
            if overlap_mode == "inside" and not overlaps:
                continue
            if overlap_mode == "outside" and overlaps:
                continue
        vals = arr[comp]
        if vals.size == 0:
            continue
        stats = {
            "peak": float(vals.max()),
            "mean": float(vals.mean()),
            "area": float(vals.size),
        }
        if best is None or stats["peak"] > best["peak"]:
            best = stats
    return best


def score_stats(arr: np.ndarray) -> dict[str, float]:
    if arr.size == 0:
        return {
            "count": 0,
            "mean": 0.0,
            "std": 0.0,
            "p05": 0.0,
            "p25": 0.0,
            "p50": 0.0,
            "p75": 0.0,
            "p95": 0.0,
        }
    return {
        "count": int(arr.size),
        "mean": float(arr.mean()),
        "std": float(arr.std()),
        "p05": float(np.percentile(arr, 5)),
        "p25": float(np.percentile(arr, 25)),
        "p50": float(np.percentile(arr, 50)),
        "p75": float(np.percentile(arr, 75)),
        "p95": float(np.percentile(arr, 95)),
    }


def sample_array(arr: np.ndarray, max_points: int, seed: int = 0) -> np.ndarray:
    if arr.size <= max_points:
        return arr
    rng = np.random.default_rng(seed)
    idx = rng.choice(arr.size, size=max_points, replace=False)
    return arr[idx]


def auc_from_scores(pos: np.ndarray, neg: np.ndarray, max_points: int = 100000) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    pos = sample_array(pos, max_points=max_points, seed=0)
    neg = sample_array(neg, max_points=max_points, seed=1)
    scores = np.concatenate([pos, neg], axis=0)
    labels = np.concatenate([np.ones_like(pos, dtype=np.int64), np.zeros_like(neg, dtype=np.int64)], axis=0)
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(scores) + 1, dtype=np.float64)
    pos_ranks = ranks[labels == 1]
    n_pos = len(pos)
    n_neg = len(neg)
    return float((pos_ranks.sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def summarize_groups(
    groups: dict[str, np.ndarray],
    max_summary_points: int = 200000,
    max_auc_points: int = 100000,
    pairs: list[tuple[str, str]] | None = None,
) -> dict:
    groups = {k: sample_array(v, max_summary_points, seed=i) for i, (k, v) in enumerate(groups.items())}
    summary = {"groups": {k: score_stats(v) for k, v in groups.items()}, "pairwise_auc": {}}
    if pairs is None:
        pairs = [
            ("true_defect", "hard_fp"),
            ("true_defect", "normal"),
            ("hard_fp", "normal"),
            ("true_defect", "outside"),
            ("hard_fp", "outside"),
        ]
    for pos_key, neg_key in pairs:
        if pos_key in groups and neg_key in groups:
            summary["pairwise_auc"][f"{pos_key}_vs_{neg_key}"] = auc_from_scores(
                groups[pos_key], groups[neg_key], max_points=max_auc_points
            )
    return summary


def plot_hist(groups: dict[str, np.ndarray], save_path: Path, title: str) -> None:
    colors = {
        "normal": "#1f77b4",
        "hard_fp": "#ff7f0e",
        "true_defect": "#2ca02c",
        "outside": "#d62728",
    }
    labels = {
        "normal": "Normal",
        "hard_fp": "Hard FP",
        "true_defect": "True Defect",
        "outside": "Outside",
    }
    plt.figure(figsize=(9, 5))
    all_vals = [v for v in groups.values() if v.size > 0]
    if all_vals:
        lo = float(min(v.min() for v in all_vals))
        hi = float(max(v.max() for v in all_vals))
        if np.isclose(lo, hi):
            hi = lo + 1e-6
        bins = np.linspace(lo, hi, 120)
    else:
        bins = np.linspace(0.0, 1.0, 120)
    ordered_keys = list(groups.keys())
    for key in ordered_keys:
        vals = groups.get(key)
        if vals is None or vals.size == 0:
            continue
        color = colors.get(key, None)
        label = labels.get(key, key.replace("_", " ").title())
        plt.hist(
            vals,
            bins=bins,
            density=True,
            histtype="step",
            linewidth=2.0,
            color=color,
            label=f"{label} | mean={vals.mean():.3f}",
        )
    plt.xlabel("Anomaly Score")
    plt.ylabel("Density")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    save_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=180)
    plt.close()


def save_summary(summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
