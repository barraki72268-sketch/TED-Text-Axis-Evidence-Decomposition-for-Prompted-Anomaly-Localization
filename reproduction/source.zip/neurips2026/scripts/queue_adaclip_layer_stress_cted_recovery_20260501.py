#!/usr/bin/env python3
"""Queue AdaCLIP layer-recipe stress runs with C-TED recovery.

This is intentionally narrow: it only covers the layer-stress ablation cases
needed to show that TED is not just diagnosing recipe fragility, but can recover
the local ranking under the same stressed recipe.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026/scripts/official_parallel_test_adaclip.py"
OUT_ROOT = ROOT / "neurips2026/results/adaclip_layer_stress_cted_recovery_20260501"
LOG_ROOT = OUT_ROOT / "logs"


PRESETS = {
    "visa2mvtec": {
        "source_root": ROOT / "neurips2026/data/VisA_pytorch_official/1cls",
        "source_dataset": "visa",
        "target_root": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
        "target_dataset": "mvtec",
        "checkpoint_path": ROOT / "neurips2026/AdaCLIP/ckpt/pretrained_visa_clinicdb.pth",
        "bank_cache_path": ROOT / "neurips2026/results/bank_cache/maintable_adaclip_vitl336_visa_seed0.pt",
    },
    "mvtec2btad": {
        "source_root": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
        "source_dataset": "mvtec",
        "target_root": ROOT / "neurips2026/data/BTAD_official",
        "target_dataset": "btad",
        "checkpoint_path": ROOT / "neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth",
        "bank_cache_path": ROOT / "neurips2026/results/bank_cache/maintable_adaclip_vitl336_mvtec_seed0.pt",
    },
    "mvtec2visa": {
        "source_root": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
        "source_dataset": "mvtec",
        "target_root": ROOT / "neurips2026/data/VisA_pytorch_official/1cls",
        "target_dataset": "visa",
        "checkpoint_path": ROOT / "neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth",
        "bank_cache_path": ROOT / "neurips2026/results/bank_cache/maintable_adaclip_vitl336_mvtec_seed0.pt",
    },
    "mvtec2mpdd": {
        "source_root": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
        "source_dataset": "mvtec",
        "target_root": Path("/mnt/data/MPDD"),
        "target_dataset": "mpdd",
        "checkpoint_path": ROOT / "neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth",
        "bank_cache_path": ROOT / "neurips2026/results/bank_cache/maintable_adaclip_vitl336_mvtec_seed0.pt",
    },
}

RECIPES = ("all4", "earlylate", "last")


def build_cmd(preset_name: str, recipe: str, device: str) -> list[str]:
    cfg = PRESETS[preset_name]
    save_dir = OUT_ROOT / f"{preset_name}_{recipe}"
    return [
        str(PY),
        "-u",
        str(SCRIPT),
        "--source_root",
        str(cfg["source_root"]),
        "--source_dataset",
        str(cfg["source_dataset"]),
        "--target_root",
        str(cfg["target_root"]),
        "--target_dataset",
        str(cfg["target_dataset"]),
        "--checkpoint_path",
        str(cfg["checkpoint_path"]),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(cfg["bank_cache_path"]),
        "--seed",
        "0",
        "--device",
        device,
        # AdaCLIP dynamic text prompts are image-batch conditioned, while the
        # text branch expands class prompt ensembles. This host is only safe
        # with batch size 1, matching the main-table AdaCLIP queue.
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "4",
        "--layer_recipe",
        recipe,
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_subspace_rank",
        "8",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--calib_lambda",
        "0.3",
        "--calib_eta_max",
        "1.0",
        "--scoring_mode",
        "logit_gate_posneg",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
    ]


def main() -> int:
    device = sys.argv[1] if len(sys.argv) > 1 else "cuda:1"
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)

    for preset_name in PRESETS:
        for recipe in RECIPES:
            save_dir = OUT_ROOT / f"{preset_name}_{recipe}"
            summary = save_dir / "summary.json"
            if summary.exists():
                print(f"[skip] {summary}", flush=True)
                continue

            log_path = LOG_ROOT / f"{preset_name}_{recipe}.log"
            cmd = build_cmd(preset_name, recipe, device)
            print(f"[start] {preset_name} {recipe} -> {save_dir}", flush=True)
            with log_path.open("w") as log:
                proc = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            if proc.returncode != 0:
                print(f"[fail] {preset_name} {recipe}; see {log_path}", flush=True)
                return proc.returncode
            print(f"[done] {preset_name} {recipe}", flush=True)

    print("[done] AdaCLIP layer-stress C-TED recovery queue", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
