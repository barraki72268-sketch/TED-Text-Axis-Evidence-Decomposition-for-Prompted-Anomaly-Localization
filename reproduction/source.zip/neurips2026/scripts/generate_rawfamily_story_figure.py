from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"


def load_metrics(save_root: Path) -> tuple[list[str], list[str], dict[tuple[str, str], dict]]:
    manifest = json.loads((save_root / "manifest.json").read_text())
    model_keys = list(manifest.keys())
    rows = {}
    preset_order = []
    for model_key in model_keys:
        payload = json.loads(Path(manifest[model_key]["metrics_json"]).read_text())
        for row in payload["rows"]:
            preset = row["preset"]
            if preset not in preset_order:
                preset_order.append(preset)
            rows[(model_key, preset)] = row
    return model_keys, preset_order, rows


def matrix(model_keys: list[str], presets: list[str], rows: dict, metric: str) -> np.ndarray:
    out = np.zeros((len(model_keys), len(presets)), dtype=np.float32)
    for i, mk in enumerate(model_keys):
        for j, pr in enumerate(presets):
            out[i, j] = float(rows[(mk, pr)][metric])
    return out


def main() -> None:
    parser = argparse.ArgumentParser("Generate raw-family GT-free story figure")
    parser.add_argument(
        "--save_root",
        type=str,
        default=str(RESULTS / "rawfamily_gtfree_entanglement"),
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=str(RESULTS / "rawfamily_gtfree_story_figure"),
    )
    args = parser.parse_args()

    save_root = Path(args.save_root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    model_keys, presets, rows = load_metrics(save_root)
    display_names = [rows[(mk, presets[0])]["model_label"] for mk in model_keys]
    preset_labels = [rows[(model_keys[0], pr)]["preset_label"] for pr in presets]

    auc_gain = matrix(model_keys, presets, rows, "auc_gain")
    d_raw = matrix(model_keys, presets, rows, "raw_cohens_d")
    d_par = matrix(model_keys, presets, rows, "parallel_cohens_d")
    d_gain = d_par - d_raw

    fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.6), constrained_layout=True)

    # Panel 1: model-average AUC gain
    ax = axes[0]
    avg_gain = auc_gain.mean(axis=1)
    y = np.arange(len(model_keys))
    ax.barh(y, avg_gain, color="#1B9E77", alpha=0.9)
    ax.set_yticks(y, display_names)
    ax.set_xlabel("Mean AUC Gain")
    ax.set_title("Raw-Family Separation Gain")
    ax.grid(axis="x", alpha=0.15)
    for i, v in enumerate(avg_gain):
        ax.text(v + 0.01, i, f"{v:+.2f}", va="center", fontsize=9)

    # Panel 2: AUC gain heatmap
    ax = axes[1]
    im = ax.imshow(auc_gain, cmap="RdYlGn", aspect="auto", vmin=np.min(auc_gain), vmax=np.max(auc_gain))
    ax.set_xticks(np.arange(len(presets)), preset_labels, rotation=20, ha="right")
    ax.set_yticks(np.arange(len(model_keys)), display_names)
    ax.set_title("AUC Gain by Preset")
    for i in range(len(model_keys)):
        for j in range(len(presets)):
            ax.text(j, i, f"{auc_gain[i, j]:+.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)

    # Panel 3: Cohen's d gain heatmap
    ax = axes[2]
    vmax = max(abs(np.min(d_gain)), abs(np.max(d_gain)))
    im = ax.imshow(d_gain, cmap="RdBu_r", aspect="auto", vmin=-vmax, vmax=vmax)
    ax.set_xticks(np.arange(len(presets)), preset_labels, rotation=20, ha="right")
    ax.set_yticks(np.arange(len(model_keys)), display_names)
    ax.set_title("Effect-Size Gain (Δ d)")
    for i in range(len(model_keys)):
        for j in range(len(presets)):
            ax.text(j, i, f"{d_gain[i, j]:+.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)

    fig.suptitle("GT-free Hard-FP / Anomaly Entanglement Across Raw Backbones", fontsize=13)
    fig.savefig(output_dir / "rawfamily_story.png", dpi=220, bbox_inches="tight")
    fig.savefig(output_dir / "rawfamily_story.pdf", bbox_inches="tight")

    summary = {
        "models": display_names,
        "presets": preset_labels,
        "avg_auc_gain": {display_names[i]: float(avg_gain[i]) for i in range(len(display_names))},
    }
    (output_dir / "rawfamily_story.json").write_text(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
