#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

CSV_PATH = OUT / "adapted_host_b_t_c_records_20260502.csv"
MVTEC2_ROOT = ROOT / "neurips2026" / "results" / "adapted_hosts_mvtec2_20260503"

HOSTS = ("AA-CLIP", "FAPrompt", "AdaCLIP", "AdaptCLIP")
TARGETS = ("MVTec", "VisA", "MPDD", "BTAD")
TARGET_PANEL_TARGETS = ("MVTec", "VisA", "MPDD", "BTAD", "MVTec2*")
PIXEL_METRICS = ("p_auc", "p_pro", "p_ap")
ALL_METRICS = ("i_auc", "p_auc", "p_pro", "p_ap")

HOST_LABELS = {
    "AA-CLIP": "AA",
    "FAPrompt": "FA",
    "AdaCLIP": "Ada",
    "AdaptCLIP": "Adapt",
}
METRIC_LABELS = {
    "i_auc": "I-AUC",
    "p_auc": "P-AUC",
    "p_pro": "PRO",
    "p_ap": "AP",
}


def read_rows() -> list[dict[str, str]]:
    with CSV_PATH.open("r", newline="") as f:
        return list(csv.DictReader(f))


def pct(value: float | None, *, already_percent: bool = False) -> float | None:
    if value is None:
        return None
    value = float(value)
    if not np.isfinite(value):
        return None
    return value if already_percent else value * 100.0


def metric_value(blob: dict | None, metric: str, *, already_percent: bool) -> float | None:
    if blob is None:
        return None
    aliases = {
        "i_auc": ("image_auc", "image_auroc"),
        "p_auc": ("pixel_auc", "pixel_auroc"),
        "p_pro": ("pixel_pro", "pixel_aupro"),
        "p_ap": ("pixel_ap",),
    }
    for key in aliases[metric]:
        if key in blob:
            return pct(blob[key], already_percent=already_percent)
    return None


def pick_first(mapping: dict, preferred: str) -> dict | None:
    if not mapping:
        return None
    if preferred in mapping:
        return mapping[preferred]
    return mapping[sorted(mapping)[0]]


def add_mvtec2_record(
    out: list[dict[str, str]],
    *,
    host: str,
    backbone: str,
    metric: str,
    baseline: float | None,
    t_ted: float | None,
    c_ted: float | None,
    source: str,
) -> None:
    if baseline is None or c_ted is None:
        return
    out.append(
        {
            "host": host,
            "backbone": backbone,
            "target": "MVTec2*",
            "metric": metric,
            "baseline": str(baseline),
            "t_ted": "" if t_ted is None else str(t_ted),
            "c_ted": str(c_ted),
            "delta_t": "" if t_ted is None else str(t_ted - baseline),
            "delta_c": str(c_ted - baseline),
            "source": source,
        }
    )


def mvtec2_rows_from_summary(path: Path) -> list[dict[str, str]]:
    name = path.parent.name
    data = json.loads(path.read_text())
    mean_blob = data.get("mean")
    if not isinstance(mean_blob, dict):
        mean_blob = {}

    host = None
    backbone = name
    already_percent = False
    baseline = t_ted = c_ted = None

    if name.startswith("aaclip_"):
        host = "AA-CLIP"
        already_percent = True
        tag = name.removeprefix("aaclip_").split("_mvtec2")[0]
        backbone = {
            "vitbplus": "ViT-B/16+",
            "vitl_openai224": "ViT-L/14 OpenAI",
            "vitl336": "ViT-L/14-336",
            "vith14": "ViT-H/14",
        }.get(tag, tag)
        baseline = mean_blob.get("baseline")
        t_ted = mean_blob.get("parallel")
        c_ted = pick_first(mean_blob.get("candidates", {}), "prescore_calibrated_alpha_1")
    elif name.startswith("adaclip_"):
        host = "AdaCLIP"
        tag = name.removeprefix("adaclip_").split("_mvtec2")[0]
        backbone = {
            "vitb16": "ViT-B/16",
            "vitl_openai224": "ViT-L/14 OpenAI",
            "vitl336": "ViT-L/14-336",
            "vith14": "ViT-H/14",
        }.get(tag, tag)
        by_mode = {row.get("mode"): row for row in data.get("rows", []) if row.get("target_label") == "mean"}
        baseline = by_mode.get("baseline_txt")
        t_ted = by_mode.get("parallel_margin")
        c_ted = by_mode.get("ted_calibrated")
    elif name.startswith("faprompt_"):
        host = "FAPrompt"
        tag = name.removeprefix("faprompt_").split("_mvtec2")[0]
        backbone = {
            "vitbplus": "ViT-B/16+",
            "vitl_openai": "ViT-L/14 OpenAI",
            "vitl336": "ViT-L/14-336",
            "vith14": "ViT-H/14",
        }.get(tag, tag)
        baseline = mean_blob.get("baseline_official")
        c_ted = pick_first(mean_blob.get("parallel", {}), "branch_calibrated_alpha_1")
    elif name.startswith("adaptclip_"):
        host = "AdaptCLIP"
        tag = name.removeprefix("adaptclip_").split("_mvtec2")[0]
        backbone = {
            "vitbplus": "ViT-B/16+",
            "vitl_openai": "ViT-L/14 OpenAI",
            "vitl336": "ViT-L/14-336",
            "vith14": "ViT-H/14",
        }.get(tag, tag)
        by_mode = {row.get("mode"): row for row in data.get("rows", []) if row.get("target_label") == "mean"}
        baseline = by_mode.get("baseline_txt")
        t_ted = by_mode.get("parallel_margin")
        c_ted = by_mode.get("ted_calibrated")

    if host is None or baseline is None or c_ted is None:
        return []

    out: list[dict[str, str]] = []
    for metric in ALL_METRICS:
        add_mvtec2_record(
            out,
            host=host,
            backbone=backbone,
            metric=metric,
            baseline=metric_value(baseline, metric, already_percent=already_percent),
            t_ted=metric_value(t_ted, metric, already_percent=already_percent),
            c_ted=metric_value(c_ted, metric, already_percent=already_percent),
            source=str(path.relative_to(ROOT)),
        )
    return out


def read_mvtec2_rows() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if not MVTEC2_ROOT.exists():
        return rows
    for path in sorted(MVTEC2_ROOT.glob("*_mvtec2mvtecad2_seed0/summary.json")):
        rows.extend(mvtec2_rows_from_summary(path))
    return rows


def fnum(value: str | None) -> float | None:
    if value in (None, "", "None"):
        return None
    out = float(value)
    if math.isnan(out):
        return None
    return out


def mean(values: list[float]) -> float:
    return float(sum(values) / len(values)) if values else float("nan")


def cted_rows(rows: list[dict[str, str]], *, metric: str | None = None) -> list[dict[str, str]]:
    out = []
    for row in rows:
        if row["host"] not in HOSTS:
            continue
        if row["target"] not in TARGETS:
            continue
        if metric is not None and row["metric"] != metric:
            continue
        delta = fnum(row.get("delta_c"))
        if delta is None:
            continue
        out.append(row)
    return out


def host_pixel_gain(rows: list[dict[str, str]]) -> dict[str, float]:
    values = {}
    for host in HOSTS:
        deltas = [
            fnum(row["delta_c"])
            for row in rows
            if row["host"] == host and row["target"] in TARGETS and row["metric"] in PIXEL_METRICS
        ]
        values[host] = mean([x for x in deltas if x is not None])
    return values


def host_pixel_win_rate(rows: list[dict[str, str]]) -> dict[str, float]:
    values = {}
    for host in HOSTS:
        deltas = [
            fnum(row["delta_c"])
            for row in rows
            if row["host"] == host and row["target"] in TARGETS and row["metric"] in PIXEL_METRICS
        ]
        clean = [x for x in deltas if x is not None]
        values[host] = 100.0 * sum(x > 0.0 for x in clean) / len(clean) if clean else float("nan")
    return values


def metric_gain(rows: list[dict[str, str]]) -> dict[str, float]:
    values = {}
    for metric in PIXEL_METRICS:
        deltas = [fnum(row["delta_c"]) for row in cted_rows(rows, metric=metric)]
        values[metric] = mean([x for x in deltas if x is not None])
    return values


def target_pixel_gain(rows: list[dict[str, str]]) -> dict[str, float]:
    values = {}
    for target in TARGET_PANEL_TARGETS:
        deltas = [
            fnum(row["delta_c"])
            for row in rows
            if row["host"] in HOSTS and row["target"] == target and row["metric"] in PIXEL_METRICS
        ]
        values[target] = mean([x for x in deltas if x is not None])
    return values


def win_rate(rows: list[dict[str, str]]) -> dict[str, float]:
    values = {}
    for metric in ALL_METRICS:
        deltas = [fnum(row["delta_c"]) for row in cted_rows(rows, metric=metric)]
        clean = [x for x in deltas if x is not None]
        values[metric] = 100.0 * sum(x > 0.0 for x in clean) / len(clean) if clean else float("nan")
    return values


def fmt_delta(value: float) -> str:
    if not np.isfinite(value):
        return "--"
    if abs(value) < 0.05:
        return "0.0"
    return f"{value:+.1f}"


def annotate(
    ax: plt.Axes,
    bars,
    values: list[float],
    *,
    percent: bool = False,
    x_offsets: list[float] | None = None,
) -> None:
    ymin, ymax = ax.get_ylim()
    span = ymax - ymin
    if x_offsets is None:
        x_offsets = [0.0] * len(values)
    for bar, value, x_offset in zip(bars, values, x_offsets):
        if not np.isfinite(value):
            continue
        label = f"{value:.0f}" if percent else fmt_delta(value)
        offset = span * 0.035
        y = value + offset if value >= 0 else value - offset
        va = "bottom" if value >= 0 else "top"
        ax.text(
            bar.get_x() + bar.get_width() / 2 + x_offset,
            y,
            label,
            ha="center",
            va=va,
            fontsize=10.5,
            fontweight="bold",
            color="#222222",
        )


def style_axis(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", color="#E9E0D2", linewidth=0.65)
    ax.set_axisbelow(True)
    ax.tick_params(axis="both", labelsize=10.0, length=0)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")


def save_panel(fig: plt.Figure, name: str, *, tight: bool = True) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    if tight:
        fig.savefig(FIG / f"{name}.pdf", bbox_inches="tight", pad_inches=0.04)
        fig.savefig(FIG / f"{name}.png", dpi=300, bbox_inches="tight", pad_inches=0.04)
    else:
        fig.savefig(FIG / f"{name}.pdf")
        fig.savefig(FIG / f"{name}.png", dpi=300)
    plt.close(fig)


def draw_bar_panel(
    ax: plt.Axes,
    labels: list[str],
    values: list[float],
    *,
    title: str,
    ylabel: str,
    colors: list[str],
    percent: bool = False,
    rotate: int = 0,
    annotation_x_offsets: list[float] | None = None,
) -> None:
    x = np.arange(len(labels))
    bars = ax.bar(x, values, width=0.62, color=colors, edgecolor="#2A2A2A", linewidth=0.35)
    lower = min(0.0, float(np.nanmin(values)) if values else 0.0)
    upper = max(0.0, float(np.nanmax(values)) if values else 0.0)
    margin = max((upper - lower) * 0.22, 1.0 if not percent else 8.0)
    ax.set_ylim(lower - margin * 0.35, upper + margin)
    ax.axhline(0, color="#262626", linewidth=0.75)
    if title:
        ax.set_title(title, fontsize=13.0, fontweight="bold", pad=7)
    ax.set_ylabel(ylabel, fontsize=11.0, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=rotate, ha="right" if rotate else "center")
    annotate(ax, bars, values, percent=percent, x_offsets=annotation_x_offsets)
    style_axis(ax)


def write_values(
    host_values: dict[str, float],
    host_gain_values: dict[str, float],
    metric_values: dict[str, float],
    target_values: dict[str, float],
    win_values: dict[str, float],
) -> None:
    lines = [
        "# Adapted Host Main Summary Figure Values",
        "",
        f"Source CSV: `{CSV_PATH.relative_to(ROOT)}`",
        "",
        "All values use C-TED minus baseline. Hosts: AA-CLIP, FAPrompt, AdaCLIP, AdaptCLIP. Standard targets: MVTec, VisA, MPDD, BTAD. MVTec2* is included only in the target-wise panel as a held-out stress target.",
        "",
        "## Host-wise Pixel Win Rate",
        "",
        "| Host | Win Rate | Mean Delta |",
        "|---|---:|---:|",
    ]
    for host in HOSTS:
        lines.append(f"| {host} | {host_values[host]:.1f} | {fmt_delta(host_gain_values[host])} |")
    lines += ["", "## Metric-wise Average Gain", "", "| Metric | Mean Delta |", "|---|---:|"]
    for metric in PIXEL_METRICS:
        lines.append(f"| {METRIC_LABELS[metric]} | {fmt_delta(metric_values[metric])} |")
    lines += ["", "## Target-wise Average Pixel Gain", "", "| Target | Mean Delta |", "|---|---:|"]
    for target in TARGET_PANEL_TARGETS:
        lines.append(f"| {target} | {fmt_delta(target_values[target])} |")
    lines += ["", "## Win Rate", "", "| Metric | Win Rate |", "|---|---:|"]
    for metric in ALL_METRICS:
        lines.append(f"| {METRIC_LABELS[metric]} | {win_values[metric]:.1f} |")
    (OUT / "adapted_host_main_summary_values_20260503.md").write_text("\n".join(lines))


def write_tex() -> None:
    tex = r"""\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{figure/adapted_host_main_summary_20260503.pdf}
\caption{
\textbf{Compact summary of source-calibrated TED on adapted CLIP-AD hosts.}
We summarize C-TED minus the host baseline over AA-CLIP, FAPrompt, AdaCLIP, and AdaptCLIP across MVTec, VisA, MPDD, and BTAD.
(a) reports host-wise pixel-metric win rates over P-AUC, PRO, and AP.
(b) reports metric-wise gains averaged over hosts, backbones, and targets.
(c) reports target-wise average pixel-metric gains, with MVTec2* shown as an additional held-out target when completed.
(d) reports improvement consistency across evaluation settings.
Full per-host tables are provided in the appendix.
}
\label{fig:adapted_host_main_summary}
\end{figure*}
"""
    (OUT / "adapted_host_main_summary_figure_20260503.tex").write_text(tex)


def main() -> int:
    rows = read_rows()
    mvtec2_rows = read_mvtec2_rows()
    rows.extend(mvtec2_rows)
    host_values = host_pixel_win_rate(rows)
    host_gain_values = host_pixel_gain(rows)
    metric_values = metric_gain(rows)
    target_values = target_pixel_gain(rows)
    win_values = win_rate(rows)

    FIG.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    palette = ["#24556A", "#3D7D79", "#79A777", "#C29A54"]

    panel_specs = [
        (
            "adapted_host_main_summary_a_host_avg_20260503",
            [HOST_LABELS[h] for h in HOSTS],
            [host_values[h] for h in HOSTS],
            "(a) Host-wise",
            "Improved pixel settings (%)",
            palette,
            True,
            0,
        ),
        (
            "adapted_host_main_summary_b_metric_avg_20260503",
            [METRIC_LABELS[m] for m in PIXEL_METRICS],
            [metric_values[m] for m in PIXEL_METRICS],
            "(b) Metric-wise",
            r"$\Delta$ score",
            palette[:3],
            False,
            0,
        ),
        (
            "adapted_host_main_summary_c_target_avg_20260503",
            list(TARGET_PANEL_TARGETS),
            [target_values[t] for t in TARGET_PANEL_TARGETS],
            "(c) Target-wise",
            r"$\Delta$ pixel metrics",
            palette[:4] + ["#8B8B8B"],
            False,
            25,
        ),
        (
            "adapted_host_main_summary_d_winrate_20260503",
            [METRIC_LABELS[m] for m in ALL_METRICS],
            [win_values[m] for m in ALL_METRICS],
            "(d) Consistency",
            "Improved settings (%)",
            palette,
            True,
            25,
        ),
    ]
    compact_ylabels = {
        "adapted_host_main_summary_a_host_avg_20260503": "Improved (%)",
        "adapted_host_main_summary_b_metric_avg_20260503": r"$\Delta$ score",
        "adapted_host_main_summary_c_target_avg_20260503": r"$\Delta$ pixel",
        "adapted_host_main_summary_d_winrate_20260503": "Improved (%)",
    }

    for name, labels, values, title, ylabel, colors, percent, rotate in panel_specs:
        fig, ax = plt.subplots(figsize=(2.35, 2.05))
        draw_bar_panel(
            ax,
            labels,
            values,
            title=title,
            ylabel=ylabel,
            colors=colors,
            percent=percent,
            rotate=rotate,
        )
        save_panel(fig, name)
        fig, ax = plt.subplots(figsize=(2.75, 2.25), constrained_layout=False)
        draw_bar_panel(
            ax,
            labels,
            values,
            title="",
            ylabel=compact_ylabels[name],
            colors=colors,
            percent=percent,
            rotate=rotate,
        )
        fig.subplots_adjust(left=0.34, right=0.985, bottom=0.30, top=0.95)
        save_panel(fig, f"{name}_notitle", tight=False)
        if name in {
            "adapted_host_main_summary_c_target_avg_20260503",
            "adapted_host_main_summary_d_winrate_20260503",
        }:
            fig, ax = plt.subplots(figsize=(2.95, 2.25), constrained_layout=False)
            horizontal_labels = labels
            if name == "adapted_host_main_summary_c_target_avg_20260503":
                horizontal_labels = ["MVT", "VisA", "MPDD", "BTAD", "MVT2"]
            draw_bar_panel(
                ax,
                horizontal_labels,
                values,
                title="",
                ylabel=compact_ylabels[name],
                colors=colors,
                percent=percent,
                rotate=0,
            )
            fig.subplots_adjust(left=0.34, right=0.985, bottom=0.22, top=0.95)
            save_panel(fig, f"{name}_notitle_horiz", tight=False)
            if name == "adapted_host_main_summary_c_target_avg_20260503":
                fig, ax = plt.subplots(figsize=(2.95, 2.25), constrained_layout=False)
                draw_bar_panel(
                    ax,
                    horizontal_labels,
                    values,
                    title="",
                    ylabel=compact_ylabels[name],
                    colors=colors,
                    percent=percent,
                    rotate=0,
                )
                ax.tick_params(axis="x", labelsize=8.6)
                fig.subplots_adjust(left=0.34, right=0.985, bottom=0.20, top=0.95)
                save_panel(fig, f"{name}_notitle_horiz_short", tight=False)
                fig, ax = plt.subplots(figsize=(2.95, 2.25), constrained_layout=False)
                draw_bar_panel(
                    ax,
                    ["M", "V", "P", "B", "M2"],
                    values,
                    title="",
                    ylabel=compact_ylabels[name],
                    colors=colors,
                    percent=percent,
                    rotate=0,
                )
                ax.tick_params(axis="x", labelsize=9.6)
                ax.set_ylabel(compact_ylabels[name], labelpad=1)
                fig.subplots_adjust(left=0.25, right=0.985, bottom=0.19, top=0.95)
                save_panel(fig, f"{name}_notitle_horiz_tiny", tight=False)

    row_labels = {
        "adapted_host_main_summary_c_target_avg_20260503": ["M", "V", "P", "B", "M2"],
    }
    for name, labels, values, _title, _ylabel, colors, percent, _rotate in panel_specs:
        fig, ax = plt.subplots(figsize=(2.75, 2.25), constrained_layout=False)
        annotation_x_offsets = None
        if name == "adapted_host_main_summary_c_target_avg_20260503":
            annotation_x_offsets = [-0.08, 0.07, 0.0, 0.0, 0.0]
        draw_bar_panel(
            ax,
            row_labels.get(name, labels),
            values,
            title="",
            ylabel=compact_ylabels[name],
            colors=colors,
            percent=percent,
            rotate=0,
            annotation_x_offsets=annotation_x_offsets,
        )
        if name == "adapted_host_main_summary_c_target_avg_20260503":
            ax.tick_params(axis="x", labelsize=9.2)
        ax.set_ylabel(compact_ylabels[name], labelpad=0)
        fig.subplots_adjust(left=0.25, right=0.985, bottom=0.30, top=0.95)
        save_panel(fig, f"{name}_notitle_rowaligned", tight=False)

    fig, axs = plt.subplots(1, 4, figsize=(10.6, 2.55), constrained_layout=True)
    for ax, (_, labels, values, title, ylabel, colors, percent, rotate) in zip(axs, panel_specs):
        draw_bar_panel(
            ax,
            labels,
            values,
            title=title,
            ylabel=ylabel,
            colors=colors,
            percent=percent,
            rotate=rotate,
        )
    fig.savefig(FIG / "adapted_host_main_summary_20260503.pdf", bbox_inches="tight", pad_inches=0.04)
    fig.savefig(FIG / "adapted_host_main_summary_20260503.png", dpi=300, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)

    fig, axs = plt.subplots(1, 4, figsize=(12.5, 2.85), constrained_layout=False)
    for ax, (name, labels, values, title, ylabel, colors, percent, rotate) in zip(axs, panel_specs):
        draw_bar_panel(
            ax,
            labels,
            values,
            title="",
            ylabel=compact_ylabels[name],
            colors=colors,
            percent=percent,
            rotate=rotate,
        )
    fig.subplots_adjust(left=0.095, right=0.995, bottom=0.30, top=0.95, wspace=0.64)
    fig.savefig(FIG / "adapted_host_main_summary_notitle_20260503.pdf")
    fig.savefig(FIG / "adapted_host_main_summary_notitle_20260503.png", dpi=300)
    plt.close(fig)

    write_values(host_values, host_gain_values, metric_values, target_values, win_values)
    write_tex()

    print(
        {
            "figure": str(FIG / "adapted_host_main_summary_20260503.pdf"),
            "png": str(FIG / "adapted_host_main_summary_20260503.png"),
            "tex": str(OUT / "adapted_host_main_summary_figure_20260503.tex"),
            "values": str(OUT / "adapted_host_main_summary_values_20260503.md"),
            "mvtec2_records": len(mvtec2_rows),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
