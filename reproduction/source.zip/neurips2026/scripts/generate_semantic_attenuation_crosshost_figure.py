from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026" / "results"

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
PRESET_LABELS = ["VisA→MVTec", "MVTec→VisA", "MVTec→MPDD", "MVTec→BTAD"]

SOURCES = {
    "AnomalyCLIP": {
        "run_tag": "rerun2",
        "prefix": "anomalyclip_wrongclass_semantic_collapse",
        "color": "#1f77b4",
    },
    "AdaCLIP": {
        "run_tag": "rerun3",
        "prefix": "adaclip_wrongclass_semantic_collapse",
        "color": "#d62728",
    },
}

METRICS = [
    ("true_prompt_top1_rate_image", "Image Top-1"),
    ("true_prompt_top1_rate_local", "Local Top-1"),
    ("mean_true_wrong_corr", "True/Wrong Corr"),
    ("mean_true_wrong_topk_overlap", "True/Wrong Top-k Overlap"),
]


def load_summary(model_name: str, preset: str) -> dict:
    info = SOURCES[model_name]
    path = RESULT_ROOT / f"{info['prefix']}_{preset}_x1_{info['run_tag']}" / "summary.json"
    with open(path, "r") as f:
        return json.load(f)


def weighted_mean(rows: list[tuple[float, int]]) -> float:
    total_w = sum(w for _, w in rows)
    if total_w == 0:
        return float("nan")
    return sum(v * w for v, w in rows) / total_w


def collect_data() -> dict:
    out: dict[str, dict] = {}
    for model_name in SOURCES:
        per_preset = {}
        for preset in PRESETS:
            payload = load_summary(model_name, preset)
            per_preset[preset] = payload["summary"]
        out[model_name] = per_preset
    return out


def build_aggregate(data: dict) -> dict:
    aggregate = {}
    for model_name, per_preset in data.items():
        agg = {}
        for metric, _ in METRICS:
            weighted = []
            for preset in PRESETS:
                summary = per_preset[preset]
                weighted.append((float(summary[metric]), int(summary["num_images"])))
            agg[metric] = weighted_mean(weighted)
        aggregate[model_name] = agg
    return aggregate


def plot(data: dict, aggregate: dict, out_dir: Path) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(13.5, 7.5), constrained_layout=True)
    axes = axes.flatten()
    x = np.arange(len(PRESETS) + 1)
    width = 0.36

    for ax, (metric, title) in zip(axes, METRICS):
        for idx, (model_name, info) in enumerate(SOURCES.items()):
            vals = [float(data[model_name][preset][metric]) for preset in PRESETS]
            vals.append(float(aggregate[model_name][metric]))
            offset = (-0.5 + idx) * width
            ax.bar(
                x + offset,
                vals,
                width=width,
                label=model_name,
                color=info["color"],
                alpha=0.9,
            )
        ax.set_title(title)
        ax.set_xticks(x, PRESET_LABELS + ["Weighted\nMean"])
        ax.set_ylim(0.0, 1.02)
        ax.grid(axis="y", alpha=0.25)

    axes[0].legend(frameon=False, ncols=2, loc="upper right")
    fig.suptitle("Cross-Host Semantic Attenuation Audit", fontsize=15)

    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / "semantic_attenuation_crosshost.png", dpi=220, bbox_inches="tight")
    fig.savefig(out_dir / "semantic_attenuation_crosshost.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    out_dir = RESULT_ROOT / "semantic_attenuation_crosshost_figure"
    data = collect_data()
    aggregate = build_aggregate(data)
    plot(data, aggregate, out_dir)
    with open(out_dir / "semantic_attenuation_crosshost.json", "w") as f:
        json.dump({"per_preset": data, "aggregate": aggregate}, f, indent=2)


if __name__ == "__main__":
    main()
