#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
IN_CSV = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables" / "failure_conditioned_gain_20260504.csv"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR = ROOT / "figure"


GROUPS = ["Low", "Mid", "High"]
GROUP_LABELS = {"Low": "Low", "Mid": "Mid", "High": "High"}
SETTING_MARKERS = {
    "FA MVTec→MPDD": "o",
    "FA MVTec→BTAD": "s",
    "Ada MVTec→BTAD": "^",
    "AdaCLIP MVTec→BTAD": "^",
}
SETTING_COLORS = {
    "FA MVTec→MPDD": "#2F6F73",
    "FA MVTec→BTAD": "#A85C3A",
    "Ada MVTec→BTAD": "#6F5C8C",
    "AdaCLIP MVTec→BTAD": "#6F5C8C",
}

DISPLAY_LABELS = {
    "FA MVTec→MPDD": "FAPrompt (MPDD)",
    "FA MVTec→BTAD": "FAPrompt (BTAD)",
    "Ada MVTec→BTAD": "AdaCLIP (BTAD)",
    "AdaCLIP MVTec→BTAD": "AdaCLIP (BTAD)",
}


def read_rows() -> list[dict[str, str]]:
    with IN_CSV.open() as f:
        return list(csv.DictReader(f))


def f(row: dict[str, str], key: str) -> float:
    return float(row[key])


def aggregate(rows: list[dict[str, str]]) -> list[dict[str, float | str | int]]:
    by_group: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_group[row["group"]].append(row)

    out: list[dict[str, float | str | int]] = []
    for group in GROUPS:
        items = by_group.get(group, [])
        if not items:
            continue
        out.append(
            {
                "group": group,
                "num_bins": len(items),
                "mean_severity": float(np.mean([f(r, "severity") for r in items])),
                "delta_pauc": float(np.mean([f(r, "delta_P-AUC") for r in items])),
                "delta_pro": float(np.mean([f(r, "delta_PRO") for r in items])),
                "delta_ap": float(np.mean([f(r, "delta_AP") for r in items])),
                "delta_loc": float(np.mean([f(r, "delta_Loc") for r in items])),
            }
        )
    return out


def write_csv(summary: list[dict[str, float | str | int]]) -> Path:
    path = OUT_DIR / "failure_conditioned_noncherry_summary_20260504.csv"
    fields = ["group", "num_bins", "mean_severity", "delta_pauc", "delta_pro", "delta_ap", "delta_loc"]
    with path.open("w", newline="") as fobj:
        writer = csv.DictWriter(fobj, fieldnames=fields)
        writer.writeheader()
        writer.writerows(summary)
    return path


def fmt_signed(x: float) -> str:
    return f"{x:+.1f}"


def write_table(summary: list[dict[str, float | str | int]]) -> Path:
    path = OUT_DIR / "failure_conditioned_noncherry_table_20260504.tex"
    low = next(row for row in summary if row["group"] == "Low")
    mid_high = [row for row in summary if row["group"] in {"Mid", "High"}]
    mh_sev = float(np.mean([float(row["mean_severity"]) for row in mid_high]))
    mh_pro = float(np.mean([float(row["delta_pro"]) for row in mid_high]))
    mh_ap = float(np.mean([float(row["delta_ap"]) for row in mid_high]))
    low_loc = 0.5 * (float(low["delta_pro"]) + float(low["delta_ap"]))
    mh_loc = 0.5 * (mh_pro + mh_ap)
    lines = [
        r"\begin{wraptable}{r}{0.43\columnwidth}",
        r"\vspace{-0.9em}",
        r"\centering",
        r"\caption{",
        r"Failure-conditioned gains. Bins are formed post-hoc by baseline hard-FP severity.",
        r"}",
        r"\label{tab:failure_conditioned_gains}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.0pt}",
        r"\renewcommand{\arraystretch}{1.02}",
        r"\resizebox{\linewidth}{!}{%",
        r"\begin{tabular}{lccc}",
        r"\toprule",
        r"Baseline H-FP & Sev. & $\Delta$PRO / $\Delta$AP & $\Delta$Loc \\",
        r"\midrule",
    ]
    lines.append(
        f"Low & {float(low['mean_severity']):.2f} "
        f"& {fmt_signed(float(low['delta_pro']))} / {fmt_signed(float(low['delta_ap']))} "
        f"& {fmt_signed(low_loc)} \\\\"
    )
    lines.append(
        f"Mid/High & {mh_sev:.2f} "
        f"& {fmt_signed(mh_pro)} / {fmt_signed(mh_ap)} "
        f"& {fmt_signed(mh_loc)} \\\\"
    )
    lines += [
        r"\midrule",
        f"Extra & {mh_sev - float(low['mean_severity']):+.2f} "
        f"& {fmt_signed(mh_pro - float(low['delta_pro']))} / {fmt_signed(mh_ap - float(low['delta_ap']))} "
        f"& {fmt_signed(mh_loc - low_loc)} \\\\",
    ]
    lines += [
        r"\bottomrule",
        r"\end{tabular}%",
        r"}",
        r"\vspace{-0.9em}",
        r"\end{wraptable}",
        "",
    ]
    path.write_text("\n".join(lines))
    return path


def draw(rows: list[dict[str, str]], summary: list[dict[str, float | str | int]]) -> Path:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    group_to_x = {g: i for i, g in enumerate(GROUPS)}
    x = np.arange(len(GROUPS))
    pro = np.array([float(row["delta_pro"]) for row in summary])
    ap = np.array([float(row["delta_ap"]) for row in summary])
    loc = np.array([float(row["delta_loc"]) for row in summary])

    fig, axes = plt.subplots(1, 2, figsize=(7.05, 2.65), gridspec_kw={"width_ratios": [1.08, 1.08]})

    width = 0.34
    axes[0].bar(x - width / 2, pro, width=width, color="#447A82", edgecolor="#222222", linewidth=0.45, label="PRO")
    axes[0].bar(x + width / 2, ap, width=width, color="#D59A42", edgecolor="#222222", linewidth=0.45, label="AP")
    axes[0].axhline(0, color="#222222", lw=0.8)
    for xi, pv, av in zip(x, pro, ap):
        axes[0].text(xi - width / 2, pv + 0.6, fmt_signed(float(pv)), ha="center", va="bottom", fontsize=7.3, fontweight="bold")
        axes[0].text(xi + width / 2, av + 0.6, fmt_signed(float(av)), ha="center", va="bottom", fontsize=7.3, fontweight="bold")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([GROUP_LABELS[g] for g in GROUPS], fontsize=8.1, fontweight="bold")
    axes[0].set_ylabel("gain over baseline", fontsize=8.3, fontweight="bold")
    axes[0].set_title("(a) Aggregate over completed bins", loc="left", fontsize=9.0, fontweight="bold")
    axes[0].legend(frameon=False, fontsize=7.6, ncol=2, loc="upper left")

    axes[1].bar(x, loc, width=0.5, color="#D8D0C2", edgecolor="#222222", linewidth=0.45, zorder=1)
    rng = np.random.default_rng(7)
    for row in rows:
        xi = group_to_x[row["group"]] + float(rng.uniform(-0.09, 0.09))
        setting = row["setting"]
        axes[1].scatter(
            xi,
            f(row, "delta_Loc"),
            s=38,
            marker=SETTING_MARKERS.get(setting, "o"),
            color=SETTING_COLORS.get(setting, "#555555"),
            edgecolor="white",
            linewidth=0.6,
            zorder=3,
        )
    axes[1].axhline(0, color="#222222", lw=0.8)
    for xi, lv in zip(x, loc):
        axes[1].text(xi, lv + 0.6, fmt_signed(float(lv)), ha="center", va="bottom", fontsize=7.5, fontweight="bold")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels([GROUP_LABELS[g] for g in GROUPS], fontsize=8.1, fontweight="bold")
    axes[1].set_ylabel(r"$\Delta$(PRO+AP)/2", fontsize=8.3, fontweight="bold")
    axes[1].set_title("(b) Host-transfer bins", loc="left", fontsize=9.0, fontweight="bold")

    handles = []
    labels = []
    for setting, marker in SETTING_MARKERS.items():
        if any(row["setting"] == setting for row in rows):
            handles.append(
                plt.Line2D(
                    [0],
                    [0],
                    marker=marker,
                    linestyle="",
                    color=SETTING_COLORS[setting],
                    markeredgecolor="white",
                    markersize=5.5,
                )
            )
            labels.append(DISPLAY_LABELS.get(setting, setting))
    axes[1].legend(handles, labels, frameon=False, fontsize=6.5, loc="upper left", bbox_to_anchor=(0.0, 1.01))

    for ax in axes:
        ax.grid(axis="y", color="#E7E1D8", lw=0.65)
        ax.set_axisbelow(True)
        ax.tick_params(axis="y", labelsize=7.5)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)

    fig.tight_layout(pad=0.5, w_pad=0.9)
    pdf = FIG_DIR / "failure_conditioned_noncherry_20260504.pdf"
    png = FIG_DIR / "failure_conditioned_noncherry_20260504.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return pdf


def write_figure_tex() -> Path:
    path = OUT_DIR / "failure_conditioned_noncherry_figure_20260504.tex"
    path.write_text(
        "\n".join(
            [
                r"\begin{figure*}[t]",
                r"\centering",
                r"\includegraphics[width=0.72\textwidth]{figure/failure_conditioned_noncherry_20260504.pdf}",
                r"\caption{",
                r"\textbf{Failure-conditioned gains without class selection.}",
                r"Target classes are binned by baseline hard-normal activation after evaluation, using all completed FAPrompt and AdaCLIP bins rather than selecting favorable classes.",
                r"(a) Aggregates PRO/AP gains by severity bin, and (b) overlays the individual host-transfer bins.",
                r"The grouping is post-hoc and is never used for bank construction, calibration, or hyperparameter selection.",
                r"}",
                r"\label{fig:failure_conditioned_noncherry}",
                r"\end{figure*}",
                "",
            ]
        )
    )
    return path


def main() -> int:
    rows = read_rows()
    summary = aggregate(rows)
    csv_path = write_csv(summary)
    table_path = write_table(summary)
    fig_path = draw(rows, summary)
    tex_path = write_figure_tex()
    print(
        json.dumps(
            {
                "input_rows": len(rows),
                "settings": sorted({row["setting"] for row in rows}),
                "summary_csv": str(csv_path.relative_to(ROOT)),
                "table": str(table_path.relative_to(ROOT)),
                "figure": str(fig_path.relative_to(ROOT)),
                "figure_tex": str(tex_path.relative_to(ROOT)),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
