from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader
from WinCLIP import WinClipAD
from utils.eval_utils import specify_resolution
from utils.metrics import metric_cal


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--eta", type=float, default=0.1)
    parser.add_argument("--rho", type=float, default=4.0)
    parser.add_argument("--ranks", nargs="+", type=int, default=[4, 8])
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=1)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--output_tag", type=str, default="winclip_prompt_oracle_geodesic")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(model: WinClipAD, batch_np) -> torch.Tensor:
    imgs = [model.transform(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(model.device)


@torch.no_grad()
def collect_normal_features(model: WinClipAD, loader) -> torch.Tensor:
    feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        image = _preprocess_batch(model, data)
        visual_features = model.encode_image(image)
        for feat in visual_features:
            feats.append(F.normalize(feat[normal_idx].float(), dim=-1))
    if not feats:
        raise RuntimeError("No normal visual features found.")
    return torch.cat(feats, dim=0)


@torch.no_grad()
def evaluate_current_text_features(model: WinClipAD, loader, resolution: int) -> dict[str, float]:
    scores = []
    test_imgs = []
    gt_list = []
    gt_mask_list = []
    for data, mask, label, _name, _img_type in loader:
        for f in data:
            test_imgs.append(f.numpy())
        image = _preprocess_batch(model, data)
        score = model(image)
        score_batch = []
        for s in score:
            if isinstance(s, np.ndarray):
                score_batch.append(np.asarray(s).squeeze())
            else:
                score_batch.append(s.squeeze().detach().cpu().numpy())
        scores += score_batch
        for l, m in zip(label, mask):
            gt_list.append(int(l.numpy() if hasattr(l, "numpy") else l))
            gt_mask_list.append((m.numpy() > 0).astype(np.uint8))
    test_imgs, scores, gt_mask_list = specify_resolution(
        test_imgs,
        scores,
        gt_mask_list,
        resolution=(resolution, resolution),
    )
    metrics = metric_cal(np.array(scores), gt_list, gt_mask_list, cal_pro=False)
    return {
        "i_roc": float(metrics["i_roc"]),
        "p_roc": float(metrics["p_roc"]),
        "p_pro": float(metrics["p_pro"]),
    }


@torch.no_grad()
def compute_lowrank_basis(normal_feats: torch.Tensor, rank: int) -> torch.Tensor:
    centered = normal_feats - normal_feats.mean(dim=0, keepdim=True)
    q = min(rank, centered.shape[0], centered.shape[1])
    if q < 1:
        raise RuntimeError("Not enough features for low-rank basis.")
    # Principal directions of normal-feature variation.
    _u, _s, v = torch.pca_lowrank(centered, q=q, center=False)
    basis = F.normalize(v[:, :q], dim=0)
    return basis


@torch.no_grad()
def transport_linear(base_normal: torch.Tensor, mu_test: torch.Tensor, eta: float) -> tuple[torch.Tensor, torch.Tensor]:
    delta = mu_test - base_normal
    shifted = F.normalize(base_normal + eta * delta, dim=-1)
    return shifted, delta


@torch.no_grad()
def transport_lowrank_geodesic(
    base_normal: torch.Tensor,
    mu_test: torch.Tensor,
    basis: torch.Tensor,
    eta: float,
    rho: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    d = mu_test - base_normal
    coeff = d @ basis
    d_parallel = coeff @ basis.T
    d_perp = d - d_parallel
    shrink = 1.0 / (1.0 + rho)
    delta = d_parallel + shrink * d_perp
    shifted = F.normalize(base_normal + eta * delta, dim=-1)
    return shifted, delta, d_parallel, d_perp


@torch.no_grad()
def set_normal_prompt(model: WinClipAD, normal_prompt: torch.Tensor, base_abnormal: torch.Tensor) -> None:
    model.avr_normal_text_features = normal_prompt.to(model.device, dtype=model.text_features.dtype)
    model.text_features = torch.cat(
        [
            model.avr_normal_text_features,
            F.normalize(base_abnormal, dim=-1).to(model.device, dtype=model.text_features.dtype),
        ],
        dim=0,
    )
    model.text_features = F.normalize(model.text_features, dim=-1)


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"

    rows = []
    for class_name in args.class_names:
        loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)
        model = WinClipAD(
            out_size_h=args.resolution,
            out_size_w=args.resolution,
            device=device,
            backbone=args.backbone,
            pretrained_dataset=args.pretrained_dataset,
            scales=tuple(args.scales),
            img_resize=args.img_resize,
            img_cropsize=args.img_cropsize,
        ).to(device)
        model.eval_mode()
        model.build_text_feature_gallery(class_name)

        base_normal = F.normalize(model.avr_normal_text_features.float(), dim=-1)
        base_abnormal = F.normalize(model.avr_abnormal_text_features.float(), dim=-1)
        normal_feats = collect_normal_features(model, loader)
        mu_test = F.normalize(normal_feats.mean(dim=0, keepdim=True), dim=-1)

        baseline = evaluate_current_text_features(model, loader, args.resolution)

        linear_prompt, linear_delta = transport_linear(base_normal, mu_test, eta=args.eta)
        set_normal_prompt(model, linear_prompt, base_abnormal)
        linear_metrics = evaluate_current_text_features(model, loader, args.resolution)
        linear_row = {
            "class_name": class_name,
            "variant": "linear",
            "rank": 0,
            "eta": float(args.eta),
            "rho": float(args.rho),
            "cos_mu_base_normal": float(F.cosine_similarity(mu_test, base_normal, dim=-1).item()),
            "cos_base_abnormal": float(F.cosine_similarity(base_normal, base_abnormal, dim=-1).item()),
            "cos_variant_abnormal": float(F.cosine_similarity(linear_prompt, base_abnormal, dim=-1).item()),
            "delta_norm": float(linear_delta.norm(dim=-1).item()),
            "parallel_norm": float("nan"),
            "perp_norm": float("nan"),
            "baseline_i_roc": baseline["i_roc"],
            "baseline_p_roc": baseline["p_roc"],
            "baseline_p_pro": baseline["p_pro"],
            "variant_i_roc": linear_metrics["i_roc"],
            "variant_p_roc": linear_metrics["p_roc"],
            "variant_p_pro": linear_metrics["p_pro"],
            "delta_i_roc": linear_metrics["i_roc"] - baseline["i_roc"],
            "delta_p_roc": linear_metrics["p_roc"] - baseline["p_roc"],
            "delta_p_pro": linear_metrics["p_pro"] - baseline["p_pro"],
        }
        rows.append(linear_row)
        print(
            f"{class_name} | linear | eta={args.eta:.2f} | "
            f"dI={linear_row['delta_i_roc']:.2f} dP={linear_row['delta_p_roc']:.2f} "
            f"dPRO={linear_row['delta_p_pro']:.2f} | ||d||={linear_row['delta_norm']:.4f}",
            flush=True,
        )

        for rank in args.ranks:
            basis = compute_lowrank_basis(normal_feats, rank=rank)
            geo_prompt, geo_delta, d_parallel, d_perp = transport_lowrank_geodesic(
                base_normal=base_normal,
                mu_test=mu_test,
                basis=basis,
                eta=args.eta,
                rho=args.rho,
            )
            set_normal_prompt(model, geo_prompt, base_abnormal)
            geo_metrics = evaluate_current_text_features(model, loader, args.resolution)
            row = {
                "class_name": class_name,
                "variant": "geodesic_lowrank",
                "rank": int(rank),
                "eta": float(args.eta),
                "rho": float(args.rho),
                "cos_mu_base_normal": float(F.cosine_similarity(mu_test, base_normal, dim=-1).item()),
                "cos_base_abnormal": float(F.cosine_similarity(base_normal, base_abnormal, dim=-1).item()),
                "cos_variant_abnormal": float(F.cosine_similarity(geo_prompt, base_abnormal, dim=-1).item()),
                "delta_norm": float(geo_delta.norm(dim=-1).item()),
                "parallel_norm": float(d_parallel.norm(dim=-1).item()),
                "perp_norm": float(d_perp.norm(dim=-1).item()),
                "baseline_i_roc": baseline["i_roc"],
                "baseline_p_roc": baseline["p_roc"],
                "baseline_p_pro": baseline["p_pro"],
                "variant_i_roc": geo_metrics["i_roc"],
                "variant_p_roc": geo_metrics["p_roc"],
                "variant_p_pro": geo_metrics["p_pro"],
                "delta_i_roc": geo_metrics["i_roc"] - baseline["i_roc"],
                "delta_p_roc": geo_metrics["p_roc"] - baseline["p_roc"],
                "delta_p_pro": geo_metrics["p_pro"] - baseline["p_pro"],
            }
            rows.append(row)
            print(
                f"{class_name} | geo-r{rank} | eta={args.eta:.2f} rho={args.rho:.2f} | "
                f"dI={row['delta_i_roc']:.2f} dP={row['delta_p_roc']:.2f} "
                f"dPRO={row['delta_p_pro']:.2f} | "
                f"||Δ||={row['delta_norm']:.4f} "
                f"||Δ_parallel||={row['parallel_norm']:.4f} "
                f"||Δ_perp||={row['perp_norm']:.4f}",
                flush=True,
            )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(rows, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
