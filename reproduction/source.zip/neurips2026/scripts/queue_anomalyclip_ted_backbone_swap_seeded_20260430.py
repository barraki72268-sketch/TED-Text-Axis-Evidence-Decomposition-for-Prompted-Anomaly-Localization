from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_ted_backbone_swap_seeded_20260430"
LOG_ROOT = RESULT_ROOT / "_logs"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")

MVTEC_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth")
VISA_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth")

VIT_L_OPENAI = "/home/jinyoung/.cache/clip/ViT-L-14.pt"
VIT_B_OPENAI = "/home/jinyoung/.cache/clip/ViT-B-16.pt"
VIT_H_LAION = (
    "/mnt/data/hf-cache/hub/models--laion--CLIP-ViT-H-14-laion2B-s32B-b79K/"
    "blobs/9a78ef8e8c73fd0df621682e7a8e8eb36c6916cb3c16b291a082ecd52ab79cc4"
)

TRANSFERS = [
    {
        "name": "visa2mvtec",
        "source_root": VISA_ROOT,
        "source_dataset": "visa",
        "target_root": MVTEC_ROOT,
        "target_dataset": "mvtec",
        "checkpoint": VISA_CKPT,
    },
    {
        "name": "mvtec2visa",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": VISA_ROOT,
        "target_dataset": "visa",
        "checkpoint": MVTEC_CKPT,
    },
    {
        "name": "mvtec2mpdd",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": MPDD_ROOT,
        "target_dataset": "mpdd",
        "checkpoint": MVTEC_CKPT,
    },
    {
        "name": "mvtec2btad",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": BTAD_ROOT,
        "target_dataset": "btad",
        "checkpoint": MVTEC_CKPT,
    },
]

BACKBONES = [
    {
        "tag": "vitl_openai",
        "label": "ViT-L/14 OpenAI",
        "model_name_or_path": VIT_L_OPENAI,
        "image_size": "224",
        "dpam_layer": "20",
        "features_list": ["6", "12", "18", "24"],
        "allow_prompt_projection": False,
    },
    {
        "tag": "vitb16_projected",
        "label": "ViT-B/16 OpenAI projected",
        "model_name_or_path": VIT_B_OPENAI,
        "image_size": "224",
        "dpam_layer": "12",
        "features_list": ["3", "6", "9", "12"],
        "allow_prompt_projection": True,
    },
    {
        "tag": "vith14_projected",
        "label": "ViT-H/14 LAION projected",
        "model_name_or_path": VIT_H_LAION,
        "image_size": "224",
        "dpam_layer": "32",
        "features_list": ["8", "16", "24", "32"],
        "allow_prompt_projection": True,
    },
]


def build_cmd(transfer: dict[str, str], backbone: dict[str, object], seed: int) -> list[str]:
    save_dir = RESULT_ROOT / f"{backbone['tag']}_{transfer['name']}_seed{seed}"
    cmd = [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        "cuda:0",
        "--checkpoint_path",
        transfer["checkpoint"],
        "--heldout_class",
        "none",
        "--source_root",
        transfer["source_root"],
        "--source_dataset",
        transfer["source_dataset"],
        "--target_root",
        transfer["target_root"],
        "--target_dataset",
        transfer["target_dataset"],
        "--target_mode",
        "test",
        "--model_name_or_path",
        str(backbone["model_name_or_path"]),
        "--image_size",
        str(backbone["image_size"]),
        "--dpam_layer",
        str(backbone["dpam_layer"]),
        "--features_list",
        *list(backbone["features_list"]),
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "1.0",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.05",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if bool(backbone["allow_prompt_projection"]):
        cmd.extend(["--allow_prompt_projection", "--prompt_projection_ridge", "1e-3"])
    return cmd


def main() -> None:
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "1"
    for backbone in BACKBONES:
        for transfer in TRANSFERS:
            for seed in (0, 1, 2):
                save_dir = RESULT_ROOT / f"{backbone['tag']}_{transfer['name']}_seed{seed}"
                if (save_dir / "summary.json").exists():
                    print(
                        {
                            "stage": "skip_existing",
                            "backbone": backbone["tag"],
                            "transfer": transfer["name"],
                            "seed": seed,
                        },
                        flush=True,
                    )
                    continue
                log_path = LOG_ROOT / f"{backbone['tag']}_{transfer['name']}_seed{seed}.log"
                cmd = build_cmd(transfer, backbone, seed)
                print(
                    {
                        "stage": "start",
                        "backbone": backbone["tag"],
                        "transfer": transfer["name"],
                        "seed": seed,
                        "log": str(log_path),
                    },
                    flush=True,
                )
                with log_path.open("w") as log_file:
                    proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
                print(
                    {
                        "stage": "done",
                        "backbone": backbone["tag"],
                        "transfer": transfer["name"],
                        "seed": seed,
                        "returncode": proc.returncode,
                        "log": str(log_path),
                    },
                    flush=True,
                )
                if proc.returncode != 0:
                    raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
