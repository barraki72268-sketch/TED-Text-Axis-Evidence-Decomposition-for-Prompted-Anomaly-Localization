from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = ROOT / "neurips2026" / ".." / ".."
RUNNER = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaclip.py"
PATCHCORE_PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULT_ROOT = ROOT / "neurips2026" / "results" / "adaclip_recipe_fragility"

PRESET_CONFIGS = {
    "visa2mvtec": {
        "source_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "source_dataset": "visa",
        "target_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "target_dataset": "mvtec",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_visa_clean_multilayer.pt"),
    },
    "mvtec2btad": {
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "source_dataset": "mvtec",
        "target_root": str(ROOT / "neurips2026" / "data" / "BTAD_official"),
        "target_dataset": "btad",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"),
    },
    "mvtec2mpdd": {
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "source_dataset": "mvtec",
        "target_root": "/mnt/data/MPDD",
        "target_dataset": "mpdd",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"),
    },
    "mvtec2visa": {
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "source_dataset": "mvtec",
        "target_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "target_dataset": "visa",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"),
    },
}


def build_command(args, preset_name: str, layer_recipe: str) -> tuple[list[str], Path]:
    preset = PRESET_CONFIGS[preset_name]
    save_dir = RESULT_ROOT / f"{preset_name}_{layer_recipe}_{args.run_tag}"
    cmd = [
        str(PATCHCORE_PYTHON),
        str(RUNNER),
        "--source_root",
        preset["source_root"],
        "--source_dataset",
        preset["source_dataset"],
        "--target_root",
        preset["target_root"],
        "--target_dataset",
        preset["target_dataset"],
        "--checkpoint_path",
        preset["checkpoint_path"],
        "--save_dir",
        str(save_dir),
        "--class_name",
        args.class_name if args.class_name is not None else "none",
        "--bank_cache_path",
        preset["bank_cache_path"],
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--prompting_depth",
        "4",
        "--prompting_length",
        "5",
        "--prompting_branch",
        "VL",
        "--prompting_type",
        "SD",
        "--use_hsf",
        "true",
        "--k_clusters",
        "20",
        "--max_good_per_class",
        str(args.max_good_per_class),
        "--max_defect_per_class",
        str(args.max_defect_per_class),
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--fp_weight",
        "0.3",
        "--scoring_mode",
        "logit_gate_posneg",
        "--refine_alpha",
        "0.3",
        "--refine_beta",
        "0.15",
        "--margin_norm_mode",
        "spatial_tanh_zscore",
        "--num_workers",
        str(args.num_workers),
        "--cpu_threads",
        str(args.cpu_threads),
        "--device",
        args.device,
        "--layer_recipe",
        layer_recipe,
        "--eval_metrics",
        *args.eval_metrics,
    ]
    return cmd, save_dir


def main() -> None:
    parser = argparse.ArgumentParser("Run AdaCLIP recipe fragility suite")
    parser.add_argument("--presets", nargs="+", default=["visa2mvtec", "mvtec2btad"])
    parser.add_argument("--layer_recipes", nargs="+", default=["all4", "last", "last2", "earlylate", "mid2"])
    parser.add_argument("--run_tag", type=str, default="pilot_v1")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--cuda_visible_devices", type=str, default="0")
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--cpu_threads", type=int, default=1)
    parser.add_argument("--max_good_per_class", type=int, default=200)
    parser.add_argument("--max_defect_per_class", type=int, default=80)
    parser.add_argument("--eval_metrics", nargs="+", default=["I-AUROC", "I-AP", "P-AUROC", "P-AP"])
    parser.add_argument("--class_name", type=str, default=None)
    args = parser.parse_args()

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = args.cuda_visible_devices
    env.setdefault("OMP_NUM_THREADS", str(args.cpu_threads))
    env.setdefault("OPENBLAS_NUM_THREADS", str(args.cpu_threads))
    env.setdefault("MKL_NUM_THREADS", str(args.cpu_threads))
    env.setdefault("NUMEXPR_NUM_THREADS", str(args.cpu_threads))
    env.setdefault("MPLCONFIGDIR", f"/tmp/matplotlib-adaclip-fragility-{args.run_tag}")

    for preset_name in args.presets:
        if preset_name not in PRESET_CONFIGS:
            raise ValueError(f"Unknown preset: {preset_name}")
        for layer_recipe in args.layer_recipes:
            cmd, save_dir = build_command(args, preset_name, layer_recipe)
            print("=" * 72, flush=True)
            print(f"preset={preset_name}", flush=True)
            print(f"layer_recipe={layer_recipe}", flush=True)
            print(f"save_dir={save_dir}", flush=True)
            print("=" * 72, flush=True)
            subprocess.run(cmd, check=True, env=env)


if __name__ == "__main__":
    main()
