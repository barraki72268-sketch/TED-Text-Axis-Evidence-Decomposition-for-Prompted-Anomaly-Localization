#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"

TARGETS = ("MVTec", "VisA", "MPDD", "BTAD")
TRANSFER_BY_TARGET = {
    "MVTec": "visa2mvtec",
    "VisA": "mvtec2visa",
    "MPDD": "mvtec2mpdd",
    "BTAD": "mvtec2btad",
}

METRICS = ("i_auc", "p_auc", "p_pro", "p_ap")


def load(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(v, already_percent: bool = False):
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    v = float(v)
    if already_percent:
        return v
    return v * 100.0 if abs(v) <= 1.5 else v


def vals_from_metric_dict(d: dict | None) -> dict[str, float | None] | None:
    if not isinstance(d, dict):
        return None
    scale_probes = [
        d.get("image_auroc", d.get("image_auc")),
        d.get("pixel_auroc", d.get("pixel_auc")),
    ]
    already_percent = any(v is not None and not (isinstance(v, float) and math.isnan(v)) and abs(float(v)) > 1.5 for v in scale_probes)
    return {
        "i_auc": pct(d.get("image_auroc", d.get("image_auc")), already_percent),
        "p_auc": pct(d.get("pixel_auroc", d.get("pixel_auc")), already_percent),
        "p_pro": pct(d.get("pixel_aupro", d.get("pixel_pro")), already_percent),
        "p_ap": pct(d.get("pixel_ap"), already_percent),
    }


def row_mode(summary: dict | None, mode: str) -> dict[str, float | None] | None:
    if summary is None:
        return None
    for row in summary.get("rows", []):
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return vals_from_metric_dict(row)
    return None


def mean_mode(summary: dict | None, mode: str) -> dict[str, float | None] | None:
    if summary is None:
        return None
    mean = summary.get("mean", summary)
    if not isinstance(mean, dict):
        return None
    return vals_from_metric_dict(mean.get(mode))


def nested_mean_mode(summary: dict | None, group: str, mode: str) -> dict[str, float | None] | None:
    if summary is None:
        return None
    mean = summary.get("mean", {})
    group_dict = mean.get(group)
    if not isinstance(group_dict, dict):
        return None
    return vals_from_metric_dict(group_dict.get(mode))


def average_dicts(items: list[dict[str, float | None] | None]) -> dict[str, float | None] | None:
    items = [x for x in items if x is not None]
    if not items:
        return None
    out = {}
    for key in METRICS:
        vals = [x[key] for x in items if x.get(key) is not None]
        out[key] = sum(vals) / len(vals) if vals else None
    return out


def add_records(records, host, backbone, target, base, tted, cted, source):
    if base is None:
        return
    for metric in METRICS:
        b = base.get(metric)
        t = None if tted is None else tted.get(metric)
        c = None if cted is None else cted.get(metric)
        records.append(
            {
                "host": host,
                "backbone": backbone,
                "target": target,
                "metric": metric,
                "baseline": b,
                "t_ted": t,
                "c_ted": c,
                "delta_t": None if b is None or t is None else t - b,
                "delta_c": None if b is None or c is None else c - b,
                "source": source,
            }
        )


def aaclip_records(records):
    rows = [
        ("vitb", "ViT-B/16+", "vitbplus"),
        ("vitl_openai", "ViT-L/14", "vitl_openai224"),
        ("vitl336", "ViT-L/14-336", "vitl336"),
        ("vith", "ViT-H/14", "vith14"),
    ]
    for _, backbone, tag in rows:
        for target in ("VisA", "MPDD", "BTAD"):
            transfer = TRANSFER_BY_TARGET[target]
            paths = [RESULTS / f"aaclip_hostres_official_{tag}_{transfer}_seed{seed}_pro_20260428" / "summary.json" for seed in range(3)]
            if tag == "vitbplus" and target == "BTAD":
                paths[0] = RESULTS / "aaclip_vitbplus_l3-6-9-12_mvtec2btad_subspace_hostres_rank8_preserve1_pro_20260428" / "summary.json"
            summaries = [load(p) for p in paths]
            base = average_dicts([mean_mode(s, "baseline") for s in summaries])
            tted = average_dicts([mean_mode(s, "parallel") for s in summaries])
            cted = average_dicts([nested_mean_mode(s, "candidates", "prescore_calibrated_alpha_1") for s in summaries])
            add_records(records, "AA-CLIP", backbone, target, base, tted, cted, "summary_json")


def adaclip_records(records):
    rows = [
        ("vitb16", "ViT-B/16+"),
        ("vitl14openai", "ViT-L/14"),
        ("vitl336", "ViT-L/14-336"),
        ("vith14", "ViT-H/14"),
    ]
    for tag, backbone in rows:
        for target in TARGETS:
            transfer = TRANSFER_BY_TARGET[target]
            summaries = [load(RESULTS / f"maintable_adaclip_{tag}_{transfer}_seed{seed}_20260429" / "summary.json") for seed in range(3)]
            base = average_dicts([row_mode(s, "baseline_txt") for s in summaries])
            tted = average_dicts([row_mode(s, "parallel_margin") for s in summaries])
            cted = average_dicts([row_mode(s, "ted_calibrated") for s in summaries])
            add_records(records, "AdaCLIP", backbone, target, base, tted, cted, "summary_json")


def adaptclip_records(records):
    rows = [
        ("vitb16plus", "ViT-B/16+"),
        ("vitl14openai", "ViT-L/14"),
        ("vitl336", "ViT-L/14-336"),
        ("vith14", "ViT-H/14"),
    ]
    for tag, backbone in rows:
        for target in TARGETS:
            transfer = TRANSFER_BY_TARGET[target]
            summaries = [load(RESULTS / f"adaptclip_dualbranch_{tag}_{transfer}_seed{seed}_20260429" / "summary.json") for seed in range(3)]
            base = average_dicts([row_mode(s, "baseline_txt") for s in summaries])
            tted = average_dicts([row_mode(s, "ted_trainfree_vl") for s in summaries])
            cted = average_dicts([row_mode(s, "ted_calibrated_vl") for s in summaries])
            add_records(records, "AdaptCLIP", backbone, target, base, tted, cted, "summary_json")


def bayespfl_records(records):
    rows = [
        ("vitb", "ViT-B/16+", RESULTS / "bayespfl_ted_vitbplus_swap_seeded_20260501"),
        ("vitl", "ViT-L/14", RESULTS / "bayespfl_ted_vitl_openai_swap_seeded_20260430"),
        ("vitl336", "ViT-L/14-336", RESULTS / "bayespfl_ted_official_mvtecsource_seeded_20260430"),
        ("vith", "ViT-H/14", RESULTS / "bayespfl_ted_vith14_swap_seeded_20260501"),
    ]
    transfer_by_target = {
        "MVTec": "mvtec2mvtec",
        "VisA": "mvtec2visa",
        "MPDD": "mvtec2mpdd",
        "BTAD": "mvtec2btad",
    }
    for _, backbone, root in rows:
        for target in TARGETS:
            transfer = transfer_by_target[target]
            summaries = [load(root / f"{transfer}_seed{seed}" / "summary.json") for seed in range(3)]
            base = average_dicts([row_mode(s, "baseline_txt") for s in summaries])
            tted = average_dicts([row_mode(s, "ted_trainfree") for s in summaries])
            cted = average_dicts([row_mode(s, "ted_calibrated") for s in summaries])
            add_records(records, "BayesPFL", backbone, target, base, tted, cted, "summary_json")


def faprompt_records(records):
    rows = [
        ("vitb16plus_f3-6-9-12_dpam10", "ViT-B/16+"),
        ("vitl14openai_f6-12-18-24_dpam20", "ViT-L/14"),
        ("vitl14_336_f6-12-18-24_dpam20", "ViT-L/14-336"),
        ("vith14_f8-16-24-32_dpam27", "ViT-H/14"),
    ]
    for tag, backbone in rows:
        for target in TARGETS:
            transfer = TRANSFER_BY_TARGET[target]
            paths: list[Path] = []
            if tag.startswith("vitb16plus"):
                # Seed 0 used the topkimg name; seeds 1-2 used officialimg.
                paths.append(RESULTS / f"faprompt_branchcal_{tag}_{transfer}_rank4_a02_topkimg_seed0_20260428" / "summary.json")
                paths.extend(RESULTS / f"faprompt_branchcal_{tag}_{transfer}_rank4_a02_officialimg_seed{seed}_20260428" / "summary.json" for seed in (1, 2))
            else:
                paths.append(RESULTS / f"faprompt_branchcal_{tag}_{transfer}_rank4_a02_officialimg_seed0_20260428" / "summary.json")
            summaries = [load(p) for p in paths]
            base = average_dicts([nested_mean_mode(s, "", "") for s in []])
            base = average_dicts([vals_from_metric_dict((s or {}).get("mean", {}).get("baseline_official")) for s in summaries])
            # These files are the source-calibrated branch C-TED runs; there is no same-protocol T-TED row.
            cted = average_dicts([nested_mean_mode(s, "parallel", "branch_calibrated_alpha_0.5") for s in summaries])
            add_records(records, "FAPrompt", backbone, target, base, None, cted, "summary_json; t_ted_missing_same_protocol")


def summarize(records):
    def fmt(v):
        return "--" if v is None else f"{v:.2f}"

    lines = []
    lines.append("| Group | N settings | Metric | B | T-TED | C-TED | Delta T | Delta C | Win T | Win C |")
    lines.append("|---|---:|---|---:|---:|---:|---:|---:|---:|---:|")
    for group_key in ("host", "backbone", "target"):
        values = sorted({r[group_key] for r in records})
        for value in values:
            for metric in ("p_pro", "p_auc", "p_ap", "i_auc"):
                subset = [r for r in records if r[group_key] == value and r["metric"] == metric and r["baseline"] is not None]
                if not subset:
                    continue
                bvals = [r["baseline"] for r in subset if r["baseline"] is not None]
                tvals = [r["t_ted"] for r in subset if r["t_ted"] is not None]
                cvals = [r["c_ted"] for r in subset if r["c_ted"] is not None]
                dt = [r["delta_t"] for r in subset if r["delta_t"] is not None]
                dc = [r["delta_c"] for r in subset if r["delta_c"] is not None]
                wt = [r["delta_t"] > 0 for r in subset if r["delta_t"] is not None]
                wc = [r["delta_c"] > 0 for r in subset if r["delta_c"] is not None]
                lines.append(
                    "| "
                    + " | ".join(
                        [
                            f"{group_key}:{value}",
                            str(len(subset)),
                            metric,
                            fmt(statistics.mean(bvals) if bvals else None),
                            fmt(statistics.mean(tvals) if tvals else None),
                            fmt(statistics.mean(cvals) if cvals else None),
                            fmt(statistics.mean(dt) if dt else None),
                            fmt(statistics.mean(dc) if dc else None),
                            fmt(100 * sum(wt) / len(wt) if wt else None),
                            fmt(100 * sum(wc) / len(wc) if wc else None),
                        ]
                    )
                    + " |"
                )
    return "\n".join(lines) + "\n"


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    aaclip_records(records)
    adaclip_records(records)
    adaptclip_records(records)
    bayespfl_records(records)
    faprompt_records(records)

    csv_path = OUT / "adapted_host_b_t_c_records_20260502.csv"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["host", "backbone", "target", "metric", "baseline", "t_ted", "c_ted", "delta_t", "delta_c", "source"],
        )
        writer.writeheader()
        writer.writerows(records)

    md_path = OUT / "adapted_host_b_t_c_summary_20260502.md"
    md_path.write_text(summarize(records))
    print({"records": len(records), "csv": str(csv_path), "summary": str(md_path)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
