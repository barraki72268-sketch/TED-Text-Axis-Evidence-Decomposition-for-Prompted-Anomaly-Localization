#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "fullfeature_memory_control_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "fullfeature_memory_control_20260504"


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_cmd(preset: str, device: str, seed: int) -> tuple[list[str], Path, Path]:
    save_dir = RESULTS / f"faprompt_vitl336_{preset}_fullfeat_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "fullfeat_replace,fullfeat_residual",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def write_worker(worker_id: int, jobs: list[dict], force: bool) -> Path:
    LOGS.mkdir(parents=True, exist_ok=True)
    worker_path = LOGS / f"fullfeature_worker_{worker_id}.py"
    payload = {"root": str(ROOT), "jobs": jobs, "force": bool(force)}
    worker_path.write_text(
        "from __future__ import annotations\n"
        "import json, subprocess\n"
        "from pathlib import Path\n\n"
        f"PAYLOAD = json.loads({json.dumps(json.dumps(payload))})\n\n"
        "root = Path(PAYLOAD['root'])\n"
        "for job in PAYLOAD['jobs']:\n"
        "    save_dir = Path(job['save_dir'])\n"
        "    summary = save_dir / 'summary.json'\n"
        "    if summary.exists() and not PAYLOAD['force']:\n"
        "        print(json.dumps({'stage': 'skip_done', 'summary': str(summary)}), flush=True)\n"
        "        continue\n"
        "    save_dir.mkdir(parents=True, exist_ok=True)\n"
        "    log_path = Path(job['log_path'])\n"
        "    log_path.parent.mkdir(parents=True, exist_ok=True)\n"
        "    print(json.dumps({'stage': 'job_start', 'save_dir': str(save_dir), 'log': str(log_path)}), flush=True)\n"
        "    with log_path.open('ab', buffering=0) as log_f:\n"
        "        proc = subprocess.run(job['cmd'], cwd=root, stdout=log_f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)\n"
        "    print(json.dumps({'stage': 'job_done', 'save_dir': str(save_dir), 'returncode': proc.returncode}), flush=True)\n"
    )
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--presets", default="mvtec2visa,mvtec2mpdd,mvtec2btad,visa2mvtec,visa2mpdd,visa2btad")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    presets = parse_csv(args.presets)
    devices = parse_csv(args.devices)
    buckets: list[list[dict]] = [[] for _ in devices]
    all_jobs = []
    for preset in presets:
        bucket_id = len(all_jobs) % len(devices)
        cmd, save_dir, log_path = build_cmd(preset, devices[bucket_id], args.seed)
        job = {"cmd": cmd, "save_dir": str(save_dir), "log_path": str(log_path), "preset": preset}
        buckets[bucket_id].append(job)
        all_jobs.append(job)

    launched = []
    for worker_id, jobs in enumerate(buckets):
        if not jobs:
            continue
        worker_path = write_worker(worker_id, jobs, args.force)
        worker_log = LOGS / f"fullfeature_worker_{worker_id}.log"
        log_f = worker_log.open("ab", buffering=0)
        proc = subprocess.Popen(
            [str(PY), "-u", str(worker_path)],
            cwd=ROOT,
            stdout=log_f,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        launched.append({"worker": worker_id, "pid": proc.pid, "device": devices[worker_id], "num_jobs": len(jobs), "log": str(worker_log)})
    print(json.dumps({"stage": "fullfeature_memory_control_queue", "num_jobs": len(all_jobs), "workers": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
