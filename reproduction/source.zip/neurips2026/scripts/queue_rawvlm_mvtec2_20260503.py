from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path

import queue_rawclip_calibrated_ted_trainfree_anchor_20260430 as raw_base


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
RESULT_ROOT = ROOT / "neurips2026/results/rawvlm_mvtec2_20260503"
LOG_ROOT = RESULT_ROOT / "_logs"
VIEW_ROOT = RESULT_ROOT / "mvtec_ad2_meta_view"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
DEFAULT_ARCHIVE = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/MVTec_AD_2_download/mvtec_ad_2.tar.gz")
DEFAULT_EXTRACT_DIR = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/MVTec_AD_2")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
KNOWN_CLASSES = {"can", "fabric", "fruit_jelly", "rice", "sheet_metal", "vial", "wallplugs", "walnuts"}
NORMAL_NAMES = {"good", "normal", "ok", "no_defect", "non_defective", "regular"}
MASK_HINTS = {"mask", "masks", "ground_truth", "groundtruth", "gt", "annotation", "annotations"}


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def wait_pid(pid: int, label: str) -> None:
    if pid <= 0:
        return
    while pid_alive(pid):
        print(json.dumps({"stage": "wait_pid", "label": label, "pid": pid}), flush=True)
        time.sleep(60)
    print(json.dumps({"stage": "wait_pid_done", "label": label, "pid": pid}), flush=True)


def wait_archive(archive: Path, download_pid: int) -> None:
    aria2_part = archive.with_name(archive.name + ".aria2")
    while True:
        size = archive.stat().st_size if archive.exists() else 0
        alive = pid_alive(download_pid)
        partial = aria2_part.exists()
        print(
            json.dumps(
                {
                    "stage": "wait_archive",
                    "archive": str(archive),
                    "bytes": int(size),
                    "download_pid": download_pid,
                    "download_alive": alive,
                    "partial_exists": partial,
                }
            ),
            flush=True,
        )
        if archive.exists() and size > 30_000_000_000 and not alive and not partial:
            return
        time.sleep(60)


def run(cmd: list[str], log_path: Path, cwd: Path | None = None, env: dict[str, str] | None = None) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print(json.dumps({"stage": "run", "log": str(log_path), "cmd": cmd}), flush=True)
    with log_path.open("w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=str(cwd or ROOT), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print(json.dumps({"stage": "done", "log": str(log_path), "returncode": proc.returncode}), flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def extract_archive(archive: Path, extract_dir: Path) -> None:
    marker = extract_dir / ".extract_done"
    if marker.exists():
        print(json.dumps({"stage": "skip_extract", "marker": str(marker)}), flush=True)
        return
    extract_dir.mkdir(parents=True, exist_ok=True)
    run(["tar", "-xzf", str(archive), "-C", str(extract_dir)], LOG_ROOT / "extract_mvtec_ad2.log", ROOT)
    marker.write_text(json.dumps({"archive": str(archive), "time": time.time()}), encoding="utf-8")


def is_image(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_EXTS


def has_images(path: Path) -> bool:
    try:
        return any(is_image(p) for p in path.rglob("*") if p.is_file())
    except OSError:
        return False


def find_dataset_root(extract_dir: Path) -> Path:
    candidates = [extract_dir]
    candidates.extend([p for p in extract_dir.iterdir() if p.is_dir()])
    for root in candidates:
        class_dirs = {p.name for p in root.iterdir() if p.is_dir() and has_images(p)}
        if len(class_dirs & KNOWN_CLASSES) >= 4:
            return root
    for root in extract_dir.rglob("*"):
        if not root.is_dir():
            continue
        try:
            class_dirs = {p.name for p in root.iterdir() if p.is_dir() and has_images(p)}
        except OSError:
            continue
        if len(class_dirs & KNOWN_CLASSES) >= 4:
            return root
    raise RuntimeError(f"could not find MVTec AD2 class root under {extract_dir}")


def path_has_hint(path: Path, hints: set[str]) -> bool:
    parts = {part.lower() for part in path.parts}
    return bool(parts & hints)


def choose_train_dir(class_dir: Path) -> Path | None:
    for name in ["train", "training"]:
        cand = class_dir / name
        if cand.exists():
            return cand
    matches = [p for p in class_dir.rglob("*") if p.is_dir() and p.name.lower() in {"train", "training"}]
    return matches[0] if matches else None


def choose_test_dir(class_dir: Path) -> Path | None:
    preferred = ["test_public", "public_test", "test", "testing", "validation", "val"]
    for name in preferred:
        cand = class_dir / name
        if cand.exists():
            return cand
    matches = [
        p
        for p in class_dir.rglob("*")
        if p.is_dir() and p.name.lower() in {"test_public", "public_test", "test", "testing", "validation", "val"}
    ]
    return matches[0] if matches else None


def find_mask_for_image(class_dir: Path, image_path: Path) -> Path | None:
    stem = image_path.stem
    img_parent = image_path.parent.name
    candidates = []
    for p in class_dir.rglob("*"):
        if not p.is_file() or not is_image(p):
            continue
        if not path_has_hint(p.parent, MASK_HINTS) and not path_has_hint(p, MASK_HINTS):
            continue
        if p.stem == stem or p.stem == f"{stem}_mask" or p.stem.startswith(stem + "_"):
            candidates.append(p)
        elif img_parent in p.parts and stem in p.stem:
            candidates.append(p)
    if not candidates:
        return None
    candidates = sorted(candidates, key=lambda p: (len(p.parts), len(p.name)))
    return candidates[0]


def normal_image(path: Path) -> bool:
    return path_has_hint(path.parent, NORMAL_NAMES) or path.parent.name.lower() in NORMAL_NAMES


def rel(root: Path, path: Path) -> str:
    return str(path.relative_to(root))


def build_meta(dataset_root: Path, view_root: Path) -> Path:
    view_root.mkdir(parents=True, exist_ok=True)
    meta: dict[str, dict[str, list[dict]]] = {"train": {}, "test": {}}
    stats = {}
    class_dirs = [p for p in dataset_root.iterdir() if p.is_dir() and p.name in KNOWN_CLASSES]
    if not class_dirs:
        class_dirs = [p for p in dataset_root.iterdir() if p.is_dir() and has_images(p)]
    for class_dir in sorted(class_dirs, key=lambda p: p.name):
        cls = class_dir.name
        train_dir = choose_train_dir(class_dir)
        test_dir = choose_test_dir(class_dir)
        if train_dir is None or test_dir is None:
            print(json.dumps({"stage": "skip_class_missing_split", "class": cls, "class_dir": str(class_dir)}), flush=True)
            continue

        train_items = []
        for img_path in sorted(p for p in train_dir.rglob("*") if p.is_file() and is_image(p)):
            if path_has_hint(img_path, MASK_HINTS):
                continue
            if not normal_image(img_path):
                continue
            train_items.append({"img_path": str(img_path), "mask_path": "", "cls_name": cls, "anomaly": 0})

        test_items = []
        missing_masks = 0
        for img_path in sorted(p for p in test_dir.rglob("*") if p.is_file() and is_image(p)):
            if path_has_hint(img_path, MASK_HINTS):
                continue
            anomaly = 0 if normal_image(img_path) else 1
            mask_path = ""
            if anomaly:
                mask = find_mask_for_image(class_dir, img_path)
                if mask is None:
                    missing_masks += 1
                    continue
                mask_path = str(mask)
            test_items.append({"img_path": str(img_path), "mask_path": mask_path, "cls_name": cls, "anomaly": anomaly})

        if train_items and test_items:
            meta["train"][cls] = train_items
            meta["test"][cls] = test_items
        stats[cls] = {
            "train": len(train_items),
            "test": len(test_items),
            "test_anomaly": sum(int(x["anomaly"]) for x in test_items),
            "missing_anomaly_masks": missing_masks,
        }
    if not meta["train"] or not meta["test"]:
        raise RuntimeError(f"failed to build usable meta for {dataset_root}; stats={stats}")
    (view_root / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    (view_root / "meta_build_stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {"stage": "meta_built", "dataset_root": str(dataset_root), "view_root": str(view_root), "stats": stats},
            indent=2,
        ),
        flush=True,
    )
    return view_root


def mvtec2_transfer(target_root: Path) -> dict[str, str]:
    return {
        "name": "mvtec2mvtecad2",
        "source_root": MVTEC_ROOT,
        "source_dataset": "mvtec",
        "target_root": str(target_root),
        "target_dataset": "mvtec_ad2",
    }


def clip_cmd(backbone: dict[str, str], transfer: dict[str, str]) -> list[str]:
    cmd = raw_base.base.clip_cmd(backbone, transfer) if hasattr(raw_base, "base") else raw_base.clip_cmd(backbone, transfer)
    cmd[cmd.index("--save_dir") + 1] = str(RESULT_ROOT / f"rawclip_{backbone['tag']}_{transfer['name']}")
    if "--calib_anchor" not in cmd:
        cmd.extend(["--calib_anchor", "trainfree"])
    return cmd


def imagebind_cmd(transfer: dict[str, str]) -> list[str]:
    cmd = raw_base.base.imagebind_cmd(transfer) if hasattr(raw_base, "base") else raw_base.imagebind_cmd(transfer)
    cmd[cmd.index("--save_dir") + 1] = str(RESULT_ROOT / f"rawimagebind_{transfer['name']}")
    if "--calib_anchor" not in cmd:
        cmd.extend(["--calib_anchor", "trainfree"])
    return cmd


def run_one(name: str, cmd: list[str], gpu: str) -> None:
    summary_path = Path(cmd[cmd.index("--save_dir") + 1]) / "summary.json"
    if summary_path.exists():
        print(json.dumps({"stage": "skip_existing", "job": name, "summary": str(summary_path)}), flush=True)
        return
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(gpu)
    env["PYTHONUNBUFFERED"] = "1"
    run(cmd, LOG_ROOT / f"{name}.log", ROOT, env)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", default="0")
    parser.add_argument("--download-pid", type=int, default=0)
    parser.add_argument("--wait-pid", type=int, action="append", default=[])
    parser.add_argument("--archive", type=Path, default=DEFAULT_ARCHIVE)
    parser.add_argument("--extract-dir", type=Path, default=DEFAULT_EXTRACT_DIR)
    args = parser.parse_args()

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)

    wait_archive(args.archive, args.download_pid)
    extract_archive(args.archive, args.extract_dir)
    dataset_root = find_dataset_root(args.extract_dir)
    target_root = build_meta(dataset_root, VIEW_ROOT)
    for pid in args.wait_pid:
        wait_pid(pid, "gpu_wait")

    transfer = mvtec2_transfer(target_root)
    for backbone in raw_base.base.CLIP_BACKBONES if hasattr(raw_base, "base") else raw_base.CLIP_BACKBONES:
        run_one(f"rawclip_{backbone['tag']}_{transfer['name']}", clip_cmd(backbone, transfer), args.gpu)
    run_one(f"rawimagebind_{transfer['name']}", imagebind_cmd(transfer), args.gpu)
    print(json.dumps({"stage": "rawvlm_mvtec2_done", "result_root": str(RESULT_ROOT), "target_root": str(dataset_root)}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
