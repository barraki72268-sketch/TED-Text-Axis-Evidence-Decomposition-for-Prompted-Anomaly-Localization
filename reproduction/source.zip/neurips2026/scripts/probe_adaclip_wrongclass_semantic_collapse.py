from __future__ import annotations

import argparse
import csv
import gc
import json
import math
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADA_SCRIPT_ROOT = ROOT / "neurips2026" / "AdaCLIP"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"
VISA_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"
MVTEC_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"

if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ADA_SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(ADA_SCRIPT_ROOT))

from official_parallel_test_adaclip import build_model, build_target_dataset, compute_baseline_outputs, smooth_map  # noqa: E402


def validate_visa_root(root: str, dataset_name: str) -> None:
    if dataset_name.lower() != "visa":
        return
    resolved = Path(root).resolve()
    official = OFFICIAL_VISA_ROOT.resolve()
    if resolved != official:
        raise ValueError(
            "VisA experiments must use the official root only: "
            f"{official}. Got: {resolved}"
        )


def current_rss_mb() -> float:
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    parts = line.split()
                    if len(parts) >= 2:
                        return float(parts[1]) / 1024.0
    except OSError:
        pass
    return float("nan")


def cleanup_image_state(device: str) -> None:
    gc.collect()
    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()


def mean_ignoring_nan(values: list[float]) -> float:
    vals = [v for v in values if np.isfinite(v)]
    if not vals:
        return float("nan")
    return float(np.mean(vals))


def rank_1_based_desc(values: dict[str, float], target_key: str) -> int:
    ordered = sorted(values.items(), key=lambda kv: kv[1], reverse=True)
    for idx, (key, _) in enumerate(ordered, start=1):
        if key == target_key:
            return idx
    return len(ordered)


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def top_fraction_mask(score_map: np.ndarray, frac: float) -> np.ndarray:
    flat = score_map.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    thresh = np.partition(flat, -k)[-k]
    return score_map >= thresh


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    inter = float(np.logical_and(a, b).sum())
    union = float(np.logical_or(a, b).sum())
    if union <= 0:
        return float("nan")
    return inter / union


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def safe_corr(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float32).reshape(-1)
    y = np.asarray(b, dtype=np.float32).reshape(-1)
    if x.size < 2 or y.size < 2:
        return float("nan")
    sx = float(np.std(x))
    sy = float(np.std(y))
    if sx < 1e-12 or sy < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def append_partial_row(save_dir: Path, row: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.jsonl", "a") as f:
        f.write(json.dumps(row) + "\n")


def write_progress(save_dir: Path, payload: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "progress.json", "w") as f:
        json.dump(payload, f, indent=2)


def save_outputs(summary: dict, rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def resolve_preset(args) -> None:
    preset = args.preset
    if preset is None:
        return
    if preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtec"
    elif preset == "mvtec2visa":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif preset == "mvtec2btad":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {preset}")


def static_text_features(model, cls_name: str) -> torch.Tensor:
    clip_model = model.clip_model
    prompt_enabled = clip_model.text_prompter.enabled
    clip_model.text_prompter.enabled = False
    try:
        with torch.no_grad():
            text_features = clip_model.static_text_embedding_layer(clip_model, [cls_name], clip_model.device)
            text_features = F.normalize(text_features.float(), dim=1)
    finally:
        clip_model.text_prompter.enabled = prompt_enabled
    return text_features


def static_prompt_map_and_score(model, baseline: dict, prompt_cls: str, sigma: float) -> tuple[np.ndarray, float]:
    text_features = static_text_features(model, prompt_cls)
    score_map, image_score = model.clip_model.visual_text_similarity(
        baseline["image_features"],
        baseline["patch_tokens"],
        text_features,
        aggregation=True,
    )
    score_map = smooth_map(score_map.squeeze(1), sigma=sigma).cpu().numpy()[0]
    return score_map, float(image_score[0].item())


def main():
    parser = argparse.ArgumentParser("Wrong-class prompt semantic attenuation audit for AdaCLIP")
    parser.add_argument("--preset", type=str, default=None, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument("--candidate_classes", nargs="*", default=None)
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=1)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--progress_every", type=int, default=1)
    parser.add_argument("--cpu_threads", type=int, default=1)
    parser.add_argument("--prompting_depth", type=int, default=4)
    parser.add_argument("--prompting_length", type=int, default=5)
    parser.add_argument("--prompting_branch", type=str, default="VL")
    parser.add_argument("--prompting_type", type=str, default="SD")
    parser.add_argument("--use_hsf", type=lambda x: x.lower() in {"1", "true", "yes"}, default=True)
    parser.add_argument("--k_clusters", type=int, default=20)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_wrongclass_semantic_collapse"),
    )
    args = parser.parse_args()

    resolve_preset(args)
    torch.set_num_threads(max(1, int(args.cpu_threads)))
    try:
        torch.set_num_interop_threads(max(1, int(args.cpu_threads)))
    except RuntimeError:
        pass

    device = args.device
    validate_visa_root(args.target_root, args.target_dataset)
    model = build_model(
        device=device,
        checkpoint_path=args.checkpoint_path,
        image_size=args.image_size,
        prompting_depth=args.prompting_depth,
        prompting_length=args.prompting_length,
        prompting_branch=args.prompting_branch,
        prompting_type=args.prompting_type,
        use_hsf=args.use_hsf,
        k_clusters=args.k_clusters,
    )
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "model_ready",
                "pid": os.getpid(),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )

    save_dir = Path(args.save_dir)
    write_progress(
        save_dir,
        {
            "event": "start",
            "pid": os.getpid(),
            "preset": args.preset,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "candidate_classes": args.candidate_classes,
            "max_anomaly_images_per_class": args.max_anomaly_images_per_class,
            "rss_mb": round(current_rss_mb(), 2),
        },
    )

    dataset = build_target_dataset(args.target_root, args.target_dataset, model, training=False, class_name=None)
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "dataset_ready",
                "pid": os.getpid(),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )
    target_classes = set(args.target_classes) if args.target_classes else set(dataset.cls_names)
    candidate_classes = sorted(dict.fromkeys(args.candidate_classes or list(dataset.cls_names)))
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "candidate_classes_ready",
                "pid": os.getpid(),
                "candidate_count": len(candidate_classes),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )
    cleanup_image_state(device)

    rows: list[dict] = []
    per_class_seen = {cls: 0 for cls in dataset.cls_names}
    target_class_list = sorted(target_classes)

    with torch.inference_mode():
        for idx in range(len(dataset)):
            if all(per_class_seen.get(cls, 0) >= args.max_anomaly_images_per_class for cls in target_class_list):
                break
            item = dataset[idx]
            cls_name = item["cls_name"]
            if cls_name not in target_classes:
                continue
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            if int(anomaly_flag) == 0:
                continue
            if per_class_seen[cls_name] >= args.max_anomaly_images_per_class:
                continue
            per_class_seen[cls_name] += 1
            if args.progress_every > 0:
                print(
                    json.dumps(
                        {
                            "event": "image_start",
                            "pid": os.getpid(),
                            "dataset_index": idx,
                            "class_name": cls_name,
                            "rows_done": len(rows),
                            "rss_mb": round(current_rss_mb(), 2),
                        }
                    ),
                    flush=True,
                )

            image = item["img"].unsqueeze(0).to(device)
            mask_tensor = item["img_mask"]
            if torch.is_tensor(mask_tensor):
                gt_mask = mask_tensor.squeeze().detach().cpu().numpy() > 0.5
            else:
                gt_mask = np.asarray(mask_tensor).squeeze() > 0.5
            if not gt_mask.any():
                continue

            baseline = compute_baseline_outputs(model, image, cls_name, args.sigma)
            learned_map = baseline["baseline_map"].cpu().numpy()[0]
            learned_image_score = float(baseline["baseline_img_score"][0].item())

            prompt_image_scores: dict[str, float] = {}
            prompt_local_auc: dict[str, float] = {}
            true_map, true_image_score = static_prompt_map_and_score(model, baseline, cls_name, args.sigma)
            prompt_image_scores[cls_name] = true_image_score
            prompt_local_auc[cls_name] = safe_auc(true_map[gt_mask], true_map[~gt_mask])
            true_mask = top_fraction_mask(true_map, args.map_topk)
            learned_mask = top_fraction_mask(learned_map, args.map_topk)

            wrong_classes = [name for name in candidate_classes if name != cls_name]
            wrong_corr: list[float] = []
            wrong_overlap: list[float] = []
            wrong_iou: list[float] = []
            wrong_image_scores: list[float] = []
            wrong_local_auc: list[float] = []
            learned_vs_wrong_corr: list[float] = []
            learned_vs_wrong_overlap: list[float] = []

            for prompt_cls in wrong_classes:
                score_map, image_score = static_prompt_map_and_score(model, baseline, prompt_cls, args.sigma)
                prompt_image_scores[prompt_cls] = image_score
                prompt_local_auc[prompt_cls] = safe_auc(score_map[gt_mask], score_map[~gt_mask])
                wrong_image_scores.append(prompt_image_scores[prompt_cls])
                wrong_local_auc.append(prompt_local_auc[prompt_cls])
                wrong_corr.append(safe_corr(true_map, score_map))
                wrong_mask = top_fraction_mask(score_map, args.map_topk)
                wrong_overlap.append(mask_overlap(true_mask, wrong_mask))
                wrong_iou.append(mask_iou(true_mask, wrong_mask))
                learned_vs_wrong_corr.append(safe_corr(learned_map, score_map))
                learned_vs_wrong_overlap.append(mask_overlap(learned_mask, wrong_mask))
                del score_map, wrong_mask
                cleanup_image_state(device)

            row = {
                "image_id": idx,
                "class_name": cls_name,
                "candidate_count": len(candidate_classes),
                "true_prompt_image_score": prompt_image_scores[cls_name],
                "true_prompt_local_auc": prompt_local_auc[cls_name],
                "true_prompt_rank_image": rank_1_based_desc(prompt_image_scores, cls_name),
                "true_prompt_rank_local": rank_1_based_desc(prompt_local_auc, cls_name),
                "true_minus_wrong_mean_image": float(prompt_image_scores[cls_name] - np.mean(wrong_image_scores)),
                "true_minus_wrong_mean_local_auc": float(prompt_local_auc[cls_name] - np.mean(wrong_local_auc)),
                "mean_true_wrong_corr": mean_ignoring_nan(wrong_corr),
                "mean_true_wrong_topk_overlap": mean_ignoring_nan(wrong_overlap),
                "mean_true_wrong_topk_iou": mean_ignoring_nan(wrong_iou),
                "learned_image_score": learned_image_score,
                "learned_vs_true_corr": safe_corr(learned_map, true_map),
                "learned_vs_mean_wrong_corr": mean_ignoring_nan(learned_vs_wrong_corr),
                "learned_vs_true_topk_overlap": mask_overlap(learned_mask, true_mask),
                "learned_vs_mean_wrong_topk_overlap": mean_ignoring_nan(learned_vs_wrong_overlap),
            }
            rows.append(row)
            append_partial_row(save_dir, row)
            write_progress(
                save_dir,
                {
                    "event": "row_saved",
                    "pid": os.getpid(),
                    "dataset_index": idx,
                    "rows_done": len(rows),
                    "class_name": cls_name,
                    "rss_mb": round(current_rss_mb(), 2),
                },
            )
            if args.progress_every > 0 and (len(rows) % args.progress_every == 0):
                print(
                    json.dumps(
                        {
                            "event": "image_done",
                            "pid": os.getpid(),
                            "dataset_index": idx,
                            "rows_done": len(rows),
                            "class_name": cls_name,
                            "rss_mb": round(current_rss_mb(), 2),
                        }
                    ),
                    flush=True,
                )
            del image, baseline, learned_map, true_map, true_mask, learned_mask
            cleanup_image_state(device)

    num_classes = len(candidate_classes)
    image_top1 = [1.0 if r["true_prompt_rank_image"] == 1 else 0.0 for r in rows]
    local_top1 = [1.0 if r["true_prompt_rank_local"] == 1 else 0.0 for r in rows]
    summary = {
        "settings": {
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "target_classes": sorted(target_classes),
            "candidate_classes": candidate_classes,
            "map_topk": args.map_topk,
            "sigma": args.sigma,
            "prompting_depth": args.prompting_depth,
            "prompting_length": args.prompting_length,
            "prompting_branch": args.prompting_branch,
            "prompting_type": args.prompting_type,
            "use_hsf": args.use_hsf,
            "k_clusters": args.k_clusters,
        },
        "summary": {
            "num_images": len(rows),
            "num_candidate_classes": num_classes,
            "chance_top1_rate": 1.0 / max(1, num_classes),
            "true_prompt_top1_rate_image": mean_ignoring_nan(image_top1),
            "true_prompt_top1_rate_local": mean_ignoring_nan(local_top1),
            "true_prompt_mean_rank_image": mean_ignoring_nan([float(r["true_prompt_rank_image"]) for r in rows]),
            "true_prompt_mean_rank_local": mean_ignoring_nan([float(r["true_prompt_rank_local"]) for r in rows]),
            "mean_true_minus_wrong_image": mean_ignoring_nan([r["true_minus_wrong_mean_image"] for r in rows]),
            "mean_true_minus_wrong_local_auc": mean_ignoring_nan([r["true_minus_wrong_mean_local_auc"] for r in rows]),
            "mean_true_wrong_corr": mean_ignoring_nan([r["mean_true_wrong_corr"] for r in rows]),
            "mean_true_wrong_topk_overlap": mean_ignoring_nan([r["mean_true_wrong_topk_overlap"] for r in rows]),
            "mean_true_wrong_topk_iou": mean_ignoring_nan([r["mean_true_wrong_topk_iou"] for r in rows]),
            "mean_learned_vs_true_corr": mean_ignoring_nan([r["learned_vs_true_corr"] for r in rows]),
            "mean_learned_vs_wrong_corr": mean_ignoring_nan([r["learned_vs_mean_wrong_corr"] for r in rows]),
            "mean_learned_vs_true_topk_overlap": mean_ignoring_nan([r["learned_vs_true_topk_overlap"] for r in rows]),
            "mean_learned_vs_wrong_topk_overlap": mean_ignoring_nan([r["learned_vs_mean_wrong_topk_overlap"] for r in rows]),
            "semantic_gap_top1": mean_ignoring_nan(image_top1) - mean_ignoring_nan(local_top1),
            "semantic_gap_rank": mean_ignoring_nan([float(r["true_prompt_rank_local"]) for r in rows])
            - mean_ignoring_nan([float(r["true_prompt_rank_image"]) for r in rows]),
            "learned_true_wrong_corr_gap": mean_ignoring_nan([r["learned_vs_mean_wrong_corr"] for r in rows])
            - mean_ignoring_nan([r["learned_vs_true_corr"] for r in rows]),
            "learned_true_wrong_topk_overlap_gap": mean_ignoring_nan([r["learned_vs_mean_wrong_topk_overlap"] for r in rows])
            - mean_ignoring_nan([r["learned_vs_true_topk_overlap"] for r in rows]),
        },
    }
    save_outputs(summary, rows, save_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
