#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT = ROOT / "neurips2026/results/recipe_entanglement_diagnostic_20260503"
LOG = OUT / "logs"
FAP_EVAL = ROOT / "neurips2026/scripts/official_parallel_test_faprompt.py"
FAP_ROOT = ROOT / "neurips2026/FAPrompt"
FAP_OFFICIAL_VISA = FAP_ROOT / "checkpoints/trained_on_visa/epoch_15.pth"
FAP_RETRAIN_ROOT = ROOT / "neurips2026/results/faprompt_layer_recipe_retrained_20260502"


RECIPES = {
    "all4_official": {
        "checkpoint": FAP_OFFICIAL_VISA,
        "features": [6, 12, 18, 24],
    },
    "earlylate": {
        "checkpoint": FAP_RETRAIN_ROOT / "faprompt_visa_earlylate_ckpt/epoch_15.pth",
        "features": [6, 24],
    },
    "last2": {
        "checkpoint": FAP_RETRAIN_ROOT / "faprompt_visa_last2_ckpt/epoch_15.pth",
        "features": [18, 24],
    },
    "last": {
        "checkpoint": FAP_RETRAIN_ROOT / "faprompt_visa_last_ckpt/epoch_15.pth",
        "features": [24],
    },
}


def run(cmd: list[str], log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print(json.dumps({"stage": "run", "cmd": " ".join(cmd), "log": str(log_path)}), flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print(json.dumps({"stage": "done", "returncode": proc.returncode, "log": str(log_path)}), flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = env.get("CUDA_VISIBLE_DEVICES", "0")
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-recipe-entanglement-20260503")

    for recipe, spec in RECIPES.items():
        save_dir = OUT / f"faprompt_visa2mvtec_{recipe}"
        summary = save_dir / "summary.json"
        if summary.exists():
            print(json.dumps({"stage": "skip", "recipe": recipe, "summary": str(summary)}), flush=True)
            continue
        checkpoint = Path(spec["checkpoint"])
        if not checkpoint.exists():
            raise FileNotFoundError(checkpoint)
        cmd = [
            str(PY),
            "-u",
            str(FAP_EVAL),
            "--preset",
            "visa2mvtec",
            "--checkpoint_path",
            str(checkpoint),
            "--save_dir",
            str(save_dir),
            "--model_name",
            "ViT-L/14@336px",
            "--prompt_load_mode",
            "strict",
            "--features_list",
            *[str(x) for x in spec["features"]],
            "--image_size",
            "518",
            "--batch_size",
            "2",
            "--num_workers",
            "4",
            "--dap_token_mode",
            "official_firstk",
            "--dpam_layer",
            "20",
            "--max_fp_per_class",
            "512",
            "--max_defect_per_class",
            "512",
            "--max_fp_total",
            "4096",
            "--max_defect_total",
            "4096",
            "--normal_topk_frac",
            "0.01",
            "--tau",
            "0.1",
            "--fp_weight",
            "1.0",
            "--alphas",
            "1.0",
            "--ours_image_score_mode",
            "official",
            "--insert_modes",
            "branch_calibrated",
            "--prescore_calib_epochs",
            "30",
            "--prescore_calib_lr",
            "0.02",
            "--prescore_calib_max_train_points",
            "2048",
            "--prescore_calib_alpha_init",
            "0.05",
            "--prescore_calib_alpha_max",
            "0.2",
            "--prescore_calib_subspace_rank",
            "4",
            "--aupro_max_step",
            "50",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--report_group_separability",
            "--separability_hard_frac",
            "0.01",
        ]
        run(cmd, LOG / f"faprompt_visa2mvtec_{recipe}.log", env)

    print(json.dumps({"stage": "done", "root": str(OUT)}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
