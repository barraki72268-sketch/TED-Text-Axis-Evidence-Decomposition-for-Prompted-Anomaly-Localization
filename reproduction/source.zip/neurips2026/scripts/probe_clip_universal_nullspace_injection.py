from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_abnormal_prompts,
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["capsules", "candle"])
    parser.add_argument(
        "--class_summary_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "clip_kin_split_allvisa_analysis" / "class_best_summary.csv"),
    )
    parser.add_argument("--alphas", nargs="+", type=float, default=[0.1, 0.5, 1.0])
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_universal_nullspace_injection")
    return parser.parse_args()


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def load_class_settings(csv_path: str) -> dict[str, dict[str, int | str]]:
    settings: dict[str, dict[str, int | str]] = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            settings[row["class_name"]] = {
                "best_layer": int(row["best_layer"]),
                "best_k": int(row["best_k"]),
                "group": row["group"],
            }
    return settings


def build_text_anchor(backbone, class_name: str, abnormal: bool) -> torch.Tensor:
    state_prompts = state_level_abnormal_prompts if abnormal else state_level_normal_prompts
    class_text = class_name.replace("_", " ")
    prompts: list[str] = []
    for template in template_level_prompts:
        for state_prompt in state_prompts:
            prompts.append(template.format(state_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = backbone.visual.proj.detach().float().to(text_anchor.device)
    token_anchor = proj @ text_anchor
    return F.normalize(token_anchor, dim=0)


def get_null_space_residual(V: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    V = V.float()
    V_proj = (V @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return V - V_proj


def forward_up_to_layer(model, image: torch.Tensor, layer_idx: int) -> tuple[torch.Tensor, torch.Tensor]:
    sequence = model.prepare_sequence(image)
    seq_mid = model.run_blocks(sequence, start_layer=1, end_layer=layer_idx)
    batch_mid = seq_mid.permute(1, 0, 2)
    cls_token = batch_mid[:, :1, :].float()
    v_mid = batch_mid[:, 1:, :].float()
    return v_mid, cls_token


def forward_remaining(model, v_mid: torch.Tensor, cls_token: torch.Tensor, layer_idx: int) -> torch.Tensor:
    batch_seq = torch.cat([cls_token, v_mid], dim=1)
    sequence = batch_seq.permute(1, 0, 2)
    seq_final = model.run_blocks(sequence, start_layer=layer_idx + 1, end_layer=model.num_layers)
    final_batch = seq_final.permute(1, 0, 2)
    final_batch = model.visual.ln_post(final_batch)
    return F.normalize(final_batch[:, 1:, :].float(), dim=-1)


def get_text_guided_gradient(
    model,
    v_mid_detached: torch.Tensor,
    cls_token: torch.Tensor,
    delta_p: torch.Tensor,
    layer_idx: int,
) -> torch.Tensor:
    v_mid = v_mid_detached.clone().detach().requires_grad_(True)
    v_final = forward_remaining(model, v_mid, cls_token, layer_idx)
    score = (v_final @ delta_p).sum()
    g = torch.autograd.grad(score, v_mid, retain_graph=False, create_graph=False)[0]
    return g.detach()


def inject_null_space_trajectory(
    v_mid_detached: torch.Tensor,
    g: torch.Tensor,
    p_norm: torch.Tensor,
    alpha: float,
) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    g_parallel = (g @ p_norm).unsqueeze(-1) * p_norm.view(1, 1, -1)
    delta_v_optimal = g - g_parallel
    return v_mid_detached + float(alpha) * delta_v_optimal


def compute_final_scores(v_final: torch.Tensor, p_norm: torch.Tensor, delta_p: torch.Tensor) -> np.ndarray:
    residual = get_null_space_residual(v_final, p_norm)
    return (residual @ delta_p).cpu().numpy()


def collect_class_cache(backbone, class_name: str, inject_layer: int, args: argparse.Namespace, device: str) -> list[dict]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    cache: list[dict] = []
    for idx, rec in enumerate(ds.records):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            v_mid, cls_token = forward_up_to_layer(backbone, image_t, inject_layer)
            v_final = forward_remaining(backbone, v_mid, cls_token, inject_layer)
        cache.append(
            {
                "index": idx,
                "name": name,
                "img_type": img_type,
                "label": int(label != 0),
                "patch_mask": to_patch_mask(mask_np, backbone.grid_size, device),
                "v_mid": v_mid[0].detach().cpu(),
                "cls_token": cls_token.detach().cpu(),
                "v_final_base": v_final[0].detach().cpu(),
            }
        )
    return cache


def evaluate_class(
    backbone,
    cache: list[dict],
    p_norm: torch.Tensor,
    delta_p: torch.Tensor,
    inject_layer: int,
    alpha: float,
    device: str,
    topk_ratio: float,
) -> dict[str, float]:
    patch_labels: list[int] = []
    base_patch_scores: list[float] = []
    inj_patch_scores: list[float] = []
    image_labels: list[int] = []
    base_image_scores: list[float] = []
    inj_image_scores: list[float] = []
    base_sem_vals: list[float] = []
    inj_sem_vals: list[float] = []

    for rec in cache:
        v_final_base = rec["v_final_base"]
        base_scores = compute_final_scores(v_final_base, p_norm, delta_p)

        v_mid = rec["v_mid"].unsqueeze(0).to(device)
        cls_token = rec["cls_token"].to(device)
        with torch.enable_grad():
            g = get_text_guided_gradient(backbone, v_mid, cls_token, delta_p.to(device), inject_layer)
            v_injected = inject_null_space_trajectory(v_mid.detach(), g, p_norm.to(device), alpha)
            v_final_inj = forward_remaining(backbone, v_injected, cls_token, inject_layer)[0]
        v_final_inj = v_final_inj.detach().cpu()
        inj_scores = compute_final_scores(v_final_inj, p_norm, delta_p)

        patch_mask = rec["patch_mask"].astype(np.int64)
        patch_labels.extend(patch_mask.tolist())
        base_patch_scores.extend(base_scores.tolist())
        inj_patch_scores.extend(inj_scores.tolist())
        image_labels.append(int(rec["label"]))
        base_image_scores.append(topk_mean(base_scores, topk_ratio))
        inj_image_scores.append(topk_mean(inj_scores, topk_ratio))

        base_sem_vals.append(float((v_final_base @ p_norm).mean().item()))
        inj_sem_vals.append(float((v_final_inj @ p_norm).mean().item()))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    inj_patch_auc = safe_auc(patch_labels, inj_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    inj_image_auc = safe_auc(image_labels, inj_image_scores)
    return {
        "base_patch_auc": base_patch_auc,
        "inj_patch_auc": inj_patch_auc,
        "patch_auc_delta": inj_patch_auc - base_patch_auc,
        "base_image_auc": base_image_auc,
        "inj_image_auc": inj_image_auc,
        "image_auc_delta": inj_image_auc - base_image_auc,
        "base_semantic_sim": float(np.mean(base_sem_vals)),
        "inj_semantic_sim": float(np.mean(inj_sem_vals)),
        "semantic_drop": float(np.mean(np.asarray(inj_sem_vals) - np.asarray(base_sem_vals))),
    }


def save_plots(summary_rows: list[dict], out_dir: Path, tag: str) -> None:
    classes = list(dict.fromkeys(row["class_name"] for row in summary_rows))
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), sharex=True)
    for cls in classes:
        cls_rows = sorted([row for row in summary_rows if row["class_name"] == cls], key=lambda x: float(x["alpha"]))
        xs = [float(row["alpha"]) for row in cls_rows]
        patch_delta = [float(row["patch_auc_delta"]) for row in cls_rows]
        image_delta = [float(row["image_auc_delta"]) for row in cls_rows]
        label = f"{cls} ({cls_rows[0]['group']})"
        axes[0].plot(xs, patch_delta, marker="o", label=label)
        axes[1].plot(xs, image_delta, marker="o", label=label)
    axes[0].axhline(0.0, color="black", linewidth=1.0, alpha=0.5)
    axes[1].axhline(0.0, color="black", linewidth=1.0, alpha=0.5)
    axes[0].set_title("Patch AUC Delta")
    axes[1].set_title("Image AUC Delta")
    axes[0].set_xlabel("alpha")
    axes[1].set_xlabel("alpha")
    axes[0].grid(True, alpha=0.3)
    axes[1].grid(True, alpha=0.3)
    axes[0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_dir / f"{tag}_delta_curves.png", dpi=180)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    class_settings = load_class_settings(args.class_summary_csv)
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    summary_rows: list[dict] = []
    for class_name in args.class_names:
        setting = class_settings[class_name]
        inject_layer = int(setting["best_layer"])
        group = str(setting["group"])
        p_norm = build_text_anchor(backbone, class_name, abnormal=False).cpu()
        p_anom = build_text_anchor(backbone, class_name, abnormal=True).cpu()
        delta_p = F.normalize(p_anom - p_norm, dim=0).cpu()
        cache = collect_class_cache(backbone, class_name, inject_layer, args, device)
        for alpha in args.alphas:
            metrics = evaluate_class(
                backbone=backbone,
                cache=cache,
                p_norm=p_norm,
                delta_p=delta_p,
                inject_layer=inject_layer,
                alpha=float(alpha),
                device=device,
                topk_ratio=args.topk_ratio,
            )
            summary_rows.append(
                {
                    "class_name": class_name,
                    "group": group,
                    "inject_layer": inject_layer,
                    "alpha": float(alpha),
                    **metrics,
                }
            )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    stem = f"{args.output_tag}_{class_tag}"
    summary_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_summary.json"
    with summary_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    with json_path.open("w") as f:
        json.dump({"summary_rows": summary_rows, "config": vars(args)}, f, indent=2)

    save_plots(summary_rows, out_dir, stem)
    print(summary_path)
    print(json_path)
    print(json.dumps(summary_rows, indent=2))


if __name__ == "__main__":
    main()
