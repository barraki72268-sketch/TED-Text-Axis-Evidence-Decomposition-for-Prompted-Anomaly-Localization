#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_adaclip.py"
RESULT_ROOT="${ROOT}/neurips2026/results"
RUN_TAG="${1:-$(date +%Y%m%d_%H%M%S)}"
STATUS_FILE="${RESULT_ROOT}/adaclip_cleanbank_queue_gpu1_${RUN_TAG}.status"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

: > "${STATUS_FILE}"

run_job() {
  local name="$1"
  shift
  echo "============================================================"
  echo "job=${name}"
  echo "run_tag=${RUN_TAG}"
  echo "============================================================"
  if CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" "$@"; then
    echo "${name} OK" | tee -a "${STATUS_FILE}"
  else
    echo "${name} FAIL" | tee -a "${STATUS_FILE}"
  fi
}

run_job visa2mvtec \
  --source_root "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  --source_dataset visa \
  --target_root "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  --target_dataset mvtec \
  --checkpoint_path "${ROOT}/neurips2026/AdaCLIP/ckpt/pretrained_visa_clinicdb.pth" \
  --save_dir "${RESULT_ROOT}/official_parallel_test_adaclip_cleanbank_gate_visa2mvtec_all_gpu1_${RUN_TAG}" \
  --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/adaclip_visa_clean_multilayer.pt" \
  --fp_weight 0.3 \
  --scoring_mode logit_gate_posneg \
  --refine_alpha 0.3 \
  --refine_beta 0.15 \
  --margin_norm_mode spatial_tanh_zscore \
  --max_good_per_class 200 \
  --max_defect_per_class 80 \
  --num_workers 8 \
  --cpu_threads 1 \
  --device cuda:0

run_job mvtec2visa \
  --source_root "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  --source_dataset mvtec \
  --target_root "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  --target_dataset visa \
  --checkpoint_path "${ROOT}/neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth" \
  --save_dir "${RESULT_ROOT}/official_parallel_test_adaclip_cleanbank_gate_mvtec2visa_all_gpu1_${RUN_TAG}" \
  --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/adaclip_mvtec_clean_multilayer.pt" \
  --fp_weight 0.3 \
  --scoring_mode logit_gate_posneg \
  --refine_alpha 0.3 \
  --refine_beta 0.15 \
  --margin_norm_mode spatial_tanh_zscore \
  --max_good_per_class 200 \
  --max_defect_per_class 80 \
  --num_workers 8 \
  --cpu_threads 1 \
  --device cuda:0
