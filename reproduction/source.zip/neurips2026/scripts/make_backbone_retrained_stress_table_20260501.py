#!/usr/bin/env python3
"""Build the backbone-retrained stress table for AnomalyCLIP and AdaCLIP."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026/results/backbone_retrained_stress_20260501"
OUT = RESULT_ROOT / "backbone_retrained_stress_table.tex"

RUNS = [
    ("AnomalyCLIP", "ViT-B/16", "anomalyclip_vitb16_eval"),
    ("AnomalyCLIP", "ViT-H/14", "anomalyclip_vith14_eval"),
    ("AdaCLIP", "ViT-B/16", "adaclip_vitb16_eval"),
    ("AdaCLIP", "ViT-H/14", "adaclip_vith14_eval"),
]

MODES = [
    ("baseline_txt", "B"),
    ("parallel_margin", "T-TED"),
    ("ted_calibrated", "C-TED"),
]


def read_mean(run_dir: str, mode: str) -> tuple[float | None, ...]:
    path = RESULT_ROOT / run_dir / "summary.json"
    if not path.exists():
        return (None, None, None, None)
    data = json.loads(path.read_text())
    for row in data.get("rows", []):
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return (
                row.get("image_auroc"),
                row.get("pixel_auroc"),
                row.get("pixel_aupro"),
                row.get("pixel_ap"),
            )
    return (None, None, None, None)


def fmt(value: float | None) -> str:
    if value is None:
        return "--.--"
    return f"{value * 100:.2f}"


def render_group(host: str, backbone: str, run_dir: str) -> list[str]:
    rows = []
    values = []
    for mode, label in MODES:
        metric = read_mean(run_dir, mode)
        rows.append((host, backbone, label, metric))
        values.append(metric)
    best = []
    for i in range(4):
        vals = [v[i] for v in values if v[i] is not None]
        best.append(max(vals) if vals else None)
    rendered = []
    for row_idx, (host_name, bb, method, metric) in enumerate(rows):
        cells = [host_name if row_idx == 0 else "", bb if row_idx == 0 else "", method]
        for i, value in enumerate(metric):
            text = fmt(value)
            if value is not None and best[i] is not None and abs(value - best[i]) < 1e-12:
                text = rf"\textbf{{{text}}}"
            cells.append(text)
        rendered.append(" & ".join(cells) + r" \\")
    return rendered


def main() -> None:
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Backbone-retrained stress on VisA$\rightarrow$MVTec. The host is retrained after replacing only the CLIP visual backbone. B denotes the retrained baseline host, T-TED denotes train-free TED, and C-TED denotes source-calibrated TED.}",
        r"\label{tab:backbone_retrained_stress}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\renewcommand{\arraystretch}{1.04}",
        r"\resizebox{\linewidth}{!}{",
        r"\begin{tabular}{lllcccc}",
        r"\toprule",
        r"Host & Backbone & Method & I-AUC & P-AUC & P-PRO & P-AP \\",
        r"\midrule",
    ]
    for idx, (host, backbone, run_dir) in enumerate(RUNS):
        lines.extend(render_group(host, backbone, run_dir))
        if idx != len(RUNS) - 1:
            lines.append(r"\midrule")
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"}",
            r"\end{table}",
            "",
        ]
    )
    OUT.write_text("\n".join(lines))
    print(OUT)


if __name__ == "__main__":
    main()
