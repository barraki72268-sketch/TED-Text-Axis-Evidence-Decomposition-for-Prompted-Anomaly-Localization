#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "failure_conditioned_separability_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "failure_conditioned_separability_20260504"


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_faprompt_cmd(preset: str, device: str, force: bool) -> tuple[list[str], Path, Path]:
    save_dir = RESULTS / f"faprompt_vitl336_{preset}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        "0",
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    if force:
        # The evaluation script itself does not expose --force; overwrite by using a new save_dir convention if needed.
        pass
    return cmd, save_dir, LOGS / f"{save_dir.name}.log"


def launch(cmd: list[str], save_dir: Path, log_path: Path, force: bool) -> dict:
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        return {"stage": "skip_done", "summary": str(summary)}
    save_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = log_path.open("ab", buffering=0)
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        stdout=log_f,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {"stage": "launched", "pid": proc.pid, "save_dir": str(save_dir), "log": str(log_path)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--presets", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    presets = parse_csv(args.presets)
    devices = parse_csv(args.devices)
    jobs = []
    for i, preset in enumerate(presets):
        cmd, save_dir, log_path = build_faprompt_cmd(preset, devices[i % len(devices)], args.force)
        jobs.append(launch(cmd, save_dir, log_path, args.force))
    print(json.dumps({"stage": "queued_failure_conditioned_separability", "jobs": jobs}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
