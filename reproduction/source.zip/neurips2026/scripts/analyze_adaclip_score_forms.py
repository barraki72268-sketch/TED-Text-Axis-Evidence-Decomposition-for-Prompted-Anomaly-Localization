from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from official_parallel_test_adaclip import (
    Evaluator,
    aggregate_results,
    build_model,
    build_target_dataset,
    compute_baseline_outputs,
    decision_axis,
    get_or_collect_source_patch_banks,
    logmeanexp_negative_sqdist_1d,
    smooth_map,
)


def append_result(
    results: dict,
    mode: str,
    sample_id: str,
    cls_name: str,
    query_path: str,
    gt_mask: torch.Tensor,
    gt_anomaly: torch.Tensor,
    pr_map: torch.Tensor,
    pr_score: torch.Tensor,
) -> None:
    results[mode]["sample_ids"].append(sample_id)
    results[mode]["cls_names"].append(cls_name)
    results[mode]["query_paths"].append(query_path)
    results[mode]["gt_masks"].append(gt_mask.detach().cpu().int())
    results[mode]["pr_masks"].append(pr_map.detach().cpu())
    results[mode]["gt_anomalys"].append(gt_anomaly.detach().cpu())
    results[mode]["pr_anomalys"].append(pr_score.detach().cpu())


def save_json(save_path: Path, payload: dict) -> None:
    save_path.parent.mkdir(parents=True, exist_ok=True)
    with open(save_path, "w") as f:
        json.dump(payload, f, indent=2)


def score_rows(evaluator, results: dict, modes: list[str], class_name: str) -> list[dict]:
    rows = []
    for mode in modes:
        result_mode = aggregate_results(results[mode])
        metric_results = evaluator.run(result_mode, class_name)
        row = {
            "mode": mode,
            "target_label": class_name,
            "image_auroc": float(metric_results["I-AUROC"]),
            "image_ap": float(metric_results["I-AP"]),
            "pixel_auroc": float(metric_results["P-AUROC"]),
            "pixel_ap": float(metric_results["P-AP"]),
        }
        if "P-AUPRO" in metric_results:
            row["pixel_aupro"] = float(metric_results["P-AUPRO"])
        rows.append(row)
    return rows


def aggregate_layer_logits_to_map(layer_logits: list[torch.Tensor], image_size: int, sigma: float, device: str) -> torch.Tensor:
    resized_logits = []
    for logits in layer_logits:
        bsz, num_tokens, num_channels = logits.shape
        h = int(round(num_tokens ** 0.5))
        cur = logits.permute(0, 2, 1).view(bsz, num_channels, h, h)
        cur = F.interpolate(cur, size=image_size, mode="bilinear", align_corners=True)
        resized_logits.append(cur)

    agg_logits = torch.mean(torch.stack(resized_logits, dim=1), dim=1)
    agg_map = torch.softmax(agg_logits, dim=1)
    agg_map = (agg_map[:, 1:, :, :] + 1 - agg_map[:, 0:1, :, :]) / 2.0
    agg_map = smooth_map(agg_map[:, 0], sigma=sigma).to(device)
    return agg_map


def main() -> None:
    parser = argparse.ArgumentParser("AdaCLIP score-form preview analysis")
    parser.add_argument("--source_root", type=str, required=True)
    parser.add_argument("--source_dataset", type=str, required=True)
    parser.add_argument("--target_root", type=str, required=True)
    parser.add_argument("--target_dataset", type=str, required=True)
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument("--save_path", type=str, required=True)
    parser.add_argument("--preview_count", type=int, default=32)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--prompting_depth", type=int, default=4)
    parser.add_argument("--prompting_length", type=int, default=5)
    parser.add_argument("--prompting_branch", type=str, default="VL")
    parser.add_argument("--prompting_type", type=str, default="SD")
    parser.add_argument("--use_hsf", type=lambda x: x.lower() in {"1", "true", "yes"}, default=True)
    parser.add_argument("--k_clusters", type=int, default=20)
    parser.add_argument("--source_exclude_class", type=str, default=None)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--corr_alpha", type=float, default=0.3)
    parser.add_argument("--map_temperature", type=float, default=1.0)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--eval_metrics", nargs="+", default=["I-AUROC", "I-AP", "P-AUROC", "P-AP"])
    args = parser.parse_args()

    if args.source_exclude_class is not None and args.source_exclude_class.lower() in {"", "none", "null", "all"}:
        args.source_exclude_class = None

    model = build_model(
        device=args.device,
        checkpoint_path=args.checkpoint_path,
        image_size=args.image_size,
        prompting_depth=args.prompting_depth,
        prompting_length=args.prompting_length,
        prompting_branch=args.prompting_branch,
        prompting_type=args.prompting_type,
        use_hsf=args.use_hsf,
        k_clusters=args.k_clusters,
    )

    features_list = model.clip_model.output_layers
    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        source_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=features_list,
        device=args.device,
        source_exclude_class=args.source_exclude_class,
        hard_frac=args.hard_frac,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        sigma=args.sigma,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.bank_cache_path,
        refresh_bank_cache=args.refresh_bank_cache,
    )

    dataset = build_target_dataset(
        args.target_root,
        args.target_dataset,
        model,
        training=False,
        class_name=args.class_name,
    )
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
    evaluator = Evaluator("cpu", metrics=args.eval_metrics, sample_level=False)

    modes = [
        "baseline_txt",
        "multi_replace_fp10",
        "last_replace_fp10",
        "multi_replace_fp03",
        "last_replace_fp03",
        "multi_corr_fp03_a03",
        "last_corr_fp03_a03",
        "multi_logitcorr_fp03_a03",
        "last_logitcorr_fp03_a03",
        "multi_gatecorr_fp03_a05",
        "multi_posgate_fp03_a05",
        "multi_gateblend_fp03_a05",
    ]
    results = {
        mode: {
            "sample_ids": [],
            "gt_masks": [],
            "pr_masks": [],
            "cls_names": [],
            "gt_anomalys": [],
            "pr_anomalys": [],
            "query_paths": [],
        }
        for mode in modes
    }

    processed = 0
    with torch.no_grad():
        for idx, items in enumerate(loader, start=1):
            image = items["img"].to(args.device)
            cls_name = items["cls_name"][0]
            query_path = items["img_path"][0]
            sample_id = f"{cls_name}_{idx:05d}"
            gt_mask = items["img_mask"][:, 0].clone().to(args.device)
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask = gt_mask.int()
            gt_anomaly = items["anomaly"].to(args.device).int()

            baseline = compute_baseline_outputs(model, image, cls_name, args.sigma)
            axis = baseline["axis"]
            text_feature = baseline["text_features"]

            margin_layers_fp10 = []
            margin_layers_fp03 = []
            margin_small_layers_fp03 = []
            layer_logits = []
            for layer_idx, patch_feature in enumerate(baseline["patch_tokens"]):
                layer_logit = 100.0 * patch_feature @ text_feature
                layer_logits.append(layer_logit)
                patch = patch_feature[0]
                fp_coeff = fp_banks[layer_idx].to(args.device) @ axis if fp_banks[layer_idx].numel() else torch.empty((0,), device=args.device)
                def_coeff = def_banks[layer_idx].to(args.device) @ axis if def_banks[layer_idx].numel() else torch.empty((0,), device=args.device)
                coeff = patch @ axis
                q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=args.tau)
                q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=args.tau)
                h = int(round(patch.shape[0] ** 0.5))
                margin_fp10 = (q_def - q_fp).reshape(1, 1, h, h)
                margin_fp03 = (q_def - 0.3 * q_fp).reshape(1, 1, h, h)
                margin_small_layers_fp03.append(margin_fp03)
                margin_fp10 = F.interpolate(margin_fp10, size=(args.image_size, args.image_size), mode="bilinear", align_corners=True)[:, 0]
                margin_fp03 = F.interpolate(margin_fp03, size=(args.image_size, args.image_size), mode="bilinear", align_corners=True)[:, 0]
                margin_layers_fp10.append(margin_fp10)
                margin_layers_fp03.append(margin_fp03)

            multi_margin_fp10 = smooth_map(torch.stack(margin_layers_fp10, dim=0).mean(dim=0), sigma=args.sigma).to(args.device)
            multi_margin_fp03 = smooth_map(torch.stack(margin_layers_fp03, dim=0).mean(dim=0), sigma=args.sigma).to(args.device)
            last_margin_fp10 = smooth_map(margin_layers_fp10[-1], sigma=args.sigma).to(args.device)
            last_margin_fp03 = smooth_map(margin_layers_fp03[-1], sigma=args.sigma).to(args.device)

            multi_corr = torch.clamp(
                baseline["baseline_map"] + args.corr_alpha * (torch.sigmoid(multi_margin_fp03 / args.map_temperature) - 0.5),
                0.0,
                1.0,
            )
            last_corr = torch.clamp(
                baseline["baseline_map"] + args.corr_alpha * (torch.sigmoid(last_margin_fp03 / args.map_temperature) - 0.5),
                0.0,
                1.0,
            )

            baseline_conf = baseline["baseline_map"]
            gate = 1.0 - torch.abs(2.0 * baseline_conf - 1.0)
            multi_margin_prob = torch.sigmoid(multi_margin_fp03 / args.map_temperature)
            multi_gatecorr = torch.clamp(
                baseline_conf + 0.5 * gate * (multi_margin_prob - 0.5),
                0.0,
                1.0,
            )
            multi_posgate = torch.clamp(
                baseline_conf + 0.5 * gate * torch.relu(multi_margin_prob - 0.5),
                0.0,
                1.0,
            )
            multi_gateblend = torch.clamp(
                (1.0 - 0.5 * gate) * baseline_conf + (0.5 * gate) * multi_margin_prob,
                0.0,
                1.0,
            )

            logit_corr_layers = []
            for layer_logit, margin_small_fp03 in zip(layer_logits, margin_small_layers_fp03):
                corr = args.corr_alpha * torch.tanh(margin_small_fp03 / args.map_temperature)
                corr = corr.reshape(layer_logit.shape[0], layer_logit.shape[1], 1)
                corrected = layer_logit.clone()
                corrected[..., 1:2] = corrected[..., 1:2] + corr
                corrected[..., 0:1] = corrected[..., 0:1] - corr
                logit_corr_layers.append(corrected)

            multi_logit_corr = aggregate_layer_logits_to_map(logit_corr_layers, args.image_size, args.sigma, args.device)
            last_logit_corr = aggregate_layer_logits_to_map([logit_corr_layers[-1]], args.image_size, args.sigma, args.device)

            mode_to_map = {
                "baseline_txt": baseline["baseline_map"],
                "multi_replace_fp10": multi_margin_fp10,
                "last_replace_fp10": last_margin_fp10,
                "multi_replace_fp03": multi_margin_fp03,
                "last_replace_fp03": last_margin_fp03,
                "multi_corr_fp03_a03": multi_corr,
                "last_corr_fp03_a03": last_corr,
                "multi_logitcorr_fp03_a03": multi_logit_corr,
                "last_logitcorr_fp03_a03": last_logit_corr,
                "multi_gatecorr_fp03_a05": multi_gatecorr,
                "multi_posgate_fp03_a05": multi_posgate,
                "multi_gateblend_fp03_a05": multi_gateblend,
            }

            for mode, map_tensor in mode_to_map.items():
                append_result(
                    results=results,
                    mode=mode,
                    sample_id=sample_id,
                    cls_name=cls_name,
                    query_path=query_path,
                    gt_mask=gt_mask,
                    gt_anomaly=gt_anomaly,
                    pr_map=map_tensor,
                    pr_score=baseline["baseline_img_score"],
                )

            processed += 1
            if processed % 8 == 0:
                print(json.dumps({"stage": "eval_progress", "images_done": processed, "current_class": cls_name}), flush=True)
            if processed >= args.preview_count:
                break

    rows = score_rows(evaluator, results, modes, args.class_name)
    payload = {
        "summary": {
            "checkpoint_path": args.checkpoint_path,
            "source_root": args.source_root,
            "source_dataset": args.source_dataset,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "class_name": args.class_name,
            "preview_count": processed,
            "image_size": args.image_size,
            "features_list": features_list,
            "sigma": args.sigma,
            "tau": args.tau,
            "corr_alpha": args.corr_alpha,
            "eval_metrics": args.eval_metrics,
            "bank_stats": bank_stats,
            "bank_cache_path": str(bank_cache_path),
            "bank_cache_meta": bank_cache_meta,
            "score_definition": {
                "baseline_txt": "official AdaCLIP baseline local map",
                "multi_replace_fp10": "multilayer replacement with q_def - 1.0 * q_fp",
                "last_replace_fp10": "last-layer replacement with q_def - 1.0 * q_fp",
                "multi_replace_fp03": "multilayer replacement with q_def - 0.3 * q_fp",
                "last_replace_fp03": "last-layer replacement with q_def - 0.3 * q_fp",
                "multi_corr_fp03_a03": "baseline map + 0.3 * (sigmoid(multilayer margin fp03) - 0.5)",
                "last_corr_fp03_a03": "baseline map + 0.3 * (sigmoid(last-layer margin fp03) - 0.5)",
                "multi_logitcorr_fp03_a03": "layerwise baseline logits corrected by multilayer fp03 margin, then aggregated with the original AdaCLIP softmax pipeline",
                "last_logitcorr_fp03_a03": "last-layer baseline logits corrected by fp03 margin, then aggregated with the original AdaCLIP softmax pipeline",
                "multi_gatecorr_fp03_a05": "baseline map plus gated multilayer fp03 correction, applied only where baseline confidence is low",
                "multi_posgate_fp03_a05": "baseline map plus positive-only gated multilayer fp03 correction",
                "multi_gateblend_fp03_a05": "gated blend between baseline map and multilayer fp03 margin probability",
            },
        },
        "rows": rows,
    }
    save_json(Path(args.save_path), payload)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
