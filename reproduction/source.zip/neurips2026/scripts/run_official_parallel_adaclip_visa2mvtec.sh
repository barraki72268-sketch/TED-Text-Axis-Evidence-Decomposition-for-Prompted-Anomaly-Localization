#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_adaclip.py"
CKPT="${ROOT}/neurips2026/AdaCLIP/ckpt/pretrained_visa_clinicdb.pth"
SOURCE_ROOT="${ROOT}/neurips2026/data/VisA_pytorch_official/1cls"
SOURCE_DATASET="visa"
COMMON_BANK="${ROOT}/neurips2026/results/bank_cache/adaclip_visa_official1cls_multilayer.pt"
export MPLCONFIGDIR="/tmp/matplotlib-adaclip-gpu1"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" \
  --source_root "${SOURCE_ROOT}" \
  --source_dataset "${SOURCE_DATASET}" \
  --target_root "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  --target_dataset mvtec \
  --checkpoint_path "${CKPT}" \
  --save_dir "${ROOT}/neurips2026/results/official_parallel_test_adaclip_visa2mvtec_all" \
  --bank_cache_path "${COMMON_BANK}" \
  --image_size 518 \
  --sigma 4 \
  --prompting_depth 4 \
  --prompting_length 5 \
  --prompting_branch VL \
  --prompting_type SD \
  --use_hsf true \
  --k_clusters 20 \
  --max_good_per_class 2 \
  --max_defect_per_class 4 \
  --max_bank_per_layer 512 \
  --max_fp_per_image 64 \
  --max_defect_per_image 64 \
  --cpu_threads 1 \
  --device cuda:0
