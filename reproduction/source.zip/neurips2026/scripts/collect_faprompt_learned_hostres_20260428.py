#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"

METRICS = ("pixel_auc", "pixel_ap", "pixel_aupro", "image_auc")
PRESETS = ("visa2mvtec", "mvtec2visa", "visa2mpdd", "visa2btad")
BACKBONES = {
    "ViT-B/16+": "vitb16plus",
    "ViT-H/14": "vith14",
    "ViT-L/14 OpenAI": "vitl14openai",
}


def fmt(value: float) -> str:
    if not math.isfinite(value):
        return "--.--"
    return f"{100.0 * value:.2f}"


def metric_tuple(metrics: dict[str, float]) -> str:
    return " / ".join(fmt(metrics[m]) for m in METRICS)


def average(rows: list[dict[str, float]]) -> dict[str, float]:
    return {metric: sum(row[metric] for row in rows) / len(rows) for metric in METRICS}


def load_one(backbone_tag: str, preset: str, seed: int) -> tuple[dict[str, float], dict[str, float], dict[str, object], Path] | None:
    path = RESULTS / f"faprompt_learned_hostres_{backbone_tag}_{preset}_seed{seed}_20260428" / "summary.json"
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    mean = data["mean"]
    base = mean["baseline_official"]
    key = "prescore_calibrated_alpha_1"
    if key not in mean["parallel"]:
        raise KeyError(f"{key} missing from {path}")
    return base, mean["parallel"][key], data.get("source_prescore_calibrator") or {}, path


def best_fmt(base: dict[str, float], ours: dict[str, float], ours_side: bool) -> str:
    values = []
    for metric in METRICS:
        value = ours[metric] if ours_side else base[metric]
        text = fmt(value)
        if math.isfinite(value) and ((ours[metric] > base[metric]) == ours_side):
            text = rf"\textbf{{{text}}}"
        values.append(text)
    return " / ".join(values)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=str, default="0")
    args = parser.parse_args()
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]

    print("FAPrompt learned host-residual subspace")
    print("=" * 40)
    collected: dict[str, tuple[dict[str, float], dict[str, float]]] = {}
    pending: list[str] = []

    for backbone, tag in BACKBONES.items():
        base_rows: list[dict[str, float]] = []
        ours_rows: list[dict[str, float]] = []
        print(f"\n{backbone}")
        for preset in PRESETS:
            seed_base: list[dict[str, float]] = []
            seed_ours: list[dict[str, float]] = []
            calibs: list[dict[str, object]] = []
            for seed in seeds:
                loaded = load_one(tag, preset, seed)
                if loaded is None:
                    pending.append(f"{backbone} {preset} seed{seed}")
                    continue
                base, ours, calib, path = loaded
                seed_base.append(base)
                seed_ours.append(ours)
                calibs.append(calib)
            if not seed_base:
                print(f"  {preset}: pending")
                continue
            base_avg = average(seed_base)
            ours_avg = average(seed_ours)
            base_rows.append(base_avg)
            ours_rows.append(ours_avg)
            eta = [float(c.get("eta", float("nan"))) for c in calibs if c]
            rank_acc = [float(c.get("source_pair_rank_accuracy", float("nan"))) for c in calibs if c]
            eta_txt = "--" if not eta else f"{sum(eta) / len(eta):.3f}"
            rank_txt = "--" if not rank_acc else f"{sum(rank_acc) / len(rank_acc):.3f}"
            print(f"  {preset}: eta={eta_txt}, source-rank={rank_txt}")
            print(f"    base {metric_tuple(base_avg)}")
            print(f"    ours {metric_tuple(ours_avg)}")
        if len(base_rows) == len(PRESETS):
            collected[backbone] = (average(base_rows), average(ours_rows))

    print("\nMean LaTeX rows")
    print("=" * 15)
    print(r"\multirow{3}{*}{FAPrompt}")
    for idx, backbone in enumerate(BACKBONES):
        if backbone in collected:
            base, ours = collected[backbone]
            print(f"  & {backbone}")
            print(f"  & {best_fmt(base, ours, ours_side=False)}")
            print(f"  & {best_fmt(base, ours, ours_side=True)} \\\\")
        else:
            print(f"  & {backbone}")
            print("  & --.-- / --.-- / --.-- / --.--")
            print("  & --.-- / --.-- / --.-- / --.-- \\\\")

    if pending:
        print("\nPending")
        print("=" * 7)
        for item in pending:
            print(item)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
