#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_rawimagebind.py"
SOURCE_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
SOURCE_DATASET="mvtec"
export MPLCONFIGDIR="/tmp/matplotlib-rawimagebind-mvtec-queue"

run_one() {
  local target_root="$1"
  local target_dataset="$2"
  local save_dir="$3"
  local bank_cache="$4"

  CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" \
    --source_root "${SOURCE_ROOT}" \
    --source_dataset "${SOURCE_DATASET}" \
    --target_root "${target_root}" \
    --target_dataset "${target_dataset}" \
    --save_dir "${save_dir}" \
    --bank_cache_path "${bank_cache}" \
    --prompt_mode class \
    --image_size 224 \
    --device cuda:0
}

run_one \
  "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  "visa" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_mvtec2visa_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_mvtec_class_exclude-none_all.pt"

run_one \
  "/mnt/data/MPDD" \
  "mpdd" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_mvtec2mpdd_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_mvtec_class_exclude-none_all.pt"

run_one \
  "${ROOT}/neurips2026/data/BTAD_official" \
  "btad" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_mvtec2btad_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_mvtec_class_exclude-none_all.pt"
