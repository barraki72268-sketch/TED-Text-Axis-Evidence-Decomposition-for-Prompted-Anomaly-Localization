from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.train_clip_ksm_v2_oracle import (  # noqa: E402
    forward_remaining,
    forward_up_to_layer,
    l2_normalize,
    patchify_sequence,
    rebuild_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.scripts.train_clip_ksm_v3_mvtec_to_visa import (  # noqa: E402
    KinematicSteeringModuleV3Conditional,
    build_prompt_condition,
    collect_mvtec_train_records,
    collect_visa_eval_records,
    compute_v36_loss,
    entropy_beta,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("KSM v3 mixed-source MVTec -> VisA sparse two-layer pilot.")
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument(
        "--target_classes",
        nargs="+",
        default=[
            "chewinggum",
            "pipe_fryum",
            "pcb4",
            "macaroni2",
            "cashew",
            "pcb1",
            "macaroni1",
            "fryum",
            "pcb2",
            "capsules",
            "candle",
            "pcb3",
        ],
    )
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12])
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-2)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--gamma_init", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=8)
    parser.add_argument("--train_anomaly_images", type=int, default=8)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_n", type=float, default=1.0)
    parser.add_argument("--lambda_smooth", type=float, default=0.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--entropy_beta_max", type=float, default=0.05)
    parser.add_argument("--entropy_hold_epochs", type=int, default=2)
    parser.add_argument("--entropy_decay_epochs", type=int, default=5)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_ksm_v3_mvtec_to_visa_multilayer")
    return parser.parse_args()


def run_multilayer_modules(backbone, image_t, layer_to_ksm, cond, return_aux: bool = False):
    layers = sorted(layer_to_ksm)
    seq = None
    aux_by_layer = {}
    base_seq_by_layer = {}
    in_patches_by_layer = {}
    for idx, layer in enumerate(layers):
        if idx == 0:
            seq = forward_up_to_layer(backbone, image_t, layer)
        else:
            seq = backbone.run_blocks(seq, start_layer=layers[idx - 1] + 1, end_layer=layer)
        base_seq_by_layer[layer] = seq
        cls_tok, patches = patchify_sequence(seq)
        in_patches_by_layer[layer] = patches
        out_patches, aux = layer_to_ksm[layer](patches, cond, return_aux=True)
        aux_by_layer[layer] = aux
        seq = rebuild_sequence(cls_tok, out_patches)
    final_patches = forward_remaining(backbone, seq, layers[-1])[0]
    if not return_aux:
        return final_patches
    return final_patches, {
        "aux_by_layer": aux_by_layer,
        "base_seq_by_layer": base_seq_by_layer,
        "in_patches_by_layer": in_patches_by_layer,
    }


def train_one_epoch(backbone, layer_to_ksm, prompt_cache, train_records, args, optimizer, device, epoch_idx):
    for ksm in layer_to_ksm.values():
        ksm.train()
    beta = entropy_beta(epoch_idx, args.entropy_beta_max, args.entropy_hold_epochs, args.entropy_decay_epochs)
    loss_vals = []
    alpha_by_layer = {layer: [] for layer in layer_to_ksm}
    gamma_s_by_layer = {layer: [] for layer in layer_to_ksm}
    gamma_u_by_layer = {layer: [] for layer in layer_to_ksm}

    for rec in train_records:
        cond = prompt_cache[rec.class_name]
        image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        _, pack = run_multilayer_modules(backbone, image_t, layer_to_ksm, cond, return_aux=True)
        mask = torch.from_numpy(rec.patch_mask.astype(np.int64)).to(device).view(1, -1)

        layer_losses = []
        layer_entropies = []
        for layer, aux in pack["aux_by_layer"].items():
            v_in = pack["in_patches_by_layer"][layer]
            loss, _ = compute_v36_loss(
                v_in,
                aux,
                cond,
                mask,
                lambda_n=args.lambda_n,
                lambda_smooth=args.lambda_smooth,
                topk_anom_ratio=args.topk_anom_ratio,
                hard_neg_ratio=args.hard_neg_ratio,
            )
            alpha_c = aux["alpha_tensor"].clamp(1e-6, 1.0 - 1e-6)
            layer_entropies.append((alpha_c * torch.log(alpha_c) + (1.0 - alpha_c) * torch.log(1.0 - alpha_c)).mean())
            layer_losses.append(loss)
            alpha_by_layer[layer].append(aux["alpha_mean"])
            gamma_s_by_layer[layer].append(aux["gamma_simplex_abs"])
            gamma_u_by_layer[layer].append(aux["gamma_subspace_abs"])

        total_loss = torch.stack(layer_losses).mean()
        total_entropy = torch.stack(layer_entropies).mean()
        total_loss = total_loss + beta * total_entropy
        optimizer.zero_grad(set_to_none=True)
        total_loss.backward()
        optimizer.step()
        loss_vals.append(float(total_loss.item()))

    out = {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "entropy_beta": float(beta),
    }
    for layer in sorted(layer_to_ksm):
        out[f"alpha_L{layer}_mean"] = float(np.mean(alpha_by_layer[layer])) if alpha_by_layer[layer] else float("nan")
        out[f"gamma_simplex_L{layer}_mean"] = float(np.mean(gamma_s_by_layer[layer])) if gamma_s_by_layer[layer] else float("nan")
        out[f"gamma_subspace_L{layer}_mean"] = float(np.mean(gamma_u_by_layer[layer])) if gamma_u_by_layer[layer] else float("nan")
    return out


def evaluate_target_class(backbone, layer_to_ksm, cond, eval_records, args, device):
    for ksm in layer_to_ksm.values():
        ksm.eval()

    patch_labels = []
    base_prompt_patch_scores = []
    ksm_prompt_patch_scores = []
    image_labels = []
    base_prompt_image_scores = []
    ksm_prompt_image_scores = []
    sem_drop_vals = []
    alpha_by_layer = {layer: [] for layer in layer_to_ksm}

    with torch.no_grad():
        last_layer = max(layer_to_ksm)
        for rec in eval_records:
            image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            base_seq = forward_up_to_layer(backbone, image_t, last_layer)
            base_final = forward_remaining(backbone, base_seq, last_layer)[0]
            out_final, pack = run_multilayer_modules(backbone, image_t, layer_to_ksm, cond, return_aux=True)

            base_prompt = score_promptmax(base_final, cond.p_norm, cond.prompt_features)
            out_prompt = score_promptmax(out_final, cond.p_norm, cond.prompt_features)
            patch_labels.extend(rec.patch_mask.astype(np.int64).tolist())
            base_prompt_patch_scores.extend(base_prompt.tolist())
            ksm_prompt_patch_scores.extend(out_prompt.tolist())
            image_labels.append(rec.label)
            base_prompt_image_scores.append(topk_mean(base_prompt, args.topk_ratio))
            ksm_prompt_image_scores.append(topk_mean(out_prompt, args.topk_ratio))

            base_norm = l2_normalize(base_final, dim=-1)
            out_norm = l2_normalize(out_final, dim=-1)
            sem_drop_vals.append(float((out_norm @ cond.p_norm).mean().item() - (base_norm @ cond.p_norm).mean().item()))
            for layer, aux in pack["aux_by_layer"].items():
                alpha_by_layer[layer].append(aux["alpha_mean"])

    base_patch_auc = safe_auc(patch_labels, base_prompt_patch_scores)
    ksm_patch_auc = safe_auc(patch_labels, ksm_prompt_patch_scores)
    base_image_auc = safe_auc(image_labels, base_prompt_image_scores)
    ksm_image_auc = safe_auc(image_labels, ksm_prompt_image_scores)
    out = {
        "base_prompt_patch_auc": base_patch_auc,
        "ksm_prompt_patch_auc": ksm_patch_auc,
        "prompt_patch_auc_delta": ksm_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "ksm_prompt_image_auc": ksm_image_auc,
        "prompt_image_auc_delta": ksm_image_auc - base_image_auc,
        "semantic_drop_mean": float(np.mean(sem_drop_vals)) if sem_drop_vals else float("nan"),
    }
    for layer in sorted(layer_to_ksm):
        out[f"alpha_L{layer}_mean_eval"] = float(np.mean(alpha_by_layer[layer])) if alpha_by_layer[layer] else float("nan")
    return out


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    layers = sorted(set(args.layers))

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for param in backbone.parameters():
        param.requires_grad_(False)

    source_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.source_classes
    }
    target_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.target_classes
    }
    train_records = collect_mvtec_train_records(backbone, args)

    layer_to_ksm = {
        layer: KinematicSteeringModuleV3Conditional(
            dim=int(next(iter(source_prompt_cache.values())).prompt_features.shape[1]),
            gamma_init=args.gamma_init,
        ).to(device)
        for layer in layers
    }
    params = []
    for layer in layers:
        params.extend(list(layer_to_ksm[layer].parameters()))
    optimizer = torch.optim.AdamW(params, lr=args.lr, weight_decay=args.weight_decay)

    history = []
    for epoch in range(1, args.epochs + 1):
        history.append(
            {
                "epoch": epoch,
                **train_one_epoch(backbone, layer_to_ksm, source_prompt_cache, train_records, args, optimizer, device, epoch),
            }
        )

    rows = []
    for class_name in args.target_classes:
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(backbone, layer_to_ksm, target_prompt_cache[class_name], eval_records, args, device)
        rows.append(
            {
                "class_name": class_name,
                "layers": "-".join(str(x) for x in layers),
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "img_size": args.img_size,
                "epochs": args.epochs,
                "gamma_init": args.gamma_init,
                "lambda_smooth": args.lambda_smooth,
                "source_classes": len(args.source_classes),
                "source_train_records": len(train_records),
                "text_rank": target_prompt_cache[class_name].text_rank,
                **history[-1],
                **eval_stats,
            }
        )

    stem = f"{args.output_tag}_{args.backbone}_L{'-'.join(str(x) for x in layers)}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump(
            {
                "args": vars(args),
                "history": history,
                "rows": rows,
            },
            f,
            indent=2,
        )
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
