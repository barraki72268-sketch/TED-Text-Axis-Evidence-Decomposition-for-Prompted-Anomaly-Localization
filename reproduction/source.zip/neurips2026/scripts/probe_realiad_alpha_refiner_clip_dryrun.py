from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
import time
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import open_clip
import torch
import torch.nn.functional as F
from PIL import Image, ImageFile
from torchvision import transforms as T

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD
from ADPretrain.models.clip import ClipModel
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts
from neurips2026.learned_refiner import AlphaSpaceKinematicRefiner, AlphaSpaceObjective


ImageFile.LOAD_TRUNCATED_IMAGES = True

CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)
LAYER_IDS = (6, 12, 18, 24)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--clip_backbone", type=str, default="clip-large-336", choices=["clip-large-336"])
    parser.add_argument("--layer", type=int, default=12, choices=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=336)
    parser.add_argument("--imagesize", type=int, default=336)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--hidden_dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--lambda_sem", type=float, default=1.0)
    parser.add_argument("--lambda_normal", type=float, default=0.5)
    parser.add_argument("--lambda_anomaly", type=float, default=0.5)
    parser.add_argument("--lambda_pairwise", type=float, default=1.0)
    parser.add_argument("--pairwise_margin", type=float, default=0.1)
    parser.add_argument("--sem_threshold", type=float, default=0.02)
    parser.add_argument("--sem_gas_beta", type=float, default=10.0)
    parser.add_argument("--lambda_normal_end", type=float, default=None)
    parser.add_argument("--lambda_normal_decay_start", type=int, default=0)
    parser.add_argument("--lambda_anomaly_start", type=float, default=None)
    parser.add_argument("--lambda_anomaly_end", type=float, default=None)
    parser.add_argument("--lr_decay_start", type=int, default=100)
    parser.add_argument("--lr_min_ratio", type=float, default=0.1)
    parser.add_argument("--eval_interval", type=int, default=5)
    parser.add_argument("--probe_normals", type=int, default=8)
    parser.add_argument("--probe_anomalies", type=int, default=8)
    parser.add_argument("--probe_sem_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_target", type=float, default=0.35)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--audit_verify_limit", type=int, default=4000)
    parser.add_argument("--mask_audit_limit", type=int, default=4000)
    parser.add_argument("--reuse_dataset_cache", action="store_true", default=True)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:1")
    parser.add_argument("--output_tag", type=str, default="realiad_clip_alpha_dryrun")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def flatten_records(dataset: RealIAD) -> list[dict]:
    items: list[dict] = []
    for view_items in dataset.data_items_by_view.values():
        items.extend(view_items)
    return items


def build_transform(resize: int, imagesize: int) -> T.Compose:
    return T.Compose(
        [
            T.Resize(resize, interpolation=T.InterpolationMode.BICUBIC),
            T.CenterCrop(imagesize),
            T.ToTensor(),
            T.Normalize(mean=CLIP_MEAN, std=CLIP_STD),
        ]
    )


def build_mask_transform(size: int) -> T.Compose:
    return T.Compose(
        [
            T.Resize(size, interpolation=T.InterpolationMode.NEAREST),
            T.CenterCrop(size),
            T.ToTensor(),
        ]
    )


def safe_image_open(path: str) -> tuple[bool, str | None]:
    try:
        with Image.open(path) as img:
            img.verify()
        return True, None
    except Exception as exc:  # pragma: no cover - audit path
        return False, str(exc)


def load_rgb_tensor(path: str, transform: T.Compose) -> torch.Tensor:
    return transform(Image.open(path).convert("RGB"))


def load_mask_tensor(path: str, transform: T.Compose) -> torch.Tensor:
    arr = np.array(Image.open(path))
    arr[arr != 0] = 255
    return transform(Image.fromarray(arr))


def dilate_mask_tensor(mask: torch.Tensor, kernel_size: int) -> torch.Tensor:
    if kernel_size <= 1:
        return mask
    if kernel_size % 2 == 0:
        raise ValueError("mask_dilate_kernel must be odd.")
    return F.max_pool2d(mask.unsqueeze(0), kernel_size=kernel_size, stride=1, padding=kernel_size // 2).squeeze(0)


def build_normal_prompt_subspace(class_name: str, model: ClipModel, device: torch.device) -> torch.Tensor:
    tokenizer = open_clip.get_tokenizer("ViT-L-14")
    prompts = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    tokens = tokenizer(prompts).to(device)
    with torch.no_grad():
        text_features = model.visual_encoder.encode_text(tokens).float()
    text_features = F.normalize(text_features, dim=-1)
    q_text, _ = torch.linalg.qr(text_features.T, mode="reduced")

    visual = model.visual_encoder.visual
    proj = getattr(visual, "proj", None)
    if proj is None:
        return q_text.cpu()

    token_basis = proj.float().to(device) @ q_text
    q_token, _ = torch.linalg.qr(token_basis, mode="reduced")
    return q_token.cpu()


def imagewise_mean(values: torch.Tensor, mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    weights = mask.float()
    denom = weights.sum(dim=1)
    valid = denom > 0
    mean = (values * weights).sum(dim=1) / denom.clamp_min(1.0)
    return mean, valid


def imagewise_mean_vec(values: torch.Tensor, mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    weights = mask.float().unsqueeze(-1)
    denom = weights.sum(dim=1)
    valid = denom.squeeze(-1) > 0
    mean = (values * weights).sum(dim=1) / denom.clamp_min(1.0)
    return mean, valid


def linear_schedule(step: int, total_steps: int, start_value: float, end_value: float, start_step: int = 1) -> float:
    if step <= start_step:
        return float(start_value)
    if total_steps <= start_step:
        return float(end_value)
    progress = min(1.0, max(0.0, (step - start_step) / float(total_steps - start_step)))
    return float(start_value + (end_value - start_value) * progress)


def cosine_decay_lr(
    step: int,
    total_steps: int,
    base_lr: float,
    start_step: int,
    min_ratio: float,
) -> float:
    if step <= start_step:
        return float(base_lr)
    if total_steps <= start_step:
        return float(base_lr * min_ratio)
    progress = min(1.0, max(0.0, (step - start_step) / float(total_steps - start_step)))
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    scale = min_ratio + (1.0 - min_ratio) * cosine
    return float(base_lr * scale)


def collect_records_by_label(records: Iterable[dict]) -> tuple[list[dict], list[dict]]:
    normals = []
    anomalies = []
    for rec in records:
        if int(rec["label"]) == 0:
            normals.append(rec)
        else:
            anomalies.append(rec)
    return normals, anomalies


def audit_dataset(
    records: list[dict],
    mask_transform: T.Compose,
    image_size: int,
    token_side: int,
    verify_limit: int,
    mask_audit_limit: int,
    seed: int,
    mask_dilate_kernel: int,
) -> dict:
    rng = random.Random(seed)
    normal_records, anomaly_records = collect_records_by_label(records)
    summary = {
        "total_records": len(records),
        "total_normal_records": len(normal_records),
        "total_anomaly_records": len(anomaly_records),
        "missing_masks": 0,
        "broken_images": 0,
        "broken_masks": 0,
        "empty_masks_full": 0,
        "empty_masks_resized": 0,
        "empty_masks_patchgrid": 0,
        "verify_limit": verify_limit,
        "mask_audit_limit": mask_audit_limit,
        "train_flag_is_not_used_in_dataset_loader": True,
        "examples": {
            "missing_masks": [],
            "broken_images": [],
            "broken_masks": [],
        },
    }

    verify_subset = records if verify_limit < 0 else rng.sample(records, min(len(records), verify_limit))
    for rec in verify_subset:
        ok, msg = safe_image_open(rec["image_path"])
        if not ok:
            summary["broken_images"] += 1
            if len(summary["examples"]["broken_images"]) < 10:
                summary["examples"]["broken_images"].append({"path": rec["image_path"], "error": msg})
        if int(rec["label"]) == 1:
            mask_path = rec["mask_path"]
            if not mask_path or not Path(mask_path).exists():
                summary["missing_masks"] += 1
                if len(summary["examples"]["missing_masks"]) < 10:
                    summary["examples"]["missing_masks"].append(rec["image_path"])
                continue
            ok, msg = safe_image_open(mask_path)
            if not ok:
                summary["broken_masks"] += 1
                if len(summary["examples"]["broken_masks"]) < 10:
                    summary["examples"]["broken_masks"].append({"path": mask_path, "error": msg})

    audit_subset = anomaly_records if mask_audit_limit < 0 else rng.sample(anomaly_records, min(len(anomaly_records), mask_audit_limit))
    full_counts = []
    resized_counts = []
    token_counts = []
    for rec in audit_subset:
        mask_path = rec["mask_path"]
        if not mask_path or not Path(mask_path).exists():
            continue
        mask = load_mask_tensor(mask_path, mask_transform)
        full_pos = int((mask > 0.5).sum().item())
        if full_pos == 0:
            summary["empty_masks_full"] += 1
        full_counts.append(full_pos)
        resized = dilate_mask_tensor(mask, mask_dilate_kernel)
        resized_pos = int((resized > 0.5).sum().item())
        if resized_pos == 0:
            summary["empty_masks_resized"] += 1
        resized_counts.append(resized_pos)
        patch = F.interpolate(resized.unsqueeze(0), size=(token_side, token_side), mode="nearest").squeeze(0)
        patch_pos = int((patch > 0.5).sum().item())
        if patch_pos == 0:
            summary["empty_masks_patchgrid"] += 1
        token_counts.append(patch_pos)

    if full_counts:
        summary["mask_positive_pixels_full_mean"] = float(np.mean(full_counts))
        summary["mask_positive_pixels_full_min"] = int(np.min(full_counts))
        summary["mask_positive_pixels_full_max"] = int(np.max(full_counts))
    if resized_counts:
        summary["mask_positive_pixels_resized_mean"] = float(np.mean(resized_counts))
        summary["mask_positive_pixels_resized_min"] = int(np.min(resized_counts))
        summary["mask_positive_pixels_resized_max"] = int(np.max(resized_counts))
    if token_counts:
        summary["mask_positive_tokens_mean"] = float(np.mean(token_counts))
        summary["mask_positive_tokens_min"] = int(np.min(token_counts))
        summary["mask_positive_tokens_max"] = int(np.max(token_counts))
        summary["mask_zero_token_fraction"] = float(np.mean(np.array(token_counts) == 0))
    return summary


def sample_balanced_batch(
    normal_records: list[dict],
    anomaly_records: list[dict],
    batch_size: int,
    rng: random.Random,
) -> list[dict]:
    half = max(1, batch_size // 2)
    num_normals = min(len(normal_records), batch_size - half)
    num_anomalies = min(len(anomaly_records), half)
    if num_normals + num_anomalies < batch_size:
        extra = batch_size - (num_normals + num_anomalies)
        num_normals = min(len(normal_records), num_normals + extra)
    batch = rng.sample(normal_records, num_normals) + rng.sample(anomaly_records, num_anomalies)
    rng.shuffle(batch)
    return batch


def record_group_key(record: dict) -> tuple[str, ...]:
    if int(record["label"]) == 1:
        return (
            str(record["class_name"]),
            str(record.get("anomaly_type", "unknown")),
            str(record["sample_id"]),
        )
    return (str(record["class_name"]), str(record["sample_id"]))


def group_records_by_physical_unit(records: list[dict]) -> dict[tuple[str, ...], list[dict]]:
    groups: dict[tuple[str, ...], list[dict]] = {}
    for rec in records:
        key = record_group_key(rec)
        groups.setdefault(key, []).append(rec)
    return groups


def summarize_grouped_records(records: list[dict]) -> dict:
    groups = group_records_by_physical_unit(records)
    view_hist: dict[int, int] = {}
    for items in groups.values():
        view_hist[len(items)] = view_hist.get(len(items), 0) + 1
    total_views = sum(len(items) for items in groups.values())
    return {
        "images": len(records),
        "groups": len(groups),
        "avg_views_per_group": float(total_views / max(len(groups), 1)),
        "view_hist": {str(k): int(v) for k, v in sorted(view_hist.items())},
    }


def build_group_balanced_epoch_batches(
    normal_records: list[dict],
    anomaly_records: list[dict],
    batch_size: int,
    rng: random.Random,
) -> list[list[dict]]:
    if batch_size < 2:
        raise ValueError("batch_size must be at least 2 for balanced group sampling.")

    normal_groups = list(group_records_by_physical_unit(normal_records).values())
    anomaly_groups = list(group_records_by_physical_unit(anomaly_records).values())
    if not normal_groups or not anomaly_groups:
        return []

    rng.shuffle(normal_groups)
    rng.shuffle(anomaly_groups)

    groups_per_side = min(len(normal_groups), len(anomaly_groups))
    normal_groups = normal_groups[:groups_per_side]
    anomaly_groups = anomaly_groups[:groups_per_side]

    normal_samples = [rng.choice(group) for group in normal_groups]
    anomaly_samples = [rng.choice(group) for group in anomaly_groups]

    half = max(1, batch_size // 2)
    batches: list[list[dict]] = []
    for start in range(0, groups_per_side, half):
        batch = normal_samples[start : start + half] + anomaly_samples[start : start + half]
        rng.shuffle(batch)
        batches.append(batch)
    return batches


def filter_trainable_anomalies(
    anomaly_records: list[dict],
    mask_transform: T.Compose,
    token_side: int,
    scan_limit: int,
    seed: int,
    mask_dilate_kernel: int,
) -> tuple[list[dict], dict]:
    rng = random.Random(seed)
    records = list(anomaly_records)
    rng.shuffle(records)
    survivors = []
    scanned = 0
    missing = 0
    zero_token = 0
    for rec in records:
        if scan_limit >= 0 and scanned >= scan_limit:
            break
        scanned += 1
        mask_path = rec["mask_path"]
        if not mask_path or not Path(mask_path).exists():
            missing += 1
            continue
        mask = dilate_mask_tensor(load_mask_tensor(mask_path, mask_transform), mask_dilate_kernel)
        patch = F.interpolate(mask.unsqueeze(0), size=(token_side, token_side), mode="nearest").squeeze(0)
        if int((patch > 0.5).sum().item()) <= 0:
            zero_token += 1
            continue
        survivors.append(rec)
    return survivors, {
        "scanned_anomalies_for_training": scanned,
        "trainable_anomalies": len(survivors),
        "training_missing_masks": missing,
        "training_zero_token_anomalies": zero_token,
    }


def build_batch_tensors(
    batch: list[dict],
    transform: T.Compose,
    mask_transform: T.Compose,
    semantic_basis_by_class: dict[str, torch.Tensor],
    clip_model: ClipModel,
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, list[int]]:
    images = torch.stack([load_rgb_tensor(rec["image_path"], transform) for rec in batch], dim=0).to(device)
    masks = []
    basis = []
    labels = []
    for rec in batch:
        if int(rec["label"]) == 1:
            mask = dilate_mask_tensor(load_mask_tensor(rec["mask_path"], mask_transform), args.mask_dilate_kernel)
        else:
            mask = torch.zeros(1, args.imagesize, args.imagesize)
        masks.append(mask)
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = build_normal_prompt_subspace(rec["class_name"], clip_model, device)
        basis.append(semantic_basis_by_class[rec["class_name"]])
        labels.append(int(rec["label"]))
    masks_t = torch.stack(masks, dim=0).to(device)
    basis_t = torch.stack(basis, dim=0).to(device)
    return images, masks_t, basis_t, labels


def evaluate_probe_batch(
    *,
    model: AlphaSpaceKinematicRefiner,
    objective: AlphaSpaceObjective,
    clip_model: ClipModel,
    probe_batch: list[dict],
    semantic_basis_by_class: dict[str, torch.Tensor],
    transform: T.Compose,
    mask_transform: T.Compose,
    args: argparse.Namespace,
    device: torch.device,
    layer_index: int,
    token_side: int,
) -> dict[str, float]:
    model_was_training = model.training
    model.eval()
    with torch.no_grad():
        images, masks_t, basis_t, labels = build_batch_tensors(
            probe_batch, transform, mask_transform, semantic_basis_by_class, clip_model, args, device
        )
        features = clip_model.encode_image_from_tensors(images, shape="img")[layer_index].float()
        out = model(features, semantic_basis=basis_t)
        loss_stats = objective(
            raw_features=features,
            refined_features=out.refined,
            alpha=out.alpha,
            anomaly_mask=masks_t,
            semantic_basis=basis_t,
        )
        anomaly_patch_mask = F.interpolate(masks_t.float(), size=(token_side, token_side), mode="nearest").reshape(len(probe_batch), -1) > 0.5
        anomaly_image_mask = torch.tensor(labels, device=device, dtype=torch.bool)
        token_anomaly_counts = anomaly_patch_mask.sum(dim=1)
        anomaly_token_counts_only = token_anomaly_counts[anomaly_image_mask]

        alpha_n = float(loss_stats["alpha_normal_mean"].item())
        alpha_a = float(loss_stats["alpha_anomaly_mean"].item())
        sem = float(loss_stats["loss_sem"].item())
        gap = alpha_n - alpha_a
        score = (
            gap
            - args.probe_sem_penalty * sem
            - args.probe_alphaa_penalty * max(0.0, alpha_a - args.probe_alphaa_target)
        )
    if model_was_training:
        model.train()
    return {
        "probe_score": float(score),
        "probe_alpha_normal_mean": alpha_n,
        "probe_alpha_anomaly_mean": alpha_a,
        "probe_alpha_gap": float(gap),
        "probe_sem_loss": sem,
        "probe_anomaly_zero_token_fraction": float((anomaly_token_counts_only == 0).float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
        "probe_anomaly_token_count_mean": float(anomaly_token_counts_only.float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
    }


def compute_patch_residual(tokens: torch.Tensor, local_mean: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    return 1.0 - F.cosine_similarity(tokens, local_mean, dim=-1, eps=eps)


def _audit_cache_path(output_dir: Path, args: argparse.Namespace) -> Path:
    return output_dir / (
        f"realiad_audit_resize{args.imagesize}_dilate{args.mask_dilate_kernel}_"
        f"verify{args.audit_verify_limit}_mask{args.mask_audit_limit}.json"
    )


def _trainable_cache_path(output_dir: Path, args: argparse.Namespace, token_side: int) -> Path:
    return output_dir / (
        f"realiad_trainable_anomalies_resize{args.imagesize}_dilate{args.mask_dilate_kernel}_"
        f"token{token_side}_scan{max(args.mask_audit_limit, args.batch_size * args.steps * 4)}.json"
    )


def _load_cached_json(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    with path.open() as f:
        return json.load(f)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    if args.resize != 336 or args.imagesize != 336:
        raise ValueError("Current ClipModel path is native 336 only for clip-large-336. Keep resize/imagesize at 336.")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_layer{args.layer}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    png_path = output_dir / f"{stem}_curves.png"

    transform = build_transform(args.resize, args.imagesize)
    mask_transform = build_mask_transform(args.imagesize)

    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.resize,
        crp_size=args.imagesize,
        msk_size=args.imagesize,
        msk_crp_size=args.imagesize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    records = flatten_records(dataset)
    normal_records, anomaly_records = collect_records_by_label(records)

    clip_model = ClipModel(args.clip_backbone, device=str(device)).eval()
    clip_model.visual_encoder = clip_model.visual_encoder.to(device)
    layer_index = LAYER_IDS.index(args.layer)
    token_side = args.imagesize // 14
    records_by_image_path = {rec["image_path"]: rec for rec in records}

    semantic_basis_by_class: dict[str, torch.Tensor] = {}

    audit_cache_path = _audit_cache_path(output_dir, args)
    audit = None
    if args.reuse_dataset_cache:
        audit = _load_cached_json(audit_cache_path)
        if audit is not None:
            print(f"[cache] loaded audit from {audit_cache_path}", flush=True)
    if audit is None:
        audit = audit_dataset(
            records=records,
            mask_transform=mask_transform,
            image_size=args.imagesize,
            token_side=token_side,
            verify_limit=args.audit_verify_limit,
            mask_audit_limit=args.mask_audit_limit,
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with audit_cache_path.open("w") as f:
            json.dump(audit, f, indent=2)
    print(
        f"[audit] records={audit['total_records']} anomaly={audit['total_anomaly_records']} "
        f"missing_masks={audit['missing_masks']} broken_images={audit['broken_images']} "
        f"broken_masks={audit['broken_masks']} zero_token_frac={audit.get('mask_zero_token_fraction', float('nan')):.4f}",
        flush=True,
    )
    shared_trainable_cache_path = _trainable_cache_path(output_dir, args, token_side)
    trainable_anomalies = None
    trainable_meta = None
    if args.reuse_dataset_cache:
        cached_trainable = _load_cached_json(shared_trainable_cache_path)
        if cached_trainable is not None:
            cached_records = []
            for rec in cached_trainable.get("records", []):
                current = records_by_image_path.get(rec["image_path"])
                if current is not None:
                    cached_records.append(current)
            if cached_records:
                trainable_anomalies = cached_records
                trainable_meta = cached_trainable.get("pool_meta", {})
                print(f"[cache] loaded train-pool from {shared_trainable_cache_path}", flush=True)
    if trainable_anomalies is None or trainable_meta is None:
        trainable_anomalies, trainable_meta = filter_trainable_anomalies(
            anomaly_records=anomaly_records,
            mask_transform=mask_transform,
            token_side=token_side,
            scan_limit=max(args.mask_audit_limit, args.batch_size * args.steps * 4),
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with shared_trainable_cache_path.open("w") as f:
            json.dump(
                {
                    "config": {
                        "mask_dilate_kernel": args.mask_dilate_kernel,
                        "token_side": token_side,
                        "scan_limit": max(args.mask_audit_limit, args.batch_size * args.steps * 4),
                    },
                    "pool_meta": trainable_meta,
                    "records": [
                        {
                            "image_path": rec["image_path"],
                            "mask_path": rec["mask_path"],
                            "class_name": rec["class_name"],
                            "anomaly_type": rec["anomaly_type"],
                            "sample_id": rec["sample_id"],
                        }
                        for rec in trainable_anomalies
                    ],
                },
                f,
                indent=2,
            )
    print(
        f"[train-pool] scanned={trainable_meta['scanned_anomalies_for_training']} "
        f"usable={trainable_meta['trainable_anomalies']} "
        f"missing={trainable_meta['training_missing_masks']} "
        f"zero_token={trainable_meta['training_zero_token_anomalies']}",
        flush=True,
    )
    if not trainable_anomalies:
        raise RuntimeError("No trainable anomaly samples survived token-grid downsampling.")
    trainable_cache_path = output_dir / f"{stem}_trainable_anomalies.json"
    with trainable_cache_path.open("w") as f:
        json.dump(
            {
                "config": {
                    "mask_dilate_kernel": args.mask_dilate_kernel,
                    "token_side": token_side,
                    "scan_limit": max(args.mask_audit_limit, args.batch_size * args.steps * 4),
                },
                "pool_meta": trainable_meta,
                "records": [
                    {
                        "image_path": rec["image_path"],
                        "mask_path": rec["mask_path"],
                        "class_name": rec["class_name"],
                        "anomaly_type": rec["anomaly_type"],
                        "sample_id": rec["sample_id"],
                    }
                    for rec in trainable_anomalies
                ],
            },
            f,
            indent=2,
        )

    model = AlphaSpaceKinematicRefiner(
        feature_dim=clip_model.feature_dimensions[layer_index],
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
    ).to(device)
    objective = AlphaSpaceObjective(
        lambda_sem=args.lambda_sem,
        lambda_normal=args.lambda_normal,
        lambda_anomaly=args.lambda_anomaly,
        lambda_pairwise=args.lambda_pairwise,
        pairwise_margin=args.pairwise_margin,
        sem_threshold=args.sem_threshold,
        sem_gas_beta=args.sem_gas_beta,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    rng = random.Random(args.seed)
    probe_rng = random.Random(args.seed + 101)
    probe_batch = probe_rng.sample(normal_records, min(len(normal_records), args.probe_normals))
    probe_batch += probe_rng.sample(trainable_anomalies, min(len(trainable_anomalies), args.probe_anomalies))
    probe_rng.shuffle(probe_batch)
    step_rows = []
    best_probe_score = -float("inf")
    best_probe_step = -1
    best_probe_metrics: dict[str, float] | None = None
    for step in range(1, args.steps + 1):
        tic = time.time()
        current_lambda_normal = linear_schedule(
            step=step,
            total_steps=args.steps,
            start_value=args.lambda_normal,
            end_value=args.lambda_normal if args.lambda_normal_end is None else args.lambda_normal_end,
            start_step=max(1, args.lambda_normal_decay_start),
        )
        current_lambda_anomaly = linear_schedule(
            step=step,
            total_steps=args.steps,
            start_value=args.lambda_anomaly if args.lambda_anomaly_start is None else args.lambda_anomaly_start,
            end_value=args.lambda_anomaly if args.lambda_anomaly_end is None else args.lambda_anomaly_end,
            start_step=1,
        )
        current_lr = cosine_decay_lr(
            step=step,
            total_steps=args.steps,
            base_lr=args.lr,
            start_step=max(1, args.lr_decay_start),
            min_ratio=args.lr_min_ratio,
        )
        for group in optimizer.param_groups:
            group["lr"] = current_lr
        objective.lambda_normal = current_lambda_normal
        objective.lambda_anomaly = current_lambda_anomaly
        batch = sample_balanced_batch(normal_records, trainable_anomalies, args.batch_size, rng)
        images, masks_t, basis_t, labels = build_batch_tensors(
            batch, transform, mask_transform, semantic_basis_by_class, clip_model, args, device
        )

        with torch.no_grad():
            features = clip_model.encode_image_from_tensors(images, shape="img")[layer_index].float()

        out = model(features, semantic_basis=basis_t)
        loss_stats = objective(
            raw_features=features,
            refined_features=out.refined,
            alpha=out.alpha,
            anomaly_mask=masks_t,
            semantic_basis=basis_t,
        )

        final_weight = model.alpha_head.head[-1].weight
        grad_normal = torch.autograd.grad(
            loss_stats["term_normal_gas"],
            final_weight,
            retain_graph=True,
            allow_unused=True,
        )[0]
        grad_anomaly = torch.autograd.grad(
            loss_stats["term_anomaly_gas"],
            final_weight,
            retain_graph=True,
            allow_unused=True,
        )[0]
        grad_pairwise = torch.autograd.grad(
            loss_stats["term_pairwise"],
            final_weight,
            retain_graph=True,
            allow_unused=True,
        )[0]

        optimizer.zero_grad()
        loss_stats["loss"].backward()
        optimizer.step()

        raw_tokens = features.flatten(2).transpose(1, 2)
        refined_tokens = out.refined.flatten(2).transpose(1, 2)
        local_mean_tokens = out.local_mean.flatten(2).transpose(1, 2)
        local_desc_tokens = out.local_descriptors.flatten(2).transpose(1, 2)
        anomaly_patch_mask = F.interpolate(masks_t.float(), size=(token_side, token_side), mode="nearest").reshape(len(batch), -1) > 0.5
        normal_patch_mask = ~anomaly_patch_mask

        raw_residual = compute_patch_residual(raw_tokens, local_mean_tokens)
        refined_residual = compute_patch_residual(refined_tokens, local_mean_tokens)

        raw_residual_n, valid_n = imagewise_mean(raw_residual, normal_patch_mask)
        raw_residual_a, valid_a = imagewise_mean(raw_residual, anomaly_patch_mask)
        refined_residual_n, _ = imagewise_mean(refined_residual, normal_patch_mask)
        refined_residual_a, _ = imagewise_mean(refined_residual, anomaly_patch_mask)
        desc_n, valid_desc_n = imagewise_mean_vec(local_desc_tokens, normal_patch_mask)
        desc_a, valid_desc_a = imagewise_mean_vec(local_desc_tokens, anomaly_patch_mask)

        token_anomaly_counts = anomaly_patch_mask.sum(dim=1)
        anomaly_image_mask = torch.tensor(labels, device=device, dtype=torch.bool)
        anomaly_token_counts_only = token_anomaly_counts[anomaly_image_mask]
        alpha_flat = out.alpha.flatten(2).transpose(1, 2).squeeze(-1)
        alpha_std = alpha_flat.std(dim=1, unbiased=False).mean()
        grad_cosine = float("nan")
        if grad_normal is not None and grad_anomaly is not None:
            gn = grad_normal.reshape(-1)
            ga = grad_anomaly.reshape(-1)
            if gn.norm().item() > 0 and ga.norm().item() > 0:
                grad_cosine = float(F.cosine_similarity(gn.unsqueeze(0), ga.unsqueeze(0), dim=1).item())
        row = {
            "step": step,
            "loss": float(loss_stats["loss"].detach().item()),
            "loss_sem": float(loss_stats["loss_sem"].item()),
            "loss_pairwise": float(loss_stats["loss_pairwise"].item()),
            "loss_normal_gas": float(loss_stats["loss_normal_gas"].item()),
            "loss_anomaly_gas": float(loss_stats["loss_anomaly_gas"].item()),
            "lambda_normal_current": current_lambda_normal,
            "lambda_anomaly_current": current_lambda_anomaly,
            "lr_current": current_lr,
            "alpha_normal_mean": float(loss_stats["alpha_normal_mean"].item()),
            "alpha_anomaly_mean": float(loss_stats["alpha_anomaly_mean"].item()),
            "alpha_gap": float(loss_stats["alpha_normal_mean"].item() - loss_stats["alpha_anomaly_mean"].item()),
            "raw_residual_normal": float(raw_residual_n[valid_n].mean().item()) if valid_n.any() else float("nan"),
            "refined_residual_normal": float(refined_residual_n[valid_n].mean().item()) if valid_n.any() else float("nan"),
            "raw_residual_anomaly": float(raw_residual_a[valid_a].mean().item()) if valid_a.any() else float("nan"),
            "refined_residual_anomaly": float(refined_residual_a[valid_a].mean().item()) if valid_a.any() else float("nan"),
            "input_l2_dist": float(
                torch.norm(
                    desc_n[valid_desc_n].mean(dim=0) - desc_a[valid_desc_a].mean(dim=0),
                    p=2,
                ).item()
            ) if valid_desc_n.any() and valid_desc_a.any() else float("nan"),
            "alpha_std_mean": float(alpha_std.item()),
            "grad_normal_gas_norm": float(grad_normal.norm().item()) if grad_normal is not None else 0.0,
            "grad_anomaly_gas_norm": float(grad_anomaly.norm().item()) if grad_anomaly is not None else 0.0,
            "grad_pairwise_norm": float(grad_pairwise.norm().item()) if grad_pairwise is not None else 0.0,
            "grad_cosine_normal_vs_anomaly": grad_cosine,
            "anomaly_image_count_in_batch": int(sum(labels)),
            "anomaly_zero_token_fraction_in_batch": float((anomaly_token_counts_only == 0).float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
            "anomaly_token_count_mean_in_batch": float(anomaly_token_counts_only.float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
        }
        if step % args.eval_interval == 0 or step == 1 or step == args.steps:
            probe_metrics = evaluate_probe_batch(
                model=model,
                objective=objective,
                clip_model=clip_model,
                probe_batch=probe_batch,
                semantic_basis_by_class=semantic_basis_by_class,
                transform=transform,
                mask_transform=mask_transform,
                args=args,
                device=device,
                layer_index=layer_index,
                token_side=token_side,
            )
            row.update(probe_metrics)
            if probe_metrics["probe_score"] > best_probe_score:
                best_probe_score = probe_metrics["probe_score"]
                best_probe_step = step
                best_probe_metrics = {"step": float(step), **probe_metrics}
        step_rows.append(row)
        print(
            f"[step {step}] loss={row['loss']:.4f} sem={row['loss_sem']:.4f} pair={row['loss_pairwise']:.4f} "
            f"ln={row['lambda_normal_current']:.4f} la={row['lambda_anomaly_current']:.4f} "
            f"lr={row['lr_current']:.5f} "
            f"alpha_n={row['alpha_normal_mean']:.4f} alpha_a={row['alpha_anomaly_mean']:.4f} "
            f"gap={row['alpha_gap']:.4f} in_l2={row['input_l2_dist']:.4f} "
            f"alpha_std={row['alpha_std_mean']:.4f} "
            f"gN={row['grad_normal_gas_norm']:.4e} gA={row['grad_anomaly_gas_norm']:.4e} "
            f"gP={row['grad_pairwise_norm']:.4e} cos={row['grad_cosine_normal_vs_anomaly']:.4f} "
            f"zero_tok={row['anomaly_zero_token_fraction_in_batch']:.4f} "
            f"t={time.time() - tic:.2f}s",
            flush=True,
        )

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(step_rows[0].keys()))
        writer.writeheader()
        writer.writerows(step_rows)

    summary = {
        "config": vars(args),
        "dataset_audit": audit,
        "trainable_anomaly_pool": trainable_meta,
        "trainable_anomaly_cache": str(trainable_cache_path),
        "final_step": step_rows[-1],
        "best_probe_metrics": best_probe_metrics,
        "best_probe_step": best_probe_step,
        "best_alpha_gap": float(max(row["alpha_gap"] for row in step_rows)),
        "min_anomaly_zero_token_fraction": float(min(row["anomaly_zero_token_fraction_in_batch"] for row in step_rows)),
        "mean_alpha_gap": float(np.mean([row["alpha_gap"] for row in step_rows])),
    }
    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    steps = [row["step"] for row in step_rows]
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    axes[0, 0].plot(steps, [row["loss"] for row in step_rows], label="total")
    axes[0, 0].plot(steps, [row["loss_sem"] for row in step_rows], label="sem")
    axes[0, 0].set_title("Loss")
    axes[0, 0].legend()

    axes[0, 1].plot(steps, [row["alpha_normal_mean"] for row in step_rows], label="alpha_n")
    axes[0, 1].plot(steps, [row["alpha_anomaly_mean"] for row in step_rows], label="alpha_a")
    axes[0, 1].set_title("Alpha Means")
    axes[0, 1].legend()

    axes[1, 0].plot(steps, [row["refined_residual_normal"] for row in step_rows], label="normal")
    axes[1, 0].plot(steps, [row["refined_residual_anomaly"] for row in step_rows], label="anomaly")
    axes[1, 0].set_title("Refined Angular Residual")
    axes[1, 0].legend()

    axes[1, 1].plot(steps, [row["anomaly_zero_token_fraction_in_batch"] for row in step_rows], label="zero-token frac")
    axes[1, 1].plot(steps, [row["anomaly_token_count_mean_in_batch"] for row in step_rows], label="mean tokens")
    axes[1, 1].set_title("Anomaly Token Survival")
    axes[1, 1].legend()
    fig.tight_layout()
    fig.savefig(png_path, dpi=180)

    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_png={png_path}")
    print(json.dumps(summary["final_step"], indent=2))


if __name__ == "__main__":
    main()
