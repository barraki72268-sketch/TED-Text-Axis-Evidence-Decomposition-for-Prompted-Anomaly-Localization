from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
    encode_text_features,
    l2_normalize,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import forward_up_to_layer, patchify_sequence  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Prompt projection diagnostics: overlap, norm retention, heatmaps.")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--layer", type=int, default=12)
    parser.add_argument("--sample_index", type=int, default=0, help="Index within anomaly samples of the target class.")
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--hybrid_lambda", type=float, default=1.0)
    parser.add_argument("--blur_sigma", type=float, default=4.0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_prompt_projection_diag")
    return parser.parse_args()


def project_orth(v: torch.Tensor, anchor: torch.Tensor) -> torch.Tensor:
    anchor = l2_normalize(anchor, dim=0)
    return v - torch.matmul(v, anchor.unsqueeze(1)).squeeze(1).unsqueeze(1) * anchor.unsqueeze(0)


def resize_mask(mask_np: np.ndarray, target_hw: tuple[int, int]) -> np.ndarray:
    mask_bin = (mask_np > 0).astype(np.uint8)
    target_h, target_w = target_hw
    if mask_bin.shape != (target_h, target_w):
        mask_bin = np.asarray(
            Image.fromarray(mask_bin * 255).resize((target_w, target_h), resample=Image.NEAREST),
            dtype=np.uint8,
        )
        mask_bin = (mask_bin > 0).astype(np.uint8)
    return mask_bin


def patch_scores_to_pixel_map(scores: np.ndarray, target_hw: tuple[int, int], blur_sigma: float) -> np.ndarray:
    side = int(round(math.sqrt(scores.shape[0])))
    if side * side != scores.shape[0]:
        raise ValueError(f"Cannot reshape patch scores of length {scores.shape[0]} into square grid.")
    target_h, target_w = target_hw
    score_t = torch.from_numpy(scores.reshape(1, 1, side, side)).float()
    pixel_map = F.interpolate(score_t, size=(target_h, target_w), mode="bilinear", align_corners=False)[
        0, 0
    ].cpu().numpy()
    if blur_sigma > 0:
        pixel_map = ndimage.gaussian_filter(pixel_map, sigma=float(blur_sigma))
    return pixel_map.astype(np.float32)


def summarize_map(score_map: np.ndarray, mask: np.ndarray) -> dict[str, float]:
    pos = mask > 0
    neg = ~pos
    out = {
        "global_mean": float(score_map.mean()),
        "global_std": float(score_map.std()),
    }
    if pos.any():
        out["inside_mean"] = float(score_map[pos].mean())
        out["inside_max"] = float(score_map[pos].max())
    else:
        out["inside_mean"] = float("nan")
        out["inside_max"] = float("nan")
    if neg.any():
        out["outside_mean"] = float(score_map[neg].mean())
        out["outside_max"] = float(score_map[neg].max())
    else:
        out["outside_mean"] = float("nan")
        out["outside_max"] = float("nan")
    if pos.any() and neg.any():
        out["inside_outside_gap"] = out["inside_mean"] - out["outside_mean"]
    else:
        out["inside_outside_gap"] = float("nan")
    return out


def save_figure(
    image_np: np.ndarray,
    mask_np: np.ndarray,
    orig_map: np.ndarray,
    proj_map: np.ndarray,
    hybrid_map: np.ndarray,
    out_path: Path,
) -> None:
    fig, axes = plt.subplots(1, 5, figsize=(20, 4))
    axes[0].imshow(image_np)
    axes[0].set_title("Image")
    axes[1].imshow(mask_np, cmap="gray")
    axes[1].set_title("GT Mask")
    vmax = max(float(orig_map.max()), float(proj_map.max()), float(hybrid_map.max()))
    for ax, title, score_map in [
        (axes[2], "Orig Prompt", orig_map),
        (axes[3], "Projected Prompt", proj_map),
        (axes[4], "Hybrid Prompt", hybrid_map),
    ]:
        ax.imshow(image_np)
        hm = ax.imshow(score_map, cmap="jet", alpha=0.6, vmin=0.0, vmax=vmax)
        ax.set_title(title)
    for ax in axes:
        ax.axis("off")
    fig.colorbar(hm, ax=axes[2:], fraction=0.02, pad=0.02)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()

    ds = OfficialVisAWinClipDataset(args.visa_root, args.split_csv, args.class_name, "test")
    anomaly_indices = [i for i in range(len(ds)) if ds[i][2] == 1]
    if not anomaly_indices:
        raise RuntimeError(f"No anomaly samples found for class {args.class_name}.")
    if args.sample_index < 0 or args.sample_index >= len(anomaly_indices):
        raise IndexError(f"sample_index={args.sample_index} is out of range for {len(anomaly_indices)} anomaly samples.")
    idx = anomaly_indices[args.sample_index]
    image_np, mask_np, label, name, _ = ds[idx]
    assert label == 1

    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(args.class_name)
    p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0].to(device)
    e_anom = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts).to(device)
    e_proj = project_orth(e_anom, p_norm)
    e_hybrid = e_anom + float(args.hybrid_lambda) * e_proj

    cos_to_normal = torch.matmul(e_anom, l2_normalize(p_norm, dim=0))
    proj_norm = torch.norm(e_proj, dim=-1)
    orig_norm = torch.norm(e_anom, dim=-1).clamp_min(1e-8)
    retention = proj_norm / orig_norm

    image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(
        device=device, dtype=backbone.visual.conv1.weight.dtype
    )
    seq = forward_up_to_layer(backbone, image_t, args.layer)
    _, patches = patchify_sequence(seq)
    patch_feat = l2_normalize(patches[0].float(), dim=-1)

    e_proj_scoring = l2_normalize(e_proj, dim=-1)
    e_hybrid_scoring = l2_normalize(e_hybrid, dim=-1)
    orig_scores = torch.matmul(patch_feat, e_anom.T).max(dim=1).values.detach().cpu().numpy()
    proj_scores = torch.matmul(patch_feat, e_proj_scoring.T).max(dim=1).values.detach().cpu().numpy()
    hybrid_scores = torch.matmul(patch_feat, e_hybrid_scoring.T).max(dim=1).values.detach().cpu().numpy()

    target_hw = (int(image_np.shape[0]), int(image_np.shape[1]))
    mask_bin = resize_mask(mask_np, target_hw)
    orig_map = patch_scores_to_pixel_map(orig_scores, target_hw, args.blur_sigma)
    proj_map = patch_scores_to_pixel_map(proj_scores, target_hw, args.blur_sigma)
    hybrid_map = patch_scores_to_pixel_map(hybrid_scores, target_hw, args.blur_sigma)

    stem = (
        f"{args.output_tag}_{args.class_name}_{args.backbone}_L{args.layer}_"
        f"sample{args.sample_index}"
    )
    fig_path = out_dir / f"{stem}_heatmap.png"
    json_path = out_dir / f"{stem}_summary.json"
    save_figure(image_np, mask_bin, orig_map, proj_map, hybrid_map, fig_path)

    summary = {
        "class_name": args.class_name,
        "sample_name": name,
        "sample_index": args.sample_index,
        "layer": args.layer,
        "backbone": args.backbone,
        "pretrained_dataset": args.pretrained_dataset,
        "normal_prompt": normal_prompt,
        "abnormal_prompts": abnormal_prompts,
        "cosine_to_normal": {
            "values": [float(x) for x in cos_to_normal.detach().cpu().tolist()],
            "mean": float(cos_to_normal.mean().item()),
            "max": float(cos_to_normal.max().item()),
            "min": float(cos_to_normal.min().item()),
        },
        "norm_retention_after_projection": {
            "values": [float(x) for x in retention.detach().cpu().tolist()],
            "mean": float(retention.mean().item()),
            "max": float(retention.max().item()),
            "min": float(retention.min().item()),
            "mean_percent": float(retention.mean().item() * 100.0),
        },
        "projection_cancellation_flag_lt_5pct": bool(float(retention.mean().item()) < 0.05),
        "heatmap_stats": {
            "original": summarize_map(orig_map, mask_bin.astype(bool)),
            "projected": summarize_map(proj_map, mask_bin.astype(bool)),
            "hybrid": summarize_map(hybrid_map, mask_bin.astype(bool)),
        },
        "figure_path": str(fig_path),
    }

    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    print(json_path)
    print(fig_path)


if __name__ == "__main__":
    main()
