from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import (  # noqa: E402
    build_model,
    get_learned_text_pair,
    load_prompt_learner,
)
from utils import get_transform  # noqa: E402


def build_dataset(root: str, image_size: int, mode: str):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode=mode)


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def logsumexp_similarity(patch: torch.Tensor, bank: torch.Tensor, tau: float) -> torch.Tensor:
    if bank.numel() == 0:
        return patch.new_zeros((patch.shape[0],))
    logits = tau * (patch @ bank.t())
    return (torch.logsumexp(logits, dim=-1) - math.log(bank.shape[0])) / tau


def farthest_point_subsample(feat: torch.Tensor, max_points: int) -> torch.Tensor:
    if feat.shape[0] <= max_points:
        return feat
    feat = F.normalize(feat.float(), dim=-1)
    mean_dir = F.normalize(feat.mean(dim=0, keepdim=True), dim=-1)
    min_dist = 1.0 - (feat @ mean_dir.t()).squeeze(1)
    selected = []
    for _ in range(max_points):
        idx = int(torch.argmax(min_dist).item())
        selected.append(idx)
        candidate_dist = 1.0 - (feat @ feat[idx : idx + 1].t()).squeeze(1)
        min_dist = torch.minimum(min_dist, candidate_dist)
        min_dist[idx] = -1.0
    return feat[torch.tensor(selected, dtype=torch.long)]


def compute_tied_whitening(bg_bank: torch.Tensor, ridge: float) -> tuple[torch.Tensor, torch.Tensor, dict]:
    bg_bank = bg_bank.float()
    mu = bg_bank.mean(dim=0)
    xc = bg_bank - mu
    cov = (xc.t() @ xc) / max(1, xc.shape[0] - 1)
    cov = cov + ridge * torch.eye(cov.shape[0], dtype=cov.dtype)
    eigvals, eigvecs = torch.linalg.eigh(cov)
    eigvals = torch.clamp(eigvals, min=ridge)
    whitening = eigvecs @ torch.diag(torch.rsqrt(eigvals)) @ eigvecs.t()
    stats = {
        "num_bg": int(bg_bank.shape[0]),
        "min_eig": float(eigvals.min().item()),
        "max_eig": float(eigvals.max().item()),
    }
    return mu, whitening, stats


def whiten_features(x: torch.Tensor, mu: torch.Tensor, whitening: torch.Tensor) -> torch.Tensor:
    return (x - mu.unsqueeze(0)) @ whitening.t()


def logmeanexp_negative_sqdist(patch: torch.Tensor, bank: torch.Tensor, tau: float) -> torch.Tensor:
    if bank.numel() == 0:
        return patch.new_zeros((patch.shape[0],))
    dist2 = torch.cdist(patch, bank, p=2.0) ** 2
    logits = -dist2 / tau
    return torch.logsumexp(logits, dim=-1) - math.log(bank.shape[0])


def collect_source_patch_banks(
    model,
    text_pair: torch.Tensor,
    data_root: str,
    image_size: int,
    features_list: list[int],
    device: str,
    heldout_class: str | None,
    max_good_per_class: int,
    max_defect_per_class: int,
    hard_frac: float,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    max_bg_per_image: int,
    tau: float,
    ridge: float,
):
    train_ds = build_dataset(data_root, image_size, mode="train")
    test_ds = build_dataset(data_root, image_size, mode="test")

    fp_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    def_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    bg_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}

    per_good: dict[str, int] = {cls_name: 0 for cls_name in train_ds.obj_list}
    per_defect: dict[str, int] = {cls_name: 0 for cls_name in test_ds.obj_list}

    with torch.no_grad():
        for idx in range(len(train_ds)):
            item = train_ds[idx]
            cls_name = item["cls_name"]
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_good[cls_name] >= max_good_per_class:
                continue
            per_good[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                selected_bg = patch
                if selected_bg.shape[0] > max_bg_per_image:
                    selected_bg = farthest_point_subsample(selected_bg, max_bg_per_image)
                bg_chunks[layer_idx].append(selected_bg.cpu())
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                patch_scores = ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)
                k = max(1, int(patch_scores.numel() * hard_frac))
                top_idx = torch.topk(patch_scores, k=k, largest=True).indices
                selected = patch[top_idx]
                if selected.shape[0] > max_fp_per_image:
                    selected = farthest_point_subsample(selected, max_fp_per_image)
                fp_chunks[layer_idx].append(selected.cpu())

        for idx in range(len(test_ds)):
            item = test_ds[idx]
            cls_name = item["cls_name"]
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0:
                continue
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_defect[cls_name] >= max_defect_per_class:
                continue
            per_defect[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"].unsqueeze(0).to(device).float()
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                h = int(round(patch.shape[0] ** 0.5))
                gt_small = F.interpolate(gt_mask, size=(h, h), mode="nearest")[0, 0].reshape(-1) > 0.5
                if int(gt_small.sum().item()) == 0:
                    continue
                selected = patch[gt_small]
                if selected.shape[0] > max_defect_per_image:
                    selected = farthest_point_subsample(selected, max_defect_per_image)
                def_chunks[layer_idx].append(selected.cpu())

    fp_banks: dict[int, torch.Tensor] = {}
    def_banks: dict[int, torch.Tensor] = {}
    bg_models: dict[int, dict] = {}
    bank_stats: dict[int, dict] = {}
    for layer_idx in range(len(features_list)):
        bg_bank = torch.cat(bg_chunks[layer_idx], dim=0) if bg_chunks[layer_idx] else torch.empty((0, 768))
        fp_bank = torch.cat(fp_chunks[layer_idx], dim=0) if fp_chunks[layer_idx] else torch.empty((0, 768))
        def_bank = torch.cat(def_chunks[layer_idx], dim=0) if def_chunks[layer_idx] else torch.empty((0, 768))
        if bg_bank.shape[0] > max_bank_per_layer:
            bg_bank = farthest_point_subsample(bg_bank, max_bank_per_layer)
        if fp_bank.shape[0] > max_bank_per_layer:
            fp_bank = farthest_point_subsample(fp_bank, max_bank_per_layer)
        if def_bank.shape[0] > max_bank_per_layer:
            def_bank = farthest_point_subsample(def_bank, max_bank_per_layer)
        fp_bank = F.normalize(fp_bank.float(), dim=-1) if fp_bank.numel() else fp_bank.float()
        def_bank = F.normalize(def_bank.float(), dim=-1) if def_bank.numel() else def_bank.float()
        bg_bank = F.normalize(bg_bank.float(), dim=-1) if bg_bank.numel() else bg_bank.float()
        mu_bg, whitening, whitening_stats = compute_tied_whitening(bg_bank, ridge=ridge)
        bg_models[layer_idx] = {
            "mu_bg": mu_bg,
            "whitening": whitening,
        }
        fp_banks[layer_idx] = whiten_features(fp_bank, mu_bg, whitening) if fp_bank.numel() else fp_bank
        def_banks[layer_idx] = whiten_features(def_bank, mu_bg, whitening) if def_bank.numel() else def_bank
        bank_stats[layer_idx] = {
            "num_bg": int(bg_bank.shape[0]),
            "num_fp": int(fp_banks[layer_idx].shape[0]),
            "num_defect": int(def_banks[layer_idx].shape[0]),
            "tau": float(tau),
            **whitening_stats,
        }
    return fp_banks, def_banks, bg_models, bank_stats


def evaluate_heldout_class(
    model,
    text_pair: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    bg_models: dict[int, dict],
    dataset,
    heldout_class: str,
    features_list: list[int],
    gammas: list[float],
    normal_topk_ratio: float,
    tau: float,
):
    results = {
        ("baseline", 0.0): {heldout_class: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}},
        ("pure_margin", 0.0): {heldout_class: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}},
    }
    stats = {
        ("baseline", 0.0): {
            "normal_topk": [],
            "normal_mean": [],
            "inside_outside_gap": [],
            "outside_inside_ratio": [],
            "margin_inside": [],
            "margin_outside": [],
            "q_def_mean": [],
            "q_fp_mean": [],
        },
        ("pure_margin", 0.0): {
            "normal_topk": [],
            "normal_mean": [],
            "inside_outside_gap": [],
            "outside_inside_ratio": [],
            "margin_inside": [],
            "margin_outside": [],
            "q_def_mean": [],
            "q_fp_mean": [],
        }
    }
    for gamma in gammas:
        results[("competitive", float(gamma))] = {heldout_class: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}}
        stats[("competitive", float(gamma))] = {
            "normal_topk": [],
            "normal_mean": [],
            "inside_outside_gap": [],
            "outside_inside_ratio": [],
            "margin_inside": [],
            "margin_outside": [],
            "q_def_mean": [],
            "q_fp_mean": [],
        }

    with torch.no_grad():
        for idx in range(len(dataset)):
            item = dataset[idx]
            if item["cls_name"] != heldout_class:
                continue
            image = item["img"].unsqueeze(0).to(next(model.parameters()).device)
            gt_mask = item["img_mask"].unsqueeze(0).clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask_np = gt_mask[0, 0].numpy().astype(bool)
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])

            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            layer_base_maps = []
            layer_margin_maps = []
            layer_q_def_maps = []
            layer_q_fp_maps = []
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                base_scores = ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)
                mu_bg = bg_models[layer_idx]["mu_bg"].to(patch.device)
                whitening = bg_models[layer_idx]["whitening"].to(patch.device)
                patch_w = whiten_features(patch, mu_bg, whitening)
                q_fp = logmeanexp_negative_sqdist(patch_w, fp_banks[layer_idx].to(patch.device), tau=tau)
                q_def = logmeanexp_negative_sqdist(patch_w, def_banks[layer_idx].to(patch.device), tau=tau)
                margin = q_def - q_fp
                h = int(round(base_scores.shape[0] ** 0.5))
                layer_base_maps.append(base_scores.reshape(h, h).detach().cpu().numpy())
                layer_margin_maps.append(margin.reshape(h, h).detach().cpu().numpy())
                layer_q_def_maps.append(q_def.reshape(h, h).detach().cpu().numpy())
                layer_q_fp_maps.append(q_fp.reshape(h, h).detach().cpu().numpy())

            base_map = np.mean(np.stack(layer_base_maps, axis=0), axis=0)
            margin_map = np.mean(np.stack(layer_margin_maps, axis=0), axis=0)
            q_def_map = np.mean(np.stack(layer_q_def_maps, axis=0), axis=0)
            q_fp_map = np.mean(np.stack(layer_q_fp_maps, axis=0), axis=0)
            target_h, target_w = gt_mask_np.shape
            base_map = (
                F.interpolate(
                    torch.from_numpy(base_map).unsqueeze(0).unsqueeze(0).float(),
                    size=(target_h, target_w),
                    mode="bilinear",
                    align_corners=False,
                )[0, 0]
                .cpu()
                .numpy()
            )
            margin_map = (
                F.interpolate(
                    torch.from_numpy(margin_map).unsqueeze(0).unsqueeze(0).float(),
                    size=(target_h, target_w),
                    mode="bilinear",
                    align_corners=False,
                )[0, 0]
                .cpu()
                .numpy()
            )
            q_def_map = (
                F.interpolate(
                    torch.from_numpy(q_def_map).unsqueeze(0).unsqueeze(0).float(),
                    size=(target_h, target_w),
                    mode="bilinear",
                    align_corners=False,
                )[0, 0]
                .cpu()
                .numpy()
            )
            q_fp_map = (
                F.interpolate(
                    torch.from_numpy(q_fp_map).unsqueeze(0).unsqueeze(0).float(),
                    size=(target_h, target_w),
                    mode="bilinear",
                    align_corners=False,
                )[0, 0]
                .cpu()
                .numpy()
            )
            final_maps = {
                ("baseline", 0.0): base_map.copy(),
                ("pure_margin", 0.0): margin_map.copy(),
            }
            for gamma in gammas:
                gate = 1.0 / (1.0 + np.exp(-gamma * margin_map))
                final_maps[("competitive", float(gamma))] = base_map * gate

            for key, final_map in final_maps.items():
                results[key][heldout_class]["gt_sp"].append(anomaly_flag)
                results[key][heldout_class]["pr_sp"].append(topk_mean(final_map, normal_topk_ratio))
                results[key][heldout_class]["imgs_masks"].append(gt_mask.numpy())
                results[key][heldout_class]["anomaly_maps"].append(final_map[None, ...])
                stats[key]["q_def_mean"].append(float(q_def_map.mean()))
                stats[key]["q_fp_mean"].append(float(q_fp_map.mean()))
                if anomaly_flag == 0:
                    stats[key]["normal_topk"].append(topk_mean(final_map, normal_topk_ratio))
                    stats[key]["normal_mean"].append(float(final_map.mean()))
                if gt_mask_np.any() and (~gt_mask_np).any():
                    inside = float(final_map[gt_mask_np].mean())
                    outside = float(final_map[~gt_mask_np].mean())
                    stats[key]["inside_outside_gap"].append(inside - outside)
                    stats[key]["outside_inside_ratio"].append(outside / (inside + 1e-6))
                    stats[key]["margin_inside"].append(float(margin_map[gt_mask_np].mean()))
                    stats[key]["margin_outside"].append(float(margin_map[~gt_mask_np].mean()))

    rows = []
    for key, result in results.items():
        result[heldout_class]["imgs_masks"] = np.concatenate(result[heldout_class]["imgs_masks"], axis=0)
        result[heldout_class]["anomaly_maps"] = np.concatenate(result[heldout_class]["anomaly_maps"], axis=0)
        image_auroc = float(image_level_metrics(result, heldout_class, "image-auroc"))
        pixel_auroc = float(pixel_level_metrics(result, heldout_class, "pixel-auroc"))
        pixel_aupro = float(pixel_level_metrics(result, heldout_class, "pixel-aupro"))
        row = {
            "mode": key[0],
            "gamma": float(key[1]),
            "heldout_class": heldout_class,
            "image_auroc": image_auroc,
            "pixel_auroc": pixel_auroc,
            "pixel_aupro": pixel_aupro,
            "inside_outside_gap": float(np.mean(stats[key]["inside_outside_gap"])) if stats[key]["inside_outside_gap"] else 0.0,
            "outside_inside_ratio": float(np.mean(stats[key]["outside_inside_ratio"])) if stats[key]["outside_inside_ratio"] else 0.0,
            "normal_topk_mean": float(np.mean(stats[key]["normal_topk"])) if stats[key]["normal_topk"] else 0.0,
            "normal_map_mean": float(np.mean(stats[key]["normal_mean"])) if stats[key]["normal_mean"] else 0.0,
            "margin_inside_mean": float(np.mean(stats[key]["margin_inside"])) if stats[key]["margin_inside"] else 0.0,
            "margin_outside_mean": float(np.mean(stats[key]["margin_outside"])) if stats[key]["margin_outside"] else 0.0,
            "q_def_mean": float(np.mean(stats[key]["q_def_mean"])) if stats[key]["q_def_mean"] else 0.0,
            "q_fp_mean": float(np.mean(stats[key]["q_fp_mean"])) if stats[key]["q_fp_mean"] else 0.0,
        }
        rows.append(row)
    return rows


def save_results(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe text-conditioned competitive patch scoring on AnomalyCLIP holdout MVTec")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_text_competitive_holdout_epoch5"),
    )
    parser.add_argument("--heldout_class", type=str, default="bottle")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=8)
    parser.add_argument("--max_defect_per_class", type=int, default=16)
    parser.add_argument("--max_bank_per_layer", type=int, default=4096)
    parser.add_argument("--max_fp_per_image", type=int, default=128)
    parser.add_argument("--max_defect_per_image", type=int, default=128)
    parser.add_argument("--max_bg_per_image", type=int, default=128)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--ridge", type=float, default=1e-4)
    parser.add_argument("--gammas", type=float, nargs="+", default=[1.0, 2.0, 5.0, 10.0])
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    args = parser.parse_args()

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    text_pair = get_learned_text_pair(model, learner).to(args.device)

    fp_banks, def_banks, bg_models, bank_stats = collect_source_patch_banks(
        model=model,
        text_pair=text_pair,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=args.heldout_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        max_bg_per_image=args.max_bg_per_image,
        tau=args.tau,
        ridge=args.ridge,
    )
    dataset = build_dataset(args.source_root, args.image_size, mode="test")
    rows = evaluate_heldout_class(
        model=model,
        text_pair=text_pair,
        fp_banks=fp_banks,
        def_banks=def_banks,
        bg_models=bg_models,
        dataset=dataset,
        heldout_class=args.heldout_class,
        features_list=args.features_list,
        gammas=args.gammas,
        normal_topk_ratio=args.normal_topk_ratio,
        tau=args.tau,
    )
    summary = {
        "heldout_class": args.heldout_class,
        "source_root": args.source_root,
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "max_good_per_class": args.max_good_per_class,
        "max_defect_per_class": args.max_defect_per_class,
        "max_bank_per_layer": args.max_bank_per_layer,
        "max_fp_per_image": args.max_fp_per_image,
        "max_defect_per_image": args.max_defect_per_image,
        "max_bg_per_image": args.max_bg_per_image,
        "tau": args.tau,
        "ridge": args.ridge,
        "bank_stats": bank_stats,
        "gammas": args.gammas,
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
