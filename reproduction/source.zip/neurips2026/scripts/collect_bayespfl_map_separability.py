from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from tqdm import tqdm

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
BAYES_ROOT = ROOT / "neurips2026" / "Bayes-PFL"
os.chdir(BAYES_ROOT)
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(BAYES_ROOT) not in sys.path:
    sys.path.insert(0, str(BAYES_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

from common_map_group_separability import (  # noqa: E402
    best_component_stats,
    plot_hist,
    save_summary,
    summarize_groups,
    top_fraction_mask,
    topk_mean_masked,
)
from datasets import Makedataset  # noqa: E402
from models.VPB import Context_Prompting, TextEncoder  # noqa: E402
from models.model_CLIP import Load_CLIP, tokenize  # noqa: E402
from test import _transform_test, setup_seed  # noqa: E402


def load_bayespfl_context_checkpoint(my_model, checkpoint, mode: str = "strict") -> dict:
    state = checkpoint["MyModel"] if isinstance(checkpoint, dict) and "MyModel" in checkpoint else checkpoint
    if mode == "strict":
        my_model.load_state_dict(state, strict=True)
        return {
            "mode": "strict",
            "loaded": len(state),
            "skipped": 0,
            "missing": 0,
            "unexpected": 0,
            "skipped_examples": [],
        }
    if mode != "compatible":
        raise ValueError(f"Unsupported checkpoint_load_mode: {mode}")

    current = my_model.state_dict()
    compatible = {}
    skipped = []
    for key, value in state.items():
        if key in current and tuple(current[key].shape) == tuple(value.shape):
            compatible[key] = value
        else:
            skipped.append(
                {
                    "key": key,
                    "checkpoint_shape": list(value.shape) if hasattr(value, "shape") else None,
                    "model_shape": list(current[key].shape) if key in current else None,
                }
            )
    missing, unexpected = my_model.load_state_dict(compatible, strict=False)
    return {
        "mode": "compatible",
        "loaded": len(compatible),
        "skipped": len(skipped),
        "missing": len(missing),
        "unexpected": len(unexpected),
        "skipped_examples": skipped[:12],
        "missing_examples": list(missing)[:12],
        "unexpected_examples": list(unexpected)[:12],
    }


def build_models(args):
    device = torch.device(f"cuda:{args.device_id}" if torch.cuda.is_available() else "cpu")

    with open(args.config_path, "r") as f:
        model_configs = json.load(f)
    args.vision_width = model_configs["vision_cfg"]["width"]
    args.text_width = model_configs["text_cfg"]["width"]
    args.embed_dim = model_configs["embed_dim"]

    model_clip, _, _ = Load_CLIP(args.image_size, args.pretrained_path, device=device)
    model_clip.to(device)
    model_clip.eval()

    pfl_text_encoder = TextEncoder(model_clip, args)
    my_model = Context_Prompting(args=args).to(device)
    my_model.eval()
    checkpoint = torch.load(args.checkpoint_path, map_location=device)
    load_report = load_bayespfl_context_checkpoint(
        my_model,
        checkpoint,
        mode=getattr(args, "checkpoint_load_mode", "strict"),
    )
    args.checkpoint_load_report = load_report
    print(json.dumps({"stage": "bayespfl_checkpoint_loaded", **load_report}, indent=2), flush=True)
    return device, model_clip, pfl_text_encoder, my_model


def infer_map(args, device, model_clip, pfl_text_encoder, my_model, image, cls_name, stage):
    with torch.no_grad():
        image_features, _, patch_tokens = model_clip.encode_image(image, args.features_list)
        text_embeddings, _ = my_model.forward_ensemble(
            pfl_text_encoder, image_features, patch_tokens, cls_name, device, tokenize, mode="test"
        )
        pro_img, anomaly_maps_list = my_model(text_embeddings, image_features, patch_tokens, stage=stage, mode="test")
        pro_img = pro_img.squeeze(2)

        temp_cls = 0.0
        for i in range(args.prompt_num * args.sample_num):
            text_probs = torch.cat(
                [pro_img[:, i].unsqueeze(0), pro_img[:, i + args.prompt_num * args.sample_num].unsqueeze(0)],
                dim=1,
            ).softmax(dim=-1)
            temp_cls = temp_cls + text_probs[0, 1]
        temp_cls = temp_cls / (args.prompt_num * args.sample_num)

        anomaly_maps = []
        for anomaly_map in anomaly_maps_list:
            for i in range(args.prompt_num * args.sample_num):
                temp = torch.softmax(
                    torch.stack(
                        [anomaly_map[:, i, :, :], anomaly_map[:, i + (args.prompt_num * args.sample_num), :, :]],
                        dim=1,
                    ),
                    dim=1,
                )
                anomaly_maps.append(temp[:, 1, :, :].cpu().numpy())
        anomaly_map = np.mean(anomaly_maps, axis=0)[0]
    return float(temp_cls.cpu().numpy()), anomaly_map


def main():
    parser = argparse.ArgumentParser("Collect Normal / Hard FP / True Defect separability for Bayes-PFL")
    parser.add_argument("--dataset", type=str, default="visa")
    parser.add_argument("--data_path", type=str, default=str(BAYES_ROOT / "dataset" / "mvisa" / "data"))
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_strict_mvtec" / "epoch_post_15_1.pth"),
    )
    parser.add_argument("--checkpoint_load_mode", type=str, choices=["strict", "compatible"], default="strict")
    parser.add_argument(
        "--config_path",
        type=str,
        default=str(BAYES_ROOT / "open_clip_local" / "model_configs" / "ViT-L-14-336.json"),
    )
    parser.add_argument(
        "--pretrained_path",
        type=str,
        default="/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt",
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--num_flows", type=int, default=10)
    parser.add_argument("--prompt_context_len", type=int, default=5)
    parser.add_argument("--prompt_num", type=int, default=3)
    parser.add_argument("--prompt_state_len", type=int, default=5)
    parser.add_argument("--sample_num", type=int, default=5)
    parser.add_argument("--device_id", type=int, default=0)
    parser.add_argument("--seed", type=int, default=333)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_points", type=int, default=200000)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_map_separability_matched_epoch15"),
    )
    args = parser.parse_args()

    setup_seed(args.seed)
    device, model_clip, pfl_text_encoder, my_model = build_models(args)
    preprocess_test = _transform_test(args.image_size)
    make_dataset = Makedataset(train_data_path=args.data_path, preprocess_test=preprocess_test, mode="test", image_size=args.image_size)
    test_dataloader, obj_list = make_dataset.mask_dataset(name=args.dataset, product_list=None, batchsize=1, shuf=False)

    groups = {"normal": [], "hard_fp": [], "true_defect": [], "outside": []}
    matched = {
        "hard_fp_topk": [],
        "true_defect_topk": [],
        "outside_topk": [],
        "hard_fp_comp_peak": [],
        "hard_fp_comp_mean": [],
        "hard_fp_comp_area": [],
        "true_defect_comp_peak": [],
        "true_defect_comp_mean": [],
        "true_defect_comp_area": [],
        "outside_comp_peak": [],
        "outside_comp_mean": [],
        "outside_comp_area": [],
    }

    stage = int(Path(args.checkpoint_path).stem.split("_")[-1]) if "epoch_post" in args.checkpoint_path else 2

    print(
        json.dumps(
            {
                "stage": "map_separability_start",
                "dataset": args.dataset,
                "num_images": len(test_dataloader.dataset),
                "hard_frac": args.hard_frac,
                "checkpoint_path": args.checkpoint_path,
                "stage_id": stage,
            },
            indent=2,
        ),
        flush=True,
    )

    for img_idx, items in enumerate(tqdm(test_dataloader), start=1):
        image = items["img"].to(device)
        cls_name = items["cls_name"]
        is_anomaly = int(items["anomaly"][0].item())
        gt_mask = items["img_mask"][0, 0].numpy() > 0.5

        _, anomaly_map = infer_map(args, device, model_clip, pfl_text_encoder, my_model, image, cls_name, stage)
        score_mask = top_fraction_mask(anomaly_map, args.hard_frac)

        if is_anomaly and gt_mask.any():
            groups["true_defect"].append(anomaly_map[gt_mask].reshape(-1))
            groups["outside"].append(anomaly_map[~gt_mask].reshape(-1))
            matched["true_defect_topk"].append(topk_mean_masked(anomaly_map, gt_mask, args.hard_frac))
            matched["outside_topk"].append(topk_mean_masked(anomaly_map, ~gt_mask, args.hard_frac))
            defect_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="inside")
            outside_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="outside")
            if defect_comp is not None:
                matched["true_defect_comp_peak"].append(defect_comp["peak"])
                matched["true_defect_comp_mean"].append(defect_comp["mean"])
                matched["true_defect_comp_area"].append(defect_comp["area"])
            if outside_comp is not None:
                matched["outside_comp_peak"].append(outside_comp["peak"])
                matched["outside_comp_mean"].append(outside_comp["mean"])
                matched["outside_comp_area"].append(outside_comp["area"])
        else:
            hard_mask = score_mask
            groups["hard_fp"].append(anomaly_map[hard_mask].reshape(-1))
            groups["normal"].append(anomaly_map[~hard_mask].reshape(-1))
            matched["hard_fp_topk"].append(float(anomaly_map[hard_mask].mean()))
            hard_comp = best_component_stats(anomaly_map, score_mask)
            if hard_comp is not None:
                matched["hard_fp_comp_peak"].append(hard_comp["peak"])
                matched["hard_fp_comp_mean"].append(hard_comp["mean"])
                matched["hard_fp_comp_area"].append(hard_comp["area"])

        if img_idx % 64 == 0 or img_idx == len(test_dataloader):
            print(
                json.dumps(
                    {
                        "stage": "map_separability_progress",
                        "images_done": img_idx,
                        "images_total": len(test_dataloader),
                    }
                ),
                flush=True,
            )

    groups_np = {}
    for key, chunks in groups.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        if vals.size > args.max_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(vals.size, size=args.max_points, replace=False)
            vals = vals[idx]
        groups_np[key] = vals.astype(np.float32, copy=False)

    summary = {
        "host": "Bayes-PFL",
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "num_images": len(test_dataloader.dataset),
        "summary": summarize_groups(groups_np, max_summary_points=args.max_points),
    }
    matched_np = {
        key: np.asarray([v for v in vals if np.isfinite(v)], dtype=np.float32)
        for key, vals in matched.items()
    }
    summary["matched_summary"] = summarize_groups(
        matched_np,
        max_summary_points=args.max_points,
        pairs=[
            ("true_defect_topk", "hard_fp_topk"),
            ("true_defect_topk", "outside_topk"),
            ("true_defect_comp_peak", "hard_fp_comp_peak"),
            ("true_defect_comp_peak", "outside_comp_peak"),
            ("true_defect_comp_mean", "hard_fp_comp_mean"),
            ("true_defect_comp_mean", "outside_comp_mean"),
        ],
    )
    save_dir = Path(args.save_dir)
    save_summary(summary, save_dir)
    plot_hist(groups_np, save_dir / "hist.png", "Bayes-PFL Map Separability")
    plot_hist(
        {
            "hard_fp_topk": matched_np["hard_fp_topk"],
            "true_defect_topk": matched_np["true_defect_topk"],
            "outside_topk": matched_np["outside_topk"],
        },
        save_dir / "matched_topk_hist.png",
        "Bayes-PFL Matched Top-k Separability",
    )
    plot_hist(
        {
            "hard_fp_comp_peak": matched_np["hard_fp_comp_peak"],
            "true_defect_comp_peak": matched_np["true_defect_comp_peak"],
            "outside_comp_peak": matched_np["outside_comp_peak"],
        },
        save_dir / "matched_component_peak_hist.png",
        "Bayes-PFL Component Peak Separability",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
