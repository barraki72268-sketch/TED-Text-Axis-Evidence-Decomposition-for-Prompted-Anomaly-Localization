#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[2]
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from official_parallel_test_faprompt import (  # noqa: E402
    PRESET_CONFIGS,
    MetaDataset,
    build_model,
    compute_faprompt_outputs,
    downsample_mask_to_patch,
    get_or_collect_source_banks,
    high_score_gate_tokens,
    learned_text_pair,
    logmeanexp_negative_sqdist_1d,
    prescore_subspace_transport_tokens,
    spatial_tanh_zscore,
    subspace_host_residual_token_score,
    train_subspace_host_residual_calibrator,
    upsample_tokens,
)


CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)

C_DEFECT = "#D64A2F"
C_HARD = "#2878A7"
C_TRAINFREE = "#D79A2B"
C_CALIB = "#1B8A6B"
C_DARK = "#202020"


def zscore_1d(x: torch.Tensor) -> torch.Tensor:
    return (x - x.mean()) / x.std().clamp_min(1e-6)


def top_indices(scores: torch.Tensor, frac: float, cap: int) -> torch.Tensor:
    k = max(1, int(math.ceil(scores.numel() * frac)))
    k = min(k, cap, scores.numel())
    return torch.topk(scores, k=k, largest=True).indices


def denormalize_image(image_t: torch.Tensor) -> np.ndarray:
    image = image_t.detach().cpu().float().numpy().transpose(1, 2, 0)
    return np.clip((image * CLIP_STD + CLIP_MEAN) * 255.0, 0, 255).astype(np.uint8)


def crop_center(image: np.ndarray, cy: int, cx: int, size: int) -> np.ndarray:
    h, w = image.shape[:2]
    half = size // 2
    y0 = max(0, min(h - size, cy - half))
    x0 = max(0, min(w - size, cx - half))
    y1 = min(h, y0 + size)
    x1 = min(w, x0 + size)
    crop = image[y0:y1, x0:x1]
    if crop.shape[:2] == (size, size):
        return crop
    out = np.zeros((size, size, 3), dtype=np.uint8)
    out[: crop.shape[0], : crop.shape[1]] = crop
    return out


def blend_mask(image: np.ndarray, mask: np.ndarray | None, color: tuple[int, int, int], alpha: float = 0.42) -> np.ndarray:
    if mask is None:
        return image
    mask_bool = mask.astype(bool)
    if mask_bool.shape[:2] != image.shape[:2] or not mask_bool.any():
        return image
    out = image.astype(np.float32).copy()
    color_arr = np.asarray(color, dtype=np.float32).reshape(1, 1, 3)
    out[mask_bool] = (1.0 - alpha) * out[mask_bool] + alpha * color_arr
    return np.clip(out, 0, 255).astype(np.uint8)


def draw_mask_contour(image: np.ndarray, mask: np.ndarray | None, color: tuple[int, int, int], thickness: int = 3) -> np.ndarray:
    if mask is None:
        return image
    m = mask.astype(bool)
    if m.shape[:2] != image.shape[:2] or not m.any():
        return image
    inner = (
        m
        & np.roll(m, 1, axis=0)
        & np.roll(m, -1, axis=0)
        & np.roll(m, 1, axis=1)
        & np.roll(m, -1, axis=1)
    )
    contour = m & ~inner
    thick = contour.copy()
    for _ in range(max(1, thickness) - 1):
        thick = (
            thick
            | np.roll(thick, 1, axis=0)
            | np.roll(thick, -1, axis=0)
            | np.roll(thick, 1, axis=1)
            | np.roll(thick, -1, axis=1)
        )
    out = image.copy()
    out[thick] = np.asarray(color, dtype=np.uint8)
    return out


def draw_box(image: np.ndarray, cy: int, cx: int, size: int, color: tuple[int, int, int]) -> np.ndarray:
    out = Image.fromarray(image.copy())
    draw = ImageDraw.Draw(out)
    half = size // 2
    x0 = max(0, cx - half)
    y0 = max(0, cy - half)
    x1 = min(image.shape[1] - 1, cx + half)
    y1 = min(image.shape[0] - 1, cy + half)
    for off in range(4):
        draw.rectangle([x0 - off, y0 - off, x1 + off, y1 + off], outline=color)
    return np.asarray(out)


def normalize_map(score: np.ndarray, lo: float | None = None, hi: float | None = None) -> np.ndarray:
    score = np.asarray(score, dtype=np.float32)
    if lo is None:
        lo = float(np.percentile(score, 2))
    if hi is None:
        hi = float(np.percentile(score, 98))
    if hi <= lo:
        hi = lo + 1e-6
    return np.clip((score - lo) / (hi - lo), 0.0, 1.0)


def overlay_heatmap(image: np.ndarray, score: np.ndarray, lo: float, hi: float, alpha: float = 0.48) -> np.ndarray:
    norm = normalize_map(score, lo=lo, hi=hi)
    heat = plt.get_cmap("magma")(norm)[..., :3]
    base = image.astype(np.float32) / 255.0
    out = (1.0 - alpha) * base + alpha * heat
    return np.clip(out * 255.0, 0, 255).astype(np.uint8)


def save_trace_images(out_dir: Path, selected: dict, prefix: str, crop_size: int) -> dict:
    image = selected.pop("_image")
    mask = selected.pop("_mask", None)
    cy = int(selected["cy"])
    cx = int(selected["cx"])
    color = (216, 74, 47) if selected["label"] == 1 else (40, 120, 167)
    if selected["label"] == 1:
        image = blend_mask(image, mask, color=color, alpha=0.16)
        image = draw_mask_contour(image, mask, color=color, thickness=3)
    full_path = out_dir / f"{prefix}_full_box.png"
    crop_path = out_dir / f"{prefix}_crop.png"
    Image.fromarray(draw_box(image, cy, cx, crop_size, color)).save(full_path)
    Image.fromarray(crop_center(image, cy, cx, crop_size)).save(crop_path)
    selected["full_box_path"] = str(full_path)
    selected["crop_path"] = str(crop_path)
    return selected


def draw_clean_heatmap_recovery(out_dir: Path, sample_cache: dict[int, dict], trace: dict) -> dict:
    selected = trace["selected"]
    rows = [
        ("Defect image", selected["defect"], C_DEFECT),
        ("Hard-normal image", selected["hard_normal"], C_HARD),
    ]
    fig, axes = plt.subplots(2, 4, figsize=(12.4, 6.1), constrained_layout=True)
    col_titles = ["Input", "Baseline map", "C-TED map", "Patch score"]
    for j, title in enumerate(col_titles):
        axes[0, j].set_title(title, fontsize=12, fontweight="bold", pad=5)

    for i, (row_title, rec, color_hex) in enumerate(rows):
        cache = sample_cache[int(rec["sample_id"])]
        image = cache["image"]
        mask = cache["mask"]
        baseline_map = cache["baseline_map"]
        calibrated_map = cache["calibrated_map"]
        lo = float(np.percentile(np.concatenate([baseline_map.reshape(-1), calibrated_map.reshape(-1)]), 2))
        hi = float(np.percentile(np.concatenate([baseline_map.reshape(-1), calibrated_map.reshape(-1)]), 98))

        input_img = image.copy()
        if int(rec["label"]) == 1:
            input_img = blend_mask(input_img, mask, color=(216, 74, 47), alpha=0.13)
            input_img = draw_mask_contour(input_img, mask, color=(216, 74, 47), thickness=2)
        input_img = draw_box(input_img, int(rec["cy"]), int(rec["cx"]), int(args_crop := 112), tuple(int(color_hex.lstrip("#")[k:k+2], 16) for k in (0, 2, 4)))

        panels = [
            input_img,
            overlay_heatmap(image, baseline_map, lo, hi),
            overlay_heatmap(image, calibrated_map, lo, hi),
        ]
        for j, panel in enumerate(panels):
            axes[i, j].imshow(panel)
            axes[i, j].set_axis_off()
        axes[i, 0].set_ylabel(row_title, fontsize=12, fontweight="bold", color=color_hex)

        ax = axes[i, 3]
        vals = [float(rec["baseline"]), float(rec["calibrated"])]
        ax.bar([0, 1], vals, color=["#777777", "#1B8A6B"], width=0.58)
        ax.set_xticks([0, 1], ["B", "C"], fontsize=10, fontweight="bold")
        ax.set_ylabel("score", fontsize=10, fontweight="bold")
        ax.grid(axis="y", alpha=0.22)
        ymin = min(vals)
        ymax = max(vals)
        pad = max(0.002, 0.45 * (ymax - ymin + 1e-6))
        ax.set_ylim(ymin - pad, ymax + pad)
        for x, v in zip([0, 1], vals):
            ax.text(x, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9, fontweight="bold")
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

    defect = selected["defect"]
    hard = selected["hard_normal"]
    b_gap = float(defect["baseline"]) - float(hard["baseline"])
    c_gap = float(defect["calibrated"]) - float(hard["calibrated"])
    fig.suptitle(
        f"Hard-FP recovery: D-H-FP gap {b_gap:+.4f} to {c_gap:+.4f}",
        fontsize=14,
        fontweight="bold",
    )
    png = out_dir / "faprompt_clean_heatmap_recovery.png"
    pdf = out_dir / "faprompt_clean_heatmap_recovery.pdf"
    fig.savefig(png, dpi=240, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {"png": str(png), "pdf": str(pdf)}


def auc_pos_vs_neg(pos: np.ndarray, neg: np.ndarray) -> float:
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def smooth(y: np.ndarray, sigma: float = 1.45, radius: int = 6) -> np.ndarray:
    x = np.arange(-radius, radius + 1, dtype=np.float32)
    k = np.exp(-(x * x) / (2.0 * sigma * sigma))
    k /= k.sum()
    return np.convolve(y, k, mode="same")


def hist_stats(pos: np.ndarray, neg: np.ndarray, bins: int = 70) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    lo = float(min(pos.min(), neg.min()))
    hi = float(max(pos.max(), neg.max()))
    if hi <= lo:
        hi = lo + 1e-6
    pad = 0.04 * (hi - lo)
    edges = np.linspace(lo - pad, hi + pad, bins + 1)
    hp, _ = np.histogram(pos, bins=edges, density=True)
    hn, _ = np.histogram(neg, bins=edges, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    hp = smooth(hp)
    hn = smooth(hn)
    dx = centers[1] - centers[0] if len(centers) > 1 else 1.0
    overlap = float(np.minimum(hp, hn).sum() * dx)
    return centers, hp, hn, {
        "auc": auc_pos_vs_neg(pos, neg),
        "overlap": overlap,
        "median_gap": float(np.median(pos) - np.median(neg)),
        "hard_above_defect_median": float((neg > np.median(pos)).mean()),
    }


def draw_hist(ax, pos: np.ndarray, neg: np.ndarray, title: str, xlabel: str, selected: dict | None = None) -> dict:
    centers, hp, hn, stats = hist_stats(pos, neg)
    ov = np.minimum(hp, hn)
    ax.fill_between(centers, hp, color=C_DEFECT, alpha=0.30)
    ax.fill_between(centers, hn, color=C_HARD, alpha=0.24)
    ax.fill_between(centers, ov, color="#4B4B4B", alpha=0.16, hatch="///", edgecolor="#4B4B4B", linewidth=0)
    ax.plot(centers, hp, color=C_DEFECT, lw=3.0, ls="--", label="defect")
    ax.plot(centers, hn, color=C_HARD, lw=3.0, ls="-", label="hard normal")
    ax.axvline(float(np.median(pos)), color=C_DEFECT, lw=2.0, ls="--", alpha=0.88)
    ax.axvline(float(np.median(neg)), color=C_HARD, lw=2.0, ls="-", alpha=0.80)
    if selected is not None:
        ymax = max(float(hp.max()), float(hn.max()), 1e-6)
        ax.scatter(
            [selected["defect"]],
            [0.145 * ymax],
            s=170,
            marker="^",
            color=C_DEFECT,
            edgecolor="black",
            linewidth=1.25,
            zorder=22,
        )
        ax.scatter(
            [selected["hard_normal"]],
            [0.085 * ymax],
            s=155,
            marker="o",
            color=C_HARD,
            edgecolor="black",
            linewidth=1.25,
            zorder=21,
        )
    ax.set_title(title, fontsize=18, fontweight="bold", pad=10)
    ax.set_xlabel(xlabel, fontsize=12.5, fontweight="bold", labelpad=7)
    ax.set_ylabel("Density", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.tick_params(axis="both", labelsize=10.5, width=1.2)
    ax.grid(alpha=0.14)
    ax.text(
        0.04,
        0.94,
        f"AUC {stats['auc']:.3f}\nOverlap {stats['overlap']:.3f}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#D7D7D7", "alpha": 0.90, "pad": 4},
    )
    return stats


def pairwise_stats(pos_a: np.ndarray, neg_a: np.ndarray) -> dict:
    correct = pos_a[:, None] > neg_a[None, :]
    return {
        "pair_auc": float(correct.mean()),
        "num_defect": int(pos_a.shape[0]),
        "num_hard_normal": int(neg_a.shape[0]),
    }


def pick_pair(records: list[dict]) -> tuple[dict, dict, dict]:
    pos = [r for r in records if r["label"] == 1]
    neg = [r for r in records if r["label"] == 0]
    pos_b = np.asarray([r["baseline"] for r in pos], dtype=np.float32)
    neg_b = np.asarray([r["baseline"] for r in neg], dtype=np.float32)
    lo = max(float(np.quantile(pos_b, 0.20)), float(np.quantile(neg_b, 0.20)))
    hi = min(float(np.quantile(pos_b, 0.80)), float(np.quantile(neg_b, 0.80)))
    if hi <= lo:
        lo = max(float(np.quantile(pos_b, 0.10)), float(np.quantile(neg_b, 0.10)))
        hi = min(float(np.quantile(pos_b, 0.90)), float(np.quantile(neg_b, 0.90)))
    pos_band = [r for r in pos if lo <= r["baseline"] <= hi] or pos
    neg_band = [r for r in neg if lo <= r["baseline"] <= hi] or neg

    best = None
    best_obj = -1e9
    for d in pos_band:
        for h in neg_band:
            base_wrong = 1.0 if d["baseline"] <= h["baseline"] else 0.0
            calib_repair = 1.0 if d["calibrated"] > h["calibrated"] else 0.0
            base_gap = abs(d["baseline"] - h["baseline"])
            pca_before = float(np.linalg.norm(np.asarray(d["xy"], dtype=np.float32) - np.asarray(h["xy"], dtype=np.float32)))
            pca_after = float(np.linalg.norm(np.asarray(d["xy_after"], dtype=np.float32) - np.asarray(h["xy_after"], dtype=np.float32)))
            pca_gain = pca_after - pca_before
            mask_overlap = float(d.get("mask_overlap_frac", 0.0))
            obj = (
                1.15 * (d["calibrated"] - h["calibrated"])
                + 0.35 * (d["train_free"] - h["train_free"])
                + 2.8 * pca_gain
                + 0.65 * mask_overlap
                - 2.0 * base_gap
                + 0.45 * base_wrong
                + 0.55 * base_wrong * calib_repair
            )
            if obj > best_obj:
                best = (d, h)
                best_obj = obj
    assert best is not None
    return best[0], best[1], {
        "overlap_band_low": lo,
        "overlap_band_high": hi,
        "objective": float(best_obj),
        "baseline_gap": float(best[0]["baseline"] - best[1]["baseline"]),
        "train_free_gap": float(best[0]["train_free"] - best[1]["train_free"]),
        "calibrated_evidence_gap": float(best[0]["calibrated_evidence"] - best[1]["calibrated_evidence"]),
        "calibrated_final_gap": float(best[0]["calibrated"] - best[1]["calibrated"]),
        "pca_pair_distance_before": float(np.linalg.norm(np.asarray(best[0]["xy"], dtype=np.float32) - np.asarray(best[1]["xy"], dtype=np.float32))),
        "pca_pair_distance_after": float(np.linalg.norm(np.asarray(best[0]["xy_after"], dtype=np.float32) - np.asarray(best[1]["xy_after"], dtype=np.float32))),
    }


def draw_trace_panel(ax, trace: dict, compact: bool = False) -> None:
    ax.axis("off")
    ax.set_title("Traced Patch Pair", fontsize=18, fontweight="bold", pad=10)
    rows = [
        ("defect patch", "^", trace["selected"]["defect"], C_DEFECT),
        ("hard normal patch", "o", trace["selected"]["hard_normal"], C_HARD),
    ]
    y0s = [0.58, 0.02]
    for (name, marker, rec, color), y0 in zip(rows, y0s):
        full = np.asarray(Image.open(rec["full_box_path"]).convert("RGB"))
        crop = np.asarray(Image.open(rec["crop_path"]).convert("RGB"))
        if compact:
            ax_full = ax.inset_axes([0.02, y0 + 0.05, 0.47, 0.32])
            ax_crop = ax.inset_axes([0.53, y0 + 0.05, 0.43, 0.32])
        else:
            ax_full = ax.inset_axes([0.02, y0 + 0.07, 0.42, 0.34])
            ax_crop = ax.inset_axes([0.47, y0 + 0.07, 0.25, 0.34])
        ax_full.imshow(full)
        ax_crop.imshow(crop)
        for child_ax in (ax_full, ax_crop):
            child_ax.set_xticks([])
            child_ax.set_yticks([])
            for spine in child_ax.spines.values():
                spine.set_linewidth(2.3)
                spine.set_edgecolor(color)
        ax.scatter([0.025], [y0 + 0.405], s=70, marker=marker, color=color, edgecolor="black", linewidth=0.75, transform=ax.transAxes, zorder=30)
        ax.text(0.07, y0 + 0.39, name, transform=ax.transAxes, ha="left", va="bottom", fontsize=12.3, fontweight="bold", color=color)
        if not compact:
            ax.text(
                0.75,
                y0 + 0.285,
                f"base {rec['baseline']:.3f}\nfree {rec['train_free']:.3f}\ncalib {rec['calibrated']:.3f}",
                transform=ax.transAxes,
                ha="left",
                va="center",
                fontsize=10.5,
                fontweight="bold",
                linespacing=1.22,
            )


def draw_support_transport_panel(ax, arrays: dict, trace: dict) -> dict:
    labels = arrays["labels"]
    support = arrays["support_xy"]
    support_after = arrays["support_xy_after"]
    source_support = arrays["source_support_xy"]
    source_label = arrays["source_labels"]
    rng = np.random.default_rng(0)
    keep_fp = rng.choice(np.where(source_label == 0)[0], size=min(800, int((source_label == 0).sum())), replace=False)
    keep_def = rng.choice(np.where(source_label == 1)[0], size=min(800, int((source_label == 1).sum())), replace=False)
    target_keep = []
    for lab in (0, 1):
        idx = np.where(labels == lab)[0]
        if idx.size:
            target_keep.append(rng.choice(idx, size=min(105, idx.size), replace=False))
    target_keep = np.concatenate(target_keep) if target_keep else np.arange(labels.size)

    ax.set_title("Support Evidence Transport", fontsize=18, fontweight="bold", pad=10)
    all_xy = np.concatenate([source_support[keep_fp], source_support[keep_def], support[target_keep], support_after[target_keep]], axis=0)
    xlo, xhi = np.quantile(all_xy[:, 0], [0.01, 0.99])
    ylo, yhi = np.quantile(all_xy[:, 1], [0.01, 0.99])
    xpad = 0.08 * max(float(xhi - xlo), 1e-6)
    ypad = 0.08 * max(float(yhi - ylo), 1e-6)

    selected_ids = {
        "defect": int(trace["selected"]["defect"]["record_id"]),
        "hard_normal": int(trace["selected"]["hard_normal"]["record_id"]),
    }
    ax.scatter(source_support[keep_fp, 0], source_support[keep_fp, 1], s=7, c=C_HARD, alpha=0.060, linewidths=0)
    ax.scatter(source_support[keep_def, 0], source_support[keep_def, 1], s=7, c=C_DEFECT, alpha=0.060, linewidths=0)

    for lab, color in [(0, C_HARD), (1, C_DEFECT)]:
        idx = target_keep[labels[target_keep] == lab]
        if idx.size == 0:
            continue
        ax.quiver(
            support[idx, 0],
            support[idx, 1],
            support_after[idx, 0] - support[idx, 0],
            support_after[idx, 1] - support[idx, 1],
            angles="xy",
            scale_units="xy",
            scale=1.0,
            color=color,
            alpha=0.18,
            width=0.0032,
            headwidth=3.6,
            headlength=4.6,
            headaxislength=3.7,
            zorder=3,
        )

    for lab, color, marker, size in [(0, C_HARD, "o", 30), (1, C_DEFECT, "^", 38)]:
        idx = target_keep[labels[target_keep] == lab]
        if idx.size == 0:
            continue
        ax.scatter(support[idx, 0], support[idx, 1], s=size, facecolors="none", edgecolors=color, linewidths=1.0, alpha=0.48, marker=marker, zorder=4)
        ax.scatter(support_after[idx, 0], support_after[idx, 1], s=size, c=color, alpha=0.70, edgecolors="white", linewidths=0.35, marker=marker, zorder=5)

    for key, color, marker in [("defect", C_DEFECT, "^"), ("hard_normal", C_HARD, "o")]:
        rid = selected_ids[key]
        ax.quiver(
            [support[rid, 0]],
            [support[rid, 1]],
            [support_after[rid, 0] - support[rid, 0]],
            [support_after[rid, 1] - support[rid, 1]],
            angles="xy",
            scale_units="xy",
            scale=1.0,
            color=color,
            alpha=0.95,
            width=0.012,
            headwidth=4.2,
            headlength=5.3,
            headaxislength=4.4,
            zorder=18,
        )
        ax.scatter([support[rid, 0]], [support[rid, 1]], s=155, facecolors="white", edgecolors=color, linewidths=2.5, marker=marker, zorder=20)
        ax.scatter([support_after[rid, 0]], [support_after[rid, 1]], s=175, c=color, alpha=0.98, edgecolors="black", linewidths=1.1, marker=marker, zorder=21)

    cent_before_def = support[labels == 1].mean(axis=0)
    cent_before_fp = support[labels == 0].mean(axis=0)
    cent_after_def = support_after[labels == 1].mean(axis=0)
    cent_after_fp = support_after[labels == 0].mean(axis=0)
    ax.plot([cent_before_def[0], cent_before_fp[0]], [cent_before_def[1], cent_before_fp[1]], color="#6B6B6B", lw=2.0, ls=":", alpha=0.70, zorder=17)
    ax.plot([cent_after_def[0], cent_after_fp[0]], [cent_after_def[1], cent_after_fp[1]], color="black", lw=2.4, ls="-", alpha=0.78, zorder=17)
    for point, color, marker, filled in [
        (cent_before_def, C_DEFECT, "X", False),
        (cent_before_fp, C_HARD, "X", False),
        (cent_after_def, C_DEFECT, "X", True),
        (cent_after_fp, C_HARD, "X", True),
    ]:
        ax.scatter([point[0]], [point[1]], s=145, marker=marker, facecolors=color if filled else "white", edgecolors="black" if filled else color, linewidths=1.6, alpha=0.96, zorder=22)

    margin_before = support[:, 0] - support[:, 1]
    margin_after = support_after[:, 0] - support_after[:, 1]
    auc_before = auc_pos_vs_neg(margin_before[labels == 1], margin_before[labels == 0])
    auc_after = auc_pos_vs_neg(margin_after[labels == 1], margin_after[labels == 0])
    gap_before = float(np.median(margin_before[labels == 1]) - np.median(margin_before[labels == 0]))
    gap_after = float(np.median(margin_after[labels == 1]) - np.median(margin_after[labels == 0]))
    ax.text(
        0.04,
        0.94,
        f"margin AUC\n{auc_before:.3f} -> {auc_after:.3f}\nmedian gap {gap_before:.3f} -> {gap_after:.3f}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#D7D7D7", "alpha": 0.90, "pad": 4},
    )
    ax.text(0.97, 0.06, "open: before\nsolid: after", transform=ax.transAxes, ha="right", va="bottom", fontsize=10.5, fontweight="bold")
    diag_lo = min(float(xlo - xpad), float(ylo - ypad))
    diag_hi = max(float(xhi + xpad), float(yhi + ypad))
    ax.plot([diag_lo, diag_hi], [diag_lo, diag_hi], color=C_DARK, lw=1.1, ls="--", alpha=0.25, zorder=1)
    ax.set_xlim(float(xlo - xpad), float(xhi + xpad))
    ax.set_ylim(float(ylo - ypad), float(yhi + ypad))
    ax.set_xlabel("defect support", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.set_ylabel("hard-FP support", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.tick_params(axis="both", labelsize=10.5, width=1.2)
    ax.grid(alpha=0.12)
    return {
        "margin_auc_before": auc_before,
        "margin_auc_after": auc_after,
        "median_gap_before": gap_before,
        "median_gap_after": gap_after,
    }


def draw_pair_pca_transport_panel(ax, arrays: dict, trace: dict) -> dict:
    labels = arrays["labels"]
    xy = arrays["xy"]
    xy_after = arrays["xy_after"]
    source_xy = arrays["source_xy"]
    source_label = arrays["source_labels"]
    rng = np.random.default_rng(0)
    keep_fp = rng.choice(np.where(source_label == 0)[0], size=min(850, int((source_label == 0).sum())), replace=False)
    keep_def = rng.choice(np.where(source_label == 1)[0], size=min(850, int((source_label == 1).sum())), replace=False)
    target_keep = []
    for lab in (0, 1):
        idx = np.where(labels == lab)[0]
        if idx.size:
            target_keep.append(rng.choice(idx, size=min(90, idx.size), replace=False))
    target_keep = np.concatenate(target_keep) if target_keep else np.arange(labels.size)

    selected_ids = {
        "defect": int(trace["selected"]["defect"]["record_id"]),
        "hard_normal": int(trace["selected"]["hard_normal"]["record_id"]),
    }
    before_points = {}
    after_points = {}
    for key in ["defect", "hard_normal"]:
        rid = selected_ids[key]
        before_points[key] = xy[rid]
        after_points[key] = xy_after[rid]
    pair_cloud = np.stack(
        [
            before_points["defect"],
            before_points["hard_normal"],
            after_points["defect"],
            after_points["hard_normal"],
        ],
        axis=0,
    )
    center = pair_cloud.mean(axis=0)
    target_all = np.concatenate([xy[target_keep], xy_after[target_keep]], axis=0)
    local_dist = np.linalg.norm(target_all - center.reshape(1, 2), axis=1)
    local = target_all[np.argsort(local_dist)[: min(280, local_dist.size)]]
    all_xy = np.concatenate([local, pair_cloud], axis=0)
    xlo, xhi = np.quantile(all_xy[:, 0], [0.03, 0.97])
    ylo, yhi = np.quantile(all_xy[:, 1], [0.03, 0.97])
    xlo = min(float(xlo), float(pair_cloud[:, 0].min()))
    xhi = max(float(xhi), float(pair_cloud[:, 0].max()))
    ylo = min(float(ylo), float(pair_cloud[:, 1].min()))
    yhi = max(float(yhi), float(pair_cloud[:, 1].max()))
    xpad = 0.22 * max(float(xhi - xlo), 1e-6)
    ypad = 0.22 * max(float(yhi - ylo), 1e-6)

    ax.set_title("Subspace-guided Transport", fontsize=18, fontweight="bold", pad=10)
    source_local = source_xy[np.concatenate([keep_fp, keep_def])]
    source_local_label = source_label[np.concatenate([keep_fp, keep_def])]
    source_keep = (
        (source_local[:, 0] >= xlo - xpad)
        & (source_local[:, 0] <= xhi + xpad)
        & (source_local[:, 1] >= ylo - ypad)
        & (source_local[:, 1] <= yhi + ypad)
    )
    ax.scatter(source_local[source_keep & (source_local_label == 0), 0], source_local[source_keep & (source_local_label == 0), 1], s=8, c=C_HARD, alpha=0.08, linewidths=0)
    ax.scatter(source_local[source_keep & (source_local_label == 1), 0], source_local[source_keep & (source_local_label == 1), 1], s=8, c=C_DEFECT, alpha=0.08, linewidths=0)

    for lab, color, marker, size in [(0, C_HARD, "o", 30), (1, C_DEFECT, "^", 38)]:
        idx = target_keep[labels[target_keep] == lab]
        if idx.size == 0:
            continue
        nearby = (
            (xy[idx, 0] >= xlo - xpad)
            & (xy[idx, 0] <= xhi + xpad)
            & (xy[idx, 1] >= ylo - ypad)
            & (xy[idx, 1] <= yhi + ypad)
        )
        idx = idx[nearby]
        if idx.size == 0:
            continue
        ax.scatter(xy[idx, 0], xy[idx, 1], s=size, facecolors="none", edgecolors=color, linewidths=1.0, alpha=0.24, marker=marker, zorder=4)
        ax.scatter(xy_after[idx, 0], xy_after[idx, 1], s=size, c=color, alpha=0.36, edgecolors="white", linewidths=0.35, marker=marker, zorder=5)

    for key, color, marker in [("defect", C_DEFECT, "^"), ("hard_normal", C_HARD, "o")]:
        rid = selected_ids[key]
        ax.quiver(
            [xy[rid, 0]],
            [xy[rid, 1]],
            [xy_after[rid, 0] - xy[rid, 0]],
            [xy_after[rid, 1] - xy[rid, 1]],
            angles="xy",
            scale_units="xy",
            scale=1.0,
            color=color,
            alpha=0.96,
            width=0.012,
            headwidth=4.2,
            headlength=5.3,
            headaxislength=4.4,
            zorder=18,
        )
        ax.scatter([xy[rid, 0]], [xy[rid, 1]], s=165, facecolors="white", edgecolors=color, linewidths=2.6, marker=marker, zorder=20)
        ax.scatter([xy_after[rid, 0]], [xy_after[rid, 1]], s=185, c=color, alpha=0.98, edgecolors="black", linewidths=1.2, marker=marker, zorder=21)

    ax.plot(
        [before_points["defect"][0], before_points["hard_normal"][0]],
        [before_points["defect"][1], before_points["hard_normal"][1]],
        color="#6B6B6B",
        lw=2.0,
        ls=":",
        alpha=0.70,
        zorder=17,
    )
    ax.plot(
        [after_points["defect"][0], after_points["hard_normal"][0]],
        [after_points["defect"][1], after_points["hard_normal"][1]],
        color="black",
        lw=2.6,
        ls="-",
        alpha=0.80,
        zorder=17,
    )
    dist_before = float(np.linalg.norm(before_points["defect"] - before_points["hard_normal"]))
    dist_after = float(np.linalg.norm(after_points["defect"] - after_points["hard_normal"]))
    axis_gap_before = float(abs(before_points["defect"][0] - before_points["hard_normal"][0]))
    axis_gap_after = float(abs(after_points["defect"][0] - after_points["hard_normal"][0]))
    cal_gap = float(trace["selected"]["defect"]["calibrated"] - trace["selected"]["hard_normal"]["calibrated"])
    base_gap = float(trace["selected"]["defect"]["baseline"] - trace["selected"]["hard_normal"]["baseline"])
    ax.text(
        0.04,
        0.94,
        f"axis gap\n{axis_gap_before:.3f} -> {axis_gap_after:.3f}\nscore gap {base_gap:.3f} -> {cal_gap:.3f}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#D7D7D7", "alpha": 0.90, "pad": 4},
    )
    ax.text(0.97, 0.06, "open: before\nsolid: after", transform=ax.transAxes, ha="right", va="bottom", fontsize=10.5, fontweight="bold")
    ax.set_xlim(float(xlo - xpad), float(xhi + xpad))
    ax.set_ylim(float(ylo - ypad), float(yhi + ypad))
    ax.axhline(0, color=C_DARK, lw=0.8, alpha=0.18)
    ax.axvline(0, color=C_DARK, lw=0.8, alpha=0.18)
    ax.set_xlabel("text-axis coordinate", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.set_ylabel("source PCA coordinate", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.tick_params(axis="both", labelsize=10.5, width=1.2)
    ax.grid(alpha=0.12)
    return {
        "pair_distance_before": dist_before,
        "pair_distance_after": dist_after,
        "axis_gap_before": axis_gap_before,
        "axis_gap_after": axis_gap_after,
        "baseline_gap": base_gap,
        "calibrated_gap": cal_gap,
    }


def draw_rank_lift_panel(ax, arrays: dict, trace: dict) -> dict:
    labels = arrays["labels"]
    baseline = arrays["baseline"]
    xy = arrays["xy"]
    text_coord = xy[:, 0].astype(np.float32)
    residual_coord = xy[:, 1].astype(np.float32)
    if np.median(residual_coord[labels == 1]) < np.median(residual_coord[labels == 0]):
        residual_coord = -residual_coord

    pos_b = baseline[labels == 1]
    neg_b = baseline[labels == 0]
    lo = max(float(np.quantile(pos_b, 0.20)), float(np.quantile(neg_b, 0.20)))
    hi = min(float(np.quantile(pos_b, 0.80)), float(np.quantile(neg_b, 0.80)))
    mask = (baseline >= lo) & (baseline <= hi)
    if int(mask.sum()) < 40:
        lo = max(float(np.quantile(pos_b, 0.10)), float(np.quantile(neg_b, 0.10)))
        hi = min(float(np.quantile(pos_b, 0.90)), float(np.quantile(neg_b, 0.90)))
        mask = (baseline >= lo) & (baseline <= hi)
    if int(mask.sum()) < 20:
        mask = np.ones_like(labels, dtype=bool)

    idx_all = np.where(mask)[0]
    rng = np.random.default_rng(0)
    keep = []
    for lab in (0, 1):
        idx = idx_all[labels[idx_all] == lab]
        if idx.size:
            keep.append(rng.choice(idx, size=min(145, idx.size), replace=False))
    keep = np.concatenate(keep) if keep else idx_all
    selected_ids = {
        "defect": int(trace["selected"]["defect"]["record_id"]),
        "hard_normal": int(trace["selected"]["hard_normal"]["record_id"]),
    }
    keep = np.unique(np.concatenate([keep, np.asarray([selected_ids["defect"], selected_ids["hard_normal"]], dtype=np.int64)]))

    y_jitter = rng.normal(0.0, 0.025, size=keep.shape[0]).astype(np.float32)
    axis_scores = text_coord[mask]
    y_axis = labels[mask]
    axis_auc = auc_pos_vs_neg(axis_scores[y_axis == 1], axis_scores[y_axis == 0])
    residual_scores = residual_coord[mask]
    residual_auc = auc_pos_vs_neg(residual_scores[y_axis == 1], residual_scores[y_axis == 0])
    if residual_auc < 0.5:
        residual_auc = 1.0 - residual_auc
    lift_gap = float(np.median(residual_scores[y_axis == 1]) - np.median(residual_scores[y_axis == 0]))
    axis_gap = float(np.median(axis_scores[y_axis == 1]) - np.median(axis_scores[y_axis == 0]))

    ax.axis("off")
    left = ax.inset_axes([0.000, 0.025, 0.455, 0.885])
    right = ax.inset_axes([0.545, 0.025, 0.455, 0.885])

    for lab, color, marker, size in [(0, C_HARD, "o", 34), (1, C_DEFECT, "^", 42)]:
        sub = keep[labels[keep] == lab]
        if sub.size == 0:
            continue
        sub_pos = np.isin(keep, sub)
        left.scatter(text_coord[sub], y_jitter[sub_pos], s=size, c=color, alpha=0.58, edgecolors="white", linewidths=0.45, marker=marker)
        right.scatter(text_coord[sub], residual_coord[sub], s=size, c=color, alpha=0.58, edgecolors="white", linewidths=0.45, marker=marker)

    for key, color, marker in [("defect", C_DEFECT, "^"), ("hard_normal", C_HARD, "o")]:
        rid = selected_ids[key]
        left.scatter([text_coord[rid]], [0.0], s=165, c=color, marker=marker, edgecolors="black", linewidths=1.3, zorder=20)
        right.scatter([text_coord[rid]], [residual_coord[rid]], s=175, c=color, marker=marker, edgecolors="black", linewidths=1.3, zorder=20)
    left.plot(
        [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
        [0.0, 0.0],
        color=C_DARK,
        lw=2.0,
        alpha=0.70,
        zorder=18,
    )

    axis_def_med = float(np.median(axis_scores[y_axis == 1]))
    axis_hard_med = float(np.median(axis_scores[y_axis == 0]))
    residual_def_med = float(np.median(residual_scores[y_axis == 1]))
    residual_hard_med = float(np.median(residual_scores[y_axis == 0]))
    right.plot(
        [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
        [residual_coord[selected_ids["defect"]], residual_coord[selected_ids["hard_normal"]]],
        color=C_DARK,
        lw=2.4,
        alpha=0.76,
        zorder=18,
    )
    right.axhline(residual_def_med, color=C_DEFECT, lw=1.7, ls="--", alpha=0.72)
    right.axhline(residual_hard_med, color=C_HARD, lw=1.7, ls="-", alpha=0.66)
    bracket_x = float(np.quantile(text_coord[keep], 0.96))
    right.annotate(
        "",
        xy=(bracket_x, residual_def_med),
        xytext=(bracket_x, residual_hard_med),
        arrowprops={"arrowstyle": "<->", "lw": 2.0, "color": C_DARK, "alpha": 0.82},
        zorder=21,
    )

    x_vals = text_coord[keep]
    xpad = 0.10 * max(float(x_vals.max() - x_vals.min()), 1e-6)
    r_vals = residual_coord[keep]
    rpad = 0.12 * max(float(r_vals.max() - r_vals.min()), 1e-6)
    left.set_xlim(float(x_vals.min() - xpad), float(x_vals.max() + xpad))
    right.set_xlim(float(x_vals.min() - xpad), float(x_vals.max() + xpad))
    left.set_ylim(-0.11, 0.11)
    right.set_ylim(float(r_vals.min() - rpad), float(r_vals.max() + rpad))
    left.axhline(0, color=C_DARK, lw=1.1, alpha=0.22)
    right.axhline(0, color=C_DARK, lw=1.1, alpha=0.22)
    title_text = {
        "Baseline": f"Baseline\ncompressed gap {abs(axis_gap):.3f}",
        "OURS": f"OURS\nlifted gap {abs(lift_gap):.3f}",
    }
    for inner, title in [(left, "Baseline"), (right, "OURS")]:
        inner.set_title(title_text[title], fontsize=12.5, fontweight="bold", pad=4, linespacing=1.04)
        inner.set_xlabel("text-axis coordinate", fontsize=10.8, fontweight="bold", labelpad=3)
        inner.tick_params(axis="both", labelsize=8.0, width=0.9)
        inner.grid(alpha=0.12)
        for spine in inner.spines.values():
            spine.set_linewidth(1.1)
    left.set_yticks([])
    right.set_ylabel("")
    return {
        "axis_auc": float(axis_auc),
        "residual_auc": float(residual_auc),
        "axis_median_gap": axis_gap,
        "residual_median_gap": lift_gap,
        "num_band_points": int(mask.sum()),
    }


def draw_story_figure(out_dir: Path, arrays: dict, trace: dict) -> dict:
    labels = arrays["labels"]
    masks_pos = labels == 1
    masks_neg = labels == 0
    baseline_scores = arrays["baseline"]
    train_free_scores = arrays["train_free"]
    selected = {
        "baseline": {
            "defect": trace["selected"]["defect"]["baseline"],
            "hard_normal": trace["selected"]["hard_normal"]["baseline"],
        },
        "train_free": {
            "defect": trace["selected"]["defect"]["train_free"],
            "hard_normal": trace["selected"]["hard_normal"]["train_free"],
        },
    }

    plt.rcParams.update({"axes.linewidth": 1.35, "font.family": "DejaVu Sans"})
    fig = plt.figure(figsize=(19.4, 5.25), constrained_layout=False)
    gs = fig.add_gridspec(1, 4, width_ratios=[1.03, 1.03, 1.82, 0.84])
    axs = [fig.add_subplot(gs[0, i]) for i in range(4)]
    base_stats = draw_hist(
        axs[0],
        baseline_scores[masks_pos],
        baseline_scores[masks_neg],
        "Baseline Entanglement",
        "host top-k patch score",
        selected=selected["baseline"],
    )
    free_stats = draw_hist(
        axs[1],
        train_free_scores[masks_pos],
        train_free_scores[masks_neg],
        "Train-free TED",
        "decomposition top-k score",
        selected=selected["train_free"],
    )
    axs[1].set_ylabel("")
    axs[0].legend(frameon=False, fontsize=11.5, loc="upper right", handlelength=2.6)
    lift_stats = draw_rank_lift_panel(axs[2], arrays, trace)
    draw_trace_panel(axs[3], trace, compact=True)
    fig.subplots_adjust(left=0.038, right=0.992, top=0.86, bottom=0.19, wspace=0.22)
    png = out_dir / "faprompt_ted_story_vitl336.png"
    pdf = out_dir / "faprompt_ted_story_vitl336.pdf"
    fig.savefig(png, dpi=260, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {"baseline": base_stats, "train_free": free_stats, "rank_lift": lift_stats, "png": str(png), "pdf": str(pdf)}


def oriented_rankr_residual(arrays: dict) -> np.ndarray:
    labels = arrays["labels"]
    xy = arrays["xy"]
    residual = xy[:, 1].astype(np.float32)
    if np.median(residual[labels == 1]) < np.median(residual[labels == 0]):
        residual = -residual
    return residual


def baseline_overlap_band_mask(labels: np.ndarray, baseline: np.ndarray) -> np.ndarray:
    pos_b = baseline[labels == 1]
    neg_b = baseline[labels == 0]
    lo = max(float(np.quantile(pos_b, 0.20)), float(np.quantile(neg_b, 0.20)))
    hi = min(float(np.quantile(pos_b, 0.80)), float(np.quantile(neg_b, 0.80)))
    mask = (baseline >= lo) & (baseline <= hi)
    if int(mask.sum()) < 40:
        lo = max(float(np.quantile(pos_b, 0.10)), float(np.quantile(neg_b, 0.10)))
        hi = min(float(np.quantile(pos_b, 0.90)), float(np.quantile(neg_b, 0.90)))
        mask = (baseline >= lo) & (baseline <= hi)
    if int(mask.sum()) < 20:
        mask = np.ones_like(labels, dtype=bool)
    return mask


def draw_rankr_story_figure(out_dir: Path, arrays: dict, trace: dict) -> dict:
    labels = arrays["labels"]
    baseline_scores = arrays["baseline"]
    rankr_scores = oriented_rankr_residual(arrays)
    band_mask = baseline_overlap_band_mask(labels, baseline_scores)
    masks_pos = (labels == 1) & band_mask
    masks_neg = (labels == 0) & band_mask
    selected_ids = {
        "defect": int(trace["selected"]["defect"]["record_id"]),
        "hard_normal": int(trace["selected"]["hard_normal"]["record_id"]),
    }

    plt.rcParams.update({"axes.linewidth": 1.35, "font.family": "DejaVu Sans"})
    fig = plt.figure(figsize=(19.4, 5.25), constrained_layout=False)
    gs = fig.add_gridspec(1, 4, width_ratios=[1.08, 1.08, 1.58, 0.86])
    axs = [fig.add_subplot(gs[0, i]) for i in range(4)]
    base_stats = draw_hist(
        axs[0],
        baseline_scores[masks_pos],
        baseline_scores[masks_neg],
        "Baseline",
        "host score",
        selected={
            "defect": trace["selected"]["defect"]["baseline"],
            "hard_normal": trace["selected"]["hard_normal"]["baseline"],
        },
    )
    rankr_stats = draw_hist(
        axs[1],
        rankr_scores[masks_pos],
        rankr_scores[masks_neg],
        "OURS",
        "OURS score",
        selected={
            "defect": float(rankr_scores[selected_ids["defect"]]),
            "hard_normal": float(rankr_scores[selected_ids["hard_normal"]]),
        },
    )
    axs[1].set_ylabel("")
    axs[0].legend(frameon=False, fontsize=11.5, loc="upper right", handlelength=2.6)
    lift_stats = draw_rank_lift_panel(axs[2], arrays, trace)
    draw_trace_panel(axs[3], trace, compact=True)
    fig.subplots_adjust(left=0.038, right=0.992, top=0.86, bottom=0.19, wspace=0.22)
    png = out_dir / "faprompt_ted_rankr_story_vitl336.png"
    pdf = out_dir / "faprompt_ted_rankr_story_vitl336.pdf"
    fig.savefig(png, dpi=260, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {"baseline": base_stats, "rankr": rankr_stats, "rank_lift": lift_stats, "png": str(png), "pdf": str(pdf)}


def draw_pca_scatter(out_dir: Path, arrays: dict) -> dict:
    labels = arrays["labels"]
    xy = arrays["xy"]
    xy_after = arrays["xy_after"]
    source_xy = arrays["source_xy"]
    source_label = arrays["source_labels"]
    rng = np.random.default_rng(0)
    keep_fp = rng.choice(np.where(source_label == 0)[0], size=min(900, int((source_label == 0).sum())), replace=False)
    keep_def = rng.choice(np.where(source_label == 1)[0], size=min(900, int((source_label == 1).sum())), replace=False)
    target_keep = []
    for lab in (0, 1):
        idx = np.where(labels == lab)[0]
        if idx.size:
            target_keep.append(rng.choice(idx, size=min(90, idx.size), replace=False))
    target_keep = np.concatenate(target_keep) if target_keep else np.arange(labels.size)

    plt.rcParams.update({"axes.linewidth": 1.35, "font.family": "DejaVu Sans"})
    fig, axs = plt.subplots(1, 2, figsize=(10.4, 4.65), sharex=True, sharey=True)

    def draw_panel(ax, target_xy: np.ndarray, title: str, suffix: str) -> None:
        ax.scatter(source_xy[keep_fp, 0], source_xy[keep_fp, 1], s=7, c=C_HARD, alpha=0.08, linewidths=0, label="source hard normal")
        ax.scatter(source_xy[keep_def, 0], source_xy[keep_def, 1], s=7, c=C_DEFECT, alpha=0.08, linewidths=0, label="source defect")
        ax.scatter(
            target_xy[target_keep[labels[target_keep] == 0], 0],
            target_xy[target_keep[labels[target_keep] == 0], 1],
            s=36,
            c=C_HARD,
            alpha=0.78,
            edgecolors="white",
            linewidths=0.45,
            label=f"{suffix} hard normal",
        )
        ax.scatter(
            target_xy[target_keep[labels[target_keep] == 1], 0],
            target_xy[target_keep[labels[target_keep] == 1], 1],
            s=44,
            c=C_DEFECT,
            alpha=0.86,
            edgecolors="white",
            linewidths=0.55,
            marker="^",
            label=f"{suffix} defect",
        )
        ax.axhline(0, color=C_DARK, lw=0.8, alpha=0.20)
        ax.axvline(0, color=C_DARK, lw=0.8, alpha=0.20)
        ax.set_title(title, fontsize=17, fontweight="bold", pad=9)
        ax.set_xlabel("text-axis coordinate", fontsize=12.5, fontweight="bold", labelpad=7)
        ax.tick_params(axis="both", labelsize=10.5, width=1.2)
        ax.grid(alpha=0.13)

    draw_panel(axs[0], xy, "Before Transport", "before")
    draw_panel(axs[1], xy_after, "After Transport", "after")
    axs[0].set_ylabel("source PCA coordinate", fontsize=12.5, fontweight="bold", labelpad=7)
    axs[1].legend(frameon=False, fontsize=8.0, loc="best", markerscale=1.0)
    fig.suptitle("Calibrated Subspace Transport", fontsize=21, fontweight="bold", y=1.02)
    fig.tight_layout()
    png = out_dir / "faprompt_ted_source_pca_scatter_vitl336.png"
    pdf = out_dir / "faprompt_ted_source_pca_scatter_vitl336.pdf"
    fig.savefig(png, dpi=260, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {"png": str(png), "pdf": str(pdf)}


def draw_transport_arrow_scatter(out_dir: Path, arrays: dict) -> dict:
    labels = arrays["labels"]
    xy = arrays["xy"]
    xy_after = arrays["xy_after"]
    rng = np.random.default_rng(0)
    target_keep = []
    for lab in (0, 1):
        idx = np.where(labels == lab)[0]
        if idx.size:
            target_keep.append(rng.choice(idx, size=min(90, idx.size), replace=False))
    target_keep = np.concatenate(target_keep) if target_keep else np.arange(labels.size)
    fig, ax = plt.subplots(figsize=(5.6, 4.7))
    for lab, color in [(0, C_HARD), (1, C_DEFECT)]:
        idx = target_keep[labels[target_keep] == lab]
        if idx.size == 0:
            continue
        ax.quiver(
            xy[idx, 0],
            xy[idx, 1],
            xy_after[idx, 0] - xy[idx, 0],
            xy_after[idx, 1] - xy[idx, 1],
            angles="xy",
            scale_units="xy",
            scale=1.0,
            color=color,
            alpha=0.42,
            width=0.0045,
            headwidth=3.5,
            headlength=4.5,
            headaxislength=3.8,
            zorder=3,
        )
    ax.scatter(xy[target_keep[labels[target_keep] == 0], 0], xy[target_keep[labels[target_keep] == 0], 1], s=36, facecolors="none", edgecolors=C_HARD, linewidths=1.2, alpha=0.78, label="before hard normal")
    ax.scatter(xy_after[target_keep[labels[target_keep] == 0], 0], xy_after[target_keep[labels[target_keep] == 0], 1], s=34, c=C_HARD, alpha=0.78, edgecolors="white", linewidths=0.45, label="after hard normal")
    ax.scatter(xy[target_keep[labels[target_keep] == 1], 0], xy[target_keep[labels[target_keep] == 1], 1], s=44, facecolors="none", edgecolors=C_DEFECT, linewidths=1.2, alpha=0.86, marker="^", label="before defect")
    ax.scatter(xy_after[target_keep[labels[target_keep] == 1], 0], xy_after[target_keep[labels[target_keep] == 1], 1], s=42, c=C_DEFECT, alpha=0.86, edgecolors="white", linewidths=0.55, marker="^", label="after defect")
    ax.axhline(0, color=C_DARK, lw=0.8, alpha=0.20)
    ax.axvline(0, color=C_DARK, lw=0.8, alpha=0.20)
    ax.set_title("Calibrated Subspace Transport", fontsize=17, fontweight="bold", pad=9)
    ax.set_xlabel("text-axis coordinate", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.set_ylabel("source PCA coordinate", fontsize=12.5, fontweight="bold", labelpad=7)
    ax.tick_params(axis="both", labelsize=10.5, width=1.2)
    ax.grid(alpha=0.13)
    ax.legend(frameon=False, fontsize=8.0, loc="best", markerscale=1.0)
    fig.tight_layout()
    png = out_dir / "faprompt_ted_transport_arrows_vitl336.png"
    pdf = out_dir / "faprompt_ted_transport_arrows_vitl336.pdf"
    fig.savefig(png, dpi=260, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {"png": str(png), "pdf": str(pdf)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="visa2mvtec")
    ap.add_argument("--class_name", default="wood")
    ap.add_argument("--save_dir", default=str(ROOT / "neurips2026" / "results" / "faprompt_ted_story_vitl336_visa2mvtec_wood"))
    ap.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--model_name", default="ViT-L/14@336px")
    ap.add_argument("--prompt_load_mode", default="strict", choices=["strict", "project_crop"])
    ap.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    ap.add_argument("--image_size", type=int, default=518)
    ap.add_argument("--batch_size", type=int, default=3)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--depth", type=int, default=9)
    ap.add_argument("--n_ctx", type=int, default=12)
    ap.add_argument("--t_n_ctx", type=int, default=4)
    ap.add_argument("--dpam_layer", type=int, default=20)
    ap.add_argument("--sigma", type=int, default=10)
    ap.add_argument("--dap_token_mode", default="official_firstk", choices=["topk", "official_firstk"])
    ap.add_argument("--candidate_topk_frac", type=float, default=0.01)
    ap.add_argument("--max_candidates_per_image", type=int, default=16)
    ap.add_argument("--tau", type=float, default=0.1)
    ap.add_argument("--fp_weight", type=float, default=1.0)
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--residual_gate_quantile", type=float, default=0.9)
    ap.add_argument("--residual_gate_temp", type=float, default=0.25)
    ap.add_argument("--bank_chunk", type=int, default=2048)
    ap.add_argument("--max_fp_per_class", type=int, default=512)
    ap.add_argument("--max_defect_per_class", type=int, default=512)
    ap.add_argument("--max_fp_total", type=int, default=4096)
    ap.add_argument("--max_defect_total", type=int, default=4096)
    ap.add_argument("--normal_topk_frac", type=float, default=0.01)
    ap.add_argument("--calib_epochs", type=int, default=30)
    ap.add_argument("--calib_lr", type=float, default=0.02)
    ap.add_argument("--calib_max_train_points", type=int, default=2048)
    ap.add_argument("--calib_alpha_init", type=float, default=0.05)
    ap.add_argument("--calib_alpha_max", type=float, default=0.2)
    ap.add_argument("--calib_subspace_rank", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--crop_size", type=int, default=112)
    ap.add_argument("--max_hist_pixels_per_image", type=int, default=4096)
    args = ap.parse_args()

    out_dir = Path(args.save_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = dict(PRESET_CONFIGS[args.preset])
    device = torch.device(args.device)
    model, prompt_learner, prompt_load_info = build_model(
        device=device,
        checkpoint_path=cfg["checkpoint_path"],
        model_name=args.model_name,
        prompt_load_mode=args.prompt_load_mode,
        dpam_layer=args.dpam_layer,
        depth=args.depth,
        n_ctx=args.n_ctx,
        t_n_ctx=args.t_n_ctx,
    )
    banks = get_or_collect_source_banks(
        model=model,
        prompt_learner=prompt_learner,
        preset=args.preset,
        source_root=cfg["source_root"],
        checkpoint_path=cfg["checkpoint_path"],
        model_name=args.model_name,
        prompt_load_mode=args.prompt_load_mode,
        cache_dir=ROOT / "neurips2026" / "results" / "bank_cache",
        image_size=args.image_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=device,
        features_list=args.features_list,
        sigma=args.sigma,
        dap_token_mode=args.dap_token_mode,
        dpam_layer=args.dpam_layer,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_fp_total=args.max_fp_total,
        max_defect_total=args.max_defect_total,
        normal_topk_frac=args.normal_topk_frac,
        seed=args.seed,
        force_rebuild_bank=False,
    )
    base_text_pair = learned_text_pair(model, prompt_learner)
    axis = F.normalize(base_text_pair[1] - base_text_pair[0], dim=0)
    fp_proj = banks["fp"].to(device) @ axis
    defect_proj = banks["defect"].to(device) @ axis
    cal1 = train_subspace_host_residual_calibrator(
        banks=banks,
        axis=axis,
        tau=args.tau,
        bank_chunk=args.bank_chunk,
        max_train_points=args.calib_max_train_points,
        epochs=args.calib_epochs,
        lr=args.calib_lr,
        rank_margin=0.05,
        rank_temp=0.05,
        eta_init=args.calib_alpha_init,
        eta_max=args.calib_alpha_max,
        eta_reg=0.001,
        fp_weight_init=1.0,
        learn_fp_weight=False,
        hardpair_frac=0.75,
        subspace_rank=args.calib_subspace_rank,
        subspace_basis_control="source",
        pair_label_control="correct",
        preserve_host_margin_weight=1.0,
        seed=args.seed,
        device=device,
        host_score_key="branch1_score",
    )
    cal2 = train_subspace_host_residual_calibrator(
        banks=banks,
        axis=axis,
        tau=args.tau,
        bank_chunk=args.bank_chunk,
        max_train_points=args.calib_max_train_points,
        epochs=args.calib_epochs,
        lr=args.calib_lr,
        rank_margin=0.05,
        rank_temp=0.05,
        eta_init=args.calib_alpha_init,
        eta_max=args.calib_alpha_max,
        eta_reg=0.001,
        fp_weight_init=1.0,
        learn_fp_weight=False,
        hardpair_frac=0.75,
        subspace_rank=args.calib_subspace_rank,
        subspace_basis_control="source",
        pair_label_control="correct",
        preserve_host_margin_weight=1.0,
        seed=args.seed,
        device=device,
        host_score_key="branch2_score",
    )
    if cal1 is None or cal2 is None:
        raise RuntimeError("Could not train source branch calibrators")

    basis = cal1["basis"].to(device).float()
    source_xy = torch.cat([banks["fp"], banks["defect"]], dim=0).to(device).float() @ basis[:, :2]
    source_labels = np.concatenate(
        [np.zeros(int(banks["fp"].shape[0]), dtype=np.int64), np.ones(int(banks["defect"].shape[0]), dtype=np.int64)]
    )
    source_axis_z = torch.cat([banks["fp"], banks["defect"]], dim=0).to(device).float() @ axis
    source_support_def = logmeanexp_negative_sqdist_1d(source_axis_z.view(1, -1), defect_proj, tau=args.tau, chunk=args.bank_chunk)[0]
    source_support_fp = logmeanexp_negative_sqdist_1d(source_axis_z.view(1, -1), fp_proj, tau=args.tau, chunk=args.bank_chunk)[0]
    source_support_xy = torch.stack([source_support_def, source_support_fp], dim=1)

    ds = MetaDataset(cfg["target_root"], args.image_size, split="test", class_name=args.class_name)
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=torch.cuda.is_available())
    records: list[dict] = []
    arrays = {
        "labels": [],
        "baseline": [],
        "train_free": [],
        "calibrated": [],
        "calibrated_evidence": [],
        "xy": [],
        "xy_after": [],
        "support_xy": [],
        "support_xy_after": [],
        "hist_labels": [],
        "hist_baseline": [],
        "hist_train_free": [],
        "hist_calibrated": [],
    }
    sample_cache: dict[int, dict] = {}
    rng_np = np.random.default_rng(args.seed)
    sample_id = 0

    with torch.no_grad():
        for batch in dl:
            image = batch["image"].to(device)
            mask = batch["mask"].to(device)
            label = batch["label"].cpu().numpy().astype(np.int64)
            out = compute_faprompt_outputs(
                model,
                prompt_learner,
                image,
                args.features_list,
                args.image_size,
                args.sigma,
                args.dap_token_mode,
                args.dpam_layer,
                base_text_pair,
            )
            tokens = out["patch_tokens"]
            baseline = out["token_score"]
            branch1 = out["branch1_token_score"]
            branch2 = out["branch2_token_score"]
            q = tokens @ axis
            q_def = logmeanexp_negative_sqdist_1d(q, defect_proj, tau=args.tau, chunk=args.bank_chunk)
            q_fp = logmeanexp_negative_sqdist_1d(q, fp_proj, tau=args.tau, chunk=args.bank_chunk)
            train_free = spatial_tanh_zscore(q_def - args.fp_weight * q_fp)

            rect1 = prescore_subspace_transport_tokens(tokens, q_def, q_fp, cal1["basis"], cal1["eta"], cal1["transport_direction"], cal1["transport_b"], cal1["fp_weight"])
            rect2 = prescore_subspace_transport_tokens(tokens, q_def, q_fp, cal2["basis"], cal2["eta"], cal2["transport_direction"], cal2["transport_b"], cal2["fp_weight"])
            rect1_z = rect1 @ axis
            rect2_z = rect2 @ axis
            q_def_after = 0.5 * (
                logmeanexp_negative_sqdist_1d(rect1_z, defect_proj, tau=args.tau, chunk=args.bank_chunk)
                + logmeanexp_negative_sqdist_1d(rect2_z, defect_proj, tau=args.tau, chunk=args.bank_chunk)
            )
            q_fp_after = 0.5 * (
                logmeanexp_negative_sqdist_1d(rect1_z, fp_proj, tau=args.tau, chunk=args.bank_chunk)
                + logmeanexp_negative_sqdist_1d(rect2_z, fp_proj, tau=args.tau, chunk=args.bank_chunk)
            )
            corrected1 = subspace_host_residual_token_score(branch1, rect1, cal1["basis"], cal1["subspace_score_w"], cal1["readout_gamma"])
            corrected2 = subspace_host_residual_token_score(branch2, rect2, cal2["basis"], cal2["subspace_score_w"], cal2["readout_gamma"])
            residual_token = 0.5 * ((corrected1 - branch1) + (corrected2 - branch2))
            token_gate = high_score_gate_tokens(
                spatial_tanh_zscore(baseline),
                topk_frac=max(1e-6, 1.0 - float(args.residual_gate_quantile)),
                sharpness=max(1e-6, 1.0 / max(float(args.residual_gate_temp), 1e-6)),
            )
            calibrated_evidence = float(args.alpha) * token_gate * residual_token
            calibrated = baseline + calibrated_evidence
            train_free_map = upsample_tokens(train_free, image_size=args.image_size, sigma=args.sigma)
            calibrated_map = upsample_tokens(calibrated, image_size=args.image_size, sigma=args.sigma)

            side = int(round(math.sqrt(tokens.shape[1])))
            patch_mask = downsample_mask_to_patch(mask, side)
            cell = float(args.image_size) / float(side)
            coords = tokens @ basis[:, :2]
            coords_after = rect1 @ basis[:, :2]

            for bi in range(tokens.shape[0]):
                y = int(label[bi])
                baseline_map_i = out["anomaly_map"][bi]
                train_free_map_i = train_free_map[bi]
                calibrated_map_i = calibrated_map[bi]
                mask_i = mask[bi, 0].detach().cpu().numpy() > 0.5
                image_np = denormalize_image(batch["image"][bi])
                sample_cache[int(sample_id)] = {
                    "image": image_np,
                    "mask": mask_i,
                    "baseline_map": np.asarray(baseline_map_i, dtype=np.float32),
                    "train_free_map": np.asarray(train_free_map_i, dtype=np.float32),
                    "calibrated_map": np.asarray(calibrated_map_i, dtype=np.float32),
                    "img_path": str(batch["img_path"][bi]),
                    "label": y,
                }
                if y == 1:
                    flat_idx = np.flatnonzero(mask_i.reshape(-1))
                else:
                    flat_scores = baseline_map_i.reshape(-1)
                    k = max(1, int(math.ceil(flat_scores.size * args.candidate_topk_frac)))
                    k = min(k, flat_scores.size, max(1, args.max_hist_pixels_per_image))
                    flat_idx = np.argpartition(flat_scores, -k)[-k:]
                if flat_idx.size > args.max_hist_pixels_per_image:
                    flat_idx = rng_np.choice(flat_idx, size=args.max_hist_pixels_per_image, replace=False)
                arrays["hist_labels"].extend([y] * int(flat_idx.size))
                arrays["hist_baseline"].extend(baseline_map_i.reshape(-1)[flat_idx].astype(np.float32).tolist())
                arrays["hist_train_free"].extend(train_free_map_i.reshape(-1)[flat_idx].astype(np.float32).tolist())
                arrays["hist_calibrated"].extend(calibrated_map_i.reshape(-1)[flat_idx].astype(np.float32).tolist())

                if y == 0:
                    idx = top_indices(baseline[bi], args.candidate_topk_frac, args.max_candidates_per_image)
                else:
                    pos_idx = torch.nonzero(patch_mask[bi], as_tuple=False).flatten()
                    if pos_idx.numel() == 0:
                        sample_id += 1
                        continue
                    idx_local = top_indices(baseline[bi, pos_idx], args.candidate_topk_frac, args.max_candidates_per_image)
                    idx = pos_idx[idx_local]
                for patch_idx_t in idx:
                    patch_idx = int(patch_idx_t.item())
                    row = patch_idx // side
                    col = patch_idx % side
                    cy = int(round((row + 0.5) * cell))
                    cx = int(round((col + 0.5) * cell))
                    y0 = max(0, min(args.image_size - 1, int(math.floor(row * cell))))
                    y1 = max(y0 + 1, min(args.image_size, int(math.ceil((row + 1) * cell))))
                    x0 = max(0, min(args.image_size - 1, int(math.floor(col * cell))))
                    x1 = max(x0 + 1, min(args.image_size, int(math.ceil((col + 1) * cell))))
                    mask_overlap_frac = 0.0
                    if y == 1:
                        local_mask = mask_i[y0:y1, x0:x1]
                        mask_overlap_frac = float(local_mask.mean()) if local_mask.size else 0.0
                        if local_mask.any():
                            yy, xx = np.nonzero(local_mask)
                            cy = int(y0 + np.median(yy))
                            cx = int(x0 + np.median(xx))
                    rec = {
                        "record_id": len(records),
                        "sample_id": int(sample_id),
                        "label": y,
                        "label_name": "defect" if y == 1 else "hard_normal",
                        "class_name": args.class_name,
                        "img_path": str(batch["img_path"][bi]),
                        "patch_idx": patch_idx,
                        "patch_row": int(row),
                        "patch_col": int(col),
                        "patch_side": int(side),
                        "cy": cy,
                        "cx": cx,
                        "mask_overlap_frac": mask_overlap_frac,
                        "baseline": float(baseline[bi, patch_idx].item()),
                        "train_free": float(train_free[bi, patch_idx].item()),
                        "calibrated": float(calibrated[bi, patch_idx].item()),
                        "calibrated_evidence": float(calibrated_evidence[bi, patch_idx].item()),
                        "support_def": float(q_def[bi, patch_idx].item()),
                        "support_fp": float(q_fp[bi, patch_idx].item()),
                        "support_def_after": float(q_def_after[bi, patch_idx].item()),
                        "support_fp_after": float(q_fp_after[bi, patch_idx].item()),
                        "xy": [float(coords[bi, patch_idx, 0].item()), float(coords[bi, patch_idx, 1].item())],
                        "xy_after": [float(coords_after[bi, patch_idx, 0].item()), float(coords_after[bi, patch_idx, 1].item())],
                        "_image": image_np,
                        "_mask": mask_i,
                    }
                    records.append(rec)
                    arrays["labels"].append(y)
                    arrays["baseline"].append(rec["baseline"])
                    arrays["train_free"].append(rec["train_free"])
                    arrays["calibrated"].append(rec["calibrated"])
                    arrays["calibrated_evidence"].append(rec["calibrated_evidence"])
                    arrays["xy"].append(rec["xy"])
                    arrays["xy_after"].append(rec["xy_after"])
                    arrays["support_xy"].append([rec["support_def"], rec["support_fp"]])
                    arrays["support_xy_after"].append([rec["support_def_after"], rec["support_fp_after"]])
                sample_id += 1
            print(json.dumps({"stage": "batch_done", "records": len(records)}), flush=True)

    defect, hard, pair_info = pick_pair(records)
    defect = save_trace_images(out_dir, defect, "defect", args.crop_size)
    hard = save_trace_images(out_dir, hard, "hard_normal", args.crop_size)
    for rec in records:
        rec.pop("_image", None)
        rec.pop("_mask", None)

    arrays_np = {
        "labels": np.asarray(arrays["labels"], dtype=np.int64),
        "baseline": np.asarray(arrays["baseline"], dtype=np.float32),
        "train_free": np.asarray(arrays["train_free"], dtype=np.float32),
        "calibrated": np.asarray(arrays["calibrated"], dtype=np.float32),
        "calibrated_evidence": np.asarray(arrays["calibrated_evidence"], dtype=np.float32),
        "xy": np.asarray(arrays["xy"], dtype=np.float32),
        "xy_after": np.asarray(arrays["xy_after"], dtype=np.float32),
        "support_xy": np.asarray(arrays["support_xy"], dtype=np.float32),
        "support_xy_after": np.asarray(arrays["support_xy_after"], dtype=np.float32),
        "hist_labels": np.asarray(arrays["hist_labels"], dtype=np.int64),
        "hist_baseline": np.asarray(arrays["hist_baseline"], dtype=np.float32),
        "hist_train_free": np.asarray(arrays["hist_train_free"], dtype=np.float32),
        "hist_calibrated": np.asarray(arrays["hist_calibrated"], dtype=np.float32),
        "source_xy": source_xy.detach().cpu().numpy().astype(np.float32),
        "source_support_xy": source_support_xy.detach().cpu().numpy().astype(np.float32),
        "source_labels": source_labels,
    }
    trace = {
        "preset": args.preset,
        "class_name": args.class_name,
        "source_dataset": cfg["source_dataset"],
        "target_dataset": cfg["target_dataset"],
        "model_name": args.model_name,
        "prompt_load_mode": args.prompt_load_mode,
        "prompt_load_info": prompt_load_info,
        "features_list": args.features_list,
        "image_size": args.image_size,
        "dap_token_mode": args.dap_token_mode,
        "dpam_layer": args.dpam_layer,
        "alpha": args.alpha,
        "tau": args.tau,
        "fp_weight": args.fp_weight,
        "num_records": len(records),
        "pair_info": pair_info,
        "calibrators": {
            "branch1": {k: v for k, v in cal1.items() if k != "basis"},
            "branch2": {k: v for k, v in cal2.items() if k != "basis"},
        },
        "selected": {"defect": defect, "hard_normal": hard},
    }
    story_stats = draw_story_figure(out_dir, arrays_np, trace)
    clean_heatmap_paths = draw_clean_heatmap_recovery(out_dir, sample_cache, trace)
    scatter_paths = draw_pca_scatter(out_dir, arrays_np)
    trace["hist_stats"] = {
        "baseline": story_stats["baseline"],
        "train_free": story_stats["train_free"],
    }
    trace["pairwise"] = {
        "baseline": pairwise_stats(arrays_np["baseline"][arrays_np["labels"] == 1], arrays_np["baseline"][arrays_np["labels"] == 0]),
        "train_free": pairwise_stats(arrays_np["train_free"][arrays_np["labels"] == 1], arrays_np["train_free"][arrays_np["labels"] == 0]),
        "calibrated": pairwise_stats(arrays_np["calibrated"][arrays_np["labels"] == 1], arrays_np["calibrated"][arrays_np["labels"] == 0]),
        "calibrated_evidence": pairwise_stats(
            arrays_np["calibrated_evidence"][arrays_np["labels"] == 1],
            arrays_np["calibrated_evidence"][arrays_np["labels"] == 0],
        ),
    }
    trace["figures"] = {"story": story_stats, "clean_heatmap": clean_heatmap_paths, "scatter": scatter_paths}

    np.savez_compressed(out_dir / "scores_with_trace_vitl336.npz", **arrays_np)
    (out_dir / "records.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    (out_dir / "selected_pair.json").write_text(json.dumps(trace, indent=2), encoding="utf-8")
    print(json.dumps({"stage": "done", "save_dir": str(out_dir), "figures": trace["figures"], "hist_stats": trace["hist_stats"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
