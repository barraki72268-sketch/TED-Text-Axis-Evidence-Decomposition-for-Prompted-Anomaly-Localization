from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADA_ROOT = ROOT / "neurips2026" / "AdaCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ADA_ROOT) not in sys.path:
    sys.path.insert(0, str(ADA_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

from common_map_group_separability import (  # noqa: E402
    best_component_stats,
    plot_hist,
    save_summary,
    summarize_groups,
    top_fraction_mask,
    topk_mean_masked,
)
from dataset.visa import VISA_CLS_NAMES, VisaDataset  # noqa: E402
from method.trainer import AdaCLIP_Trainer  # noqa: E402


def main():
    parser = argparse.ArgumentParser("Collect Normal / Hard FP / True Defect separability for AdaCLIP")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(
            ROOT
            / "neurips2026"
            / "results"
            / "adaclip_fair_baseline_mvtec2visa"
            / "models"
            / "0s-pretrained-['mvtec']-ViT-L-14-336-SD-VL-D4-L5-HSF-K20_last.pth"
        ),
    )
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_points", type=int, default=200000)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_map_separability_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = args.device
    model = AdaCLIP_Trainer(
        backbone="ViT-L-14-336",
        feat_list=[6, 12, 18, 24],
        input_dim=1024,
        output_dim=768,
        learning_rate=0.001,
        device=device,
        image_size=518,
        prompting_depth=4,
        prompting_length=5,
        prompting_branch="VL",
        prompting_type="SD",
        use_hsf=True,
        k_clusters=20,
        use_ir_scorer=False,
        text_leakage_reg=False,
    )
    model.load(args.checkpoint_path)
    model.eval()
    model.clip_model.eval()

    dataset = VisaDataset(
        transform=model.preprocess,
        target_transform=model.transform,
        clsnames=VISA_CLS_NAMES,
        root="/mnt/data/gijeong/MMAD_new/VisA",
        training=False,
    )
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    groups = {"normal": [], "hard_fp": [], "true_defect": [], "outside": []}
    matched = {
        "hard_fp_topk": [],
        "true_defect_topk": [],
        "outside_topk": [],
        "hard_fp_comp_peak": [],
        "hard_fp_comp_mean": [],
        "hard_fp_comp_area": [],
        "true_defect_comp_peak": [],
        "true_defect_comp_mean": [],
        "true_defect_comp_area": [],
        "outside_comp_peak": [],
        "outside_comp_mean": [],
        "outside_comp_area": [],
    }

    print(
        json.dumps(
            {
                "stage": "map_separability_start",
                "num_images": len(dataset),
                "hard_frac": args.hard_frac,
                "checkpoint_path": args.checkpoint_path,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            cls_name = items["cls_name"]
            gt = items["img_mask"]
            gt[gt > 0.5], gt[gt <= 0.5] = 1, 0
            gt_mask = gt[0, 0].cpu().numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            anomaly_map, _ = model.clip_model(image, cls_name, aggregation=True)
            anomaly_map = anomaly_map[0].detach().cpu().numpy()
            anomaly_map = gaussian_filter(anomaly_map, sigma=4)
            score_mask = top_fraction_mask(anomaly_map, args.hard_frac)

            if is_anomaly and gt_mask.any():
                groups["true_defect"].append(anomaly_map[gt_mask].reshape(-1))
                groups["outside"].append(anomaly_map[~gt_mask].reshape(-1))
                matched["true_defect_topk"].append(topk_mean_masked(anomaly_map, gt_mask, args.hard_frac))
                matched["outside_topk"].append(topk_mean_masked(anomaly_map, ~gt_mask, args.hard_frac))
                defect_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="inside")
                outside_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="outside")
                if defect_comp is not None:
                    matched["true_defect_comp_peak"].append(defect_comp["peak"])
                    matched["true_defect_comp_mean"].append(defect_comp["mean"])
                    matched["true_defect_comp_area"].append(defect_comp["area"])
                if outside_comp is not None:
                    matched["outside_comp_peak"].append(outside_comp["peak"])
                    matched["outside_comp_mean"].append(outside_comp["mean"])
                    matched["outside_comp_area"].append(outside_comp["area"])
            else:
                hard_mask = score_mask
                groups["hard_fp"].append(anomaly_map[hard_mask].reshape(-1))
                groups["normal"].append(anomaly_map[~hard_mask].reshape(-1))
                matched["hard_fp_topk"].append(float(anomaly_map[hard_mask].mean()))
                hard_comp = best_component_stats(anomaly_map, score_mask)
                if hard_comp is not None:
                    matched["hard_fp_comp_peak"].append(hard_comp["peak"])
                    matched["hard_fp_comp_mean"].append(hard_comp["mean"])
                    matched["hard_fp_comp_area"].append(hard_comp["area"])

            if img_idx % 64 == 0 or img_idx == len(dataset):
                print(
                    json.dumps(
                        {
                            "stage": "map_separability_progress",
                            "images_done": img_idx,
                            "images_total": len(dataset),
                        }
                    ),
                    flush=True,
                )

    groups_np = {}
    for key, chunks in groups.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        if vals.size > args.max_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(vals.size, size=args.max_points, replace=False)
            vals = vals[idx]
        groups_np[key] = vals.astype(np.float32, copy=False)

    summary = {
        "host": "AdaCLIP",
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "num_images": len(dataset),
        "summary": summarize_groups(groups_np, max_summary_points=args.max_points),
    }
    matched_np = {
        key: np.asarray([v for v in vals if np.isfinite(v)], dtype=np.float32)
        for key, vals in matched.items()
    }
    summary["matched_summary"] = summarize_groups(
        matched_np,
        max_summary_points=args.max_points,
        pairs=[
            ("true_defect_topk", "hard_fp_topk"),
            ("true_defect_topk", "outside_topk"),
            ("true_defect_comp_peak", "hard_fp_comp_peak"),
            ("true_defect_comp_peak", "outside_comp_peak"),
            ("true_defect_comp_mean", "hard_fp_comp_mean"),
            ("true_defect_comp_mean", "outside_comp_mean"),
        ],
    )
    save_dir = Path(args.save_dir)
    save_summary(summary, save_dir)
    plot_hist(groups_np, save_dir / "hist.png", "AdaCLIP Map Separability")
    plot_hist(
        {
            "hard_fp_topk": matched_np["hard_fp_topk"],
            "true_defect_topk": matched_np["true_defect_topk"],
            "outside_topk": matched_np["outside_topk"],
        },
        save_dir / "matched_topk_hist.png",
        "AdaCLIP Matched Top-k Separability",
    )
    plot_hist(
        {
            "hard_fp_comp_peak": matched_np["hard_fp_comp_peak"],
            "true_defect_comp_peak": matched_np["true_defect_comp_peak"],
            "outside_comp_peak": matched_np["outside_comp_peak"],
        },
        save_dir / "matched_component_peak_hist.png",
        "AdaCLIP Component Peak Separability",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
