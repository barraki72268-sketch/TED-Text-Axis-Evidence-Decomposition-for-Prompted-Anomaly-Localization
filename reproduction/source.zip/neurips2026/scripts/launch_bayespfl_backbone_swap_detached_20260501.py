from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
QUEUE = ROOT / "neurips2026/scripts/queue_bayespfl_ted_backbone_swap_seeded_20260501.py"

JOBS = [
    (
        "vitb_plus",
        "0",
        ROOT / "neurips2026/results/bayespfl_ted_vitbplus_swap_seeded_20260501",
    ),
    (
        "vith14",
        "1",
        ROOT / "neurips2026/results/bayespfl_ted_vith14_swap_seeded_20260501",
    ),
]


def main() -> None:
    for backbone, gpu, result_root in JOBS:
        result_root.mkdir(parents=True, exist_ok=True)
        log_path = result_root / "_queue_detached.log"
        pid_path = result_root / "_queue_detached.pid"
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = gpu
        cmd = [
            PY,
            "-u",
            str(QUEUE),
            "--backbone",
            backbone,
            "--gpu",
            gpu,
        ]
        log_file = log_path.open("a")
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
        pid_path.write_text(str(proc.pid))
        print({"stage": "detached_started", "backbone": backbone, "gpu": gpu, "pid": proc.pid, "log": str(log_path)}, flush=True)


if __name__ == "__main__":
    main()
