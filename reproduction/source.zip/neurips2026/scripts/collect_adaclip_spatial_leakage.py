from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ADA_ROOT = ROOT / "neurips2026" / "AdaCLIP"
if str(ADA_ROOT) not in sys.path:
    sys.path.insert(0, str(ADA_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

from dataset.visa import VISA_CLS_NAMES, VisaDataset  # noqa: E402
from method.trainer import AdaCLIP_Trainer  # noqa: E402


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def save_rows(rows, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump(rows, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "class_name",
                "num_anomaly",
                "num_normal",
                "inside_mean",
                "outside_mean",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Collect baseline-only spatial leakage metrics for AdaCLIP")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(
            ROOT
            / "neurips2026"
            / "results"
            / "adaclip_fair_baseline_mvtec2visa"
            / "models"
            / "0s-pretrained-['mvtec']-ViT-L-14-336-SD-VL-D4-L5-HSF-K20_last.pth"
        ),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "problem_spatial_adaclip_baseline"),
    )
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = args.device
    model = AdaCLIP_Trainer(
        backbone="ViT-L-14-336",
        feat_list=[6, 12, 18, 24],
        input_dim=1024,
        output_dim=768,
        learning_rate=0.001,
        device=device,
        image_size=518,
        prompting_depth=4,
        prompting_length=5,
        prompting_branch="VL",
        prompting_type="SD",
        use_hsf=True,
        k_clusters=20,
        use_ir_scorer=False,
        text_leakage_reg=False,
    )
    model.load(args.checkpoint_path)
    model.eval()
    model.clip_model.eval()

    dataset = VisaDataset(
        transform=model.preprocess,
        target_transform=model.transform,
        clsnames=VISA_CLS_NAMES,
        root="/mnt/data/gijeong/MMAD_new/VisA",
        training=False,
    )
    obj_list = VISA_CLS_NAMES
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    per_class = {
        obj: {
            "num_anomaly": 0,
            "num_normal": 0,
            "inside_sum": 0.0,
            "outside_sum": 0.0,
            "ratio_sum": 0.0,
            "normal_topk_sum": 0.0,
            "normal_mean_sum": 0.0,
        }
        for obj in obj_list
    }

    with torch.no_grad():
        for items in loader:
            image = items["img"].to(device)
            cls_name = items["cls_name"]
            gt = items["img_mask"]
            gt[gt > 0.5], gt[gt <= 0.5] = 1, 0
            gt_mask = gt[0, 0].cpu().numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            anomaly_map, _ = model.clip_model(image, cls_name, aggregation=True)
            anomaly_map = anomaly_map[0].detach().cpu().numpy()
            anomaly_map = gaussian_filter(anomaly_map, sigma=4)

            stats = per_class[cls_name[0]]
            if is_anomaly and gt_mask.any():
                inside = float(anomaly_map[gt_mask].mean())
                outside = float(anomaly_map[~gt_mask].mean())
                stats["num_anomaly"] += 1
                stats["inside_sum"] += inside
                stats["outside_sum"] += outside
                stats["ratio_sum"] += outside / max(inside, 1e-8)
            else:
                stats["num_normal"] += 1
                stats["normal_topk_sum"] += topk_mean(anomaly_map, args.topk_frac)
                stats["normal_mean_sum"] += float(anomaly_map.mean())

    rows = []
    for cls_name, stats in per_class.items():
        row = {
            "class_name": cls_name,
            "num_anomaly": stats["num_anomaly"],
            "num_normal": stats["num_normal"],
            "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
            "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
            "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
            "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
            "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
            "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
        }
        rows.append(row)

    mean_row = {
        "class_name": "mean",
        "num_anomaly": sum(r["num_anomaly"] for r in rows),
        "num_normal": sum(r["num_normal"] for r in rows),
        "inside_mean": float(np.mean([r["inside_mean"] for r in rows])),
        "outside_mean": float(np.mean([r["outside_mean"] for r in rows])),
        "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in rows])),
        "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in rows])),
        "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in rows])),
        "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in rows])),
    }
    rows.append(mean_row)
    save_rows(rows, Path(args.save_dir))
    print(json.dumps({"num_rows": len(rows), "save_dir": args.save_dir, "mean": mean_row}, indent=2))


if __name__ == "__main__":
    main()
