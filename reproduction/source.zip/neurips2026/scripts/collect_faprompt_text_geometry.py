from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
FAPROMPT_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(FAPROMPT_ROOT) not in sys.path:
    sys.path.insert(0, str(FAPROMPT_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402


def cosine(a: torch.Tensor, b: torch.Tensor) -> float:
    a = F.normalize(a.float(), dim=-1)
    b = F.normalize(b.float(), dim=-1)
    return float((a * b).sum().item())


def normal_basis(text_bank: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    text_bank = F.normalize(text_bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(text_bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return text_bank.new_zeros((text_bank.shape[-1], 0))
    return vh[:rank].transpose(0, 1).contiguous()


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = vec @ basis
    return float(coeff.pow(2).sum().item())


def build_model(device: str):
    params = {
        "Prompt_length": 12,
        "learnabel_text_embedding_depth": 9,
        "learnabel_text_embedding_length": 4,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    return model, params


def build_prompt_learner(model, params, ckpt_path: Path, device: str):
    learner = FAPrompt(model.to("cpu"), params)
    ckpt = torch.load(ckpt_path, map_location="cpu")
    learner.load_state_dict(ckpt["prompt_learner"])
    learner.to(device)
    learner.eval()
    model.to(device)
    model.eval()
    return learner


@torch.no_grad()
def get_learned_text(model, learner):
    prompts_pos, prompts_neg, tokenized_prompt_pos, tokenized_prompt_neg, compound_prompts_text, _ = learner.forward()
    dev = next(model.parameters()).device
    prompts_pos = prompts_pos.to(dev)
    prompts_neg = prompts_neg.to(dev)
    tokenized_prompt_pos = tokenized_prompt_pos.to(dev)
    tokenized_prompt_neg = tokenized_prompt_neg.to(dev)
    compound_prompts_text = [prompt.to(dev) for prompt in compound_prompts_text]

    text_features_pos = model.encode_text_learn(prompts_pos, tokenized_prompt_pos, compound_prompts_text).float()
    text_features_neg = model.encode_text_learn(prompts_neg, tokenized_prompt_neg, compound_prompts_text).float()
    text_features_neg_mean = torch.mean(text_features_neg, dim=0, keepdim=True)

    learned_normal = F.normalize(text_features_pos[0], dim=-1)
    learned_anomaly = F.normalize(text_features_neg_mean[0], dim=-1)
    normal_bank = F.normalize(text_features_pos, dim=-1)
    return learned_normal, learned_anomaly, normal_bank


@torch.no_grad()
def get_base_text(model, params, device: str):
    base_learner = FAPrompt(model.to("cpu"), params)
    base_learner.to(device)
    base_learner.eval()
    learned_normal, learned_anomaly, _ = get_learned_text(model, base_learner)
    return learned_normal, learned_anomaly


def save_rows(rows, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump(rows, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "epoch",
                "overlap_cos",
                "proj_energy_to_normal",
                "anchor_retention_norm",
                "anchor_retention_anom",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Collect FAPrompt text geometry")
    parser.add_argument(
        "--ckpt_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_baseline_mvtec" / "checkpoints"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "problem_geom_faprompt_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    os.environ.setdefault("FAPROMPT_CACHE_DIR", "/mnt/data/pilab-kingjinyoung/ADPretrain/FAPrompt/.cache/clip")

    model, params = build_model(args.device)
    base_normal, base_anomaly = get_base_text(model, params, args.device)
    rows = []
    for ckpt_path in sorted(Path(args.ckpt_dir).glob("epoch_*.pth"), key=lambda p: int(p.stem.split("_")[-1])):
        learner = build_prompt_learner(model, params, ckpt_path, args.device)
        learned_normal, learned_anomaly, normal_bank = get_learned_text(model, learner)
        basis = normal_basis(normal_bank).to(learned_normal.device)
        rows.append(
            {
                "epoch": int(ckpt_path.stem.split("_")[-1]),
                "overlap_cos": cosine(learned_anomaly, learned_normal),
                "proj_energy_to_normal": projection_energy(learned_anomaly, basis),
                "anchor_retention_norm": cosine(learned_normal, base_normal),
                "anchor_retention_anom": cosine(learned_anomaly, base_anomaly),
            }
        )
    save_rows(rows, Path(args.save_dir))
    print(json.dumps({"num_rows": len(rows), "save_dir": args.save_dir}, indent=2))


if __name__ == "__main__":
    main()
