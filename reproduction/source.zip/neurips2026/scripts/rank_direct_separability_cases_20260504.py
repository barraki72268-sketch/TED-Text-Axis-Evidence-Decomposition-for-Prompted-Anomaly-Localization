#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"


def pct(x: float | None) -> float | None:
    if x is None:
        return None
    return float(x) * 100.0 if abs(float(x)) <= 1.5 else float(x)


def metric_delta(b: dict[str, Any], c: dict[str, Any]) -> dict[str, float]:
    return {
        "d_pauc": pct(c.get("pixel_auc")) - pct(b.get("pixel_auc")),
        "d_pro": pct(c.get("pixel_aupro")) - pct(b.get("pixel_aupro")),
        "d_ap": pct(c.get("pixel_ap")) - pct(b.get("pixel_ap")),
    }


def pick_cted(mapping: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(mapping, dict) or not mapping:
        return None
    preferred = [
        "branch_calibrated_alpha_0.5",
        "prescore_calibrated_alpha_1",
        "ted_calibrated",
        "ted_calibrated_vl",
        "ted_calibrated_tl",
    ]
    for key in preferred:
        if key in mapping:
            return mapping[key]
    return mapping[sorted(mapping.keys())[0]]


def parse_summary(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text())
    setting = path.parent.name
    rows: list[dict[str, Any]] = []

    def add_row(level: str, class_name: str, rec: dict[str, Any]) -> None:
        base = rec.get("baseline_official") or rec.get("baseline")
        cted = pick_cted(rec.get("parallel", rec.get("candidates", {})))
        sep = rec.get("separability")
        if not base or not cted or not sep:
            return
        sep_b = sep.get("baseline_official") or sep.get("baseline")
        sep_c = pick_cted(sep.get("parallel", sep.get("candidates", {})))
        if not sep_b or not sep_c:
            return
        md = metric_delta(base, cted)
        b_auc = float(sep_b.get("auc_defect_vs_hardfp", np.nan))
        c_auc = float(sep_c.get("auc_defect_vs_hardfp", np.nan))
        b_out = float(sep_b.get("auc_defect_vs_outside", np.nan))
        c_out = float(sep_c.get("auc_defect_vs_outside", np.nan))
        b_gap = float(sep_b.get("mean_true_defect", np.nan)) - float(sep_b.get("mean_hard_fp", np.nan))
        c_gap = float(sep_c.get("mean_true_defect", np.nan)) - float(sep_c.get("mean_hard_fp", np.nan))
        rows.append(
            {
                "setting": setting,
                "level": level,
                "class_name": class_name,
                **md,
                "d_avg_pixel": float(np.mean([md["d_pauc"], md["d_pro"], md["d_ap"]])),
                "base_auc_d_hfp": b_auc,
                "cted_auc_d_hfp": c_auc,
                "d_auc_d_hfp": c_auc - b_auc,
                "base_auc_d_out": b_out,
                "cted_auc_d_out": c_out,
                "d_auc_d_out": c_out - b_out,
                "base_gap_d_hfp": b_gap,
                "cted_gap_d_hfp": c_gap,
                "d_gap_d_hfp": c_gap - b_gap,
                "score": (c_auc - b_auc) * 100.0 + (c_gap - b_gap) * 50.0 + 0.25 * md["d_pro"] + 0.25 * md["d_ap"],
                "path": str(path.relative_to(ROOT)),
            }
        )

    mean = data.get("mean", {})
    sep_mean = data.get("separability_mean")
    if mean and sep_mean:
        rec = dict(mean)
        rec["separability"] = sep_mean
        add_row("mean", "mean", rec)

    per_class = data.get("per_class")
    if isinstance(per_class, list):
        for rec in per_class:
            add_row("class", str(rec.get("class_name", "unknown")), rec)
    elif isinstance(per_class, dict):
        for cls, rec in per_class.items():
            add_row("class", str(cls), rec)

    return rows


def fmt(x: float, nd: int = 2) -> str:
    return f"{x:+.{nd}f}"


def write_outputs(rows: list[dict[str, Any]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / "direct_separability_ranked_cases_20260504.csv"
    fields = list(rows[0].keys()) if rows else []
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    candidates = [
        r
        for r in rows
        if r["level"] == "class"
        and r["d_pro"] > 0.0
        and r["d_ap"] > 0.0
        and (r["d_auc_d_hfp"] > 0.0 or r["d_gap_d_hfp"] > 0.0)
    ]
    candidates = sorted(candidates, key=lambda r: (r["d_auc_d_hfp"] > 0.0, r["score"]), reverse=True)
    selected = candidates[:8]

    md = [
        "# Direct separability cases",
        "",
        "Selected class-level cases where localization improves and either defect-vs-hard-FP AUC or score gap improves.",
        "",
        "| Setting | Class | ΔP-AUC | ΔPRO | ΔAP | ΔAUC(D,H-FP) | ΔGap(D,H-FP) |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for r in selected:
        md.append(
            f"| {r['setting']} | {r['class_name']} | {fmt(r['d_pauc'])} | {fmt(r['d_pro'])} | {fmt(r['d_ap'])} | "
            f"{fmt(100*r['d_auc_d_hfp'])} | {fmt(100*r['d_gap_d_hfp'])} |"
        )
    (OUT / "direct_separability_selected_cases_20260504.md").write_text("\n".join(md) + "\n")

    tex = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Representative failure-conditioned cases.",
        r"Rows show class-level cases where C-TED improves localization and also increases either defect-vs-hard-FP AUC or the defect-minus-hard-FP score gap.",
        r"}",
        r"\label{tab:failure_conditioned_cases}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.2pt}",
        r"\renewcommand{\arraystretch}{1.05}",
        r"\resizebox{\linewidth}{!}{%",
        r"\begin{tabular}{llrrrrr}",
        r"\toprule",
        r"Setting & Class & $\Delta$P-AUC & $\Delta$PRO & $\Delta$AP & $\Delta$AUC & $\Delta$Gap \\",
        r"\midrule",
    ]
    for r in selected[:5]:
        setting = str(r["setting"]).replace("_", r"\_")
        cls = str(r["class_name"]).replace("_", r"\_")
        tex.append(
            f"{setting} & {cls} & {fmt(r['d_pauc'])} & {fmt(r['d_pro'])} & {fmt(r['d_ap'])} & "
            f"{fmt(100*r['d_auc_d_hfp'])} & {fmt(100*r['d_gap_d_hfp'])} \\\\"
        )
    tex += [
        r"\bottomrule",
        r"\end{tabular}%",
        r"}",
        r"\end{table}",
        "",
    ]
    (OUT / "direct_separability_selected_cases_table_20260504.tex").write_text("\n".join(tex))

    direct_candidates = [
        r
        for r in rows
        if "failure_conditioned_separability_20260504" in str(r["path"])
        and r["level"] == "class"
        and r["d_pro"] > 0.0
        and r["d_ap"] > 0.0
        and r["d_auc_d_hfp"] > 0.0
        and r["d_gap_d_hfp"] > 0.0
    ]
    direct_candidates = sorted(direct_candidates, key=lambda r: r["score"], reverse=True)
    direct_selected = direct_candidates[:6]
    direct_md = [
        "# Direct-only failure-conditioned cases",
        "",
        "Selected from `failure_conditioned_separability_20260504` only.",
        "",
        "| Transfer | Class | ΔP-AUC | ΔPRO | ΔAP | ΔAUC(D,H-FP) | ΔGap(D,H-FP) |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for r in direct_selected:
        transfer = str(r["setting"]).replace("faprompt_vitl336_", "")
        direct_md.append(
            f"| {transfer} | {r['class_name']} | {fmt(r['d_pauc'])} | {fmt(r['d_pro'])} | {fmt(r['d_ap'])} | "
            f"{fmt(100*r['d_auc_d_hfp'])} | {fmt(100*r['d_gap_d_hfp'])} |"
        )
    (OUT / "direct_only_failure_conditioned_cases_20260504.md").write_text("\n".join(direct_md) + "\n")

    direct_tex = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Representative failure-conditioned cases from the fixed FAPrompt sweep.",
        r"Each row is a target class where C-TED improves localization while increasing both defect-vs-hard-FP AUC and the defect-minus-hard-FP score gap.",
        r"}",
        r"\label{tab:failure_conditioned_direct_cases}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.4pt}",
        r"\renewcommand{\arraystretch}{1.05}",
        r"\resizebox{\linewidth}{!}{%",
        r"\begin{tabular}{llrrrrr}",
        r"\toprule",
        r"Transfer & Class & $\Delta$P-AUC & $\Delta$PRO & $\Delta$AP & $\Delta$AUC & $\Delta$Gap \\",
        r"\midrule",
    ]
    for r in direct_selected[:5]:
        transfer = str(r["setting"]).replace("faprompt_vitl336_", "").replace("2", r"$\to$")
        cls = str(r["class_name"]).replace("_", r"\_")
        direct_tex.append(
            f"{transfer} & {cls} & {fmt(r['d_pauc'])} & {fmt(r['d_pro'])} & {fmt(r['d_ap'])} & "
            f"{fmt(100*r['d_auc_d_hfp'])} & {fmt(100*r['d_gap_d_hfp'])} \\\\"
        )
    direct_tex += [
        r"\bottomrule",
        r"\end{tabular}%",
        r"}",
        r"\end{table}",
        "",
    ]
    (OUT / "direct_only_failure_conditioned_cases_table_20260504.tex").write_text("\n".join(direct_tex))


def main() -> int:
    paths = sorted((ROOT / "neurips2026" / "results").glob("**/summary.json"))
    rows: list[dict[str, Any]] = []
    for path in paths:
        try:
            text = path.read_text()
        except UnicodeDecodeError:
            continue
        if "auc_defect_vs_hardfp" not in text:
            continue
        rows.extend(parse_summary(path))
    rows = sorted(rows, key=lambda r: r["score"], reverse=True)
    write_outputs(rows)
    candidates = [
        r
        for r in rows
        if r["level"] == "class"
        and r["d_pro"] > 0.0
        and r["d_ap"] > 0.0
        and (r["d_auc_d_hfp"] > 0.0 or r["d_gap_d_hfp"] > 0.0)
    ]
    print(
        json.dumps(
            {
                "rows": len(rows),
                "candidate_rows": len(candidates),
                "csv": str((OUT / "direct_separability_ranked_cases_20260504.csv").relative_to(ROOT)),
                "selected_md": str((OUT / "direct_separability_selected_cases_20260504.md").relative_to(ROOT)),
                "selected_tex": str((OUT / "direct_separability_selected_cases_table_20260504.tex").relative_to(ROOT)),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
