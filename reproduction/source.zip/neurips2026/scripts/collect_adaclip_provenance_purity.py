from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from neurips2026.scripts.adaclip_diagnostics_common import (
    AdaCLIPDiagConfig,
    ROOT,
    _preset_fields,
    build_loader,
    compute_mode_outputs,
    load_model_and_banks,
    save_json,
)
from neurips2026.scripts.official_parallel_test_adaclip import resolve_layer_recipe


def topk_patch_indices(score: torch.Tensor, frac: float) -> torch.Tensor:
    k = max(1, int(round(score.numel() * frac)))
    return torch.topk(score, k=k, largest=True).indices


def main() -> None:
    parser = argparse.ArgumentParser("AdaCLIP support provenance purity")
    parser.add_argument("--preset", type=str, required=True)
    parser.add_argument("--layer_recipe", type=str, default="all4")
    parser.add_argument("--run_tag", type=str, default="pilot_v1")
    parser.add_argument("--topk_frac", type=float, default=0.1)
    parser.add_argument("--class_name", type=str, default=None)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--cpu_threads", type=int, default=1)
    args = parser.parse_args()

    cfg = AdaCLIPDiagConfig(
        preset=args.preset,
        layer_recipe=args.layer_recipe,
        class_name=args.class_name,
        device=args.device,
        num_workers=args.num_workers,
        cpu_threads=args.cpu_threads,
    )
    model, fp_banks_gpu, def_banks_gpu, meta = load_model_and_banks(cfg)
    preset = _preset_fields(args.preset)
    _, loader = build_loader(cfg, preset["target_root"], preset["target_dataset"], model)
    selected = resolve_layer_recipe(meta["features_list"], args.layer_recipe)

    stats = {
        "baseline": {"anom_pos_rate": [], "anom_margin": [], "normal_pos_rate": [], "normal_margin": []},
        "ours": {"anom_pos_rate": [], "anom_margin": [], "normal_pos_rate": [], "normal_margin": []},
    }
    with torch.no_grad():
        for items in loader:
            image = items["img"].to(cfg.device)
            cls_name = items["cls_name"][0]
            is_anomaly = int(items["anomaly"][0])
            out = compute_mode_outputs(
                model=model,
                fp_banks_gpu=fp_banks_gpu,
                def_banks_gpu=def_banks_gpu,
                selected_layer_indices=selected,
                image=image,
                cls_name=cls_name,
                sigma=cfg.sigma,
                tau=cfg.tau,
                fp_weight=cfg.fp_weight,
                scoring_mode=cfg.scoring_mode,
                refine_alpha=cfg.refine_alpha,
                refine_beta=cfg.refine_beta,
                margin_norm_mode=cfg.margin_norm_mode,
                image_size=cfg.image_size,
            )
            provenance_margin = out["provenance_margin"]
            for mode, score_key in (("baseline", "baseline_patch_score"), ("ours", "parallel_patch_score")):
                idx = topk_patch_indices(out[score_key], args.topk_frac)
                top_margin = provenance_margin[idx]
                pos_rate = float((top_margin > 0).float().mean().item())
                mean_margin = float(top_margin.mean().item())
                if is_anomaly == 0:
                    stats[mode]["normal_pos_rate"].append(pos_rate)
                    stats[mode]["normal_margin"].append(mean_margin)
                else:
                    stats[mode]["anom_pos_rate"].append(pos_rate)
                    stats[mode]["anom_margin"].append(mean_margin)

    rows = []
    for mode_key, mode_name in (("baseline", "baseline_txt"), ("ours", "parallel_margin")):
        row = {
            "preset": args.preset,
            "layer_recipe": args.layer_recipe,
            "mode": mode_name,
            "anomaly_positive_rate": float(np.mean(stats[mode_key]["anom_pos_rate"])),
            "anomaly_margin_mean": float(np.mean(stats[mode_key]["anom_margin"])),
            "normal_positive_rate": float(np.mean(stats[mode_key]["normal_pos_rate"])),
            "normal_margin_mean": float(np.mean(stats[mode_key]["normal_margin"])),
        }
        row["purity_gap"] = row["anomaly_positive_rate"] - row["normal_positive_rate"]
        row["margin_gap"] = row["anomaly_margin_mean"] - row["normal_margin_mean"]
        rows.append(row)

    payload = {
        "meta": {
            "preset": args.preset,
            "run_tag": args.run_tag,
            "layer_recipe": args.layer_recipe,
            "topk_frac": args.topk_frac,
            "class_name": args.class_name,
            **meta,
        },
        "rows": rows,
    }
    out_path = ROOT / "neurips2026" / "results" / "adaclip_provenance_purity" / f"{args.preset}_{args.run_tag}.json"
    save_json(out_path, payload)
    print(json.dumps({"path": str(out_path), "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
