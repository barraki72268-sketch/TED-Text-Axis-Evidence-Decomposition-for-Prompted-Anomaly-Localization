#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_rawimagebind.py"
export MPLCONFIGDIR="/tmp/matplotlib-rawimagebind-all-gpu1"

run_one() {
  local source_root="$1"
  local source_dataset="$2"
  local target_root="$3"
  local target_dataset="$4"
  local save_dir="$5"
  local bank_cache="$6"

  "${PYTHON}" "${SCRIPT}" \
    --source_root "${source_root}" \
    --source_dataset "${source_dataset}" \
    --target_root "${target_root}" \
    --target_dataset "${target_dataset}" \
    --save_dir "${save_dir}" \
    --bank_cache_path "${bank_cache}" \
    --prompt_mode class \
    --image_size 224 \
    --device cuda:1
}

run_one \
  "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  "visa" \
  "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  "mvtec" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_visa2mvtec_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_visa_class_exclude-none_all.pt"

run_one \
  "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  "mvtec" \
  "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  "visa" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_mvtec2visa_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_mvtec_class_exclude-none_all.pt"

run_one \
  "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  "mvtec" \
  "/mnt/data/MPDD" \
  "mpdd" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_mvtec2mpdd_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_mvtec_class_exclude-none_all.pt"

run_one \
  "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  "mvtec" \
  "${ROOT}/neurips2026/data/BTAD_official" \
  "btad" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_mvtec2btad_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawimagebind_mvtec_class_exclude-none_all.pt"
