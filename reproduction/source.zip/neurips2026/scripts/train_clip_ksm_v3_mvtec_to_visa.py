from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD  # noqa: E402
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
    encode_text_features,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (  # noqa: E402
    choose_text_rank,
    forward_remaining,
    forward_up_to_layer,
    l2_normalize,
    patchify_sequence,
    rebuild_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


@dataclass
class Record:
    image_t: torch.Tensor | None
    patch_mask: np.ndarray | None
    label: int
    name: str
    class_name: str
    image_path: str | None = None
    mask_path: str | None = None


@dataclass
class PromptCondition:
    p_norm: torch.Tensor
    prompt_features: torch.Tensor
    U_basis: torch.Tensor
    delta_key: torch.Tensor
    delta_val: torch.Tensor
    text_rank: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("KSM v3 mixed-source MVTec -> VisA zero-shot pilot.")
    parser.add_argument("--source_dataset", type=str, default="mvtec", choices=["mvtec", "realiad"])
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--realiad_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument(
        "--target_classes",
        nargs="+",
        default=[
            "chewinggum",
            "pipe_fryum",
            "pcb4",
            "macaroni2",
            "cashew",
            "pcb1",
            "macaroni1",
            "fryum",
            "pcb2",
            "capsules",
            "candle",
            "pcb3",
        ],
    )
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--layer", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-2)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--train_batch_size", type=int, default=64)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    parser.add_argument("--gamma_init", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=8)
    parser.add_argument("--train_anomaly_images", type=int, default=8)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_n", type=float, default=1.0)
    parser.add_argument("--lambda_smooth", type=float, default=0.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--entropy_beta_max", type=float, default=0.05)
    parser.add_argument("--entropy_hold_epochs", type=int, default=2)
    parser.add_argument("--entropy_decay_epochs", type=int, default=5)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_ksm_v3_mvtec_to_visa")
    return parser.parse_args()


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = l2_normalize(p_norm, dim=0)
    return v.float() - (v.float() * p_norm.view(*([1] * (v.dim() - 1)), -1)).sum(dim=-1, keepdim=True) * p_norm.view(
        *([1] * (v.dim() - 1)),
        -1,
    )


def compute_consensus_loss(
    r_out: torch.Tensor,
    prompt_features: torch.Tensor,
    mask: torch.Tensor,
    topk_ratio: float | None,
) -> torch.Tensor:
    pos = mask > 0
    if int(pos.sum().item()) == 0:
        return torch.zeros([], device=r_out.device)
    scores = torch.matmul(r_out[pos], prompt_features.T)
    j_star = torch.argmax(scores.mean(dim=0))
    patch_scores = scores[:, j_star]
    if topk_ratio is None:
        return 1.0 - patch_scores.mean()
    k_anom = max(1, int(float(topk_ratio) * float(patch_scores.numel())))
    topk_scores = torch.topk(patch_scores, k=min(k_anom, patch_scores.numel()), largest=True).values
    return 1.0 - topk_scores.mean()


def compute_hard_norm(
    v_out_raw: torch.Tensor,
    v_in: torch.Tensor,
    mask: torch.Tensor,
    hard_neg_ratio: float,
) -> torch.Tensor:
    neg = mask <= 0
    if int(neg.sum().item()) == 0:
        return torch.zeros([], device=v_out_raw.device)
    v_in_neg = v_in[neg]
    v_out_neg = v_out_raw[neg]
    diff = (v_out_neg - v_in_neg).norm(dim=-1)
    hard_k = max(1, int(round(float(hard_neg_ratio) * float(diff.numel())))) if diff.numel() > 0 else 0
    if hard_k > 0:
        hard_idx = torch.topk(diff, k=min(hard_k, diff.numel()), largest=True).indices
        return F.mse_loss(v_out_neg[hard_idx], v_in_neg[hard_idx])
    return F.mse_loss(v_out_neg, v_in_neg)


def compute_spatial_smooth(delta_u: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    bsz, num_patches, dim = delta_u.shape
    grid = int(round(math.sqrt(num_patches)))
    if grid * grid != num_patches:
        return torch.zeros([], device=delta_u.device)

    delta_grid = delta_u.view(bsz, grid, grid, dim)
    mask_grid = mask.view(bsz, grid, grid).float()
    diff_h = delta_grid[:, 1:, :, :] - delta_grid[:, :-1, :, :]
    diff_w = delta_grid[:, :, 1:, :] - delta_grid[:, :, :-1, :]
    mask_h = mask_grid[:, 1:, :] * mask_grid[:, :-1, :]
    mask_w = mask_grid[:, :, 1:] * mask_grid[:, :, :-1]

    loss_h = torch.zeros([], device=delta_u.device)
    loss_w = torch.zeros([], device=delta_u.device)
    if float(mask_h.sum().item()) > 0:
        loss_h = (diff_h.pow(2).mean(dim=-1) * mask_h).sum() / (mask_h.sum() + 1e-6)
    if float(mask_w.sum().item()) > 0:
        loss_w = (diff_w.pow(2).mean(dim=-1) * mask_w).sum() / (mask_w.sum() + 1e-6)
    return loss_h + loss_w


class KinematicSteeringModuleV3Conditional(nn.Module):
    def __init__(self, dim: int, gamma_init: float = 1e-3):
        super().__init__()
        self.dim = int(dim)
        self.q_proj_simplex = nn.Linear(3 * self.dim, self.dim, bias=False)
        self.q_proj_subspace = nn.Linear(3 * self.dim, self.dim, bias=False)
        self.router = nn.Linear(self.dim, 1, bias=True)
        nn.init.xavier_uniform_(self.q_proj_simplex.weight, gain=0.25)
        nn.init.xavier_uniform_(self.q_proj_subspace.weight, gain=0.25)
        nn.init.zeros_(self.router.weight)
        nn.init.zeros_(self.router.bias)
        self.gamma_simplex = nn.Parameter(torch.full((1,), float(gamma_init), dtype=torch.float32))
        self.gamma_subspace = nn.Parameter(torch.full((1,), float(gamma_init), dtype=torch.float32))

    def forward(
        self,
        v_in: torch.Tensor,
        cond: PromptCondition,
        return_aux: bool = False,
    ):
        bsz, n, dim = v_in.shape
        assert dim == self.dim
        v_in = v_in.float()
        p_norm = cond.p_norm
        delta_key = cond.delta_key
        delta_val = cond.delta_val
        U_basis = cond.U_basis

        v_bar = v_in.mean(dim=1, keepdim=True)
        v_res = v_in - v_bar
        q_ctx = torch.cat([v_in, v_bar.expand(-1, n, -1), v_res], dim=-1)
        q_simplex = self.q_proj_simplex(q_ctx)
        q_subspace = self.q_proj_subspace(q_ctx)

        simplex_logits = torch.matmul(q_simplex, delta_key.T) / math.sqrt(self.dim)
        simplex_attn = torch.softmax(simplex_logits, dim=-1)
        delta_simplex = torch.matmul(simplex_attn, delta_val)

        subspace_logits = torch.matmul(q_subspace, U_basis.T) / math.sqrt(self.dim)
        subspace_attn = torch.tanh(subspace_logits)
        delta_subspace = torch.matmul(subspace_attn, U_basis)

        alpha = torch.sigmoid(self.router(v_bar.squeeze(1))).view(bsz, 1, 1)
        simplex_delta = get_null_space_residual(self.gamma_simplex.view(1, 1, 1) * delta_simplex, p_norm)
        subspace_delta = get_null_space_residual(self.gamma_subspace.view(1, 1, 1) * delta_subspace, p_norm)
        delta_mix = alpha * simplex_delta + (1.0 - alpha) * subspace_delta
        v_out = v_in + get_null_space_residual(delta_mix, p_norm)
        if not return_aux:
            return v_out
        return v_out, {
            "alpha_tensor": alpha,
            "alpha_mean": float(alpha.mean().item()),
            "gamma_simplex_abs": float(self.gamma_simplex.abs().item()),
            "gamma_subspace_abs": float(self.gamma_subspace.abs().item()),
            "simplex_attn_entropy": float((-(simplex_attn.clamp_min(1e-8) * simplex_attn.clamp_min(1e-8).log()).sum(dim=-1)).mean().item()),
            "simplex_top1_mass": float(simplex_attn.max(dim=-1).values.mean().item()),
            "simplex_delta": simplex_delta,
            "subspace_delta": subspace_delta,
        }


def compute_v36_loss(
    v_in: torch.Tensor,
    aux: dict[str, torch.Tensor | float],
    cond: PromptCondition,
    mask: torch.Tensor,
    lambda_n: float,
    lambda_smooth: float,
    topk_anom_ratio: float,
    hard_neg_ratio: float,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    p_norm = cond.p_norm
    prompt_features = cond.prompt_features
    simplex_delta = aux["simplex_delta"]
    subspace_delta = aux["subspace_delta"]
    alpha = aux["alpha_tensor"]

    v_out_s_raw = v_in + simplex_delta
    v_out_u_raw = v_in + subspace_delta
    r_out_s = l2_normalize(get_null_space_residual(v_out_s_raw, p_norm), dim=-1)
    r_out_u = l2_normalize(get_null_space_residual(v_out_u_raw, p_norm), dim=-1)

    delta_v_mixed_detached = alpha * simplex_delta.detach() + (1.0 - alpha) * subspace_delta.detach()
    v_out_mixed_raw = v_in + delta_v_mixed_detached
    r_out_mixed = l2_normalize(get_null_space_residual(v_out_mixed_raw, p_norm), dim=-1)

    l_s = compute_consensus_loss(r_out_s, prompt_features, mask, topk_ratio=topk_anom_ratio)
    l_u = compute_consensus_loss(r_out_u, prompt_features, mask, topk_ratio=None)
    l_router = compute_consensus_loss(r_out_mixed, prompt_features, mask, topk_ratio=None)
    l_smooth = compute_spatial_smooth(subspace_delta, mask) if lambda_smooth > 0 else torch.zeros([], device=v_in.device)
    l_norm_s = compute_hard_norm(v_out_s_raw, v_in, mask, hard_neg_ratio)
    l_norm_u = compute_hard_norm(v_out_u_raw, v_in, mask, hard_neg_ratio)
    total = l_s + l_u + l_router + float(lambda_smooth) * l_smooth + float(lambda_n) * (l_norm_s + l_norm_u)
    return total, {
        "l_s": l_s,
        "l_u": l_u,
        "l_router": l_router,
        "l_smooth": l_smooth,
        "l_norm_s": l_norm_s,
        "l_norm_u": l_norm_u,
    }


def entropy_beta(epoch: int, beta_max: float, hold_epochs: int, decay_epochs: int) -> float:
    if beta_max <= 0:
        return 0.0
    if epoch <= hold_epochs:
        return float(beta_max)
    decay_step = epoch - hold_epochs
    if decay_step >= decay_epochs:
        return 0.0
    frac = 1.0 - (float(decay_step) / float(decay_epochs))
    return float(beta_max) * max(0.0, frac)


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int]) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .numpy()
        .astype(np.int64)
    )


def materialize_record(backbone, rec: Record) -> tuple[torch.Tensor, np.ndarray]:
    if rec.image_t is not None and rec.patch_mask is not None:
        return rec.image_t, rec.patch_mask

    assert rec.image_path is not None
    image = Image.open(rec.image_path).convert("RGB")
    image_t = backbone.transform_pil(image).unsqueeze(0).cpu()
    if rec.label == 0:
        patch_mask = np.zeros(backbone.grid_size[0] * backbone.grid_size[1], dtype=np.int64)
    else:
        assert rec.mask_path is not None
        mask_np = np.asarray(Image.open(rec.mask_path), dtype=np.uint8)
        if mask_np.ndim == 3:
            mask_np = mask_np[..., 0]
        mask_np = (mask_np > 0).astype(np.uint8) * 255
        patch_mask = to_patch_mask(mask_np, backbone.grid_size)
    return image_t, patch_mask


def materialize_record_batch(backbone, batch_records: list[Record]) -> tuple[torch.Tensor, np.ndarray]:
    images = []
    masks = []
    for rec in batch_records:
        image_t, patch_mask = materialize_record(backbone, rec)
        images.append(image_t)
        masks.append(patch_mask)
    return torch.cat(images, dim=0), np.stack(masks, axis=0)


def json_to_mask(json_path: Path, image_size: tuple[int, int]) -> np.ndarray:
    h, w = image_size
    mask = np.zeros((h, w), dtype=np.uint8)
    if not json_path.exists():
        return mask
    obj = json.loads(json_path.read_text())
    for shape in obj.get("shapes", []):
        points = shape.get("points", [])
        if len(points) != 2:
            continue
        (x0, y0), (x1, y1) = points
        xa, xb = sorted((int(round(x0)), int(round(x1))))
        ya, yb = sorted((int(round(y0)), int(round(y1))))
        xa = max(0, min(xa, w - 1))
        xb = max(0, min(xb, w))
        ya = max(0, min(ya, h - 1))
        yb = max(0, min(yb, h))
        if xb > xa and yb > ya:
            mask[ya:yb, xa:xb] = 255
    return mask


def collect_mvtec_train_records(backbone, args: argparse.Namespace) -> list[Record]:
    root = Path(args.mvtec_root)
    records: list[Record] = []
    for class_name in args.source_classes:
        class_dir = root / class_name
        good_dir = class_dir / "good"
        good_paths = sorted(good_dir.glob("*.png"))
        if args.train_normal_images > 0:
            good_paths = good_paths[: args.train_normal_images]

        anom_paths: list[Path] = []
        for defect_dir in sorted([p for p in class_dir.iterdir() if p.is_dir() and p.name != "good"]):
            anom_paths.extend(sorted(defect_dir.glob("*.png")))
        if args.train_anomaly_images > 0:
            anom_paths = anom_paths[: args.train_anomaly_images]

        for img_path in good_paths + anom_paths:
            image = np.asarray(Image.open(img_path).convert("RGB"), dtype=np.uint8)
            json_path = img_path.with_suffix(".json")
            if img_path.parent.name == "good":
                mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
                label = 0
            else:
                mask = json_to_mask(json_path, image.shape[:2])
                label = 1
            image_t = backbone.transform_pil(Image.fromarray(image)).unsqueeze(0).cpu()
            records.append(
                Record(
                    image_t=image_t,
                    patch_mask=to_patch_mask(mask, backbone.grid_size),
                    label=label,
                    name=f"{class_name}-{img_path.parent.name}-{img_path.stem}",
                    class_name=class_name,
                )
            )
    return records


def collect_realiad_train_records(backbone, args: argparse.Namespace) -> list[Record]:
    dataset = RealIAD(
        args.realiad_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.img_size,
        crp_size=args.img_size,
        msk_size=args.img_size,
        msk_crp_size=args.img_size,
        sub_dir=RealIAD._resolve_sub_dir(args.realiad_root, None),
    )
    records: list[Record] = []
    items = []
    for view_items in dataset.data_items_by_view.values():
        items.extend(view_items)
    for idx, item in enumerate(items):
        label = int(item["label"])
        if label == 1 and item["mask_path"] is None:
            continue
        records.append(
            Record(
                image_t=None,
                patch_mask=None,
                label=label,
                name=f"{item['class_name']}-{item['sample_id']}-{idx}",
                class_name=item["class_name"],
                image_path=item["image_path"],
                mask_path=item["mask_path"],
            )
        )
    return records


def collect_visa_eval_records(backbone, class_name: str, args: argparse.Namespace) -> list[Record]:
    ds = OfficialVisAWinClipDataset(args.visa_root, args.visa_split_csv, class_name, "test")
    records: list[Record] = []
    for idx in range(len(ds)):
        image_np, mask_np, label, name, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).cpu()
        item = ds.records[idx]
        records.append(
            Record(
                image_t=image_t,
                patch_mask=to_patch_mask(mask_np, backbone.grid_size),
                label=int(label != 0),
                name=name,
                class_name=class_name,
                image_path=item["image_path"],
                mask_path=item["mask_path"],
            )
        )
    return records


def build_prompt_condition(backbone, class_name: str, text_var_threshold: float, device: str) -> PromptCondition:
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0].to(device)
    prompt_features = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts).to(device)
    delta_bank = prompt_features - p_norm.unsqueeze(0)
    text_rank = choose_text_rank(delta_bank, text_var_threshold)
    delta_key = l2_normalize(delta_bank, dim=-1)
    delta_val = l2_normalize(get_null_space_residual(delta_bank, p_norm), dim=-1)
    delta_center = delta_bank - delta_bank.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(delta_center, full_matrices=False)
    U_basis = l2_normalize(vh[:text_rank].contiguous(), dim=-1)
    return PromptCondition(
        p_norm=l2_normalize(p_norm, dim=0),
        prompt_features=l2_normalize(prompt_features, dim=-1),
        U_basis=U_basis,
        delta_key=delta_key,
        delta_val=delta_val,
        text_rank=text_rank,
    )


def train_one_epoch(
    backbone,
    ksm: KinematicSteeringModuleV3Conditional,
    prompt_cache: dict[str, PromptCondition],
    train_records: list[Record],
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    ksm.train()
    beta = entropy_beta(epoch_idx, args.entropy_beta_max, args.entropy_hold_epochs, args.entropy_decay_epochs)
    loss_vals = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []
    start_time = time.time()
    total_records = len(train_records)
    records_by_class: dict[str, list[Record]] = {}
    for rec in train_records:
        records_by_class.setdefault(rec.class_name, []).append(rec)

    rng = np.random.default_rng(epoch_idx)
    class_order = list(records_by_class.keys())
    rng.shuffle(class_order)
    processed = 0
    next_log = 1000

    for class_name in class_order:
        cond = prompt_cache[class_name]
        class_records = records_by_class[class_name]
        order = rng.permutation(len(class_records))
        for start in range(0, len(order), args.train_batch_size):
            batch_idx = order[start : start + args.train_batch_size]
            batch_records = [class_records[int(i)] for i in batch_idx]
            image_t_cpu, patch_mask = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, args.layer)
            _, patches = patchify_sequence(seq)
            mask = torch.from_numpy(patch_mask.astype(np.int64)).to(device)
            v_out, aux = ksm(patches, cond, return_aux=True)
            loss, _ = compute_v36_loss(
                patches,
                aux,
                cond,
                mask,
                lambda_n=args.lambda_n,
                lambda_smooth=args.lambda_smooth,
                topk_anom_ratio=args.topk_anom_ratio,
                hard_neg_ratio=args.hard_neg_ratio,
            )
            alpha_c = aux["alpha_tensor"].clamp(1e-6, 1.0 - 1e-6)
            l_entropy = (alpha_c * torch.log(alpha_c) + (1.0 - alpha_c) * torch.log(1.0 - alpha_c)).mean()
            loss = loss + beta * l_entropy
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            loss_vals.append(float(loss.item()))
            alpha_vals.append(aux["alpha_mean"])
            gamma_s_vals.append(aux["gamma_simplex_abs"])
            gamma_u_vals.append(aux["gamma_subspace_abs"])
            processed += len(batch_records)
            if processed >= next_log or processed == total_records:
                elapsed = time.time() - start_time
                img_per_sec = float(processed) / max(elapsed, 1e-6)
                print(
                    f"  [epoch {epoch_idx}] "
                    f"{processed}/{total_records} "
                    f"({100.0 * processed / total_records:.1f}%) "
                    f"loss={float(np.mean(loss_vals[-20:])):.6f} "
                    f"img/s={img_per_sec:.2f}"
                )
                next_log += 1000
    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "alpha_mean": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
        "entropy_beta": float(beta),
    }


def evaluate_target_class(
    backbone,
    ksm: KinematicSteeringModuleV3Conditional,
    cond: PromptCondition,
    eval_records: list[Record],
    layer_idx: int,
    topk_ratio: float,
    eval_batch_size: int,
    device: str,
) -> dict[str, float]:
    ksm.eval()
    patch_labels: list[int] = []
    base_prompt_patch_scores: list[float] = []
    ksm_prompt_patch_scores: list[float] = []
    image_labels: list[int] = []
    base_prompt_image_scores: list[float] = []
    ksm_prompt_image_scores: list[float] = []
    alpha_vals: list[float] = []
    gamma_s_vals: list[float] = []
    gamma_u_vals: list[float] = []
    sem_drop_vals: list[float] = []
    with torch.no_grad():
        for start in range(0, len(eval_records), eval_batch_size):
            batch_records = eval_records[start : start + eval_batch_size]
            image_t_cpu, patch_masks = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            cls_tok, patches = patchify_sequence(seq)
            base_final = forward_remaining(backbone, seq, layer_idx)
            out_patches, aux = ksm(patches, cond, return_aux=True)
            out_seq = rebuild_sequence(cls_tok, out_patches)
            out_final = forward_remaining(backbone, out_seq, layer_idx)

            base_prompt = score_promptmax(base_final, cond.p_norm, cond.prompt_features)
            out_prompt = score_promptmax(out_final, cond.p_norm, cond.prompt_features)
            base_norm = l2_normalize(base_final, dim=-1)
            out_norm = l2_normalize(out_final, dim=-1)
            base_sem = (base_norm @ cond.p_norm).mean(dim=-1)
            out_sem = (out_norm @ cond.p_norm).mean(dim=-1)

            alpha_vals.extend(aux["alpha_tensor"].view(-1).detach().cpu().tolist())
            gamma_s_vals.extend([aux["gamma_simplex_abs"]] * len(batch_records))
            gamma_u_vals.extend([aux["gamma_subspace_abs"]] * len(batch_records))
            sem_drop_vals.extend((out_sem - base_sem).detach().cpu().tolist())

            for rec, patch_mask, base_score, out_score in zip(batch_records, patch_masks, base_prompt, out_prompt):
                patch_labels.extend(patch_mask.astype(np.int64).tolist())
                base_prompt_patch_scores.extend(base_score.tolist())
                ksm_prompt_patch_scores.extend(out_score.tolist())
                image_labels.append(rec.label)
                base_prompt_image_scores.append(topk_mean(np.asarray(base_score), topk_ratio))
                ksm_prompt_image_scores.append(topk_mean(np.asarray(out_score), topk_ratio))
    base_patch_auc = safe_auc(patch_labels, base_prompt_patch_scores)
    ksm_patch_auc = safe_auc(patch_labels, ksm_prompt_patch_scores)
    base_image_auc = safe_auc(image_labels, base_prompt_image_scores)
    ksm_image_auc = safe_auc(image_labels, ksm_prompt_image_scores)
    return {
        "base_prompt_patch_auc": base_patch_auc,
        "ksm_prompt_patch_auc": ksm_patch_auc,
        "prompt_patch_auc_delta": ksm_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "ksm_prompt_image_auc": ksm_image_auc,
        "prompt_image_auc_delta": ksm_image_auc - base_image_auc,
        "alpha_mean_eval": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean_eval": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean_eval": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
        "semantic_drop_mean": float(np.mean(sem_drop_vals)) if sem_drop_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for param in backbone.parameters():
        param.requires_grad_(False)

    if args.source_dataset == "mvtec":
        source_class_names = list(args.source_classes)
        train_records = collect_mvtec_train_records(backbone, args)
    else:
        source_class_names = list(RealIAD.CLASS_NAMES)
        train_records = collect_realiad_train_records(backbone, args)

    source_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in source_class_names
    }
    target_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.target_classes
    }

    ksm = KinematicSteeringModuleV3Conditional(
        dim=int(next(iter(source_prompt_cache.values())).prompt_features.shape[1]),
        gamma_init=args.gamma_init,
    ).to(device)
    optimizer = torch.optim.AdamW(ksm.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    print(
        f"[setup] source_dataset={args.source_dataset} "
        f"source_classes={len(source_class_names)} "
        f"source_records={len(train_records)} "
        f"target_classes={len(args.target_classes)} "
        f"layer=L{args.layer}"
    )

    history: list[dict[str, float]] = []
    for epoch in range(1, args.epochs + 1):
        epoch_stats = {
            "epoch": epoch,
            **train_one_epoch(backbone, ksm, source_prompt_cache, train_records, args, optimizer, device, epoch),
        }
        history.append(epoch_stats)
        print(
            f"[epoch {epoch}/{args.epochs}] "
            f"loss={epoch_stats['train_loss']:.6f} "
            f"alpha={epoch_stats['alpha_mean']:.6f} "
            f"gamma_s={epoch_stats['gamma_simplex_abs_mean']:.6f} "
            f"gamma_u={epoch_stats['gamma_subspace_abs_mean']:.6f} "
            f"beta={epoch_stats['entropy_beta']:.6f}"
        )

    rows = []
    for class_name in args.target_classes:
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(
            backbone,
            ksm,
            target_prompt_cache[class_name],
            eval_records,
            args.layer,
            args.topk_ratio,
            args.eval_batch_size,
            device,
        )
        rows.append(
            {
                "class_name": class_name,
                "layer": args.layer,
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "source_dataset": args.source_dataset,
                "img_size": args.img_size,
                "epochs": args.epochs,
                "gamma_init": args.gamma_init,
                "lambda_smooth": args.lambda_smooth,
                "source_train_records": len(train_records),
                "source_classes": len(source_class_names),
                "text_rank": target_prompt_cache[class_name].text_rank,
                **history[-1],
                **eval_stats,
            }
        )

    stem = f"{args.output_tag}_{args.backbone}_L{args.layer}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump(
            {
                "args": vars(args),
                "history": history,
                "rows": rows,
                "source_dataset": args.source_dataset,
                "source_classes": source_class_names,
                "target_classes": args.target_classes,
            },
            f,
            indent=2,
        )
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
