#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results" / "source_readout_extra_baselines_20260506"
OUT_DIR = ROOT / "supp_fig"
CSV_OUT = OUT_DIR / "source_readout_extra_controls_20260506.csv"
TEX_OUT = OUT_DIR / "source_readout_extra_controls_20260506.tex"


def pct(x: float) -> float:
    return 100.0 * x if abs(x) <= 1.5 else x


def fmt(x: float) -> str:
    if math.isnan(x):
        return "--"
    return f"{x:+.1f}"


def short_transfer(name: str) -> str:
    if "visa2mvtec" in name:
        return r"V$\rightarrow$M"
    if "mvtec2visa" in name:
        return r"M$\rightarrow$V"
    if "mvtec2mpdd" in name:
        return r"M$\rightarrow$P"
    if "mvtec2btad" in name:
        return r"M$\rightarrow$B"
    if "visa2mpdd" in name:
        return r"V$\rightarrow$P"
    if "visa2btad" in name:
        return r"V$\rightarrow$B"
    return name


def readout_name(name: str) -> str:
    if "support_affine" in name:
        return "support-affine"
    if "mlp_rank" in name:
        return "MLP-rank"
    return "source readout"


def host_name(name: str) -> str:
    if name.startswith("faprompt_"):
        return "FAPrompt"
    if name.startswith("aaclip_"):
        return "AA-CLIP"
    if name.startswith("adaclip_"):
        return "AdaCLIP"
    if name.startswith("adaptclip_"):
        return "AdaptCLIP"
    return "Unknown"


def first_key(d: dict, prefix: str) -> str | None:
    keys = sorted(k for k in d if k.startswith(prefix))
    return keys[0] if keys else None


def triplet(blob: dict, pro_key: str) -> tuple[float, float, float]:
    return (
        pct(float(blob.get("pixel_auc", float("nan")))),
        pct(float(blob.get(pro_key, blob.get("pixel_aupro", float("nan"))))),
        pct(float(blob.get("pixel_ap", float("nan")))),
    )


def deltas(cand: tuple[float, float, float], base: tuple[float, float, float]) -> tuple[float, float, float, float]:
    d_auc = cand[0] - base[0]
    d_pro = cand[1] - base[1]
    d_ap = cand[2] - base[2]
    return d_auc, d_pro, d_ap, 0.5 * (d_pro + d_ap)


def parse_one(path: Path) -> dict | None:
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError:
        # Failed or still-writing jobs can leave partial summaries. Exclude them
        # so the table always reflects completed, parseable settings only.
        return None
    name = path.parent.name
    host = host_name(name)
    if host == "Unknown":
        return None

    if host in {"AdaCLIP", "AdaptCLIP"}:
        if int(data.get("summary", {}).get("max_eval_images", 0) or 0) > 0:
            return None
        mean_rows = {row.get("mode"): row for row in data.get("rows", []) if row.get("target_label") == "mean"}
        if host == "AdaCLIP":
            base_mode = "baseline_txt"
            replace_mode = "scalar_replace"
            residual_mode = "scalar_residual"
            cted_mode = "ted_calibrated"
        else:
            base_mode = "baseline_txt"
            replace_mode = "scalar_replace_vl"
            residual_mode = "scalar_residual_vl"
            cted_mode = "ted_calibrated_vl"
        if any(mode not in mean_rows for mode in [base_mode, replace_mode, residual_mode, cted_mode]):
            return None

        def row_triplet(row: dict) -> tuple[float, float, float]:
            return (
                pct(float(row.get("pixel_auroc", float("nan")))),
                pct(float(row.get("pixel_aupro", float("nan")))),
                pct(float(row.get("pixel_ap", float("nan")))),
            )

        base = row_triplet(mean_rows[base_mode])
        replace = deltas(row_triplet(mean_rows[replace_mode]), base)
        residual = deltas(row_triplet(mean_rows[residual_mode]), base)
        cted = deltas(row_triplet(mean_rows[cted_mode]), base)
        return {
            "host": host,
            "transfer": short_transfer(name),
            "readout": readout_name(name),
            "setting": name,
            "replace_delta_loc": replace[3],
            "residual_delta_loc": residual[3],
            "cted_delta_loc": cted[3],
            "replace_delta_pro": replace[1],
            "replace_delta_ap": replace[2],
            "residual_delta_pro": residual[1],
            "residual_delta_ap": residual[2],
            "cted_delta_pro": cted[1],
            "cted_delta_ap": cted[2],
        }

    mean = data.get("mean", {})
    if host == "FAPrompt":
        base_blob = mean.get("baseline_official")
        candidates = mean.get("parallel", {})
        pro_key = "pixel_aupro"
        cted_prefix = "branch_calibrated_alpha_"
    else:
        base_blob = mean.get("baseline")
        candidates = mean.get("candidates", {})
        pro_key = "pixel_pro"
        cted_prefix = "prescore_calibrated_alpha_"

    replace_key = first_key(candidates, "plugin_replace_alpha_")
    residual_key = first_key(candidates, "plugin_residual_alpha_")
    cted_key = first_key(candidates, cted_prefix)
    if not base_blob or not replace_key or not residual_key or not cted_key:
        return None

    base = triplet(base_blob, pro_key)
    replace = deltas(triplet(candidates[replace_key], pro_key), base)
    residual = deltas(triplet(candidates[residual_key], pro_key), base)
    cted = deltas(triplet(candidates[cted_key], pro_key), base)
    return {
        "host": host,
        "transfer": short_transfer(name),
        "readout": readout_name(name),
        "setting": name,
        "replace_delta_loc": replace[3],
        "residual_delta_loc": residual[3],
        "cted_delta_loc": cted[3],
        "replace_delta_pro": replace[1],
        "replace_delta_ap": replace[2],
        "residual_delta_pro": residual[1],
        "residual_delta_ap": residual[2],
        "cted_delta_pro": cted[1],
        "cted_delta_ap": cted[2],
    }


def write_csv(rows: list[dict]) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fields = [
        "host",
        "transfer",
        "readout",
        "setting",
        "replace_delta_loc",
        "residual_delta_loc",
        "cted_delta_loc",
        "replace_delta_pro",
        "replace_delta_ap",
        "residual_delta_pro",
        "residual_delta_ap",
        "cted_delta_pro",
        "cted_delta_ap",
    ]
    with CSV_OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_tex(rows: list[dict]) -> None:
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        grouped[(row["host"], row["readout"])].append(row)

    compact_rows = []
    for (host, readout), sub in sorted(grouped.items()):
        compact_rows.append(
            {
                "host": host,
                "readout": readout,
                "n": len(sub),
                "replace_delta_loc": sum(float(r["replace_delta_loc"]) for r in sub) / len(sub),
                "residual_delta_loc": sum(float(r["residual_delta_loc"]) for r in sub) / len(sub),
                "cted_delta_loc": sum(float(r["cted_delta_loc"]) for r in sub) / len(sub),
            }
        )
    if rows:
        compact_rows.append(
            {
                "host": "Mean",
                "readout": "all controls",
                "n": len(rows),
                "replace_delta_loc": sum(float(r["replace_delta_loc"]) for r in rows) / len(rows),
                "residual_delta_loc": sum(float(r["residual_delta_loc"]) for r in rows) / len(rows),
                "cted_delta_loc": sum(float(r["cted_delta_loc"]) for r in rows) / len(rows),
            }
        )

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Additional source-supervised readout controls.",
        r"All controls use the same source defect and hard-FP banks as C-TED, but replace the evidence comparison with a directly learned source readout.",
        r"Replace uses the learned readout as the local anomaly map, while Residual adds it to the host map.",
        r"Rows average completed transfer settings for each host/readout control.",
        r"Values are $\Delta$Loc, the mean of $\Delta$PRO and $\Delta$AP over the host baseline.",
        r"}",
        r"\label{tab:supp_source_readout_extra_controls}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.0pt}",
        r"\renewcommand{\arraystretch}{1.05}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}llcccc}",
        r"\toprule",
        r"Host & Readout control & $n$ & Replace & Residual & C-TED \\",
        r"\midrule",
    ]
    for row in compact_rows:
        lines.append(
            f"{row['host']} & {row['readout']} & {row['n']} & "
            f"{fmt(row['replace_delta_loc'])} & {fmt(row['residual_delta_loc'])} & "
            f"\\textbf{{{fmt(row['cted_delta_loc'])}}} \\\\"
        )
    lines += [
        r"\bottomrule",
        r"\end{tabular*}",
        r"\end{table}",
        "",
    ]
    TEX_OUT.write_text("\n".join(lines))


def main() -> int:
    rows = []
    for path in sorted(RESULTS.glob("*/summary.json")):
        row = parse_one(path)
        if row is not None:
            rows.append(row)
    rows.sort(key=lambda r: (r["host"], r["readout"], r["transfer"]))
    write_csv(rows)
    write_tex(rows)
    print(json.dumps({"rows": len(rows), "csv": str(CSV_OUT.relative_to(ROOT)), "tex": str(TEX_OUT.relative_to(ROOT))}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
