from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["fryum", "pcb1"])
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240", "ViT-L-14:laion400m_e32:224"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--target_layer", type=int, default=12)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_global_consistency_oracle")
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def build_recent_general_prompt_bank(class_name: str) -> tuple[str, list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt = (
        f"a close-up inspection photo of a {cls} that is intact, complete, clean, "
        f"and free of visible damage, defects, cracks, missing parts, contamination, "
        f"deformation, discoloration, or abnormal surface patterns."
    )
    abnormal_prompts = [
        (
            f"a close-up inspection photo of a {cls} showing visible damage, cracks, holes, "
            f"broken regions, missing material, or structural defects."
        ),
        (
            f"a close-up inspection photo of a {cls} with scratches, dents, tears, surface flaws, "
            f"contamination, stains, discoloration, or abnormal marks."
        ),
        (
            f"a close-up inspection photo of a {cls} whose shape, texture, edge, or surface pattern "
            f"looks irregular, deformed, incomplete, or visibly defective."
        ),
        (
            f"a detailed inspection photo of a {cls} with missing parts, broken edges, foreign material, "
            f"local damage, or manufacturing defects."
        ),
        (
            f"a detailed inspection photo of a {cls} that appears damaged, defective, incomplete, "
            f"deformed, contaminated, or inconsistent with a normal intact item."
        ),
        (
            f"a close-up inspection photo of a {cls} with visible surface damage, structural breakage, "
            f"missing components, contamination, or abnormal appearance."
        ),
    ]
    return normal_prompt, abnormal_prompts


def encode_text_features(backbone, prompts: list[str]) -> torch.Tensor:
    device = backbone.device
    text = backbone.tokenizer(prompts).to(device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = l2_normalize(text_features, dim=-1)
    proj = getattr(backbone.visual, "proj", None)
    if proj is not None:
        text_features = (proj.detach().float().to(text_features.device) @ text_features.T).T
        text_features = l2_normalize(text_features, dim=-1)
    return text_features


def prepare_text_bank(backbone, text_prompts: list[str], p_norm: torch.Tensor) -> torch.Tensor:
    p_anom_raw = encode_text_features(backbone, text_prompts)
    delta_p = p_anom_raw - p_norm.unsqueeze(0)
    return l2_normalize(delta_p, dim=-1)


def extract_residual(v_test: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    v_test = l2_normalize(v_test, dim=-1)
    p_norm = l2_normalize(p_norm, dim=0)
    return v_test - (v_test @ p_norm).unsqueeze(1) * p_norm.unsqueeze(0)


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def collect_test_tokens(backbone, class_name: str, target_layer: int, args: argparse.Namespace, device: str) -> list[dict]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    side_h, side_w = backbone.grid_size
    records: list[dict] = []
    for idx, rec in enumerate(ds.records):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens = backbone.extract_layer_patch_tokens(image_t, target_layers=[target_layer])[target_layer][0]
        records.append(
            {
                "index": idx,
                "name": name,
                "img_type": img_type,
                "label": int(label != 0),
                "patch_tokens": l2_normalize(tokens.float(), dim=-1).cpu(),
                "patch_mask": to_patch_mask(mask_np, (side_h, side_w), device),
            }
        )
    return records


def score_static(r_test: torch.Tensor, Delta_P: torch.Tensor) -> np.ndarray:
    delta_static = l2_normalize(Delta_P.mean(dim=0), dim=0)
    return (r_test @ delta_static).cpu().numpy()


def score_local_best(r_test: torch.Tensor, Delta_P: torch.Tensor) -> tuple[np.ndarray, np.ndarray]:
    scores_all = r_test @ Delta_P.T
    score_local = torch.max(scores_all, dim=-1).values
    prompt_idx = torch.argmax(scores_all, dim=-1)
    return score_local.cpu().numpy(), prompt_idx.cpu().numpy()


def score_global_best(r_test: torch.Tensor, Delta_P: torch.Tensor) -> tuple[np.ndarray, int]:
    scores_all = r_test @ Delta_P.T
    prompt_best = int(torch.argmax(torch.max(scores_all, dim=0).values).item())
    score_global = scores_all[:, prompt_best]
    return score_global.cpu().numpy(), prompt_best


def evaluate_class(backbone, class_name: str, args: argparse.Namespace, device: str) -> tuple[list[dict], dict]:
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    p_norm = encode_text_features(backbone, [normal_prompt])[0].cpu()
    Delta_P = prepare_text_bank(backbone, abnormal_prompts, p_norm.to(backbone.device)).cpu()
    records = collect_test_tokens(backbone, class_name, args.target_layer, args, device)

    patch_labels: list[int] = []
    image_labels: list[int] = []
    static_patch_scores: list[float] = []
    local_patch_scores: list[float] = []
    global_patch_scores: list[float] = []
    static_image_scores: list[float] = []
    local_image_scores: list[float] = []
    global_image_scores: list[float] = []
    global_prompt_counter: Counter[int] = Counter()

    for rec in records:
        labels_patch = rec["patch_mask"].astype(np.int64)
        r_test = extract_residual(rec["patch_tokens"], p_norm)
        static_scores = score_static(r_test, Delta_P)
        local_scores, _ = score_local_best(r_test, Delta_P)
        global_scores, global_prompt_idx = score_global_best(r_test, Delta_P)
        global_prompt_counter[global_prompt_idx] += 1

        patch_labels.extend(labels_patch.tolist())
        static_patch_scores.extend(static_scores.tolist())
        local_patch_scores.extend(local_scores.tolist())
        global_patch_scores.extend(global_scores.tolist())

        image_labels.append(int(rec["label"]))
        static_image_scores.append(topk_mean(static_scores, args.topk_ratio))
        local_image_scores.append(topk_mean(local_scores, args.topk_ratio))
        global_image_scores.append(topk_mean(global_scores, args.topk_ratio))

    static_patch_auc = safe_auc(patch_labels, static_patch_scores)
    local_patch_auc = safe_auc(patch_labels, local_patch_scores)
    global_patch_auc = safe_auc(patch_labels, global_patch_scores)
    static_image_auc = safe_auc(image_labels, static_image_scores)
    local_image_auc = safe_auc(image_labels, local_image_scores)
    global_image_auc = safe_auc(image_labels, global_image_scores)

    rows = [
        {
            "class_name": class_name,
            "method": "static",
            "num_prompts": int(Delta_P.shape[0]),
            "patch_auc": static_patch_auc,
            "image_auc": static_image_auc,
        },
        {
            "class_name": class_name,
            "method": "local_best",
            "num_prompts": int(Delta_P.shape[0]),
            "patch_auc": local_patch_auc,
            "image_auc": local_image_auc,
            "patch_auc_delta_vs_static": local_patch_auc - static_patch_auc,
            "image_auc_delta_vs_static": local_image_auc - static_image_auc,
        },
        {
            "class_name": class_name,
            "method": "global_best",
            "num_prompts": int(Delta_P.shape[0]),
            "patch_auc": global_patch_auc,
            "image_auc": global_image_auc,
            "patch_auc_delta_vs_static": global_patch_auc - static_patch_auc,
            "image_auc_delta_vs_static": global_image_auc - static_image_auc,
            "patch_auc_delta_vs_local": global_patch_auc - local_patch_auc,
            "image_auc_delta_vs_local": global_image_auc - local_image_auc,
        },
    ]
    detail = {
        "class_name": class_name,
        "num_images": len(records),
        "num_prompts": int(Delta_P.shape[0]),
        "global_prompt_hist": dict(sorted(global_prompt_counter.items())),
        "abnormal_prompts": abnormal_prompts,
    }
    return rows, detail


def plot_image_auc(rows: list[dict[str, float | str]], out_dir: Path, stem: str) -> None:
    backbones = sorted({str(r["backbone"]) for r in rows})
    classes = sorted({str(r["class_name"]) for r in rows})
    methods = ["static", "local_best", "global_best"]
    for backbone in backbones:
        subset = [r for r in rows if str(r["backbone"]) == backbone]
        plt.figure(figsize=(7.5, 4.5))
        x = np.arange(len(classes))
        width = 0.24
        for j, method in enumerate(methods):
            vals = []
            for cls in classes:
                row = next(r for r in subset if str(r["class_name"]) == cls and str(r["method"]) == method)
                vals.append(float(row["image_auc"]))
            plt.bar(x + (j - 1) * width, vals, width=width, label=method)
        plt.xticks(x, classes, rotation=20)
        plt.ylabel("Image AUC")
        plt.title(f"Global Consistency Oracle | {backbone}")
        plt.grid(axis="y", alpha=0.25)
        plt.legend()
        plt.tight_layout()
        safe_name = backbone.replace("/", "_").replace(":", "_")
        plt.savefig(out_dir / f"{stem}_{safe_name}_image_auc.png", dpi=200)
        plt.close()


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    rows: list[dict[str, float | str]] = []
    details: list[dict] = []

    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        for class_name in args.class_names:
            class_rows, detail = evaluate_class(backbone, class_name, args, device)
            for row in class_rows:
                row["backbone"] = backbone_name
                row["pretrained"] = pretrained_name
                row["img_size"] = img_size_i
                rows.append(row)
            detail["backbone"] = backbone_name
            detail["pretrained"] = pretrained_name
            detail["img_size"] = img_size_i
            details.append(detail)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{'-'.join(args.class_names)}_{'-'.join(spec.split(':')[0] for spec in args.backbones)}_L{args.target_layer}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"

    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    with json_path.open("w") as f:
        json.dump({"rows": rows, "details": details}, f, indent=2)

    plot_image_auc(rows, out_dir, stem)
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
