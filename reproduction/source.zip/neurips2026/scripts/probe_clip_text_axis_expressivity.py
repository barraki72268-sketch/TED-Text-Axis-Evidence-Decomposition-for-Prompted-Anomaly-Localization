from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
    build_text_workspace,
    encode_text_features,
    reconstruct_optimal_text_axis,
)
from neurips2026.scripts.probe_clip_text_axis_reconstruction_eval import (  # noqa: E402
    extract_visual_subspace,
    load_class_settings,
    collect_test_tokens,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Signed vs simplex expressivity check for reconstructed text axis.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["capsules", "fryum"])
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240", "ViT-L-14:laion400m_e32:224"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument(
        "--class_summary_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "clip_kin_split_allvisa_analysis" / "class_best_summary.csv"),
    )
    parser.add_argument("--max_fit_anomaly_patches", type=int, default=4096)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_text_axis_expressivity")
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def fit_signed(delta_bank: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    # delta_bank: [m, D], target: [D]
    weights, *_ = np.linalg.lstsq(delta_bank.T, target, rcond=None)
    recon = delta_bank.T @ weights
    return weights.astype(np.float64), recon.astype(np.float64)


def fit_simplex(delta_bank: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray, bool]:
    m = delta_bank.shape[0]
    A = delta_bank.T.astype(np.float64)
    b = target.astype(np.float64)

    def objective(w: np.ndarray) -> float:
        r = A @ w - b
        return 0.5 * float(r @ r)

    def grad(w: np.ndarray) -> np.ndarray:
        r = A @ w - b
        return A.T @ r

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0, "jac": lambda w: np.ones_like(w)}]
    bounds = [(0.0, 1.0) for _ in range(m)]
    x0 = np.full(m, 1.0 / m, dtype=np.float64)
    res = minimize(objective, x0=x0, jac=grad, method="SLSQP", bounds=bounds, constraints=constraints, options={"maxiter": 1000, "ftol": 1e-12})
    w = res.x.astype(np.float64)
    recon = A @ w
    return w, recon.astype(np.float64), bool(res.success)


def fit_metrics(recon: np.ndarray, target: np.ndarray) -> dict[str, float]:
    t = target.astype(np.float64)
    r = recon.astype(np.float64)
    t_norm = np.linalg.norm(t) + 1e-12
    r_norm = np.linalg.norm(r) + 1e-12
    return {
        "cosine": float(np.dot(r, t) / (r_norm * t_norm)),
        "l2_error": float(np.linalg.norm(r - t)),
        "rel_error": float(np.linalg.norm(r - t) / t_norm),
        "norm_ratio": float(r_norm / t_norm),
    }


def support_stats(weights: np.ndarray, topk: int = 3) -> dict[str, float | list[int]]:
    abs_w = np.abs(weights)
    order = np.argsort(-abs_w)
    return {
        "top_idx": [int(i) for i in order[:topk]],
        "top_abs_mass": float(abs_w[order[:topk]].sum()),
        "num_nonzero_gt1e-3": int((abs_w > 1e-3).sum()),
    }


def evaluate_one(backbone, class_name: str, class_settings: dict[str, dict[str, int | str]], args: argparse.Namespace, device: str) -> dict:
    if class_name not in class_settings:
        raise RuntimeError(f"Missing class settings for {class_name}")
    best_layer = int(class_settings[class_name]["best_layer"])
    best_k = int(class_settings[class_name]["best_k"])

    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0]
    U_text, delta_bank_t = build_text_workspace(backbone, backbone.tokenizer, abnormal_prompts, p_norm)
    records = collect_test_tokens(backbone, class_name, best_layer, args, device)
    anom_indices = [i for i, rec in enumerate(records) if int(rec["label"]) == 1]
    V_anom = extract_visual_subspace(records, anom_indices, p_norm.cpu(), best_k, args.max_fit_anomaly_patches)
    delta_p_recon, _, singulars = reconstruct_optimal_text_axis(U_text.to(V_anom.device), V_anom)

    delta_bank = delta_bank_t.cpu().numpy().astype(np.float64)
    target = delta_p_recon.cpu().numpy().astype(np.float64)

    signed_w, signed_recon = fit_signed(delta_bank, target)
    simplex_w, simplex_recon, simplex_ok = fit_simplex(delta_bank, target)

    signed_metrics = fit_metrics(signed_recon, target)
    simplex_metrics = fit_metrics(simplex_recon, target)
    simplex_projection_norm = float(np.linalg.norm(simplex_recon))

    return {
        "class_name": class_name,
        "best_layer": best_layer,
        "best_k": best_k,
        "num_prompts": int(delta_bank.shape[0]),
        "sigma1": float(singulars[0].item()) if singulars.numel() else float("nan"),
        "signed_success": 1,
        "simplex_success": int(simplex_ok),
        "signed_cosine": signed_metrics["cosine"],
        "signed_rel_error": signed_metrics["rel_error"],
        "signed_l2_error": signed_metrics["l2_error"],
        "signed_norm_ratio": signed_metrics["norm_ratio"],
        "simplex_cosine": simplex_metrics["cosine"],
        "simplex_rel_error": simplex_metrics["rel_error"],
        "simplex_l2_error": simplex_metrics["l2_error"],
        "simplex_norm_ratio": simplex_metrics["norm_ratio"],
        "simplex_projection_norm": simplex_projection_norm,
        "expressivity_gap_rel_error": simplex_metrics["rel_error"] - signed_metrics["rel_error"],
        "expressivity_gap_cosine": signed_metrics["cosine"] - simplex_metrics["cosine"],
        "signed_top_idx": json.dumps(support_stats(signed_w)["top_idx"]),
        "signed_top_abs_mass": float(support_stats(signed_w)["top_abs_mass"]),
        "signed_num_nonzero_gt1e-3": int(support_stats(signed_w)["num_nonzero_gt1e-3"]),
        "simplex_top_idx": json.dumps(support_stats(simplex_w)["top_idx"]),
        "simplex_top_abs_mass": float(support_stats(simplex_w)["top_abs_mass"]),
        "simplex_num_nonzero_gt1e-3": int(support_stats(simplex_w)["num_nonzero_gt1e-3"]),
        "signed_weights": json.dumps([float(x) for x in signed_w.tolist()]),
        "simplex_weights": json.dumps([float(x) for x in simplex_w.tolist()]),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    class_settings = load_class_settings(args.class_summary_csv)
    rows: list[dict] = []
    skipped: list[dict] = []

    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        for class_name in args.class_names:
            try:
                row = evaluate_one(backbone, class_name, class_settings, args, device)
                row["backbone"] = backbone_name
                row["pretrained"] = pretrained_name
                row["img_size"] = img_size_i
                rows.append(row)
            except RuntimeError as exc:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": str(exc)})

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{'-'.join(args.class_names)}_{'-'.join(spec.split(':')[0] for spec in args.backbones)}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"

    fieldnames = sorted({k for row in rows for k in row.keys()}) if rows else []
    with csv_path.open("w", newline="") as f:
        if fieldnames:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"rows": rows, "skipped": skipped}, f, indent=2)

    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
