#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[2]
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from official_parallel_test_faprompt import (  # noqa: E402
    PRESET_CONFIGS,
    MetaDataset,
    build_model,
    compute_faprompt_outputs,
    downsample_mask_to_patch,
    get_or_collect_source_banks,
    learned_text_pair,
    logmeanexp_negative_sqdist_1d,
)


CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)


def zscore_1d(x: torch.Tensor) -> torch.Tensor:
    return (x - x.mean()) / x.std().clamp_min(1e-6)


def top_indices(scores: torch.Tensor, frac: float, cap: int) -> torch.Tensor:
    k = max(1, int(math.ceil(scores.numel() * frac)))
    k = min(k, cap, scores.numel())
    return torch.topk(scores, k=k, largest=True).indices


def denormalize_image(image_t: torch.Tensor) -> np.ndarray:
    image = image_t.detach().cpu().float().numpy().transpose(1, 2, 0)
    image = np.clip((image * CLIP_STD + CLIP_MEAN) * 255.0, 0, 255).astype(np.uint8)
    return image


def crop_center(image: np.ndarray, cy: int, cx: int, size: int) -> np.ndarray:
    h, w = image.shape[:2]
    half = size // 2
    y0 = max(0, min(h - size, cy - half))
    x0 = max(0, min(w - size, cx - half))
    y1 = min(h, y0 + size)
    x1 = min(w, x0 + size)
    crop = image[y0:y1, x0:x1]
    if crop.shape[0] == size and crop.shape[1] == size:
        return crop
    out = np.zeros((size, size, 3), dtype=np.uint8)
    out[: crop.shape[0], : crop.shape[1]] = crop
    return out


def draw_box(image: np.ndarray, cy: int, cx: int, size: int, color: tuple[int, int, int]) -> np.ndarray:
    out = Image.fromarray(image.copy())
    draw = ImageDraw.Draw(out)
    half = size // 2
    x0 = max(0, cx - half)
    y0 = max(0, cy - half)
    x1 = min(image.shape[1] - 1, cx + half)
    y1 = min(image.shape[0] - 1, cy + half)
    for off in range(4):
        draw.rectangle([x0 - off, y0 - off, x1 + off, y1 + off], outline=color)
    return np.asarray(out)


def pick_pair(records: list[dict]) -> tuple[dict, dict, dict]:
    pos = [r for r in records if r["label"] == 1]
    neg = [r for r in records if r["label"] == 0]
    pos_b = np.asarray([r["baseline"] for r in pos], dtype=np.float32)
    neg_b = np.asarray([r["baseline"] for r in neg], dtype=np.float32)
    lo = max(float(np.quantile(pos_b, 0.25)), float(np.quantile(neg_b, 0.25)))
    hi = min(float(np.quantile(pos_b, 0.75)), float(np.quantile(neg_b, 0.75)))
    if hi <= lo:
        lo = max(float(np.quantile(pos_b, 0.15)), float(np.quantile(neg_b, 0.15)))
        hi = min(float(np.quantile(pos_b, 0.85)), float(np.quantile(neg_b, 0.85)))
    pos_band = [r for r in pos if lo <= r["baseline"] <= hi]
    neg_band = [r for r in neg if lo <= r["baseline"] <= hi]
    if not pos_band:
        center = 0.5 * (lo + hi)
        pos_band = sorted(pos, key=lambda r: abs(r["baseline"] - center))[:16]
    if not neg_band:
        center = 0.5 * (lo + hi)
        neg_band = sorted(neg, key=lambda r: abs(r["baseline"] - center))[:32]

    best = None
    best_obj = -1e9
    for d in pos_band:
        for h in neg_band:
            base_gap = abs(d["baseline"] - h["baseline"])
            ours_gain = d["fused"] - h["fused"]
            baseline_wrong_bonus = 0.25 if d["baseline"] <= h["baseline"] else 0.0
            obj = ours_gain - 2.5 * base_gap + baseline_wrong_bonus
            if obj > best_obj:
                best = (d, h)
                best_obj = obj
    assert best is not None
    info = {
        "overlap_band_low": lo,
        "overlap_band_high": hi,
        "objective": float(best_obj),
        "baseline_gap_abs": float(abs(best[0]["baseline"] - best[1]["baseline"])),
        "ours_gap": float(best[0]["fused"] - best[1]["fused"]),
    }
    return best[0], best[1], info


def save_trace_images(out_dir: Path, selected: dict, prefix: str, crop_size: int) -> dict:
    image = selected.pop("_image")
    cy = int(selected["cy"])
    cx = int(selected["cx"])
    color = (216, 74, 47) if selected["label"] == 1 else (40, 120, 167)
    boxed = draw_box(image, cy, cx, crop_size, color)
    crop = crop_center(image, cy, cx, crop_size)
    full_path = out_dir / f"{prefix}_full_box.png"
    crop_path = out_dir / f"{prefix}_crop.png"
    Image.fromarray(boxed).save(full_path)
    Image.fromarray(crop).save(crop_path)
    selected["full_box_path"] = str(full_path)
    selected["crop_path"] = str(crop_path)
    return selected


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="visa2mvtec")
    ap.add_argument("--class_name", default="cable")
    ap.add_argument("--save_dir", default=str(ROOT / "neurips2026" / "results" / "faprompt_patch_trace_visa2mvtec_cable_vitb_v1"))
    ap.add_argument("--device", default="cuda:1" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--model_name", default="ViT-B-16-plus-240")
    ap.add_argument("--prompt_load_mode", default="project_crop", choices=["strict", "project_crop"])
    ap.add_argument("--features_list", type=int, nargs="+", default=[6, 12])
    ap.add_argument("--image_size", type=int, default=518)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--depth", type=int, default=9)
    ap.add_argument("--n_ctx", type=int, default=12)
    ap.add_argument("--t_n_ctx", type=int, default=4)
    ap.add_argument("--dpam_layer", type=int, default=20)
    ap.add_argument("--sigma", type=int, default=10)
    ap.add_argument("--dap_token_mode", default="official_firstk", choices=["topk", "official_firstk"])
    ap.add_argument("--candidate_topk_frac", type=float, default=0.01)
    ap.add_argument("--max_candidates_per_image", type=int, default=16)
    ap.add_argument("--alpha", type=float, default=0.25)
    ap.add_argument("--tau", type=float, default=0.1)
    ap.add_argument("--fp_weight", type=float, default=1.0)
    ap.add_argument("--bank_chunk", type=int, default=2048)
    ap.add_argument("--max_fp_per_class", type=int, default=512)
    ap.add_argument("--max_defect_per_class", type=int, default=512)
    ap.add_argument("--max_fp_total", type=int, default=4096)
    ap.add_argument("--max_defect_total", type=int, default=4096)
    ap.add_argument("--normal_topk_frac", type=float, default=0.01)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--crop_size", type=int, default=112)
    args = ap.parse_args()

    out_dir = Path(args.save_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = dict(PRESET_CONFIGS[args.preset])
    device = torch.device(args.device)
    model, prompt_learner, prompt_load_info = build_model(
        device=device,
        checkpoint_path=cfg["checkpoint_path"],
        model_name=args.model_name,
        prompt_load_mode=args.prompt_load_mode,
        dpam_layer=args.dpam_layer,
        depth=args.depth,
        n_ctx=args.n_ctx,
        t_n_ctx=args.t_n_ctx,
    )
    banks = get_or_collect_source_banks(
        model=model,
        prompt_learner=prompt_learner,
        preset=args.preset,
        source_root=cfg["source_root"],
        checkpoint_path=cfg["checkpoint_path"],
        model_name=args.model_name,
        prompt_load_mode=args.prompt_load_mode,
        cache_dir=ROOT / "neurips2026" / "results" / "bank_cache",
        image_size=args.image_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=device,
        features_list=args.features_list,
        sigma=args.sigma,
        dap_token_mode=args.dap_token_mode,
        dpam_layer=args.dpam_layer,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_fp_total=args.max_fp_total,
        max_defect_total=args.max_defect_total,
        normal_topk_frac=args.normal_topk_frac,
        seed=args.seed,
        force_rebuild_bank=False,
    )
    base_text_pair = learned_text_pair(model, prompt_learner)
    axis = F.normalize(base_text_pair[1] - base_text_pair[0], dim=0)
    fp_proj = banks["fp"].to(device) @ axis
    defect_proj = banks["defect"].to(device) @ axis

    ds = MetaDataset(cfg["target_root"], args.image_size, split="test", class_name=args.class_name)
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=torch.cuda.is_available())
    records: list[dict] = []
    labels: list[int] = []
    baseline_scores: list[float] = []
    residual_scores: list[float] = []
    fused_scores: list[float] = []
    sample_id = 0

    with torch.no_grad():
        for batch in dl:
            image = batch["image"].to(device)
            mask = batch["mask"].to(device)
            label = batch["label"].cpu().numpy().astype(np.int64)
            out = compute_faprompt_outputs(
                model,
                prompt_learner,
                image,
                args.features_list,
                args.image_size,
                args.sigma,
                args.dap_token_mode,
                args.dpam_layer,
                base_text_pair,
            )
            tokens = out["patch_tokens"]
            baseline = out["token_score"]
            q = tokens @ axis
            q_def = logmeanexp_negative_sqdist_1d(q, defect_proj, tau=args.tau, chunk=args.bank_chunk)
            q_fp = logmeanexp_negative_sqdist_1d(q, fp_proj, tau=args.tau, chunk=args.bank_chunk)
            residual = q_def - args.fp_weight * q_fp
            side = int(round(math.sqrt(tokens.shape[1])))
            patch_mask = downsample_mask_to_patch(mask, side)
            cell = float(args.image_size) / float(side)

            for bi in range(tokens.shape[0]):
                y = int(label[bi])
                if y == 0:
                    idx = top_indices(baseline[bi], args.candidate_topk_frac, args.max_candidates_per_image)
                else:
                    pos_idx = torch.nonzero(patch_mask[bi], as_tuple=False).flatten()
                    if pos_idx.numel() == 0:
                        sample_id += 1
                        continue
                    idx_local = top_indices(baseline[bi, pos_idx], args.candidate_topk_frac, args.max_candidates_per_image)
                    idx = pos_idx[idx_local]
                b = baseline[bi, idx].detach().float()
                r = residual[bi, idx].detach().float()
                f = zscore_1d(b) + args.alpha * zscore_1d(r) if idx.numel() > 1 else b + args.alpha * r
                image_np = denormalize_image(batch["image"][bi])
                for local_j, patch_idx_t in enumerate(idx):
                    patch_idx = int(patch_idx_t.item())
                    row = patch_idx // side
                    col = patch_idx % side
                    cy = int(round((row + 0.5) * cell))
                    cx = int(round((col + 0.5) * cell))
                    rec = {
                        "record_id": len(records),
                        "sample_id": int(sample_id),
                        "label": y,
                        "label_name": "defect" if y == 1 else "hard_normal",
                        "class_name": args.class_name,
                        "img_path": str(batch["img_path"][bi]),
                        "patch_idx": patch_idx,
                        "patch_row": int(row),
                        "patch_col": int(col),
                        "patch_side": int(side),
                        "cy": cy,
                        "cx": cx,
                        "baseline": float(b[local_j].item()),
                        "residual": float(r[local_j].item()),
                        "fused": float(f[local_j].item()),
                        "_image": image_np,
                    }
                    records.append(rec)
                    labels.append(y)
                    baseline_scores.append(rec["baseline"])
                    residual_scores.append(rec["residual"])
                    fused_scores.append(rec["fused"])
                sample_id += 1
            print(json.dumps({"stage": "batch_done", "records": len(records)}), flush=True)

    defect, hard, pair_info = pick_pair(records)
    defect = save_trace_images(out_dir, defect, "defect", args.crop_size)
    hard = save_trace_images(out_dir, hard, "hard_normal", args.crop_size)
    for rec in records:
        rec.pop("_image", None)

    payload = {
        "preset": args.preset,
        "class_name": args.class_name,
        "source_dataset": cfg["source_dataset"],
        "target_dataset": cfg["target_dataset"],
        "target_root": cfg["target_root"],
        "model_name": args.model_name,
        "prompt_load_mode": args.prompt_load_mode,
        "prompt_load_info": prompt_load_info,
        "features_list": args.features_list,
        "image_size": args.image_size,
        "dap_token_mode": args.dap_token_mode,
        "dpam_layer": args.dpam_layer,
        "alpha": args.alpha,
        "tau": args.tau,
        "fp_weight": args.fp_weight,
        "num_records": len(records),
        "pair_info": pair_info,
        "selected": {
            "defect": defect,
            "hard_normal": hard,
        },
    }
    np.savez_compressed(
        out_dir / "scores_with_trace.npz",
        labels=np.asarray(labels, dtype=np.int64),
        baseline=np.asarray(baseline_scores, dtype=np.float32),
        residual=np.asarray(residual_scores, dtype=np.float32),
        fused=np.asarray(fused_scores, dtype=np.float32),
    )
    (out_dir / "records.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    (out_dir / "selected_pair.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"stage": "done", "save_dir": str(out_dir), "selected": payload["selected"], "pair_info": pair_info}, indent=2), flush=True)


if __name__ == "__main__":
    main()
