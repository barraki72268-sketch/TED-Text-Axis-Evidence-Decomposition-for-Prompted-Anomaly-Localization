from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_abnormal_prompts,
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--class_names",
        nargs="+",
        default=["chewinggum", "pipe_fryum", "pcb4", "capsules", "candle", "pcb3"],
    )
    parser.add_argument(
        "--class_summary_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "clip_kin_split_allvisa_analysis" / "class_best_summary.csv"),
    )
    parser.add_argument("--alphas", nargs="+", type=float, default=[0.1, 0.5, 1.0])
    parser.add_argument("--num_splits", type=int, default=5)
    parser.add_argument("--fit_fraction", type=float, default=0.5)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--max_fit_anomaly_patches", type=int, default=4096)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_injected_text_readout")
    return parser.parse_args()


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def load_class_settings(csv_path: str) -> dict[str, dict[str, int | str]]:
    settings: dict[str, dict[str, int | str]] = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            settings[row["class_name"]] = {
                "best_layer": int(row["best_layer"]),
                "best_k": int(row["best_k"]),
                "group": row["group"],
            }
    return settings


def build_text_anchor(backbone, class_name: str, abnormal: bool) -> torch.Tensor:
    state_prompts = state_level_abnormal_prompts if abnormal else state_level_normal_prompts
    class_text = class_name.replace("_", " ")
    prompts: list[str] = []
    for template in template_level_prompts:
        for state_prompt in state_prompts:
            prompts.append(template.format(state_prompt.format(class_text)))

    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = backbone.visual.proj.detach().float().to(text_anchor.device)
    token_anchor = proj @ text_anchor
    return F.normalize(token_anchor, dim=0)


def get_null_space_residual(V: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    V = V.float()
    V_proj = (V @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return V - V_proj


def forward_up_to_layer(model, image: torch.Tensor, layer_idx: int, return_sequence: bool = False):
    sequence = model.prepare_sequence(image)
    seq_mid = model.run_blocks(sequence, start_layer=1, end_layer=layer_idx)
    tokens_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
    if return_sequence:
        return tokens_mid, seq_mid
    return tokens_mid


def forward_remaining(model, v_mid_modified: torch.Tensor, layer_idx: int, cls_token: torch.Tensor) -> torch.Tensor:
    batch_seq = torch.cat([cls_token, v_mid_modified], dim=1)
    sequence = batch_seq.permute(1, 0, 2)
    seq_final = model.run_blocks(sequence, start_layer=layer_idx + 1, end_layer=model.num_layers)
    final_batch = seq_final.permute(1, 0, 2)
    final_batch = model.visual.ln_post(final_batch)
    return F.normalize(final_batch[:, 1:, :].float(), dim=-1)


def inject_kinematic_signal(v_mid: torch.Tensor, p_norm: torch.Tensor, V_anom: torch.Tensor, alpha: float) -> torch.Tensor:
    r_mid = get_null_space_residual(v_mid, p_norm)
    delta_v = torch.matmul(torch.matmul(r_mid, V_anom), V_anom.T)
    return v_mid + float(alpha) * delta_v


def collect_class_cache(backbone, class_name: str, inject_layer: int, p_norm: torch.Tensor, args: argparse.Namespace, device: str) -> list[dict]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    cache: list[dict] = []
    for idx, rec in enumerate(ds.records):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            _, seq_mid = forward_up_to_layer(backbone, image_t, inject_layer, return_sequence=True)
            cls_token = seq_mid.permute(1, 0, 2)[:, :1, :].float()
            v_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
            v_final = forward_remaining(backbone, v_mid, inject_layer, cls_token)
        cache.append(
            {
                "index": idx,
                "name": name,
                "img_type": img_type,
                "label": int(label != 0),
                "patch_mask": to_patch_mask(mask_np, backbone.grid_size, device),
                "v_mid": v_mid[0].detach().cpu(),
                "cls_token": cls_token.detach().cpu(),
                "v_final_base": v_final[0].detach().cpu(),
            }
        )
    return cache


def extract_anomaly_subspace_from_cache(
    cache: list[dict],
    fit_anomaly_indices: list[int],
    p_norm: torch.Tensor,
    k: int,
    max_fit_anomaly_patches: int,
) -> torch.Tensor:
    chunks: list[torch.Tensor] = []
    for idx in fit_anomaly_indices:
        rec = cache[idx]
        pos = rec["patch_mask"] > 0
        if int(pos.sum()) == 0:
            continue
        chunks.append(rec["v_mid"][pos])
    if not chunks:
        raise RuntimeError("No positive anomaly patches available in fit split.")

    patches = torch.cat(chunks, dim=0)
    if max_fit_anomaly_patches > 0 and patches.shape[0] > max_fit_anomaly_patches:
        sel = torch.linspace(0, patches.shape[0] - 1, steps=max_fit_anomaly_patches).round().long()
        patches = patches[sel]
    residual = get_null_space_residual(patches, p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:k].T.contiguous()


def score_final_tokens(v_final: torch.Tensor, p_norm: torch.Tensor, delta_p: torch.Tensor) -> np.ndarray:
    residual = get_null_space_residual(v_final, p_norm)
    return (residual @ delta_p).cpu().numpy()


def evaluate_split(
    backbone,
    cache: list[dict],
    p_norm: torch.Tensor,
    delta_p: torch.Tensor,
    inject_layer: int,
    V_anom: torch.Tensor,
    alpha: float,
    eval_indices: list[int],
    device: str,
    topk_ratio: float,
) -> dict[str, float]:
    patch_labels: list[int] = []
    base_patch_scores: list[float] = []
    inj_patch_scores: list[float] = []
    image_labels: list[int] = []
    base_image_scores: list[float] = []
    inj_image_scores: list[float] = []

    for idx in eval_indices:
        rec = cache[idx]
        v_final_base = rec["v_final_base"]
        base_scores = score_final_tokens(v_final_base, p_norm, delta_p)

        v_mid = rec["v_mid"].unsqueeze(0).to(device)
        cls_token = rec["cls_token"].to(device)
        with torch.no_grad():
            v_mid_inj = inject_kinematic_signal(v_mid, p_norm.to(device), V_anom.to(device), alpha)
            v_final_inj = forward_remaining(backbone, v_mid_inj, inject_layer, cls_token)[0].cpu()
        inj_scores = score_final_tokens(v_final_inj, p_norm, delta_p)

        patch_mask = rec["patch_mask"].astype(np.int64)
        patch_labels.extend(patch_mask.tolist())
        base_patch_scores.extend(base_scores.tolist())
        inj_patch_scores.extend(inj_scores.tolist())
        image_labels.append(int(rec["label"]))
        base_image_scores.append(topk_mean(base_scores, topk_ratio))
        inj_image_scores.append(topk_mean(inj_scores, topk_ratio))

    return {
        "base_patch_auc": safe_auc(patch_labels, base_patch_scores),
        "inj_patch_auc": safe_auc(patch_labels, inj_patch_scores),
        "patch_auc_delta": safe_auc(patch_labels, inj_patch_scores) - safe_auc(patch_labels, base_patch_scores),
        "base_image_auc": safe_auc(image_labels, base_image_scores),
        "inj_image_auc": safe_auc(image_labels, inj_image_scores),
        "image_auc_delta": safe_auc(image_labels, inj_image_scores) - safe_auc(image_labels, base_image_scores),
    }


def aggregate_rows(rows: list[dict], base: dict[str, object]) -> dict[str, object]:
    out = dict(base)
    for key in [
        "base_patch_auc",
        "inj_patch_auc",
        "patch_auc_delta",
        "base_image_auc",
        "inj_image_auc",
        "image_auc_delta",
    ]:
        vals = np.asarray([float(row[key]) for row in rows], dtype=np.float64)
        out[f"{key}_mean"] = float(vals.mean())
        out[f"{key}_std"] = float(vals.std())
    return out


def save_plots(summary_rows: list[dict], out_dir: Path, tag: str) -> None:
    class_names = list(dict.fromkeys(row["class_name"] for row in summary_rows))
    alphas = sorted({float(row["alpha"]) for row in summary_rows})

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), sharex=True)
    for cls in class_names:
        cls_rows = sorted([row for row in summary_rows if row["class_name"] == cls], key=lambda x: float(x["alpha"]))
        xs = [float(row["alpha"]) for row in cls_rows]
        patch_delta = [float(row["patch_auc_delta_mean"]) for row in cls_rows]
        image_delta = [float(row["image_auc_delta_mean"]) for row in cls_rows]
        label = f"{cls} ({cls_rows[0]['group']})"
        axes[0].plot(xs, patch_delta, marker="o", label=label)
        axes[1].plot(xs, image_delta, marker="o", label=label)
    axes[0].axhline(0.0, color="black", linewidth=1.0, alpha=0.5)
    axes[1].axhline(0.0, color="black", linewidth=1.0, alpha=0.5)
    axes[0].set_title("Patch AUC Delta (Injected - Baseline)")
    axes[1].set_title("Image AUC Delta (Injected - Baseline)")
    axes[0].set_xlabel("alpha")
    axes[1].set_xlabel("alpha")
    axes[0].grid(True, alpha=0.3)
    axes[1].grid(True, alpha=0.3)
    axes[0].legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(out_dir / f"{tag}_delta_curves.png", dpi=180)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    class_settings = load_class_settings(args.class_summary_csv)
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    summary_rows: list[dict] = []
    detail_rows: list[dict] = []

    for class_name in args.class_names:
        setting = class_settings[class_name]
        inject_layer = int(setting["best_layer"])
        subspace_k = int(setting["best_k"])
        group = str(setting["group"])

        p_norm = build_text_anchor(backbone, class_name, abnormal=False).cpu()
        p_anom = build_text_anchor(backbone, class_name, abnormal=True).cpu()
        delta_p = F.normalize(p_anom - p_norm, dim=0).cpu()

        cache = collect_class_cache(backbone, class_name, inject_layer, p_norm, args, device)
        anomaly_cache_indices = [i for i, rec in enumerate(cache) if rec["label"] == 1]
        normal_cache_indices = [i for i, rec in enumerate(cache) if rec["label"] == 0]
        if len(anomaly_cache_indices) < 2:
            raise RuntimeError(f"class={class_name} needs at least two anomaly images for split evaluation")

        for alpha in args.alphas:
            alpha_rows: list[dict] = []
            for split_id in range(args.num_splits):
                rng = np.random.default_rng(split_id)
                perm = rng.permutation(anomaly_cache_indices).tolist()
                fit_count = max(1, int(round(len(perm) * args.fit_fraction)))
                fit_count = min(fit_count, len(perm) - 1)
                fit_indices = perm[:fit_count]
                eval_indices = normal_cache_indices + perm[fit_count:]

                V_anom = extract_anomaly_subspace_from_cache(
                    cache,
                    fit_indices,
                    p_norm,
                    subspace_k,
                    args.max_fit_anomaly_patches,
                )
                metrics = evaluate_split(
                    backbone=backbone,
                    cache=cache,
                    p_norm=p_norm,
                    delta_p=delta_p,
                    inject_layer=inject_layer,
                    V_anom=V_anom,
                    alpha=float(alpha),
                    eval_indices=eval_indices,
                    device=device,
                    topk_ratio=args.topk_ratio,
                )
                row = {
                    "class_name": class_name,
                    "group": group,
                    "inject_layer": inject_layer,
                    "subspace_k": subspace_k,
                    "alpha": float(alpha),
                    "split_id": split_id,
                    "fit_anom_images": len(fit_indices),
                    "eval_anom_images": len(perm[fit_count:]),
                    "eval_normal_images": len(normal_cache_indices),
                    **metrics,
                }
                alpha_rows.append(row)
                detail_rows.append(row)

            summary_rows.append(
                aggregate_rows(
                    alpha_rows,
                    {
                        "class_name": class_name,
                        "group": group,
                        "inject_layer": inject_layer,
                        "subspace_k": subspace_k,
                        "alpha": float(alpha),
                        "num_splits": len(alpha_rows),
                    },
                )
            )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    stem = f"{args.output_tag}_{class_tag}"
    summary_path = out_dir / f"{stem}_summary.csv"
    detail_path = out_dir / f"{stem}_detail.csv"
    json_path = out_dir / f"{stem}_summary.json"

    with summary_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    with detail_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(detail_rows[0].keys()))
        writer.writeheader()
        writer.writerows(detail_rows)
    with json_path.open("w") as f:
        json.dump({"summary_rows": summary_rows, "detail_rows": detail_rows, "config": vars(args)}, f, indent=2)

    save_plots(summary_rows, out_dir, stem)
    print(summary_path)
    print(detail_path)
    print(json_path)
    print(json.dumps(summary_rows, indent=2))


if __name__ == "__main__":
    main()
