from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT_DIR = ROOT / "neurips2026" / "scripts"
RESULT_ROOT = ROOT / "neurips2026" / "results"

HOST_TO_SCRIPT = {
    "anomalyclip": SCRIPT_DIR / "probe_anomalyclip_common_failure.py",
    "adaclip": SCRIPT_DIR / "probe_adaclip_common_failure.py",
    "adaptclip": SCRIPT_DIR / "probe_adaptclip_common_failure.py",
    "faprompt": SCRIPT_DIR / "probe_faprompt_common_failure.py",
}

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]


def append_status(path: Path, line: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(line.rstrip() + "\n")


def main() -> int:
    parser = argparse.ArgumentParser("Sequential unified common-failure recollection runner")
    parser.add_argument("--hosts", nargs="+", default=["anomalyclip", "adaclip", "adaptclip", "faprompt"])
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--run_tag", type=str, default="rerun1")
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=-1)
    parser.add_argument("--max_normal_images_per_class", type=int, default=-1)
    args = parser.parse_args()

    status_path = RESULT_ROOT / f"common_failure_run_{args.run_tag}.status"
    if status_path.exists():
        status_path.unlink()

    env = os.environ.copy()
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("OPENBLAS_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    env.setdefault("NUMEXPR_NUM_THREADS", "1")

    for host in args.hosts:
        if host not in HOST_TO_SCRIPT:
            raise ValueError(f"Unknown host: {host}")
        script = HOST_TO_SCRIPT[host]
        for preset in PRESETS:
            save_dir = RESULT_ROOT / f"common_failure_{host}_{preset}_{args.run_tag}"
            log_file = Path("/tmp") / f"{save_dir.name}.log"
            cmd = [
                str(PYTHON),
                "-u",
                str(script),
                "--preset",
                preset,
                "--device",
                args.device,
                "--max_anomaly_images_per_class",
                str(args.max_anomaly_images_per_class),
                "--max_normal_images_per_class",
                str(args.max_normal_images_per_class),
                "--save_dir",
                str(save_dir),
            ]
            with open(log_file, "w") as fp:
                proc = subprocess.run(cmd, stdout=fp, stderr=subprocess.STDOUT, env=env)
            status = "OK" if proc.returncode == 0 else "FAIL"
            append_status(status_path, f"{host} {preset} {status} {save_dir} log={log_file}")
            if proc.returncode != 0:
                return proc.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
