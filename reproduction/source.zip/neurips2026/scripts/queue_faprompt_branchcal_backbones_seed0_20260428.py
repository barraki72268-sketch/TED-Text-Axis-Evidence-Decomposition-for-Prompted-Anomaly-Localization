#!/usr/bin/env python3
"""Queue FAPrompt branch-calibrated runs for non-ViT-B backbones."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]

BACKBONES = {
    "vitl14_336": {
        "model_name": "ViT-L/14@336px",
        "prompt_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "dpam_layer": "20",
        "tag": "vitl14_336_f6-12-18-24_dpam20",
    },
    "vitl14openai": {
        "model_name": "ViT-L/14",
        "prompt_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "dpam_layer": "20",
        "tag": "vitl14openai_f6-12-18-24_dpam20",
    },
    "vith14": {
        "model_name": "ViT-H-14",
        "prompt_load_mode": "project_crop",
        "features": ["8", "16", "24", "32"],
        "dpam_layer": "27",
        "tag": "vith14_f8-16-24-32_dpam27",
    },
}


def run_one(backbone_key: str, preset: str, seed: int, device: str) -> None:
    cfg = BACKBONES[backbone_key]
    save_dir = (
        Path("neurips2026/results")
        / f"faprompt_branchcal_{cfg['tag']}_{preset}_rank4_a02_officialimg_seed{seed}_20260428"
    )
    cmd = [
        sys.executable,
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        cfg["model_name"],
        "--prompt_load_mode",
        cfg["prompt_load_mode"],
        "--features_list",
        *cfg["features"],
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        cfg["dpam_layer"],
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    print(
        f"[RUN] backbone={backbone_key} seed={seed} preset={preset} "
        f"device={device} save_dir={save_dir}",
        flush=True,
    )
    subprocess.run(cmd, check=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backbones", default="vitl14openai,vith14")
    ap.add_argument("--presets", default=",".join(PRESETS))
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cuda:0")
    args = ap.parse_args()

    for backbone_key in [x.strip() for x in args.backbones.split(",") if x.strip()]:
        if backbone_key not in BACKBONES:
            raise ValueError(f"Unknown backbone: {backbone_key}. Choices: {sorted(BACKBONES)}")
        for preset in [p.strip() for p in args.presets.split(",") if p.strip()]:
            run_one(backbone_key, preset, seed=args.seed, device=args.device)


if __name__ == "__main__":
    main()
