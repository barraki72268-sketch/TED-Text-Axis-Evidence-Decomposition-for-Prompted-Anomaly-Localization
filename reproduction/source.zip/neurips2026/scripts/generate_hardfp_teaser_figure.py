from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"

HOSTS = ["AnomalyCLIP", "AdaCLIP", "AdaptCLIP", "FAPrompt"]
HOST_FILES = {
    "AnomalyCLIP": RESULTS / "anomalyclip_map_separability_baseline_epoch5" / "summary.json",
    "AdaCLIP": RESULTS / "adaclip_map_separability_baseline_last" / "summary.json",
    "AdaptCLIP": RESULTS / "adaptclip_map_separability_baseline_epoch15" / "summary.json",
    "FAPrompt": RESULTS / "faprompt_map_separability_baseline_epoch15" / "summary.json",
}
HIST_IMAGE = RESULTS / "anomalyclip_map_separability_baseline_epoch5" / "hist.png"
COLORS = {
    "AnomalyCLIP": "#355C7D",
    "AdaCLIP": "#C06C84",
    "AdaptCLIP": "#6C5B7B",
    "FAPrompt": "#F8B195",
}


def load_json(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser("Generate hard-FP entanglement teaser figure")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULTS / "hardfp_teaser_figure"),
    )
    args = parser.parse_args()

    rows = []
    for host in HOSTS:
        payload = load_json(HOST_FILES[host])["summary"]
        rows.append(
            {
                "host": host,
                "auc_true_defect_vs_hard_fp": float(payload["pairwise_auc"]["true_defect_vs_hard_fp"]),
                "auc_true_defect_vs_outside": float(payload["pairwise_auc"]["true_defect_vs_outside"]),
                "true_defect_mean": float(payload["groups"]["true_defect"]["mean"]),
                "hard_fp_mean": float(payload["groups"]["hard_fp"]["mean"]),
                "hard_fp_minus_true": float(payload["groups"]["hard_fp"]["mean"] - payload["groups"]["true_defect"]["mean"]),
            }
        )

    fig = plt.figure(figsize=(18, 5.2), constrained_layout=True)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 1.1, 1.0])
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[0, 2])

    hist_img = mpimg.imread(HIST_IMAGE)
    ax0.imshow(hist_img)
    ax0.axis("off")
    ax0.set_title("Representative Baseline Score Overlap\n(AnomalyCLIP)")

    x = np.arange(len(HOSTS))
    w = 0.34
    auc_hfp = [r["auc_true_defect_vs_hard_fp"] for r in rows]
    auc_out = [r["auc_true_defect_vs_outside"] for r in rows]
    ax1.bar(x - w / 2, auc_hfp, width=w, label="True Defect vs Hard FP", color="#D95F02")
    ax1.bar(x + w / 2, auc_out, width=w, label="True Defect vs Outside", color="#1B9E77")
    ax1.axhline(0.5, color="black", lw=0.9, ls="--", alpha=0.7)
    ax1.set_xticks(x, HOSTS, rotation=15, ha="right")
    ax1.set_ylim(0.0, 1.0)
    ax1.set_ylabel("AUC")
    ax1.set_title("Hard FP Is Much Harder Than Generic Outside")
    ax1.legend(frameon=False, loc="upper left")
    ax1.grid(axis="y", alpha=0.2)
    for xi, y in zip(x - w / 2, auc_hfp):
        ax1.text(xi, y + 0.02, f"{y:.2f}", ha="center", va="bottom", fontsize=9)
    for xi, y in zip(x + w / 2, auc_out):
        ax1.text(xi, y + 0.02, f"{y:.2f}", ha="center", va="bottom", fontsize=9)

    delta = [r["hard_fp_minus_true"] for r in rows]
    bars = ax2.bar(x, delta, color=[COLORS[h] for h in HOSTS], width=0.62)
    ax2.axhline(0.0, color="black", lw=0.9)
    ax2.set_xticks(x, HOSTS, rotation=15, ha="right")
    ax2.set_ylabel("Hard FP mean - True Defect mean")
    ax2.set_title("Hard FP Often Scores Above True Defect")
    ax2.grid(axis="y", alpha=0.2)
    ymax = max(delta)
    ax2.set_ylim(min(-0.02, min(delta) - 0.02), ymax + 0.06)
    for b, y in zip(bars, delta):
        ax2.text(b.get_x() + b.get_width() / 2, y + 0.01, f"{y:+.2f}", ha="center", va="bottom", fontsize=9)

    fig.suptitle("Main Failure Mode: Hard Normal vs True Defect Entanglement", fontsize=15)

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    png = save_dir / "hardfp_teaser.png"
    pdf = save_dir / "hardfp_teaser.pdf"
    with open(save_dir / "hardfp_teaser.json", "w") as f:
        json.dump({"rows": rows, "hist_image": str(HIST_IMAGE)}, f, indent=2)
    fig.savefig(png, dpi=220, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print(json.dumps({"png": str(png), "pdf": str(pdf)}, indent=2))


if __name__ == "__main__":
    main()
