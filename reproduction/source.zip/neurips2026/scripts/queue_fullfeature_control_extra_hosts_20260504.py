#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "fullfeature_memory_control_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "fullfeature_memory_control_20260504"
BANK = ROOT / "neurips2026" / "results" / "bank_cache"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADAPT_MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
ADAPT_VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"

DATASETS = {
    "mvtec": MVTEC_ROOT,
    "visa": VISA_ROOT,
    "mpdd": MPDD_ROOT,
    "btad": BTAD_ROOT,
}


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def split_preset(preset: str) -> tuple[str, str]:
    if "2" not in preset:
        raise SystemExit(f"Unsupported preset={preset}; expected source2target")
    source, target = preset.split("2", 1)
    if source not in DATASETS or target not in DATASETS:
        raise SystemExit(f"Unsupported preset={preset}")
    return source, target


def adapt_ckpt(source: str) -> Path:
    return ADAPT_VISA_CKPT if source == "visa" else ADAPT_MVTEC_CKPT


def aaclip_cmd(preset: str, device: str, seed: int) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_fullfeat_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0",
        "--blend_modes",
        "fullfeat_replace,fullfeat_residual",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir


def adaptclip_cmd(preset: str, device: str, seed: int) -> tuple[list[str], Path]:
    source, target = split_preset(preset)
    save_dir = RESULTS / f"adaptclip_vitl336_{preset}_fullfeat_seed{seed}"
    bank_cache = BANK / f"adaptclip_fullfeat_control_{source}_all4_seed{seed}.pt"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaptclip.py",
        "--source_root",
        str(DATASETS[source]),
        "--source_dataset",
        source,
        "--target_root",
        str(DATASETS[target]),
        "--target_dataset",
        target,
        "--checkpoint_path",
        str(adapt_ckpt(source)),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank_cache),
        "--pretrained_model",
        "ViT-L/14@336px",
        "--checkpoint_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "8",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--include_fullfeat_control",
        "--fullfeat_tau",
        "0.1",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
        "--seed",
        str(seed),
        "--device",
        device,
    ]
    return cmd, save_dir


def launch(cmd: list[str], save_dir: Path, log_path: Path, force: bool) -> dict:
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        return {"stage": "skip_done", "summary": str(summary)}
    save_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = log_path.open("ab", buffering=0)
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        stdout=log_f,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {"stage": "launched", "pid": proc.pid, "save_dir": str(save_dir), "log": str(log_path)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="aaclip,adaptclip")
    ap.add_argument("--presets", default="visa2btad,mvtec2visa")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    builders = {
        "aaclip": aaclip_cmd,
        "adaptclip": adaptclip_cmd,
    }
    hosts = parse_csv(args.hosts)
    presets = parse_csv(args.presets)
    devices = parse_csv(args.devices)
    if not devices:
        raise SystemExit("--devices cannot be empty")

    jobs = []
    for host in hosts:
        if host not in builders:
            raise SystemExit(f"Unsupported host={host}; allowed={sorted(builders)}")
        for preset in presets:
            device = devices[len(jobs) % len(devices)]
            cmd, save_dir = builders[host](preset, device, args.seed)
            log_path = LOGS / f"{save_dir.name}.log"
            jobs.append((cmd, save_dir, log_path))

    launched = [launch(cmd, save_dir, log_path, args.force) for cmd, save_dir, log_path in jobs]
    print(json.dumps({"stage": "fullfeature_extra_host_queue", "jobs": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
