from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MVTED_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"

if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_fp_text_decomposition import (  # noqa: E402
    build_model,
    get_learned_text_pair,
    load_prompt_learner,
)
from probe_anomalyclip_wrongclass_semantic_collapse import (  # noqa: E402
    aggregate_map_from_patch_features,
    build_eval_dataset,
    build_reference_text_model,
    safe_auc,
    safe_corr,
    static_text_pair_for_class,
    top_fraction_mask,
)


def resolve_preset(preset: str) -> tuple[str, str, str]:
    if preset == "visa2mvtec":
        return str(VISA_CKPT), str(MVTEC_ROOT), "mvtec"
    if preset == "mvtec2visa":
        return str(MVTED_CKPT), str(OFFICIAL_VISA_ROOT), "visa"
    raise ValueError(f"Unknown preset: {preset}")


def denormalize_image(img_tensor: torch.Tensor) -> np.ndarray:
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = np.transpose(img_tensor.cpu().numpy(), (1, 2, 0))
    img = np.clip((img * std + mean) * 255.0, 0, 255).astype(np.uint8)
    return img


def apply_score_overlay(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.52, colormap: int = cv2.COLORMAP_JET) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, colormap)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return np.clip(alpha * image.astype(np.float32) + (1.0 - alpha) * scoremap.astype(np.float32), 0, 255).astype(np.uint8)


def overlay_binary_mask(image: np.ndarray, mask: np.ndarray, color=(255, 80, 40), alpha: float = 0.55) -> np.ndarray:
    out = image.astype(np.float32).copy()
    color_arr = np.array(color, dtype=np.float32)
    out[mask] = (1 - alpha) * out[mask] + alpha * color_arr
    return np.clip(out, 0, 255).astype(np.uint8)


def percentile_bounds(arr: np.ndarray, lo: float = 1.0, hi: float = 99.0) -> tuple[float, float]:
    lo_v = float(np.percentile(arr, lo))
    hi_v = float(np.percentile(arr, hi))
    if hi_v <= lo_v:
        lo_v = float(arr.min())
        hi_v = float(arr.max())
    return lo_v, hi_v


def normalize_map(arr: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((arr - vmin) / denom, 0.0, 1.0)


def normalize_abs_map(arr: np.ndarray, q: float = 99.0) -> np.ndarray:
    bound = max(float(np.percentile(np.abs(arr), q)), 1e-8)
    return np.clip(np.abs(arr) / bound, 0.0, 1.0)


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def pick_row(metrics_path: Path, class_name: str, dataset_index: int | None) -> dict:
    rows = []
    with open(metrics_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            if row["class_name"] != class_name:
                continue
            rows.append(row)
    if not rows:
        raise ValueError(f"No rows found for class={class_name} in {metrics_path}")
    if dataset_index is not None:
        for row in rows:
            if int(row["image_id"]) == dataset_index:
                return row
        raise ValueError(f"dataset_index={dataset_index} not found for class={class_name}")
    rows.sort(
        key=lambda row: (
            float(row["true_prompt_rank_local"]) - float(row["true_prompt_rank_image"]),
            float(row["learned_vs_mean_wrong_corr"]) - float(row["learned_vs_true_corr"]),
        ),
        reverse=True,
    )
    return rows[0]


def main():
    parser = argparse.ArgumentParser("Generate discussion composite for AnomalyCLIP using existing audit + dashboard artifact")
    parser.add_argument("--preset", type=str, required=True, choices=["visa2mvtec", "mvtec2visa"])
    parser.add_argument("--target_class", type=str, required=True)
    parser.add_argument("--audit_metrics_path", type=str, required=True)
    parser.add_argument("--dashboard_png", type=str, required=True)
    parser.add_argument("--dashboard_json", type=str, required=True)
    parser.add_argument("--dataset_index", type=int, default=None)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--save_dir", type=str, required=True)
    args = parser.parse_args()

    row = pick_row(Path(args.audit_metrics_path), args.target_class, args.dataset_index)
    dataset_index = int(row["image_id"])
    checkpoint_path, target_root, target_dataset = resolve_preset(args.preset)

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    reference_model = build_reference_text_model(args.device)
    dataset = build_eval_dataset(target_root, target_dataset, args.image_size, mode="test")
    item = dataset[dataset_index]
    if item["cls_name"] != args.target_class:
        raise ValueError(f"dataset_index={dataset_index} has class={item['cls_name']}, expected {args.target_class}")

    image = item["img"].unsqueeze(0).to(args.device)
    gt_mask = item["img_mask"].squeeze().detach().cpu().numpy() > 0.5
    input_img = denormalize_image(item["img"])

    with torch.inference_mode():
        _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
        learned_map = aggregate_map_from_patch_features(patch_features, learned_pair, args.image_size, args.sigma)

        true_pair = static_text_pair_for_class(reference_model, args.target_class, args.device)
        true_map = aggregate_map_from_patch_features(patch_features, true_pair, args.image_size, args.sigma)

        wrong_maps = []
        for prompt_cls in dataset.obj_list:
            if prompt_cls == args.target_class:
                continue
            text_pair = static_text_pair_for_class(reference_model, prompt_cls, args.device)
            score_map = aggregate_map_from_patch_features(patch_features, text_pair, args.image_size, args.sigma)
            wrong_maps.append(
                {
                    "class": prompt_cls,
                    "map": score_map,
                    "local_auc": safe_auc(score_map[gt_mask], score_map[~gt_mask]),
                }
            )

    wrong_maps.sort(key=lambda x: x["local_auc"], reverse=True)
    wrong = wrong_maps[0]
    wrong_map = wrong["map"]
    wrong_cls = wrong["class"]

    learned_auc = safe_auc(learned_map[gt_mask], learned_map[~gt_mask])
    true_auc = safe_auc(true_map[gt_mask], true_map[~gt_mask])
    wrong_auc = safe_auc(wrong_map[gt_mask], wrong_map[~gt_mask])

    all_maps = np.concatenate(
        [
            learned_map.reshape(-1),
            true_map.reshape(-1),
            wrong_map.reshape(-1),
        ]
    )
    vmin, vmax = percentile_bounds(all_maps)

    vis_input = input_img
    vis_gt = overlay_binary_mask(input_img, gt_mask)
    vis_learned = apply_score_overlay(input_img, normalize_map(learned_map, vmin, vmax))
    vis_true = apply_score_overlay(input_img, normalize_map(true_map, vmin, vmax))
    vis_wrong = apply_score_overlay(input_img, normalize_map(wrong_map, vmin, vmax))
    vis_problem_delta = normalize_abs_map(true_map - wrong_map)

    dashboard_img = cv2.cvtColor(cv2.imread(args.dashboard_png), cv2.COLOR_BGR2RGB)
    with open(args.dashboard_json, "r") as f:
        dashboard_meta = json.load(f)

    true_mask = top_fraction_mask(true_map, args.map_topk)
    wrong_mask = top_fraction_mask(wrong_map, args.map_topk)

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    out_png = save_dir / f"{args.target_class}_discussion_composite.png"
    out_pdf = save_dir / f"{args.target_class}_discussion_composite.pdf"
    out_json = save_dir / f"{args.target_class}_discussion_composite.json"

    fig = plt.figure(figsize=(18, 9), constrained_layout=True)
    gs = fig.add_gridspec(2, 5)
    ax_input = fig.add_subplot(gs[0, 0])
    ax_gt = fig.add_subplot(gs[0, 1])
    ax_learned = fig.add_subplot(gs[0, 2])
    ax_true = fig.add_subplot(gs[1, 0])
    ax_wrong = fig.add_subplot(gs[1, 1])
    ax_delta = fig.add_subplot(gs[1, 2])
    ax_dashboard = fig.add_subplot(gs[:, 3:])

    panels = [
        (ax_input, vis_input, "Input"),
        (ax_gt, vis_gt, "GT"),
        (ax_learned, vis_learned, f"Learned Baseline\nAUC={learned_auc:.3f}"),
        (ax_true, vis_true, f"True Prompt\n{args.target_class}\nAUC={true_auc:.3f} rank={row['true_prompt_rank_local']}"),
        (ax_wrong, vis_wrong, f"Confounding Wrong\n{wrong_cls}\nAUC={wrong_auc:.3f}"),
    ]
    for ax, img, title in panels:
        ax.imshow(img)
        ax.set_title(title, fontsize=11)
        ax.axis("off")

    ax_delta.imshow(vis_problem_delta, cmap="magma")
    ax_delta.set_title(
        f"|True-Wrong|\ncorr={safe_corr(true_map, wrong_map):.3f}\noverlap={mask_overlap(true_mask, wrong_mask):.3f}",
        fontsize=11,
    )
    ax_delta.axis("off")

    ax_dashboard.imshow(dashboard_img)
    ax_dashboard.set_title(
        "Existing OURS Dashboard\nbaseline vs OURS support re-ranking",
        fontsize=12,
    )
    ax_dashboard.axis("off")

    fig.suptitle(
        f"AnomalyCLIP discussion composite | {args.preset} | class={args.target_class} | sample={Path(item['img_path']).name}",
        fontsize=14,
    )

    fig.savefig(out_png, dpi=220)
    fig.savefig(out_pdf)
    plt.close(fig)

    payload = {
        "preset": args.preset,
        "class_name": args.target_class,
        "dataset_index": dataset_index,
        "img_path": item["img_path"],
        "problem_side": {
            "learned_local_auc": learned_auc,
            "true_prompt_local_auc": true_auc,
            "wrong_prompt_class": wrong_cls,
            "wrong_prompt_local_auc": wrong_auc,
            "audit_row": row,
            "true_wrong_corr": safe_corr(true_map, wrong_map),
            "true_wrong_topk_overlap": mask_overlap(true_mask, wrong_mask),
        },
        "ours_side": dashboard_meta,
        "artifacts": {
            "png": str(out_png),
            "pdf": str(out_pdf),
        },
    }
    with open(out_json, "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
