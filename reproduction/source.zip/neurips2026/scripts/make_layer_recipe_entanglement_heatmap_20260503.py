#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import sys
from collections import OrderedDict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw
from scipy.ndimage import binary_dilation, gaussian_filter


ROOT = Path(__file__).resolve().parents[2]
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from official_parallel_test_faprompt import (  # noqa: E402
    PRESET_CONFIGS,
    MetaDataset,
    build_model,
    compute_faprompt_outputs,
    get_or_collect_source_banks,
    high_score_gate_tokens,
    learned_text_pair,
    logmeanexp_negative_sqdist_1d,
    prescore_subspace_transport_tokens,
    setup_seed,
    spatial_tanh_zscore,
    subspace_host_residual_token_score,
    train_subspace_host_residual_calibrator,
    upsample_tokens,
)


FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
RUN_DIR = ROOT / "neurips2026" / "results" / "layer_recipe_entanglement_heatmap_20260503"
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
FAP_RETRAIN_ROOT = ROOT / "neurips2026" / "results" / "faprompt_layer_recipe_retrained_20260502"

CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)

C_DEFECT = "#D64A2F"
C_HARDFP = "#1B5E8A"
C_BASE = "#8C939B"
C_CTED = "#1B5E8A"

RECIPES = OrderedDict(
    [
        (
            "Full",
            {
                "checkpoint": FAP_ROOT / "checkpoints/trained_on_visa/epoch_15.pth",
                "features": [6, 12, 18, 24],
            },
        ),
        (
            "EL",
            {
                "checkpoint": FAP_RETRAIN_ROOT / "faprompt_visa_earlylate_ckpt/epoch_15.pth",
                "features": [6, 24],
            },
        ),
        (
            "L2",
            {
                "checkpoint": FAP_RETRAIN_ROOT / "faprompt_visa_last2_ckpt/epoch_15.pth",
                "features": [18, 24],
            },
        ),
        (
            "L",
            {
                "checkpoint": FAP_RETRAIN_ROOT / "faprompt_visa_last_ckpt/epoch_15.pth",
                "features": [24],
            },
        ),
    ]
)


def denormalize_image(image_t: torch.Tensor) -> np.ndarray:
    image = image_t.detach().cpu().float().numpy().transpose(1, 2, 0)
    return np.clip((image * CLIP_STD + CLIP_MEAN) * 255.0, 0, 255).astype(np.uint8)


def rank_map(score: np.ndarray) -> np.ndarray:
    flat = score.reshape(-1)
    order = np.argsort(flat, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float32)
    ranks[order] = np.linspace(0.0, 1.0, flat.size, dtype=np.float32)
    return ranks.reshape(score.shape)


def robust_minmax(score: np.ndarray, lo: float, hi: float) -> np.ndarray:
    score = score.astype(np.float32)
    if hi <= lo:
        return np.zeros_like(score, dtype=np.float32)
    return np.clip((score - lo) / (hi - lo), 0.0, 1.0)


def crop_center(image: np.ndarray, cy: int, cx: int, size: int) -> np.ndarray:
    h, w = image.shape[:2]
    half = size // 2
    y0 = max(0, min(h - size, int(cy) - half))
    x0 = max(0, min(w - size, int(cx) - half))
    crop = image[y0 : y0 + size, x0 : x0 + size]
    if crop.shape[:2] == (size, size):
        return crop
    out = np.zeros((size, size, 3), dtype=np.uint8)
    out[: crop.shape[0], : crop.shape[1]] = crop
    return out


def draw_box(image: np.ndarray, cy: int, cx: int, size: int, color: str, width: int = 4) -> np.ndarray:
    out = Image.fromarray(image.copy())
    draw = ImageDraw.Draw(out)
    half = size // 2
    x0 = max(0, int(cx) - half)
    y0 = max(0, int(cy) - half)
    x1 = min(image.shape[1] - 1, int(cx) + half)
    y1 = min(image.shape[0] - 1, int(cy) + half)
    for off in range(width):
        draw.rectangle([x0 - off, y0 - off, x1 + off, y1 + off], outline=color)
    return np.asarray(out)


def contour_mask(image: np.ndarray, mask: np.ndarray, color: str = C_DEFECT) -> np.ndarray:
    if mask.shape != image.shape[:2] or not mask.any():
        return image
    m = mask.astype(bool)
    inner = m & np.roll(m, 1, 0) & np.roll(m, -1, 0) & np.roll(m, 1, 1) & np.roll(m, -1, 1)
    contour = m & ~inner
    contour = binary_dilation(contour, iterations=2)
    rgb = tuple(int(color.lstrip("#")[i : i + 2], 16) for i in (0, 2, 4))
    out = image.copy()
    out[contour] = np.asarray(rgb, dtype=np.uint8)
    return out


def overlay_heatmap(image: np.ndarray, heat: np.ndarray, alpha: float = 0.54) -> np.ndarray:
    heat = np.clip(heat.astype(np.float32), 0.0, 1.0)
    cmap = plt.get_cmap("magma")
    colored = (cmap(heat)[..., :3] * 255.0).astype(np.float32)
    out = (1.0 - alpha) * image.astype(np.float32) + alpha * colored
    return np.clip(out, 0, 255).astype(np.uint8)


def get_mask_np(sample: dict, image_size: int) -> np.ndarray:
    mask = sample["mask"]
    if mask.ndim == 3:
        mask = mask[0]
    mask_np = mask.detach().cpu().numpy() > 0.5
    if mask_np.shape != (image_size, image_size):
        mask_t = mask.float().view(1, 1, *mask.shape[-2:])
        mask_np = (
            F.interpolate(mask_t, size=(image_size, image_size), mode="nearest")[0, 0]
            .detach()
            .cpu()
            .numpy()
            > 0.5
        )
    return mask_np


def train_branch_calibrators(banks: dict, axis: torch.Tensor, device: torch.device, seed: int) -> dict[str, dict]:
    calibrators = {}
    for branch_name, host_score_key, offset in (("branch1", "branch1_score", 101), ("branch2", "branch2_score", 202)):
        calibrator = train_subspace_host_residual_calibrator(
            banks=banks,
            axis=axis,
            tau=0.1,
            bank_chunk=2048,
            max_train_points=2048,
            epochs=30,
            lr=0.02,
            rank_margin=0.05,
            rank_temp=0.05,
            eta_init=0.05,
            eta_max=0.2,
            eta_reg=0.001,
            fp_weight_init=1.0,
            learn_fp_weight=False,
            hardpair_frac=0.75,
            subspace_rank=4,
            preserve_host_margin_weight=1.0,
            seed=seed + offset,
            device=device,
            host_score_key=host_score_key,
        )
        if calibrator is None:
            raise RuntimeError(f"failed to train {branch_name} calibrator")
        calibrators[branch_name] = calibrator
    return calibrators


def build_context(name: str, spec: dict, device: torch.device) -> dict:
    checkpoint = Path(spec["checkpoint"])
    if not checkpoint.exists():
        raise FileNotFoundError(checkpoint)
    cfg = PRESET_CONFIGS["visa2mvtec"]
    model, prompt_learner, prompt_load_info = build_model(
        device=device,
        checkpoint_path=str(checkpoint),
        model_name="ViT-L/14@336px",
        prompt_load_mode="strict",
        dpam_layer=20,
        depth=9,
        n_ctx=12,
        t_n_ctx=4,
    )
    banks = get_or_collect_source_banks(
        model=model,
        prompt_learner=prompt_learner,
        preset="visa2mvtec",
        source_root=cfg["source_root"],
        checkpoint_path=str(checkpoint),
        model_name="ViT-L/14@336px",
        prompt_load_mode="strict",
        cache_dir=ROOT / "neurips2026/results/bank_cache",
        image_size=518,
        batch_size=2,
        num_workers=4,
        device=device,
        features_list=list(spec["features"]),
        sigma=10,
        dap_token_mode="official_firstk",
        dpam_layer=prompt_load_info["effective_dpam_layer"],
        max_fp_per_class=512,
        max_defect_per_class=512,
        max_fp_total=4096,
        max_defect_total=4096,
        normal_topk_frac=0.01,
        seed=0,
        force_rebuild_bank=False,
    )
    base_text_pair = learned_text_pair(model, prompt_learner)
    axis = F.normalize(base_text_pair[1] - base_text_pair[0], dim=0)
    calibrators = train_branch_calibrators(banks, axis, device, seed=0)
    return {
        "name": name,
        "model": model,
        "prompt_learner": prompt_learner,
        "features": list(spec["features"]),
        "dpam_layer": prompt_load_info["effective_dpam_layer"],
        "banks": banks,
        "axis": axis,
        "calibrators": calibrators,
        "base_text_pair": base_text_pair,
    }


@torch.no_grad()
def compute_maps(ctx: dict, sample: dict, device: torch.device) -> dict:
    image = sample["image"].unsqueeze(0).to(device)
    out = compute_faprompt_outputs(
        ctx["model"],
        ctx["prompt_learner"],
        image,
        ctx["features"],
        image_size=518,
        sigma=10,
        dap_token_mode="official_firstk",
        dpam_layer=ctx["dpam_layer"],
        base_text_pair=ctx["base_text_pair"],
    )
    tokens = out["patch_tokens"]
    branch1_token = out["branch1_token_score"]
    branch2_token = out["branch2_token_score"]
    baseline_token = out["token_score"]
    axis = ctx["axis"]
    banks = ctx["banks"]
    fp_proj = banks["fp"].to(device) @ axis
    defect_proj = banks["defect"].to(device) @ axis
    query_proj = tokens @ axis
    q_def = logmeanexp_negative_sqdist_1d(query_proj, defect_proj, tau=0.1, chunk=2048)
    q_fp = logmeanexp_negative_sqdist_1d(query_proj, fp_proj, tau=0.1, chunk=2048)
    baseline_z = spatial_tanh_zscore(baseline_token)

    cal1 = ctx["calibrators"]["branch1"]
    cal2 = ctx["calibrators"]["branch2"]
    rect_tokens1 = prescore_subspace_transport_tokens(
        tokens=tokens,
        q_def=q_def,
        q_fp=q_fp,
        basis=cal1["basis"],
        eta=float(cal1["eta"]),
        direction=cal1["transport_direction"],
        transport_b=float(cal1["transport_b"]),
        fp_weight=float(cal1["fp_weight"]),
    )
    rect_tokens2 = prescore_subspace_transport_tokens(
        tokens=tokens,
        q_def=q_def,
        q_fp=q_fp,
        basis=cal2["basis"],
        eta=float(cal2["eta"]),
        direction=cal2["transport_direction"],
        transport_b=float(cal2["transport_b"]),
        fp_weight=float(cal2["fp_weight"]),
    )
    corrected1 = subspace_host_residual_token_score(
        host_score=branch1_token,
        rect_tokens=rect_tokens1,
        basis=cal1["basis"],
        score_w=cal1["subspace_score_w"],
        readout_gamma=float(cal1.get("readout_gamma", 1.0)),
    )
    corrected2 = subspace_host_residual_token_score(
        host_score=branch2_token,
        rect_tokens=rect_tokens2,
        basis=cal2["basis"],
        score_w=cal2["subspace_score_w"],
        readout_gamma=float(cal2.get("readout_gamma", 1.0)),
    )
    residual_token = 0.5 * ((corrected1 - branch1_token) + (corrected2 - branch2_token))
    token_gate = high_score_gate_tokens(baseline_z, topk_frac=0.1, sharpness=4.0)
    corrected = baseline_token + token_gate * residual_token
    cted_map = upsample_tokens(corrected, image_size=518, sigma=10)[0]
    base_map = out["anomaly_map"]
    if base_map.ndim == 3:
        base_map = base_map[0]
    return {
        "baseline_raw": np.asarray(base_map, dtype=np.float32),
        "cted_raw": np.asarray(cted_map, dtype=np.float32),
    }


def pick_case(contexts: OrderedDict[str, dict], dataset: MetaDataset, device: torch.device, max_images: int = 140) -> dict:
    best = None
    checked = 0
    for idx, item in enumerate(dataset.items):
        if int(item.get("anomaly", 0)) == 0:
            continue
        sample = dataset[idx]
        mask = get_mask_np(sample, 518)
        if int(mask.sum()) < 64:
            continue
        full_ctx = contexts["Full"]
        maps = compute_maps(full_ctx, sample, device)
        base = rank_map(maps["baseline_raw"])
        outside = ~binary_dilation(mask, iterations=28)
        if not outside.any():
            continue
        defect_flat_idx = int(np.argmax(np.where(mask, base, -np.inf)))
        hard_flat_idx = int(np.argmax(np.where(outside, base, -np.inf)))
        dy, dx = np.unravel_index(defect_flat_idx, base.shape)
        hy, hx = np.unravel_index(hard_flat_idx, base.shape)
        if math.dist((float(dy), float(dx)), (float(hy), float(hx))) < 70.0:
            continue
        base_gaps = []
        cted_gaps = []
        improvements = []
        hard_strengths = []
        defect_strengths = []
        for _, ctx in contexts.items():
            recipe_maps = compute_maps(ctx, sample, device)
            rb = rank_map(recipe_maps["baseline_raw"])
            rc = rank_map(recipe_maps["cted_raw"])
            bg = float(rb[dy, dx] - rb[hy, hx])
            cg = float(rc[dy, dx] - rc[hy, hx])
            base_gaps.append(bg)
            cted_gaps.append(cg)
            improvements.append(cg - bg)
            hard_strengths.append(float(rb[hy, hx]))
            defect_strengths.append(float(rb[dy, dx]))
        mean_improvement = float(np.mean(improvements))
        min_improvement = float(np.min(improvements))
        mean_base_confusion = float(np.mean(np.maximum(-np.asarray(base_gaps), 0.0)))
        mean_hard_strength = float(np.mean(hard_strengths))
        objective = mean_improvement + 0.35 * min_improvement + 0.25 * mean_base_confusion + 0.20 * mean_hard_strength
        row = {
            "idx": idx,
            "img_path": item.get("img_path"),
            "class_name": item.get("cls_name"),
            "defect": [int(dy), int(dx)],
            "hard_fp": [int(hy), int(hx)],
            "base_gaps": base_gaps,
            "cted_gaps": cted_gaps,
            "improvements": improvements,
            "mean_improvement": mean_improvement,
            "min_improvement": min_improvement,
            "mean_base_confusion": mean_base_confusion,
            "mean_hard_strength": mean_hard_strength,
            "hard_strengths": hard_strengths,
            "defect_strengths": defect_strengths,
            "objective": objective,
        }
        if best is None or objective > best["objective"]:
            best = row
        checked += 1
        if checked % 25 == 0:
            print(json.dumps({"stage": "case_scan", "checked": checked, "best": None if best is None else best["img_path"], "objective": None if best is None else best["objective"]}), flush=True)
        if checked >= max_images:
            break
    if best is None:
        raise RuntimeError("failed to find an anomalous target case")
    return best


def crop_heat_and_img(image: np.ndarray, heat: np.ndarray, cy: int, cx: int, size: int) -> np.ndarray:
    img_crop = crop_center(image, cy, cx, size)
    heat_crop = crop_center((np.clip(heat, 0, 1) * 255).astype(np.uint8)[..., None].repeat(3, axis=2), cy, cx, size)[..., 0]
    return overlay_heatmap(img_crop, heat_crop.astype(np.float32) / 255.0, alpha=0.58)


def make_figure(image: np.ndarray, mask: np.ndarray, case: dict, recipe_maps: OrderedDict[str, dict]) -> dict:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 7.8,
            "axes.titlesize": 8.8,
            "axes.labelsize": 7.4,
            "xtick.labelsize": 7.2,
            "ytick.labelsize": 7.2,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    dy, dx = case["defect"]
    hy, hx = case["hard_fp"]
    box = 46
    boxed = contour_mask(image, mask)
    boxed = draw_box(boxed, dy, dx, box, C_DEFECT, width=4)
    boxed = draw_box(boxed, hy, hx, box, C_HARDFP, width=4)
    defect_crop = draw_box(crop_center(image, dy, dx, 84), 42, 42, 72, C_DEFECT, width=4)
    hard_crop = draw_box(crop_center(image, hy, hx, 84), 42, 42, 72, C_HARDFP, width=4)

    fig = plt.figure(figsize=(7.25, 2.92))
    gs = fig.add_gridspec(3, 6, width_ratios=[1.10, 1.0, 1.0, 1.0, 1.0, 1.34], wspace=0.12, hspace=0.10)

    left = gs[:, 0].subgridspec(2, 2, height_ratios=[1.42, 0.76], wspace=0.07, hspace=0.20)
    ax_img = fig.add_subplot(left[0, :])
    ax_img.imshow(boxed)
    ax_img.set_title("target", fontweight="bold", pad=2, fontsize=9.2)
    ax_img.set_xticks([])
    ax_img.set_yticks([])
    for s in ax_img.spines.values():
        s.set_visible(False)

    for ax, crop, title, color in [
        (fig.add_subplot(left[1, 0]), defect_crop, "D", C_DEFECT),
        (fig.add_subplot(left[1, 1]), hard_crop, "H-FP", C_HARDFP),
    ]:
        ax.imshow(crop)
        ax.text(
            0.05,
            0.07,
            title,
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=8.2,
            fontweight="bold",
            color="white",
            bbox={"facecolor": color, "edgecolor": "none", "alpha": 0.90, "pad": 1.8},
        )
        ax.set_xticks([])
        ax.set_yticks([])
        for s in ax.spines.values():
            s.set_linewidth(2.4)
            s.set_edgecolor(color)

    gaps = {"B": [], "C-TED": []}
    crop_size = 86
    for col, (recipe, maps) in enumerate(recipe_maps.items(), start=1):
        b_raw = maps["baseline_raw"]
        c_raw = maps["cted_raw"]
        lo, hi = np.quantile(np.concatenate([b_raw.reshape(-1), c_raw.reshape(-1)]), [0.02, 0.995])
        b = robust_minmax(b_raw, float(lo), float(hi))
        c = robust_minmax(c_raw, float(lo), float(hi))
        b_rank = rank_map(b_raw)
        c_rank = rank_map(c_raw)
        gaps["B"].append(float(b_rank[dy, dx] - b_rank[hy, hx]))
        gaps["C-TED"].append(float(c_rank[dy, dx] - c_rank[hy, hx]))
        for row, (row_label, heat, cy, cx, color) in enumerate(
            [
                ("Defect", b, dy, dx, C_DEFECT),
                ("B", b, hy, hx, C_HARDFP),
                ("C-TED", c, hy, hx, C_HARDFP),
            ]
        ):
            ax = fig.add_subplot(gs[row, col])
            vis = crop_heat_and_img(image, heat, cy, cx, crop_size)
            vis = draw_box(vis, crop_size // 2, crop_size // 2, crop_size - 16, color, width=3)
            ax.imshow(vis)
            if row == 0:
                ax.set_title(recipe, fontweight="bold", pad=3, fontsize=9.8)
            if col == 1:
                if row_label == "Defect":
                    score_val = float(b_rank[cy, cx])
                    tag = f"Defect {score_val:.2f}"
                elif row_label == "B":
                    score_val = float(b_rank[cy, cx])
                    tag = f"B {score_val:.2f}"
                else:
                    score_val = float(c_rank[cy, cx])
                    tag = f"C-TED {score_val:.2f}"
                ax.text(
                    0.04,
                    0.08,
                    tag,
                    transform=ax.transAxes,
                    ha="left",
                    va="bottom",
                    fontsize=7.9,
                    fontweight="bold",
                    color="white",
                    bbox={"facecolor": "#111111", "edgecolor": "none", "alpha": 0.72, "pad": 1.8},
                )
            ax.set_xticks([])
            ax.set_yticks([])
            for s in ax.spines.values():
                s.set_visible(False)

    inset = fig.add_subplot(gs[:, 5])
    x = np.arange(len(recipe_maps))
    inset.axhline(0, color="#333333", lw=0.8, alpha=0.35)
    inset.plot(x, gaps["B"], color=C_BASE, marker="o", lw=1.8, ms=4.0, label="B")
    inset.plot(x, gaps["C-TED"], color=C_CTED, marker="o", lw=2.0, ms=4.0, label="C-TED")
    inset.set_xticks(x)
    inset.set_xticklabels(list(recipe_maps.keys()), fontweight="bold")
    inset.set_ylabel("")
    inset.set_title("D-H-FP gap", fontweight="bold", pad=2, fontsize=9.2)
    inset.tick_params(axis="y", pad=3, labelleft=False, labelright=True)
    inset.yaxis.tick_right()
    inset.grid(axis="y", alpha=0.20)
    inset.spines["top"].set_visible(False)
    inset.spines["right"].set_visible(False)
    inset.legend(frameon=False, fontsize=6.9, loc="lower right", handlelength=1.2)

    fig.tight_layout(pad=0.16)
    return {"figure": fig, "gaps": gaps}


def main() -> int:
    setup_seed(0)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    cfg = PRESET_CONFIGS["visa2mvtec"]
    dataset = MetaDataset(cfg["target_root"], 518, split="test")

    contexts = OrderedDict()
    for name, spec in RECIPES.items():
        print(json.dumps({"stage": "build_context", "recipe": name}), flush=True)
        contexts[name] = build_context(name, spec, device)
    print(json.dumps({"stage": "pick_case"}), flush=True)
    case = pick_case(contexts, dataset, device)
    sample = dataset[int(case["idx"])]
    image = denormalize_image(sample["image"])
    mask = get_mask_np(sample, 518)

    recipe_maps = OrderedDict()
    for name in RECIPES:
        recipe_maps[name] = compute_maps(contexts[name], sample, device)

    rendered = make_figure(image, mask, case, recipe_maps)
    pdf = FIG_DIR / "layer_recipe_entanglement_heatmap_20260503.pdf"
    png = FIG_DIR / "layer_recipe_entanglement_heatmap_20260503.png"
    rendered["figure"].savefig(pdf, bbox_inches="tight")
    rendered["figure"].savefig(png, dpi=300, bbox_inches="tight")

    meta = {
        "case": case,
        "recipes": list(recipe_maps.keys()),
        "patch_percentile_gaps": rendered["gaps"],
    }
    (RUN_DIR / "selected_case.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    tex = OUT_DIR / "layer_recipe_entanglement_heatmap_20260503.tex"
    tex.write_text(
        r"""\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{figure/layer_recipe_entanglement_heatmap_20260503.pdf}
\caption{
Layer-recipe changes expose the same hard-FP competition.
For one target image, the same defect and hard-FP patches are traced across retrained feature-layer recipes.
The retrained baseline repeatedly assigns high responses to the hard-FP patch, while C-TED improves the defect-versus-hard-FP percentile gap by re-decoding the same host responses with source evidence.
}
\label{fig:layer_recipe_entanglement_heatmap}
\end{figure*}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)
    print(RUN_DIR / "selected_case.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
