#!/usr/bin/env python3
"""Build a compact AdaCLIP layer-stress table from completed summaries."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026/results/adaclip_layer_stress_cted_recovery_20260501"
OUT = RESULT_ROOT / "adaclip_layer_stress_transfer_table.tex"

TRANSFERS = [
    ("visa2mvtec", r"VisA$\rightarrow$MVTec"),
    ("mvtec2visa", r"MVTec$\rightarrow$VisA"),
    ("mvtec2mpdd", r"MVTec$\rightarrow$MPDD"),
    ("mvtec2btad", r"MVTec$\rightarrow$BTAD"),
]

RECIPES = [
    ("all4", r"Full"),
    ("last", r"Last"),
]

MODES = [
    ("baseline_txt", "B"),
    ("parallel_margin", "T-TED"),
    ("ted_calibrated", "C-TED"),
]


def fmt(x: float | None) -> str:
    if x is None:
        return "--.--"
    return f"{x * 100:.2f}"


def read_mean(preset: str, recipe: str, mode: str) -> tuple[float | None, ...]:
    path = RESULT_ROOT / f"{preset}_{recipe}" / "summary.json"
    if not path.exists():
        return (None, None, None, None)
    data = json.loads(path.read_text())
    for row in data.get("rows", []):
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return (
                row.get("image_auroc"),
                row.get("pixel_auroc"),
                row.get("pixel_aupro"),
                row.get("pixel_ap"),
            )
    return (None, None, None, None)


def bold_best(rows: list[list[str | float | None]]) -> list[list[str]]:
    metric_values: list[list[float | None]] = []
    for row in rows:
        metric_values.append([v if isinstance(v, float) else None for v in row[3:]])

    best: list[float | None] = []
    for metric_idx in range(4):
        vals = [v[metric_idx] for v in metric_values if v[metric_idx] is not None]
        best.append(max(vals) if vals else None)

    out_rows: list[list[str]] = []
    for row, values in zip(rows, metric_values):
        out = [str(row[0]), str(row[1]), str(row[2])]
        for metric_idx, value in enumerate(values):
            text = fmt(value)
            if value is not None and best[metric_idx] is not None and abs(value - best[metric_idx]) < 1e-12:
                text = rf"\textbf{{{text}}}"
            out.append(text)
        out_rows.append(out)
    return out_rows


def main() -> None:
    lines: list[str] = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{AdaCLIP layer-recipe stress and TED recovery. The host checkpoint is fixed; only the local feature layers used for decoding are changed. B denotes the baseline host, T-TED denotes train-free TED, and C-TED denotes source-calibrated TED.}",
        r"\label{tab:adaclip_layer_stress_transfer}",
        r"\small",
        r"\setlength{\tabcolsep}{3.5pt}",
        r"\renewcommand{\arraystretch}{1.04}",
        r"\resizebox{\linewidth}{!}{",
        r"\begin{tabular}{lllcccc}",
        r"\toprule",
        r"Target & Layer & Method & I-AUC & P-AUC & P-PRO & P-AP \\",
        r"\midrule",
    ]

    for preset_idx, (preset, display) in enumerate(TRANSFERS):
        rows: list[list[str | float | None]] = []
        for recipe, recipe_display in RECIPES:
            for mode, method in MODES:
                values = read_mean(preset, recipe, mode)
                rows.append([display, recipe_display, method, *values])

        rendered = bold_best(rows)
        for idx, row in enumerate(rendered):
            target = row[0] if idx == 0 else ""
            layer = row[1] if idx % len(MODES) == 0 else ""
            lines.append(
                f"{target} & {layer} & {row[2]} & {row[3]} & {row[4]} & {row[5]} & {row[6]} \\\\"
            )
            if idx == 2:
                lines.append(r"\cmidrule(lr){2-7}")
        if preset_idx != len(TRANSFERS) - 1:
            lines.append(r"\midrule")

    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"}",
            r"\end{table}",
            "",
        ]
    )
    OUT.write_text("\n".join(lines))
    print(OUT)


if __name__ == "__main__":
    main()
