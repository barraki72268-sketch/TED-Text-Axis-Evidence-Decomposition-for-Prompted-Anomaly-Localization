#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP
PY="/mnt/data/envs/patchcore-conda/bin/python"

run_dino() {
  local preset="$1"
  local save_dir="$2"
  if [[ -f "${save_dir}/summary.json" ]]; then
    echo "[$(date '+%F %T')] skip existing ${save_dir}"
    return 0
  fi
  echo "[$(date '+%F %T')] start AA-CLIP + DINOv2-B ${preset}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip_dinov2_bridge.py \
    --preset "${preset}" \
    --dino_backbone dinov2-base \
    --dino_layers 6,12 \
    --model_name ViT-B-16-plus-240 \
    --pretrained laion400m_e32 \
    --adapter_load_mode project_crop \
    --aa_levels 6,12 \
    --image_size 224 \
    --batch_size 1 \
    --fit_max_per_class 2 \
    --fit_max_patches_per_image 128 \
    --max_fp_per_class 256 \
    --max_defect_per_class 256 \
    --source_limit_per_class 64 \
    --target_limit_per_class 0 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --support_tau 0.1 \
    --gate_sharpness 3.0 \
    --fp_weight 1.0 \
    --alphas=-0.5 \
    --image_score_topk 0.10 \
    --aupro_max_step 50 \
    --device cuda:1 \
    --save_dir "${save_dir}"
}

run_dino visa2mvtec neurips2026/results/aaclip_dinov2base_bridge_visa2mvtec_img224_src64_neg05_map_topk_pro_20260427
run_dino mvtec2visa neurips2026/results/aaclip_dinov2base_bridge_mvtec2visa_img224_src64_neg05_map_topk_pro_20260427
run_dino visa2mpdd neurips2026/results/aaclip_dinov2base_bridge_visa2mpdd_img224_src64_neg05_map_topk_pro_20260427
run_dino visa2btad neurips2026/results/aaclip_dinov2base_bridge_visa2btad_img224_src64_neg05_map_topk_pro_20260427

echo "[$(date '+%F %T')] AA-CLIP + DINOv2-B all-metric queue finished"
