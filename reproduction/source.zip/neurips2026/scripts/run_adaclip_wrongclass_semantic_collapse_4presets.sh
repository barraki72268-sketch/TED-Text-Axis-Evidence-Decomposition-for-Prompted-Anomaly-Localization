#!/usr/bin/env bash
set -euo pipefail

MAX_PER_CLASS="${1:-1}"
GPU_ORDINAL="${2:-0}"
CPU_THREADS="${3:-1}"
RUN_TAG="${4:-$(date +%Y%m%d_%H%M%S)}"

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="neurips2026/scripts/probe_adaclip_wrongclass_semantic_collapse.py"
RESULT_ROOT="${ROOT}/neurips2026/results"
STATUS_FILE="${RESULT_ROOT}/adaclip_wrongclass_semantic_collapse_run_${RUN_TAG}.status"

: > "${STATUS_FILE}"

run_preset() {
  local preset="$1"
  local save_dir="${RESULT_ROOT}/adaclip_wrongclass_semantic_collapse_${preset}_x${MAX_PER_CLASS}_${RUN_TAG}"
  local log_file="/tmp/$(basename "${save_dir}").log"

  echo "============================================================"
  echo "preset=${preset}"
  echo "save_dir=${save_dir}"
  echo "log_file=${log_file}"
  echo "============================================================"

  if \
    OMP_NUM_THREADS="${CPU_THREADS}" \
    OPENBLAS_NUM_THREADS="${CPU_THREADS}" \
    MKL_NUM_THREADS="${CPU_THREADS}" \
    NUMEXPR_NUM_THREADS="${CPU_THREADS}" \
    "${PYTHON}" -u "${SCRIPT}" \
      --preset "${preset}" \
      --max_anomaly_images_per_class "${MAX_PER_CLASS}" \
      --progress_every 1 \
      --cpu_threads "${CPU_THREADS}" \
      --device "cuda:${GPU_ORDINAL}" \
      --save_dir "${save_dir}" \
      2>&1 | tee "${log_file}"; then
    echo "${preset} OK ${save_dir}" | tee -a "${STATUS_FILE}"
  else
    echo "${preset} FAIL ${save_dir}" | tee -a "${STATUS_FILE}"
  fi
}

run_preset visa2mvtec
run_preset mvtec2visa
run_preset mvtec2mpdd
run_preset mvtec2btad
