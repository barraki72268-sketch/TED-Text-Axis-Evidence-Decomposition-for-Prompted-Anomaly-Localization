#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OFFICIAL = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaclip.py"


def _load_official_module():
    spec = importlib.util.spec_from_file_location("official_parallel_test_adaclip_mvtec2", OFFICIAL)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load {OFFICIAL}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    official = _load_official_module()
    original_build_target_dataset = official.build_target_dataset

    def build_target_dataset(root: str, dataset_name: str, model, training: bool, class_name: str | None = None):
        if dataset_name == "mvtec2":
            split = "train" if training else "test"
            return official.GenericMetaDataset(
                root,
                model.preprocess,
                model.transform,
                split=split,
                class_name=class_name,
            )
        return original_build_target_dataset(root, dataset_name, model, training, class_name=class_name)

    official.build_target_dataset = build_target_dataset
    sys.argv = [str(OFFICIAL), *sys.argv[1:]]
    return int(official.main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())
