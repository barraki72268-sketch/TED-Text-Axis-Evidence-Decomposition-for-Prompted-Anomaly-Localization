#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_rawclip.py"
SOURCE_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
SOURCE_DATASET="mvtec"
export MPLCONFIGDIR="/tmp/matplotlib-rawclip-vith14-gpu0"

run_one() {
  local target_root="$1"
  local target_dataset="$2"
  local save_dir="$3"
  local bank_cache="$4"

  CUDA_VISIBLE_DEVICES=0 "${PYTHON}" "${SCRIPT}" \
    --source_root "${SOURCE_ROOT}" \
    --source_dataset "${SOURCE_DATASET}" \
    --target_root "${target_root}" \
    --target_dataset "${target_dataset}" \
    --save_dir "${save_dir}" \
    --bank_cache_path "${bank_cache}" \
    --backbone "ViT-H-14" \
    --pretrained_dataset "laion2b_s32b_b79k" \
    --image_size 224 \
    --prompt_mode class \
    --sigma 4 \
    --max_good_per_class 2 \
    --max_defect_per_class 4 \
    --max_bank_per_layer 512 \
    --max_fp_per_image 64 \
    --max_defect_per_image 64 \
    --device cuda:0
}

run_one \
  "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  "visa" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawclip_vith14_mvtec2visa_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawclip_vith14_mvtec_multilayer.pt"

run_one \
  "/mnt/data/MPDD" \
  "mpdd" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawclip_vith14_mvtec2mpdd_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawclip_vith14_mvtec_multilayer.pt"

run_one \
  "${ROOT}/neurips2026/data/BTAD_official" \
  "btad" \
  "${ROOT}/neurips2026/results/official_parallel_test_rawclip_vith14_mvtec2btad_all" \
  "${ROOT}/neurips2026/results/bank_cache/rawclip_vith14_mvtec_multilayer.pt"
