from __future__ import annotations

import argparse
import json
import os
import shutil
import time
from pathlib import Path


SAFE_PATTERNS = [
    "vscode-typescript*",
    "mpl*",
    "matplotlib-*",
]


def disk_free_gb(path: str = "/") -> float:
    usage = shutil.disk_usage(path)
    return usage.free / (1024 ** 3)


def cleanup_tmp(tmp_root: Path, min_age_sec: int) -> list[str]:
    removed = []
    now = time.time()
    for pattern in SAFE_PATTERNS:
        for p in tmp_root.glob(pattern):
            try:
                stat = p.stat()
            except FileNotFoundError:
                continue
            if now - stat.st_mtime < min_age_sec:
                continue
            try:
                if p.is_dir():
                    shutil.rmtree(p, ignore_errors=False)
                else:
                    p.unlink(missing_ok=True)
                removed.append(str(p))
            except Exception:
                continue
    return removed


def main():
    parser = argparse.ArgumentParser("Simple /tmp watchdog for long-running experiment queues")
    parser.add_argument("--log_path", type=str, required=True)
    parser.add_argument("--interval_sec", type=int, default=300)
    parser.add_argument("--min_free_gb", type=float, default=8.0)
    parser.add_argument("--min_age_sec", type=int, default=1800)
    parser.add_argument("--tmp_root", type=str, default="/tmp")
    args = parser.parse_args()

    log_path = Path(args.log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_root = Path(args.tmp_root)

    while True:
        record = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "free_gb_before": round(disk_free_gb("/"), 3),
            "cleanup_triggered": False,
            "removed": [],
        }
        if record["free_gb_before"] < args.min_free_gb:
            record["cleanup_triggered"] = True
            record["removed"] = cleanup_tmp(tmp_root, args.min_age_sec)
            record["free_gb_after"] = round(disk_free_gb("/"), 3)
        with open(log_path, "a") as f:
            f.write(json.dumps(record) + "\n")
        time.sleep(args.interval_sec)


if __name__ == "__main__":
    main()
