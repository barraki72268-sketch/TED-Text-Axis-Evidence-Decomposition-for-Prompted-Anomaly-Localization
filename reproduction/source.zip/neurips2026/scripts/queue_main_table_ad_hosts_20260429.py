from __future__ import annotations

import argparse
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPTS = ROOT / "neurips2026" / "scripts"
RESULTS = ROOT / "neurips2026" / "results"
BANK_ROOT = RESULTS / "bank_cache"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADACLIP_MVTEC_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"
ADACLIP_VISA_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"
ADAPTCLIP_MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
ADAPTCLIP_VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"


TRANSFERS = {
    "mvtec2visa": (MVTEC_ROOT, "mvtec", VISA_ROOT, "visa"),
    "mvtec2mpdd": (MVTEC_ROOT, "mvtec", MPDD_ROOT, "mpdd"),
    "mvtec2btad": (MVTEC_ROOT, "mvtec", BTAD_ROOT, "btad"),
    "visa2mvtec": (VISA_ROOT, "visa", MVTEC_ROOT, "mvtec"),
}

ADACLIP_BACKBONES = {
    "vitl336": {"label": "ViT-L/14-336", "backbone": "ViT-L-14-336", "load": "strict"},
    "vitl14openai": {"label": "ViT-L/14 OpenAI", "backbone": "ViT-L-14", "load": "compatible"},
    "vitb16": {"label": "ViT-B/16", "backbone": "ViT-B-16", "load": "compatible"},
    "vith14": {"label": "ViT-H/14", "backbone": "ViT-H-14", "load": "compatible"},
}

ADAPTCLIP_BACKBONES = {
    "vitl336": {"label": "ViT-L/14-336", "pretrained": "ViT-L/14@336px", "features": [24], "load": "strict"},
    "vitb16plus": {"label": "ViT-B/16+", "pretrained": "VITB16_PLUS_240", "features": [12], "load": "compatible"},
    "vith14": {"label": "ViT-H/14", "pretrained": "ViT-H-14", "features": [32], "load": "compatible"},
}


def source_ckpt(host: str, source_dataset: str) -> Path:
    if host == "adaclip":
        return ADACLIP_VISA_CKPT if source_dataset == "visa" else ADACLIP_MVTEC_CKPT
    if host == "adaptclip":
        return ADAPTCLIP_VISA_CKPT if source_dataset == "visa" else ADAPTCLIP_MVTEC_CKPT
    raise ValueError(host)


def common_result_dir(host: str, backbone_tag: str, transfer: str, seed: int) -> Path:
    return RESULTS / f"maintable_{host}_{backbone_tag}_{transfer}_seed{seed}_20260429"


def adaclip_cmd(backbone_tag: str, transfer: str, seed: int, device: str) -> tuple[Path, list[str]]:
    source_root, source_dataset, target_root, target_dataset = TRANSFERS[transfer]
    cfg = ADACLIP_BACKBONES[backbone_tag]
    save_dir = common_result_dir("adaclip", backbone_tag, transfer, seed)
    bank = BANK_ROOT / f"maintable_adaclip_{backbone_tag}_{source_dataset}_seed{seed}.pt"
    cmd = [
        str(PYTHON),
        str(SCRIPTS / "official_parallel_test_adaclip.py"),
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(source_ckpt("adaclip", source_dataset)),
        "--save_dir",
        str(save_dir),
        "--backbone",
        cfg["backbone"],
        "--checkpoint_load_mode",
        cfg["load"],
        "--bank_cache_path",
        str(bank),
        "--image_size",
        "518",
        "--layer_recipe",
        "all4",
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "2",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_gate_mode",
        "host",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--image_topk_frac",
        "0.01",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
        "--seed",
        str(seed),
        "--device",
        device,
    ]
    return save_dir, cmd


def adaptclip_cmd(backbone_tag: str, transfer: str, seed: int, device: str) -> tuple[Path, list[str]]:
    source_root, source_dataset, target_root, target_dataset = TRANSFERS[transfer]
    cfg = ADAPTCLIP_BACKBONES[backbone_tag]
    save_dir = common_result_dir("adaptclip", backbone_tag, transfer, seed)
    bank = BANK_ROOT / f"maintable_adaptclip_{backbone_tag}_{source_dataset}_seed{seed}.pt"
    cmd = [
        str(PYTHON),
        str(SCRIPTS / "official_parallel_test_adaptclip_vlrefine.py"),
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(source_ckpt("adaptclip", source_dataset)),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank),
        "--pretrained_model",
        cfg["pretrained"],
        "--checkpoint_load_mode",
        cfg["load"],
        "--features_list",
        *[str(x) for x in cfg["features"]],
        "--image_size",
        "518",
        "--batch_size",
        "1",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--corr_alpha",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--seed",
        str(seed),
        "--device",
        device,
        "--num_workers",
        "4",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
    ]
    return save_dir, cmd


def parse_csv(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def main() -> None:
    parser = argparse.ArgumentParser("Queue final-table AdaCLIP/AdaptCLIP backbone-transfer runs.")
    parser.add_argument("--hosts", default="adaptclip,adaclip")
    parser.add_argument("--backbones", default="vitl336,vitb16plus,vitb16,vith14")
    parser.add_argument("--transfers", default="mvtec2visa,mvtec2mpdd,mvtec2btad,visa2mvtec")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--sleep_sec", type=float, default=2.0)
    parser.add_argument("--dry_run", action="store_true")
    args = parser.parse_args()

    hosts = parse_csv(args.hosts)
    backbones = parse_csv(args.backbones)
    transfers = parse_csv(args.transfers)
    seeds = [int(x) for x in parse_csv(args.seeds)]

    jobs: list[tuple[str, Path, list[str]]] = []
    for host in hosts:
        for backbone in backbones:
            if host == "adaclip":
                if backbone not in ADACLIP_BACKBONES:
                    continue
                make_cmd = adaclip_cmd
            elif host == "adaptclip":
                if backbone not in ADAPTCLIP_BACKBONES:
                    continue
                make_cmd = adaptclip_cmd
            else:
                raise ValueError(f"Unsupported host: {host}")
            for transfer in transfers:
                if transfer not in TRANSFERS:
                    raise ValueError(f"Unsupported transfer: {transfer}")
                for seed in seeds:
                    save_dir, cmd = make_cmd(backbone, transfer, seed, args.device)
                    jobs.append((f"{host}/{backbone}/{transfer}/seed{seed}", save_dir, cmd))

    print(f"[queue] jobs={len(jobs)} device={args.device}", flush=True)
    for tag, save_dir, cmd in jobs:
        summary = save_dir / "summary.json"
        if summary.exists():
            print(f"[skip] {tag}: {summary}", flush=True)
            continue
        print(f"[run] {tag}: {save_dir}", flush=True)
        if args.dry_run:
            print(" ".join(cmd), flush=True)
            continue
        subprocess.run(cmd, cwd=str(ROOT), check=True)
        if args.sleep_sec > 0:
            time.sleep(args.sleep_sec)


if __name__ == "__main__":
    main()
