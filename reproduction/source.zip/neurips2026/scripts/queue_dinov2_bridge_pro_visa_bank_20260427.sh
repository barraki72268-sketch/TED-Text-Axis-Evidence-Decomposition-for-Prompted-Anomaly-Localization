#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

PY="/mnt/data/envs/patchcore-conda/bin/python"
WAIT_PIDS="${WAIT_PIDS:-1558713 1579933}"

wait_for_gpu_pids() {
  for pid in "$@"; do
    [[ -z "${pid}" ]] && continue
    while nvidia-smi --query-compute-apps=pid --format=csv,noheader | tr -d ' ' | grep -qx "${pid}"; do
      echo "[$(date '+%F %T')] waiting for GPU pid ${pid}"
      sleep 60
    done
  done
}

run_dino() {
  local backbone="$1"
  local layers="$2"
  local preset="$3"
  local save_dir="$4"
  echo "[$(date '+%F %T')] start ${backbone} bridge ${preset} -> ${save_dir}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_dinov2_bridge.py \
    --preset "${preset}" \
    --dino_backbone "${backbone}" \
    --layers ${layers} \
    --image_size 224 \
    --fit_max_per_class 2 \
    --fit_max_patches_per_image 128 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --support_tau 0.1 \
    --gate_sharpness 3.0 \
    --alphas 0.02,0.05,0.1 \
    --image_score_topk 0.01 \
    --aupro_max_step 50 \
    --device cuda:1 \
    --save_dir "${save_dir}"
  echo "[$(date '+%F %T')] done ${backbone} bridge ${preset}"
}

wait_for_gpu_pids ${WAIT_PIDS}

for preset in visa2mvtec visa2mpdd visa2btad; do
  run_dino dinov2-base "3 6 9 12" "${preset}" "neurips2026/results/dinov2_base_clipbridge_prescore_hostaxis_${preset}_full_pro_20260427"
done

for preset in visa2mvtec visa2mpdd visa2btad; do
  run_dino dinov2-large "6 12 18 24" "${preset}" "neurips2026/results/dinov2_large_clipbridge_prescore_hostaxis_${preset}_full_pro_20260427"
done

echo "[$(date '+%F %T')] DINOv2 bridge P-PRO queue finished"
