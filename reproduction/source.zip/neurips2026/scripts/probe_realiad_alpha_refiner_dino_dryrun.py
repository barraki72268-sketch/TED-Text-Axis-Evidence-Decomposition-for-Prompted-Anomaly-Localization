from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import open_clip
import torch
import torch.nn.functional as F
from torchvision import transforms as T

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD
from ADPretrain.models.clip import ClipModel
from ADPretrain.models.dino import DinoModel
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts
from neurips2026.learned_refiner import (
    AlphaSpaceKinematicRefiner,
    AlphaSpaceObjective,
    AlphaSpaceSemanticRefiner,
    LinearSemanticBridge,
)
from neurips2026.scripts.probe_realiad_alpha_refiner_clip_dryrun import (
    CLIP_MEAN,
    CLIP_STD,
    LAYER_IDS,
    _load_cached_json,
    build_mask_transform,
    collect_records_by_label,
    compute_patch_residual,
    cosine_decay_lr,
    dilate_mask_tensor,
    filter_trainable_anomalies,
    flatten_records,
    imagewise_mean,
    imagewise_mean_vec,
    linear_schedule,
    load_mask_tensor,
    load_rgb_tensor,
    sample_balanced_batch,
    set_seed,
    audit_dataset,
)

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--dino_backbone", type=str, default="dinov2-large", choices=["dinov2-base", "dinov2-large"])
    parser.add_argument("--teacher_backbone", type=str, default="clip-large-336", choices=["clip-large-336"])
    parser.add_argument("--layer", type=int, default=18, choices=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=448)
    parser.add_argument("--imagesize", type=int, default=448)
    parser.add_argument("--teacher_resize", type=int, default=336)
    parser.add_argument("--teacher_imagesize", type=int, default=336)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--hidden_dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--lambda_sem", type=float, default=1.0)
    parser.add_argument("--lambda_normal", type=float, default=0.1)
    parser.add_argument("--lambda_anomaly", type=float, default=0.1)
    parser.add_argument("--lambda_pairwise", type=float, default=1.0)
    parser.add_argument("--pairwise_margin", type=float, default=0.1)
    parser.add_argument("--sem_threshold", type=float, default=0.02)
    parser.add_argument("--sem_gas_beta", type=float, default=10.0)
    parser.add_argument("--lambda_normal_end", type=float, default=None)
    parser.add_argument("--lambda_normal_decay_start", type=int, default=0)
    parser.add_argument("--lambda_anomaly_start", type=float, default=None)
    parser.add_argument("--lambda_anomaly_end", type=float, default=None)
    parser.add_argument("--lr_decay_start", type=int, default=100)
    parser.add_argument("--lr_min_ratio", type=float, default=0.1)
    parser.add_argument("--eval_interval", type=int, default=5)
    parser.add_argument("--probe_normals", type=int, default=8)
    parser.add_argument("--probe_anomalies", type=int, default=8)
    parser.add_argument("--probe_sem_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_target", type=float, default=0.35)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--fit_normals", type=int, default=32)
    parser.add_argument("--bridge_ridge", type=float, default=1e-3)
    parser.add_argument("--freeze_bridge", action="store_true")
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--steps", type=int, default=160)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--audit_verify_limit", type=int, default=100)
    parser.add_argument("--mask_audit_limit", type=int, default=100)
    parser.add_argument("--reuse_dataset_cache", action="store_true", default=True)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--output_tag", type=str, default="realiad_dino_alpha_dryrun")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def build_transform(
    mean: tuple[float, float, float],
    std: tuple[float, float, float],
    resize: int,
    imagesize: int,
) -> T.Compose:
    return T.Compose(
        [
            T.Resize(resize, interpolation=T.InterpolationMode.BICUBIC),
            T.CenterCrop(imagesize),
            T.ToTensor(),
            T.Normalize(mean=mean, std=std),
        ]
    )


def build_normal_prompt_subspace_text(
    class_name: str,
    clip_model: ClipModel,
    device: torch.device,
) -> torch.Tensor:
    tokenizer = open_clip.get_tokenizer("ViT-L-14")
    prompts = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    text = tokenizer(prompts).to(device)
    with torch.no_grad():
        text_features = clip_model.visual_encoder.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    q_text, _ = torch.linalg.qr(text_features.T, mode="reduced")
    return q_text.cpu()


def maybe_project_clip_tokens(tokens: torch.Tensor, clip_model: ClipModel) -> torch.Tensor:
    visual = clip_model.visual_encoder.visual
    proj = getattr(visual, "proj", None)
    if proj is None:
        return tokens
    target_dim = proj.shape[-1]
    if tokens.shape[-1] == target_dim:
        return tokens
    return tokens @ proj.float().to(tokens.device)


def fit_ridge_bridge(x: torch.Tensor, y: torch.Tensor, ridge: float) -> torch.Tensor:
    x64 = x.double()
    y64 = y.double()
    n = max(x64.shape[0], 1)
    eye = torch.eye(x64.shape[1], dtype=x64.dtype, device=x64.device)
    return torch.linalg.solve((x64.T @ x64) / n + ridge * eye, (x64.T @ y64) / n).float()


def build_batch_tensors_dino(
    batch: list[dict],
    dino_transform: T.Compose,
    mask_transform: T.Compose,
    semantic_basis_by_class: dict[str, torch.Tensor],
    clip_teacher: ClipModel,
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, list[int]]:
    images = torch.stack([load_rgb_tensor(rec["image_path"], dino_transform) for rec in batch], dim=0).to(device)
    masks = []
    basis = []
    labels = []
    for rec in batch:
        if int(rec["label"]) == 1:
            mask = dilate_mask_tensor(load_mask_tensor(rec["mask_path"], mask_transform), args.mask_dilate_kernel)
        else:
            mask = torch.zeros(1, args.imagesize, args.imagesize)
        masks.append(mask)
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = build_normal_prompt_subspace_text(
                rec["class_name"],
                clip_teacher,
                device,
            )
        basis.append(semantic_basis_by_class[rec["class_name"]])
        labels.append(int(rec["label"]))
    masks_t = torch.stack(masks, dim=0).to(device)
    basis_t = torch.stack(basis, dim=0).to(device)
    return images, masks_t, basis_t, labels


def fit_bridge_from_normals(
    *,
    normal_records: list[dict],
    dino_model: DinoModel,
    clip_teacher: ClipModel,
    dino_transform: T.Compose,
    teacher_transform: T.Compose,
    layer_index: int,
    fit_normals: int,
    ridge: float,
    device: torch.device,
) -> tuple[torch.Tensor, dict[str, float]]:
    chosen = normal_records[: min(len(normal_records), fit_normals)]
    xs = []
    ys = []
    for rec in chosen:
        dino_img = load_rgb_tensor(rec["image_path"], dino_transform).unsqueeze(0).to(device)
        clip_img = load_rgb_tensor(rec["image_path"], teacher_transform).unsqueeze(0).to(device)
        with torch.no_grad():
            dino_feat = dino_model.encode_image_from_tensors(dino_img, shape="img")[layer_index].float()
            clip_feat = clip_teacher.encode_image_from_tensors(clip_img, shape="img")[layer_index].float()
        _, d_dim, h, w = dino_feat.shape
        clip_feat = F.interpolate(clip_feat, size=(h, w), mode="bilinear", align_corners=False)
        dino_tokens = dino_feat[0].permute(1, 2, 0).reshape(-1, d_dim)
        clip_tokens = maybe_project_clip_tokens(
            clip_feat[0].permute(1, 2, 0).reshape(-1, clip_feat.shape[1]),
            clip_teacher,
        )
        xs.append(dino_tokens.cpu())
        ys.append(F.normalize(clip_tokens, dim=-1).cpu())
    x = torch.cat(xs, dim=0).to(device)
    y = torch.cat(ys, dim=0).to(device)
    w = fit_ridge_bridge(x, y, ridge=ridge)
    pred = F.normalize(x @ w, dim=-1)
    target = F.normalize(y, dim=-1)
    stats = {
        "fit_pairs": int(x.shape[0]),
        "bridge_train_cos_mean": float(F.cosine_similarity(pred, target, dim=-1).mean().item()),
        "bridge_train_mse": float(((x @ w) - y).pow(2).mean().item()),
    }
    return w.cpu(), stats


def evaluate_probe_batch_dino(
    *,
    model: AlphaSpaceSemanticRefiner,
    objective: AlphaSpaceObjective,
    dino_model: DinoModel,
    clip_teacher: ClipModel,
    probe_batch: list[dict],
    semantic_basis_by_class: dict[str, torch.Tensor],
    dino_transform: T.Compose,
    mask_transform: T.Compose,
    args: argparse.Namespace,
    device: torch.device,
    layer_index: int,
    token_side: int,
) -> dict[str, float]:
    model_was_training = model.training
    model.eval()
    with torch.no_grad():
        images, masks_t, basis_t, labels = build_batch_tensors_dino(
            probe_batch,
            dino_transform,
            mask_transform,
            semantic_basis_by_class,
            clip_teacher,
            args,
            device,
        )
        features = dino_model.encode_image_from_tensors(images, shape="img")[layer_index].float()
        out = model(features, semantic_basis=basis_t)
        loss_stats = objective(
            raw_features=features,
            refined_features=out.refined,
            alpha=out.alpha,
            anomaly_mask=masks_t,
            semantic_basis=out.semantic_basis,
        )
        anomaly_patch_mask = F.interpolate(masks_t.float(), size=(token_side, token_side), mode="nearest").reshape(len(probe_batch), -1) > 0.5
        anomaly_image_mask = torch.tensor(labels, device=device, dtype=torch.bool)
        token_anomaly_counts = anomaly_patch_mask.sum(dim=1)
        anomaly_token_counts_only = token_anomaly_counts[anomaly_image_mask]

        alpha_n = float(loss_stats["alpha_normal_mean"].item())
        alpha_a = float(loss_stats["alpha_anomaly_mean"].item())
        sem = float(loss_stats["loss_sem"].item())
        gap = alpha_n - alpha_a
        score = (
            gap
            - args.probe_sem_penalty * sem
            - args.probe_alphaa_penalty * max(0.0, alpha_a - args.probe_alphaa_target)
        )
    if model_was_training:
        model.train()
    return {
        "probe_score": float(score),
        "probe_alpha_normal_mean": alpha_n,
        "probe_alpha_anomaly_mean": alpha_a,
        "probe_alpha_gap": float(gap),
        "probe_sem_loss": sem,
        "probe_anomaly_zero_token_fraction": float((anomaly_token_counts_only == 0).float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
        "probe_anomaly_token_count_mean": float(anomaly_token_counts_only.float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
    }


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_layer{args.layer}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    png_path = output_dir / f"{stem}_curves.png"

    dino_transform = build_transform(IMAGENET_MEAN, IMAGENET_STD, args.resize, args.imagesize)
    teacher_transform = build_transform(CLIP_MEAN, CLIP_STD, args.teacher_resize, args.teacher_imagesize)
    mask_transform = build_mask_transform(args.imagesize)

    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.resize,
        crp_size=args.imagesize,
        msk_size=args.imagesize,
        msk_crp_size=args.imagesize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    records = flatten_records(dataset)
    normal_records, anomaly_records = collect_records_by_label(records)
    records_by_image_path = {rec["image_path"]: rec for rec in records}

    dino_model = DinoModel(args.dino_backbone, device=str(device)).eval()
    dino_model.visual_encoder = dino_model.visual_encoder.to(device)
    clip_teacher = ClipModel(args.teacher_backbone, device=str(device)).eval()
    clip_teacher.visual_encoder = clip_teacher.visual_encoder.to(device)
    layer_index = LAYER_IDS.index(args.layer)
    token_side = args.imagesize // 14

    audit_cache_path = output_dir / f"realiad_audit_resize{args.imagesize}_dilate{args.mask_dilate_kernel}_verify{args.audit_verify_limit}_mask{args.mask_audit_limit}.json"
    audit = _load_cached_json(audit_cache_path) if args.reuse_dataset_cache else None
    if audit is None:
        audit = audit_dataset(
            records=records,
            mask_transform=mask_transform,
            image_size=args.imagesize,
            token_side=token_side,
            verify_limit=args.audit_verify_limit,
            mask_audit_limit=args.mask_audit_limit,
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with audit_cache_path.open("w") as f:
            json.dump(audit, f, indent=2)

    trainable_cache_path = output_dir / f"realiad_trainable_anomalies_resize{args.imagesize}_dilate{args.mask_dilate_kernel}_token{token_side}_scan{max(args.mask_audit_limit, args.batch_size * args.steps * 4)}.json"
    cached_trainable = _load_cached_json(trainable_cache_path) if args.reuse_dataset_cache else None
    trainable_anomalies = None
    trainable_meta = None
    if cached_trainable is not None:
        cached_records = []
        for rec in cached_trainable.get("records", []):
            current = records_by_image_path.get(rec["image_path"])
            if current is not None:
                cached_records.append(current)
        if cached_records:
            trainable_anomalies = cached_records
            trainable_meta = cached_trainable.get("pool_meta", {})
    if trainable_anomalies is None or trainable_meta is None:
        trainable_anomalies, trainable_meta = filter_trainable_anomalies(
            anomaly_records=anomaly_records,
            mask_transform=mask_transform,
            token_side=token_side,
            scan_limit=max(args.mask_audit_limit, args.batch_size * args.steps * 4),
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with trainable_cache_path.open("w") as f:
            json.dump(
                {
                    "pool_meta": trainable_meta,
                    "records": [
                        {
                            "image_path": rec["image_path"],
                            "mask_path": rec["mask_path"],
                            "class_name": rec["class_name"],
                            "anomaly_type": rec["anomaly_type"],
                            "sample_id": rec["sample_id"],
                        }
                        for rec in trainable_anomalies
                    ],
                },
                f,
                indent=2,
            )
    if not trainable_anomalies:
        raise RuntimeError("No trainable anomaly samples survived token-grid downsampling.")

    bridge_weight, bridge_stats = fit_bridge_from_normals(
        normal_records=normal_records,
        dino_model=dino_model,
        clip_teacher=clip_teacher,
        dino_transform=dino_transform,
        teacher_transform=teacher_transform,
        layer_index=layer_index,
        fit_normals=args.fit_normals,
        ridge=args.bridge_ridge,
        device=device,
    )

    semantic_basis_by_class: dict[str, torch.Tensor] = {}
    core = AlphaSpaceKinematicRefiner(
        feature_dim=dino_model.feature_dimensions[layer_index],
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
    ).to(device)
    bridge = LinearSemanticBridge(
        semantic_dim=bridge_weight.shape[1],
        feature_dim=bridge_weight.shape[0],
    ).to(device)
    with torch.no_grad():
        bridge.weight.copy_(bridge_weight.to(device))
    if args.freeze_bridge:
        for param in bridge.parameters():
            param.requires_grad = False
    model = AlphaSpaceSemanticRefiner(core, bridge).to(device)
    objective = AlphaSpaceObjective(
        lambda_sem=args.lambda_sem,
        lambda_normal=args.lambda_normal,
        lambda_anomaly=args.lambda_anomaly,
        lambda_pairwise=args.lambda_pairwise,
        pairwise_margin=args.pairwise_margin,
        sem_threshold=args.sem_threshold,
        sem_gas_beta=args.sem_gas_beta,
    ).to(device)
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    rng = random.Random(args.seed)
    probe_rng = random.Random(args.seed + 101)
    probe_batch = probe_rng.sample(normal_records, min(len(normal_records), args.probe_normals))
    probe_batch += probe_rng.sample(trainable_anomalies, min(len(trainable_anomalies), args.probe_anomalies))
    probe_rng.shuffle(probe_batch)

    step_rows = []
    best_probe_score = -float("inf")
    best_probe_step = -1
    best_probe_metrics: dict[str, float] | None = None
    for step in range(1, args.steps + 1):
        tic = time.time()
        current_lambda_normal = linear_schedule(
            step=step,
            total_steps=args.steps,
            start_value=args.lambda_normal,
            end_value=args.lambda_normal if args.lambda_normal_end is None else args.lambda_normal_end,
            start_step=max(1, args.lambda_normal_decay_start),
        )
        current_lambda_anomaly = linear_schedule(
            step=step,
            total_steps=args.steps,
            start_value=args.lambda_anomaly if args.lambda_anomaly_start is None else args.lambda_anomaly_start,
            end_value=args.lambda_anomaly if args.lambda_anomaly_end is None else args.lambda_anomaly_end,
            start_step=1,
        )
        current_lr = cosine_decay_lr(
            step=step,
            total_steps=args.steps,
            base_lr=args.lr,
            start_step=max(1, args.lr_decay_start),
            min_ratio=args.lr_min_ratio,
        )
        for group in optimizer.param_groups:
            group["lr"] = current_lr
        objective.lambda_normal = current_lambda_normal
        objective.lambda_anomaly = current_lambda_anomaly

        batch = sample_balanced_batch(normal_records, trainable_anomalies, args.batch_size, rng)
        images, masks_t, basis_t, labels = build_batch_tensors_dino(
            batch,
            dino_transform,
            mask_transform,
            semantic_basis_by_class,
            clip_teacher,
            args,
            device,
        )

        with torch.no_grad():
            features = dino_model.encode_image_from_tensors(images, shape="img")[layer_index].float()

        out = model(features, semantic_basis=basis_t)
        loss_stats = objective(
            raw_features=features,
            refined_features=out.refined,
            alpha=out.alpha,
            anomaly_mask=masks_t,
            semantic_basis=out.semantic_basis,
        )

        final_weight = model.core_refiner.alpha_head.head[-1].weight
        grad_normal = torch.autograd.grad(loss_stats["term_normal_gas"], final_weight, retain_graph=True, allow_unused=True)[0]
        grad_anomaly = torch.autograd.grad(loss_stats["term_anomaly_gas"], final_weight, retain_graph=True, allow_unused=True)[0]
        grad_pairwise = torch.autograd.grad(loss_stats["term_pairwise"], final_weight, retain_graph=True, allow_unused=True)[0]

        optimizer.zero_grad()
        loss_stats["loss"].backward()
        optimizer.step()

        raw_tokens = features.flatten(2).transpose(1, 2)
        refined_tokens = out.refined.flatten(2).transpose(1, 2)
        local_mean_tokens = out.local_mean.flatten(2).transpose(1, 2)
        local_desc_tokens = out.local_descriptors.flatten(2).transpose(1, 2)
        anomaly_patch_mask = F.interpolate(masks_t.float(), size=(token_side, token_side), mode="nearest").reshape(len(batch), -1) > 0.5
        normal_patch_mask = ~anomaly_patch_mask

        raw_residual = compute_patch_residual(raw_tokens, local_mean_tokens)
        refined_residual = compute_patch_residual(refined_tokens, local_mean_tokens)
        raw_residual_n, valid_n = imagewise_mean(raw_residual, normal_patch_mask)
        raw_residual_a, valid_a = imagewise_mean(raw_residual, anomaly_patch_mask)
        refined_residual_n, _ = imagewise_mean(refined_residual, normal_patch_mask)
        refined_residual_a, _ = imagewise_mean(refined_residual, anomaly_patch_mask)
        desc_n, valid_desc_n = imagewise_mean_vec(local_desc_tokens, normal_patch_mask)
        desc_a, valid_desc_a = imagewise_mean_vec(local_desc_tokens, anomaly_patch_mask)

        token_anomaly_counts = anomaly_patch_mask.sum(dim=1)
        anomaly_image_mask = torch.tensor(labels, device=device, dtype=torch.bool)
        anomaly_token_counts_only = token_anomaly_counts[anomaly_image_mask]
        alpha_flat = out.alpha.flatten(2).transpose(1, 2).squeeze(-1)
        alpha_std = alpha_flat.std(dim=1, unbiased=False).mean()
        grad_cosine = float("nan")
        if grad_normal is not None and grad_anomaly is not None:
            gn = grad_normal.reshape(-1)
            ga = grad_anomaly.reshape(-1)
            if gn.norm().item() > 0 and ga.norm().item() > 0:
                grad_cosine = float(F.cosine_similarity(gn.unsqueeze(0), ga.unsqueeze(0), dim=1).item())

        row = {
            "step": step,
            "loss": float(loss_stats["loss"].detach().item()),
            "loss_sem": float(loss_stats["loss_sem"].item()),
            "loss_pairwise": float(loss_stats["loss_pairwise"].item()),
            "loss_normal_gas": float(loss_stats["loss_normal_gas"].item()),
            "loss_anomaly_gas": float(loss_stats["loss_anomaly_gas"].item()),
            "lambda_normal_current": current_lambda_normal,
            "lambda_anomaly_current": current_lambda_anomaly,
            "lr_current": current_lr,
            "alpha_normal_mean": float(loss_stats["alpha_normal_mean"].item()),
            "alpha_anomaly_mean": float(loss_stats["alpha_anomaly_mean"].item()),
            "alpha_gap": float(loss_stats["alpha_normal_mean"].item() - loss_stats["alpha_anomaly_mean"].item()),
            "raw_residual_normal": float(raw_residual_n[valid_n].mean().item()) if valid_n.any() else float("nan"),
            "refined_residual_normal": float(refined_residual_n[valid_n].mean().item()) if valid_n.any() else float("nan"),
            "raw_residual_anomaly": float(raw_residual_a[valid_a].mean().item()) if valid_a.any() else float("nan"),
            "refined_residual_anomaly": float(refined_residual_a[valid_a].mean().item()) if valid_a.any() else float("nan"),
            "input_l2_dist": float(torch.norm(desc_n[valid_desc_n].mean(dim=0) - desc_a[valid_desc_a].mean(dim=0), p=2).item()) if valid_desc_n.any() and valid_desc_a.any() else float("nan"),
            "alpha_std_mean": float(alpha_std.item()),
            "grad_normal_gas_norm": float(grad_normal.norm().item()) if grad_normal is not None else 0.0,
            "grad_anomaly_gas_norm": float(grad_anomaly.norm().item()) if grad_anomaly is not None else 0.0,
            "grad_pairwise_norm": float(grad_pairwise.norm().item()) if grad_pairwise is not None else 0.0,
            "grad_cosine_normal_vs_anomaly": grad_cosine,
            "anomaly_image_count_in_batch": int(sum(labels)),
            "anomaly_zero_token_fraction_in_batch": float((anomaly_token_counts_only == 0).float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
            "anomaly_token_count_mean_in_batch": float(anomaly_token_counts_only.float().mean().item()) if anomaly_token_counts_only.numel() > 0 else float("nan"),
        }

        if step % args.eval_interval == 0 or step == 1 or step == args.steps:
            probe_metrics = evaluate_probe_batch_dino(
                model=model,
                objective=objective,
                dino_model=dino_model,
                clip_teacher=clip_teacher,
                probe_batch=probe_batch,
                semantic_basis_by_class=semantic_basis_by_class,
                dino_transform=dino_transform,
                mask_transform=mask_transform,
                args=args,
                device=device,
                layer_index=layer_index,
                token_side=token_side,
            )
            row.update(probe_metrics)
            if probe_metrics["probe_score"] > best_probe_score:
                best_probe_score = probe_metrics["probe_score"]
                best_probe_step = step
                best_probe_metrics = {"step": float(step), **probe_metrics}
        step_rows.append(row)
        print(
            f"[step {step}] loss={row['loss']:.4f} sem={row['loss_sem']:.4f} pair={row['loss_pairwise']:.4f} "
            f"ln={row['lambda_normal_current']:.4f} la={row['lambda_anomaly_current']:.4f} "
            f"lr={row['lr_current']:.5f} alpha_n={row['alpha_normal_mean']:.4f} "
            f"alpha_a={row['alpha_anomaly_mean']:.4f} gap={row['alpha_gap']:.4f} "
            f"in_l2={row['input_l2_dist']:.4f} alpha_std={row['alpha_std_mean']:.4f} "
            f"gN={row['grad_normal_gas_norm']:.4e} gA={row['grad_anomaly_gas_norm']:.4e} "
            f"gP={row['grad_pairwise_norm']:.4e} cos={row['grad_cosine_normal_vs_anomaly']:.4f} "
            f"zero_tok={row['anomaly_zero_token_fraction_in_batch']:.4f} "
            f"t={time.time() - tic:.2f}s",
            flush=True,
        )

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(step_rows[0].keys()))
        writer.writeheader()
        writer.writerows(step_rows)

    summary = {
        "config": vars(args),
        "dataset_audit": audit,
        "trainable_anomaly_pool": trainable_meta,
        "bridge_init_stats": bridge_stats,
        "final_step": step_rows[-1],
        "best_probe_metrics": best_probe_metrics,
        "best_probe_step": best_probe_step,
        "best_alpha_gap": float(max(row["alpha_gap"] for row in step_rows)),
        "min_anomaly_zero_token_fraction": float(min(row["anomaly_zero_token_fraction_in_batch"] for row in step_rows)),
        "mean_alpha_gap": float(sum(row["alpha_gap"] for row in step_rows) / len(step_rows)),
    }
    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    steps = [row["step"] for row in step_rows]
    gaps = [row["alpha_gap"] for row in step_rows]
    probe_gaps = [row.get("probe_alpha_gap", float("nan")) for row in step_rows]
    fig, ax = plt.subplots(1, 1, figsize=(7, 4))
    ax.plot(steps, gaps, label="train gap")
    ax.plot(steps, probe_gaps, label="probe gap")
    ax.set_xlabel("step")
    ax.set_ylabel("alpha gap")
    ax.legend()
    ax.grid(True, alpha=0.2)
    fig.tight_layout()
    fig.savefig(png_path, dpi=200)

    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_png={png_path}")
    print(json.dumps(summary["final_step"], indent=2))


if __name__ == "__main__":
    main()
