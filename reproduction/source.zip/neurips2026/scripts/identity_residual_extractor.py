from __future__ import annotations

import math
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F


class IdentityResidualExtractor(nn.Module):
    """
    Identity-Residual Decomposition for frozen CLIP visual tokens.

    Input:
        v_in:   [B, N, D] visual patch tokens from a frozen backbone
        E_norm: [K, D]    normal prompt bank
        E_anom: [M, D]    anomaly prompt bank (optional for scoring)

    Output:
        A dict containing:
            f_id           [B, N, D] identity-support feature map
            f_res          [B, N, D] defect-residual feature map
            score          [B, N]    parameter-free anomaly score map
            loss_ortho     []        orthogonality loss for f_res vs normal text subspace
            id_support     [B, N]    normal support score
            res_evidence   [B, N]    residual evidence score
    """

    def __init__(
        self,
        dim: int,
        num_id_queries: int = 32,
        num_res_queries: int = 32,
        detach_residual_input: bool = True,
        init_std: float = 0.02,
        eps: float = 1e-6,
    ) -> None:
        super().__init__()
        self.dim = int(dim)
        self.num_id_queries = int(num_id_queries)
        self.num_res_queries = int(num_res_queries)
        self.detach_residual_input = bool(detach_residual_input)
        self.eps = float(eps)

        self.query_id = nn.Parameter(torch.randn(self.num_id_queries, self.dim) * float(init_std))
        self.query_res = nn.Parameter(torch.randn(self.num_res_queries, self.dim) * float(init_std))

        # Independent projections per branch are intentional.
        # Q1: this prevents L_ortho on f_res from directly contaminating the id branch.
        self.q_proj_id = nn.Linear(self.dim, self.dim, bias=False)
        self.k_proj_id = nn.Linear(self.dim, self.dim, bias=False)
        self.v_proj_id = nn.Linear(self.dim, self.dim, bias=False)
        self.patch_q_proj_id = nn.Linear(self.dim, self.dim, bias=False)
        self.token_k_proj_id = nn.Linear(self.dim, self.dim, bias=False)

        self.q_proj_res = nn.Linear(self.dim, self.dim, bias=False)
        self.k_proj_res = nn.Linear(self.dim, self.dim, bias=False)
        self.v_proj_res = nn.Linear(self.dim, self.dim, bias=False)
        self.patch_q_proj_res = nn.Linear(self.dim, self.dim, bias=False)
        self.token_k_proj_res = nn.Linear(self.dim, self.dim, bias=False)

        for mod in [
            self.q_proj_id,
            self.k_proj_id,
            self.v_proj_id,
            self.patch_q_proj_id,
            self.token_k_proj_id,
            self.q_proj_res,
            self.k_proj_res,
            self.v_proj_res,
            self.patch_q_proj_res,
            self.token_k_proj_res,
        ]:
            nn.init.xavier_uniform_(mod.weight, gain=0.25)

    def _cross_attend(
        self,
        v_src: torch.Tensor,
        query_bank: torch.Tensor,
        q_proj: nn.Linear,
        k_proj: nn.Linear,
        v_proj: nn.Linear,
        patch_q_proj: nn.Linear,
        token_k_proj: nn.Linear,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Two-stage cross-attention:
        1) learnable queries gather information from visual tokens
        2) gathered token features are re-projected back to patch space
        """
        bsz = v_src.shape[0]
        q_tok = q_proj(query_bank).unsqueeze(0).expand(bsz, -1, -1)
        k_vis = k_proj(v_src)
        v_vis = v_proj(v_src)

        attn_extract = torch.softmax(torch.matmul(q_tok, k_vis.transpose(1, 2)) / math.sqrt(self.dim), dim=-1)
        token_feat = torch.matmul(attn_extract, v_vis)

        q_patch = patch_q_proj(v_src)
        k_tok = token_k_proj(token_feat)
        attn_reproj = torch.softmax(torch.matmul(q_patch, k_tok.transpose(1, 2)) / math.sqrt(self.dim), dim=-1)
        patch_feat = torch.matmul(attn_reproj, token_feat)
        return patch_feat, attn_extract, attn_reproj

    def _normal_basis(self, E_norm: torch.Tensor) -> torch.Tensor:
        """
        Build an orthonormal basis for the normal text subspace.

        We use SVD instead of inverse-based projectors to stay numerically stable
        when the prompt bank is rank-deficient.
        """
        E_norm = F.normalize(E_norm.float(), p=2, dim=-1, eps=self.eps)
        _, s, vh = torch.linalg.svd(E_norm, full_matrices=False)
        rank = int((s > self.eps).sum().item())
        if rank == 0:
            return E_norm.new_zeros((self.dim, 0))
        return vh[:rank].transpose(0, 1).contiguous()

    def orthogonality_loss(self, f_res: torch.Tensor, E_norm: torch.Tensor) -> torch.Tensor:
        """
        Q2: Do not minimize cosine similarity directly.
        Minimizing cosine could drive the model to anti-correlation (-1), not orthogonality (0).

        We instead penalize the squared projection energy of f_res onto the normal subspace:
            L_ortho = || f_res * B_norm ||_2^2
        where B_norm is an orthonormal basis of span(E_norm).

        This is a null-space projection penalty. It is:
        - exact for subspace orthogonality
        - smooth around zero
        - immune to the anti-correlation trap because the sign disappears after squaring
        """
        basis = self._normal_basis(E_norm)
        if basis.shape[1] == 0:
            return f_res.new_zeros(())
        f_res_n = F.normalize(f_res.float(), p=2, dim=-1, eps=self.eps)
        coeff = torch.matmul(f_res_n, basis)
        return coeff.pow(2).sum(dim=-1).mean()

    def anomaly_score(
        self,
        f_id: torch.Tensor,
        f_res: torch.Tensor,
        E_norm: torch.Tensor,
        E_anom: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Q3: parameter-free score.

        We avoid a manual lambda-weighted sum. Instead we use object-conditioned gating:
            score = residual_evidence * normalized_identity_support

        - identity_support comes from similarity to E_norm
        - residual_evidence comes from similarity to E_anom when available
          or the norm of f_res as a fallback
        - normalized_identity_support suppresses background regions where object support is weak

        This stays parameter-free while avoiding the background blow-up of ratio-based scoring.
        """
        f_id_n = F.normalize(f_id.float(), p=2, dim=-1, eps=self.eps)
        f_res_n = F.normalize(f_res.float(), p=2, dim=-1, eps=self.eps)
        E_norm_n = F.normalize(E_norm.float(), p=2, dim=-1, eps=self.eps)

        id_support = torch.matmul(f_id_n, E_norm_n.T).max(dim=-1).values.clamp_min(0.0)
        if E_anom is None:
            res_evidence = f_res.float().norm(dim=-1)
        else:
            E_anom_n = F.normalize(E_anom.float(), p=2, dim=-1, eps=self.eps)
            res_evidence = torch.matmul(f_res_n, E_anom_n.T).max(dim=-1).values.clamp_min(0.0)

        id_gate = id_support / id_support.amax(dim=1, keepdim=True).clamp_min(self.eps)
        score = res_evidence * id_gate
        return score, id_support, res_evidence

    def forward(
        self,
        v_in: torch.Tensor,
        E_norm: torch.Tensor,
        E_anom: torch.Tensor | None = None,
        return_aux: bool = True,
    ) -> dict[str, Any]:
        v_in = v_in.float()

        # Q1: Gradient interference control.
        #
        # The backbone is assumed frozen, but we still make the residual branch consume
        # a detached copy of visual tokens. This ensures that L_ortho cannot leak back
        # into any upstream trainable producer of v_in if the caller later inserts one.
        #
        # Identity and residual branches also use separate Q/K/V projections, so
        # branch-specific losses never share trainable branch parameters.
        v_res_src = v_in.detach() if self.detach_residual_input else v_in

        f_id, attn_id, reproj_id = self._cross_attend(
            v_in,
            self.query_id,
            self.q_proj_id,
            self.k_proj_id,
            self.v_proj_id,
            self.patch_q_proj_id,
            self.token_k_proj_id,
        )
        f_res, attn_res, reproj_res = self._cross_attend(
            v_res_src,
            self.query_res,
            self.q_proj_res,
            self.k_proj_res,
            self.v_proj_res,
            self.patch_q_proj_res,
            self.token_k_proj_res,
        )

        loss_ortho = self.orthogonality_loss(f_res, E_norm)
        score, id_support, res_evidence = self.anomaly_score(f_id, f_res, E_norm, E_anom=E_anom)

        out = {
            "f_id": f_id,
            "f_res": f_res,
            "score": score,
            "loss_ortho": loss_ortho,
            "id_support": id_support,
            "res_evidence": res_evidence,
        }
        if return_aux:
            out.update(
                {
                    "attn_id": attn_id,
                    "attn_res": attn_res,
                    "reproj_id": reproj_id,
                    "reproj_res": reproj_res,
                    "detach_residual_input": self.detach_residual_input,
                }
            )
        return out
