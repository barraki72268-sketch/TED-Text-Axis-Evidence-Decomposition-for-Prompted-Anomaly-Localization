from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    build_dataset,
    decision_axis,
    decompose_with_axis,
    get_or_collect_source_patch_banks,
    logmeanexp_negative_sqdist_1d,
    project_bank,
)
from probe_anomalyclip_text_decomposition_score import patch_text_score  # noqa: E402


def denormalize_image(img_tensor: torch.Tensor) -> np.ndarray:
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = np.transpose(img_tensor.cpu().numpy(), (1, 2, 0))
    img = np.clip((img * std + mean) * 255.0, 0, 255).astype(np.uint8)
    return img


def apply_ad_scoremap(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.5, colormap: int = cv2.COLORMAP_JET) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, colormap)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return (alpha * image.astype(float) + (1 - alpha) * scoremap.astype(float)).astype(np.uint8)


def normalize_map(arr: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((arr - vmin) / denom, 0.0, 1.0)


def percentile_bounds(arr: np.ndarray, lo: float = 1.0, hi: float = 99.0) -> tuple[float, float]:
    lo_v = float(np.percentile(arr, lo))
    hi_v = float(np.percentile(arr, hi))
    if hi_v <= lo_v:
        lo_v = float(arr.min())
        hi_v = float(arr.max())
    return lo_v, hi_v


def symmetric_abs_bound(arr: np.ndarray, q: float = 99.0) -> float:
    return max(float(np.percentile(np.abs(arr), q)), 1e-8)


def overlay_binary_mask(image: np.ndarray, mask: np.ndarray, color=(255, 80, 40), alpha: float = 0.55) -> np.ndarray:
    out = image.astype(np.float32).copy()
    color_arr = np.array(color, dtype=np.float32)
    out[mask] = (1 - alpha) * out[mask] + alpha * color_arr
    return np.clip(out, 0, 255).astype(np.uint8)


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    order = np.argsort(s)
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, s.size + 1)
    pos_ranks = ranks[: pos.size].sum()
    return float((pos_ranks - pos.size * (pos.size + 1) / 2.0) / (pos.size * neg.size))


def balanced_values(pos: np.ndarray, neg: np.ndarray, seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    if pos.size == 0 or neg.size == 0:
        return pos, neg
    n = min(pos.size, neg.size)
    if pos.size > n:
        pos = pos[rng.choice(pos.size, size=n, replace=False)]
    if neg.size > n:
        neg = neg[rng.choice(neg.size, size=n, replace=False)]
    return pos, neg


def pick_sample(dataset, target_classes: set[str] | None, sample_index: int):
    matches = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        if target_classes is not None and item["cls_name"] not in target_classes:
            continue
        anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
        if anomaly_flag == 0:
            continue
        matches.append(item)
    if sample_index >= len(matches):
        raise IndexError(f"sample_index={sample_index} out of range for {len(matches)} anomaly images")
    return matches[sample_index]


def compute_maps(
    model,
    text_pair: torch.Tensor,
    axis: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    image: torch.Tensor,
    features_list: list[int],
    tau: float,
    target_h: int,
    target_w: int,
) -> tuple[np.ndarray, np.ndarray]:
    bank_device = axis.device
    fp_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in fp_banks.items()}
    def_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in def_banks.items()}
    projected_banks = {}
    for layer_idx in range(len(features_list)):
        fp_coeff, _ = project_bank(fp_banks[layer_idx], axis)
        def_coeff, _ = project_bank(def_banks[layer_idx], axis)
        projected_banks[layer_idx] = {
            "fp_parallel_coeff": fp_coeff,
            "def_parallel_coeff": def_coeff,
        }

    with torch.no_grad():
        _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
        txt_maps = []
        parallel_maps = []
        for layer_idx, patch_feature in enumerate(patch_features):
            patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
            patch_coeff = patch @ axis
            banks = projected_banks[layer_idx]
            s_txt = patch_text_score(patch_feature, text_pair)
            q_fp_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["fp_parallel_coeff"], tau=tau)
            q_def_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["def_parallel_coeff"], tau=tau)
            h = int(round(patch.shape[0] ** 0.5))
            txt_maps.append(s_txt.reshape(h, h).detach().cpu().numpy())
            parallel_maps.append((q_def_parallel - q_fp_parallel).reshape(h, h).detach().cpu().numpy())

    def resize_map(arr: np.ndarray) -> np.ndarray:
        return (
            F.interpolate(
                torch.from_numpy(arr).unsqueeze(0).unsqueeze(0).float(),
                size=(target_h, target_w),
                mode="bilinear",
                align_corners=False,
            )[0, 0]
            .cpu()
            .numpy()
        )

    s_txt_map = resize_map(np.mean(np.stack(txt_maps, axis=0), axis=0))
    parallel_map = resize_map(np.mean(np.stack(parallel_maps, axis=0), axis=0))
    return s_txt_map, parallel_map


def sample_scatter_points(base: np.ndarray, parallel: np.ndarray, gt_mask: np.ndarray, fp_mask: np.ndarray, max_points: int = 12000):
    rng = np.random.default_rng(0)
    groups = {
        "inside": gt_mask,
        "fp_outside": fp_mask,
        "other_outside": (~gt_mask) & (~fp_mask),
    }
    out = []
    quota = max(1, max_points // 3)
    for name, mask in groups.items():
        ys, xs = np.where(mask)
        if ys.size == 0:
            continue
        idx = np.arange(ys.size)
        if idx.size > quota:
            idx = rng.choice(idx, size=quota, replace=False)
        out.append(
            {
                "name": name,
                "x": base[ys[idx], xs[idx]],
                "y": parallel[ys[idx], xs[idx]],
            }
        )
    return out


def main():
    parser = argparse.ArgumentParser("Generate baseline vs parallel-margin dashboard")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--source_dataset", type=str, default="mvtec")
    parser.add_argument("--target_root", type=str, required=True)
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--target_classes", nargs="+", required=True)
    parser.add_argument("--heldout_class", type=str, default="bottle")
    parser.add_argument("--device", type=str, default="cuda:1" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--checkpoint_path", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"))
    parser.add_argument("--save_dir", type=str, required=True)
    parser.add_argument("--sample_index", type=int, default=0)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    args = parser.parse_args()

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    axis = decision_axis(learned_pair).to(args.device)

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=args.heldout_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.bank_cache_path,
        refresh_bank_cache=args.refresh_bank_cache,
    )

    dataset = build_dataset(args.target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    item = pick_sample(dataset, set(args.target_classes), args.sample_index)
    specie_name = item.get("specie_name", item.get("cls_name", "unknown"))
    image = item["img"].unsqueeze(0).to(args.device)
    gt_mask = item["img_mask"][0].cpu().numpy().astype(bool)
    input_img = denormalize_image(item["img"])
    s_txt_map, parallel_map = compute_maps(
        model=model,
        text_pair=learned_pair,
        axis=axis,
        fp_banks=fp_banks,
        def_banks=def_banks,
        image=image,
        features_list=args.features_list,
        tau=args.tau,
        target_h=gt_mask.shape[0],
        target_w=gt_mask.shape[1],
    )
    fp_mask = (~gt_mask) & (parallel_map < 0.0)

    base_vmin, base_vmax = percentile_bounds(s_txt_map, 1.0, 99.0)
    parallel_abs = symmetric_abs_bound(parallel_map, 99.0)
    base_norm = normalize_map(s_txt_map, base_vmin, base_vmax)
    parallel_norm = normalize_map(parallel_map, -parallel_abs, parallel_abs)
    parallel_pos = np.maximum(parallel_map, 0.0)
    parallel_neg = np.maximum(-parallel_map, 0.0)
    parallel_pos_max = max(float(np.percentile(parallel_pos, 99.0)), 1e-8)
    parallel_neg_max = max(float(np.percentile(parallel_neg, 99.0)), 1e-8)
    parallel_pos_norm = normalize_map(parallel_pos, 0.0, parallel_pos_max)
    parallel_neg_norm = normalize_map(parallel_neg, 0.0, parallel_neg_max)
    rel_diff = parallel_norm - base_norm
    rel_diff_abs = symmetric_abs_bound(rel_diff, 99.0)

    scatter_groups = sample_scatter_points(s_txt_map, parallel_map, gt_mask, fp_mask)
    suppressed_outside = (~gt_mask) & (base_norm >= 0.70) & (parallel_norm <= 0.40)
    baseline_inside = s_txt_map[gt_mask]
    baseline_outside = s_txt_map[~gt_mask]
    parallel_inside = parallel_map[gt_mask]
    parallel_outside = parallel_map[~gt_mask]
    parallel_fpoutside = parallel_map[fp_mask]
    baseline_inside_bal, baseline_outside_bal = balanced_values(baseline_inside, baseline_outside, seed=0)
    parallel_inside_bal, parallel_outside_bal = balanced_values(parallel_inside, parallel_outside, seed=1)
    _, parallel_fpoutside_bal = balanced_values(parallel_inside, parallel_fpoutside, seed=2)
    baseline_auc = safe_auc(baseline_inside, baseline_outside)
    parallel_auc = safe_auc(parallel_inside, parallel_outside)
    parallel_fp_auc = safe_auc(parallel_inside, parallel_fpoutside)

    heatmap_fig = plt.figure(figsize=(20, 10))
    heat_gs = heatmap_fig.add_gridspec(2, 4)
    heat_axes = np.array([[heatmap_fig.add_subplot(heat_gs[r, c]) for c in range(4)] for r in range(2)])

    heat_axes[0, 0].imshow(input_img)
    heat_axes[0, 0].set_title("input")
    heat_axes[0, 0].axis("off")
    heat_axes[0, 1].imshow(gt_mask, cmap="gray")
    heat_axes[0, 1].set_title("GT mask")
    heat_axes[0, 1].axis("off")
    heat_axes[0, 2].imshow(apply_ad_scoremap(input_img, base_norm, colormap=cv2.COLORMAP_JET))
    heat_axes[0, 2].set_title("baseline overlay")
    heat_axes[0, 2].axis("off")
    heat_axes[0, 3].imshow(apply_ad_scoremap(input_img, parallel_norm, colormap=cv2.COLORMAP_COOL))
    heat_axes[0, 3].set_title("ours overlay")
    heat_axes[0, 3].axis("off")

    heat_axes[1, 0].imshow(base_norm, cmap="jet", vmin=0.0, vmax=1.0)
    heat_axes[1, 0].set_title("baseline heatmap")
    heat_axes[1, 0].axis("off")
    heat_axes[1, 1].imshow(parallel_map, cmap="coolwarm", vmin=-parallel_abs, vmax=parallel_abs)
    heat_axes[1, 1].set_title("ours heatmap")
    heat_axes[1, 1].axis("off")
    heat_axes[1, 2].imshow(parallel_pos_norm, cmap="Reds", vmin=0.0, vmax=1.0)
    heat_axes[1, 2].contour(gt_mask.astype(float), levels=[0.5], colors="black", linewidths=0.7)
    heat_axes[1, 2].set_title("ours positive support")
    heat_axes[1, 2].axis("off")
    gain_overlay = overlay_binary_mask(input_img, suppressed_outside, color=(255, 60, 60), alpha=0.60)
    heat_axes[1, 3].imshow(gain_overlay)
    heat_axes[1, 3].set_title("outside suppressed by ours")
    heat_axes[1, 3].axis("off")

    hist_fig = plt.figure(figsize=(18, 5.5))
    hist_gs = hist_fig.add_gridspec(1, 3)
    hist_axes = np.array([hist_fig.add_subplot(hist_gs[0, i]) for i in range(3)])

    hist_axes[0].hist(baseline_outside_bal, bins=50, density=True, histtype="step", linewidth=1.8, label="outside", color="tab:blue")
    hist_axes[0].hist(baseline_inside_bal, bins=50, density=True, histtype="step", linewidth=1.8, label="inside", color="tab:red")
    hist_axes[0].axvline(float(baseline_inside.mean()), color="tab:red", lw=1, ls="--")
    hist_axes[0].axvline(float(baseline_outside.mean()), color="tab:blue", lw=1, ls="--")
    hist_axes[0].set_title(f"baseline histogram (AUC={baseline_auc:.3f})")
    hist_axes[0].legend()
    hist_axes[1].hist(parallel_outside_bal, bins=50, density=True, histtype="step", linewidth=1.8, label="outside", color="tab:blue")
    hist_axes[1].hist(parallel_inside_bal, bins=50, density=True, histtype="step", linewidth=1.8, label="inside", color="tab:red")
    if parallel_fpoutside_bal.size:
        hist_axes[1].hist(parallel_fpoutside_bal, bins=50, density=True, histtype="step", linewidth=1.8, label="fp-outside", color="tab:green")
    hist_axes[1].axvline(float(parallel_inside.mean()), color="tab:red", lw=1, ls="--")
    hist_axes[1].axvline(float(parallel_outside.mean()), color="tab:blue", lw=1, ls="--")
    if parallel_fpoutside.size:
        hist_axes[1].axvline(float(parallel_fpoutside.mean()), color="tab:green", lw=1, ls="--")
    hist_axes[1].set_title(f"ours histogram (out AUC={parallel_auc:.3f}, fp AUC={parallel_fp_auc:.3f})")
    hist_axes[1].legend()

    colors = {"inside": "tab:red", "fp_outside": "tab:green", "other_outside": "tab:blue"}
    for grp in scatter_groups:
        hist_axes[2].scatter(grp["x"], grp["y"], s=4, alpha=0.35, label=grp["name"], c=colors[grp["name"]])
    hist_axes[2].axhline(0.0, color="black", lw=1, ls="--")
    hist_axes[2].set_xlabel("baseline text score")
    hist_axes[2].set_ylabel("ours parallel margin")
    hist_axes[2].set_title("score vs margin")
    hist_axes[2].legend(markerscale=3)

    text_lines = [
        f"class={item['cls_name']} / specie={specie_name}",
        f"baseline inside mean={float(s_txt_map[gt_mask].mean()):.4f}",
        f"baseline outside mean={float(s_txt_map[~gt_mask].mean()):.4f}",
        f"baseline range=[{base_vmin:.4f}, {base_vmax:.4f}]",
        f"parallel inside mean={float(parallel_map[gt_mask].mean()):.4f}",
        f"parallel outside mean={float(parallel_map[~gt_mask].mean()):.4f}",
        f"parallel fp-outside mean={float(parallel_map[fp_mask].mean()) if fp_mask.any() else float('nan'):.4f}",
        f"parallel absmax={parallel_abs:.4f}",
        f"positive support max={parallel_pos_max:.4f}",
        f"negative support max={parallel_neg_max:.4f}",
        f"suppressed outside px={int(suppressed_outside.sum())}",
        f"bank fp/def per layer={bank_stats[0]['num_fp']}/{bank_stats[0]['num_defect']}",
        "baseline/ours heatmaps use independent robust scaling",
        "histograms are balanced+density, so shape not count",
    ]
    heatmap_fig.text(0.70, 0.02, "\n".join(text_lines), va="bottom", ha="left", fontsize=9.2, family="monospace")
    heatmap_fig.tight_layout()
    hist_fig.tight_layout()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.target_dataset}_{'_'.join(args.target_classes)}_{item['cls_name']}_{specie_name}_{args.sample_index}"
    heatmap_png_path = save_dir / f"{stem}_heatmap.png"
    hist_png_path = save_dir / f"{stem}_hist.png"
    heatmap_fig.savefig(heatmap_png_path, dpi=180, bbox_inches="tight")
    hist_fig.savefig(hist_png_path, dpi=180, bbox_inches="tight")
    plt.close(heatmap_fig)
    plt.close(hist_fig)

    meta = {
        "target_dataset": args.target_dataset,
        "target_classes": args.target_classes,
        "sample_index": args.sample_index,
        "cls_name": item["cls_name"],
        "specie_name": specie_name,
        "baseline_inside_mean": float(s_txt_map[gt_mask].mean()),
        "baseline_outside_mean": float(s_txt_map[~gt_mask].mean()),
        "parallel_inside_mean": float(parallel_map[gt_mask].mean()),
        "parallel_outside_mean": float(parallel_map[~gt_mask].mean()),
        "parallel_fpoutside_mean": float(parallel_map[fp_mask].mean()) if fp_mask.any() else None,
        "baseline_min": base_vmin,
        "baseline_max": base_vmax,
        "parallel_absmax": parallel_abs,
        "baseline_inside_vs_outside_auc": baseline_auc,
        "parallel_inside_vs_outside_auc": parallel_auc,
        "parallel_inside_vs_fpoutside_auc": parallel_fp_auc,
        "num_suppressed_outside_pixels": int(suppressed_outside.sum()),
        "num_fp_pixels": int(fp_mask.sum()),
        "bank_stats": bank_stats,
        "bank_cache_path": str(bank_cache_path),
        "bank_cache_meta": bank_cache_meta,
        "heatmap_png": str(heatmap_png_path),
        "hist_png": str(hist_png_path),
    }
    json_path = save_dir / f"{stem}.json"
    with open(json_path, "w") as f:
        json.dump(meta, f, indent=2)
    print(json.dumps({"heatmap_png": str(heatmap_png_path), "hist_png": str(hist_png_path), "json": str(json_path), "meta": meta}, indent=2))


if __name__ == "__main__":
    main()
