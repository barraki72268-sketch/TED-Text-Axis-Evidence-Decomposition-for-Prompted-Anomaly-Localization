from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from WinCLIP import WinClipAD  # noqa: E402
from neurips2026.scripts.eval_winclip_oneclass_featureop import maybe_wrap_feature_op  # noqa: E402
from neurips2026.scripts.probe_realiad_alpha_refiner_winclip_dryrun import extract_scale_groups  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, default="pcb1")
    parser.add_argument("--feature_op", type=str, default="learned_refiner", choices=["learned_refiner"])
    parser.add_argument("--refiner_ckpt", type=str, required=True)
    parser.add_argument("--max_normals", type=int, default=20)
    parser.add_argument("--max_anomalies", type=int, default=20)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="winclip_learned_diag")
    return parser.parse_args()


def build_model(args: argparse.Namespace, device: str, feature_op: str) -> WinClipAD:
    model = WinClipAD(
        out_size_h=args.resolution,
        out_size_w=args.resolution,
        device=device,
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=tuple(args.scales),
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    ).to(device)
    model.eval_mode()
    model.build_text_feature_gallery(args.class_name)

    wrap_args = argparse.Namespace(
        refiner_ckpt=args.refiner_ckpt,
        refiner_ckpts=[],
        class_name=args.class_name,
    )
    maybe_wrap_feature_op(model, feature_op, wrap_args)
    return model


def extract_identity_groups(model: WinClipAD, image_t: torch.Tensor, mask_t: torch.Tensor, target_layer: int):
    patch_mask_flat = (
        F.interpolate(mask_t.float(), size=model.grid_size, mode="nearest")[:, 0].reshape(image_t.shape[0], -1) > 0.5
    )
    return extract_scale_groups(model.model.visual, image_t, patch_mask_flat, target_layer)


def compute_group_diag(tokens: torch.Tensor, window_masks: torch.Tensor, basis: torch.Tensor, refiner) -> dict[str, float]:
    side = int(round(tokens.shape[1] ** 0.5))
    out = refiner(tokens.float(), semantic_basis=basis, spatial_shape=(side, side))
    alpha = out.alpha.reshape(tokens.shape[0], -1)
    masks = window_masks.bool()
    normal = ~masks

    def masked_mean(vals: torch.Tensor, m: torch.Tensor) -> float:
        if int(m.sum().item()) == 0:
            return float("nan")
        return float(vals[m].mean().item())

    raw_sem = torch.einsum("bnc,bck->bnk", tokens.float(), basis.float())
    ref_sem = torch.einsum("bnc,bck->bnk", out.refined.float(), basis.float())
    sem_error = (ref_sem - raw_sem).square().mean(dim=-1)

    return {
        "alpha_normal_mean": masked_mean(alpha, normal),
        "alpha_anomaly_mean": masked_mean(alpha, masks),
        "sem_normal_mean": masked_mean(sem_error, normal),
        "sem_anomaly_mean": masked_mean(sem_error, masks),
    }


def nanmean(vals: list[float]) -> float:
    arr = np.asarray(vals, dtype=np.float64)
    return float(np.nanmean(arr)) if arr.size else float("nan")


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, args.class_name, "test")

    normal_indices = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"][: args.max_normals]
    anomaly_indices = [i for i, rec in enumerate(ds.records) if rec["label"] != "normal"][: args.max_anomalies]
    selected = normal_indices + anomaly_indices

    raw_model = build_model(args, device, "identity")
    learned_model = build_model(args, device, args.feature_op)
    wrapper = learned_model.model.visual
    if not hasattr(wrapper, "refiner") or not hasattr(wrapper, "semantic_basis"):
        raise RuntimeError("learned_refiner wrapper is not active.")
    target_layer = int(wrapper.target_layer)
    base_visual = wrapper.base

    rows: list[dict] = []
    for idx in selected:
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = learned_model.transform(Image.fromarray(image_np)).unsqueeze(0).to(device)
        visual_dtype = base_visual.conv1.weight.dtype
        image_t = image_t.to(dtype=visual_dtype)

        mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
        mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)

        with torch.no_grad():
            raw_score = np.asarray(raw_model(image_t)[0], dtype=np.float32)
            learned_score = np.asarray(learned_model(image_t)[0], dtype=np.float32)

            groups = extract_identity_groups(learned_model, image_t, mask_t, target_layer)
            basis_stats = []
            for group in groups:
                n_windows = int(group["n_windows"])
                basis_group = wrapper.semantic_basis.to(device=group["tokens"].device, dtype=torch.float32).repeat(
                    n_windows, 1, 1
                )
                basis_stats.append(
                    compute_group_diag(
                        tokens=group["tokens"],
                        window_masks=group["window_masks"],
                        basis=basis_group,
                        refiner=wrapper.refiner,
                    )
                )

        row = {
            "name": name,
            "label": 0 if label == 0 else 1,
            "img_type": img_type,
            "raw_img_score": float(raw_score.max()),
            "learned_img_score": float(learned_score.max()),
            "raw_score_var": float(raw_score.var()),
            "learned_score_var": float(learned_score.var()),
            "raw_score_mean": float(raw_score.mean()),
            "learned_score_mean": float(learned_score.mean()),
            "alpha_normal_mean": nanmean([s["alpha_normal_mean"] for s in basis_stats]),
            "alpha_anomaly_mean": nanmean([s["alpha_anomaly_mean"] for s in basis_stats]),
            "sem_normal_mean": nanmean([s["sem_normal_mean"] for s in basis_stats]),
            "sem_anomaly_mean": nanmean([s["sem_anomaly_mean"] for s in basis_stats]),
        }
        rows.append(row)

    normals = [r for r in rows if r["label"] == 0]
    anomalies = [r for r in rows if r["label"] == 1]

    def split_mean(items: list[dict], key: str) -> float:
        return float(np.mean([r[key] for r in items])) if items else float("nan")

    summary = {
        "class_name": args.class_name,
        "target_layer": target_layer,
        "num_normals": len(normals),
        "num_anomalies": len(anomalies),
        "raw_normal_img_score_mean": split_mean(normals, "raw_img_score"),
        "raw_anomaly_img_score_mean": split_mean(anomalies, "raw_img_score"),
        "learned_normal_img_score_mean": split_mean(normals, "learned_img_score"),
        "learned_anomaly_img_score_mean": split_mean(anomalies, "learned_img_score"),
        "raw_img_score_gap": split_mean(anomalies, "raw_img_score") - split_mean(normals, "raw_img_score"),
        "learned_img_score_gap": split_mean(anomalies, "learned_img_score") - split_mean(normals, "learned_img_score"),
        "raw_normal_score_var_mean": split_mean(normals, "raw_score_var"),
        "raw_anomaly_score_var_mean": split_mean(anomalies, "raw_score_var"),
        "learned_normal_score_var_mean": split_mean(normals, "learned_score_var"),
        "learned_anomaly_score_var_mean": split_mean(anomalies, "learned_score_var"),
        "raw_normal_score_mean_mean": split_mean(normals, "raw_score_mean"),
        "raw_anomaly_score_mean_mean": split_mean(anomalies, "raw_score_mean"),
        "learned_normal_score_mean_mean": split_mean(normals, "learned_score_mean"),
        "learned_anomaly_score_mean_mean": split_mean(anomalies, "learned_score_mean"),
        "alpha_normal_mean_on_anomaly_images": split_mean(anomalies, "alpha_normal_mean"),
        "alpha_anomaly_mean_on_anomaly_images": split_mean(anomalies, "alpha_anomaly_mean"),
        "alpha_gap_on_anomaly_images": split_mean(anomalies, "alpha_normal_mean") - split_mean(anomalies, "alpha_anomaly_mean"),
        "sem_normal_mean_on_anomaly_images": split_mean(anomalies, "sem_normal_mean"),
        "sem_anomaly_mean_on_anomaly_images": split_mean(anomalies, "sem_anomaly_mean"),
        "alpha_normal_mean_on_normal_images": split_mean(normals, "alpha_normal_mean"),
        "sem_normal_mean_on_normal_images": split_mean(normals, "sem_normal_mean"),
    }

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{args.class_name}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary.keys()))
        writer.writeheader()
        writer.writerow(summary)
    with json_path.open("w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)

    print(csv_path)
    print(json_path)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
