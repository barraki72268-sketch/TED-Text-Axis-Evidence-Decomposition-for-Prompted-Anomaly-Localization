#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

DISPLAY = {
    "rawclip_vitb": "ViT-B",
    "rawclip_vitl": "ViT-L",
    "rawclip_vitl14openai": "ViT-L\nOpenAI",
    "rawclip_vith14": "ViT-H",
}


def load_rows(root_name: str) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    root = RESULTS / root_name
    for csv_path in sorted(root.glob("rawclip_*/metrics.csv")):
        with csv_path.open() as f:
            for row in csv.DictReader(f):
                out = dict(row)
                out["root"] = root_name
                out["model_short"] = DISPLAY.get(row["model_key"], row["model_key"])
                for key in (
                    "raw_auc",
                    "visual_auc",
                    "text_auc",
                    "raw_wrong_pair_rate",
                    "visual_wrong_pair_rate",
                    "text_wrong_pair_rate",
                    "raw_d",
                    "visual_d",
                    "text_d",
                ):
                    out[key] = float(row[key])
                rows.append(out)
    return rows


def summarize(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    model_order = []
    for row in rows:
        key = str(row["model_key"])
        if key not in model_order:
            model_order.append(key)
    summary = []
    for key in model_order:
        items = [r for r in rows if r["model_key"] == key]
        entry: dict[str, object] = {
            "model_key": key,
            "model": DISPLAY.get(key, key),
            "n": len(items),
        }
        for score in ("raw", "visual", "text"):
            auc = np.array([float(r[f"{score}_auc"]) * 100.0 for r in items])
            wrong = np.array([float(r[f"{score}_wrong_pair_rate"]) * 100.0 for r in items])
            entry[f"{score}_auc_mean"] = float(auc.mean())
            entry[f"{score}_auc_std"] = float(auc.std(ddof=0))
            entry[f"{score}_wrong_mean"] = float(wrong.mean())
            entry[f"{score}_wrong_std"] = float(wrong.std(ddof=0))
        entry["text_auc_gain"] = entry["text_auc_mean"] - entry["raw_auc_mean"]
        entry["visual_auc_gain"] = entry["visual_auc_mean"] - entry["raw_auc_mean"]
        summary.append(entry)
    return summary


def write_outputs(rows: list[dict[str, object]], summary: list[dict[str, object]], root_name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    row_path = OUT / f"raw_vlm_support_ablation_rows_{root_name}_20260505.csv"
    summary_path = OUT / f"raw_vlm_support_ablation_summary_{root_name}_20260505.csv"
    with row_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with summary_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)

    def fmt(x: float) -> str:
        return f"{x:.1f}"

    tex = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Raw VLM source-support ablation. Values are defect-versus-hard-normal AUC averaged over completed transfer settings. Visual support uses source banks in full feature space, while text-axis support projects query and bank features onto the normal-versus-anomaly text axis.}",
        r"\label{tab:raw_vlm_support_ablation}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\renewcommand{\arraystretch}{1.08}",
        r"\begin{tabular}{lrrrr}",
        r"\toprule",
        r"Backbone & $n$ & Raw prompt & Visual support & Text-axis support \\",
        r"\midrule",
    ]
    for row in summary:
        tex.append(
            f"{str(row['model']).replace(chr(10), ' ')} & {row['n']} & "
            f"{fmt(float(row['raw_auc_mean']))} & {fmt(float(row['visual_auc_mean']))} & {fmt(float(row['text_auc_mean']))} \\\\"
        )
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    (OUT / f"raw_vlm_support_ablation_table_{root_name}_20260505.tex").write_text("\n".join(tex))


def plot(summary: list[dict[str, object]], root_name: str) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    labels = [str(r["model"]) for r in summary]
    x = np.arange(len(labels))
    width = 0.24
    series = [
        ("Raw prompt", "raw_auc_mean", "raw_auc_std", "#B85450"),
        ("Visual support", "visual_auc_mean", "visual_auc_std", "#6F5C8C"),
        ("Text-axis support", "text_auc_mean", "text_auc_std", "#2F6F73"),
    ]

    fig, ax = plt.subplots(figsize=(7.0, 2.65))
    for i, (name, mean_key, std_key, color) in enumerate(series):
        vals = np.array([float(r[mean_key]) for r in summary])
        errs = np.array([float(r[std_key]) for r in summary])
        bars = ax.bar(x + (i - 1) * width, vals, width=width, yerr=errs, capsize=2.5, color=color, label=name)
        if i == 2:
            for bar, val, row in zip(bars, vals, summary):
                gain = float(row["text_auc_gain"])
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    val + 2.2,
                    f"+{gain:.1f}",
                    ha="center",
                    va="bottom",
                    fontsize=7.5,
                    fontweight="bold",
                    color="#1F4F52",
                )
    ax.set_ylabel("Defect-vs-Hard-Normal AUC", fontsize=9.5, fontweight="bold")
    ax.set_ylim(20, 95)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8.5, fontweight="bold")
    ax.tick_params(axis="y", labelsize=8.5)
    ax.grid(axis="y", color="#E6E1D8", lw=0.65)
    ax.set_axisbelow(True)
    ax.legend(frameon=False, loc="upper left", fontsize=8.5, ncol=3)
    ax.set_title("Source evidence in frozen VLMs", loc="left", fontsize=11, fontweight="bold", pad=2)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    fig.tight_layout(pad=0.55)
    fig.savefig(FIG / f"raw_vlm_support_ablation_{root_name}_20260505.pdf", bbox_inches="tight")
    fig.savefig(FIG / f"raw_vlm_support_ablation_{root_name}_20260505.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root_name", default="rawclip_support_ablation_maponly")
    args = ap.parse_args()

    rows = load_rows(args.root_name)
    if not rows:
        raise SystemExit(f"No metrics found under {args.root_name}")
    summary = summarize(rows)
    write_outputs(rows, summary, args.root_name)
    plot(summary, args.root_name)
    print(
        json.dumps(
            {
                "root_name": args.root_name,
                "rows": len(rows),
                "summary_rows": len(summary),
                "figure": f"figure/raw_vlm_support_ablation_{args.root_name}_20260505.pdf",
                "table": f"neurips2026/results/final_metric_and_novelty_tables/raw_vlm_support_ablation_table_{args.root_name}_20260505.tex",
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
