from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import binary_dilation, binary_erosion, label


FEATURE_NAMES = [
    "peak",
    "mean",
    "top10_mean",
    "p90",
    "std",
    "area",
    "fill_ratio",
    "compactness",
    "boundary_mean",
    "interior_mean",
    "boundary_gap",
    "ring_mean",
    "ring_contrast",
    "peak_over_mean",
    "top10_over_mean",
    "aspect_ratio",
]


def safe_mean(arr: np.ndarray) -> float:
    return float(arr.mean()) if arr.size > 0 else 0.0


def topk_mean(vals: np.ndarray, frac: float) -> float:
    if vals.size == 0:
        return 0.0
    k = max(1, int(vals.size * frac))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def iterate_components(binary_mask: np.ndarray):
    labeled, num = label(binary_mask.astype(np.uint8), structure=np.ones((3, 3), dtype=np.uint8))
    for comp_idx in range(1, num + 1):
        yield labeled == comp_idx


def extract_region_descriptor(score_map: np.ndarray, region_mask: np.ndarray) -> dict[str, float]:
    vals = score_map[region_mask]
    area = int(vals.size)
    if area == 0:
        return {}

    ys, xs = np.where(region_mask)
    y0, y1 = ys.min(), ys.max()
    x0, x1 = xs.min(), xs.max()
    bbox_h = int(y1 - y0 + 1)
    bbox_w = int(x1 - x0 + 1)
    bbox_area = float(max(1, bbox_h * bbox_w))
    fill_ratio = float(area / bbox_area)

    eroded = binary_erosion(region_mask, structure=np.ones((3, 3), dtype=bool), border_value=0)
    boundary = region_mask & (~eroded)
    interior = region_mask & eroded

    dilated = binary_dilation(region_mask, structure=np.ones((5, 5), dtype=bool))
    ring = dilated & (~region_mask)

    peak = float(vals.max())
    mean = float(vals.mean())
    p90 = float(np.percentile(vals, 90))
    std = float(vals.std())
    top10 = topk_mean(vals, 0.1)
    boundary_mean = safe_mean(score_map[boundary])
    interior_mean = safe_mean(score_map[interior]) if interior.any() else mean
    ring_mean = safe_mean(score_map[ring]) if ring.any() else 0.0
    perimeter = float(boundary.sum())
    compactness = float((4.0 * math.pi * area) / max(perimeter * perimeter, 1e-8))
    peak_over_mean = float(peak / max(mean, 1e-8))
    top10_over_mean = float(top10 / max(mean, 1e-8))
    aspect_ratio = float(max(bbox_h, bbox_w) / max(1, min(bbox_h, bbox_w)))

    return {
        "peak": peak,
        "mean": mean,
        "top10_mean": top10,
        "p90": p90,
        "std": std,
        "area": float(area),
        "fill_ratio": fill_ratio,
        "compactness": compactness,
        "boundary_mean": boundary_mean,
        "interior_mean": interior_mean,
        "boundary_gap": float(interior_mean - boundary_mean),
        "ring_mean": ring_mean,
        "ring_contrast": float(mean - ring_mean),
        "peak_over_mean": peak_over_mean,
        "top10_over_mean": top10_over_mean,
        "aspect_ratio": aspect_ratio,
    }


def rows_to_matrix(rows: list[dict], feature_names: list[str]) -> np.ndarray:
    return np.asarray([[float(row[name]) for name in feature_names] for row in rows], dtype=np.float32)


def save_rows(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def load_rows(path: Path) -> list[dict]:
    with open(path, "r", newline="") as f:
        return list(csv.DictReader(f))


def save_json(payload: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
