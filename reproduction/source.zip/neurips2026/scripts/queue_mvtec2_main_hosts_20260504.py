#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "adapted_hosts_mvtec2_20260503"
LOG_DIR = RESULTS / "logs"
BANK = ROOT / "neurips2026" / "results" / "bank_cache"
SOURCE_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
TARGET_ROOT = ROOT / "neurips2026" / "results" / "rawvlm_mvtec2_20260503" / "mvtec_ad2_meta_view"


ADACLIP_BACKBONES = {
    "vitb16": {
        "label": "ViT-B/16",
        "backbone": "ViT-B-16",
        "image_size": "224",
        "checkpoint_load_mode": "compatible",
    },
    "vitl_openai224": {
        "label": "ViT-L/14 OpenAI",
        "backbone": "ViT-L-14",
        "image_size": "224",
        "checkpoint_load_mode": "compatible",
    },
    "vitl336": {
        "label": "ViT-L/14-336",
        "backbone": "ViT-L-14-336",
        "image_size": "518",
        "checkpoint_load_mode": "strict",
    },
    "vith14": {
        "label": "ViT-H/14",
        "backbone": "ViT-H-14",
        "image_size": "224",
        "checkpoint_load_mode": "compatible",
    },
}


FAPROMPT_BACKBONES = {
    "vitbplus": {
        "label": "ViT-B/16+",
        "model_name": "ViT-B-16-plus-240",
        "prompt_load_mode": "project_crop",
        "features": ["3", "6", "9", "12"],
        "dpam_layer": "10",
        "image_size": "518",
        "batch_size": "4",
    },
    "vitl_openai": {
        "label": "ViT-L/14 OpenAI",
        "model_name": "ViT-L/14",
        "prompt_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "dpam_layer": "20",
        "image_size": "518",
        "batch_size": "4",
    },
    "vitl336": {
        "label": "ViT-L/14-336",
        "model_name": "ViT-L/14@336px",
        "prompt_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "dpam_layer": "20",
        "image_size": "518",
        "batch_size": "4",
    },
    "vith14": {
        "label": "ViT-H/14",
        "model_name": "ViT-H-14",
        "prompt_load_mode": "project_crop",
        "features": ["8", "16", "24", "32"],
        "dpam_layer": "27",
        "image_size": "518",
        "batch_size": "4",
    },
}


ADAPTCLIP_BACKBONES = {
    "vitbplus": {
        "label": "ViT-B/16+",
        "pretrained_model": "VITB16_PLUS_240",
        "checkpoint_load_mode": "compatible",
        "features": ["3", "6", "9", "12"],
        "batch_size": "4",
    },
    "vitl_openai": {
        "label": "ViT-L/14 OpenAI",
        "pretrained_model": "/home/jinyoung/.cache/clip/ViT-L-14.pt",
        "checkpoint_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "batch_size": "4",
    },
    "vitl336": {
        "label": "ViT-L/14-336",
        "pretrained_model": "ViT-L/14@336px",
        "checkpoint_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "batch_size": "4",
    },
    "vith14": {
        "label": "ViT-H/14",
        "pretrained_model": "ViT-H-14",
        "checkpoint_load_mode": "compatible",
        "features": ["8", "16", "24", "32"],
        "batch_size": "2",
    },
}


def csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def wait_for_pid_file(path: Path, poll_sec: int) -> None:
    if not path.exists():
        print({"stage": "wait_skip", "reason": "pid_file_missing", "pid_file": str(path)}, flush=True)
        return
    try:
        pid = int(path.read_text().strip())
    except ValueError:
        print({"stage": "wait_skip", "reason": "pid_file_invalid", "pid_file": str(path)}, flush=True)
        return
    while Path(f"/proc/{pid}").exists():
        print({"stage": "wait", "pid": pid, "pid_file": str(path)}, flush=True)
        time.sleep(max(5, int(poll_sec)))
    print({"stage": "wait_done", "pid": pid, "pid_file": str(path)}, flush=True)


def run_job(name: str, cmd: list[str], log_path: Path, force: bool) -> int:
    save_dir = Path(cmd[cmd.index("--save_dir") + 1])
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        print({"stage": "skip", "name": name, "summary": str(summary)}, flush=True)
        return 0
    if force and summary.exists():
        summary.unlink()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "name": name, "log": str(log_path), "save_dir": str(save_dir)}, flush=True)
    with log_path.open("w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "finished", "name": name, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
    return proc.returncode


def adaclip_cmd(tag: str, seed: int, device: str) -> tuple[str, list[str], Path]:
    cfg = ADACLIP_BACKBONES[tag]
    save_dir = RESULTS / f"adaclip_{tag}_mvtec2mvtecad2_seed{seed}"
    log_path = LOG_DIR / f"adaclip_{tag}_mvtec2_seed{seed}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/run_adaclip_mvtec2_custom.py",
        "--source_root",
        str(SOURCE_ROOT),
        "--source_dataset",
        "mvtec",
        "--target_root",
        str(TARGET_ROOT),
        "--target_dataset",
        "mvtec2",
        "--checkpoint_path",
        str(ROOT / "neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth"),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(BANK / f"adaclip_mvtec_mvtec2_{tag}_seed{seed}.pt"),
        "--seed",
        str(seed),
        "--device",
        device,
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "4",
        "--backbone",
        cfg["backbone"],
        "--checkpoint_load_mode",
        cfg["checkpoint_load_mode"],
        "--image_size",
        cfg["image_size"],
        "--sigma",
        "4",
        "--prompting_depth",
        "4",
        "--prompting_length",
        "5",
        "--prompting_branch",
        "VL",
        "--prompting_type",
        "SD",
        "--use_hsf",
        "true",
        "--k_clusters",
        "20",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--layer_recipe",
        "all4",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_subspace_rank",
        "8",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--calib_lambda",
        "0.3",
        "--calib_eta_max",
        "1.0",
        "--scoring_mode",
        "logit_gate_posneg",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
    ]
    return f"adaclip_{tag}", cmd, log_path


def faprompt_cmd(tag: str, seed: int, device: str) -> tuple[str, list[str], Path]:
    cfg = FAPROMPT_BACKBONES[tag]
    save_dir = RESULTS / f"faprompt_{tag}_mvtec2mvtecad2_seed{seed}"
    log_path = LOG_DIR / f"faprompt_{tag}_mvtec2_seed{seed}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/run_faprompt_mvtec2_custom.py",
        "--model_name",
        cfg["model_name"],
        "--prompt_load_mode",
        cfg["prompt_load_mode"],
        "--features_list",
        *cfg["features"],
        "--image_size",
        cfg["image_size"],
        "--batch_size",
        cfg["batch_size"],
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        cfg["dpam_layer"],
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    return f"faprompt_{tag}", cmd, log_path


def adaptclip_cmd(tag: str, seed: int, device: str) -> tuple[str, list[str], Path]:
    cfg = ADAPTCLIP_BACKBONES[tag]
    save_dir = RESULTS / f"adaptclip_{tag}_mvtec2mvtecad2_seed{seed}"
    log_path = LOG_DIR / f"adaptclip_{tag}_mvtec2_seed{seed}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaptclip.py",
        "--source_root",
        str(SOURCE_ROOT),
        "--source_dataset",
        "mvtec",
        "--target_root",
        str(TARGET_ROOT),
        "--target_dataset",
        "mvtec2",
        "--checkpoint_path",
        str(ROOT / "neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_mvtec_3adpaters_batch8/epoch_15.pth"),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(BANK / f"adaptclip_mvtec_mvtec2_{tag}_seed{seed}.pt"),
        "--pretrained_model",
        cfg["pretrained_model"],
        "--checkpoint_load_mode",
        cfg["checkpoint_load_mode"],
        "--features_list",
        *cfg["features"],
        "--image_size",
        "518",
        "--batch_size",
        cfg["batch_size"],
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "50",
        "--device",
        device,
    ]
    return f"adaptclip_{tag}", cmd, log_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="adaclip,faprompt,adaptclip")
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--wait_pid_file", default=str(RESULTS / "aaclip_backbones_20260504.pid"))
    ap.add_argument("--poll_sec", type=int, default=60)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-main-hosts-mvtec2-20260504")
    os.environ.setdefault("TRANSFORMERS_CACHE", "/mnt/data/hf-cache")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

    if args.wait_pid_file:
        wait_for_pid_file(Path(args.wait_pid_file), args.poll_sec)

    builders = {
        "adaclip": (ADACLIP_BACKBONES, adaclip_cmd),
        "faprompt": (FAPROMPT_BACKBONES, faprompt_cmd),
        "adaptclip": (ADAPTCLIP_BACKBONES, adaptclip_cmd),
    }
    failed = 0
    for seed in [int(x) for x in csv(args.seeds)]:
        for host in csv(args.hosts):
            if host not in builders:
                raise SystemExit(f"unknown host={host}; choices={sorted(builders)}")
            backbone_map, builder = builders[host]
            for tag in backbone_map:
                name, cmd, log_path = builder(tag, seed, args.device)
                failed += int(run_job(name, cmd, log_path, force=args.force) != 0)
                time.sleep(3)
    print({"stage": "done", "failed": failed}, flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
