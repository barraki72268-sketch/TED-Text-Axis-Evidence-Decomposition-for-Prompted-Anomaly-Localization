from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.kinematic_text_axis_reconstruction import (
    build_recent_general_prompt_bank,
    encode_text_features,
    reconstruct_optimal_text_axis,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    choose_text_rank,
    collect_oracle_records,
    forward_up_to_layer,
    l2_normalize,
    patchify_sequence,
    prepare_text_subspace,
    safe_auc,
    score_promptmax,
    score_reconstructed_axis,
    topk_mean,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("AQM v1 oracle prototype on frozen CLIP.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--class_specs",
        nargs="+",
        default=["capsules:12", "fryum:6"],
        help="Entries: class_name:layer",
    )
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_simplex_tokens", type=int, default=32)
    parser.add_argument("--num_subspace_tokens", type=int, default=32)
    parser.add_argument("--gamma_init", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=12)
    parser.add_argument("--train_anomaly_images", type=int, default=12)
    parser.add_argument("--eval_normal_images", type=int, default=12)
    parser.add_argument("--eval_anomaly_images", type=int, default=12)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--entropy_beta_max", type=float, default=0.05)
    parser.add_argument("--entropy_hold_epochs", type=int, default=2)
    parser.add_argument("--entropy_decay_epochs", type=int, default=3)
    parser.add_argument("--selection_metric", type=str, default="prompt_image", choices=["prompt_image", "recon_image"])
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_aqm_oracle")
    return parser.parse_args()


def parse_class_spec(spec: str) -> tuple[str, int]:
    class_name, layer = spec.split(":")
    return class_name, int(layer)


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = l2_normalize(p_norm, dim=0)
    return v.float() - (v.float() * p_norm.view(*([1] * (v.dim() - 1)), -1)).sum(dim=-1, keepdim=True) * p_norm.view(
        *([1] * (v.dim() - 1)),
        -1,
    )


def normalize_feat(v: torch.Tensor) -> torch.Tensor:
    return F.normalize(v.float(), p=2, dim=-1, eps=1e-6)


def stack_batch(records) -> tuple[torch.Tensor, torch.Tensor]:
    images = torch.cat([rec.image_t for rec in records], dim=0)
    masks = np.stack([rec.patch_mask.astype(np.int64) for rec in records], axis=0)
    return images, torch.from_numpy(masks)


class AnomalyQueryModuleV1(nn.Module):
    def __init__(
        self,
        dim: int,
        num_simplex_tokens: int = 32,
        num_subspace_tokens: int = 32,
        gamma_init: float = 1e-3,
    ):
        super().__init__()
        self.dim = int(dim)
        self.num_simplex_tokens = int(num_simplex_tokens)
        self.num_subspace_tokens = int(num_subspace_tokens)

        self.simplex_tokens = nn.Parameter(torch.randn(self.num_simplex_tokens, self.dim) * 0.02)
        self.subspace_tokens = nn.Parameter(torch.randn(self.num_subspace_tokens, self.dim) * 0.02)

        self.q_proj_simplex = nn.Linear(self.dim, self.dim, bias=False)
        self.q_proj_subspace = nn.Linear(self.dim, self.dim, bias=False)
        self.k_proj_simplex = nn.Linear(self.dim, self.dim, bias=False)
        self.v_proj_simplex = nn.Linear(self.dim, self.dim, bias=False)
        self.k_proj_subspace = nn.Linear(self.dim, self.dim, bias=False)
        self.v_proj_subspace = nn.Linear(self.dim, self.dim, bias=False)
        self.patch_q_proj_simplex = nn.Linear(self.dim, self.dim, bias=False)
        self.patch_q_proj_subspace = nn.Linear(self.dim, self.dim, bias=False)
        self.token_k_proj_simplex = nn.Linear(self.dim, self.dim, bias=False)
        self.token_k_proj_subspace = nn.Linear(self.dim, self.dim, bias=False)
        self.router = nn.Linear(self.dim, 1, bias=True)

        for mod in [
            self.q_proj_simplex,
            self.q_proj_subspace,
            self.k_proj_simplex,
            self.v_proj_simplex,
            self.k_proj_subspace,
            self.v_proj_subspace,
            self.patch_q_proj_simplex,
            self.patch_q_proj_subspace,
            self.token_k_proj_simplex,
            self.token_k_proj_subspace,
        ]:
            nn.init.xavier_uniform_(mod.weight, gain=0.25)
        nn.init.zeros_(self.router.weight)
        nn.init.zeros_(self.router.bias)

        self.gamma_simplex = nn.Parameter(torch.full((1,), float(gamma_init), dtype=torch.float32))
        self.gamma_subspace = nn.Parameter(torch.full((1,), float(gamma_init), dtype=torch.float32))

    def _extract_branch(
        self,
        v_in: torch.Tensor,
        token_bank: torch.Tensor,
        q_proj_tokens: nn.Linear,
        k_proj_vis: nn.Linear,
        v_proj_vis: nn.Linear,
        q_proj_patches: nn.Linear,
        k_proj_tokens_back: nn.Linear,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        bsz = v_in.shape[0]
        q_tok = q_proj_tokens(token_bank).unsqueeze(0).expand(bsz, -1, -1)
        k_vis = k_proj_vis(v_in)
        v_vis = v_proj_vis(v_in)
        attn_extract = torch.softmax(torch.matmul(q_tok, k_vis.transpose(1, 2)) / math.sqrt(self.dim), dim=-1)
        token_feat = torch.matmul(attn_extract, v_vis)

        q_patch = q_proj_patches(v_in)
        k_tok = k_proj_tokens_back(token_feat)
        attn_reproj = torch.softmax(torch.matmul(q_patch, k_tok.transpose(1, 2)) / math.sqrt(self.dim), dim=-1)
        patch_feat = torch.matmul(attn_reproj, token_feat)
        return patch_feat, attn_extract, attn_reproj

    def forward(self, v_in: torch.Tensor, p_norm: torch.Tensor, return_aux: bool = False):
        v_in = v_in.float()
        v_bar = v_in.mean(dim=1, keepdim=True)
        feat_simplex, attn_simplex, _ = self._extract_branch(
            v_in,
            self.simplex_tokens,
            self.q_proj_simplex,
            self.k_proj_simplex,
            self.v_proj_simplex,
            self.patch_q_proj_simplex,
            self.token_k_proj_simplex,
        )
        feat_subspace, attn_subspace, _ = self._extract_branch(
            v_in,
            self.subspace_tokens,
            self.q_proj_subspace,
            self.k_proj_subspace,
            self.v_proj_subspace,
            self.patch_q_proj_subspace,
            self.token_k_proj_subspace,
        )

        alpha = torch.sigmoid(self.router(v_bar.squeeze(1))).view(v_in.shape[0], 1, 1)
        simplex_feat = get_null_space_residual(self.gamma_simplex.view(1, 1, 1) * feat_simplex, p_norm)
        subspace_feat = get_null_space_residual(self.gamma_subspace.view(1, 1, 1) * feat_subspace, p_norm)
        mixed_feat = get_null_space_residual(alpha * simplex_feat + (1.0 - alpha) * subspace_feat, p_norm)
        if not return_aux:
            return mixed_feat
        return mixed_feat, {
            "alpha_tensor": alpha,
            "alpha_mean": float(alpha.mean().item()),
            "gamma_simplex_abs": float(self.gamma_simplex.abs().item()),
            "gamma_subspace_abs": float(self.gamma_subspace.abs().item()),
            "simplex_feat": simplex_feat,
            "subspace_feat": subspace_feat,
            "mixed_feat": mixed_feat,
            "simplex_extract_entropy": float(
                (-(attn_simplex.clamp_min(1e-8) * attn_simplex.clamp_min(1e-8).log()).sum(dim=-1)).mean().item()
            ),
            "subspace_extract_entropy": float(
                (-(attn_subspace.clamp_min(1e-8) * attn_subspace.clamp_min(1e-8).log()).sum(dim=-1)).mean().item()
            ),
        }


def compute_consensus_loss(
    r_out: torch.Tensor,
    prompt_features: torch.Tensor,
    mask: torch.Tensor,
    topk_ratio: float | None,
) -> torch.Tensor:
    pos = mask > 0
    if int(pos.sum().item()) == 0:
        return torch.zeros([], device=r_out.device)
    scores = torch.matmul(r_out[pos], prompt_features.T)
    j_star = torch.argmax(scores.mean(dim=0))
    patch_scores = scores[:, j_star]
    if topk_ratio is None:
        return 1.0 - patch_scores.mean()
    k = max(1, int(float(topk_ratio) * float(patch_scores.numel())))
    return 1.0 - torch.topk(patch_scores, k=min(k, patch_scores.numel()), largest=True).values.mean()


def compute_zero_signal_loss(feat: torch.Tensor, mask: torch.Tensor, hard_neg_ratio: float) -> torch.Tensor:
    neg = mask <= 0
    if int(neg.sum().item()) == 0:
        return torch.zeros([], device=feat.device)
    vals = feat[neg].norm(dim=-1)
    k = max(1, int(round(float(hard_neg_ratio) * float(vals.numel()))))
    hard_vals = torch.topk(vals, k=min(k, vals.numel()), largest=True).values
    return hard_vals.pow(2).mean()


def entropy_beta(epoch: int, beta_max: float, hold_epochs: int, decay_epochs: int) -> float:
    if beta_max <= 0:
        return 0.0
    if epoch <= hold_epochs:
        return float(beta_max)
    step = epoch - hold_epochs
    if step >= decay_epochs:
        return 0.0
    frac = 1.0 - (float(step) / float(decay_epochs))
    return float(beta_max) * max(0.0, frac)


def compute_aqm_loss(
    aux: dict[str, torch.Tensor | float],
    prompt_features: torch.Tensor,
    mask: torch.Tensor,
    hard_neg_ratio: float,
    topk_anom_ratio: float,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    simplex_feat = aux["simplex_feat"]
    subspace_feat = aux["subspace_feat"]
    alpha = aux["alpha_tensor"]

    r_s = normalize_feat(simplex_feat)
    r_u = normalize_feat(subspace_feat)
    mixed_detached = alpha * simplex_feat.detach() + (1.0 - alpha) * subspace_feat.detach()
    r_mix = normalize_feat(mixed_detached)

    l_s = compute_consensus_loss(r_s, prompt_features, mask, topk_ratio=topk_anom_ratio)
    l_u = compute_consensus_loss(r_u, prompt_features, mask, topk_ratio=None)
    l_router = compute_consensus_loss(r_mix, prompt_features, mask, topk_ratio=None)
    l_zero_s = compute_zero_signal_loss(simplex_feat, mask, hard_neg_ratio)
    l_zero_u = compute_zero_signal_loss(subspace_feat, mask, hard_neg_ratio)
    total = l_s + l_u + l_router + l_zero_s + l_zero_u
    return total, {
        "l_s": l_s,
        "l_u": l_u,
        "l_router": l_router,
        "l_zero_s": l_zero_s,
        "l_zero_u": l_zero_u,
    }


def build_batches(records, batch_size: int):
    order = np.random.permutation(len(records))
    for start in range(0, len(order), batch_size):
        idx = order[start : start + batch_size]
        yield [records[int(i)] for i in idx]


def train_one_epoch(
    backbone,
    aqm: AnomalyQueryModuleV1,
    layer_idx: int,
    train_records,
    p_norm: torch.Tensor,
    prompt_features: torch.Tensor,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    aqm.train()
    beta = entropy_beta(epoch_idx, args.entropy_beta_max, args.entropy_hold_epochs, args.entropy_decay_epochs)
    loss_vals = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []
    l_s_vals = []
    l_u_vals = []
    l_router_vals = []
    l_zero_s_vals = []
    l_zero_u_vals = []
    entropy_vals = []
    for batch_records in build_batches(train_records, args.batch_size):
        image_t, mask = stack_batch(batch_records)
        image_t = image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        mask = mask.to(device)
        seq = forward_up_to_layer(backbone, image_t, layer_idx)
        _, patches = patchify_sequence(seq)
        _, aux = aqm(patches, p_norm.to(device), return_aux=True)
        loss, parts = compute_aqm_loss(
            aux,
            prompt_features.to(device),
            mask,
            hard_neg_ratio=args.hard_neg_ratio,
            topk_anom_ratio=args.topk_anom_ratio,
        )
        alpha_c = aux["alpha_tensor"].clamp(1e-6, 1.0 - 1e-6)
        l_entropy = (alpha_c * torch.log(alpha_c) + (1.0 - alpha_c) * torch.log(1.0 - alpha_c)).mean()
        loss = loss + beta * l_entropy
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        loss_vals.append(float(loss.item()))
        alpha_vals.append(aux["alpha_mean"])
        gamma_s_vals.append(aux["gamma_simplex_abs"])
        gamma_u_vals.append(aux["gamma_subspace_abs"])
        l_s_vals.append(float(parts["l_s"].item()))
        l_u_vals.append(float(parts["l_u"].item()))
        l_router_vals.append(float(parts["l_router"].item()))
        l_zero_s_vals.append(float(parts["l_zero_s"].item()))
        l_zero_u_vals.append(float(parts["l_zero_u"].item()))
        entropy_vals.append(float(l_entropy.item()))
    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "train_loss_s": float(np.mean(l_s_vals)) if l_s_vals else float("nan"),
        "train_loss_u": float(np.mean(l_u_vals)) if l_u_vals else float("nan"),
        "train_loss_router": float(np.mean(l_router_vals)) if l_router_vals else float("nan"),
        "train_loss_zero_s": float(np.mean(l_zero_s_vals)) if l_zero_s_vals else float("nan"),
        "train_loss_zero_u": float(np.mean(l_zero_u_vals)) if l_zero_u_vals else float("nan"),
        "train_loss_entropy": float(np.mean(entropy_vals)) if entropy_vals else float("nan"),
        "entropy_beta": float(beta),
        "alpha_mean": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
    }


def score_from_feature(feat: torch.Tensor, p_norm: torch.Tensor, prompt_features: torch.Tensor, delta_p_recon: torch.Tensor):
    feat = feat.float()
    feat_np_recon = score_reconstructed_axis(feat, p_norm, delta_p_recon)
    feat_np_prompt = score_promptmax(feat, p_norm, prompt_features)
    return feat_np_recon, feat_np_prompt


def evaluate_model(
    backbone,
    aqm: AnomalyQueryModuleV1,
    layer_idx: int,
    eval_records,
    p_norm: torch.Tensor,
    prompt_features: torch.Tensor,
    delta_p_recon: torch.Tensor,
    topk_ratio: float,
    batch_size: int,
    device: str,
) -> dict[str, float]:
    aqm.eval()
    patch_labels = []
    base_recon_patch_scores = []
    mix_recon_patch_scores = []
    simplex_recon_patch_scores = []
    subspace_recon_patch_scores = []
    base_prompt_patch_scores = []
    mix_prompt_patch_scores = []
    simplex_prompt_patch_scores = []
    subspace_prompt_patch_scores = []
    image_labels = []
    base_recon_image_scores = []
    mix_recon_image_scores = []
    simplex_recon_image_scores = []
    subspace_recon_image_scores = []
    base_prompt_image_scores = []
    mix_prompt_image_scores = []
    simplex_prompt_image_scores = []
    subspace_prompt_image_scores = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []
    simplex_entropy_vals = []
    subspace_entropy_vals = []

    with torch.no_grad():
        for start in range(0, len(eval_records), batch_size):
            batch_records = eval_records[start : start + batch_size]
            image_t, mask = stack_batch(batch_records)
            image_t = image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            _, patches = patchify_sequence(seq)
            _, aux = aqm(patches, p_norm.to(device), return_aux=True)

            base_recon, base_prompt = score_from_feature(patches, p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device))
            mix_recon, mix_prompt = score_from_feature(aux["mixed_feat"], p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device))
            simplex_recon, simplex_prompt = score_from_feature(aux["simplex_feat"], p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device))
            subspace_recon, subspace_prompt = score_from_feature(aux["subspace_feat"], p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device))

            for rec, rec_mask, br, mr, sr, ur, bp, mp, sp, up in zip(
                batch_records,
                mask.cpu().numpy(),
                base_recon,
                mix_recon,
                simplex_recon,
                subspace_recon,
                base_prompt,
                mix_prompt,
                simplex_prompt,
                subspace_prompt,
            ):
                patch_labels.extend(rec_mask.astype(np.int64).tolist())
                base_recon_patch_scores.extend(br.tolist())
                mix_recon_patch_scores.extend(mr.tolist())
                simplex_recon_patch_scores.extend(sr.tolist())
                subspace_recon_patch_scores.extend(ur.tolist())
                base_prompt_patch_scores.extend(bp.tolist())
                mix_prompt_patch_scores.extend(mp.tolist())
                simplex_prompt_patch_scores.extend(sp.tolist())
                subspace_prompt_patch_scores.extend(up.tolist())
                image_labels.append(rec.label)
                base_recon_image_scores.append(topk_mean(np.asarray(br), topk_ratio))
                mix_recon_image_scores.append(topk_mean(np.asarray(mr), topk_ratio))
                simplex_recon_image_scores.append(topk_mean(np.asarray(sr), topk_ratio))
                subspace_recon_image_scores.append(topk_mean(np.asarray(ur), topk_ratio))
                base_prompt_image_scores.append(topk_mean(np.asarray(bp), topk_ratio))
                mix_prompt_image_scores.append(topk_mean(np.asarray(mp), topk_ratio))
                simplex_prompt_image_scores.append(topk_mean(np.asarray(sp), topk_ratio))
                subspace_prompt_image_scores.append(topk_mean(np.asarray(up), topk_ratio))

            alpha_vals.extend(aux["alpha_tensor"].view(-1).detach().cpu().tolist())
            gamma_s_vals.extend([aux["gamma_simplex_abs"]] * len(batch_records))
            gamma_u_vals.extend([aux["gamma_subspace_abs"]] * len(batch_records))
            simplex_entropy_vals.extend([aux["simplex_extract_entropy"]] * len(batch_records))
            subspace_entropy_vals.extend([aux["subspace_extract_entropy"]] * len(batch_records))

    base_recon_patch_auc = safe_auc(patch_labels, base_recon_patch_scores)
    mix_recon_patch_auc = safe_auc(patch_labels, mix_recon_patch_scores)
    simplex_recon_patch_auc = safe_auc(patch_labels, simplex_recon_patch_scores)
    subspace_recon_patch_auc = safe_auc(patch_labels, subspace_recon_patch_scores)
    base_prompt_patch_auc = safe_auc(patch_labels, base_prompt_patch_scores)
    mix_prompt_patch_auc = safe_auc(patch_labels, mix_prompt_patch_scores)
    simplex_prompt_patch_auc = safe_auc(patch_labels, simplex_prompt_patch_scores)
    subspace_prompt_patch_auc = safe_auc(patch_labels, subspace_prompt_patch_scores)
    base_recon_image_auc = safe_auc(image_labels, base_recon_image_scores)
    mix_recon_image_auc = safe_auc(image_labels, mix_recon_image_scores)
    simplex_recon_image_auc = safe_auc(image_labels, simplex_recon_image_scores)
    subspace_recon_image_auc = safe_auc(image_labels, subspace_recon_image_scores)
    base_prompt_image_auc = safe_auc(image_labels, base_prompt_image_scores)
    mix_prompt_image_auc = safe_auc(image_labels, mix_prompt_image_scores)
    simplex_prompt_image_auc = safe_auc(image_labels, simplex_prompt_image_scores)
    subspace_prompt_image_auc = safe_auc(image_labels, subspace_prompt_image_scores)
    return {
        "base_recon_patch_auc": base_recon_patch_auc,
        "aqm_recon_patch_auc": mix_recon_patch_auc,
        "recon_patch_auc_delta": mix_recon_patch_auc - base_recon_patch_auc,
        "simplex_recon_patch_auc_delta": simplex_recon_patch_auc - base_recon_patch_auc,
        "subspace_recon_patch_auc_delta": subspace_recon_patch_auc - base_recon_patch_auc,
        "base_prompt_patch_auc": base_prompt_patch_auc,
        "aqm_prompt_patch_auc": mix_prompt_patch_auc,
        "prompt_patch_auc_delta": mix_prompt_patch_auc - base_prompt_patch_auc,
        "simplex_prompt_patch_auc_delta": simplex_prompt_patch_auc - base_prompt_patch_auc,
        "subspace_prompt_patch_auc_delta": subspace_prompt_patch_auc - base_prompt_patch_auc,
        "base_recon_image_auc": base_recon_image_auc,
        "aqm_recon_image_auc": mix_recon_image_auc,
        "recon_image_auc_delta": mix_recon_image_auc - base_recon_image_auc,
        "simplex_recon_image_auc_delta": simplex_recon_image_auc - base_recon_image_auc,
        "subspace_recon_image_auc_delta": subspace_recon_image_auc - base_recon_image_auc,
        "base_prompt_image_auc": base_prompt_image_auc,
        "aqm_prompt_image_auc": mix_prompt_image_auc,
        "prompt_image_auc_delta": mix_prompt_image_auc - base_prompt_image_auc,
        "simplex_prompt_image_auc_delta": simplex_prompt_image_auc - base_prompt_image_auc,
        "subspace_prompt_image_auc_delta": subspace_prompt_image_auc - base_prompt_image_auc,
        "alpha_mean_eval": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean_eval": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean_eval": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
        "simplex_extract_entropy_eval": float(np.mean(simplex_entropy_vals)) if simplex_entropy_vals else float("nan"),
        "subspace_extract_entropy_eval": float(np.mean(subspace_entropy_vals)) if subspace_entropy_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    details = []

    class_specs = [parse_class_spec(spec) for spec in args.class_specs]
    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        backbone.eval()
        for param in backbone.parameters():
            param.requires_grad_(False)

        for class_name, layer_idx in class_specs:
            train_records, eval_records = collect_oracle_records(backbone, class_name, args)
            normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
            p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0]
            prompt_features = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts)
            delta_bank = prompt_features - p_norm.unsqueeze(0)
            k = choose_text_rank(delta_bank, args.text_var_threshold)
            U_basis = prepare_text_subspace(prompt_features, p_norm, k)

            anom_chunks = []
            for rec in train_records:
                if rec.label != 1:
                    continue
                image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
                with torch.no_grad():
                    seq = forward_up_to_layer(backbone, image_t, layer_idx)
                    _, patches = patchify_sequence(seq)
                pos = torch.from_numpy(rec.patch_mask > 0).to(patches.device)
                if int(pos.sum().item()) > 0:
                    anom_chunks.append(patches[0][pos].detach())
            if not anom_chunks:
                continue
            patches_cat = torch.cat(anom_chunks, dim=0)
            residual = get_null_space_residual(patches_cat, p_norm.view(-1).to(patches_cat.device))
            residual = residual - residual.mean(dim=0, keepdim=True)
            _, _, vh = torch.linalg.svd(residual, full_matrices=False)
            V_anom = vh[: min(k, vh.shape[0])].contiguous()
            delta_p_recon, _, singular_values = reconstruct_optimal_text_axis(U_basis.T.to(V_anom.device), V_anom.T.contiguous())
            sigma1 = float(singular_values[0].item()) if singular_values.numel() else float("nan")

            aqm = AnomalyQueryModuleV1(
                dim=int(prompt_features.shape[1]),
                num_simplex_tokens=args.num_simplex_tokens,
                num_subspace_tokens=args.num_subspace_tokens,
                gamma_init=args.gamma_init,
            ).to(device)
            token_params = [aqm.simplex_tokens, aqm.subspace_tokens]
            other_params = [p for n, p in aqm.named_parameters() if n not in {"simplex_tokens", "subspace_tokens"}]
            optimizer = torch.optim.AdamW(
                [
                    {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
                    {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
                ]
            )

            history = []
            best_state = None
            best_metric = -float("inf")
            for epoch in range(1, args.epochs + 1):
                train_stats = train_one_epoch(
                    backbone,
                    aqm,
                    layer_idx,
                    train_records,
                    p_norm.to(device),
                    prompt_features.to(device),
                    args,
                    optimizer,
                    device,
                    epoch,
                )
                eval_stats = evaluate_model(
                    backbone,
                    aqm,
                    layer_idx,
                    eval_records,
                    p_norm.to(device),
                    prompt_features.to(device),
                    delta_p_recon.to(device),
                    args.topk_ratio,
                    args.batch_size,
                    device,
                )
                history.append({"epoch": epoch, **train_stats, **eval_stats})
                metric_key = "aqm_prompt_image_auc" if args.selection_metric == "prompt_image" else "aqm_recon_image_auc"
                if eval_stats[metric_key] > best_metric:
                    best_metric = eval_stats[metric_key]
                    best_state = {k0: v.detach().cpu() for k0, v in aqm.state_dict().items()}

            if best_state is None:
                continue

            aqm.load_state_dict(best_state)
            best_eval = evaluate_model(
                backbone,
                aqm,
                layer_idx,
                eval_records,
                p_norm.to(device),
                prompt_features.to(device),
                delta_p_recon.to(device),
                args.topk_ratio,
                args.batch_size,
                device,
            )
            row = {
                "class_name": class_name,
                "layer": layer_idx,
                "backbone": backbone_name,
                "pretrained": pretrained_name,
                "img_size": img_size_i,
                "epochs": args.epochs,
                "num_simplex_tokens": args.num_simplex_tokens,
                "num_subspace_tokens": args.num_subspace_tokens,
                "gamma_init": args.gamma_init,
                "selection_metric": args.selection_metric,
                "sigma1": sigma1,
                "text_rank": k,
                **history[-1],
                **best_eval,
            }
            rows.append(row)
            details.append(
                {
                    "class_name": class_name,
                    "layer": layer_idx,
                    "history": history,
                    "best_eval": best_eval,
                }
            )

    stem = args.output_tag
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"args": vars(args), "rows": rows, "details": details}, f, indent=2)
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
