#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results"
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_faprompt.py"

PRESETS = ["visa2mvtec", "mvtec2visa", "visa2mpdd", "visa2btad"]

BACKBONES = {
    "vitb": {
        "row_name": "ViT-B/16+",
        "save_tag": "vitb16plus",
        "model_name": "ViT-B-16-plus-240",
        "prompt_load_mode": "project_crop",
        "features_list": [6, 12],
        "dpam_layer": 12,
        "batch_size": 8,
        "bank_chunk": 4096,
    },
    "vith": {
        "row_name": "ViT-H/14",
        "save_tag": "vith14",
        "model_name": "ViT-H-14",
        "prompt_load_mode": "project_crop",
        "features_list": [8, 16, 24, 32],
        "dpam_layer": 30,
        "batch_size": 8,
        "bank_chunk": 8192,
    },
    "vitl_openai": {
        "row_name": "ViT-L/14 OpenAI",
        "save_tag": "vitl14openai",
        "model_name": "ViT-L/14",
        "prompt_load_mode": "strict",
        "features_list": [6, 12, 18, 24],
        "dpam_layer": 20,
        "batch_size": 8,
        "bank_chunk": 8192,
    },
}


def run_job(backbone_key: str, preset: str, seed: int, device: str, num_workers: int, aupro_max_step: int) -> None:
    cfg = BACKBONES[backbone_key]
    save_dir = RESULTS / f"faprompt_learned_hostres_{cfg['save_tag']}_{preset}_seed{seed}_20260428"
    summary = save_dir / "summary.json"
    if summary.exists():
        print(f"[skip] {summary}", flush=True)
        return

    save_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(SCRIPT),
        "--preset",
        preset,
        "--model_name",
        str(cfg["model_name"]),
        "--prompt_load_mode",
        str(cfg["prompt_load_mode"]),
        "--features_list",
        *[str(x) for x in cfg["features_list"]],
        "--image_size",
        "518",
        "--batch_size",
        str(cfg["batch_size"]),
        "--num_workers",
        str(num_workers),
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        str(cfg["dpam_layer"]),
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "1.0",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "prescore_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--rectifier_gate_mode",
        "support_mass",
        "--rectifier_gate_sharpness",
        "3.0",
        "--bank_chunk",
        str(cfg["bank_chunk"]),
        "--aupro_max_step",
        str(aupro_max_step),
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    print(f"[run] {save_dir}", flush=True)
    print(" ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--backbone", choices=[*BACKBONES, "all"], default="all")
    parser.add_argument("--preset", choices=[*PRESETS, "all"], default="all")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--num_workers", type=int, default=6)
    parser.add_argument("--aupro_max_step", type=int, default=50)
    parser.add_argument("--seeds", type=str, default="0")
    args = parser.parse_args()

    backbones = list(BACKBONES) if args.backbone == "all" else [args.backbone]
    presets = list(PRESETS) if args.preset == "all" else [args.preset]
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    for seed in seeds:
        for backbone_key in backbones:
            for preset in presets:
                run_job(backbone_key, preset, seed, args.device, args.num_workers, args.aupro_max_step)
    print("[done] FAPrompt learned host-residual subspace jobs", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
