from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter
from skimage import measure
from sklearn.metrics import auc, average_precision_score, roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    build_dataset,
    decision_axis,
    logmeanexp_negative_sqdist_1d,
    project_bank,
    safe_auc,
    topk_mean,
)


def patch_text_score(
    patch_feature: torch.Tensor,
    text_pair: torch.Tensor,
    mode: str = "prob",
    temperature: float = 0.07,
) -> torch.Tensor:
    if mode in {"logit_margin", "neg_logit_margin", "cos_margin", "neg_cos_margin"}:
        patch = F.normalize(patch_feature[:, 1:, :].float(), dim=-1)
        text = F.normalize(text_pair.float(), dim=-1)
        logits = patch @ text.t()
        if mode in {"logit_margin", "neg_logit_margin"}:
            logits = logits / float(temperature)
        margin = logits[..., 1] - logits[..., 0]
        if mode in {"neg_logit_margin", "neg_cos_margin"}:
            margin = -margin
        return margin.reshape(-1)
    patch_feature = F.normalize(patch_feature.float(), dim=-1)
    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
    return ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)


def farthest_point_subsample_indices(feat: torch.Tensor, max_points: int) -> torch.Tensor:
    if feat.shape[0] <= max_points:
        return torch.arange(feat.shape[0], dtype=torch.long)
    feat = F.normalize(feat.float(), dim=-1)
    mean_dir = F.normalize(feat.mean(dim=0, keepdim=True), dim=-1)
    min_dist = 1.0 - (feat @ mean_dir.t()).squeeze(1)
    selected: list[int] = []
    for _ in range(max_points):
        idx = int(torch.argmax(min_dist).item())
        selected.append(idx)
        candidate_dist = 1.0 - (feat @ feat[idx : idx + 1].t()).squeeze(1)
        min_dist = torch.minimum(min_dist, candidate_dist)
        min_dist[idx] = -1.0
    return torch.tensor(selected, dtype=torch.long)


def inverse_softplus(value: float) -> float:
    value = max(float(value), 1e-6)
    return math.log(math.expm1(value)) if value < 20 else value


def sample_source_hardpair_indices(
    fp_scores: torch.Tensor,
    defect_scores: torch.Tensor,
    n: int,
    hardpair_frac: float,
    rng: torch.Generator,
) -> tuple[torch.Tensor, torch.Tensor]:
    hardpair_frac = float(np.clip(float(hardpair_frac), 0.0, 1.0))
    n_hard = int(round(n * hardpair_frac))
    n_rand = max(0, n - n_hard)

    def mixed(scores: torch.Tensor, hard_high: bool) -> torch.Tensor:
        scores_cpu = scores.detach().cpu()
        hard_idx = torch.empty(0, dtype=torch.long)
        rand_idx = torch.empty(0, dtype=torch.long)
        if n_hard > 0:
            k = min(n_hard, scores_cpu.numel())
            hard_idx = torch.topk(scores_cpu, k=k, largest=hard_high).indices
        if n_rand > 0:
            perm = torch.randperm(scores_cpu.numel(), generator=rng)
            if hard_idx.numel() > 0:
                mask = torch.ones(scores_cpu.numel(), dtype=torch.bool)
                mask[hard_idx] = False
                perm = perm[mask[perm]]
            rand_idx = perm[: min(n_rand, perm.numel())]
        idx = torch.cat([hard_idx, rand_idx], dim=0)
        if idx.numel() < n:
            fill = torch.randperm(scores_cpu.numel(), generator=rng)[: n - idx.numel()]
            idx = torch.cat([idx, fill], dim=0)
        return idx[:n]

    return mixed(fp_scores, hard_high=True), mixed(defect_scores, hard_high=False)


def apply_pair_label_control_to_tensors(
    fp_tensors: list[torch.Tensor],
    defect_tensors: list[torch.Tensor],
    mode: str,
    seed: int,
) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
    """Corrupt the source hard-pair supervision for training-control ablations."""
    if mode == "correct":
        return fp_tensors, defect_tensors
    if mode == "swap":
        return defect_tensors, fp_tensors
    if mode == "shuffle":
        if not fp_tensors or not defect_tensors:
            return fp_tensors, defect_tensors
        n = min(fp_tensors[0].shape[0], defect_tensors[0].shape[0])
        if n <= 1:
            return fp_tensors, defect_tensors
        rng = torch.Generator(device="cpu")
        rng.manual_seed(int(seed))
        swap_mask = torch.rand(n, generator=rng) < 0.5
        new_fp: list[torch.Tensor] = []
        new_def: list[torch.Tensor] = []
        for fp, defect in zip(fp_tensors, defect_tensors):
            fp_out = fp.clone()
            def_out = defect.clone()
            fp_out[swap_mask] = defect[swap_mask]
            def_out[swap_mask] = fp[swap_mask]
            new_fp.append(fp_out)
            new_def.append(def_out)
        return new_fp, new_def
    raise ValueError(f"Unknown pair label control: {mode}")


def _orthonormalize_columns(mat: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    basis = []
    for i in range(mat.shape[1]):
        v = mat[:, i].float()
        for u in basis:
            v = v - torch.dot(v, u) * u
        n = torch.norm(v)
        if float(n.item()) > eps:
            basis.append(v / n)
    if not basis:
        return F.normalize(mat[:, :1].float(), dim=0)
    return torch.stack(basis, dim=1)


def build_defect_parallel_basis(
    fp: torch.Tensor,
    defect: torch.Tensor,
    axis: torch.Tensor,
    rank: int,
    device: torch.device,
) -> torch.Tensor:
    fp = F.normalize(fp.float().to(device), dim=-1)
    defect = F.normalize(defect.float().to(device), dim=-1)
    axis = F.normalize(axis.float().to(device), dim=0)
    cols = [axis]
    if fp.numel() > 0 and defect.numel() > 0:
        mu_fp = F.normalize(fp.mean(dim=0), dim=0)
        mu_def = F.normalize(defect.mean(dim=0), dim=0)
        cols.append(F.normalize(mu_def - mu_fp, dim=0))
        n = min(fp.shape[0], defect.shape[0], 4096)
        if n > 4 and rank > 2:
            pair_diff = defect[:n] - fp[:n]
            pair_diff = pair_diff - pair_diff.mean(dim=0, keepdim=True)
            try:
                _, _, vh = torch.linalg.svd(pair_diff.float(), full_matrices=False)
                for pc in vh[: max(0, int(rank) - len(cols))]:
                    cols.append(F.normalize(pc, dim=0))
            except RuntimeError:
                pass
    mat = torch.stack(cols, dim=1)
    return _orthonormalize_columns(mat)[:, : max(1, int(rank))]


def spatial_tanh_zscore_token(x: torch.Tensor) -> torch.Tensor:
    return torch.tanh((x - x.mean(dim=1, keepdim=True)) / x.std(dim=1, keepdim=True).clamp_min(1e-6))


def prescore_subspace_transport_tokens(
    tokens: torch.Tensor,
    q_def: torch.Tensor,
    q_fp: torch.Tensor,
    basis: torch.Tensor,
    eta: float,
    direction: list[float],
    transport_b: float,
    fp_weight: float,
    margin_sign: float = 1.0,
) -> torch.Tensor:
    basis = basis.to(tokens.device).float()
    direction_t = F.normalize(torch.tensor(direction, device=tokens.device, dtype=torch.float32), dim=0)
    move_dir = F.normalize(basis @ direction_t, dim=0)
    raw_margin = float(margin_sign) * (q_def - float(fp_weight) * q_fp)
    margin = spatial_tanh_zscore_token(raw_margin)
    delta = float(eta) * torch.tanh(margin + float(transport_b))
    return F.normalize(tokens.float() + delta.unsqueeze(-1) * move_dir.view(1, 1, -1), dim=-1)


def subspace_host_residual_token_score(
    host_score: torch.Tensor,
    rect_tokens: torch.Tensor,
    basis: torch.Tensor,
    score_w: list[float],
    readout_gamma: float,
) -> torch.Tensor:
    basis = basis.to(rect_tokens.device).float()
    score_w_t = F.normalize(torch.tensor(score_w, device=rect_tokens.device, dtype=torch.float32), dim=0)
    coords = rect_tokens.float() @ basis
    if score_w_t.numel() == max(0, coords.shape[-1] - 1):
        residual = coords[..., 1:] @ score_w_t
    else:
        residual = coords @ score_w_t - coords[..., 0]
    return host_score.float() + float(readout_gamma) * residual


def train_subspace_host_residual_calibrator(
    banks: dict,
    axis: torch.Tensor,
    tau: float,
    max_train_points: int,
    epochs: int,
    lr: float,
    rank_margin: float,
    rank_temp: float,
    eta_init: float,
    eta_max: float,
    eta_reg: float,
    fp_weight_init: float,
    learn_fp_weight: bool,
    hardpair_frac: float,
    subspace_rank: int,
    preserve_host_margin_weight: float,
    margin_sign: float,
    pair_label_control: str,
    seed: int,
    device: torch.device,
) -> dict | None:
    if epochs <= 0:
        return None
    fp = F.normalize(banks["fp"].float(), dim=-1)
    defect = F.normalize(banks["defect"].float(), dim=-1)
    if fp.numel() == 0 or defect.numel() == 0:
        return None
    rng = torch.Generator(device="cpu")
    rng.manual_seed(seed)
    n = min(fp.shape[0], defect.shape[0], max_train_points // 2 if max_train_points > 0 else 10**9)
    if n <= 0:
        return None

    axis = F.normalize(axis.to(device).float(), dim=0)
    basis = build_defect_parallel_basis(fp, defect, axis, subspace_rank, device)
    fp_all = fp.to(device)
    defect_all = defect.to(device)
    fp_proj_all = fp_all @ axis
    defect_proj_all = defect_all @ axis
    fp_host_all = banks.get("fp_score", fp_proj_all.detach().cpu()).float().to(device)
    defect_host_all = banks.get("defect_score", defect_proj_all.detach().cpu()).float().to(device)
    fp_idx, def_idx = sample_source_hardpair_indices(
        fp_scores=fp_host_all,
        defect_scores=defect_host_all,
        n=n,
        hardpair_frac=hardpair_frac,
        rng=rng,
    )
    fp_train = fp[fp_idx].to(device)
    defect_train = defect[def_idx].to(device)
    fp_host = fp_host_all[fp_idx]
    defect_host = defect_host_all[def_idx]
    fp_q_axis = fp_train @ axis
    defect_q_axis = defect_train @ axis
    fp_q_def = logmeanexp_negative_sqdist_1d(fp_q_axis, defect_proj_all, tau=tau)
    fp_q_fp = logmeanexp_negative_sqdist_1d(fp_q_axis, fp_proj_all, tau=tau)
    defect_q_def = logmeanexp_negative_sqdist_1d(defect_q_axis, defect_proj_all, tau=tau)
    defect_q_fp = logmeanexp_negative_sqdist_1d(defect_q_axis, fp_proj_all, tau=tau)
    (
        fp_train,
        fp_host,
        fp_q_def,
        fp_q_fp,
    ), (
        defect_train,
        defect_host,
        defect_q_def,
        defect_q_fp,
    ) = apply_pair_label_control_to_tensors(
        [fp_train, fp_host, fp_q_def, fp_q_fp],
        [defect_train, defect_host, defect_q_def, defect_q_fp],
        pair_label_control,
        seed + 10007,
    )

    eta_max = max(float(eta_max), 1e-6)
    eta_init = float(np.clip(abs(float(eta_init)), 1e-6, 0.99 * eta_max))
    eta_raw = torch.tensor(inverse_softplus(eta_init), device=device, requires_grad=True)
    fp_weight_raw = torch.tensor(inverse_softplus(fp_weight_init), device=device, requires_grad=bool(learn_fp_weight))
    raw_direction = torch.zeros(basis.shape[1], device=device, requires_grad=True)
    raw_direction.data[0] = 1.0
    transport_b = torch.tensor(0.0, device=device, requires_grad=True)
    scorer_dim = max(1, basis.shape[1] - 1)
    scorer = torch.zeros(scorer_dim, device=device, requires_grad=True)
    scorer.data[0] = 1.0
    readout_gamma_raw = torch.tensor(inverse_softplus(eta_init), device=device, requires_grad=True)
    params = [eta_raw, raw_direction, transport_b, scorer, readout_gamma_raw]
    if fp_weight_raw.requires_grad:
        params.append(fp_weight_raw)
    opt = torch.optim.Adam(params, lr=lr)
    pair_index = torch.arange(n, device=device)
    rank_temp = max(float(rank_temp), 1e-6)

    def current_params():
        eta = torch.clamp(F.softplus(eta_raw), max=eta_max)
        readout_gamma = torch.clamp(F.softplus(readout_gamma_raw), max=eta_max)
        fp_weight = F.softplus(fp_weight_raw) + 1e-6
        direction = F.normalize(raw_direction, dim=0)
        score_w = F.normalize(scorer, dim=0)
        return eta, direction, transport_b, score_w, readout_gamma, fp_weight

    def transport_scores(features, host_scores, q_def, q_fp, eta, direction, b, score_w, readout_gamma, fp_weight):
        raw_margin = float(margin_sign) * (q_def - fp_weight * q_fp)
        margin = torch.tanh((raw_margin - raw_margin.mean()) / raw_margin.std().clamp_min(1e-6))
        delta = eta * torch.tanh(margin + b)
        move_dir = basis @ direction
        rect = F.normalize(features.float() + delta.unsqueeze(-1) * move_dir.view(1, -1), dim=-1)
        coords = rect @ basis
        if basis.shape[1] > 1:
            residual = coords[:, 1:] @ score_w
        else:
            residual = coords[:, :1].squeeze(1)
        scores = host_scores.float() + readout_gamma * residual
        return scores, delta

    for _ in range(epochs):
        opt.zero_grad(set_to_none=True)
        perm = pair_index[torch.randperm(n, device=device)]
        eta, direction, b, score_w, readout_gamma, fp_weight = current_params()
        features = torch.cat([fp_train[perm], defect_train], dim=0)
        host_scores = torch.cat([fp_host[perm], defect_host], dim=0)
        q_def = torch.cat([fp_q_def[perm], defect_q_def], dim=0)
        q_fp = torch.cat([fp_q_fp[perm], defect_q_fp], dim=0)
        scores, _ = transport_scores(features, host_scores, q_def, q_fp, eta, direction, b, score_w, readout_gamma, fp_weight)
        s_fp, s_def = scores[:n], scores[n:]
        loss = F.softplus((s_fp - s_def + rank_margin) / rank_temp).mean()
        if preserve_host_margin_weight > 0:
            base_margin = defect_host - fp_host[perm]
            final_margin = s_def - s_fp
            easy_weight = torch.sigmoid((base_margin - rank_margin) / rank_temp)
            preserve = F.relu(base_margin - final_margin).mul(easy_weight).sum()
            preserve = preserve / easy_weight.sum().clamp_min(1e-6)
            loss = loss + float(preserve_host_margin_weight) * preserve
        if eta_reg > 0:
            loss = loss + float(eta_reg) * (eta.pow(2) + readout_gamma.pow(2))
        loss.backward()
        opt.step()

    with torch.no_grad():
        eta, direction, b, score_w, readout_gamma, fp_weight = current_params()
        features = torch.cat([fp_train, defect_train], dim=0)
        host_scores = torch.cat([fp_host, defect_host], dim=0)
        q_def = torch.cat([fp_q_def, defect_q_def], dim=0)
        q_fp = torch.cat([fp_q_fp, defect_q_fp], dim=0)
        scores, delta = transport_scores(features, host_scores, q_def, q_fp, eta, direction, b, score_w, readout_gamma, fp_weight)
        s_fp, s_def = scores[:n], scores[n:]
        pair_acc = (s_def > s_fp).float().mean().item()
        base_pair_acc = (defect_host > fp_host).float().mean().item()

    return {
        "calibration": "source_calibrated_host_residual_subspace_rank_no_target",
        "host_branch": "anomalyclip_patch_text_similarity",
        "eta": float(eta.item()),
        "transport_direction": direction.detach().cpu().tolist(),
        "transport_b": float(b.item()),
        "subspace_score_w": score_w.detach().cpu().tolist(),
        "readout_gamma": float(readout_gamma.item()),
        "basis": basis.detach().cpu(),
        "subspace_rank": int(basis.shape[1]),
        "fp_weight": float(fp_weight.item()),
        "margin_sign": float(margin_sign),
        "pair_label_control": str(pair_label_control),
        "train_points_per_class": int(n),
        "source_pair_rank_accuracy": float(pair_acc),
        "source_base_pair_rank_accuracy": float(base_pair_acc),
        "source_delta_fp_mean": float(delta[:n].mean().item()),
        "source_delta_def_mean": float(delta[n:].mean().item()),
        "hardpair_frac": float(hardpair_frac),
        "preserve_host_margin_weight": float(preserve_host_margin_weight),
    }


def score_bank_cache_path(
    checkpoint_path: str,
    model_name_or_path: str,
    allow_prompt_projection: bool,
    prompt_projection_ridge: float,
    source_root: str,
    source_dataset: str,
    heldout_class: str | None,
    image_size: int,
    features_list: list[int],
    hard_frac: float,
    max_good_per_class: int,
    max_defect_per_class: int,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    dpam_layer: int,
    explicit_path: str | None,
    legacy_bank_cache_path: str | None,
) -> Path:
    if explicit_path:
        return Path(explicit_path)
    if legacy_bank_cache_path:
        legacy = Path(legacy_bank_cache_path)
        return legacy.with_name(f"{legacy.stem}_withscores{legacy.suffix}")
    cache_cfg = {
        "checkpoint_path": str(checkpoint_path),
        "model_name_or_path": str(model_name_or_path),
        "allow_prompt_projection": bool(allow_prompt_projection),
        "prompt_projection_ridge": float(prompt_projection_ridge),
        "source_root": str(source_root),
        "source_dataset": source_dataset,
        "heldout_class": heldout_class,
        "image_size": int(image_size),
        "features_list": list(features_list),
        "hard_frac": float(hard_frac),
        "max_good_per_class": int(max_good_per_class),
        "max_defect_per_class": int(max_defect_per_class),
        "max_bank_per_layer": int(max_bank_per_layer),
        "max_fp_per_image": int(max_fp_per_image),
        "max_defect_per_image": int(max_defect_per_image),
        "dpam_layer": int(dpam_layer),
        "contains_host_scores": True,
    }
    import hashlib

    digest = hashlib.md5(json.dumps(cache_cfg, sort_keys=True).encode("utf-8")).hexdigest()[:12]
    source_tag = f"{source_dataset}_{Path(source_root).name.replace('/', '_')}"
    heldout_tag = heldout_class or "none"
    return ROOT / "neurips2026" / "results" / "bank_cache" / f"anomalyclip_ted_scorebank_{source_tag}_exclude-{heldout_tag}_{digest}.pt"


def collect_source_patch_banks_with_scores(
    model,
    text_pair: torch.Tensor,
    data_root: str,
    source_dataset: str,
    image_size: int,
    features_list: list[int],
    device: str,
    heldout_class: str | None,
    max_good_per_class: int,
    max_defect_per_class: int,
    hard_frac: float,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    dpam_layer: int,
    host_patch_score_mode: str,
):
    train_ds = build_dataset(data_root, source_dataset, image_size, mode="train")
    test_ds = build_dataset(data_root, source_dataset, image_size, mode="test")

    fp_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    def_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    fp_score_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    def_score_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    per_good: dict[str, int] = {cls_name: 0 for cls_name in train_ds.obj_list}
    per_defect: dict[str, int] = {cls_name: 0 for cls_name in test_ds.obj_list}
    target_good_classes = [cls_name for cls_name in train_ds.obj_list if heldout_class is None or cls_name != heldout_class]
    target_defect_classes = [cls_name for cls_name in test_ds.obj_list if heldout_class is None or cls_name != heldout_class]

    with torch.no_grad():
        for idx in range(len(train_ds)):
            if all(per_good[cls_name] >= max_good_per_class for cls_name in target_good_classes):
                break
            item = train_ds[idx]
            cls_name = item["cls_name"]
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_good[cls_name] >= max_good_per_class:
                continue
            per_good[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=dpam_layer)
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                patch_scores = patch_text_score(patch_feature, text_pair, mode=host_patch_score_mode)
                k = max(1, int(patch_scores.numel() * hard_frac))
                top_idx = torch.topk(patch_scores, k=k, largest=True).indices
                selected = patch[top_idx]
                selected_scores = patch_scores[top_idx]
                if selected.shape[0] > max_fp_per_image:
                    keep = farthest_point_subsample_indices(selected.detach().cpu(), max_fp_per_image).to(selected.device)
                    selected = selected[keep]
                    selected_scores = selected_scores[keep]
                fp_chunks[layer_idx].append(selected.cpu())
                fp_score_chunks[layer_idx].append(selected_scores.detach().cpu())

        for idx in range(len(test_ds)):
            if all(per_defect[cls_name] >= max_defect_per_class for cls_name in target_defect_classes):
                break
            item = test_ds[idx]
            cls_name = item["cls_name"]
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0:
                continue
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_defect[cls_name] >= max_defect_per_class:
                continue
            per_defect[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"].unsqueeze(0).to(device).float()
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=dpam_layer)
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                patch_scores = patch_text_score(patch_feature, text_pair, mode=host_patch_score_mode)
                h = int(round(patch.shape[0] ** 0.5))
                gt_small = F.interpolate(gt_mask, size=(h, h), mode="nearest")[0, 0].reshape(-1) > 0.5
                if int(gt_small.sum().item()) == 0:
                    continue
                selected = patch[gt_small]
                selected_scores = patch_scores[gt_small]
                if selected.shape[0] > max_defect_per_image:
                    keep = farthest_point_subsample_indices(selected.detach().cpu(), max_defect_per_image).to(selected.device)
                    selected = selected[keep]
                    selected_scores = selected_scores[keep]
                def_chunks[layer_idx].append(selected.cpu())
                def_score_chunks[layer_idx].append(selected_scores.detach().cpu())

    fp_banks: dict[int, torch.Tensor] = {}
    def_banks: dict[int, torch.Tensor] = {}
    fp_scores: dict[int, torch.Tensor] = {}
    def_scores: dict[int, torch.Tensor] = {}
    bank_stats: dict[int, dict] = {}
    for layer_idx in range(len(features_list)):
        fp_bank = torch.cat(fp_chunks[layer_idx], dim=0) if fp_chunks[layer_idx] else torch.empty((0, 768))
        def_bank = torch.cat(def_chunks[layer_idx], dim=0) if def_chunks[layer_idx] else torch.empty((0, 768))
        fp_score = torch.cat(fp_score_chunks[layer_idx], dim=0) if fp_score_chunks[layer_idx] else torch.empty((0,))
        def_score = torch.cat(def_score_chunks[layer_idx], dim=0) if def_score_chunks[layer_idx] else torch.empty((0,))
        if fp_bank.shape[0] > max_bank_per_layer:
            keep = farthest_point_subsample_indices(fp_bank, max_bank_per_layer)
            fp_bank = fp_bank[keep]
            fp_score = fp_score[keep]
        if def_bank.shape[0] > max_bank_per_layer:
            keep = farthest_point_subsample_indices(def_bank, max_bank_per_layer)
            def_bank = def_bank[keep]
            def_score = def_score[keep]
        fp_banks[layer_idx] = F.normalize(fp_bank.float(), dim=-1) if fp_bank.numel() else fp_bank.float()
        def_banks[layer_idx] = F.normalize(def_bank.float(), dim=-1) if def_bank.numel() else def_bank.float()
        fp_scores[layer_idx] = fp_score.float()
        def_scores[layer_idx] = def_score.float()
        bank_stats[layer_idx] = {
            "num_fp": int(fp_banks[layer_idx].shape[0]),
            "num_defect": int(def_banks[layer_idx].shape[0]),
            "fp_host_score_mean": float(fp_scores[layer_idx].mean().item()) if fp_scores[layer_idx].numel() else float("nan"),
            "defect_host_score_mean": float(def_scores[layer_idx].mean().item()) if def_scores[layer_idx].numel() else float("nan"),
            "fp_host_score_std": float(fp_scores[layer_idx].std().item()) if fp_scores[layer_idx].numel() > 1 else 0.0,
            "defect_host_score_std": float(def_scores[layer_idx].std().item()) if def_scores[layer_idx].numel() > 1 else 0.0,
        }
    return fp_banks, def_banks, fp_scores, def_scores, bank_stats


def get_or_collect_source_patch_banks_with_scores(
    model,
    text_pair: torch.Tensor,
    data_root: str,
    source_dataset: str,
    image_size: int,
    features_list: list[int],
    device: str,
    heldout_class: str | None,
    max_good_per_class: int,
    max_defect_per_class: int,
    hard_frac: float,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    checkpoint_path: str,
    model_name_or_path: str,
    allow_prompt_projection: bool,
    prompt_projection_ridge: float,
    dpam_layer: int,
    bank_cache_path: str | None,
    score_bank_cache_path_arg: str | None,
    refresh_bank_cache: bool,
    host_patch_score_mode: str,
):
    requested_cache_meta = {
        "checkpoint_path": str(checkpoint_path),
        "model_name_or_path": str(model_name_or_path),
        "allow_prompt_projection": bool(allow_prompt_projection),
        "prompt_projection_ridge": float(prompt_projection_ridge),
        "source_root": str(data_root),
        "source_dataset": source_dataset,
        "heldout_class": heldout_class,
        "image_size": int(image_size),
        "features_list": list(features_list),
        "hard_frac": float(hard_frac),
        "max_good_per_class": int(max_good_per_class),
        "max_defect_per_class": int(max_defect_per_class),
        "max_bank_per_layer": int(max_bank_per_layer),
        "max_fp_per_image": int(max_fp_per_image),
        "max_defect_per_image": int(max_defect_per_image),
        "dpam_layer": int(dpam_layer),
        "host_patch_score_mode": str(host_patch_score_mode),
        "contains_host_scores": True,
    }
    cache_path = score_bank_cache_path(
        checkpoint_path=checkpoint_path,
        model_name_or_path=model_name_or_path,
        allow_prompt_projection=allow_prompt_projection,
        prompt_projection_ridge=prompt_projection_ridge,
        source_root=data_root,
        source_dataset=source_dataset,
        heldout_class=heldout_class,
        image_size=image_size,
        features_list=features_list,
        hard_frac=hard_frac,
        max_good_per_class=max_good_per_class,
        max_defect_per_class=max_defect_per_class,
        max_bank_per_layer=max_bank_per_layer,
        max_fp_per_image=max_fp_per_image,
        max_defect_per_image=max_defect_per_image,
        dpam_layer=dpam_layer,
        explicit_path=score_bank_cache_path_arg,
        legacy_bank_cache_path=bank_cache_path,
    )
    if cache_path.exists() and not refresh_bank_cache:
        payload = torch.load(cache_path, map_location="cpu")
        cache_meta = payload.get("cache_meta", {})
        required_keys = {"fp_banks", "def_banks", "fp_scores", "defect_scores", "bank_stats"}
        if cache_meta == requested_cache_meta and required_keys.issubset(payload.keys()):
            return (
                {int(k): v.float() for k, v in payload["fp_banks"].items()},
                {int(k): v.float() for k, v in payload["def_banks"].items()},
                {int(k): v.float() for k, v in payload["fp_scores"].items()},
                {int(k): v.float() for k, v in payload["defect_scores"].items()},
                {int(k): v for k, v in payload["bank_stats"].items()},
                cache_path,
                cache_meta,
            )
        print(json.dumps({"stage": "score_bank_cache_mismatch", "cache_path": str(cache_path)}), flush=True)

    fp_banks, def_banks, fp_scores, def_scores, bank_stats = collect_source_patch_banks_with_scores(
        model=model,
        text_pair=text_pair,
        data_root=data_root,
        source_dataset=source_dataset,
        image_size=image_size,
        features_list=features_list,
        device=device,
        heldout_class=heldout_class,
        max_good_per_class=max_good_per_class,
        max_defect_per_class=max_defect_per_class,
        hard_frac=hard_frac,
        max_bank_per_layer=max_bank_per_layer,
        max_fp_per_image=max_fp_per_image,
        max_defect_per_image=max_defect_per_image,
        dpam_layer=dpam_layer,
        host_patch_score_mode=host_patch_score_mode,
    )
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_meta = requested_cache_meta
    torch.save(
        {
            "fp_banks": {int(k): v.detach().cpu() for k, v in fp_banks.items()},
            "def_banks": {int(k): v.detach().cpu() for k, v in def_banks.items()},
            "fp_scores": {int(k): v.detach().cpu() for k, v in fp_scores.items()},
            "defect_scores": {int(k): v.detach().cpu() for k, v in def_scores.items()},
            "bank_stats": bank_stats,
            "cache_meta": cache_meta,
        },
        cache_path,
    )
    return fp_banks, def_banks, fp_scores, def_scores, bank_stats, cache_path, cache_meta


def pixel_average_precision(result: dict, label: str) -> float:
    gt = np.array(result[label]["imgs_masks"]).ravel()
    pr = np.array(result[label]["anomaly_maps"]).ravel()
    return float(average_precision_score(gt, pr))


def precompute_aupro_regions(masks: np.ndarray) -> dict:
    masks = np.asarray(masks)
    if masks.ndim == 4:
        masks = masks.squeeze(1)
    masks = (masks > 0.5).astype(np.uint8)
    inverse_masks = 1 - masks
    regions_by_image: list[list[np.ndarray]] = []
    for mask in masks:
        regions = []
        labeled = measure.label(mask)
        for region in measure.regionprops(labeled):
            regions.append(region.coords)
        regions_by_image.append(regions)
    return {
        "masks": masks,
        "inverse_masks": inverse_masks,
        "inverse_total": int(inverse_masks.sum()),
        "regions_by_image": regions_by_image,
        "has_foreground": bool(masks.sum() > 0),
    }


def calculate_fast_aupro(
    masks: np.ndarray,
    maps: np.ndarray,
    max_step: int = 200,
    expect_fpr: float = 0.3,
    precomputed: dict | None = None,
) -> float:
    pre = precomputed if precomputed is not None else precompute_aupro_regions(masks)
    if not pre["has_foreground"] or pre["inverse_total"] <= 0:
        return float("nan")
    maps = np.asarray(maps, dtype=np.float32)
    if maps.ndim == 4:
        maps = maps.squeeze(1)
    min_th = float(np.min(maps))
    max_th = float(np.max(maps))
    if not np.isfinite(min_th) or not np.isfinite(max_th) or max_th <= min_th:
        return 0.5
    thresholds = np.linspace(min_th, max_th, num=max(2, int(max_step)), endpoint=False, dtype=np.float32)
    pros: list[float] = []
    fprs: list[float] = []
    inverse_masks = pre["inverse_masks"]
    inverse_total = int(pre["inverse_total"])
    for th in thresholds:
        binary_maps = maps > float(th)
        pro_vals = []
        for binary_map, regions in zip(binary_maps, pre["regions_by_image"]):
            for coords in regions:
                pro_vals.append(float(binary_map[coords[:, 0], coords[:, 1]].sum() / max(coords.shape[0], 1)))
        if not pro_vals:
            continue
        fp_pixels = np.logical_and(inverse_masks, binary_maps).sum()
        pros.append(float(np.mean(pro_vals)))
        fprs.append(float(fp_pixels / inverse_total))
    if not pros:
        return float("nan")
    pros_np = np.asarray(pros, dtype=np.float32)
    fprs_np = np.asarray(fprs, dtype=np.float32)
    keep = fprs_np < float(expect_fpr)
    if int(keep.sum()) <= 2:
        return 0.5
    fprs_keep = fprs_np[keep]
    denom = float(fprs_keep.max() - fprs_keep.min())
    if denom <= 1e-12:
        return 0.5
    fprs_keep = (fprs_keep - fprs_keep.min()) / denom
    return float(auc(fprs_keep, pros_np[keep]))


def normalized_topk_mean(arr: np.ndarray, frac: float) -> float:
    vals = np.asarray(arr, dtype=np.float32)
    vals = (vals - float(vals.min())) / (float(vals.max()) - float(vals.min()) + 1e-6)
    return topk_mean(vals, frac)


def evaluate_target(
    model,
    text_pair: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    dataset,
    target_dataset: str,
    heldout_class: str | None,
    target_classes: set[str] | None,
    features_list: list[int],
    baseline_features_list: list[int] | None,
    tau: float,
    axis: torch.Tensor,
    image_score_topk: float,
    max_normal_eval_images: int | None,
    max_anomaly_eval_images: int | None,
    sigma: float,
    source_calibrators: dict[int, dict] | None = None,
    calib_lambda: float = 1.0,
    calib_map_anchor: str = "host",
    ted_image_score_mode: str = "map_topk",
    ted_image_fusion_weight: float = 0.1,
    parallel_image_fusion_weight: float | None = None,
    calibrated_image_fusion_weight: float | None = None,
    ted_image_fusion_weights: list[float] | None = None,
    skip_pixel_aupro: bool = False,
    skip_separability_metrics: bool = False,
    image_only_probe: bool = False,
    dpam_layer: int = 20,
    aupro_max_step: int = 200,
    host_patch_score_mode: str = "prob",
    baseline_patch_score_mode: str = "prob",
    ted_active_layer_indices: list[int] | None = None,
    ted_layer_signs: dict[int, float] | None = None,
):
    baseline_features_list = list(baseline_features_list or features_list)
    if ted_active_layer_indices is None:
        ted_active_layer_indices = list(range(len(features_list)))
    ted_active_layer_indices = sorted({int(idx) for idx in ted_active_layer_indices})
    if not ted_active_layer_indices:
        raise ValueError("ted_active_layer_indices must contain at least one layer index")
    invalid_layers = [idx for idx in ted_active_layer_indices if idx < 0 or idx >= len(features_list)]
    if invalid_layers:
        raise ValueError(f"Invalid TED layer indices {invalid_layers} for features_list={features_list}")
    ted_active_layer_set = set(ted_active_layer_indices)
    ted_layer_signs = {int(k): float(v) for k, v in (ted_layer_signs or {}).items()}
    bank_device = axis.device
    fp_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in fp_banks.items()}
    def_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in def_banks.items()}
    projected_banks = {}
    for layer_idx in ted_active_layer_indices:
        fp_coeff, _ = project_bank(fp_banks[layer_idx], axis)
        def_coeff, _ = project_bank(def_banks[layer_idx], axis)
        projected_banks[layer_idx] = {
            "fp_parallel_coeff": fp_coeff,
            "def_parallel_coeff": def_coeff,
        }
    if ted_image_fusion_weights is not None:
        parallel_weight_values = [float(w) for w in ted_image_fusion_weights]
        calibrated_weight_values = [float(w) for w in ted_image_fusion_weights]
    else:
        parallel_weight_values = [
            float(ted_image_fusion_weight if parallel_image_fusion_weight is None else parallel_image_fusion_weight)
        ]
        calibrated_weight_values = [
            float(ted_image_fusion_weight if calibrated_image_fusion_weight is None else calibrated_image_fusion_weight)
        ]

    if target_classes:
        label_list = [cls_name for cls_name in dataset.obj_list if cls_name in target_classes]
    elif target_dataset == "mvtec" and heldout_class is not None:
        label_list = [heldout_class]
    else:
        label_list = list(dataset.obj_list)

    results = {
        ("baseline_txt", 0.0): {label: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for label in label_list},
    }
    for image_weight in parallel_weight_values:
        results[("parallel_margin", image_weight)] = {
            label: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for label in label_list
        }
    if source_calibrators:
        for image_weight in calibrated_weight_values:
            results[("ted_calibrated", image_weight)] = {
                label: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for label in label_list
            }
    stats = {
        key: {
            label: {"inside_scores": [], "outside_scores": [], "fpoutside_scores": [], "inside_outside_gap": []}
            for label in label_list
        }
        for key in results
    }
    raw_stats = {
        label: {
            "s_txt_inside": [],
            "s_txt_outside": [],
            "r_parallel_inside": [],
            "r_parallel_outside": [],
        }
        for label in label_list
    }

    num_normal_done = {label: 0 for label in label_list}
    num_anomaly_done = {label: 0 for label in label_list}
    with torch.no_grad():
        for idx in range(len(dataset)):
            item = dataset[idx]
            cls_label = item["cls_name"]
            if target_classes is not None:
                if cls_label not in target_classes:
                    continue
            elif target_dataset == "mvtec" and heldout_class is not None and cls_label != heldout_class:
                continue

            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0 and max_normal_eval_images is not None and num_normal_done[cls_label] >= max_normal_eval_images:
                continue
            if anomaly_flag == 1 and max_anomaly_eval_images is not None and num_anomaly_done[cls_label] >= max_anomaly_eval_images:
                continue

            image = item["img"].unsqueeze(0).to(next(model.parameters()).device)
            gt_mask = item["img_mask"].unsqueeze(0).clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask_np = gt_mask[0, 0].numpy().astype(bool)

            if anomaly_flag == 0:
                num_normal_done[cls_label] += 1
            else:
                num_anomaly_done[cls_label] += 1

            image_features, patch_features = model.encode_image(image, features_list, DPAM_layer=dpam_layer)
            if baseline_features_list == features_list:
                baseline_patch_features = patch_features
            else:
                _, baseline_patch_features = model.encode_image(
                    image, baseline_features_list, DPAM_layer=dpam_layer
                )
            image_features = F.normalize(image_features.float(), dim=-1)
            baseline_image_score = float(((image_features @ text_pair.t()) / 0.07).softmax(dim=-1)[0, 1].item())
            txt_maps = []
            parallel_maps = []
            calibrated_maps = []
            calibrated_delta_maps = []
            for baseline_patch_feature in baseline_patch_features:
                s_base = patch_text_score(baseline_patch_feature, text_pair, mode=baseline_patch_score_mode)
                base_patch = baseline_patch_feature[:, 1:, :].reshape(-1, baseline_patch_feature.shape[-1])
                h_base = int(round(base_patch.shape[0] ** 0.5))
                txt_maps.append(s_base.reshape(h_base, h_base).detach().cpu().numpy())
            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx not in ted_active_layer_set:
                    continue
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                patch_coeff = patch @ axis
                banks = projected_banks[layer_idx]

                s_txt = patch_text_score(patch_feature, text_pair, mode=host_patch_score_mode)
                q_fp_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["fp_parallel_coeff"], tau=tau)
                q_def_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["def_parallel_coeff"], tau=tau)

                h = int(round(patch.shape[0] ** 0.5))
                margin_sign = float(ted_layer_signs.get(layer_idx, 1.0))
                parallel_maps.append((margin_sign * (q_def_parallel - q_fp_parallel)).reshape(h, h).detach().cpu().numpy())
                if source_calibrators and layer_idx in source_calibrators:
                    calibrator = source_calibrators[layer_idx]
                    rect_tokens = prescore_subspace_transport_tokens(
                        tokens=patch.unsqueeze(0).float(),
                        q_def=q_def_parallel.view(1, -1),
                        q_fp=q_fp_parallel.view(1, -1),
                        basis=calibrator["basis"],
                        eta=float(calibrator["eta"]),
                        direction=calibrator["transport_direction"],
                        transport_b=float(calibrator["transport_b"]),
                        fp_weight=float(calibrator["fp_weight"]),
                        margin_sign=margin_sign,
                    )
                    calibrated_token_score = subspace_host_residual_token_score(
                        host_score=s_txt.view(1, -1),
                        rect_tokens=rect_tokens,
                        basis=calibrator["basis"],
                        score_w=calibrator["subspace_score_w"],
                        readout_gamma=float(calibrator["readout_gamma"]),
                    )[0]
                    delta_score = calibrated_token_score - s_txt
                    token_score = s_txt + float(calib_lambda) * delta_score
                    calibrated_maps.append(token_score.reshape(h, h).detach().cpu().numpy())
                    calibrated_delta_maps.append(delta_score.reshape(h, h).detach().cpu().numpy())

            target_h, target_w = gt_mask_np.shape

            def resize_map(arr: np.ndarray) -> np.ndarray:
                return (
                    F.interpolate(
                        torch.from_numpy(arr).unsqueeze(0).unsqueeze(0).float(),
                        size=(target_h, target_w),
                        mode="bilinear",
                        align_corners=False,
                    )[0, 0]
                    .cpu()
                    .numpy()
                )

            s_txt_map = resize_map(np.mean(np.stack(txt_maps, axis=0), axis=0))
            r_parallel_map = resize_map(np.mean(np.stack(parallel_maps, axis=0), axis=0))
            s_txt_map = gaussian_filter(s_txt_map, sigma=sigma)
            r_parallel_map = gaussian_filter(r_parallel_map, sigma=sigma)
            calibrated_map = None
            if calibrated_maps:
                calibrated_map = resize_map(np.mean(np.stack(calibrated_maps, axis=0), axis=0))
                calibrated_map = gaussian_filter(calibrated_map, sigma=sigma)
                if calib_map_anchor == "host_full":
                    delta_map = resize_map(np.mean(np.stack(calibrated_delta_maps, axis=0), axis=0))
                    delta_map = gaussian_filter(delta_map, sigma=sigma)
                    calibrated_map = s_txt_map + float(calib_lambda) * delta_map
                if calib_map_anchor == "trainfree":
                    delta_map = resize_map(np.mean(np.stack(calibrated_delta_maps, axis=0), axis=0))
                    delta_map = gaussian_filter(delta_map, sigma=sigma)
                    delta_map = (delta_map - float(delta_map.mean())) / (float(delta_map.std()) + 1e-6)
                    calibrated_map = r_parallel_map + float(calib_lambda) * (float(r_parallel_map.std()) + 1e-6) * delta_map
            fpoutside_mask = (~gt_mask_np) & (r_parallel_map < 0.0)

            final_maps = {
                "baseline_txt": s_txt_map,
                "parallel_margin": r_parallel_map,
            }
            if calibrated_map is not None:
                final_maps["ted_calibrated"] = calibrated_map

            for mode_name, final_map in final_maps.items():
                if mode_name == "baseline_txt":
                    keys = [("baseline_txt", 0.0)]
                elif mode_name == "parallel_margin":
                    keys = [("parallel_margin", w) for w in parallel_weight_values]
                else:
                    keys = [("ted_calibrated", w) for w in calibrated_weight_values]
                for key in keys:
                    results[key][cls_label]["gt_sp"].append(anomaly_flag)
                    if key[0] == "baseline_txt":
                        results[key][cls_label]["pr_sp"].append(baseline_image_score)
                    else:
                        image_weight = float(key[1])
                        if ted_image_score_mode == "host":
                            image_score = baseline_image_score
                        elif ted_image_score_mode == "host_plus_topk":
                            image_score = baseline_image_score + image_weight * topk_mean(final_map, image_score_topk)
                        elif ted_image_score_mode == "host_plus_norm_topk":
                            image_score = baseline_image_score + image_weight * normalized_topk_mean(final_map, image_score_topk)
                        elif ted_image_score_mode == "norm_topk":
                            image_score = normalized_topk_mean(final_map, image_score_topk)
                        else:
                            image_score = topk_mean(final_map, image_score_topk)
                        results[key][cls_label]["pr_sp"].append(float(image_score))
                    if not image_only_probe:
                        results[key][cls_label]["imgs_masks"].append(gt_mask.numpy())
                        results[key][cls_label]["anomaly_maps"].append(final_map[None, ...])

                    if not image_only_probe and not skip_separability_metrics and gt_mask_np.any() and (~gt_mask_np).any():
                        inside_scores = final_map[gt_mask_np]
                        outside_scores = final_map[~gt_mask_np]
                        fpoutside_scores = final_map[fpoutside_mask]
                        stats[key][cls_label]["inside_scores"].append(inside_scores.astype(np.float32, copy=False))
                        stats[key][cls_label]["outside_scores"].append(outside_scores.astype(np.float32, copy=False))
                        stats[key][cls_label]["fpoutside_scores"].append(fpoutside_scores.astype(np.float32, copy=False))
                        stats[key][cls_label]["inside_outside_gap"].append(float(inside_scores.mean() - outside_scores.mean()))

            if not image_only_probe and not skip_separability_metrics and gt_mask_np.any() and (~gt_mask_np).any():
                raw_stats[cls_label]["s_txt_inside"].append(float(s_txt_map[gt_mask_np].mean()))
                raw_stats[cls_label]["s_txt_outside"].append(float(s_txt_map[~gt_mask_np].mean()))
                raw_stats[cls_label]["r_parallel_inside"].append(float(r_parallel_map[gt_mask_np].mean()))
                raw_stats[cls_label]["r_parallel_outside"].append(float(r_parallel_map[~gt_mask_np].mean()))

            total_done = num_normal_done[cls_label] + num_anomaly_done[cls_label]
            if total_done % 8 == 0:
                print(json.dumps({"stage": "eval_progress", "class": cls_label, "normal_done": num_normal_done[cls_label], "anomaly_done": num_anomaly_done[cls_label]}), flush=True)

    rows = []
    aupro_cache: dict[str, dict] = {}
    for key, result in results.items():
        mode_rows = []
        for label in label_list:
            if not result[label]["gt_sp"]:
                continue
            print(
                json.dumps(
                    {
                        "stage": "metric_progress",
                        "mode": key[0],
                        "beta": key[1],
                        "class": label,
                        "num_images": len(result[label]["gt_sp"]),
                    }
                ),
                flush=True,
            )
            if not image_only_probe:
                result[label]["imgs_masks"] = np.concatenate(result[label]["imgs_masks"], axis=0)
                result[label]["anomaly_maps"] = np.concatenate(result[label]["anomaly_maps"], axis=0)
            if not image_only_probe and not skip_pixel_aupro and label not in aupro_cache:
                aupro_cache[label] = precompute_aupro_regions(result[label]["imgs_masks"])
            inside = np.concatenate(stats[key][label]["inside_scores"], axis=0) if stats[key][label]["inside_scores"] else np.empty((0,), dtype=np.float32)
            outside = np.concatenate(stats[key][label]["outside_scores"], axis=0) if stats[key][label]["outside_scores"] else np.empty((0,), dtype=np.float32)
            fpoutside = np.concatenate(stats[key][label]["fpoutside_scores"], axis=0) if stats[key][label]["fpoutside_scores"] else np.empty((0,), dtype=np.float32)
            inside_mean = float(np.mean(inside)) if inside.size else float("nan")
            fpoutside_mean = float(np.mean(fpoutside)) if fpoutside.size else float("nan")
            row = {
                "mode": key[0],
                "beta": key[1],
                "target_label": label,
                "image_auroc": float(image_level_metrics(result, label, "image-auroc")),
                "pixel_auroc": float("nan") if image_only_probe else float(pixel_level_metrics(result, label, "pixel-auroc")),
                "pixel_aupro": float("nan")
                if (image_only_probe or skip_pixel_aupro)
                else calculate_fast_aupro(
                    result[label]["imgs_masks"],
                    result[label]["anomaly_maps"],
                    max_step=aupro_max_step,
                    precomputed=aupro_cache[label],
                ),
                "pixel_ap": float("nan") if image_only_probe else pixel_average_precision(result, label),
                "inside_vs_outside_auc": safe_auc(inside, outside),
                "inside_vs_fpoutside_auc": safe_auc(inside, fpoutside),
                "inside_outside_gap": float(np.mean(stats[key][label]["inside_outside_gap"])) if stats[key][label]["inside_outside_gap"] else float("nan"),
                "inside_mean": inside_mean,
                "fpoutside_mean": fpoutside_mean,
                "inside_fpoutside_gap": inside_mean - fpoutside_mean,
                "s_txt_inside_mean": float(np.mean(raw_stats[label]["s_txt_inside"])) if raw_stats[label]["s_txt_inside"] else float("nan"),
                "s_txt_outside_mean": float(np.mean(raw_stats[label]["s_txt_outside"])) if raw_stats[label]["s_txt_outside"] else float("nan"),
                "r_parallel_inside_mean": float(np.mean(raw_stats[label]["r_parallel_inside"])) if raw_stats[label]["r_parallel_inside"] else float("nan"),
                "r_parallel_outside_mean": float(np.mean(raw_stats[label]["r_parallel_outside"])) if raw_stats[label]["r_parallel_outside"] else float("nan"),
                "num_inside": int(inside.size),
                "num_outside": int(outside.size),
                "num_fpoutside": int(fpoutside.size),
            }
            rows.append(row)
            mode_rows.append(row)
        if mode_rows:
            rows.append(
                {
                    "mode": key[0],
                    "beta": key[1],
                    "target_label": "mean",
                    "image_auroc": float(np.nanmean([row["image_auroc"] for row in mode_rows])),
                    "pixel_auroc": float(np.nanmean([row["pixel_auroc"] for row in mode_rows])),
                    "pixel_aupro": float(np.nanmean([row["pixel_aupro"] for row in mode_rows])),
                    "pixel_ap": float(np.nanmean([row["pixel_ap"] for row in mode_rows])),
                    "inside_vs_outside_auc": float(np.nanmean([row["inside_vs_outside_auc"] for row in mode_rows])),
                    "inside_vs_fpoutside_auc": float(np.nanmean([row["inside_vs_fpoutside_auc"] for row in mode_rows])),
                    "inside_outside_gap": float(np.nanmean([row["inside_outside_gap"] for row in mode_rows])),
                    "inside_mean": float(np.nanmean([row["inside_mean"] for row in mode_rows])),
                    "fpoutside_mean": float(np.nanmean([row["fpoutside_mean"] for row in mode_rows])),
                    "inside_fpoutside_gap": float(np.nanmean([row["inside_fpoutside_gap"] for row in mode_rows])),
                    "s_txt_inside_mean": float(np.nanmean([row["s_txt_inside_mean"] for row in mode_rows])),
                    "s_txt_outside_mean": float(np.nanmean([row["s_txt_outside_mean"] for row in mode_rows])),
                    "r_parallel_inside_mean": float(np.nanmean([row["r_parallel_inside_mean"] for row in mode_rows])),
                    "r_parallel_outside_mean": float(np.nanmean([row["r_parallel_outside_mean"] for row in mode_rows])),
                    "num_inside": int(np.sum([row["num_inside"] for row in mode_rows])),
                    "num_outside": int(np.sum([row["num_outside"] for row in mode_rows])),
                    "num_fpoutside": int(np.sum([row["num_fpoutside"] for row in mode_rows])),
                }
            )
    return rows


def save_results(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Evaluate baseline text score vs parallel-margin score on AnomalyCLIP")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--source_dataset", type=str, default="mvtec")
    parser.add_argument("--target_root", type=str, default=None)
    parser.add_argument("--target_dataset", type=str, default="mvtec")
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument("--source_exclude_class", type=str, default=None)
    parser.add_argument("--checkpoint_path", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"))
    parser.add_argument("--model_name_or_path", type=str, default="ViT-L/14@336px")
    parser.add_argument("--allow_prompt_projection", action="store_true")
    parser.add_argument("--prompt_projection_ridge", type=float, default=1e-3)
    parser.add_argument("--save_dir", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_text_decomposition_score_epoch5"))
    parser.add_argument("--heldout_class", type=str, default="bottle")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--dpam_layer", type=int, default=20)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument(
        "--baseline_features_list",
        type=int,
        nargs="+",
        default=None,
        help="Feature layers used only for the reported baseline map. TED banks and OURS use --features_list.",
    )
    parser.add_argument(
        "--host_patch_score_mode",
        type=str,
        choices=["prob", "logit_margin", "neg_logit_margin", "cos_margin", "neg_cos_margin"],
        default="prob",
        help="Local host score used for source hard-FP mining and C-TED anchoring.",
    )
    parser.add_argument(
        "--baseline_patch_score_mode",
        type=str,
        choices=["prob", "logit_margin", "neg_logit_margin", "cos_margin", "neg_cos_margin"],
        default="prob",
        help="Local score used only for the reported baseline text map.",
    )
    parser.add_argument(
        "--ted_layer_gate",
        type=str,
        choices=["none", "def_gt_fp"],
        default="none",
        help=(
            "Source-only gate for TED layers. def_gt_fp keeps only layers where source defect bank "
            "has a higher mean host score than the hard-FP bank."
        ),
    )
    parser.add_argument(
        "--ted_layer_gate_margin",
        type=float,
        default=0.0,
        help="Minimum source defect-minus-hard-FP host-score margin required by --ted_layer_gate def_gt_fp.",
    )
    parser.add_argument(
        "--ted_layer_gate_fallback",
        type=str,
        choices=["all", "last"],
        default="last",
        help="Fallback TED layer recipe if the source-only gate selects no layer.",
    )
    parser.add_argument(
        "--ted_margin_sign",
        type=str,
        choices=["def_minus_fp", "fp_minus_def", "auto_source"],
        default="def_minus_fp",
        help=(
            "Orientation of the train-free TED margin. auto_source chooses the sign that ranks source "
            "defect-bank patches above source hard-FP-bank patches for each active layer."
        ),
    )
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--score_bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument(
        "--ted_image_score_mode",
        type=str,
        choices=["map_topk", "host", "host_plus_topk", "host_plus_norm_topk", "norm_topk"],
        default="map_topk",
    )
    parser.add_argument("--ted_image_fusion_weight", type=float, default=0.1)
    parser.add_argument("--parallel_image_fusion_weight", type=float, default=None)
    parser.add_argument("--calibrated_image_fusion_weight", type=float, default=None)
    parser.add_argument(
        "--ted_image_fusion_weights",
        type=str,
        default=None,
        help="Optional comma-separated image fusion weights evaluated in one forward pass.",
    )
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--max_normal_eval_images", type=int, default=None)
    parser.add_argument("--max_anomaly_eval_images", type=int, default=None)
    parser.add_argument("--skip_pixel_aupro", action="store_true")
    parser.add_argument("--aupro_max_step", type=int, default=200)
    parser.add_argument("--skip_separability_metrics", action="store_true")
    parser.add_argument("--image_only_probe", action="store_true")
    parser.add_argument("--prepare_bank_only", action="store_true")
    parser.add_argument("--enable_calibrator", action="store_true")
    parser.add_argument("--calib_subspace_rank", type=int, default=8)
    parser.add_argument("--calib_max_train_points", type=int, default=4096)
    parser.add_argument("--calib_epochs", type=int, default=80)
    parser.add_argument("--calib_lr", type=float, default=0.05)
    parser.add_argument("--calib_rank_margin", type=float, default=0.05)
    parser.add_argument("--calib_rank_temp", type=float, default=0.05)
    parser.add_argument("--calib_eta_init", type=float, default=0.05)
    parser.add_argument("--calib_eta_max", type=float, default=0.5)
    parser.add_argument("--calib_eta_reg", type=float, default=0.001)
    parser.add_argument("--calib_fp_weight_init", type=float, default=1.0)
    parser.add_argument("--calib_learn_fp_weight", action="store_true")
    parser.add_argument("--calib_hardpair_frac", type=float, default=0.75)
    parser.add_argument("--calib_preserve_host_margin_weight", type=float, default=0.5)
    parser.add_argument("--calib_lambda", type=float, default=1.0)
    parser.add_argument("--calib_map_anchor", type=str, choices=["host", "host_full", "trainfree"], default="host")
    parser.add_argument("--calib_seed", type=int, default=0)
    parser.add_argument("--calib_pair_label_control", type=str, default="correct", choices=["correct", "shuffle", "swap"])
    parser.add_argument("--calib_skip_degenerate_host_layers", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--calib_host_score_std_eps", type=float, default=1e-6)
    args = parser.parse_args()
    if args.heldout_class is not None and str(args.heldout_class).lower() in {"", "none", "null", "all"}:
        args.heldout_class = None
    ted_image_fusion_weights = None
    if args.ted_image_fusion_weights:
        ted_image_fusion_weights = [
            float(weight.strip())
            for weight in args.ted_image_fusion_weights.split(",")
            if weight.strip()
        ]

    model, params = build_model(
        args.device,
        args.depth,
        args.n_ctx,
        args.t_n_ctx,
        args.model_name_or_path,
        args.dpam_layer,
    )
    learner = load_prompt_learner(
        model,
        params,
        Path(args.checkpoint_path),
        args.device,
        allow_projection=args.allow_prompt_projection,
        projection_ridge=args.prompt_projection_ridge,
    )
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    learned_axis = decision_axis(learned_pair).to(args.device)
    source_exclude_class = args.source_exclude_class if args.source_exclude_class else args.heldout_class

    fp_banks, def_banks, fp_scores, def_scores, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks_with_scores(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=source_exclude_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=args.checkpoint_path,
        model_name_or_path=args.model_name_or_path,
        allow_prompt_projection=args.allow_prompt_projection,
        prompt_projection_ridge=args.prompt_projection_ridge,
        dpam_layer=args.dpam_layer,
        bank_cache_path=args.bank_cache_path,
        score_bank_cache_path_arg=args.score_bank_cache_path,
        refresh_bank_cache=args.refresh_bank_cache,
        host_patch_score_mode=args.host_patch_score_mode,
    )
    if args.prepare_bank_only:
        payload = {
            "bank_cache_path": str(bank_cache_path),
            "bank_cache_meta": bank_cache_meta,
            "bank_stats": bank_stats,
            "checkpoint_path": args.checkpoint_path,
            "source_root": args.source_root,
            "source_dataset": args.source_dataset,
            "source_exclude_class": source_exclude_class,
        }
        print(json.dumps(payload, indent=2))
        return

    ted_active_layer_indices = list(range(len(args.features_list)))
    if args.ted_layer_gate == "def_gt_fp":
        gated_indices = []
        for layer_idx in range(len(args.features_list)):
            layer_stats = bank_stats[layer_idx]
            margin = float(layer_stats["defect_host_score_mean"]) - float(layer_stats["fp_host_score_mean"])
            if margin > float(args.ted_layer_gate_margin):
                gated_indices.append(layer_idx)
        if gated_indices:
            ted_active_layer_indices = gated_indices
        elif args.ted_layer_gate_fallback == "last":
            ted_active_layer_indices = [len(args.features_list) - 1]
        else:
            ted_active_layer_indices = list(range(len(args.features_list)))
        print(
            json.dumps(
                {
                    "stage": "ted_source_layer_gate",
                    "gate": args.ted_layer_gate,
                    "gate_margin": args.ted_layer_gate_margin,
                    "fallback": args.ted_layer_gate_fallback,
                    "active_layer_indices": ted_active_layer_indices,
                    "active_feature_layers": [args.features_list[idx] for idx in ted_active_layer_indices],
                    "source_layer_margins": {
                        str(idx): float(bank_stats[idx]["defect_host_score_mean"])
                        - float(bank_stats[idx]["fp_host_score_mean"])
                        for idx in range(len(args.features_list))
                    },
                }
            ),
            flush=True,
        )

    ted_layer_signs = {layer_idx: 1.0 for layer_idx in ted_active_layer_indices}
    if args.ted_margin_sign == "fp_minus_def":
        ted_layer_signs = {layer_idx: -1.0 for layer_idx in ted_active_layer_indices}
    elif args.ted_margin_sign == "auto_source":
        with torch.no_grad():
            for layer_idx in ted_active_layer_indices:
                fp_bank = F.normalize(fp_banks[layer_idx].to(learned_axis.device).float(), dim=-1)
                def_bank = F.normalize(def_banks[layer_idx].to(learned_axis.device).float(), dim=-1)
                fp_coeff, _ = project_bank(fp_bank, learned_axis)
                def_coeff, _ = project_bank(def_bank, learned_axis)
                fp_q_def = logmeanexp_negative_sqdist_1d(fp_coeff, def_coeff, tau=args.tau)
                fp_q_fp = logmeanexp_negative_sqdist_1d(fp_coeff, fp_coeff, tau=args.tau)
                def_q_def = logmeanexp_negative_sqdist_1d(def_coeff, def_coeff, tau=args.tau)
                def_q_fp = logmeanexp_negative_sqdist_1d(def_coeff, fp_coeff, tau=args.tau)
                fp_margin = float((fp_q_def - fp_q_fp).mean().item())
                def_margin = float((def_q_def - def_q_fp).mean().item())
                ted_layer_signs[layer_idx] = 1.0 if def_margin >= fp_margin else -1.0
        print(
            json.dumps(
                {
                    "stage": "ted_source_margin_orientation",
                    "mode": args.ted_margin_sign,
                    "layer_signs": ted_layer_signs,
                    "feature_layer_signs": {
                        str(args.features_list[idx]): ted_layer_signs[idx] for idx in ted_active_layer_indices
                    },
                }
            ),
            flush=True,
        )

    source_calibrators = None
    if args.enable_calibrator:
        source_calibrators = {}
        device_obj = torch.device(args.device)
        for layer_idx in ted_active_layer_indices:
            if args.calib_skip_degenerate_host_layers:
                fp_std = float(fp_scores[layer_idx].std().item()) if fp_scores[layer_idx].numel() > 1 else 0.0
                def_std = float(def_scores[layer_idx].std().item()) if def_scores[layer_idx].numel() > 1 else 0.0
                if max(fp_std, def_std) < float(args.calib_host_score_std_eps):
                    print(
                        json.dumps(
                            {
                                "stage": "source_calibrator_skip_degenerate_host_layer",
                                "layer_idx": layer_idx,
                                "feature_layer": args.features_list[layer_idx],
                                "fp_host_score_std": fp_std,
                                "defect_host_score_std": def_std,
                            }
                        ),
                        flush=True,
                    )
                    continue
            calibrator = train_subspace_host_residual_calibrator(
                banks={
                    "fp": fp_banks[layer_idx],
                    "defect": def_banks[layer_idx],
                    "fp_score": fp_scores[layer_idx],
                    "defect_score": def_scores[layer_idx],
                },
                axis=learned_axis,
                tau=args.tau,
                max_train_points=args.calib_max_train_points,
                epochs=args.calib_epochs,
                lr=args.calib_lr,
                rank_margin=args.calib_rank_margin,
                rank_temp=args.calib_rank_temp,
                eta_init=args.calib_eta_init,
                eta_max=args.calib_eta_max,
                eta_reg=args.calib_eta_reg,
                fp_weight_init=args.calib_fp_weight_init,
                learn_fp_weight=args.calib_learn_fp_weight,
                hardpair_frac=args.calib_hardpair_frac,
                subspace_rank=args.calib_subspace_rank,
                preserve_host_margin_weight=args.calib_preserve_host_margin_weight,
                margin_sign=float(ted_layer_signs.get(layer_idx, 1.0)),
                pair_label_control=args.calib_pair_label_control,
                seed=args.calib_seed + layer_idx,
                device=device_obj,
            )
            if calibrator is not None:
                source_calibrators[layer_idx] = calibrator
                print(
                    json.dumps(
                        {
                            "stage": "source_calibrator_trained",
                            "layer_idx": layer_idx,
                            "feature_layer": args.features_list[layer_idx],
                            "subspace_rank": calibrator["subspace_rank"],
                            "eta": calibrator["eta"],
                            "readout_gamma": calibrator["readout_gamma"],
                            "fp_weight": calibrator["fp_weight"],
                            "source_pair_rank_accuracy": calibrator["source_pair_rank_accuracy"],
                            "source_base_pair_rank_accuracy": calibrator["source_base_pair_rank_accuracy"],
                        }
                    ),
                    flush=True,
                )
        if not source_calibrators:
            raise RuntimeError("enable_calibrator was set, but no source calibrators could be trained")

    target_root = args.target_root or args.source_root
    dataset = build_dataset(target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    rows = evaluate_target(
        model=model,
        text_pair=learned_pair,
        fp_banks=fp_banks,
        def_banks=def_banks,
        dataset=dataset,
        target_dataset=args.target_dataset,
        heldout_class=args.heldout_class if args.target_dataset == "mvtec" else None,
        target_classes=set(args.target_classes) if args.target_classes else None,
        features_list=args.features_list,
        baseline_features_list=args.baseline_features_list,
        tau=args.tau,
        axis=learned_axis,
        image_score_topk=args.image_score_topk,
        max_normal_eval_images=args.max_normal_eval_images,
        max_anomaly_eval_images=args.max_anomaly_eval_images,
        sigma=args.sigma,
        source_calibrators=source_calibrators,
        calib_lambda=args.calib_lambda,
        calib_map_anchor=args.calib_map_anchor,
        ted_image_score_mode=args.ted_image_score_mode,
        ted_image_fusion_weight=args.ted_image_fusion_weight,
        parallel_image_fusion_weight=args.parallel_image_fusion_weight,
        calibrated_image_fusion_weight=args.calibrated_image_fusion_weight,
        ted_image_fusion_weights=ted_image_fusion_weights,
        skip_pixel_aupro=args.skip_pixel_aupro,
        skip_separability_metrics=args.skip_separability_metrics,
        image_only_probe=args.image_only_probe,
        dpam_layer=args.dpam_layer,
        aupro_max_step=args.aupro_max_step,
        host_patch_score_mode=args.host_patch_score_mode,
        baseline_patch_score_mode=args.baseline_patch_score_mode,
        ted_active_layer_indices=ted_active_layer_indices,
        ted_layer_signs=ted_layer_signs,
    )
    summary = {
        "heldout_class": args.heldout_class,
        "source_exclude_class": source_exclude_class,
        "source_root": args.source_root,
        "source_dataset": args.source_dataset,
        "target_root": target_root,
        "target_dataset": args.target_dataset,
        "target_mode": args.target_mode,
        "target_classes": sorted(args.target_classes) if args.target_classes else "all",
        "checkpoint_path": args.checkpoint_path,
        "model_name_or_path": args.model_name_or_path,
        "image_size": args.image_size,
        "features_list": list(args.features_list),
        "baseline_features_list": list(args.baseline_features_list or args.features_list),
        "allow_prompt_projection": args.allow_prompt_projection,
        "prompt_projection_ridge": args.prompt_projection_ridge,
        "hard_frac": args.hard_frac,
        "tau": args.tau,
        "image_score_topk": args.image_score_topk,
        "dpam_layer": args.dpam_layer,
        "host_patch_score_mode": args.host_patch_score_mode,
        "baseline_patch_score_mode": args.baseline_patch_score_mode,
        "ted_layer_gate": args.ted_layer_gate,
        "ted_layer_gate_margin": args.ted_layer_gate_margin,
        "ted_layer_gate_fallback": args.ted_layer_gate_fallback,
        "ted_margin_sign": args.ted_margin_sign,
        "ted_layer_signs": {str(k): v for k, v in ted_layer_signs.items()},
        "ted_active_layer_indices": ted_active_layer_indices,
        "ted_active_feature_layers": [args.features_list[idx] for idx in ted_active_layer_indices],
        "ted_image_score_mode": args.ted_image_score_mode,
        "ted_image_fusion_weight": args.ted_image_fusion_weight,
        "parallel_image_fusion_weight": args.parallel_image_fusion_weight,
        "calibrated_image_fusion_weight": args.calibrated_image_fusion_weight,
        "ted_image_fusion_weights": ted_image_fusion_weights,
        "sigma": args.sigma,
        "max_normal_eval_images": args.max_normal_eval_images,
        "max_anomaly_eval_images": args.max_anomaly_eval_images,
        "skip_pixel_aupro": args.skip_pixel_aupro,
        "aupro_max_step": args.aupro_max_step,
        "skip_separability_metrics": args.skip_separability_metrics,
        "image_only_probe": args.image_only_probe,
        "bank_stats": bank_stats,
        "bank_cache_path": str(bank_cache_path),
        "bank_cache_meta": bank_cache_meta,
        "enable_calibrator": args.enable_calibrator,
        "calib_subspace_rank": args.calib_subspace_rank,
        "calib_max_train_points": args.calib_max_train_points,
        "calib_epochs": args.calib_epochs,
        "calib_lr": args.calib_lr,
        "calib_rank_margin": args.calib_rank_margin,
        "calib_rank_temp": args.calib_rank_temp,
        "calib_eta_init": args.calib_eta_init,
        "calib_eta_max": args.calib_eta_max,
        "calib_eta_reg": args.calib_eta_reg,
        "calib_fp_weight_init": args.calib_fp_weight_init,
        "calib_learn_fp_weight": args.calib_learn_fp_weight,
        "calib_hardpair_frac": args.calib_hardpair_frac,
        "calib_preserve_host_margin_weight": args.calib_preserve_host_margin_weight,
        "calib_lambda": args.calib_lambda,
        "calib_map_anchor": args.calib_map_anchor,
        "calib_pair_label_control": args.calib_pair_label_control,
        "calib_skip_degenerate_host_layers": args.calib_skip_degenerate_host_layers,
        "calib_host_score_std_eps": args.calib_host_score_std_eps,
        "source_calibrators": None
        if source_calibrators is None
        else {
            str(k): {
                kk: vv
                for kk, vv in cal.items()
                if kk not in {"basis", "transport_direction", "subspace_score_w"}
            }
            for k, cal in source_calibrators.items()
        },
        "axis_definition": "normalize(e_anom_learned - e_norm_learned)",
        "score_definition": "baseline_txt: raw text anomaly score; parallel_margin/train-free TED: on-axis defect-vs-fp competitive margin; ted_calibrated: source-only residual subspace correction anchored to AnomalyCLIP patch-text score when calib_map_anchor=host, anchored to the full reported host map when calib_map_anchor=host_full, or anchored to train-free TED when calib_map_anchor=trainfree; host_patch_score_mode selects the host local score used for hard-FP mining and calibration anchoring",
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
