from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
OUT_DIR = ROOT / "supp_fig"


RAW_CASES = [
    (
        "Raw VLM: ViT-L, VisA target",
        ROOT / "neurips2026/results/rawclip_qualitative_vitl_macaroni_pair/rawclip_capsules_qualitative.png",
    ),
    (
        "Raw VLM: ViT-B, MVTec target",
        ROOT / "neurips2026/results/rawclip_qualitative_vitb_mvtec_capsule_pill_hist/rawclip_capsules_qualitative.png",
    ),
]


HOST_CASES = [
    (
        "Adapted host: FAPrompt, MVTec source to VisA target",
        ROOT / "neurips2026/results/faprompt_ted_story_vitl336_mvtec2visa_capsules_alpha15/faprompt_ted_story_vitl336.png",
    ),
    (
        "Adapted host: FAPrompt, VisA source to MVTec target",
        ROOT / "neurips2026/results/faprompt_ted_story_vitl336_visa2mvtec_metal_nut_alpha15/faprompt_ted_story_vitl336.png",
    ),
    (
        "Adapted host: FAPrompt, VisA source to MVTec target",
        ROOT / "neurips2026/results/faprompt_ted_story_vitl336_visa2mvtec_wood_alpha15/faprompt_ted_story_vitl336.png",
    ),
]


def load_image(path: Path) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(path)
    return np.asarray(Image.open(path).convert("RGB"))


def make_gallery(cases: list[tuple[str, Path]], stem: str, figsize: tuple[float, float]) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(len(cases), 1, figsize=figsize, constrained_layout=True)
    if len(cases) == 1:
        axes = [axes]

    for idx, (title, path) in enumerate(cases):
        ax = axes[idx]
        ax.imshow(load_image(path))
        ax.set_axis_off()
        ax.set_title(f"({chr(ord('a') + idx)}) {title}", loc="left", fontsize=12, fontweight="bold", pad=4)

    fig.savefig(OUT_DIR / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(OUT_DIR / f"{stem}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    make_gallery(
        RAW_CASES,
        "raw_vlm_failure_recovery_heatmap_gallery_20260505",
        figsize=(14.0, 7.2),
    )
    make_gallery(
        HOST_CASES,
        "adapted_host_failure_recovery_heatmap_gallery_20260505",
        figsize=(14.0, 8.5),
    )


if __name__ == "__main__":
    main()
