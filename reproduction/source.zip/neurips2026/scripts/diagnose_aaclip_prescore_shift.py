#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[2]
OFFICIAL_PATH = ROOT / "neurips2026" / "scripts" / "official_parallel_test_aaclip.py"


def load_official_module():
    spec = importlib.util.spec_from_file_location("official_parallel_test_aaclip", OFFICIAL_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {OFFICIAL_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def masked_topk_mean(values: torch.Tensor, mask: torch.Tensor, rank: torch.Tensor, frac: float) -> torch.Tensor | None:
    vals = []
    for vi, mi, ri in zip(values, mask, rank):
        idx = torch.nonzero(mi.reshape(-1), as_tuple=False).flatten()
        if idx.numel() == 0:
            continue
        vf = vi.reshape(-1)
        rf = ri.reshape(-1)
        k = max(1, int(np.ceil(idx.numel() * float(frac))))
        k = min(k, idx.numel())
        top_local = torch.topk(rf[idx], k=k, largest=True).indices
        vals.append(vf[idx[top_local]].mean())
    if not vals:
        return None
    return torch.stack(vals).mean()


def add_stat(bucket: dict, key: str, value: torch.Tensor | None) -> None:
    if value is None:
        return
    bucket.setdefault(key, []).append(float(value.detach().cpu().item()))


def mean_stat(values: list[float]) -> float:
    return float(np.mean(values)) if values else float("nan")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--topk_frac", type=float, default=0.05)
    ap.add_argument("--output", default="")
    args = ap.parse_args()

    official = load_official_module()
    official.setup_seed(0)
    official._add_aaclip_to_syspath()
    official.ensure_aaclip_pretrained_weight()

    from dataset.constants import DOMAINS
    from forward_utils import calculate_similarity_map, get_adapted_text_embedding
    from model.adapter import AdaptedCLIP
    from model.clip import create_model

    summary = json.loads(Path(args.summary).read_text())
    device = torch.device(args.device)
    img_size = int(summary["img_size"])
    levels = list(summary["levels"])

    clip_model = create_model(
        model_name=summary["model_name"],
        img_size=img_size,
        device=device,
        pretrained=summary.get("pretrained", "openai"),
        force_image_size=img_size,
        require_pretrained=True,
    )
    model = AdaptedCLIP(
        clip_model=clip_model,
        text_adapt_weight=0.1,
        image_adapt_weight=0.1,
        text_adapt_until=3,
        image_adapt_until=6,
        levels=levels,
        relu=False,
    ).to(device)
    model.eval()

    ckpt_dir = summary["ckpt_dir"]
    image_ckpt = os.path.join(ckpt_dir, "image_adapter.pth")
    ckpt = torch.load(image_ckpt, map_location="cpu")
    official.load_state_project_crop(
        model.image_adapter,
        ckpt["image_adapter"],
        mode=summary.get("adapter_load_mode", "strict"),
    )
    text_ckpt = os.path.join(ckpt_dir, "text_adapter.pth")
    if os.path.exists(text_ckpt):
        ckpt_t = torch.load(text_ckpt, map_location="cpu")
        official.load_state_project_crop(
            model.text_adapter,
            ckpt_t["text_adapter"],
            mode=summary.get("adapter_load_mode", "strict"),
        )
    for p in model.parameters():
        p.requires_grad = False

    cache_dir = ROOT / "neurips2026" / "results" / "bank_cache"
    banks = official.get_or_collect_source_banks(
        model=model,
        preset=summary["preset"],
        model_name=f"{summary['model_name']}:{summary.get('pretrained', 'openai')}",
        adapter_load_mode=summary.get("adapter_load_mode", "strict"),
        source_dataset=summary["source_dataset"],
        source_root=summary["source_root"],
        ckpt_dir=summary["ckpt_dir"],
        cache_dir=cache_dir,
        img_size=img_size,
        batch_size=int(args.batch_size),
        num_workers=int(args.num_workers),
        device=device,
        max_fp_per_class=int(summary["max_fp_per_class"]),
        max_defect_per_class=int(summary["max_defect_per_class"]),
        normal_topk_frac=float(summary["normal_topk_frac"]),
        defect_topk_frac=float(summary["defect_topk_frac"]),
        seed=0,
        source_limit_per_class=None,
    )

    target_text = get_adapted_text_embedding(model, summary["target_dataset"], device)
    source_text = get_adapted_text_embedding(model, summary["source_dataset"], device)
    source_axis = official.mean_text_anomaly_axis(source_text).to(device)
    fp_proj = [F.normalize(t.to(device), dim=-1) @ source_axis for t in banks["fp"]]
    def_proj = [F.normalize(t.to(device), dim=-1) @ source_axis for t in banks["defect"]]
    calibrators = summary["source_prescore_calib_summary"]
    transport_mode = calibrators.get("transport_mode", "additive_margin")
    alphas = calibrators.get("layer_effective_alpha") or calibrators["layer_alpha"]
    fp_weights = calibrators["layer_fp_weight"]
    gate_sharpness = calibrators["layer_gate_sharpness"]
    transport_ws = calibrators.get("layer_transport_w") or [None] * len(levels)
    transport_bs = calibrators.get("layer_transport_b") or [None] * len(levels)

    image_transform, mask_transform = official.build_transforms(img_size)
    target_meta = json.loads((Path(summary["target_root"]) / "meta.json").read_text())
    class_names = sorted(target_meta["test"].keys())
    rows = []

    for class_name in class_names:
        ds = official.GenericMetaDataset(
            root=summary["target_root"],
            image_transform=image_transform,
            mask_transform=mask_transform,
            split="test",
            class_name=class_name,
        )
        dl = DataLoader(
            ds,
            batch_size=int(args.batch_size),
            shuffle=False,
            num_workers=int(args.num_workers),
            pin_memory=torch.cuda.is_available(),
        )
        text_feature = target_text[class_name].to(device)
        target_axis = F.normalize(text_feature[:, 1] - text_feature[:, 0], dim=0)
        class_stats = [{"class_name": class_name, "layer": level} for level in levels]
        acc = [dict() for _ in levels]
        combined_acc: dict = {}

        for batch in dl:
            image = batch["image"].to(device)
            mask = batch["mask"].to(device) > 0.5
            if not bool(mask.any()):
                continue
            with torch.no_grad():
                seg_tokens, _ = model(image)
                combined_base_maps = []
                combined_rect_maps = []
                for li, tokens in enumerate(seg_tokens):
                    base_map = calculate_similarity_map(
                        tokens,
                        text_feature,
                        img_size,
                        test=True,
                        domain=DOMAINS[summary["target_dataset"]],
                    )[:, 0]
                    query_proj = tokens @ source_axis
                    q_def = official.logmeanexp_negative_sqdist_1d(
                        query_proj,
                        def_proj[li],
                        tau=float(summary["tau"]),
                    )
                    q_fp = official.logmeanexp_negative_sqdist_1d(
                        query_proj,
                        fp_proj[li],
                        tau=float(summary["tau"]),
                    )
                    if transport_mode == "parallel_tanh":
                        rect_tokens = official.prescore_parallel_transport_seg_tokens(
                            tokens=tokens,
                            q_def=q_def,
                            q_fp=q_fp,
                            target_axis=target_axis,
                            eta=float(alphas[li]),
                            transport_w=float(transport_ws[li]),
                            transport_b=float(transport_bs[li]),
                            fp_weight=float(fp_weights[li]),
                        )
                    else:
                        rect_tokens = official.prescore_rectify_seg_tokens(
                            tokens=tokens,
                            q_def=q_def,
                            q_fp=q_fp,
                            target_axis=target_axis,
                            alpha=float(alphas[li]),
                            fp_weight=float(fp_weights[li]),
                            gate_sharpness=float(gate_sharpness[li]),
                        )
                    rect_map = calculate_similarity_map(
                        rect_tokens,
                        text_feature,
                        img_size,
                        test=True,
                        domain=DOMAINS[summary["target_dataset"]],
                    )[:, 0]
                    combined_base_maps.append(base_map)
                    combined_rect_maps.append(rect_map)
                    map_mask = mask[:, 0]
                    bg_mask = ~map_mask
                    hard_rank_map = base_map
                    add_stat(acc[li], "base_defect", masked_topk_mean(base_map, map_mask, base_map, args.topk_frac))
                    add_stat(acc[li], "new_defect", masked_topk_mean(rect_map, map_mask, base_map, args.topk_frac))
                    add_stat(acc[li], "base_hardfp", masked_topk_mean(base_map, bg_mask, hard_rank_map, args.topk_frac))
                    add_stat(acc[li], "new_hardfp", masked_topk_mean(rect_map, bg_mask, hard_rank_map, args.topk_frac))
                    add_stat(acc[li], "new_hardfp_newrank", masked_topk_mean(rect_map, bg_mask, rect_map, args.topk_frac))

                    side = int(round(tokens.shape[1] ** 0.5))
                    patch_mask = official.downsample_mask_to_patch(mask.float(), side).to(device)
                    patch_bg = ~patch_mask
                    text_batch = text_feature[None].repeat(tokens.shape[0], 1, 1)
                    patch_base = official.spatial_zscore_tokens(
                        official.batch_patch_score_grid(tokens, text_batch)
                    )
                    raw_margin = q_def - float(fp_weights[li]) * q_fp
                    margin = official.spatial_tanh_zscore(raw_margin)
                    if transport_mode == "parallel_tanh":
                        step_strength = float(alphas[li]) * torch.tanh(
                            float(transport_ws[li]) * margin + float(transport_bs[li])
                        )
                    else:
                        mass = official.spatial_tanh_zscore(q_def + q_fp)
                        gate = torch.sigmoid(float(gate_sharpness[li]) * mass)
                        step_strength = float(alphas[li]) * gate * margin
                    q_fp_z = official.spatial_zscore_tokens(q_fp)
                    hard_rank_patch = patch_base + q_fp_z
                    add_stat(acc[li], "step_defect", masked_topk_mean(step_strength, patch_mask, patch_base, args.topk_frac))
                    add_stat(acc[li], "step_hardfp", masked_topk_mean(step_strength, patch_bg, hard_rank_patch, args.topk_frac))
                    add_stat(acc[li], "margin_defect", masked_topk_mean(margin, patch_mask, patch_base, args.topk_frac))
                    add_stat(acc[li], "margin_hardfp", masked_topk_mean(margin, patch_bg, hard_rank_patch, args.topk_frac))

                if combined_base_maps and combined_rect_maps:
                    base_sum = torch.stack(combined_base_maps, dim=1).sum(1)
                    rect_sum = torch.stack(combined_rect_maps, dim=1).sum(1)
                    map_mask = mask[:, 0]
                    bg_mask = ~map_mask
                    add_stat(
                        combined_acc,
                        "base_defect",
                        masked_topk_mean(base_sum, map_mask, base_sum, args.topk_frac),
                    )
                    add_stat(
                        combined_acc,
                        "new_defect",
                        masked_topk_mean(rect_sum, map_mask, base_sum, args.topk_frac),
                    )
                    add_stat(
                        combined_acc,
                        "base_hardfp",
                        masked_topk_mean(base_sum, bg_mask, base_sum, args.topk_frac),
                    )
                    add_stat(
                        combined_acc,
                        "new_hardfp",
                        masked_topk_mean(rect_sum, bg_mask, base_sum, args.topk_frac),
                    )
                    add_stat(
                        combined_acc,
                        "new_hardfp_newrank",
                        masked_topk_mean(rect_sum, bg_mask, rect_sum, args.topk_frac),
                    )

        for li, row in enumerate(class_stats):
            st = acc[li]
            base_def = mean_stat(st.get("base_defect", []))
            new_def = mean_stat(st.get("new_defect", []))
            base_fp = mean_stat(st.get("base_hardfp", []))
            new_fp = mean_stat(st.get("new_hardfp", []))
            row.update(
                {
                    "alpha": float(alphas[li]),
                    "base_gap": base_def - base_fp,
                    "new_gap": new_def - new_fp,
                    "delta_gap": (new_def - new_fp) - (base_def - base_fp),
                    "delta_defect": new_def - base_def,
                    "delta_hardfp": new_fp - base_fp,
                    "new_hardfp_newrank": mean_stat(st.get("new_hardfp_newrank", [])),
                    "new_gap_newrank": new_def - mean_stat(st.get("new_hardfp_newrank", [])),
                    "step_defect": mean_stat(st.get("step_defect", [])),
                    "step_hardfp": mean_stat(st.get("step_hardfp", [])),
                    "margin_defect": mean_stat(st.get("margin_defect", [])),
                    "margin_hardfp": mean_stat(st.get("margin_hardfp", [])),
                }
            )
            rows.append(row)
        st = combined_acc
        base_def = mean_stat(st.get("base_defect", []))
        new_def = mean_stat(st.get("new_defect", []))
        base_fp = mean_stat(st.get("base_hardfp", []))
        new_fp = mean_stat(st.get("new_hardfp", []))
        rows.append(
            {
                "class_name": class_name,
                "layer": "sum",
                "alpha": None,
                "base_gap": base_def - base_fp,
                "new_gap": new_def - new_fp,
                "delta_gap": (new_def - new_fp) - (base_def - base_fp),
                "delta_defect": new_def - base_def,
                "delta_hardfp": new_fp - base_fp,
                "new_hardfp_newrank": mean_stat(st.get("new_hardfp_newrank", [])),
                "new_gap_newrank": new_def - mean_stat(st.get("new_hardfp_newrank", [])),
                "step_defect": None,
                "step_hardfp": None,
                "margin_defect": None,
                "margin_hardfp": None,
            }
        )

    print(json.dumps(rows, indent=2))
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
