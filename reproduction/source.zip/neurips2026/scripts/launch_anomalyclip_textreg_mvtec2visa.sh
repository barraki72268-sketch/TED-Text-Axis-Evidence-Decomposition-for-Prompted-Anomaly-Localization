#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"
GPU_ID="${1:-1}"

MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT="/mnt/data/gijeong/MMAD_new/VisA"

SAVE_DIR="${ROOT}/neurips2026/results/anomalyclip_textreg_mvtec2visa/checkpoints"
TEST_DIR="${ROOT}/neurips2026/results/anomalyclip_textreg_mvtec2visa/test_visa_0shot"

mkdir -p "${SAVE_DIR}" "${TEST_DIR}"

cd "${ROOT}/neurips2026/AnomalyCLIP"

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" train.py \
  --dataset mvtec \
  --train_data_path "${MVTEC_ROOT}" \
  --save_path "${SAVE_DIR}" \
  --features_list 24 \
  --image_size 518 \
  --batch_size 8 \
  --print_freq 1 \
  --epoch 15 \
  --save_freq 1 \
  --depth 9 \
  --n_ctx 12 \
  --t_n_ctx 4 \
  --text_leakage_reg \
  --text_ortho_weight 0.01 \
  --text_anchor_weight 0.05

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" test.py \
  --dataset visa \
  --data_path "${VISA_ROOT}" \
  --save_path "${TEST_DIR}" \
  --checkpoint_path "${SAVE_DIR}/epoch_15.pth" \
  --features_list 24 \
  --image_size 518 \
  --depth 9 \
  --n_ctx 12 \
  --t_n_ctx 4
