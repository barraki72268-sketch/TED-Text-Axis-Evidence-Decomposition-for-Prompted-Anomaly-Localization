#!/usr/bin/env python3
from __future__ import annotations

import csv
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

CSV_PATH = OUT / "adapted_host_b_t_c_records_20260502.csv"
FAPROMPT_T_CSV = OUT / "faprompt_t_ted_prescore_separate_20260502.csv"

HOSTS = ("AA-CLIP", "FAPrompt", "AdaCLIP")
TARGETS = ("VisA", "MPDD", "BTAD")
METRICS = ("p_auc", "p_pro", "p_ap")
METRIC_LABELS = {
    "p_auc": r"$\Delta$P-AUC",
    "p_pro": r"$\Delta$PRO",
    "p_ap": r"$\Delta$AP",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="") as f:
        return list(csv.DictReader(f))


def fnum(value: str | None) -> float | None:
    if value in (None, "", "None"):
        return None
    out = float(value)
    if math.isnan(out):
        return None
    return out


def mean(values: list[float]) -> float | None:
    return sum(values) / len(values) if values else None


def faprompt_t_delta(records: list[dict[str, str]], target: str, metric: str) -> float | None:
    vals = []
    for row in records:
        if row["target"] != target:
            continue
        base = fnum(row.get(f"baseline_{metric}"))
        tted = fnum(row.get(f"t_ted_{metric}"))
        if base is not None and tted is not None:
            vals.append(tted - base)
    return mean(vals)


def build_matrix(records: list[dict[str, str]], faprompt_t_records: list[dict[str, str]], metric: str, method: str) -> np.ndarray:
    matrix = np.full((len(HOSTS), len(TARGETS)), np.nan)
    delta_key = "delta_t" if method == "t" else "delta_c"
    for i, host in enumerate(HOSTS):
        for j, target in enumerate(TARGETS):
            if method == "t" and host == "FAPrompt":
                value = faprompt_t_delta(faprompt_t_records, target, metric)
                if value is not None:
                    matrix[i, j] = value
                continue
            vals = [
                v
                for row in records
                if row["host"] == host and row["target"] == target and row["metric"] == metric
                for v in [fnum(row.get(delta_key))]
                if v is not None
            ]
            value = mean(vals)
            if value is not None:
                matrix[i, j] = value
    return matrix


def fmt(value: float) -> str:
    if not np.isfinite(value):
        return "--"
    if abs(value) < 0.05:
        return "0"
    return f"{value:+.1f}"


def draw_heatmap(ax: plt.Axes, matrix: np.ndarray, title: str) -> None:
    finite = matrix[np.isfinite(matrix)]
    vmax = max(1.0, float(np.nanpercentile(np.abs(finite), 92))) if finite.size else 1.0
    ax.imshow(matrix, cmap="BrBG", vmin=-vmax, vmax=vmax, aspect="auto")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, fmt(matrix[i, j]), ha="center", va="center", fontsize=8.5, color="#1d1d1b")
    ax.set_title(title, pad=4, fontsize=9)
    ax.set_xticks(np.arange(len(TARGETS)))
    ax.set_xticklabels(TARGETS, rotation=25, ha="right")
    ax.set_yticks(np.arange(len(HOSTS)))
    ax.set_yticklabels(HOSTS)
    ax.tick_params(length=0, labelsize=8)
    for spine in ax.spines.values():
        spine.set_visible(False)


def write_tex() -> None:
    tex = r"""\begin{figure*}[t]
\centering
\begin{subfigure}[t]{0.32\linewidth}
\centering
\includegraphics[width=\linewidth]{figure/host3_dataset3_ted_p_auc_20260503.pdf}
\caption{P-AUC gain.}
\end{subfigure}\hfill
\begin{subfigure}[t]{0.32\linewidth}
\centering
\includegraphics[width=\linewidth]{figure/host3_dataset3_ted_p_pro_20260503.pdf}
\caption{PRO gain.}
\end{subfigure}\hfill
\begin{subfigure}[t]{0.32\linewidth}
\centering
\includegraphics[width=\linewidth]{figure/host3_dataset3_ted_p_ap_20260503.pdf}
\caption{AP gain.}
\end{subfigure}
\caption{
\textbf{Compact cross-host summary under MVTec-source transfer.}
Each entry reports the average improvement of TED over the host baseline, averaged over available backbones and seeds for the corresponding host and target dataset.
The top and bottom rows in each panel correspond to train-free TED and source-calibrated TED, respectively.
}
\label{fig:host3_dataset3_ted}
\end{figure*}
"""
    (OUT / "host3_dataset3_ted_figure_20260503.tex").write_text(tex)


def write_values(matrices: dict[str, np.ndarray]) -> None:
    lines = [
        "# 3 Host x 3 Dataset TED Figure Values",
        "",
        f"Source CSV: `{CSV_PATH.relative_to(ROOT)}`",
        "",
        "Each value is TED minus baseline, averaged over available backbones/seeds.",
        "",
    ]
    for method_name, method_mats in matrices.items():
        lines += [f"# {method_name}", ""]
        for metric, matrix in method_mats.items():
            lines += [f"## {METRIC_LABELS[metric]}", "", "| Host | " + " | ".join(TARGETS) + " |", "|---|" + "|".join(["---:"] * len(TARGETS)) + "|"]
            for i, host in enumerate(HOSTS):
                lines.append("| " + host + " | " + " | ".join(fmt(matrix[i, j]) for j in range(len(TARGETS))) + " |")
            lines.append("")
    (OUT / "host3_dataset3_ted_values_20260503.md").write_text("\n".join(lines))


def draw_method_metric_panel(ax: plt.Axes, t_matrix: np.ndarray, c_matrix: np.ndarray, title: str) -> None:
    # Stack hosts for T-TED and C-TED so each metric remains one compact subfigure.
    matrix = np.vstack([t_matrix, c_matrix])
    finite = matrix[np.isfinite(matrix)]
    vmax = max(1.0, float(np.nanpercentile(np.abs(finite), 92))) if finite.size else 1.0
    ax.imshow(matrix, cmap="BrBG", vmin=-vmax, vmax=vmax, aspect="auto")
    ylabels = [f"T {h}" for h in HOSTS] + [f"C {h}" for h in HOSTS]
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, fmt(matrix[i, j]), ha="center", va="center", fontsize=7.2, color="#1d1d1b")
    ax.axhline(len(HOSTS) - 0.5, color="#2f2f2f", linewidth=0.65)
    ax.set_title(title, pad=4, fontsize=9)
    ax.set_xticks(np.arange(len(TARGETS)))
    ax.set_xticklabels(TARGETS, rotation=25, ha="right")
    ax.set_yticks(np.arange(len(ylabels)))
    ax.set_yticklabels(ylabels)
    ax.tick_params(length=0, labelsize=7.2)
    for spine in ax.spines.values():
        spine.set_visible(False)


def main() -> int:
    records = read_csv(CSV_PATH)
    faprompt_t_records = read_csv(FAPROMPT_T_CSV)
    matrices = {
        "T-TED": {metric: build_matrix(records, faprompt_t_records, metric, "t") for metric in METRICS},
        "C-TED": {metric: build_matrix(records, faprompt_t_records, metric, "c") for metric in METRICS},
    }

    FIG.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    for metric in METRICS:
        fig, ax = plt.subplots(figsize=(2.35, 2.35))
        draw_method_metric_panel(ax, matrices["T-TED"][metric], matrices["C-TED"][metric], METRIC_LABELS[metric])
        fig.savefig(FIG / f"host3_dataset3_ted_{metric}_20260503.pdf", bbox_inches="tight")
        fig.savefig(FIG / f"host3_dataset3_ted_{metric}_20260503.png", dpi=300, bbox_inches="tight")
        plt.close(fig)

    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.45), constrained_layout=True)
    for ax, metric in zip(axs, METRICS):
        draw_method_metric_panel(ax, matrices["T-TED"][metric], matrices["C-TED"][metric], METRIC_LABELS[metric])
    fig.savefig(FIG / "host3_dataset3_ted_row_20260503.pdf", bbox_inches="tight")
    fig.savefig(FIG / "host3_dataset3_ted_row_20260503.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    write_tex()
    write_values(matrices)
    print(
        {
            "row": str(FIG / "host3_dataset3_ted_row_20260503.pdf"),
            "tex": str(OUT / "host3_dataset3_ted_figure_20260503.tex"),
            "values": str(OUT / "host3_dataset3_ted_values_20260503.md"),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
