from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.train_clip_aqm_oracle import (
    AnomalyQueryModuleV1,
    compute_consensus_loss,
    compute_zero_signal_loss,
    normalize_feat,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    forward_up_to_layer,
    patchify_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.scripts.train_clip_ksm_v3_mvtec_to_visa import (
    PromptCondition,
    build_prompt_condition,
    collect_mvtec_train_records,
    collect_realiad_train_records,
    collect_visa_eval_records,
    materialize_record_batch,
)
from utils.metrics import cal_pro_metric


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("AQM v4.0-min MVTec -> VisA prompt-centric transfer pilot.")
    parser.add_argument("--source_dataset", type=str, default="mvtec", choices=["mvtec", "realiad"])
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--realiad_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument(
        "--target_classes",
        nargs="+",
        default=[
            "chewinggum",
            "pipe_fryum",
            "pcb4",
            "macaroni2",
            "cashew",
            "pcb1",
            "macaroni1",
            "fryum",
            "pcb2",
            "capsules",
            "candle",
            "pcb3",
        ],
    )
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--layer", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_simplex_tokens", type=int, default=32)
    parser.add_argument("--num_subspace_tokens", type=int, default=32)
    parser.add_argument("--gamma_init", type=float, default=1e-3)
    parser.add_argument("--train_normal_images", type=int, default=8)
    parser.add_argument("--train_anomaly_images", type=int, default=8)
    parser.add_argument("--train_batch_size", type=int, default=64)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--lambda_proj", type=float, default=0.3)
    parser.add_argument("--lambda_router", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--router_tau", type=float, default=5.0)
    parser.add_argument("--router_lse_beta", type=float, default=10.0)
    parser.add_argument("--fusion_eta", type=float, default=1.0)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--pixel_blur_sigma", type=float, default=4.0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_aqm_mvtec2visa_v40")
    return parser.parse_args()


def compute_subspace_projection_loss(
    r_u: torch.Tensor,
    u_basis: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    pos = mask > 0
    if int(pos.sum().item()) == 0:
        return torch.zeros([], device=r_u.device)
    proj_norm = torch.norm(torch.matmul(r_u[pos], u_basis.T), dim=-1)
    return 1.0 - proj_norm.mean()


def compute_router_update_loss(
    r_s: torch.Tensor,
    r_u: torch.Tensor,
    prompt_features: torch.Tensor,
    mask: torch.Tensor,
    alpha: torch.Tensor,
    lse_beta: float,
    tau: float,
) -> torch.Tensor:
    alpha_flat = alpha.view(alpha.shape[0], -1).mean(dim=1)
    losses = []
    beta = float(lse_beta)
    tau_f = float(tau)
    for bidx in range(r_s.shape[0]):
        pos = mask[bidx] > 0
        if int(pos.sum().item()) == 0:
            continue
        score_s = torch.matmul(r_s[bidx][pos], prompt_features.T).max(dim=1).values.detach()
        score_u = torch.matmul(r_u[bidx][pos], prompt_features.T).max(dim=1).values.detach()
        u_s = (torch.logsumexp(beta * score_s, dim=0) - math.log(float(score_s.numel()))) / beta
        u_u = (torch.logsumexp(beta * score_u, dim=0) - math.log(float(score_u.numel()))) / beta
        target = torch.sigmoid(tau_f * (u_s - u_u))
        pred = alpha_flat[bidx].clamp(1e-6, 1.0 - 1e-6)
        losses.append(F.binary_cross_entropy(pred, target))
    if not losses:
        return torch.zeros([], device=r_s.device)
    return torch.stack(losses).mean()


def compute_aqm_v40_loss(
    aux: dict[str, torch.Tensor | float],
    cond: PromptCondition,
    mask: torch.Tensor,
    topk_anom_ratio: float,
    hard_neg_ratio: float,
    lambda_zero: float,
    lambda_proj: float,
    lambda_router: float,
    router_lse_beta: float,
    router_tau: float,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    simplex_feat = aux["simplex_feat"]
    subspace_feat = aux["subspace_feat"]
    alpha = aux["alpha_tensor"]

    r_s = normalize_feat(simplex_feat)
    r_u = normalize_feat(subspace_feat)

    l_s = compute_consensus_loss(r_s, cond.prompt_features, mask, topk_ratio=topk_anom_ratio)
    l_u_prompt = compute_consensus_loss(r_u, cond.prompt_features, mask, topk_ratio=None)
    l_u_proj = compute_subspace_projection_loss(r_u, cond.U_basis, mask)
    l_zero_s = compute_zero_signal_loss(simplex_feat, mask, hard_neg_ratio)
    l_zero_u = compute_zero_signal_loss(subspace_feat, mask, hard_neg_ratio)
    l_router = compute_router_update_loss(
        r_s,
        r_u,
        cond.prompt_features,
        mask,
        alpha,
        lse_beta=router_lse_beta,
        tau=router_tau,
    )

    total = (
        l_s
        + l_u_prompt
        + float(lambda_proj) * l_u_proj
        + float(lambda_zero) * (l_zero_s + l_zero_u)
        + float(lambda_router) * l_router
    )
    return total, {
        "l_s": l_s,
        "l_u_prompt": l_u_prompt,
        "l_u_proj": l_u_proj,
        "l_router": l_router,
        "l_zero_s": l_zero_s,
        "l_zero_u": l_zero_u,
    }

def train_one_epoch(
    backbone,
    aqm: AnomalyQueryModuleV1,
    prompt_cache: dict[str, PromptCondition],
    train_records,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    aqm.train()
    loss_vals = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []
    l_s_vals = []
    l_u_prompt_vals = []
    l_u_proj_vals = []
    l_router_vals = []
    l_zero_s_vals = []
    l_zero_u_vals = []

    records_by_class: dict[str, list] = {}
    for rec in train_records:
        records_by_class.setdefault(rec.class_name, []).append(rec)
    rng = np.random.default_rng(epoch_idx)
    class_order = list(records_by_class.keys())
    rng.shuffle(class_order)

    for class_name in class_order:
        cond = prompt_cache[class_name]
        class_records = records_by_class[class_name]
        order = rng.permutation(len(class_records))
        for start in range(0, len(order), args.train_batch_size):
            batch_idx = order[start : start + args.train_batch_size]
            batch_records = [class_records[int(i)] for i in batch_idx]
            image_t_cpu, patch_mask = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            mask = torch.from_numpy(patch_mask.astype(np.int64)).to(device)
            seq = forward_up_to_layer(backbone, image_t, args.layer)
            _, patches = patchify_sequence(seq)
            _, aux = aqm(patches, cond.p_norm, return_aux=True)
            loss, parts = compute_aqm_v40_loss(
                aux,
                cond,
                mask,
                topk_anom_ratio=args.topk_anom_ratio,
                hard_neg_ratio=args.hard_neg_ratio,
                lambda_zero=args.lambda_zero,
                lambda_proj=args.lambda_proj,
                lambda_router=args.lambda_router,
                router_lse_beta=args.router_lse_beta,
                router_tau=args.router_tau,
            )

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()

            loss_vals.append(float(loss.item()))
            alpha_vals.append(aux["alpha_mean"])
            gamma_s_vals.append(aux["gamma_simplex_abs"])
            gamma_u_vals.append(aux["gamma_subspace_abs"])
            l_s_vals.append(float(parts["l_s"].item()))
            l_u_prompt_vals.append(float(parts["l_u_prompt"].item()))
            l_u_proj_vals.append(float(parts["l_u_proj"].item()))
            l_router_vals.append(float(parts["l_router"].item()))
            l_zero_s_vals.append(float(parts["l_zero_s"].item()))
            l_zero_u_vals.append(float(parts["l_zero_u"].item()))

    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "train_loss_s": float(np.mean(l_s_vals)) if l_s_vals else float("nan"),
        "train_loss_u_prompt": float(np.mean(l_u_prompt_vals)) if l_u_prompt_vals else float("nan"),
        "train_loss_u_proj": float(np.mean(l_u_proj_vals)) if l_u_proj_vals else float("nan"),
        "train_loss_router": float(np.mean(l_router_vals)) if l_router_vals else float("nan"),
        "train_loss_zero_s": float(np.mean(l_zero_s_vals)) if l_zero_s_vals else float("nan"),
        "train_loss_zero_u": float(np.mean(l_zero_u_vals)) if l_zero_u_vals else float("nan"),
        "alpha_mean": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
    }


def load_resized_mask(mask_path: str | None, target_size: int) -> np.ndarray:
    if mask_path is None:
        return np.zeros((target_size, target_size), dtype=np.uint8)
    mask_np = np.asarray(Image.open(mask_path))
    if mask_np.ndim == 3:
        mask_np = mask_np[..., 0]
    mask_np = (mask_np > 0).astype(np.uint8)
    if mask_np.shape != (target_size, target_size):
        mask_np = np.asarray(
            Image.fromarray(mask_np * 255).resize((target_size, target_size), resample=Image.NEAREST),
            dtype=np.uint8,
        )
        mask_np = (mask_np > 0).astype(np.uint8)
    return mask_np


def patch_scores_to_pixel_map(scores: np.ndarray, target_size: int, blur_sigma: float) -> np.ndarray:
    side = int(round(math.sqrt(scores.shape[0])))
    if side * side != scores.shape[0]:
        raise ValueError(f"Cannot reshape patch scores of length {scores.shape[0]} into square grid.")
    score_t = torch.from_numpy(scores.reshape(1, 1, side, side)).float()
    pixel_map = F.interpolate(score_t, size=(target_size, target_size), mode="bilinear", align_corners=False)[
        0, 0
    ].cpu().numpy()
    if blur_sigma > 0:
        pixel_map = ndimage.gaussian_filter(pixel_map, sigma=float(blur_sigma))
    return pixel_map.astype(np.float32)


def safe_pixel_auc(score_maps: list[np.ndarray], gt_masks: list[np.ndarray]) -> float:
    if not score_maps or not gt_masks:
        return float("nan")
    score_arr = np.stack(score_maps, axis=0)
    gt_arr = np.stack(gt_masks, axis=0).astype(np.uint8)
    flat_gt = gt_arr.ravel()
    if flat_gt.min() == flat_gt.max():
        return float("nan")
    try:
        return float(roc_auc_score(flat_gt, score_arr.ravel()))
    except Exception:
        return float("nan")


def safe_pro(score_maps: list[np.ndarray], gt_masks: list[np.ndarray]) -> float:
    if not score_maps or not gt_masks:
        return float("nan")
    gt_arr = np.stack(gt_masks, axis=0).astype(np.uint8)
    if gt_arr.max() <= 0:
        return float("nan")
    score_arr = np.stack(score_maps, axis=0).astype(np.float32)
    try:
        return float(cal_pro_metric(gt_arr, score_arr, fpr_thresh=0.3))
    except Exception:
        return float("nan")


def evaluate_target_class(
    backbone,
    aqm: AnomalyQueryModuleV1,
    cond: PromptCondition,
    eval_records,
    layer_idx: int,
    img_size: int,
    topk_ratio: float,
    eval_batch_size: int,
    fusion_eta: float,
    pixel_blur_sigma: float,
    device: str,
) -> dict[str, float]:
    aqm.eval()
    patch_labels = []
    base_patch_scores = []
    mix_patch_scores = []
    simplex_patch_scores = []
    subspace_patch_scores = []
    image_labels = []
    base_image_scores = []
    mix_image_scores = []
    simplex_image_scores = []
    subspace_image_scores = []
    gt_masks = []
    base_pixel_maps = []
    mix_pixel_maps = []
    simplex_pixel_maps = []
    subspace_pixel_maps = []
    alpha_vals = []
    gamma_s_vals = []
    gamma_u_vals = []

    with torch.no_grad():
        for start in range(0, len(eval_records), eval_batch_size):
            batch_records = eval_records[start : start + eval_batch_size]
            image_t_cpu, patch_masks = materialize_record_batch(backbone, batch_records)
            image_t = image_t_cpu.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            _, patches = patchify_sequence(seq)
            _, aux = aqm(patches, cond.p_norm, return_aux=True)

            base_scores = score_promptmax(patches, cond.p_norm, cond.prompt_features)
            simplex_scores = score_promptmax(aux["simplex_feat"], cond.p_norm, cond.prompt_features)
            subspace_scores = score_promptmax(aux["subspace_feat"], cond.p_norm, cond.prompt_features)
            alpha_np = aux["alpha_tensor"].view(-1).detach().cpu().numpy()

            for rec, patch_mask, bs, ss, us, a in zip(
                batch_records,
                patch_masks,
                base_scores,
                simplex_scores,
                subspace_scores,
                alpha_np,
            ):
                mixed_anom = float(a) * ss + (1.0 - float(a)) * us
                fused_mix = bs + float(fusion_eta) * mixed_anom
                fused_s = bs + float(fusion_eta) * ss
                fused_u = bs + float(fusion_eta) * us

                patch_labels.extend(patch_mask.astype(np.int64).tolist())
                base_patch_scores.extend(bs.tolist())
                mix_patch_scores.extend(fused_mix.tolist())
                simplex_patch_scores.extend(fused_s.tolist())
                subspace_patch_scores.extend(fused_u.tolist())
                image_labels.append(rec.label)
                base_image_scores.append(topk_mean(np.asarray(bs), topk_ratio))
                mix_image_scores.append(topk_mean(np.asarray(fused_mix), topk_ratio))
                simplex_image_scores.append(topk_mean(np.asarray(fused_s), topk_ratio))
                subspace_image_scores.append(topk_mean(np.asarray(fused_u), topk_ratio))
                gt_mask = load_resized_mask(rec.mask_path if rec.label == 1 else None, img_size)
                gt_masks.append(gt_mask)
                base_pixel_maps.append(patch_scores_to_pixel_map(np.asarray(bs), img_size, pixel_blur_sigma))
                mix_pixel_maps.append(
                    patch_scores_to_pixel_map(np.asarray(fused_mix), img_size, pixel_blur_sigma)
                )
                simplex_pixel_maps.append(
                    patch_scores_to_pixel_map(np.asarray(fused_s), img_size, pixel_blur_sigma)
                )
                subspace_pixel_maps.append(
                    patch_scores_to_pixel_map(np.asarray(fused_u), img_size, pixel_blur_sigma)
                )

            alpha_vals.extend(aux["alpha_tensor"].view(-1).detach().cpu().tolist())
            gamma_s_vals.extend([aux["gamma_simplex_abs"]] * len(batch_records))
            gamma_u_vals.extend([aux["gamma_subspace_abs"]] * len(batch_records))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    mix_patch_auc = safe_auc(patch_labels, mix_patch_scores)
    simplex_patch_auc = safe_auc(patch_labels, simplex_patch_scores)
    subspace_patch_auc = safe_auc(patch_labels, subspace_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    mix_image_auc = safe_auc(image_labels, mix_image_scores)
    simplex_image_auc = safe_auc(image_labels, simplex_image_scores)
    subspace_image_auc = safe_auc(image_labels, subspace_image_scores)
    base_pixel_auc = safe_pixel_auc(base_pixel_maps, gt_masks)
    mix_pixel_auc = safe_pixel_auc(mix_pixel_maps, gt_masks)
    simplex_pixel_auc = safe_pixel_auc(simplex_pixel_maps, gt_masks)
    subspace_pixel_auc = safe_pixel_auc(subspace_pixel_maps, gt_masks)
    base_p_pro = safe_pro(base_pixel_maps, gt_masks)
    mix_p_pro = safe_pro(mix_pixel_maps, gt_masks)
    simplex_p_pro = safe_pro(simplex_pixel_maps, gt_masks)
    subspace_p_pro = safe_pro(subspace_pixel_maps, gt_masks)
    return {
        "base_prompt_patch_auc": base_patch_auc,
        "aqm_prompt_patch_auc": mix_patch_auc,
        "prompt_patch_auc_delta": mix_patch_auc - base_patch_auc,
        "simplex_prompt_patch_auc_delta": simplex_patch_auc - base_patch_auc,
        "subspace_prompt_patch_auc_delta": subspace_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "aqm_prompt_image_auc": mix_image_auc,
        "prompt_image_auc_delta": mix_image_auc - base_image_auc,
        "simplex_prompt_image_auc_delta": simplex_image_auc - base_image_auc,
        "subspace_prompt_image_auc_delta": subspace_image_auc - base_image_auc,
        "base_prompt_pixel_auc": base_pixel_auc,
        "aqm_prompt_pixel_auc": mix_pixel_auc,
        "prompt_pixel_auc_delta": mix_pixel_auc - base_pixel_auc,
        "simplex_prompt_pixel_auc_delta": simplex_pixel_auc - base_pixel_auc,
        "subspace_prompt_pixel_auc_delta": subspace_pixel_auc - base_pixel_auc,
        "base_prompt_p_pro": base_p_pro,
        "aqm_prompt_p_pro": mix_p_pro,
        "prompt_p_pro_delta": mix_p_pro - base_p_pro,
        "simplex_prompt_p_pro_delta": simplex_p_pro - base_p_pro,
        "subspace_prompt_p_pro_delta": subspace_p_pro - base_p_pro,
        "alpha_mean_eval": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean_eval": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean_eval": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for p in backbone.parameters():
        p.requires_grad_(False)

    if args.source_dataset == "mvtec":
        train_records = collect_mvtec_train_records(backbone, args)
        source_class_names = list(args.source_classes)
    else:
        train_records = collect_realiad_train_records(backbone, args)
        source_class_names = sorted({rec.class_name for rec in train_records})
    source_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in source_class_names
    }
    target_prompt_cache = {
        class_name: build_prompt_condition(backbone, class_name, args.text_var_threshold, device)
        for class_name in args.target_classes
    }

    aqm = AnomalyQueryModuleV1(
        dim=int(next(iter(source_prompt_cache.values())).prompt_features.shape[1]),
        num_simplex_tokens=args.num_simplex_tokens,
        num_subspace_tokens=args.num_subspace_tokens,
        gamma_init=args.gamma_init,
    ).to(device)
    token_params = [aqm.simplex_tokens, aqm.subspace_tokens]
    other_params = [p for n, p in aqm.named_parameters() if n not in {"simplex_tokens", "subspace_tokens"}]
    optimizer = torch.optim.AdamW(
        [
            {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
            {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
        ]
    )

    print(
        f"[setup] source_dataset={args.source_dataset} source_classes={len(source_class_names)} "
        f"source_records={len(train_records)} target_classes={len(args.target_classes)} "
        f"layer=L{args.layer}"
    )

    history = []
    for epoch in range(1, args.epochs + 1):
        stats = train_one_epoch(
            backbone,
            aqm,
            source_prompt_cache,
            train_records,
            args,
            optimizer,
            device,
            epoch,
        )
        history.append({"epoch": epoch, **stats})
        print(
            f"[epoch {epoch}/{args.epochs}] loss={stats['train_loss']:.6f} "
            f"alpha={stats['alpha_mean']:.6f} "
            f"gamma_s={stats['gamma_simplex_abs_mean']:.6f} "
            f"gamma_u={stats['gamma_subspace_abs_mean']:.6f}"
        )

    rows = []
    for class_name in args.target_classes:
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(
            backbone,
            aqm,
            target_prompt_cache[class_name],
            eval_records,
            args.layer,
            args.img_size,
            args.topk_ratio,
            args.eval_batch_size,
            args.fusion_eta,
            args.pixel_blur_sigma,
            device,
        )
        rows.append(
            {
                "class_name": class_name,
                "layer": args.layer,
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "img_size": args.img_size,
                "epochs": args.epochs,
                "gamma_init": args.gamma_init,
                "num_simplex_tokens": args.num_simplex_tokens,
                "num_subspace_tokens": args.num_subspace_tokens,
                "lambda_zero": args.lambda_zero,
                "lambda_proj": args.lambda_proj,
                "lambda_router": args.lambda_router,
                "router_tau": args.router_tau,
                "router_lse_beta": args.router_lse_beta,
                "fusion_eta": args.fusion_eta,
                "source_dataset": args.source_dataset,
                "source_classes": len(source_class_names),
                "source_train_records": len(train_records),
                "text_rank": target_prompt_cache[class_name].text_rank,
                **history[-1],
                **eval_stats,
            }
        )

    stem = f"{args.output_tag}_{args.backbone}_L{args.layer}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump(
            {
                "args": vars(args),
                "history": history,
                "rows": rows,
                "source_classes": source_class_names,
                "target_classes": args.target_classes,
            },
            f,
            indent=2,
        )
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
