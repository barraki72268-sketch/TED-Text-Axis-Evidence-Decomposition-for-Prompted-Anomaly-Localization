from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from matplotlib.ticker import FormatStrFormatter, MaxNLocator
from sklearn.metrics import roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    build_dataset,
    decision_axis,
    decompose_with_axis,
    get_or_collect_source_patch_banks,
    logmeanexp_negative_sqdist,
    logmeanexp_negative_sqdist_1d,
    project_bank,
)


def patch_text_score_map(patch_feature: torch.Tensor, text_pair: torch.Tensor, image_size: int) -> torch.Tensor:
    patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
    similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], image_size)
    return ((similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0).squeeze(0)


def sample_array(arr: np.ndarray, max_points: int, seed: int) -> np.ndarray:
    if arr.size <= max_points:
        return arr
    rng = np.random.default_rng(seed)
    idx = rng.choice(arr.size, size=max_points, replace=False)
    return arr[idx]


def safe_auc(pos: np.ndarray, neg: np.ndarray, max_points: int = 100000) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    pos = sample_array(pos, max_points=max_points, seed=0)
    neg = sample_array(neg, max_points=max_points, seed=1)
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def outside_top_fraction_mask(arr: np.ndarray, outside_mask: np.ndarray, frac: float) -> np.ndarray:
    vals = arr[outside_mask]
    if vals.size == 0:
        return np.zeros_like(arr, dtype=bool)
    k = max(1, int(math.ceil(vals.size * frac)))
    thresh_idx = np.argpartition(vals, -k)[-k:]
    full_idx = np.flatnonzero(outside_mask)[thresh_idx]
    mask = np.zeros(arr.size, dtype=bool)
    mask[full_idx] = True
    return mask.reshape(arr.shape)


def collect_groups(
    model,
    text_pair: torch.Tensor,
    axis: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    dataset,
    target_dataset: str,
    heldout_class: str | None,
    target_class: str | None,
    features_list: list[int],
    image_size: int,
    tau: float,
    hard_frac: float,
    max_normal_eval_images: int | None,
    max_anomaly_eval_images: int | None,
):
    projected_banks = {}
    for layer_idx in range(len(features_list)):
        fp_bank = fp_banks[layer_idx].to(axis.device)
        def_bank = def_banks[layer_idx].to(axis.device)
        fp_coeff, fp_perp = project_bank(fp_bank, axis)
        def_coeff, def_perp = project_bank(def_bank, axis)
        projected_banks[layer_idx] = {
            "fp_parallel_coeff": fp_coeff,
            "fp_perp": fp_perp,
            "def_parallel_coeff": def_coeff,
            "def_perp": def_perp,
        }

    groups = {
        "coeff_inside": [],
        "coeff_hard_fp": [],
        "coeff_outside": [],
        "perp_inside": [],
        "perp_hard_fp": [],
        "perp_outside": [],
        "parallel_inside": [],
        "parallel_hard_fp": [],
        "parallel_outside": [],
    }

    num_normal_done = 0
    num_anomaly_done = 0

    with torch.no_grad():
        for idx in range(len(dataset)):
            item = dataset[idx]
            if target_dataset == "mvtec" and heldout_class is not None and item["cls_name"] != heldout_class:
                continue
            if target_class is not None and item["cls_name"] != target_class:
                continue
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0 and max_normal_eval_images is not None and num_normal_done >= max_normal_eval_images:
                continue
            if anomaly_flag == 1 and max_anomaly_eval_images is not None and num_anomaly_done >= max_anomaly_eval_images:
                continue

            image = item["img"].unsqueeze(0).to(next(model.parameters()).device)
            gt_mask = item["img_mask"].unsqueeze(0).clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask_np = gt_mask[0, 0].numpy().astype(bool)
            if not gt_mask_np.any():
                if anomaly_flag == 0:
                    num_normal_done += 1
                continue
            if anomaly_flag == 0:
                num_normal_done += 1
            else:
                num_anomaly_done += 1

            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)

            baseline_maps = []
            coeff_maps = []
            perp_maps = []
            parallel_maps = []
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                patch_coeff = patch @ axis
                _, patch_perp = decompose_with_axis(patch, axis)
                banks = projected_banks[layer_idx]

                q_fp_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["fp_parallel_coeff"], tau=tau)
                q_def_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["def_parallel_coeff"], tau=tau)
                q_fp_perp = logmeanexp_negative_sqdist(patch_perp, banks["fp_perp"], tau=tau)
                q_def_perp = logmeanexp_negative_sqdist(patch_perp, banks["def_perp"], tau=tau)

                h = int(round(patch.shape[0] ** 0.5))
                coeff_maps.append(patch_coeff.reshape(h, h).detach().cpu().numpy())
                perp_maps.append((q_def_perp - q_fp_perp).reshape(h, h).detach().cpu().numpy())
                parallel_maps.append((q_def_parallel - q_fp_parallel).reshape(h, h).detach().cpu().numpy())
                baseline_maps.append(patch_text_score_map(patch_feature, text_pair, image_size).detach().cpu().numpy())

            target_h, target_w = gt_mask_np.shape

            def resize_map(arr: np.ndarray) -> np.ndarray:
                return (
                    F.interpolate(
                        torch.from_numpy(arr).unsqueeze(0).unsqueeze(0).float(),
                        size=(target_h, target_w),
                        mode="bilinear",
                        align_corners=False,
                    )[0, 0]
                    .cpu()
                    .numpy()
                )

            coeff_map = resize_map(np.mean(np.stack(coeff_maps, axis=0), axis=0))
            perp_map = resize_map(np.mean(np.stack(perp_maps, axis=0), axis=0))
            parallel_map = resize_map(np.mean(np.stack(parallel_maps, axis=0), axis=0))
            baseline_map = resize_map(np.mean(np.stack(baseline_maps, axis=0), axis=0))

            outside_mask = ~gt_mask_np
            hard_fp_mask = outside_top_fraction_mask(baseline_map, outside_mask, hard_frac)
            other_outside_mask = outside_mask & (~hard_fp_mask)

            groups["coeff_inside"].append(coeff_map[gt_mask_np].astype(np.float32, copy=False))
            groups["coeff_hard_fp"].append(coeff_map[hard_fp_mask].astype(np.float32, copy=False))
            groups["coeff_outside"].append(coeff_map[other_outside_mask].astype(np.float32, copy=False))
            groups["perp_inside"].append(perp_map[gt_mask_np].astype(np.float32, copy=False))
            groups["perp_hard_fp"].append(perp_map[hard_fp_mask].astype(np.float32, copy=False))
            groups["perp_outside"].append(perp_map[other_outside_mask].astype(np.float32, copy=False))
            groups["parallel_inside"].append(parallel_map[gt_mask_np].astype(np.float32, copy=False))
            groups["parallel_hard_fp"].append(parallel_map[hard_fp_mask].astype(np.float32, copy=False))
            groups["parallel_outside"].append(parallel_map[other_outside_mask].astype(np.float32, copy=False))

            if (num_normal_done + num_anomaly_done) % 8 == 0:
                print(
                    json.dumps(
                        {
                            "stage": "dist_progress",
                            "normal_done": num_normal_done,
                            "anomaly_done": num_anomaly_done,
                            "current_class": item["cls_name"],
                        }
                    ),
                    flush=True,
                )

    out = {}
    for key, chunks in groups.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        out[key] = vals
    return out


def plot_groups(groups: dict[str, np.ndarray], save_dir: Path, stem: str, title_suffix: str):
    plt.rcParams.update(
        {
            "font.size": 18,
            "axes.titlesize": 21,
            "axes.labelsize": 19,
            "xtick.labelsize": 16,
            "ytick.labelsize": 16,
            "legend.fontsize": 15,
            "font.weight": "bold",
            "axes.titleweight": "bold",
            "axes.labelweight": "bold",
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )

    fig, axes = plt.subplots(1, 3, figsize=(19.2, 5.6), constrained_layout=True)

    panel_defs = [
        ("Raw On-Axis Coefficient", "coeff_inside", "coeff_hard_fp", "coeff_outside", "On-axis coefficient"),
        ("Orthogonal Residual Score", "perp_inside", "perp_hard_fp", "perp_outside", "Residual score"),
        ("Decomposition Margin $r_{\\parallel}$", "parallel_inside", "parallel_hard_fp", "parallel_outside", "Margin score"),
    ]
    styles = [
        ("Inside", "#d55e00", "-"),
        ("Hard-FP", "#0072b2", "--"),
        ("Outside", "#009e73", ":"),
    ]

    panel_summary = {}
    for ax, (title, k_in, k_fp, k_out, xlabel) in zip(axes, panel_defs):
        arrs = [groups[k_in], groups[k_fp], groups[k_out]]
        non_empty = [a for a in arrs if a.size > 0]
        lo = float(min(a.min() for a in non_empty))
        hi = float(max(a.max() for a in non_empty))
        if np.isclose(lo, hi):
            hi = lo + 1e-6
        bins = np.linspace(lo, hi, 140)
        for (label, color, ls), vals in zip(styles, arrs):
            if vals.size == 0:
                continue
            vals = sample_array(vals, 120000, seed=hash((title, label)) % 10000)
            _, _, patches = ax.hist(vals, bins=bins, density=True, histtype="step", linewidth=3.0, color=color, label=label)
            for p in patches:
                p.set_linestyle(ls)
        auc_if = safe_auc(groups[k_in], groups[k_fp])
        auc_io = safe_auc(groups[k_in], groups[k_out])
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Density")
        value_range = hi - lo
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
        if value_range < 0.005:
            ax.xaxis.set_major_formatter(FormatStrFormatter("%.4f"))
        elif value_range < 0.05:
            ax.xaxis.set_major_formatter(FormatStrFormatter("%.3f"))
        else:
            ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))
        ax.tick_params(axis="x", labelsize=14)
        ax.legend(frameon=False, loc="upper left")
        ax.text(
            0.98,
            0.96,
            f"AUC(in/fp)={auc_if:.3f}\nAUC(in/out)={auc_io:.3f}",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=13,
            bbox={"boxstyle": "round,pad=0.3", "facecolor": "white", "edgecolor": "black", "alpha": 0.9},
        )
        panel_summary[title] = {
            "auc_inside_vs_hardfp": auc_if,
            "auc_inside_vs_outside": auc_io,
            "num_inside": int(groups[k_in].size),
            "num_hardfp": int(groups[k_fp].size),
            "num_outside": int(groups[k_out].size),
        }

    if title_suffix.strip():
        fig.suptitle(title_suffix, y=1.02)
    save_dir.mkdir(parents=True, exist_ok=True)
    png_path = save_dir / f"{stem}.png"
    pdf_path = save_dir / f"{stem}.pdf"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    return panel_summary, png_path, pdf_path


def main():
    parser = argparse.ArgumentParser("Generate raw axis entanglement figure for AnomalyCLIP")
    parser.add_argument("--source_root", type=str, required=True)
    parser.add_argument("--source_dataset", type=str, required=True)
    parser.add_argument("--target_root", type=str, required=True)
    parser.add_argument("--target_dataset", type=str, required=True)
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--save_dir", type=str, required=True)
    parser.add_argument("--title", type=str, default="Representative Entanglement on the Text-Guided Axis")
    parser.add_argument("--heldout_class", type=str, default=None)
    parser.add_argument("--target_class", type=str, default=None)
    parser.add_argument("--source_exclude_class", type=str, default=None)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--max_normal_eval_images", type=int, default=None)
    parser.add_argument("--max_anomaly_eval_images", type=int, default=None)
    args = parser.parse_args()

    def normalize_optional(value: str | None) -> str | None:
        if value is None:
            return None
        return None if value.strip().lower() in {"", "none", "null", "all"} else value

    args.heldout_class = normalize_optional(args.heldout_class)
    args.target_class = normalize_optional(args.target_class)
    args.source_exclude_class = normalize_optional(args.source_exclude_class)

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    axis = decision_axis(learned_pair).to(args.device)
    source_exclude_class = args.source_exclude_class if args.source_exclude_class else args.heldout_class

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=source_exclude_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.bank_cache_path,
        refresh_bank_cache=args.refresh_bank_cache,
    )

    dataset = build_dataset(args.target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    groups = collect_groups(
        model=model,
        text_pair=learned_pair,
        axis=axis,
        fp_banks=fp_banks,
        def_banks=def_banks,
        dataset=dataset,
        target_dataset=args.target_dataset,
        heldout_class=args.heldout_class if args.target_dataset == "mvtec" else None,
        target_class=args.target_class,
        features_list=args.features_list,
        image_size=args.image_size,
        tau=args.tau,
        hard_frac=args.hard_frac,
        max_normal_eval_images=args.max_normal_eval_images,
        max_anomaly_eval_images=args.max_anomaly_eval_images,
    )

    groups = {k: sample_array(v, 200000, seed=i) for i, (k, v) in enumerate(groups.items())}
    stem = f"axis_entanglement_{args.source_dataset}2{args.target_dataset}"
    panel_summary, png_path, pdf_path = plot_groups(groups, Path(args.save_dir), stem, args.title)

    payload = {
        "summary": {
            "source_dataset": args.source_dataset,
            "target_dataset": args.target_dataset,
            "target_mode": args.target_mode,
            "target_class": args.target_class,
            "checkpoint_path": args.checkpoint_path,
            "bank_cache_path": str(bank_cache_path),
            "bank_cache_meta": bank_cache_meta,
            "bank_stats": bank_stats,
            "hard_frac": args.hard_frac,
            "tau": args.tau,
            "max_normal_eval_images": args.max_normal_eval_images,
            "max_anomaly_eval_images": args.max_anomaly_eval_images,
        },
        "panel_summary": panel_summary,
        "groups": {k: v.tolist() for k, v in groups.items()},
        "png_path": str(png_path),
        "pdf_path": str(pdf_path),
    }
    save_dir = Path(args.save_dir)
    with open(save_dir / f"{stem}.json", "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload["panel_summary"], indent=2))
    print(png_path)
    print(pdf_path)


if __name__ == "__main__":
    main()
