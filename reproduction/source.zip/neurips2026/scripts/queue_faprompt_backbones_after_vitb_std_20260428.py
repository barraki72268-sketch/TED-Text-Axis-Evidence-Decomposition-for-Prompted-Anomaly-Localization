#!/usr/bin/env python3
"""Wait for FAPrompt ViT-B std runs, then launch remaining backbone runs."""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]


def expected_vitb_summaries(seeds: list[int]) -> list[Path]:
    paths = []
    for seed in seeds:
        for preset in PRESETS:
            paths.append(
                Path("neurips2026/results")
                / f"faprompt_branchcal_vitb16plus_f3-6-9-12_dpam10_{preset}_"
                f"rank4_a02_officialimg_seed{seed}_20260428"
                / "summary.json"
            )
    return paths


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wait_seeds", default="1,2")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--poll_sec", type=int, default=60)
    args = ap.parse_args()

    seeds = [int(x) for x in args.wait_seeds.split(",") if x.strip()]
    paths = expected_vitb_summaries(seeds)
    while True:
        missing = [p for p in paths if not p.exists()]
        if not missing:
            break
        print(f"[WAIT] FAPrompt ViT-B std summaries missing: {len(missing)}", flush=True)
        time.sleep(args.poll_sec)

    cmd = [
        sys.executable,
        "-u",
        "neurips2026/scripts/queue_faprompt_branchcal_backbones_seed0_20260428.py",
        "--seed",
        "0",
        "--device",
        args.device,
        "--backbones",
        "vitl14openai,vith14",
    ]
    print("[RUN] launching remaining FAPrompt backbones", flush=True)
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
