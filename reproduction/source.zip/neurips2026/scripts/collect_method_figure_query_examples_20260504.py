#!/usr/bin/env python3
"""Collect query defect / hard-FP patch examples for the TED method figure."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps


ROOT = Path("neurips2026/results")
OUT_ROOT = Path("figure/method_figure/query_examples")

CASES = {
    "tted_capsule_visa2mvtec": ROOT / "faprompt_ted_story_vitl336_visa2mvtec_capsule_alpha15",
    "cted_pcb1_mvtec2visa": ROOT / "faprompt_ted_story_vitl336_mvtec2visa_pcb1_alpha15",
}


def add_border_and_label(src: Path, dst: Path, label: str, color: tuple[int, int, int]) -> None:
    img = Image.open(src).convert("RGB")
    img = ImageOps.contain(img, (180, 180), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (190, 210), (255, 255, 255))
    canvas.paste(img, ((190 - img.width) // 2, 24))
    draw = ImageDraw.Draw(canvas)
    draw.text((8, 5), label, fill=color)
    for i in range(3):
        draw.rectangle([i, 24 + i, 189 - i, 209 - i], outline=color)
    canvas.save(dst)


def make_contact(case_dir: Path, out_path: Path) -> None:
    d = Image.open(case_dir / "D_query_labeled.png").convert("RGB")
    h = Image.open(case_dir / "HFP_query_labeled.png").convert("RGB")
    pad = 12
    sheet = Image.new("RGB", (d.width + h.width + pad * 3, max(d.height, h.height) + pad * 2), (255, 255, 255))
    sheet.paste(d, (pad, pad))
    sheet.paste(h, (pad * 2 + d.width, pad))
    sheet.save(out_path)


def main() -> None:
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    top_manifest: dict[str, object] = {"cases": {}}

    for case_name, src_dir in CASES.items():
        if not src_dir.exists():
            raise FileNotFoundError(src_dir)
        case_out = OUT_ROOT / case_name
        case_out.mkdir(parents=True, exist_ok=True)

        defect_src = src_dir / "defect_crop.png"
        hard_src = src_dir / "hard_normal_crop.png"
        pair_src = src_dir / "selected_pair.json"
        pair = json.loads(pair_src.read_text(encoding="utf-8"))

        shutil.copy2(defect_src, case_out / "D_query.png")
        shutil.copy2(hard_src, case_out / "HFP_query.png")
        shutil.copy2(pair_src, case_out / "selected_pair.json")

        add_border_and_label(defect_src, case_out / "D_query_labeled.png", "D query", (205, 38, 38))
        add_border_and_label(hard_src, case_out / "HFP_query_labeled.png", "H-FP query", (32, 96, 196))
        make_contact(case_out, case_out / "query_pair_contact_sheet.png")

        top_manifest["cases"][case_name] = {
            "case_dir": str(case_out),
            "source_story_dir": str(src_dir),
            "recommended_use": "T-TED/direct evidence margin" if case_name.startswith("tted") else "C-TED/source residual subspace",
            "D_query": str(case_out / "D_query.png"),
            "HFP_query": str(case_out / "HFP_query.png"),
            "D_query_labeled": str(case_out / "D_query_labeled.png"),
            "HFP_query_labeled": str(case_out / "HFP_query_labeled.png"),
            "contact_sheet": str(case_out / "query_pair_contact_sheet.png"),
            "selected": pair.get("selected", {}),
            "pair_info": pair.get("pair_info", {}),
        }

    (OUT_ROOT / "manifest.json").write_text(json.dumps(top_manifest, indent=2), encoding="utf-8")
    print(json.dumps({"out_dir": str(OUT_ROOT), "cases": list(CASES)}, indent=2))


if __name__ == "__main__":
    main()
