#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT = ROOT / "neurips2026/results/layer_selection_burden_20260502"
LOG = OUT / "logs"

ADACLIP = ROOT / "neurips2026/scripts/official_parallel_test_adaclip.py"
FAPROMPT = ROOT / "neurips2026/scripts/official_parallel_test_faprompt.py"

MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD = Path("/mnt/data/MPDD")
BTAD = ROOT / "neurips2026/data/BTAD_official"
VISA = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"

ADACLIP_MVTEC_CKPT = ROOT / "neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth"
ADACLIP_BANK_MVTEC = ROOT / "neurips2026/results/bank_cache/maintable_adaclip_vitl336_mvtec_seed0.pt"


ADACLIP_TRANSFERS = {
    "mvtec2mpdd": {
        "source_root": MVTEC,
        "source_dataset": "mvtec",
        "target_root": MPDD,
        "target_dataset": "mpdd",
    },
    "mvtec2btad": {
        "source_root": MVTEC,
        "source_dataset": "mvtec",
        "target_root": BTAD,
        "target_dataset": "btad",
    },
}

ADACLIP_RECIPES = ("all4", "earlylate", "mid2", "last2", "last")

FAPROMPT_RECIPES = {
    "all4": ["6", "12", "18", "24"],
    "earlylate": ["6", "24"],
    "mid2": ["12", "18"],
    "last": ["24"],
}


def run(cmd: list[str], log_path: Path, env: dict[str, str], cwd: Path = ROOT) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"failed: {log_path}")


def queue_adaclip(env: dict[str, str]) -> None:
    for transfer, cfg in ADACLIP_TRANSFERS.items():
        for recipe in ADACLIP_RECIPES:
            save_dir = OUT / f"adaclip_{transfer}_{recipe}"
            if (save_dir / "summary.json").exists():
                print({"stage": "skip", "summary": str(save_dir / "summary.json")}, flush=True)
                continue
            cmd = [
                str(PY),
                "-u",
                str(ADACLIP),
                "--source_root",
                str(cfg["source_root"]),
                "--source_dataset",
                str(cfg["source_dataset"]),
                "--target_root",
                str(cfg["target_root"]),
                "--target_dataset",
                str(cfg["target_dataset"]),
                "--checkpoint_path",
                str(ADACLIP_MVTEC_CKPT),
                "--save_dir",
                str(save_dir),
                "--bank_cache_path",
                str(ADACLIP_BANK_MVTEC),
                "--seed",
                "0",
                "--device",
                "cuda:0",
                "--batch_size",
                "1",
                "--num_workers",
                "4",
                "--cpu_threads",
                "4",
                "--layer_recipe",
                recipe,
                "--enable_calibrator",
                "--calib_epochs",
                "30",
                "--calib_subspace_rank",
                "8",
                "--calib_insertion_mode",
                "prescore_rectify",
                "--calib_train_score_space",
                "cache_prob",
                "--calib_lambda",
                "0.3",
                "--calib_eta_max",
                "1.0",
                "--scoring_mode",
                "logit_gate_posneg",
                "--ours_image_score_mode",
                "official_plus_map_topk",
                "--eval_metrics",
                "I-AUROC",
                "I-AP",
                "P-AUROC",
                "P-AP",
                "P-AUPRO",
                "--aupro_max_step",
                "200",
            ]
            run(cmd, LOG / f"adaclip_{transfer}_{recipe}.log", env)


def queue_faprompt(env: dict[str, str]) -> None:
    # One representative host/target pair is enough to show that layer selection
    # is a feature-source choice, not an evidence-decoding principle.
    preset = "mvtec2btad"
    for recipe, features in FAPROMPT_RECIPES.items():
        save_dir = OUT / f"faprompt_vitl336_{preset}_{recipe}"
        if (save_dir / "summary.json").exists():
            print({"stage": "skip", "summary": str(save_dir / "summary.json")}, flush=True)
            continue
        cmd = [
            str(PY),
            "-u",
            str(FAPROMPT),
            "--preset",
            preset,
            "--model_name",
            "ViT-L/14@336px",
            "--prompt_load_mode",
            "strict",
            "--features_list",
            *features,
            "--image_size",
            "518",
            "--batch_size",
            "2",
            "--num_workers",
            "4",
            "--dap_token_mode",
            "official_firstk",
            "--dpam_layer",
            "20",
            "--max_fp_per_class",
            "512",
            "--max_defect_per_class",
            "512",
            "--max_fp_total",
            "4096",
            "--max_defect_total",
            "4096",
            "--normal_topk_frac",
            "0.01",
            "--tau",
            "0.1",
            "--fp_weight",
            "1.0",
            "--alphas",
            "0.5,1.0",
            "--ours_image_score_mode",
            "official",
            "--insert_modes",
            "branch_calibrated",
            "--prescore_calib_epochs",
            "30",
            "--prescore_calib_lr",
            "0.02",
            "--prescore_calib_max_train_points",
            "2048",
            "--prescore_calib_alpha_init",
            "0.05",
            "--prescore_calib_alpha_max",
            "0.2",
            "--prescore_calib_subspace_rank",
            "4",
            "--aupro_max_step",
            "50",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--save_dir",
            str(save_dir),
        ]
        run(cmd, LOG / f"faprompt_vitl336_{preset}_{recipe}.log", env)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-layer-selection-burden")
    queue_adaclip(env)
    queue_faprompt(env)
    print({"stage": "done", "task": "layer_selection_burden_gpu1"}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
