#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"
GPU_ID="${1:-0}"
LAMBDA="${2:-0.1}"
TAG="${3:-lambda_0p1}"
EPOCHS="${4:-5}"
BATCH_SIZE="${5:-8}"
SKIP_TOPK="${6:-0}"

MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"

SAVE_DIR="${ROOT}/neurips2026/results/anomalyclip_lproj_${TAG}/checkpoints"
mkdir -p "${SAVE_DIR}"

cd "${ROOT}/neurips2026/AnomalyCLIP"

CUDA_VISIBLE_DEVICES="${GPU_ID}" "${PY}" train.py \
  --dataset mvtec \
  --train_data_path "${MVTEC_ROOT}" \
  --save_path "${SAVE_DIR}" \
  --features_list 24 \
  --image_size 518 \
  --batch_size "${BATCH_SIZE}" \
  --print_freq 1 \
  --epoch "${EPOCHS}" \
  --save_freq 1 \
  --depth 9 \
  --n_ctx 12 \
  --t_n_ctx 4 \
  --text_leakage_reg \
  --text_ortho_weight "${LAMBDA}" \
  --text_anchor_weight 0.0 \
  --text_proj_skip_topk "${SKIP_TOPK}"
