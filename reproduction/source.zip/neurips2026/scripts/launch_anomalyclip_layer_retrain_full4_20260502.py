#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
OUT_ROOT = ROOT / "neurips2026/results/anomalyclip_layer_retrained_full4_20260502"
LOG_ROOT = OUT_ROOT / "logs"

VISA_1CLS = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
TRAIN_DIR = ROOT / "neurips2026/AnomalyCLIP"
EVAL_SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w") as log:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=log, stderr=subprocess.STDOUT)
    return int(proc.returncode)


def main() -> int:
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    (OUT_ROOT / "bank_cache").mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-anomalyclip-layer-retrain-20260502")

    ckpt_dir = OUT_ROOT / "anomalyclip_visa_full4_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if not ckpt_path.exists():
        train_cmd = [
            PY,
            "-u",
            "train.py",
            "--dataset",
            "visa",
            "--train_data_path",
            str(VISA_1CLS),
            "--save_path",
            str(ckpt_dir),
            "--features_list",
            "6",
            "12",
            "18",
            "24",
            "--feature_map_layer",
            "0",
            "1",
            "2",
            "3",
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ]
        rc = run(train_cmd, TRAIN_DIR, LOG_ROOT / "train_visa_full4.log", env)
        if rc != 0:
            return rc

    eval_dir = OUT_ROOT / "visa2mvtec_full4_retrained_eval"
    eval_cmd = [
        PY,
        "-u",
        str(EVAL_SCRIPT),
        "--device",
        "cuda:0",
        "--checkpoint_path",
        str(ckpt_path),
        "--model_name_or_path",
        "ViT-L/14@336px",
        "--heldout_class",
        "none",
        "--source_root",
        str(VISA_1CLS),
        "--source_dataset",
        "visa",
        "--target_root",
        str(MVTEC_ROOT),
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--baseline_features_list",
        "6",
        "12",
        "18",
        "24",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--dpam_layer",
        "20",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(OUT_ROOT / "bank_cache/anomalyclip_visa_full4_retrained_withscores.pt"),
        "--refresh_bank_cache",
        "--enable_calibrator",
        "--calib_seed",
        "0",
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(eval_dir),
    ]
    return run(eval_cmd, ROOT, LOG_ROOT / "eval_visa2mvtec_full4_retrained.log", env)


if __name__ == "__main__":
    raise SystemExit(main())
