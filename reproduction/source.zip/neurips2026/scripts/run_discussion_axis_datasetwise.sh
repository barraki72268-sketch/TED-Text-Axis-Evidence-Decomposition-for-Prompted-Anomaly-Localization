#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
SCRIPT="${ROOT}/neurips2026/scripts/probe_anomalyclip_text_axis_decomposition.py"
PY="/mnt/data/envs/patchcore-conda/bin/python"

if [[ $# -lt 2 ]]; then
  echo "usage: $0 <group:mvtec|others> <cuda_device>" >&2
  exit 1
fi

GROUP="$1"
DEVICE="$2"

run_probe() {
  local save_dir="$1"
  shift
  "${PY}" "${SCRIPT}" "$@" \
    --device "${DEVICE}" \
    --save_dir "${save_dir}" \
    --max_good_per_class 2 \
    --max_defect_per_class 4 \
    --max_bank_per_layer 512 \
    --max_fp_per_image 64 \
    --max_defect_per_image 64
}

if [[ "${GROUP}" == "mvtec" ]]; then
  run_probe \
    "${ROOT}/neurips2026/results/anomalyclip_text_axis_decomposition_visa2mvtec_all_epoch15_discussion" \
    --source_root "neurips2026/data/VisA_pytorch_official/1cls" \
    --source_dataset visa \
    --target_root /mnt/data/pilab-kingjinyoung/ijepa/data/mvtec \
    --target_dataset mvtec \
    --target_mode test \
    --checkpoint_path "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth" \
    --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/anomalyclip_visa_official1cls_epoch15_multiscale.pt" \
    --heldout_class none \
    --source_exclude_class none
elif [[ "${GROUP}" == "others" ]]; then
  run_probe \
    "${ROOT}/neurips2026/results/anomalyclip_text_axis_decomposition_mvtec2visa_all_epoch15_discussion" \
    --source_root /mnt/data/pilab-kingjinyoung/ijepa/data/mvtec \
    --source_dataset mvtec \
    --target_root "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
    --target_dataset visa \
    --target_mode test \
    --checkpoint_path "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth" \
    --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/anomalyclip_mvtec_full_epoch15_multiscale_visa.pt" \
    --heldout_class none \
    --source_exclude_class none

  run_probe \
    "${ROOT}/neurips2026/results/anomalyclip_text_axis_decomposition_mvtec2mpdd_epoch15_discussion" \
    --source_root /mnt/data/pilab-kingjinyoung/ijepa/data/mvtec \
    --source_dataset mvtec \
    --target_root /mnt/data/MPDD \
    --target_dataset mpdd \
    --target_mode test \
    --checkpoint_path "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth" \
    --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/anomalyclip_mvtec_full_epoch15_multiscale_visa.pt" \
    --heldout_class none \
    --source_exclude_class none

  run_probe \
    "${ROOT}/neurips2026/results/anomalyclip_text_axis_decomposition_mvtec2btad_all_epoch15_discussion" \
    --source_root /mnt/data/pilab-kingjinyoung/ijepa/data/mvtec \
    --source_dataset mvtec \
    --target_root "${ROOT}/neurips2026/data/BTAD_official" \
    --target_dataset btad \
    --target_mode test \
    --checkpoint_path "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth" \
    --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/anomalyclip_mvtec_full_epoch15_multiscale_visa.pt" \
    --heldout_class none \
    --source_exclude_class none
else
  echo "unknown group: ${GROUP}" >&2
  exit 1
fi
