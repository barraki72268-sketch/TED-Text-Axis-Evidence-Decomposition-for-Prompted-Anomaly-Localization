#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_layer_stress_baselast_ours4_20260502"
LOG_ROOT = RESULT_ROOT / "_logs"

VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale_visa/epoch_15.pth")

VARIANTS = {
    "last_tedlast": {
        "baseline_layers": ["24"],
        "ted_layers": ["24"],
        "description": "official last-layer baseline and last-layer TED diagnostic",
    },
    "last_ted4": {
        "baseline_layers": ["24"],
        "ted_layers": ["6", "12", "18", "24"],
        "description": "official last-layer baseline with 4-layer TED",
    },
    "full_ted4": {
        "baseline_layers": ["6", "12", "18", "24"],
        "ted_layers": ["6", "12", "18", "24"],
        "description": "stressed 4-layer baseline with 4-layer TED",
    },
}


def wait_pid(pid: int) -> None:
    if pid <= 0:
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            print({"stage": "wait_pid_done", "pid": pid}, flush=True)
            return
        time.sleep(60)


def build_cmd(variant_name: str, variant: dict[str, list[str] | str], seed: int, device: str) -> list[str]:
    save_dir = RESULT_ROOT / f"visa2mvtec_{variant_name}_seed{seed}"
    cmd = [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        VISA_CKPT,
        "--heldout_class",
        "none",
        "--source_root",
        VISA_ROOT,
        "--source_dataset",
        "visa",
        "--target_root",
        MVTEC_ROOT,
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--baseline_features_list",
        *variant["baseline_layers"],
        "--features_list",
        *variant["ted_layers"],
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    return [str(x) for x in cmd]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda:1")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--variants", default="last_tedlast,last_ted4,full_ted4")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    wait_pid(args.wait_pid)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    variants = [name.strip() for name in args.variants.split(",") if name.strip()]
    unknown = [name for name in variants if name not in VARIANTS]
    if unknown:
        raise SystemExit(f"Unknown variants {unknown}. Allowed: {sorted(VARIANTS)}")

    for variant_name in variants:
        variant = VARIANTS[variant_name]
        save_dir = RESULT_ROOT / f"visa2mvtec_{variant_name}_seed{args.seed}"
        summary_path = save_dir / "summary.json"
        log_path = LOG_ROOT / f"visa2mvtec_{variant_name}_seed{args.seed}.log"
        if summary_path.exists() and not args.force:
            print({"stage": "skip_completed", "variant": variant_name, "summary": str(summary_path)}, flush=True)
            continue
        cmd = build_cmd(variant_name, variant, args.seed, args.device)
        print(
            {
                "stage": "start",
                "variant": variant_name,
                "description": variant["description"],
                "log": str(log_path),
            },
            flush=True,
        )
        with log_path.open("w") as log_file:
            proc = subprocess.run(cmd, cwd=str(ROOT), stdout=log_file, stderr=subprocess.STDOUT, text=True)
        print({"stage": "done", "variant": variant_name, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
        if proc.returncode != 0:
            raise SystemExit(proc.returncode)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
