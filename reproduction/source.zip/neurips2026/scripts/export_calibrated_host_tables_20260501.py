#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import statistics
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT_DIR = RESULTS / "final_metric_and_novelty_tables"

METRIC_KEYS = ("image_auroc", "pixel_auroc", "pixel_aupro", "pixel_ap")
TARGETS = ("MVTec", "VisA", "MPDD", "BTAD")


def load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def mean_row(summary: dict | None, mode: str) -> dict | None:
    if summary is None:
        return None
    for row in summary.get("rows", []):
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return row
    return None


def aggregate(paths: Iterable[Path], mode: str) -> tuple[list[float], list[float]] | None:
    values: list[list[float]] = []
    for path in paths:
        row = mean_row(load_json(path), mode)
        if row is None:
            continue
        vals = [row.get(k) for k in METRIC_KEYS]
        if any(v is None or (isinstance(v, float) and math.isnan(v)) for v in vals):
            continue
        values.append([float(v) * 100.0 for v in vals])
    if not values:
        return None
    cols = list(zip(*values))
    means = [sum(col) / len(col) for col in cols]
    stds = [statistics.stdev(col) if len(col) > 1 else 0.0 for col in cols]
    return means, stds


def metric_cell(base: tuple[list[float], list[float]] | None, ours: tuple[list[float], list[float]] | None, row: str, idx: int) -> str:
    current = base if row == "base" else ours
    other = ours if row == "base" else base
    if current is None:
        return "--.--"
    mean, std = current
    text = f"{mean[idx]:.2f}$\\pm${std[idx]:.2f}"
    if other is None:
        return text
    other_mean = other[0][idx]
    if mean[idx] >= other_mean - 1e-12:
        return f"\\textbf{{{text}}}"
    return text


def anomalyclip_paths(backbone_key: str, target: str) -> list[Path]:
    target_to_transfer = {
        "MVTec": "visa2mvtec",
        "VisA": "mvtec2visa",
        "MPDD": "mvtec2mpdd",
        "BTAD": "mvtec2btad",
    }
    transfer = target_to_transfer[target]
    if backbone_key == "vitl336":
        root = RESULTS / "anomalyclip_ted_trainfree_anchor_seeded_20260430"
        return [root / f"{transfer}_seed{seed}" / "summary.json" for seed in range(3)]
    root = RESULTS / "anomalyclip_ted_backbone_swap_seeded_20260430"
    prefix = {
        "vitb": "vitb16_projected",
        "vitl_openai": "vitl_openai",
        "vith": "vith14_projected",
    }[backbone_key]
    return [root / f"{prefix}_{transfer}_seed{seed}" / "summary.json" for seed in range(3)]


def bayespfl_paths(backbone_key: str, target: str) -> list[Path]:
    target_to_transfer = {
        "MVTec": "mvtec2mvtec",
        "VisA": "mvtec2visa",
        "MPDD": "mvtec2mpdd",
        "BTAD": "mvtec2btad",
    }
    root = {
        "vitb": RESULTS / "bayespfl_ted_vitbplus_swap_seeded_20260501",
        "vitl_openai": RESULTS / "bayespfl_ted_vitl_openai_swap_seeded_20260430",
        "vitl336": RESULTS / "bayespfl_ted_official_mvtecsource_seeded_20260430",
        "vith": RESULTS / "bayespfl_ted_vith14_swap_seeded_20260501",
    }[backbone_key]
    transfer = target_to_transfer[target]
    return [root / f"{transfer}_seed{seed}" / "summary.json" for seed in range(3)]


def render_table(
    host: str,
    label: str,
    caption: str,
    path_fn,
    backbones: tuple[tuple[str, str], ...],
) -> str:
    lines: list[str] = [
        r"\begin{table*}[h]",
        r"\centering",
        rf"\caption{{Results with \textbf{{{host}}} as host using calibrated TED.}}",
        rf"\label{{{label}}}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\renewcommand{\arraystretch}{1.08}",
        r"\resizebox{\textwidth}{!}{",
        r"\begin{tabular}{lllc cccc}",
        r"\toprule",
        r"Host & Backbone & Target & Method & I-AUROC & P-AUROC & P-PRO & P-AP \\",
        r"\midrule",
        "",
        rf"\multirow{{32}}{{*}}{{\begin{{tabular}}[c]{{@{{}}c@{{}}}}{host}\end{{tabular}}}}",
        "",
    ]
    for b_idx, (backbone_key, backbone_name) in enumerate(backbones):
        if b_idx > 0:
            lines.append(r"\cmidrule(lr){2-8}")
            lines.append("")
        lines.append(f"% ---------------- {backbone_name} ----------------")
        lines.append(rf"& \multirow{{8}}{{*}}{{{backbone_name}}}")
        for t_idx, target in enumerate(TARGETS):
            if t_idx > 0:
                lines.append(r"\cmidrule(lr){3-8}")
                lines.append("")
                lines.append(rf"& & \multirow{{2}}{{*}}{{{target}}} & Base")
            else:
                lines.append(rf"& \multirow{{2}}{{*}}{{{target}}} & Base")
            paths = path_fn(backbone_key, target)
            base = aggregate(paths, "baseline_txt")
            ours = aggregate(paths, "ted_calibrated")
            base_cells = [metric_cell(base, ours, "base", i) for i in range(4)]
            ours_cells = [metric_cell(base, ours, "ours", i) for i in range(4)]
            lines[-1] += " & " + " & ".join(base_cells) + r" \\"
            lines.append(r"& & & OURS & " + " & ".join(ours_cells) + r" \\")
            if t_idx == len(TARGETS) - 1:
                lines.append("")
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"}",
            r"\end{table*}",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    backbones = (
        ("vitb", "ViT-B/16+"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
        ("vitl336", "ViT-L/14-336"),
        ("vith", "ViT-H/14"),
    )
    anomaly_tex = render_table(
        host="AnomalyCLIP",
        label="tab:anomalyclip_results",
        caption="Results with AnomalyCLIP as host.",
        path_fn=anomalyclip_paths,
        backbones=backbones,
    )
    bayes_tex = render_table(
        host="BayesPFL",
        label="tab:bayespfl_results",
        caption="Results with BayesPFL as host.",
        path_fn=bayespfl_paths,
        backbones=backbones,
    )
    (OUT_DIR / "AnomalyCLIP.tex").write_text(anomaly_tex)
    (OUT_DIR / "BayesPFL.tex").write_text(bayes_tex)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
