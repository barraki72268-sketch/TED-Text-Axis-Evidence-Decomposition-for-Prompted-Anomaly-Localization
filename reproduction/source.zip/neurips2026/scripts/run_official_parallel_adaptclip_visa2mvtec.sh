#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_adaptclip.py"
CKPT="${ROOT}/neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth"
export MPLCONFIGDIR="/tmp/matplotlib-adaptclip-gpu1"

CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" \
  --source_root "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  --source_dataset visa \
  --target_root "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  --target_dataset mvtec \
  --checkpoint_path "${CKPT}" \
  --save_dir "${ROOT}/neurips2026/results/official_parallel_test_adaptclip_visa2mvtec_all" \
  --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/adaptclip_visa_official1cls_multilayer.pt" \
  --pretrained_model "ViT-L/14@336px" \
  --features_list 6 12 18 24 \
  --image_size 518 \
  --batch_size 8 \
  --n_ctx 12 \
  --sigma 4 \
  --vl_reduction 4 \
  --fusion_type average_mean \
  --max_good_per_class 2 \
  --max_defect_per_class 4 \
  --max_bank_per_layer 512 \
  --max_fp_per_image 64 \
  --max_defect_per_image 64 \
  --device cuda:0
