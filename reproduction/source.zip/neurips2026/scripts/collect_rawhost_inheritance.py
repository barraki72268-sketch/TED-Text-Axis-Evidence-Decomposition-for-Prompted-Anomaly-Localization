from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from collect_rawfamily_gtfree_entanglement import PRESET_LABELS, collect_gtfree_topk_scores as collect_rawfamily_scores
from generate_anomalyclip_gtfree_overlap_figure import collect_gtfree_topk_scores as collect_anomalyclip_scores


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"


def canonical_image_id(image_path: str, target_root: str) -> str:
    p = Path(image_path)
    root = Path(target_root)
    try:
        return p.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        parts = p.parts
        return "/".join(parts[-4:]) if len(parts) >= 4 else p.as_posix()


def rankdata_average(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(len(x), dtype=np.float64)
    sorted_x = x[order]
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and sorted_x[j] == sorted_x[i]:
            j += 1
        rank = 0.5 * (i + j - 1) + 1.0
        ranks[order[i:j]] = rank
        i = j
    return ranks


def spearman_rho(x: np.ndarray, y: np.ndarray) -> float:
    rx = rankdata_average(x)
    ry = rankdata_average(y)
    sx = rx.std()
    sy = ry.std()
    if sx < 1e-12 or sy < 1e-12:
        return float("nan")
    return float(np.corrcoef(rx, ry)[0, 1])


def align_records(raw_payload: dict, host_payload: dict) -> tuple[list[dict], list[dict]]:
    raw_root = raw_payload["meta"]["target_root"]
    host_root = host_payload["meta"]["target_root"]
    raw_by_id = {
        canonical_image_id(rec["image_path"], raw_root): rec
        for rec in raw_payload["records"]
    }
    host_by_id = {
        canonical_image_id(rec["image_path"], host_root): rec
        for rec in host_payload["records"]
    }
    common = sorted(set(raw_by_id.keys()) & set(host_by_id.keys()))
    return [raw_by_id[k] for k in common], [host_by_id[k] for k in common]


def split_anomaly_normal(records: list[dict], score_key: str) -> tuple[np.ndarray, np.ndarray]:
    anomaly = np.asarray([float(r[score_key]) for r in records if int(r["anomaly"]) == 1], dtype=np.float32)
    normal = np.asarray([float(r[score_key]) for r in records if int(r["anomaly"]) == 0], dtype=np.float32)
    return anomaly, normal


def pair_misordered_rate(anomaly_scores: np.ndarray, normal_scores: np.ndarray) -> tuple[np.ndarray, float]:
    misordered = anomaly_scores[:, None] <= normal_scores[None, :]
    return misordered, float(misordered.mean())


def pair_order_agreement(raw_anom: np.ndarray, raw_norm: np.ndarray, host_anom: np.ndarray, host_norm: np.ndarray) -> float:
    raw_pos = raw_anom[:, None] > raw_norm[None, :]
    host_pos = host_anom[:, None] > host_norm[None, :]
    return float((raw_pos == host_pos).mean())


def correction_rate(
    baseline_anom: np.ndarray,
    baseline_norm: np.ndarray,
    ours_anom: np.ndarray,
    ours_norm: np.ndarray,
) -> float:
    misordered = baseline_anom[:, None] <= baseline_norm[None, :]
    total = int(misordered.sum())
    if total == 0:
        return float("nan")
    corrected = misordered & (ours_anom[:, None] > ours_norm[None, :])
    return float(corrected.sum() / total)


def inherited_misorder_rate(
    raw_anom: np.ndarray,
    raw_norm: np.ndarray,
    host_anom: np.ndarray,
    host_norm: np.ndarray,
) -> float:
    raw_mis = raw_anom[:, None] <= raw_norm[None, :]
    total = int(raw_mis.sum())
    if total == 0:
        return float("nan")
    host_mis = host_anom[:, None] <= host_norm[None, :]
    return float((raw_mis & host_mis).sum() / total)


def main() -> None:
    parser = argparse.ArgumentParser("Collect raw-to-host entanglement inheritance metrics")
    parser.add_argument("--raw_model_key", type=str, default="rawclip_vitl")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--max_normal_images", type=int, default=64)
    parser.add_argument("--max_anomaly_images", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULTS / "rawhost_inheritance_vitl_to_anomalyclip"),
    )
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for preset in PRESET_LABELS:
        raw_arrays, raw_payload = collect_rawfamily_scores(
            model_key=args.raw_model_key,
            preset=preset,
            device=args.device,
            max_normal_images=args.max_normal_images,
            max_anomaly_images=args.max_anomaly_images,
            seed=args.seed,
        )
        host_arrays, host_payload = collect_anomalyclip_scores(
            preset=preset,
            device=args.device,
            max_normal_images=args.max_normal_images,
            max_anomaly_images=args.max_anomaly_images,
            seed=args.seed,
        )
        raw_records, host_records = align_records(raw_payload, host_payload)
        raw_scores = np.asarray([r["raw_score"] for r in raw_records], dtype=np.float32)
        host_scores = np.asarray([r["raw_score"] for r in host_records], dtype=np.float32)

        raw_anom, raw_norm = split_anomaly_normal(raw_records, "raw_score")
        raw_par_anom, raw_par_norm = split_anomaly_normal(raw_records, "parallel_score")
        host_anom, host_norm = split_anomaly_normal(host_records, "raw_score")
        host_par_anom, host_par_norm = split_anomaly_normal(host_records, "parallel_score")

        _, raw_mis_rate = pair_misordered_rate(raw_anom, raw_norm)
        _, host_mis_rate = pair_misordered_rate(host_anom, host_norm)

        row = {
            "preset": preset,
            "preset_label": PRESET_LABELS[preset],
            "num_images": int(len(raw_records)),
            "num_anomaly": int(raw_anom.size),
            "num_normal": int(raw_norm.size),
            "spearman_rho": spearman_rho(raw_scores, host_scores),
            "pair_order_agreement": pair_order_agreement(raw_anom, raw_norm, host_anom, host_norm),
            "raw_misordered_rate": raw_mis_rate,
            "host_misordered_rate": host_mis_rate,
            "inherited_misorder_rate": inherited_misorder_rate(raw_anom, raw_norm, host_anom, host_norm),
            "raw_correction_rate": correction_rate(raw_anom, raw_norm, raw_par_anom, raw_par_norm),
            "host_correction_rate": correction_rate(host_anom, host_norm, host_par_anom, host_par_norm),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)

    with (save_dir / "metrics.json").open("w") as f:
        json.dump({"raw_model_key": args.raw_model_key, "rows": rows}, f, indent=2)
    with (save_dir / "metrics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    labels = [r["preset_label"] for r in rows]
    y = np.arange(len(rows))
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.2), constrained_layout=True)

    ax = axes[0]
    pair_agree = [r["pair_order_agreement"] for r in rows]
    inherited = [r["inherited_misorder_rate"] for r in rows]
    ax.barh(y - 0.18, pair_agree, height=0.32, color="#4C72B0", label="Pair-order agreement")
    ax.barh(y + 0.18, inherited, height=0.32, color="#DD8452", label="Inherited misorder rate")
    ax.set_yticks(y, labels)
    ax.set_xlim(0.0, 1.0)
    ax.set_title("Raw → Host Inheritance")
    ax.grid(axis="x", alpha=0.15)
    ax.legend(frameon=False, loc="lower right")

    ax = axes[1]
    raw_corr = [r["raw_correction_rate"] for r in rows]
    host_corr = [r["host_correction_rate"] for r in rows]
    ax.barh(y - 0.18, raw_corr, height=0.32, color="#55A868", label="Raw correction rate")
    ax.barh(y + 0.18, host_corr, height=0.32, color="#C44E52", label="Host correction rate")
    ax.set_yticks(y, labels)
    ax.set_xlim(0.0, 1.0)
    ax.set_title("OURS Pair Correction Rate")
    ax.grid(axis="x", alpha=0.15)
    ax.legend(frameon=False, loc="lower right")

    fig.suptitle(f"Raw→Host Inheritance and OURS Correction ({args.raw_model_key} → AnomalyCLIP)", fontsize=13)
    fig.savefig(save_dir / "inheritance_summary.png", dpi=220, bbox_inches="tight")
    fig.savefig(save_dir / "inheritance_summary.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
