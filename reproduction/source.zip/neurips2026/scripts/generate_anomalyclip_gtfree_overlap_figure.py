from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    build_dataset,
    decision_axis,
    load_source_patch_banks_cache,
    logmeanexp_negative_sqdist,
    logmeanexp_negative_sqdist_1d,
    project_bank,
    topk_mean,
)


DISCUSSION_SUMMARIES = {
    "visa2mvtec": RESULTS / "anomalyclip_text_axis_decomposition_visa2mvtec_all_epoch15_discussion" / "summary.json",
    "mvtec2visa": RESULTS / "anomalyclip_text_axis_decomposition_mvtec2visa_all_epoch15_discussion" / "summary.json",
    "mvtec2mpdd": RESULTS / "anomalyclip_text_axis_decomposition_mvtec2mpdd_epoch15_discussion" / "summary.json",
    "mvtec2btad": RESULTS / "anomalyclip_text_axis_decomposition_mvtec2btad_all_epoch15_discussion" / "summary.json",
}
PRESET_LABELS = {
    "visa2mvtec": "VisA→MVTec",
    "mvtec2visa": "MVTec→VisA",
    "mvtec2mpdd": "MVTec→MPDD",
    "mvtec2btad": "MVTec→BTAD",
}


def load_json(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def resolve_path(path_str: str) -> Path:
    path = Path(path_str)
    if path.is_absolute():
        return path
    return ROOT / path


def compute_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def histogram_overlap(pos: np.ndarray, neg: np.ndarray, bins: int = 60) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    lo = float(min(pos.min(), neg.min()))
    hi = float(max(pos.max(), neg.max()))
    if hi <= lo:
        hi = lo + 1e-6
    edges = np.linspace(lo, hi, bins + 1)
    pos_hist, _ = np.histogram(pos, bins=edges, density=True)
    neg_hist, _ = np.histogram(neg, bins=edges, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    overlap = np.minimum(pos_hist, neg_hist)
    ovl = float(np.sum(overlap * np.diff(edges)))
    return centers, pos_hist, neg_hist, ovl


def smooth_histogram(y: np.ndarray, sigma_bins: float = 1.6, radius: int = 6) -> np.ndarray:
    if sigma_bins <= 0:
        return y
    xs = np.arange(-radius, radius + 1, dtype=np.float32)
    kernel = np.exp(-(xs**2) / (2.0 * sigma_bins * sigma_bins))
    kernel /= np.clip(kernel.sum(), 1e-8, None)
    return np.convolve(y, kernel, mode="same")


def denormalize_image(img_tensor: torch.Tensor) -> np.ndarray:
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = np.transpose(img_tensor.cpu().numpy(), (1, 2, 0))
    img = np.clip((img * std + mean) * 255.0, 0, 255).astype(np.uint8)
    return img


def crop_from_center(image: np.ndarray, cy: int, cx: int, crop_size: int = 112) -> np.ndarray:
    h, w = image.shape[:2]
    half = crop_size // 2
    y0 = max(0, min(h - crop_size, cy - half))
    x0 = max(0, min(w - crop_size, cx - half))
    y1 = min(h, y0 + crop_size)
    x1 = min(w, x0 + crop_size)
    crop = image[y0:y1, x0:x1]
    if crop.shape[0] != crop_size or crop.shape[1] != crop_size:
        out = np.zeros((crop_size, crop_size, 3), dtype=np.uint8)
        out[: crop.shape[0], : crop.shape[1]] = crop
        return out
    return crop


def select_example_pair(records: list[dict], overlap_center: float) -> tuple[dict, dict]:
    anomaly = [r for r in records if r["anomaly"] == 1]
    normal = [r for r in records if r["anomaly"] == 0]
    anomaly = sorted(anomaly, key=lambda r: abs(r["raw_score"] - overlap_center))[:12]
    normal = sorted(normal, key=lambda r: abs(r["raw_score"] - overlap_center))[:12]
    best_pair = None
    best_score = None
    for a in anomaly:
        for n in normal:
            raw_gap = abs(a["raw_score"] - n["raw_score"])
            parallel_gain = a["parallel_score"] - n["parallel_score"]
            objective = parallel_gain - 0.6 * raw_gap
            if best_pair is None or objective > best_score:
                best_pair = (a, n)
                best_score = objective
    return best_pair


def collect_gtfree_topk_scores(
    preset: str,
    device: str,
    max_normal_images: int | None,
    max_anomaly_images: int | None,
    seed: int,
) -> tuple[dict[str, np.ndarray], dict]:
    payload = load_json(DISCUSSION_SUMMARIES[preset])
    summary = payload["summary"]
    ckpt_path = resolve_path(summary["checkpoint_path"])
    source_root = resolve_path(summary["source_root"])
    target_root = resolve_path(summary["target_root"])
    bank_cache_path = resolve_path(summary["bank_cache_path"])
    source_dataset = summary["source_dataset"]
    target_dataset = summary["target_dataset"]
    image_size = int(summary["bank_cache_meta"]["image_size"])
    features_list = list(summary["bank_cache_meta"]["features_list"])
    image_score_topk = float(summary["image_score_topk"])
    tau = float(summary["tau"])

    model, params = build_model(device, 9, 12, 4)
    learner = load_prompt_learner(model, params, ckpt_path, device)
    learned_pair = get_learned_text_pair(model, learner).to(device)
    learned_axis = decision_axis(learned_pair).to(device)

    fp_banks, def_banks, _, _ = load_source_patch_banks_cache(bank_cache_path)
    fp_banks = {idx: bank.to(device) for idx, bank in fp_banks.items()}
    def_banks = {idx: bank.to(device) for idx, bank in def_banks.items()}
    projected_banks = {}
    for layer_idx in range(len(features_list)):
        fp_coeff, _ = project_bank(fp_banks[layer_idx], learned_axis)
        def_coeff, _ = project_bank(def_banks[layer_idx], learned_axis)
        projected_banks[layer_idx] = {
            "fp_parallel_coeff": fp_coeff,
            "def_parallel_coeff": def_coeff,
        }

    dataset = build_dataset(str(target_root), target_dataset, image_size, mode="test")
    rng = np.random.default_rng(seed)
    normal_indices = [idx for idx, data in enumerate(dataset.data_all) if int(data["anomaly"]) == 0]
    anomaly_indices = [idx for idx, data in enumerate(dataset.data_all) if int(data["anomaly"]) == 1]
    if max_normal_images is not None and len(normal_indices) > max_normal_images:
        normal_indices = rng.choice(normal_indices, size=max_normal_images, replace=False).tolist()
    if max_anomaly_images is not None and len(anomaly_indices) > max_anomaly_images:
        anomaly_indices = rng.choice(anomaly_indices, size=max_anomaly_images, replace=False).tolist()
    selected_indices = sorted(normal_indices + anomaly_indices)

    out = {
        "raw_anomaly": [],
        "raw_normal": [],
        "parallel_anomaly": [],
        "parallel_normal": [],
    }
    records = []
    num_normal = 0
    num_anomaly = 0

    with torch.no_grad():
        for idx in selected_indices:
            item = dataset[idx]
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])

            image = item["img"].unsqueeze(0).to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            raw_maps = []
            parallel_maps = []
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                patch_coeff = patch @ learned_axis
                q_fp_raw = logmeanexp_negative_sqdist(patch, fp_banks[layer_idx], tau=tau)
                q_def_raw = logmeanexp_negative_sqdist(patch, def_banks[layer_idx], tau=tau)
                q_fp_parallel = logmeanexp_negative_sqdist_1d(
                    patch_coeff, projected_banks[layer_idx]["fp_parallel_coeff"], tau=tau
                )
                q_def_parallel = logmeanexp_negative_sqdist_1d(
                    patch_coeff, projected_banks[layer_idx]["def_parallel_coeff"], tau=tau
                )
                side = int(round(patch.shape[0] ** 0.5))
                raw_maps.append((q_def_raw - q_fp_raw).reshape(side, side))
                parallel_maps.append((q_def_parallel - q_fp_parallel).reshape(side, side))

            target_h = int(item["img"].shape[-2])
            target_w = int(item["img"].shape[-1])
            raw_map = torch.stack(raw_maps, dim=0).mean(dim=0, keepdim=True).unsqueeze(0)
            parallel_map = torch.stack(parallel_maps, dim=0).mean(dim=0, keepdim=True).unsqueeze(0)
            raw_map = F.interpolate(raw_map, size=(target_h, target_w), mode="bilinear", align_corners=False)[0, 0].cpu().numpy()
            parallel_map = (
                F.interpolate(parallel_map, size=(target_h, target_w), mode="bilinear", align_corners=False)[0, 0].cpu().numpy()
            )

            raw_score = topk_mean(raw_map, image_score_topk)
            parallel_score = topk_mean(parallel_map, image_score_topk)
            raw_peak = np.unravel_index(int(np.argmax(raw_map)), raw_map.shape)
            image_np = denormalize_image(item["img"])
            if anomaly_flag == 1:
                out["raw_anomaly"].append(raw_score)
                out["parallel_anomaly"].append(parallel_score)
                num_anomaly += 1
            else:
                out["raw_normal"].append(raw_score)
                out["parallel_normal"].append(parallel_score)
                num_normal += 1
            records.append(
                {
                    "idx": int(idx),
                    "anomaly": int(anomaly_flag),
                    "raw_score": float(raw_score),
                    "parallel_score": float(parallel_score),
                    "raw_peak_y": int(raw_peak[0]),
                    "raw_peak_x": int(raw_peak[1]),
                    "image_path": item.get("img_path", ""),
                    "cls_name": item.get("cls_name", ""),
                    "image": image_np,
                }
            )

            done = num_normal + num_anomaly
            if done % 16 == 0:
                print(
                    json.dumps(
                        {
                            "stage": "collect_progress",
                            "preset": preset,
                            "normal_done": num_normal,
                            "anomaly_done": num_anomaly,
                        }
                    ),
                    flush=True,
                )

    arrays = {key: np.asarray(vals, dtype=np.float32) for key, vals in out.items()}
    meta = {
        "preset": preset,
        "preset_label": PRESET_LABELS[preset],
        "checkpoint_path": str(ckpt_path),
        "source_root": str(source_root),
        "target_root": str(target_root),
        "source_dataset": source_dataset,
        "target_dataset": target_dataset,
        "bank_cache_path": str(bank_cache_path),
        "image_score_topk": image_score_topk,
        "tau": tau,
        "num_normal": int(arrays["raw_normal"].size),
        "num_anomaly": int(arrays["raw_anomaly"].size),
        "seed": int(seed),
    }
    return arrays, {"meta": meta, "records": records}


def plot_overlap_panel(
    ax,
    pos: np.ndarray,
    neg: np.ndarray,
    title: str,
    color_pos: str,
    color_neg: str,
    marker_values: tuple[float, float] | None = None,
) -> dict:
    centers, pos_hist, neg_hist, ovl = histogram_overlap(pos, neg, bins=60)
    pos_hist = smooth_histogram(pos_hist)
    neg_hist = smooth_histogram(neg_hist)
    overlap = np.minimum(pos_hist, neg_hist)
    dx = centers[1] - centers[0] if len(centers) > 1 else 1.0
    ovl = float(np.sum(overlap) * dx)
    auc = compute_auc(pos, neg)

    ax.fill_between(centers, pos_hist, color=color_pos, alpha=0.35, label="Anomaly-image top-k")
    ax.fill_between(centers, neg_hist, color=color_neg, alpha=0.35, label="Normal-image hard-FP top-k")
    ax.plot(centers, pos_hist, color=color_pos, lw=2.0)
    ax.plot(centers, neg_hist, color=color_neg, lw=2.0)
    ax.fill_between(
        centers,
        overlap,
        color="#7F7F7F",
        alpha=0.18,
        hatch="///",
        edgecolor="#555555",
        linewidth=0.0,
        label="Overlap",
    )
    if marker_values is not None:
        ax.axvline(marker_values[0], color=color_pos, lw=1.5, ls="--", alpha=0.9)
        ax.axvline(marker_values[1], color=color_neg, lw=1.5, ls="--", alpha=0.9)
    ax.set_title(title)
    ax.set_xlabel("Top-1% response score")
    ax.set_ylabel("Density")
    ax.grid(alpha=0.15)
    ax.text(
        0.03,
        0.97,
        f"AUC={auc:.3f}\nOVL={ovl:.3f}\nGap={pos.mean() - neg.mean():+.3f}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=10,
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.85},
    )
    return {
        "auc": auc,
        "overlap": ovl,
        "mean_gap": float(pos.mean() - neg.mean()),
        "overlap_peak_x": float(centers[int(np.argmax(overlap))]),
    }


def draw_example_row(ax_img, ax_crop, record: dict, border_color: str, label: str) -> None:
    image = record["image"]
    cy = record["raw_peak_y"]
    cx = record["raw_peak_x"]
    crop_size = 112
    ax_img.imshow(image)
    ax_img.add_patch(
        Rectangle(
            (cx - crop_size / 2, cy - crop_size / 2),
            crop_size,
            crop_size,
            fill=False,
            ec=border_color,
            lw=2.4,
        )
    )
    ax_img.set_title(
        f"{label}\nraw={record['raw_score']:.4f}, ours={record['parallel_score']:.4f}",
        fontsize=10,
    )
    ax_img.axis("off")

    crop = crop_from_center(image, cy, cx, crop_size=crop_size)
    ax_crop.imshow(crop)
    ax_crop.set_title(f"{record['cls_name']}", fontsize=10)
    ax_crop.axis("off")


def main() -> None:
    parser = argparse.ArgumentParser("Generate GT-free overlap figure for AnomalyCLIP baseline vs OURS")
    parser.add_argument("--preset", type=str, default="visa2mvtec", choices=list(DISCUSSION_SUMMARIES.keys()))
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--max_normal_images", type=int, default=128)
    parser.add_argument("--max_anomaly_images", type=int, default=128)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULTS / "anomalyclip_gtfree_overlap_figure"),
    )
    args = parser.parse_args()

    arrays, payload = collect_gtfree_topk_scores(
        preset=args.preset,
        device=args.device,
        max_normal_images=args.max_normal_images,
        max_anomaly_images=args.max_anomaly_images,
        seed=args.seed,
    )
    meta = payload["meta"]
    records = payload["records"]

    summary_rows = {}
    for preset, path in DISCUSSION_SUMMARIES.items():
        rows = load_json(path)["rows"]
        raw = next(row for row in rows if row["axis"] == "learned" and row["component"] == "raw")
        parallel = next(row for row in rows if row["axis"] == "learned" and row["component"] == "parallel")
        summary_rows[preset] = {
            "label": PRESET_LABELS[preset],
            "raw_image_auroc": float(raw["image_auroc"]),
            "parallel_image_auroc": float(parallel["image_auroc"]),
        }

    tmp_centers, tmp_pos_hist, tmp_neg_hist, _ = histogram_overlap(arrays["raw_anomaly"], arrays["raw_normal"], bins=60)
    tmp_overlap = np.minimum(smooth_histogram(tmp_pos_hist), smooth_histogram(tmp_neg_hist))
    overlap_center = float(tmp_centers[int(np.argmax(tmp_overlap))])
    example_anomaly, example_normal = select_example_pair(records, overlap_center)

    fig = plt.figure(figsize=(21.0, 5.8), constrained_layout=True)
    gs = fig.add_gridspec(1, 4, width_ratios=[1.15, 1.15, 0.96, 1.25])
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[0, 2])
    gs_ex = gs[0, 3].subgridspec(2, 2, width_ratios=[1.0, 0.92], hspace=0.12, wspace=0.08)
    ax3 = fig.add_subplot(gs_ex[0, 0])
    ax4 = fig.add_subplot(gs_ex[0, 1])
    ax5 = fig.add_subplot(gs_ex[1, 0])
    ax6 = fig.add_subplot(gs_ex[1, 1])

    baseline_stats = plot_overlap_panel(
        ax0,
        arrays["raw_anomaly"],
        arrays["raw_normal"],
        "Baseline: Raw Host Response",
        color_pos="#D95F02",
        color_neg="#7570B3",
        marker_values=(example_anomaly["raw_score"], example_normal["raw_score"]),
    )
    ours_stats = plot_overlap_panel(
        ax1,
        arrays["parallel_anomaly"],
        arrays["parallel_normal"],
        "OURS: Parallel Support Response",
        color_pos="#1B9E77",
        color_neg="#7570B3",
        marker_values=(example_anomaly["parallel_score"], example_normal["parallel_score"]),
    )
    handles, labels = ax1.get_legend_handles_labels()
    ax1.legend(handles[:3], labels[:3], frameon=False, loc="upper right")

    y = np.arange(len(summary_rows))
    raw_vals = [summary_rows[key]["raw_image_auroc"] for key in DISCUSSION_SUMMARIES]
    par_vals = [summary_rows[key]["parallel_image_auroc"] for key in DISCUSSION_SUMMARIES]
    for i, preset in enumerate(DISCUSSION_SUMMARIES):
        ax2.plot([raw_vals[i], par_vals[i]], [i, i], color="#9A9A9A", lw=1.8, zorder=1)
        ax2.scatter(raw_vals[i], i, s=62, color="#D95F02", zorder=2, label="Baseline" if i == 0 else None)
        ax2.scatter(par_vals[i], i, s=62, color="#1B9E77", zorder=2, label="OURS" if i == 0 else None)
        ax2.text(max(raw_vals[i], par_vals[i]) + 0.012, i, f"{par_vals[i] - raw_vals[i]:+.2f}", va="center", fontsize=10)
    ax2.set_yticks(y, [summary_rows[key]["label"] for key in DISCUSSION_SUMMARIES])
    ax2.set_xlim(0.0, 1.02)
    ax2.set_xlabel("AUC(Anomaly-image top-k > Normal-image top-k)")
    ax2.set_title("Preset-wise Separation Gain")
    ax2.grid(axis="x", alpha=0.15)
    ax2.legend(frameon=False, loc="lower right")

    draw_example_row(ax3, ax4, example_anomaly, "#D95F02", "Anomaly-image example")
    draw_example_row(ax5, ax6, example_normal, "#7570B3", "Hard-normal example")

    fig.suptitle(
        f"GT-free Hard-FP Entanglement View ({meta['preset_label']}, {meta['num_anomaly']} anomaly / {meta['num_normal']} normal)",
        fontsize=14,
    )

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(save_dir / f"{args.preset}_topk_arrays.npz", **arrays)
    payload = {
        "meta": meta,
        "baseline_stats": baseline_stats,
        "ours_stats": ours_stats,
        "preset_rows": summary_rows,
        "arrays_file": str(save_dir / f"{args.preset}_topk_arrays.npz"),
        "example_anomaly": {
            "image_path": example_anomaly["image_path"],
            "cls_name": example_anomaly["cls_name"],
            "raw_score": float(example_anomaly["raw_score"]),
            "parallel_score": float(example_anomaly["parallel_score"]),
        },
        "example_normal": {
            "image_path": example_normal["image_path"],
            "cls_name": example_normal["cls_name"],
            "raw_score": float(example_normal["raw_score"]),
            "parallel_score": float(example_normal["parallel_score"]),
        },
    }
    with open(save_dir / f"{args.preset}_gtfree_overlap.json", "w") as f:
        json.dump(payload, f, indent=2)
    png = save_dir / f"{args.preset}_gtfree_overlap.png"
    pdf = save_dir / f"{args.preset}_gtfree_overlap.pdf"
    fig.savefig(png, dpi=220, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print(json.dumps({"png": str(png), "pdf": str(pdf)}, indent=2))


if __name__ == "__main__":
    main()
