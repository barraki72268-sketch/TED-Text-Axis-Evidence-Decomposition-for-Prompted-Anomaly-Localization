#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = ROOT / "neurips2026" / "results" / "host_problem_solution_figure"


SUMMARY_FILES = [
    (
        "AA-CLIP\nMVTec -> VisA",
        ROOT / "neurips2026" / "results" / "candidate_entanglement_aaclip_mvtec2visa_v1" / "summary.json",
    ),
    (
        "AA-CLIP\nVisA -> MVTec",
        ROOT / "neurips2026" / "results" / "candidate_entanglement_aaclip_visa2mvtec_v1" / "summary.json",
    ),
    (
        "FAPrompt\nVisA -> MVTec",
        ROOT / "neurips2026" / "results" / "candidate_entanglement_faprompt_visa2mvtec_v1" / "summary.json",
    ),
    (
        "FAPrompt\nMVTec -> VisA",
        ROOT / "neurips2026" / "results" / "candidate_entanglement_faprompt_mvtec2visa_v1" / "summary.json",
    ),
]


INSERTION_FILES = [
    (
        "metal_nut",
        ROOT / "neurips2026" / "results" / "aaclip_insertion_zgrid_visa2mvtec_metalnut_top005_v1" / "summary.json",
    ),
    (
        "screw",
        ROOT / "neurips2026" / "results" / "aaclip_insertion_zgrid_visa2mvtec_screw_top005_v1" / "summary.json",
    ),
    (
        "pcb3",
        ROOT / "neurips2026" / "results" / "aaclip_insertion_zgrid_mvtec2visa_pcb3_top005_v1" / "summary.json",
    ),
    (
        "pcb1",
        ROOT / "neurips2026" / "results" / "aaclip_insertion_zgrid_mvtec2visa_pcb1_top005_v1" / "summary.json",
    ),
]

REAL_DISTRIBUTION_FILE = (
    ROOT
    / "neurips2026"
    / "results"
    / "candidate_score_arrays_faprompt_visa2mvtec_cable_v1"
    / "scores_cable.npz"
)

REAL_DISTRIBUTION_SUMMARY = (
    ROOT
    / "neurips2026"
    / "results"
    / "candidate_score_arrays_faprompt_visa2mvtec_cable_v1"
    / "summary.json"
)

REAL_DISTRIBUTION_LABEL = "actual FAPrompt cable candidate scores"


def add_box(ax, xy, wh, text, fc, ec="#20242a", fontsize=10, weight="bold"):
    box = FancyBboxPatch(
        xy,
        wh[0],
        wh[1],
        boxstyle="round,pad=0.035,rounding_size=0.055",
        linewidth=1.4,
        edgecolor=ec,
        facecolor=fc,
        transform=ax.transAxes,
        clip_on=False,
    )
    ax.add_patch(box)
    ax.text(
        xy[0] + wh[0] / 2,
        xy[1] + wh[1] / 2,
        text,
        ha="center",
        va="center",
        fontsize=fontsize,
        fontweight=weight,
        color="#171b20",
        transform=ax.transAxes,
    )


def add_arrow(ax, start, end, color="#20242a", rad=0.0):
    arrow = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=16,
        linewidth=1.6,
        color=color,
        connectionstyle=f"arc3,rad={rad}",
        transform=ax.transAxes,
        clip_on=False,
    )
    ax.add_patch(arrow)


def draw_flow_panel(ax):
    ax.axis("off")
    ax.text(
        0.02,
        0.95,
        "1. Changed insertion",
        fontsize=13,
        fontweight="bold",
        ha="left",
        va="top",
        transform=ax.transAxes,
    )
    ax.text(
        0.02,
        0.87,
        "Keep the host as a candidate proposer. Apply OURS only inside high-response local candidates.",
        fontsize=9,
        ha="left",
        va="top",
        color="#4b5563",
        transform=ax.transAxes,
    )
    add_box(ax, (0.04, 0.59), (0.25, 0.16), "host map\nproposal", "#d7e9ff", fontsize=9)
    add_box(ax, (0.37, 0.59), (0.25, 0.16), "top-response\ncandidate gate", "#fff3c4", fontsize=9)
    add_box(ax, (0.70, 0.59), (0.25, 0.16), "text-conditioned\nsupport residual", "#dff7df", fontsize=9)
    add_arrow(ax, (0.30, 0.67), (0.36, 0.67))
    add_arrow(ax, (0.63, 0.67), (0.69, 0.67))

    add_box(ax, (0.16, 0.29), (0.68, 0.13), "correct local ranking\nwithout replacing the detector", "#f1f5f9", fontsize=10)
    add_arrow(ax, (0.82, 0.59), (0.61, 0.43), rad=-0.15)
    add_arrow(ax, (0.50, 0.59), (0.50, 0.43))
    ax.text(
        0.05,
        0.10,
        r"$M' = z(M_{\mathrm{host}}) + \alpha\,G_{\mathrm{top}}(M_{\mathrm{host}})\,z(R_{\mathrm{ours}})$",
        fontsize=13,
        fontweight="bold",
        ha="left",
        va="bottom",
        color="#111827",
        transform=ax.transAxes,
    )


def draw_overlap_panel(ax):
    labels = []
    before = []
    after = []
    for label, path in SUMMARY_FILES:
        data = json.loads(path.read_text())["mean"]
        labels.append(label)
        before.append(data["baseline"]["overlap_iqr"])
        after.append(data["ours_residual"]["overlap_iqr"])
    x = np.arange(len(labels))
    width = 0.36
    ax.bar(x - width / 2, before, width, label="host candidates", color="#d14b3f")
    ax.bar(x + width / 2, after, width, label="after OURS residual", color="#2f9e66")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8, fontweight="bold")
    ax.set_ylabel("candidate overlap", fontsize=9, fontweight="bold")
    ax.set_title("2. Shared host failure: hard-FP/defect entanglement", fontsize=13, fontweight="bold", pad=8, loc="left")
    ax.grid(axis="y", alpha=0.24)
    ax.legend(frameon=False, fontsize=9, loc="upper right")
    for i, (b, a) in enumerate(zip(before, after)):
        ratio = b / max(a, 1e-6)
        ax.text(i, max(b, a) + max(before) * 0.035, f"{ratio:.1f}x lower", ha="center", va="bottom", fontsize=8, fontweight="bold")


def zscore_np(x):
    x = np.asarray(x, dtype=np.float32)
    return (x - x.mean()) / (x.std() + 1e-6)


def smooth_hist(values, bins):
    hist, edges = np.histogram(values, bins=bins, density=True)
    kernel = np.array([1, 2, 3, 4, 3, 2, 1], dtype=np.float32)
    kernel = kernel / kernel.sum()
    hist = np.convolve(hist, kernel, mode="same")
    centers = (edges[:-1] + edges[1:]) / 2
    return centers, hist


def draw_score_pair(ax, labels, scores, y_offset, title, stats, bins):
    score_z = zscore_np(scores)
    hard = score_z[labels == 0]
    defect = score_z[labels == 1]
    xh, yh = smooth_hist(hard, bins)
    xd, yd = smooth_hist(defect, bins)
    scale = 0.95 / max(float(yh.max()), float(yd.max()), 1e-6)
    yh = yh * scale + y_offset
    yd = yd * scale + y_offset
    ax.fill_between(xh, y_offset, yh, color="#ef7d6d", alpha=0.40)
    ax.fill_between(xd, y_offset, yd, color="#6aa6ff", alpha=0.40)
    ax.plot(xh, yh, color="#c92f28", linewidth=2.2)
    ax.plot(xd, yd, color="#226be0", linewidth=2.2)
    ax.axhline(y_offset, color="#374151", linewidth=0.9)
    ax.text(-3.15, y_offset + 0.78, title, fontsize=10, fontweight="bold", ha="left")
    ax.text(
        -3.15,
        y_offset + 0.55,
        f"AUC {stats['auc']:.2f}, AP {stats['ap']:.2f}, overlap {stats['overlap_iqr']:.2f}",
        fontsize=8.5,
        color="#4b5563",
        ha="left",
    )


def draw_distribution_panel(ax):
    data = np.load(REAL_DISTRIBUTION_FILE)
    summary = json.loads(REAL_DISTRIBUTION_SUMMARY.read_text())["mean"]
    labels = data["labels"].astype(np.int64)
    bins = np.linspace(-3.3, 3.3, 48)
    draw_score_pair(ax, labels, data["baseline"], 1.25, "host candidate score", summary["baseline"], bins)
    draw_score_pair(ax, labels, data["residual"], -0.15, "OURS residual score", summary["ours_residual"], bins)
    ax.set_title(f"3. Actual score distributions: {REAL_DISTRIBUTION_LABEL}", fontsize=13, fontweight="bold", pad=8, loc="left")
    ax.set_ylim(-0.22, 2.42)
    ax.set_xlim(-3.35, 3.35)
    ax.set_yticks([])
    ax.set_xlabel("z-normalized candidate score", fontsize=9, fontweight="bold")
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.legend(
        handles=[
            plt.Rectangle((0, 0), 1, 1, color="#ef7d6d", alpha=0.45, label="hard normal"),
            plt.Rectangle((0, 0), 1, 1, color="#6aa6ff", alpha=0.45, label="defect"),
        ],
        frameon=False,
        fontsize=9,
        loc="upper right",
    )


def draw_insertion_table(ax):
    ax.axis("off")
    rows = []
    for cls, path in INSERTION_FILES:
        data = json.loads(path.read_text())["mean"]
        base = data["baseline"]
        best_key, best = max(data["candidates"].items(), key=lambda kv: (kv[1]["pixel_ap"], kv[1]["pixel_auc"]))
        delta_ap = best["pixel_ap"] - base["pixel_ap"]
        delta_auc = best["pixel_auc"] - base["pixel_auc"]
        status = "helps" if delta_ap > 0 else "unsafe"
        rows.append([cls, f"{delta_auc:+.2f}", f"{delta_ap:+.2f}", status])
    ax.text(
        0.02,
        0.96,
        "4. AA-CLIP: insertion position matters",
        ha="left",
        va="top",
        fontsize=13,
        fontweight="bold",
        transform=ax.transAxes,
    )
    ax.text(
        0.02,
        0.88,
        "The same residual can help or hurt depending on host calibration.",
        ha="left",
        va="top",
        fontsize=9,
        color="#4b5563",
        transform=ax.transAxes,
    )
    col_labels = ["class", "local AUC\nshift", "local AP\nshift", "decision"]
    table = ax.table(
        cellText=rows,
        colLabels=col_labels,
        cellLoc="center",
        colLoc="center",
        bbox=[0.02, 0.08, 0.96, 0.70],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    for (r, c), cell in table.get_celld().items():
        cell.set_linewidth(0.8)
        cell.set_edgecolor("#d1d5db")
        if r == 0:
            cell.set_facecolor("#111827")
            cell.set_text_props(color="white", fontweight="bold")
        elif c == 3:
            text = cell.get_text().get_text()
            cell.set_facecolor("#dcfce7" if text == "helps" else "#fee2e2")
            cell.set_text_props(fontweight="bold", color="#14532d" if text == "helps" else "#991b1b")
        elif r % 2 == 0:
            cell.set_facecolor("#f8fafc")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.facecolor": "white",
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )
    fig = plt.figure(figsize=(15.0, 9.0), constrained_layout=True)
    gs = fig.add_gridspec(2, 2, width_ratios=[1.05, 1.05], height_ratios=[1.0, 1.0])
    draw_flow_panel(fig.add_subplot(gs[0, 0]))
    draw_overlap_panel(fig.add_subplot(gs[0, 1]))
    draw_distribution_panel(fig.add_subplot(gs[1, 0]))
    draw_insertion_table(fig.add_subplot(gs[1, 1]))
    fig.savefig(OUT_DIR / "host_problem_solution_story.png", dpi=240, bbox_inches="tight")
    fig.savefig(OUT_DIR / "host_problem_solution_story.pdf", bbox_inches="tight")
    print(OUT_DIR / "host_problem_solution_story.png")
    print(OUT_DIR / "host_problem_solution_story.pdf")


if __name__ == "__main__":
    main()
