from __future__ import annotations

import argparse
import csv
import gc
import json
import os
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import roc_auc_score

from official_parallel_test_adaptclip import build_dataset, build_model, compute_baseline_outputs, resize_map, smooth_map


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"
VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"
MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"


def validate_visa_root(root: str, dataset_name: str) -> None:
    if dataset_name.lower() != "visa":
        return
    resolved = Path(root).resolve()
    official = OFFICIAL_VISA_ROOT.resolve()
    if resolved != official:
        raise ValueError(f"VisA experiments must use the official root only: {official}. Got: {resolved}")


def resolve_preset(args) -> None:
    if args.preset is None:
        return
    if args.preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtec"
    elif args.preset == "mvtec2visa":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif args.preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif args.preset == "mvtec2btad":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {args.preset}")


def current_rss_mb() -> float:
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    parts = line.split()
                    if len(parts) >= 2:
                        return float(parts[1]) / 1024.0
    except OSError:
        pass
    return float("nan")


def cleanup_image_state(device: str) -> None:
    gc.collect()
    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()


def mean_ignoring_nan(values: list[float]) -> float:
    vals = [v for v in values if np.isfinite(v)]
    if not vals:
        return float("nan")
    return float(np.mean(vals))


def safe_corr(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float32).reshape(-1)
    y = np.asarray(b, dtype=np.float32).reshape(-1)
    if x.size < 2 or y.size < 2:
        return float("nan")
    sx = float(np.std(x))
    sy = float(np.std(y))
    if sx < 1e-12 or sy < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def top_fraction_mask(score_map: np.ndarray, frac: float) -> np.ndarray:
    flat = score_map.reshape(-1)
    k = max(1, int(np.ceil(flat.size * frac)))
    thresh = np.partition(flat, -k)[-k]
    return score_map >= thresh


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    inter = float(np.logical_and(a, b).sum())
    union = float(np.logical_or(a, b).sum())
    if union <= 0:
        return float("nan")
    return inter / union


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def append_partial_row(save_dir: Path, row: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.jsonl", "a") as f:
        f.write(json.dumps(row) + "\n")


def write_progress(save_dir: Path, payload: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "progress.json", "w") as f:
        json.dump(payload, f, indent=2)


def save_outputs(summary: dict, rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser("Branch dominance audit for AdaptCLIP baseline localization")
    parser.add_argument("--preset", type=str, default=None, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=1)
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--fusion_type", type=str, default="average_mean")
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--progress_every", type=int, default=1)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_branch_dominance"),
    )
    args = parser.parse_args()

    resolve_preset(args)
    validate_visa_root(args.target_root, args.target_dataset)
    save_dir = Path(args.save_dir)

    model, textual_learner, visual_learner, learned_text_features, dpam_layer = build_model(
        args.device,
        args.checkpoint_path,
        args.image_size,
        args.n_ctx,
        args.vl_reduction,
        args.pretrained_model,
    )
    print(json.dumps({"event": "stage", "name": "model_ready", "pid": os.getpid(), "rss_mb": round(current_rss_mb(), 2)}), flush=True)

    write_progress(
        save_dir,
        {
            "event": "start",
            "pid": os.getpid(),
            "preset": args.preset,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "max_anomaly_images_per_class": args.max_anomaly_images_per_class,
            "rss_mb": round(current_rss_mb(), 2),
        },
    )

    dataset = build_dataset(args.target_root, args.image_size, args.target_dataset, "test", str(save_dir), class_name=None)
    print(json.dumps({"event": "stage", "name": "dataset_ready", "pid": os.getpid(), "rss_mb": round(current_rss_mb(), 2)}), flush=True)
    target_classes = set(args.target_classes) if args.target_classes else set(dataset.obj_list)

    loader_kwargs = {"batch_size": 1, "shuffle": False, "num_workers": args.num_workers}
    if args.num_workers > 0:
        loader_kwargs["pin_memory"] = args.device.startswith("cuda")
        loader_kwargs["persistent_workers"] = True
        loader_kwargs["prefetch_factor"] = 2
    loader = torch.utils.data.DataLoader(dataset, **loader_kwargs)

    rows: list[dict] = []
    per_class_seen = {cls: 0 for cls in dataset.obj_list}
    target_class_list = sorted(target_classes)

    with torch.no_grad():
        for idx, items in enumerate(loader):
            if all(per_class_seen.get(cls, 0) >= args.max_anomaly_images_per_class for cls in target_class_list):
                break
            cls_name = items["cls_name"][0]
            if cls_name not in target_classes:
                continue
            anomaly_flag = int(items["anomaly"].item())
            if anomaly_flag == 0:
                continue
            if per_class_seen[cls_name] >= args.max_anomaly_images_per_class:
                continue
            per_class_seen[cls_name] += 1

            if args.progress_every > 0:
                print(json.dumps({"event": "image_start", "pid": os.getpid(), "dataset_index": idx, "class_name": cls_name, "rows_done": len(rows), "rss_mb": round(current_rss_mb(), 2)}), flush=True)

            image = items["img"].to(args.device)
            mask_tensor = items["img_mask"][:, 0]
            gt_mask = mask_tensor.squeeze().detach().cpu().numpy() > 0.5
            if not gt_mask.any():
                continue

            baseline = compute_baseline_outputs(
                model,
                textual_learner,
                visual_learner,
                learned_text_features,
                image,
                args.features_list,
                dpam_layer,
                args.image_size,
                args.sigma,
                args.fusion_type,
            )

            fused_map = baseline["baseline_map"].detach().cpu().numpy()[0]
            vl_map = resize_map(smooth_map(baseline["local_vl_map"], sigma=args.sigma).to(args.device), args.image_size).detach().cpu().numpy()[0]
            tl_map = resize_map(smooth_map(baseline["local_tl_map"], sigma=args.sigma).to(args.device), args.image_size).detach().cpu().numpy()[0]

            fused_mask = top_fraction_mask(fused_map, args.map_topk)
            vl_mask = top_fraction_mask(vl_map, args.map_topk)
            tl_mask = top_fraction_mask(tl_map, args.map_topk)

            row = {
                "image_id": int(idx),
                "class_name": cls_name,
                "fused_vs_vl_corr": safe_corr(fused_map, vl_map),
                "fused_vs_tl_corr": safe_corr(fused_map, tl_map),
                "fused_vs_vl_topk_overlap": mask_overlap(fused_mask, vl_mask),
                "fused_vs_tl_topk_overlap": mask_overlap(fused_mask, tl_mask),
                "fused_vs_vl_topk_iou": mask_iou(fused_mask, vl_mask),
                "fused_vs_tl_topk_iou": mask_iou(fused_mask, tl_mask),
                "fused_local_auc": safe_auc(fused_map[gt_mask], fused_map[~gt_mask]),
                "vl_local_auc": safe_auc(vl_map[gt_mask], vl_map[~gt_mask]),
                "tl_local_auc": safe_auc(tl_map[gt_mask], tl_map[~gt_mask]),
                "corr_gap_vl_minus_tl": safe_corr(fused_map, vl_map) - safe_corr(fused_map, tl_map),
                "overlap_gap_vl_minus_tl": mask_overlap(fused_mask, vl_mask) - mask_overlap(fused_mask, tl_mask),
            }
            rows.append(row)
            append_partial_row(save_dir, row)
            write_progress(
                save_dir,
                {
                    "event": "row_saved",
                    "pid": os.getpid(),
                    "dataset_index": int(idx),
                    "rows_done": len(rows),
                    "class_name": cls_name,
                    "rss_mb": round(current_rss_mb(), 2),
                },
            )
            if args.progress_every > 0 and (len(rows) % args.progress_every == 0):
                print(json.dumps({"event": "image_done", "pid": os.getpid(), "dataset_index": int(idx), "rows_done": len(rows), "class_name": cls_name, "rss_mb": round(current_rss_mb(), 2)}), flush=True)

            del image, baseline
            cleanup_image_state(args.device)

    summary = {
        "settings": {
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "target_classes": sorted(target_classes),
            "features_list": args.features_list,
            "image_size": args.image_size,
            "sigma": args.sigma,
            "fusion_type": args.fusion_type,
            "map_topk": args.map_topk,
        },
        "summary": {
            "num_images": len(rows),
            "mean_fused_vs_vl_corr": mean_ignoring_nan([r["fused_vs_vl_corr"] for r in rows]),
            "mean_fused_vs_tl_corr": mean_ignoring_nan([r["fused_vs_tl_corr"] for r in rows]),
            "mean_fused_vs_vl_topk_overlap": mean_ignoring_nan([r["fused_vs_vl_topk_overlap"] for r in rows]),
            "mean_fused_vs_tl_topk_overlap": mean_ignoring_nan([r["fused_vs_tl_topk_overlap"] for r in rows]),
            "mean_fused_vs_vl_topk_iou": mean_ignoring_nan([r["fused_vs_vl_topk_iou"] for r in rows]),
            "mean_fused_vs_tl_topk_iou": mean_ignoring_nan([r["fused_vs_tl_topk_iou"] for r in rows]),
            "mean_fused_local_auc": mean_ignoring_nan([r["fused_local_auc"] for r in rows]),
            "mean_vl_local_auc": mean_ignoring_nan([r["vl_local_auc"] for r in rows]),
            "mean_tl_local_auc": mean_ignoring_nan([r["tl_local_auc"] for r in rows]),
            "mean_corr_gap_vl_minus_tl": mean_ignoring_nan([r["corr_gap_vl_minus_tl"] for r in rows]),
            "mean_overlap_gap_vl_minus_tl": mean_ignoring_nan([r["overlap_gap_vl_minus_tl"] for r in rows]),
        },
    }
    save_outputs(summary, rows, save_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
