#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AA_ROOT = ROOT / "neurips2026" / "AA-CLIP"
OFFICIAL = ROOT / "neurips2026" / "scripts" / "official_parallel_test_aaclip.py"
SOURCE_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
TARGET_ROOT = str(ROOT / "neurips2026/results/rawvlm_mvtec2_20260503/mvtec_ad2_meta_view")
CKPT_DIR = "/mnt/data/pilab-kingjinyoung/ADPretrain/results/aaclip_ckpt/mvtec_fullshot"


def _load_official_module():
    spec = importlib.util.spec_from_file_location("official_parallel_test_aaclip_mvtec2", OFFICIAL)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load {OFFICIAL}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _patch_aaclip_constants(class_names: list[str]) -> None:
    if str(AA_ROOT) not in sys.path:
        sys.path.insert(0, str(AA_ROOT))
    from dataset import constants

    real_names = {
        name: {
            "fruit_jelly": "fruit jelly",
            "sheet_metal": "sheet metal",
            "wallplugs": "wall plugs",
        }.get(name, name.replace("_", " "))
        for name in class_names
    }
    constants.CLASS_NAMES["MVTec2"] = class_names
    constants.DOMAINS["MVTec2"] = "Industrial"
    constants.REAL_NAMES["MVTec2"] = real_names

    # forward_utils imports these dictionaries by value at module import time.
    # Patch it as well if another import already materialized the module.
    if "forward_utils" in sys.modules:
        sys.modules["forward_utils"].CLASS_NAMES["MVTec2"] = class_names
        sys.modules["forward_utils"].REAL_NAMES["MVTec2"] = real_names


def main() -> int:
    import json

    meta = json.loads((Path(TARGET_ROOT) / "meta.json").read_text(encoding="utf-8"))
    class_names = sorted(meta["test"].keys())
    _patch_aaclip_constants(class_names)

    official = _load_official_module()
    official.PRESET_CONFIGS["mvtec2mvtec2"] = {
        "source_dataset": "MVTec",
        "target_dataset": "MVTec2",
        "source_root": SOURCE_ROOT,
        "target_root": TARGET_ROOT,
        "ckpt_dir": CKPT_DIR,
    }

    sys.argv = [str(OFFICIAL), "--preset", "mvtec2mvtec2", *sys.argv[1:]]
    return int(official.main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())
