#!/usr/bin/env python3
"""Collect source-bank visual patch examples for the TED method figure.

The saved source-bank tensors used by the experiments do not retain image
paths/patch coordinates. This script reconstructs visually faithful examples
from the same source split: defect examples are cropped around source anomaly
masks, while hard-normal examples are cropped from source train-normal images
at high edge/contrast locations.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageOps


DEFAULT_CLASSES = ["cable", "capsule", "metal_nut", "tile", "wood"]


def read_rgb(path: Path) -> Image.Image:
    return Image.open(path).convert("RGB")


def read_mask(path: Path) -> np.ndarray:
    mask = Image.open(path).convert("L")
    return np.asarray(mask) > 0


def clamp_crop_box(cx: float, cy: float, size: int, w: int, h: int) -> tuple[int, int, int, int]:
    half = size // 2
    left = int(round(cx)) - half
    top = int(round(cy)) - half
    left = max(0, min(left, max(0, w - size)))
    top = max(0, min(top, max(0, h - size)))
    right = min(w, left + size)
    bottom = min(h, top + size)
    if right - left < size:
        left = max(0, right - size)
    if bottom - top < size:
        top = max(0, bottom - size)
    return left, top, right, bottom


def crop_square(img: Image.Image, cx: float, cy: float, crop_size: int, out_size: int) -> tuple[Image.Image, tuple[int, int, int, int]]:
    w, h = img.size
    box = clamp_crop_box(cx, cy, crop_size, w, h)
    crop = img.crop(box)
    crop = ImageOps.contain(crop, (out_size, out_size), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (out_size, out_size), (255, 255, 255))
    canvas.paste(crop, ((out_size - crop.width) // 2, (out_size - crop.height) // 2))
    return canvas, box


def add_border(img: Image.Image, color: tuple[int, int, int]) -> Image.Image:
    out = img.copy()
    draw = ImageDraw.Draw(out)
    for i in range(3):
        draw.rectangle([i, i, out.width - 1 - i, out.height - 1 - i], outline=color)
    return out


def choose_defect_entry(root: Path, meta: dict, class_name: str) -> tuple[dict, np.ndarray]:
    entries = [x for x in meta["test"][class_name] if int(x.get("anomaly", 0)) == 1 and x.get("mask_path")]
    scored: list[tuple[int, dict, np.ndarray]] = []
    for entry in entries:
        mask_path = root / entry["mask_path"]
        if not mask_path.exists():
            continue
        mask = read_mask(mask_path)
        area = int(mask.sum())
        if area > 0:
            scored.append((area, entry, mask))
    if not scored:
        raise RuntimeError(f"No anomaly mask found for class {class_name}")
    scored.sort(key=lambda x: x[0], reverse=True)
    _, entry, mask = scored[0]
    return entry, mask


def defect_center(mask: np.ndarray) -> tuple[float, float]:
    ys, xs = np.nonzero(mask)
    if xs.size == 0:
        return mask.shape[1] / 2.0, mask.shape[0] / 2.0
    return float(xs.mean()), float(ys.mean())


def edge_contrast_score(gray: np.ndarray) -> np.ndarray:
    gray = gray.astype(np.float32) / 255.0
    gx = np.zeros_like(gray)
    gy = np.zeros_like(gray)
    gx[:, 1:-1] = gray[:, 2:] - gray[:, :-2]
    gy[1:-1, :] = gray[2:, :] - gray[:-2, :]
    return np.sqrt(gx * gx + gy * gy) + 0.35 * np.abs(gray - gray.mean())


def choose_hard_normal_crop(root: Path, meta: dict, class_name: str, crop_size: int, used_paths: set[str]) -> tuple[dict, tuple[float, float]]:
    entries = [x for x in meta["train"][class_name] if int(x.get("anomaly", 0)) == 0]
    best: tuple[float, dict, tuple[float, float]] | None = None
    for entry in entries[: min(len(entries), 40)]:
        img_path = root / entry["img_path"]
        if not img_path.exists():
            continue
        img = read_rgb(img_path)
        gray = np.asarray(img.convert("L"))
        score = edge_contrast_score(gray)
        h, w = score.shape
        step = max(16, crop_size // 4)
        margin = crop_size // 2
        for cy in range(margin, max(margin + 1, h - margin), step):
            for cx in range(margin, max(margin + 1, w - margin), step):
                patch = score[max(0, cy - margin) : min(h, cy + margin), max(0, cx - margin) : min(w, cx + margin)]
                if patch.size == 0:
                    continue
                # Penalize crops that are mostly blank or saturated.
                raw = gray[max(0, cy - margin) : min(h, cy + margin), max(0, cx - margin) : min(w, cx + margin)]
                saturation_penalty = float(((raw < 5) | (raw > 250)).mean())
                val = float(patch.mean() + 0.15 * patch.std() - 0.25 * saturation_penalty)
                key = f"{entry['img_path']}:{cx}:{cy}"
                if key in used_paths:
                    continue
                if best is None or val > best[0]:
                    best = (val, entry, (float(cx), float(cy)))
    if best is None:
        raise RuntimeError(f"No normal crop candidate found for class {class_name}")
    used_paths.add(f"{best[1]['img_path']}:{int(best[2][0])}:{int(best[2][1])}")
    return best[1], best[2]


def make_contact_sheet(items: list[Path], title: str, out_path: Path, tile: int = 128) -> None:
    pad = 10
    label_h = 26
    w = len(items) * tile + (len(items) + 1) * pad
    h = tile + label_h + 2 * pad
    sheet = Image.new("RGB", (w, h), (255, 255, 255))
    draw = ImageDraw.Draw(sheet)
    draw.text((pad, 4), title, fill=(20, 20, 20))
    for i, path in enumerate(items):
        img = read_rgb(path).resize((tile, tile), Image.Resampling.LANCZOS)
        x = pad + i * (tile + pad)
        y = pad + label_h
        sheet.paste(img, (x, y))
        draw.text((x + 4, y + 4), f"{i + 1}", fill=(20, 20, 20))
    sheet.save(out_path)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source_root", default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    ap.add_argument("--out_dir", default="figure/method_figure/source_bank_examples")
    ap.add_argument("--classes", nargs="+", default=DEFAULT_CLASSES)
    ap.add_argument("--crop_size", type=int, default=128)
    ap.add_argument("--out_size", type=int, default=160)
    args = ap.parse_args()

    source_root = Path(args.source_root)
    out_dir = Path(args.out_dir)
    defect_dir = out_dir / "defect_bank"
    fp_dir = out_dir / "fp_bank"
    defect_dir.mkdir(parents=True, exist_ok=True)
    fp_dir.mkdir(parents=True, exist_ok=True)

    meta = json.loads((source_root / "meta.json").read_text(encoding="utf-8"))
    manifest: dict[str, list[dict]] = {"defect_bank": [], "fp_bank": []}
    defect_paths: list[Path] = []
    fp_paths: list[Path] = []
    used_fp: set[str] = set()

    for idx, class_name in enumerate(args.classes, start=1):
        defect_entry, mask = choose_defect_entry(source_root, meta, class_name)
        defect_img = read_rgb(source_root / defect_entry["img_path"])
        dcx, dcy = defect_center(mask)
        defect_crop, defect_box = crop_square(defect_img, dcx, dcy, args.crop_size, args.out_size)
        defect_crop = add_border(defect_crop, (205, 38, 38))
        defect_out = defect_dir / f"defect_{idx:02d}_{class_name}_{Path(defect_entry['img_path']).stem}.png"
        defect_crop.save(defect_out)
        defect_paths.append(defect_out)
        manifest["defect_bank"].append(
            {
                "file": str(defect_out),
                "source_image": str(source_root / defect_entry["img_path"]),
                "source_mask": str(source_root / defect_entry["mask_path"]),
                "class_name": class_name,
                "crop_box_xyxy": list(defect_box),
                "selection": "source anomaly mask centroid",
            }
        )

        fp_entry, (fcx, fcy) = choose_hard_normal_crop(source_root, meta, class_name, args.crop_size, used_fp)
        fp_img = read_rgb(source_root / fp_entry["img_path"])
        fp_crop, fp_box = crop_square(fp_img, fcx, fcy, args.crop_size, args.out_size)
        fp_crop = add_border(fp_crop, (32, 96, 196))
        fp_out = fp_dir / f"fp_{idx:02d}_{class_name}_{Path(fp_entry['img_path']).stem}.png"
        fp_crop.save(fp_out)
        fp_paths.append(fp_out)
        manifest["fp_bank"].append(
            {
                "file": str(fp_out),
                "source_image": str(source_root / fp_entry["img_path"]),
                "class_name": class_name,
                "crop_box_xyxy": list(fp_box),
                "selection": "source train-normal high edge/contrast hard-normal candidate",
            }
        )

    make_contact_sheet(defect_paths, "Source defect evidence examples", out_dir / "defect_bank_contact_sheet.png", tile=args.out_size)
    make_contact_sheet(fp_paths, "Source hard-normal / FP evidence examples", out_dir / "fp_bank_contact_sheet.png", tile=args.out_size)
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"out_dir": str(out_dir), "num_defect": len(defect_paths), "num_fp": len(fp_paths)}, indent=2))


if __name__ == "__main__":
    main()
