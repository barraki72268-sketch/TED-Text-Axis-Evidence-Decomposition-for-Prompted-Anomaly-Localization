from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADAPT_ROOT = ROOT / "neurips2026" / "AdaptCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ADAPT_ROOT) not in sys.path:
    sys.path.insert(0, str(ADAPT_ROOT))

import adaptcliplib  # noqa: E402
from adaptcliplib import TextualAdapter, VisualAdapter, fusion_fun  # noqa: E402
from common_map_group_separability import (  # noqa: E402
    best_component_stats,
    plot_hist,
    save_summary,
    summarize_groups,
    top_fraction_mask,
    topk_mean_masked,
)
from dataset import Dataset  # noqa: E402
from tools import get_transform  # noqa: E402


def main():
    parser = argparse.ArgumentParser("Collect Normal / Hard FP / True Defect separability for AdaptCLIP")
    parser.add_argument("--test_data_path", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(
            ROOT
            / "neurips2026"
            / "results"
            / "adaptclip_official_vitl336_mvtec2visa_seed10"
            / "checkpoints"
            / "epoch_15.pth"
        ),
    )
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_points", type=int, default=200000)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_map_separability_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = args.device
    model, _ = adaptcliplib.load(args.pretrained_model, device=device)
    model.visual.DAPM_replace(DPAM_layer=20)
    patch_size = 14
    input_dim = 768
    DPAM_layer = 20

    preprocess, target_transform = get_transform(image_size=args.image_size)
    test_data = Dataset(
        root=args.test_data_path,
        transform=preprocess,
        target_transform=target_transform,
        dataset_name=args.dataset,
        k_shots=0,
        save_dir=args.save_dir,
        mode="test",
        seed=10,
    )
    test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size, shuffle=False, num_workers=0)

    textual_learner = TextualAdapter(model.to("cpu"), args.image_size, args.n_ctx)
    visual_learner = VisualAdapter(args.image_size, patch_size, input_dim, args.vl_reduction)

    checkpoint = torch.load(args.checkpoint_path, map_location="cpu")
    textual_learner.load_state_dict(checkpoint["textual_learner"])
    visual_learner.load_state_dict(checkpoint["visual_learner"])
    textual_learner.to(device)
    visual_learner.to(device)
    model.to(device)
    model.eval()
    textual_learner.eval()
    visual_learner.eval()

    textual_learner.prepare_static_text_feature(model)
    prompt_text, token_text = textual_learner.forward()
    learned_text_features = model.encode_text_learn(prompt_text, token_text, None)
    learned_text_features = learned_text_features / learned_text_features.norm(dim=-1, keepdim=True)

    groups = {"normal": [], "hard_fp": [], "true_defect": [], "outside": []}
    matched = {
        "hard_fp_topk": [],
        "true_defect_topk": [],
        "outside_topk": [],
        "hard_fp_comp_peak": [],
        "hard_fp_comp_mean": [],
        "hard_fp_comp_area": [],
        "true_defect_comp_peak": [],
        "true_defect_comp_mean": [],
        "true_defect_comp_area": [],
        "outside_comp_peak": [],
        "outside_comp_mean": [],
        "outside_comp_area": [],
    }

    print(
        json.dumps(
            {
                "stage": "map_separability_start",
                "num_images": len(test_data),
                "hard_frac": args.hard_frac,
                "checkpoint_path": args.checkpoint_path,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(test_dataloader, start=1):
            query_image = items["img"].to(device)
            cls_name = items["cls_name"]
            gt_mask = items["img_mask"][:, 0]
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask = gt_mask[0].cpu().numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            query_feats, query_patch_feats = model.encode_image(query_image, args.features_list, DPAM_layer=DPAM_layer)
            global_vl_logit, local_vl_map = visual_learner(query_feats, query_patch_feats, textual_learner.static_text_features)
            local_vl_map = local_vl_map[:, 1].detach()
            global_tl_logit, local_tl_map = textual_learner.compute_global_local_score(query_feats, query_patch_feats, learned_text_features)
            local_tl_map = local_tl_map[:, 1].detach()

            pixel_anomaly_map = fusion_fun([local_vl_map, local_tl_map], fusion_type="average_mean")
            pixel_anomaly_map = torch.stack(
                [torch.from_numpy(gaussian_filter(i, sigma=args.sigma)) for i in pixel_anomaly_map.cpu()],
                dim=0,
            )
            anomaly_map = pixel_anomaly_map[0].numpy()
            score_mask = top_fraction_mask(anomaly_map, args.hard_frac)

            if is_anomaly and gt_mask.any():
                groups["true_defect"].append(anomaly_map[gt_mask].reshape(-1))
                groups["outside"].append(anomaly_map[~gt_mask].reshape(-1))
                matched["true_defect_topk"].append(topk_mean_masked(anomaly_map, gt_mask, args.hard_frac))
                matched["outside_topk"].append(topk_mean_masked(anomaly_map, ~gt_mask, args.hard_frac))
                defect_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="inside")
                outside_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="outside")
                if defect_comp is not None:
                    matched["true_defect_comp_peak"].append(defect_comp["peak"])
                    matched["true_defect_comp_mean"].append(defect_comp["mean"])
                    matched["true_defect_comp_area"].append(defect_comp["area"])
                if outside_comp is not None:
                    matched["outside_comp_peak"].append(outside_comp["peak"])
                    matched["outside_comp_mean"].append(outside_comp["mean"])
                    matched["outside_comp_area"].append(outside_comp["area"])
            else:
                hard_mask = score_mask
                groups["hard_fp"].append(anomaly_map[hard_mask].reshape(-1))
                groups["normal"].append(anomaly_map[~hard_mask].reshape(-1))
                matched["hard_fp_topk"].append(float(anomaly_map[hard_mask].mean()))
                hard_comp = best_component_stats(anomaly_map, score_mask)
                if hard_comp is not None:
                    matched["hard_fp_comp_peak"].append(hard_comp["peak"])
                    matched["hard_fp_comp_mean"].append(hard_comp["mean"])
                    matched["hard_fp_comp_area"].append(hard_comp["area"])

            if img_idx % 64 == 0 or img_idx == len(test_data):
                print(
                    json.dumps(
                        {
                            "stage": "map_separability_progress",
                            "images_done": img_idx,
                            "images_total": len(test_data),
                        }
                    ),
                    flush=True,
                )

    groups_np = {}
    for key, chunks in groups.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        if vals.size > args.max_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(vals.size, size=args.max_points, replace=False)
            vals = vals[idx]
        groups_np[key] = vals.astype(np.float32, copy=False)

    summary = {
        "host": "AdaptCLIP",
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "num_images": len(test_data),
        "summary": summarize_groups(groups_np, max_summary_points=args.max_points),
    }
    matched_np = {
        key: np.asarray([v for v in vals if np.isfinite(v)], dtype=np.float32)
        for key, vals in matched.items()
    }
    summary["matched_summary"] = summarize_groups(
        matched_np,
        max_summary_points=args.max_points,
        pairs=[
            ("true_defect_topk", "hard_fp_topk"),
            ("true_defect_topk", "outside_topk"),
            ("true_defect_comp_peak", "hard_fp_comp_peak"),
            ("true_defect_comp_peak", "outside_comp_peak"),
            ("true_defect_comp_mean", "hard_fp_comp_mean"),
            ("true_defect_comp_mean", "outside_comp_mean"),
        ],
    )
    save_dir = Path(args.save_dir)
    save_summary(summary, save_dir)
    plot_hist(groups_np, save_dir / "hist.png", "AdaptCLIP Map Separability")
    plot_hist(
        {
            "hard_fp_topk": matched_np["hard_fp_topk"],
            "true_defect_topk": matched_np["true_defect_topk"],
            "outside_topk": matched_np["outside_topk"],
        },
        save_dir / "matched_topk_hist.png",
        "AdaptCLIP Matched Top-k Separability",
    )
    plot_hist(
        {
            "hard_fp_comp_peak": matched_np["hard_fp_comp_peak"],
            "true_defect_comp_peak": matched_np["true_defect_comp_peak"],
            "outside_comp_peak": matched_np["outside_comp_peak"],
        },
        save_dir / "matched_component_peak_hist.png",
        "AdaptCLIP Component Peak Separability",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
