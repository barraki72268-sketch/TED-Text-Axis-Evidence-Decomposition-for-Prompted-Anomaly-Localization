from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import open_clip
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.models.clip import ClipModel
from neurips2026.patchcore_adapters.visa_dataset import VisAOneClassDataset
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts


CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--backbone", type=str, default="clip-large-336", choices=["clip-large", "clip-large-336"])
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=336)
    parser.add_argument("--imagesize", type=int, default=336)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--pca_rank", type=int, default=1)
    parser.add_argument("--tau_quantile", type=float, default=0.8)
    parser.add_argument("--self_exclude_radius", type=int, default=1)
    parser.add_argument("--match_cos_thresh", type=float, default=0.25)
    parser.add_argument("--ransac_iters", type=int, default=64)
    parser.add_argument("--ransac_thresh", type=float, default=0.15)
    parser.add_argument("--max_normals", type=int, default=20)
    parser.add_argument("--max_anomalies", type=int, default=20)
    parser.add_argument("--pairwise_sample", type=int, default=1024)
    parser.add_argument("--vis_layer", type=int, default=12)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--output_dir", type=str, default="neurips2026/results")
    parser.add_argument("--output_tag", type=str, default="clip_nullspace_probe")
    return parser.parse_args()


def patch_coords(side: int, device: torch.device) -> torch.Tensor:
    yy, xx = torch.meshgrid(
        torch.arange(side, device=device),
        torch.arange(side, device=device),
        indexing="ij",
    )
    return torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=-1).float()


def normalize_coords(coords: torch.Tensor, side: int) -> torch.Tensor:
    out = coords.clone()
    out[:, 0] = (out[:, 0] / max(side - 1, 1)) * 2.0 - 1.0
    out[:, 1] = (out[:, 1] / max(side - 1, 1)) * 2.0 - 1.0
    return out


def local_mean_tokens(tokens: torch.Tensor, side: int, kernel_size: int) -> torch.Tensor:
    feat = tokens.view(side, side, -1).permute(2, 0, 1).unsqueeze(0)
    unfolded = F.unfold(feat, kernel_size=kernel_size, padding=kernel_size // 2)
    d = feat.shape[1]
    k2 = kernel_size * kernel_size
    unfolded = unfolded.view(1, d, k2, side * side)
    return unfolded.mean(dim=2).squeeze(0).T


def local_pca_residual(tokens: torch.Tensor, side: int, kernel_size: int, rank: int) -> torch.Tensor:
    feat = tokens.view(side, side, -1).permute(2, 0, 1).unsqueeze(0)
    d = feat.shape[1]
    k2 = kernel_size * kernel_size
    unfolded = F.unfold(feat, kernel_size=kernel_size, padding=kernel_size // 2)
    unfolded = unfolded.view(1, d, k2, side * side).permute(0, 3, 1, 2).squeeze(0)
    mu = unfolded.mean(dim=-1)
    centered = unfolded - mu.unsqueeze(-1)
    u, _, _ = torch.linalg.svd(centered, full_matrices=False)
    r = min(rank, u.shape[-1])
    u_r = u[:, :, :r]
    f_diff = tokens - mu
    coeff = torch.bmm(u_r.transpose(1, 2), f_diff.unsqueeze(-1))
    proj = torch.bmm(u_r, coeff).squeeze(-1)
    return torch.norm(f_diff - proj, dim=-1).pow(2)


def build_self_similarity(tokens: torch.Tensor, fg_mask: torch.Tensor, side: int, radius: int) -> torch.Tensor:
    sims = F.normalize(tokens, dim=-1) @ F.normalize(tokens, dim=-1).T
    coords = patch_coords(side, sims.device)
    diff = coords[:, None, :] - coords[None, :, :]
    local = diff.abs().amax(dim=-1) <= radius
    valid = fg_mask[:, None] & fg_mask[None, :]
    sims = sims.masked_fill(~valid, float("-inf"))
    sims = sims.masked_fill(local, float("-inf"))
    return sims


def solve_affine(src_pts: torch.Tensor, dst_pts: torch.Tensor) -> torch.Tensor:
    n = src_pts.shape[0]
    a = torch.zeros((2 * n, 6), dtype=src_pts.dtype, device=src_pts.device)
    b = torch.zeros((2 * n,), dtype=dst_pts.dtype, device=dst_pts.device)
    a[0::2, 0] = src_pts[:, 0]
    a[0::2, 1] = src_pts[:, 1]
    a[0::2, 2] = 1.0
    a[1::2, 3] = src_pts[:, 0]
    a[1::2, 4] = src_pts[:, 1]
    a[1::2, 5] = 1.0
    b[0::2] = dst_pts[:, 0]
    b[1::2] = dst_pts[:, 1]
    sol = torch.linalg.lstsq(a, b).solution
    aff = torch.eye(3, dtype=src_pts.dtype, device=src_pts.device)
    aff[0, :3] = sol[:3]
    aff[1, :3] = sol[3:]
    return aff


def ransac_affine(src_pts: torch.Tensor, dst_pts: torch.Tensor, iters: int, thresh: float, seed: int) -> torch.Tensor:
    device = src_pts.device
    if src_pts.shape[0] < 3:
        return torch.eye(3, dtype=src_pts.dtype, device=device)
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    best_aff = torch.eye(3, dtype=src_pts.dtype, device=device)
    best_count = 0
    src_h = torch.cat([src_pts, torch.ones((src_pts.shape[0], 1), dtype=src_pts.dtype, device=device)], dim=-1)
    for _ in range(iters):
        sel = torch.randperm(src_pts.shape[0], generator=gen)[:3].to(device)
        try:
            aff = solve_affine(src_pts[sel], dst_pts[sel])
        except RuntimeError:
            continue
        pred = (src_h @ aff.T)[:, :2]
        err = (pred - dst_pts).norm(dim=-1)
        count = int((err < thresh).sum().item())
        if count > best_count:
            best_count = count
            best_aff = aff
    return best_aff


def foreground_mask(image: torch.Tensor, side: int) -> torch.Tensor:
    mean = torch.tensor(CLIP_MEAN, dtype=image.dtype, device=image.device).view(1, 3, 1, 1)
    std = torch.tensor(CLIP_STD, dtype=image.dtype, device=image.device).view(1, 3, 1, 1)
    rgb = (image.unsqueeze(0) * std + mean).squeeze(0).clamp(0.0, 1.0)
    h, w = rgb.shape[-2:]
    patch = max(4, min(h, w) // 18)
    corners = torch.cat(
        [
            rgb[:, :patch, :patch].reshape(3, -1).T,
            rgb[:, :patch, -patch:].reshape(3, -1).T,
            rgb[:, -patch:, :patch].reshape(3, -1).T,
            rgb[:, -patch:, -patch:].reshape(3, -1).T,
        ],
        dim=0,
    )
    bg_mean = corners.mean(dim=0, keepdim=True)
    corner_dist = torch.norm(corners - bg_mean, dim=1)
    thresh = max(18.0 / 255.0, float(torch.quantile(corner_dist, 0.99).item()) + 8.0 / 255.0)
    dist = torch.norm(rgb.permute(1, 2, 0) - bg_mean.view(1, 1, 3), dim=-1)
    fg = (dist > thresh).float().view(1, 1, h, w)
    fg = F.interpolate(fg, size=(side, side), mode="bilinear", align_corners=False)
    return fg.view(-1) > 0.30


def build_normal_text_anchor(class_name: str, model: ClipModel, device: torch.device) -> torch.Tensor:
    phrases = []
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            phrases.append(template.format(normal_prompt.format(class_name)))
    tokenizer = open_clip.get_tokenizer("ViT-L-14")
    text = tokenizer(phrases).to(device)
    with torch.no_grad():
        text_features = model.visual_encoder.encode_text(text)
    avg = text_features.float().mean(dim=0)
    return avg / avg.norm().clamp_min(1e-8)


def maybe_project_to_text_space(tokens: torch.Tensor, model: ClipModel) -> torch.Tensor:
    if tokens.dim() != 2:
        raise ValueError(f"Expected [HW, C] tokens, got {tokens.shape}")
    visual = model.visual_encoder.visual
    proj = getattr(visual, "proj", None)
    if proj is None or tokens.shape[-1] == proj.shape[-1]:
        return tokens
    return tokens @ proj.float().to(tokens.device)


def compute_energy(tokens: torch.Tensor, fg_mask: torch.Tensor, args: argparse.Namespace) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    side = int(round(tokens.shape[0] ** 0.5))
    coords = patch_coords(side, tokens.device)
    coords_norm = normalize_coords(coords, side)
    sims = build_self_similarity(tokens, fg_mask=fg_mask, side=side, radius=args.self_exclude_radius)
    best_val, best_idx = sims.max(dim=1)
    valid_match = torch.isfinite(best_val) & (best_val >= args.match_cos_thresh)
    matched_u = coords_norm[best_idx]

    e_pca = local_pca_residual(tokens, side=side, kernel_size=args.kernel_size, rank=args.pca_rank)
    tau = torch.quantile(e_pca[fg_mask], args.tau_quantile) if fg_mask.any() else torch.quantile(e_pca, args.tau_quantile)
    suspect = e_pca > tau
    safe = fg_mask & (~suspect) & valid_match

    e_geo = torch.zeros_like(e_pca)
    if int(safe.sum().item()) >= 3:
        aff = ransac_affine(
            matched_u[safe],
            coords_norm[safe],
            iters=args.ransac_iters,
            thresh=args.ransac_thresh,
            seed=args.seed,
        )
        all_src_h = torch.cat([matched_u, torch.ones((matched_u.shape[0], 1), dtype=matched_u.dtype, device=matched_u.device)], dim=-1)
        proj = (all_src_h @ aff.T)[:, :2]
        e_geo = torch.norm(coords_norm - proj, dim=-1).pow(2)
        if valid_match.any():
            fallback = e_geo[valid_match & fg_mask].mean()
            e_geo = torch.where(valid_match, e_geo, fallback)
    energy = e_pca + e_geo
    return e_pca, e_geo, energy


def pairwise_mean_cos(tokens: torch.Tensor, max_points: int, seed: int) -> float:
    if tokens.shape[0] == 0:
        return float("nan")
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    if tokens.shape[0] > max_points:
        sel = torch.randperm(tokens.shape[0], generator=gen)[:max_points].to(tokens.device)
        tokens = tokens[sel]
    tokens = F.normalize(tokens.float(), dim=-1)
    sims = tokens @ tokens.T
    n = sims.shape[0]
    if n <= 1:
        return float("nan")
    tri = torch.triu_indices(n, n, offset=1, device=sims.device)
    return float(sims[tri[0], tri[1]].mean().item())


def downsample_mask(mask: torch.Tensor, side: int) -> torch.Tensor:
    m = F.interpolate(mask.unsqueeze(0), size=(side, side), mode="nearest").squeeze(0).squeeze(0)
    return m > 0.5


def pca_2d(x: torch.Tensor) -> torch.Tensor:
    x = x.float()
    mu = x.mean(dim=0, keepdim=True)
    centered = x - mu
    _, _, v = torch.linalg.svd(centered, full_matrices=False)
    basis = v[:2].T
    return centered @ basis


def main() -> None:
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    model = ClipModel(args.backbone, device=str(device)).eval()
    model.visual_encoder = model.visual_encoder.to(device)
    anchor = build_normal_text_anchor(args.class_name, model, device=device)

    train_unused = VisAOneClassDataset(
        root=args.dataset_root,
        class_name=args.class_name,
        split="train",
        resize=args.resize,
        imagesize=args.imagesize,
        mean=CLIP_MEAN,
        std=CLIP_STD,
    )
    test_ds = VisAOneClassDataset(
        root=args.dataset_root,
        class_name=args.class_name,
        split="test",
        resize=args.resize,
        imagesize=args.imagesize,
        mean=CLIP_MEAN,
        std=CLIP_STD,
    )
    normals = [rec for rec in test_ds.data_to_iterate if rec[1] == "good"][: args.max_normals]
    anomalies = [rec for rec in test_ds.data_to_iterate if rec[1] != "good"][: args.max_anomalies]
    test_ds.data_to_iterate = normals + anomalies

    rows: list[dict] = []
    vis_payload = None

    for idx in range(len(test_ds)):
        sample = test_ds[idx]
        image = sample["image"].unsqueeze(0).to(device)
        mask = sample["mask"].to(device)
        is_anomaly = bool(sample["is_anomaly"])

        with torch.no_grad():
            feats = model.encode_image_from_tensors(image, shape="img")

        for layer_id, feat in zip((6, 12, 18, 24), feats):
            if layer_id not in args.layers:
                continue
            c, h, w = feat.shape[1:]
            raw = feat[0].permute(1, 2, 0).reshape(-1, c).float()
            raw = maybe_project_to_text_space(raw, model)
            side = h
            fg = foreground_mask(image[0], side=side)
            local_mean = local_mean_tokens(raw, side=side, kernel_size=args.kernel_size)
            geom_tokens = F.normalize(raw, dim=-1)
            _, _, energy = compute_energy(geom_tokens, fg, args)
            tau = max(float(energy[fg].mean().item()) if fg.any() else float(energy.mean().item()), 1e-8)
            lam = energy / tau
            alpha = (1.0 / (1.0 + lam)).clamp(0.0, 1.0)

            delta = local_mean - raw
            raw_res = raw + alpha.unsqueeze(-1) * delta

            t = anchor.to(device=raw.device, dtype=raw.dtype)
            delta_parallel = (delta @ t).unsqueeze(-1) * t.unsqueeze(0)
            delta_perp = delta - delta_parallel
            orth_res = raw + alpha.unsqueeze(-1) * delta_perp

            patch_mask = downsample_mask(mask, side=side)
            defect = patch_mask.view(-1) & fg
            clean = (~patch_mask.view(-1)) & fg
            label_type = torch.full((raw.shape[0],), 0, device=raw.device, dtype=torch.long)
            if is_anomaly:
                label_type[clean] = 1
                label_type[defect] = 2
            else:
                label_type[fg] = 0

            rows.append(
                {
                    "layer": layer_id,
                    "is_anomaly_image": int(is_anomaly),
                    "normal_count": int((label_type == 0).sum().item()),
                    "clean_count": int((label_type == 1).sum().item()),
                    "defect_count": int((label_type == 2).sum().item()),
                    "text_axis_delta_raw_mean": float(((raw_res - raw) @ t).abs().mean().item()),
                    "text_axis_delta_orth_mean": float(((orth_res - raw) @ t).abs().mean().item()),
                    "text_axis_delta_orth_max": float(((orth_res - raw) @ t).abs().max().item()),
                    "cos_to_text_raw_mean": float(F.cosine_similarity(raw, t.unsqueeze(0), dim=-1)[fg].mean().item()) if fg.any() else float("nan"),
                    "cos_to_text_rawres_mean": float(F.cosine_similarity(raw_res, t.unsqueeze(0), dim=-1)[fg].mean().item()) if fg.any() else float("nan"),
                    "cos_to_text_orth_mean": float(F.cosine_similarity(orth_res, t.unsqueeze(0), dim=-1)[fg].mean().item()) if fg.any() else float("nan"),
                }
            )

            if vis_payload is None and layer_id == args.vis_layer and is_anomaly and int(defect.sum().item()) > 0:
                proj_before = pca_2d(raw[fg])
                proj_after = pca_2d(orth_res[fg])
                vis_payload = {
                    "layer": layer_id,
                    "fg_mask": fg.detach().cpu(),
                    "labels": label_type[fg].detach().cpu(),
                    "axis_before": (raw @ t).detach().cpu(),
                    "axis_rawres": (raw_res @ t).detach().cpu(),
                    "axis_after": (orth_res @ t).detach().cpu(),
                    "proj_before": proj_before.detach().cpu(),
                    "proj_after": proj_after.detach().cpu(),
                }

    by_layer: dict[int, dict[str, float]] = {}
    for layer_id in args.layers:
        layer_rows = [r for r in rows if r["layer"] == layer_id]
        if not layer_rows:
            continue
        by_layer[layer_id] = {
            "text_axis_delta_raw_mean": float(np.nanmean([r["text_axis_delta_raw_mean"] for r in layer_rows])),
            "text_axis_delta_orth_mean": float(np.nanmean([r["text_axis_delta_orth_mean"] for r in layer_rows])),
            "text_axis_delta_orth_max": float(np.nanmax([r["text_axis_delta_orth_max"] for r in layer_rows])),
            "cos_to_text_raw_mean": float(np.nanmean([r["cos_to_text_raw_mean"] for r in layer_rows])),
            "cos_to_text_rawres_mean": float(np.nanmean([r["cos_to_text_rawres_mean"] for r in layer_rows])),
            "cos_to_text_orth_mean": float(np.nanmean([r["cos_to_text_orth_mean"] for r in layer_rows])),
        }

    # aggregate separation / cohesion on sampled subset
    detailed = {}
    for layer_id in args.layers:
        normal_raw, normal_rawres, normal_orth = [], [], []
        clean_raw, clean_rawres, clean_orth = [], [], []
        defect_raw, defect_rawres, defect_orth = [], [], []
        for idx in range(len(test_ds)):
            sample = test_ds[idx]
            image = sample["image"].unsqueeze(0).to(device)
            mask = sample["mask"].to(device)
            is_anomaly = bool(sample["is_anomaly"])
            with torch.no_grad():
                feats = model.encode_image_from_tensors(image, shape="img")
            feat = feats[(6, 12, 18, 24).index(layer_id)]
            c, h, w = feat.shape[1:]
            raw = feat[0].permute(1, 2, 0).reshape(-1, c).float()
            raw = maybe_project_to_text_space(raw, model)
            fg = foreground_mask(image[0], side=h)
            local_mean = local_mean_tokens(raw, side=h, kernel_size=args.kernel_size)
            geom_tokens = F.normalize(raw, dim=-1)
            _, _, energy = compute_energy(geom_tokens, fg, args)
            tau = max(float(energy[fg].mean().item()) if fg.any() else float(energy.mean().item()), 1e-8)
            alpha = (1.0 / (1.0 + energy / tau)).clamp(0.0, 1.0)
            delta = local_mean - raw
            raw_res = raw + alpha.unsqueeze(-1) * delta
            t = anchor.to(device=raw.device, dtype=raw.dtype)
            delta_perp = delta - (delta @ t).unsqueeze(-1) * t.unsqueeze(0)
            orth_res = raw + alpha.unsqueeze(-1) * delta_perp

            patch_mask = downsample_mask(mask, side=h).view(-1)
            if is_anomaly:
                clean = (~patch_mask) & fg
                defect = patch_mask & fg
                if clean.any():
                    clean_raw.append(raw[clean])
                    clean_rawres.append(raw_res[clean])
                    clean_orth.append(orth_res[clean])
                if defect.any():
                    defect_raw.append(raw[defect])
                    defect_rawres.append(raw_res[defect])
                    defect_orth.append(orth_res[defect])
            else:
                if fg.any():
                    normal_raw.append(raw[fg])
                    normal_rawres.append(raw_res[fg])
                    normal_orth.append(orth_res[fg])

        if not normal_raw:
            continue
        nr = torch.cat(normal_raw, dim=0)
        nrr = torch.cat(normal_rawres, dim=0)
        nro = torch.cat(normal_orth, dim=0)
        centroid_raw = nr.mean(dim=0, keepdim=True)
        centroid_rawres = nrr.mean(dim=0, keepdim=True)
        centroid_orth = nro.mean(dim=0, keepdim=True)
        def _cat(xs): return torch.cat(xs, dim=0) if xs else None
        cr, crr, co = _cat(clean_raw), _cat(clean_rawres), _cat(clean_orth)
        dr, drr, do = _cat(defect_raw), _cat(defect_rawres), _cat(defect_orth)
        sep_before = float((torch.norm(dr - centroid_raw, dim=-1).mean() - torch.norm(cr - centroid_raw, dim=-1).mean()).item()) if dr is not None and cr is not None else float("nan")
        sep_rawres = float((torch.norm(drr - centroid_rawres, dim=-1).mean() - torch.norm(crr - centroid_rawres, dim=-1).mean()).item()) if drr is not None and crr is not None else float("nan")
        sep_orth = float((torch.norm(do - centroid_orth, dim=-1).mean() - torch.norm(co - centroid_orth, dim=-1).mean()).item()) if do is not None and co is not None else float("nan")
        detailed[layer_id] = {
            "normal_pairwise_raw": pairwise_mean_cos(nr, args.pairwise_sample, args.seed),
            "normal_pairwise_rawres": pairwise_mean_cos(nrr, args.pairwise_sample, args.seed),
            "normal_pairwise_orth": pairwise_mean_cos(nro, args.pairwise_sample, args.seed),
            "defect_clean_sep_before": sep_before,
            "defect_clean_sep_rawres": sep_rawres,
            "defect_clean_sep_orth": sep_orth,
        }

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / f"{args.output_tag}_{args.class_name}_summary.csv"
    json_path = out_dir / f"{args.output_tag}_{args.class_name}_detail.json"
    png_path = out_dir / f"{args.output_tag}_{args.class_name}_vis.png"

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "layer",
                "text_axis_delta_raw_mean",
                "text_axis_delta_orth_mean",
                "text_axis_delta_orth_max",
                "cos_to_text_raw_mean",
                "cos_to_text_rawres_mean",
                "cos_to_text_orth_mean",
                "normal_pairwise_raw",
                "normal_pairwise_rawres",
                "normal_pairwise_orth",
                "defect_clean_sep_before",
                "defect_clean_sep_rawres",
                "defect_clean_sep_orth",
            ],
        )
        writer.writeheader()
        for layer_id in args.layers:
            row = {"layer": layer_id}
            row.update(by_layer.get(layer_id, {}))
            row.update(detailed.get(layer_id, {}))
            writer.writerow(row)

    with json_path.open("w") as f:
        json.dump({"summary": by_layer, "detail": detailed}, f, indent=2)

    if vis_payload is not None:
        labels = vis_payload["labels"].numpy()
        colors = np.array(["tab:blue", "tab:green", "tab:red"], dtype=object)
        label_names = np.array(["normal", "clean", "defect"], dtype=object)
        fig, axes = plt.subplots(2, 2, figsize=(10, 8))
        ax = axes[0, 0]
        ax.scatter(vis_payload["axis_before"][vis_payload["fg_mask"]].numpy(), vis_payload["axis_rawres"][vis_payload["fg_mask"]].numpy(), s=8, alpha=0.35)
        lims = ax.get_xlim()
        ax.plot(lims, lims, "k--", linewidth=1)
        ax.set_title("Raw vs Raw-Residual text-axis")
        ax.set_xlabel("raw T^T V")
        ax.set_ylabel("rawres T^T V")

        ax = axes[0, 1]
        ax.scatter(vis_payload["axis_before"][vis_payload["fg_mask"]].numpy(), vis_payload["axis_after"][vis_payload["fg_mask"]].numpy(), s=8, alpha=0.35)
        lims = ax.get_xlim()
        ax.plot(lims, lims, "k--", linewidth=1)
        ax.set_title("Raw vs Orth-Residual text-axis")
        ax.set_xlabel("raw T^T V")
        ax.set_ylabel("orth T^T V")

        for label_id in [0, 1, 2]:
            sel = labels == label_id
            if not np.any(sel):
                continue
            axes[1, 0].scatter(
                vis_payload["proj_before"][sel, 0].numpy(),
                vis_payload["proj_before"][sel, 1].numpy(),
                s=12,
                alpha=0.5,
                c=colors[label_id],
                label=label_names[label_id],
            )
            axes[1, 1].scatter(
                vis_payload["proj_after"][sel, 0].numpy(),
                vis_payload["proj_after"][sel, 1].numpy(),
                s=12,
                alpha=0.5,
                c=colors[label_id],
                label=label_names[label_id],
            )
        axes[1, 0].set_title(f"Orth-space PCA before (L{vis_payload['layer']})")
        axes[1, 1].set_title(f"Orth-space PCA after (L{vis_payload['layer']})")
        axes[1, 0].legend(frameon=False)
        plt.tight_layout()
        fig.savefig(png_path, dpi=180)

    print(csv_path)
    print(json_path)
    if vis_payload is not None:
        print(png_path)


if __name__ == "__main__":
    main()
