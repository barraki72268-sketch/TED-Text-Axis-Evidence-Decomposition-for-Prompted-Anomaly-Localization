from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import open_clip
import torch
import torch.nn.functional as F
from PIL import Image
from torchvision import transforms as T

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.models.clip import ClipModel
from ADPretrain.models.dino import DinoModel
from neurips2026.patchcore_adapters.visa_dataset import VisAOneClassDataset
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
LAYER_IDS = (6, 12, 18, 24)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--dino_backbone", type=str, default="dinov2-large", choices=["dinov2-base", "dinov2-large"])
    parser.add_argument("--clip_teacher", type=str, default="clip-large", choices=["clip-large"])
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=224)
    parser.add_argument("--imagesize", type=int, default=224)
    parser.add_argument("--teacher_resize", type=int, default=224)
    parser.add_argument("--teacher_imagesize", type=int, default=224)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--gamma", type=float, default=1.0)
    parser.add_argument("--gate_mode", type=str, default="shock_topk", choices=["var_mean", "shock_topk"])
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--refine_mode", type=str, default="orth_perp", choices=["orth_perp", "residual_raw_norm"])
    parser.add_argument("--ridge", type=float, default=1e-3)
    parser.add_argument("--max_fit_normals", type=int, default=40)
    parser.add_argument("--max_normals", type=int, default=20)
    parser.add_argument("--max_anomalies", type=int, default=20)
    parser.add_argument("--pairwise_sample", type=int, default=1024)
    parser.add_argument("--vis_layer", type=int, default=12)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:1")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="dino_linear_text_probe")
    return parser.parse_args()


def foreground_mask(image: torch.Tensor, side: int, mean: tuple[float, float, float], std: tuple[float, float, float]) -> torch.Tensor:
    mean_t = torch.tensor(mean, dtype=image.dtype, device=image.device).view(1, 3, 1, 1)
    std_t = torch.tensor(std, dtype=image.dtype, device=image.device).view(1, 3, 1, 1)
    rgb = (image.unsqueeze(0) * std_t + mean_t).squeeze(0).clamp(0.0, 1.0)
    h, w = rgb.shape[-2:]
    patch = max(4, min(h, w) // 18)
    corners = torch.cat(
        [
            rgb[:, :patch, :patch].reshape(3, -1).T,
            rgb[:, :patch, -patch:].reshape(3, -1).T,
            rgb[:, -patch:, :patch].reshape(3, -1).T,
            rgb[:, -patch:, -patch:].reshape(3, -1).T,
        ],
        dim=0,
    )
    bg_mean = corners.mean(dim=0, keepdim=True)
    corner_dist = torch.norm(corners - bg_mean, dim=1)
    thresh = max(18.0 / 255.0, float(torch.quantile(corner_dist, 0.99).item()) + 8.0 / 255.0)
    dist = torch.norm(rgb.permute(1, 2, 0) - bg_mean.view(1, 1, 3), dim=-1)
    fg = (dist > thresh).float().view(1, 1, h, w)
    fg = F.interpolate(fg, size=(side, side), mode="bilinear", align_corners=False)
    return fg.view(-1) > 0.30


def build_transform(
    mean: tuple[float, float, float],
    std: tuple[float, float, float],
    resize: int,
    imagesize: int,
) -> T.Compose:
    return T.Compose(
        [
            T.Resize(resize, interpolation=T.InterpolationMode.BICUBIC),
            T.CenterCrop(imagesize),
            T.ToTensor(),
            T.Normalize(mean=mean, std=std),
        ]
    )


def load_image_with_transform(image_path: str, transform: T.Compose, device: torch.device) -> torch.Tensor:
    return transform(Image.open(image_path).convert("RGB")).unsqueeze(0).to(device)


def downsample_mask(mask: torch.Tensor, side: int) -> torch.Tensor:
    m = F.interpolate(mask.unsqueeze(0), size=(side, side), mode="nearest").squeeze(0).squeeze(0)
    return m > 0.5


def maybe_project_clip_tokens(tokens: torch.Tensor, model: ClipModel) -> torch.Tensor:
    visual = model.visual_encoder.visual
    proj = getattr(visual, "proj", None)
    if proj is None:
        return tokens
    target_dim = proj.shape[-1]
    if tokens.shape[-1] == target_dim:
        return tokens
    return tokens @ proj.float().to(tokens.device)


def maybe_resize_feature_map(feat: torch.Tensor, target_hw: tuple[int, int]) -> torch.Tensor:
    if feat.shape[-2:] == target_hw:
        return feat
    return F.interpolate(feat.float(), size=target_hw, mode="bilinear", align_corners=False)


def build_normal_text_anchor(class_name: str, model: ClipModel, device: torch.device) -> torch.Tensor:
    phrases = []
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            phrases.append(template.format(normal_prompt.format(class_name)))
    tokenizer = open_clip.get_tokenizer("ViT-L-14")
    text = tokenizer(phrases).to(device)
    with torch.no_grad():
        text_features = model.visual_encoder.encode_text(text)
    avg = text_features.float().mean(dim=0)
    return avg / avg.norm().clamp_min(1e-8)


def _shock_lambda(x: torch.Tensor, kernel_size: int, gate_mode: str, topk_ratio: float) -> tuple[torch.Tensor, torch.Tensor]:
    mu = F.avg_pool2d(x, kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
    second_moment = F.avg_pool2d(x.pow(2), kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
    var = (second_moment - mu.pow(2)).clamp_min(1e-6)
    if gate_mode == "var_mean":
        lam = var.mean(dim=1, keepdim=True)
    elif gate_mode == "shock_topk":
        shock = (x - mu).pow(2) / var
        b, d, h, w = shock.shape
        k = max(1, min(d, int(round(d * topk_ratio))))
        shock_flat = shock.permute(0, 2, 3, 1).reshape(-1, d)
        topk_vals, _ = torch.topk(shock_flat, k=k, dim=1)
        lam = topk_vals.mean(dim=1, keepdim=True).reshape(b, h, w, 1).permute(0, 3, 1, 2)
    else:
        raise ValueError(f"Unknown gate_mode: {gate_mode}")
    return mu, lam


def refine_tokens(
    v_raw: torch.Tensor,
    t_anchor: torch.Tensor,
    kernel_size: int = 3,
    gamma: float = 1.0,
    gate_mode: str = "shock_topk",
    topk_ratio: float = 0.1,
    refine_mode: str = "orth_perp",
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if v_raw.dim() != 4:
        raise ValueError(f"Expected (B,D,H,W), got {tuple(v_raw.shape)}")
    if kernel_size % 2 == 0:
        raise ValueError("kernel_size must be odd.")

    if refine_mode == "residual_raw_norm":
        mu_full, lam = _shock_lambda(v_raw, kernel_size=kernel_size, gate_mode=gate_mode, topk_ratio=topk_ratio)
        alpha = 1.0 / (1.0 + gamma * lam)
        mu_full = F.normalize(mu_full, dim=1)
        refined = F.normalize(v_raw + alpha * (mu_full - v_raw), dim=1)
        return refined, alpha, lam

    if t_anchor.dim() == 1:
        t = t_anchor.view(1, -1, 1, 1)
    elif t_anchor.dim() == 4:
        t = t_anchor
    else:
        raise ValueError(f"Unexpected t_anchor shape: {tuple(t_anchor.shape)}")
    t = t.to(device=v_raw.device, dtype=v_raw.dtype)
    t = t / t.norm(dim=1, keepdim=True).clamp_min(1e-8)

    v_parallel = torch.sum(v_raw * t, dim=1, keepdim=True) * t
    v_perp = v_raw - v_parallel
    mu_perp, lam = _shock_lambda(v_perp, kernel_size=kernel_size, gate_mode=gate_mode, topk_ratio=topk_ratio)
    alpha = 1.0 / (1.0 + gamma * lam)
    v_perp_refined = v_perp + alpha * (mu_perp - v_perp)
    v_final = v_parallel + v_perp_refined
    return v_final, alpha, lam


def pairwise_mean_cos(tokens: torch.Tensor, max_points: int, seed: int) -> float:
    if tokens.shape[0] == 0:
        return float("nan")
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    if tokens.shape[0] > max_points:
        sel = torch.randperm(tokens.shape[0], generator=gen)[:max_points].to(tokens.device)
        tokens = tokens[sel]
    tokens = F.normalize(tokens.float(), dim=-1)
    sims = tokens @ tokens.T
    n = sims.shape[0]
    if n <= 1:
        return float("nan")
    tri = torch.triu_indices(n, n, offset=1, device=sims.device)
    return float(sims[tri[0], tri[1]].mean().item())


def pca_2d(x: torch.Tensor) -> torch.Tensor:
    x = x.float()
    mu = x.mean(dim=0, keepdim=True)
    centered = x - mu
    _, _, v = torch.linalg.svd(centered, full_matrices=False)
    basis = v[:2].T
    return centered @ basis


def fit_ridge_bridge(x: torch.Tensor, y: torch.Tensor, ridge: float) -> tuple[torch.Tensor, dict[str, float]]:
    x64 = x.double()
    y64 = y.double()
    n = x64.shape[0]
    eye = torch.eye(x64.shape[1], dtype=x64.dtype, device=x64.device)
    xtx = (x64.T @ x64) / max(n, 1) + ridge * eye
    xty = (x64.T @ y64) / max(n, 1)
    w = torch.linalg.solve(xtx, xty).float()
    pred = F.normalize((x @ w).float(), dim=-1)
    target = F.normalize(y.float(), dim=-1)
    return w, {
        "fit_pairs": float(n),
        "bridge_train_cos_mean": float(F.cosine_similarity(pred, target, dim=-1).mean().item()),
        "bridge_train_mse": float(((x @ w) - y).pow(2).mean().item()),
    }


def main() -> None:
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    dino = DinoModel(args.dino_backbone, device=str(device)).eval()
    dino.visual_encoder = dino.visual_encoder.to(device)
    clip_teacher = ClipModel(args.clip_teacher, device=str(device)).eval()
    clip_teacher.visual_encoder = clip_teacher.visual_encoder.to(device)
    text_anchor = build_normal_text_anchor(args.class_name, clip_teacher, device=device)
    clip_transform = build_transform(
        mean=(0.48145466, 0.4578275, 0.40821073),
        std=(0.26862954, 0.26130258, 0.27577711),
        resize=args.teacher_resize,
        imagesize=args.teacher_imagesize,
    )

    fit_ds = VisAOneClassDataset(
        root=args.dataset_root,
        class_name=args.class_name,
        split="train",
        resize=args.resize,
        imagesize=args.imagesize,
        mean=IMAGENET_MEAN,
        std=IMAGENET_STD,
    )
    fit_ds.data_to_iterate = fit_ds.data_to_iterate[: args.max_fit_normals]

    layer_pairs_x: dict[int, list[torch.Tensor]] = {layer: [] for layer in args.layers}
    layer_pairs_y: dict[int, list[torch.Tensor]] = {layer: [] for layer in args.layers}
    for idx in range(len(fit_ds)):
        sample = fit_ds[idx]
        image = sample["image"].unsqueeze(0).to(device)
        clip_image = load_image_with_transform(sample["image_path"], clip_transform, device)
        with torch.no_grad():
            dino_feats = dino.encode_image_from_tensors(image, shape="img")
            clip_feats = clip_teacher.encode_image_from_tensors(clip_image, shape="img")
        for layer_id, dino_feat, clip_feat in zip(LAYER_IDS, dino_feats, clip_feats):
            if layer_id not in args.layers:
                continue
            _, cd, h, w = dino_feat.shape
            clip_feat = maybe_resize_feature_map(clip_feat, target_hw=(h, w))
            dino_tokens = dino_feat[0].permute(1, 2, 0).reshape(-1, cd).float()
            clip_tokens = maybe_project_clip_tokens(
                clip_feat[0].permute(1, 2, 0).reshape(-1, clip_feat.shape[1]).float(),
                clip_teacher,
            )
            fg = foreground_mask(image[0], side=h, mean=IMAGENET_MEAN, std=IMAGENET_STD)
            if fg.any():
                layer_pairs_x[layer_id].append(dino_tokens[fg].cpu())
                layer_pairs_y[layer_id].append(F.normalize(clip_tokens[fg], dim=-1).cpu())

    bridge_by_layer: dict[int, torch.Tensor] = {}
    axis_by_layer: dict[int, torch.Tensor] = {}
    bridge_stats: dict[int, dict[str, float]] = {}
    for layer_id in args.layers:
        x = torch.cat(layer_pairs_x[layer_id], dim=0).to(device)
        y = torch.cat(layer_pairs_y[layer_id], dim=0).to(device)
        w, stats = fit_ridge_bridge(x, y, ridge=args.ridge)
        a = w @ text_anchor.to(device=w.device, dtype=w.dtype)
        a = a / a.norm().clamp_min(1e-8)
        bridge_by_layer[layer_id] = w.detach()
        axis_by_layer[layer_id] = a.detach()
        bridge_stats[layer_id] = stats

    test_ds = VisAOneClassDataset(
        root=args.dataset_root,
        class_name=args.class_name,
        split="test",
        resize=args.resize,
        imagesize=args.imagesize,
        mean=IMAGENET_MEAN,
        std=IMAGENET_STD,
    )
    normals = [rec for rec in test_ds.data_to_iterate if rec[1] == "good"][: args.max_normals]
    anomalies = [rec for rec in test_ds.data_to_iterate if rec[1] != "good"][: args.max_anomalies]
    test_ds.data_to_iterate = normals + anomalies

    rows: list[dict] = []
    cache: dict[tuple[int, int], tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]] = {}
    vis_payload = None

    for idx in range(len(test_ds)):
        sample = test_ds[idx]
        image = sample["image"].unsqueeze(0).to(device)
        mask = sample["mask"].to(device)
        is_anomaly = bool(sample["is_anomaly"])

        with torch.no_grad():
            dino_feats = dino.encode_image_from_tensors(image, shape="img")

        for layer_id, dino_feat in zip(LAYER_IDS, dino_feats):
            if layer_id not in args.layers:
                continue
            c, h, w = dino_feat.shape[1:]
            raw = dino_feat[0].permute(1, 2, 0).reshape(-1, c).float()
            raw_map = raw.T.reshape(1, c, h, w)
            dino_axis = axis_by_layer[layer_id].to(device=raw.device, dtype=raw.dtype)
            refined_map, alpha_map, lambda_map = refine_tokens(
                raw_map,
                dino_axis,
                kernel_size=args.kernel_size,
                gamma=args.gamma,
                gate_mode=args.gate_mode,
                topk_ratio=args.topk_ratio,
                refine_mode=args.refine_mode,
            )
            refined = refined_map[0].permute(1, 2, 0).reshape(-1, c)
            fg = foreground_mask(image[0], side=h, mean=IMAGENET_MEAN, std=IMAGENET_STD)
            patch_mask = downsample_mask(mask, side=h).view(-1)
            defect = patch_mask & fg
            clean = (~patch_mask) & fg
            label_type = torch.full((raw.shape[0],), 0, device=raw.device, dtype=torch.long)
            if is_anomaly:
                label_type[clean] = 1
                label_type[defect] = 2

            delta = refined - raw
            text_axis_before = raw @ dino_axis
            text_axis_after = refined @ dino_axis
            text_axis_delta = text_axis_after - text_axis_before

            w_bridge = bridge_by_layer[layer_id].to(device=raw.device, dtype=raw.dtype)
            raw_proj = F.normalize(raw @ w_bridge, dim=-1)
            refined_proj = F.normalize(refined @ w_bridge, dim=-1)
            text_clip = text_anchor.to(device=raw.device, dtype=raw.dtype)

            rows.append(
                {
                    "layer": layer_id,
                    "is_anomaly_image": int(is_anomaly),
                    "normal_count": int((label_type == 0).sum().item()),
                    "clean_count": int((label_type == 1).sum().item()),
                    "defect_count": int((label_type == 2).sum().item()),
                    "text_axis_delta_mean": float(text_axis_delta[fg].abs().mean().item()) if fg.any() else float("nan"),
                    "text_axis_signed_mean": float(text_axis_delta[fg].mean().item()) if fg.any() else float("nan"),
                    "text_axis_delta_max": float(text_axis_delta[fg].abs().max().item()) if fg.any() else float("nan"),
                    "cos_to_text_raw_mean": float((raw_proj @ text_clip)[fg].mean().item()) if fg.any() else float("nan"),
                    "cos_to_text_refined_mean": float((refined_proj @ text_clip)[fg].mean().item()) if fg.any() else float("nan"),
                    "alpha_fg_mean": float(alpha_map.view(-1)[fg].mean().item()) if fg.any() else float("nan"),
                    "lambda_fg_mean": float(lambda_map.view(-1)[fg].mean().item()) if fg.any() else float("nan"),
                }
            )

            cache[(idx, layer_id)] = (raw.detach(), refined.detach(), fg.detach(), defect.detach(), clean.detach())

            if vis_payload is None and layer_id == args.vis_layer and is_anomaly and int(defect.sum().item()) > 0:
                vpar = (raw @ dino_axis).unsqueeze(-1) * dino_axis.unsqueeze(0)
                vperp_before = raw - vpar
                vpar_after = (refined @ dino_axis).unsqueeze(-1) * dino_axis.unsqueeze(0)
                vperp_after = refined - vpar_after
                proj_before = pca_2d(vperp_before[fg])
                proj_after = pca_2d(vperp_after[fg])
                vis_payload = {
                    "layer": layer_id,
                    "labels": label_type[fg].detach().cpu(),
                    "axis_before": text_axis_before[fg].detach().cpu(),
                    "axis_after": text_axis_after[fg].detach().cpu(),
                    "alpha_fg": alpha_map.view(-1)[fg].detach().cpu(),
                    "proj_before": proj_before.detach().cpu(),
                    "proj_after": proj_after.detach().cpu(),
                }

    summary = {}
    detail = {}
    for layer_id in args.layers:
        layer_rows = [r for r in rows if r["layer"] == layer_id]
        if not layer_rows:
            continue
        summary[layer_id] = {
            "fit_pairs": bridge_stats[layer_id]["fit_pairs"],
            "bridge_train_cos_mean": bridge_stats[layer_id]["bridge_train_cos_mean"],
            "bridge_train_mse": bridge_stats[layer_id]["bridge_train_mse"],
            "text_axis_delta_mean": float(np.nanmean([r["text_axis_delta_mean"] for r in layer_rows])),
            "text_axis_signed_mean": float(np.nanmean([r["text_axis_signed_mean"] for r in layer_rows])),
            "text_axis_delta_max": float(np.nanmax([r["text_axis_delta_max"] for r in layer_rows])),
            "cos_to_text_raw_mean": float(np.nanmean([r["cos_to_text_raw_mean"] for r in layer_rows])),
            "cos_to_text_refined_mean": float(np.nanmean([r["cos_to_text_refined_mean"] for r in layer_rows])),
            "alpha_fg_mean": float(np.nanmean([r["alpha_fg_mean"] for r in layer_rows])),
            "lambda_fg_mean": float(np.nanmean([r["lambda_fg_mean"] for r in layer_rows])),
        }

        normal_raw, normal_ref = [], []
        clean_raw, clean_ref = [], []
        defect_raw, defect_ref = [], []
        for idx in range(len(test_ds)):
            if (idx, layer_id) not in cache:
                continue
            raw, refined, fg, defect, clean = cache[(idx, layer_id)]
            sample = test_ds[idx]
            if bool(sample["is_anomaly"]):
                if clean.any():
                    clean_raw.append(raw[clean])
                    clean_ref.append(refined[clean])
                if defect.any():
                    defect_raw.append(raw[defect])
                    defect_ref.append(refined[defect])
            else:
                if fg.any():
                    normal_raw.append(raw[fg])
                    normal_ref.append(refined[fg])

        if not normal_raw:
            continue
        nr = torch.cat(normal_raw, dim=0)
        nrf = torch.cat(normal_ref, dim=0)
        cr = torch.cat(clean_raw, dim=0) if clean_raw else None
        cf = torch.cat(clean_ref, dim=0) if clean_ref else None
        dr = torch.cat(defect_raw, dim=0) if defect_raw else None
        df = torch.cat(defect_ref, dim=0) if defect_ref else None
        centroid_raw = nr.mean(dim=0, keepdim=True)
        centroid_ref = nrf.mean(dim=0, keepdim=True)

        detail[layer_id] = {
            "normal_pairwise_raw": pairwise_mean_cos(nr, args.pairwise_sample, args.seed),
            "normal_pairwise_refined": pairwise_mean_cos(nrf, args.pairwise_sample, args.seed),
            "defect_clean_sep_before": float((torch.norm(dr - centroid_raw, dim=-1).mean() - torch.norm(cr - centroid_raw, dim=-1).mean()).item()) if dr is not None and cr is not None else float("nan"),
            "defect_clean_sep_after": float((torch.norm(df - centroid_ref, dim=-1).mean() - torch.norm(cf - centroid_ref, dim=-1).mean()).item()) if df is not None and cf is not None else float("nan"),
        }

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{args.class_name}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    png_path = out_dir / f"{stem}_vis.png"

    fieldnames = [
        "layer",
        "fit_pairs",
        "bridge_train_cos_mean",
        "bridge_train_mse",
        "text_axis_delta_mean",
        "text_axis_signed_mean",
        "text_axis_delta_max",
        "cos_to_text_raw_mean",
        "cos_to_text_refined_mean",
        "alpha_fg_mean",
        "lambda_fg_mean",
        "normal_pairwise_raw",
        "normal_pairwise_refined",
        "defect_clean_sep_before",
        "defect_clean_sep_after",
    ]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for layer_id in args.layers:
            row = {"layer": layer_id}
            row.update(summary.get(layer_id, {}))
            row.update(detail.get(layer_id, {}))
            writer.writerow(row)

    with json_path.open("w") as f:
        json.dump({"summary": summary, "detail": detail}, f, indent=2)

    if vis_payload is not None:
        labels = vis_payload["labels"].numpy()
        colors = np.array(["tab:blue", "tab:green", "tab:red"], dtype=object)
        names = np.array(["normal", "clean", "defect"], dtype=object)
        fig, axes = plt.subplots(2, 2, figsize=(10, 8))

        ax = axes[0, 0]
        ax.scatter(vis_payload["axis_before"].numpy(), vis_payload["axis_after"].numpy(), s=8, alpha=0.35)
        lims = ax.get_xlim()
        ax.plot(lims, lims, "k--", linewidth=1)
        ax.set_title("Raw vs Refined text-axis")
        ax.set_xlabel("raw a^T V")
        ax.set_ylabel("refined a^T V")

        ax = axes[0, 1]
        ax.hist(vis_payload["alpha_fg"].numpy(), bins=30, color="tab:orange", alpha=0.8)
        ax.set_title("Foreground alpha distribution")
        ax.set_xlabel("alpha")
        ax.set_ylabel("count")

        for label_id in [0, 1, 2]:
            sel = labels == label_id
            if not np.any(sel):
                continue
            axes[1, 0].scatter(
                vis_payload["proj_before"][sel, 0].numpy(),
                vis_payload["proj_before"][sel, 1].numpy(),
                s=12,
                alpha=0.5,
                c=colors[label_id],
                label=names[label_id],
            )
            axes[1, 1].scatter(
                vis_payload["proj_after"][sel, 0].numpy(),
                vis_payload["proj_after"][sel, 1].numpy(),
                s=12,
                alpha=0.5,
                c=colors[label_id],
                label=names[label_id],
            )
        axes[1, 0].set_title(f"Perp-space PCA before (L{vis_payload['layer']})")
        axes[1, 1].set_title(f"Perp-space PCA after (L{vis_payload['layer']})")
        axes[1, 0].legend(frameon=False)
        plt.tight_layout()
        fig.savefig(png_path, dpi=180)

    print(csv_path)
    print(json_path)
    if vis_payload is not None:
        print(png_path)


if __name__ == "__main__":
    main()
