from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"


HOST_FILES = {
    "AnomalyCLIP": RESULTS / "anomalyclip_map_separability_matched_epoch5" / "summary.json",
    "AdaptCLIP": RESULTS / "adaptclip_map_separability_matched_epoch15" / "summary.json",
    "AdaCLIP": RESULTS / "adaclip_map_separability_matched_last" / "summary.json",
    "FAPrompt": RESULTS / "faprompt_map_separability_matched_epoch15" / "summary.json",
    "Bayes-PFL": RESULTS / "bayespfl_map_separability_matched_epoch15" / "summary.json",
}


def load_json(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def bar_plot(labels: list[str], values: list[float], ylabel: str, title: str, save_path: Path, ylim=(0.0, 1.0)):
    plt.figure(figsize=(8, 4.5))
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    xs = np.arange(len(labels))
    plt.bar(xs, values, color=colors[: len(labels)], width=0.65)
    for x, y in zip(xs, values):
        plt.text(x, y + 0.01 * (ylim[1] - ylim[0]), f"{y:.3f}", ha="center", va="bottom", fontsize=10)
    plt.xticks(xs, labels, rotation=0)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.ylim(*ylim)
    plt.tight_layout()
    save_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=180)
    plt.close()


def main():
    save_dir = RESULTS / "map_separability_dashboard_matched"
    save_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for host, path in HOST_FILES.items():
        data = load_json(path)
        matched = data["matched_summary"]
        groups = matched["groups"]
        aucs = matched["pairwise_auc"]
        rows.append(
            {
                "host": host,
                "true_defect_topk_mean": groups["true_defect_topk"]["mean"],
                "hard_fp_topk_mean": groups["hard_fp_topk"]["mean"],
                "outside_topk_mean": groups["outside_topk"]["mean"],
                "true_defect_comp_peak_mean": groups["true_defect_comp_peak"]["mean"],
                "hard_fp_comp_peak_mean": groups["hard_fp_comp_peak"]["mean"],
                "outside_comp_peak_mean": groups["outside_comp_peak"]["mean"],
                "true_defect_comp_mean_mean": groups["true_defect_comp_mean"]["mean"],
                "hard_fp_comp_mean_mean": groups["hard_fp_comp_mean"]["mean"],
                "outside_comp_mean_mean": groups["outside_comp_mean"]["mean"],
                "auc_true_defect_topk_vs_hard_fp_topk": aucs["true_defect_topk_vs_hard_fp_topk"],
                "auc_true_defect_topk_vs_outside_topk": aucs["true_defect_topk_vs_outside_topk"],
                "auc_true_defect_comp_peak_vs_hard_fp_comp_peak": aucs["true_defect_comp_peak_vs_hard_fp_comp_peak"],
                "auc_true_defect_comp_peak_vs_outside_comp_peak": aucs["true_defect_comp_peak_vs_outside_comp_peak"],
                "auc_true_defect_comp_mean_vs_hard_fp_comp_mean": aucs["true_defect_comp_mean_vs_hard_fp_comp_mean"],
                "auc_true_defect_comp_mean_vs_outside_comp_mean": aucs["true_defect_comp_mean_vs_outside_comp_mean"],
            }
        )

    csv_path = save_dir / "matched_summary.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    labels = [row["host"] for row in rows]
    bar_plot(
        labels,
        [row["auc_true_defect_topk_vs_hard_fp_topk"] for row in rows],
        ylabel="AUC",
        title="Top-k Matched Separability: True Defect vs Hard FP",
        save_path=save_dir / "auc_true_defect_topk_vs_hard_fp_topk.png",
    )
    bar_plot(
        labels,
        [row["auc_true_defect_comp_peak_vs_hard_fp_comp_peak"] for row in rows],
        ylabel="AUC",
        title="Component Peak Separability: True Defect vs Hard FP",
        save_path=save_dir / "auc_true_defect_comp_peak_vs_hard_fp_comp_peak.png",
    )
    bar_plot(
        labels,
        [row["auc_true_defect_comp_peak_vs_outside_comp_peak"] for row in rows],
        ylabel="AUC",
        title="Component Peak Separability: True Defect vs Outside",
        save_path=save_dir / "auc_true_defect_comp_peak_vs_outside_comp_peak.png",
    )


if __name__ == "__main__":
    main()
