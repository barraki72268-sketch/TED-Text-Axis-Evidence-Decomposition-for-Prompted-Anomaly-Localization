from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[2]
PATCHCORE_SRC = ROOT / "neurips2026" / "patchcore-inspection" / "src"
ADPRETRAIN_ROOT = ROOT / "ADPretrain"
sys.path.insert(0, str(PATCHCORE_SRC))
sys.path.insert(0, str(ADPRETRAIN_ROOT))
sys.path.insert(0, str(ROOT))

import patchcore.common  # noqa: E402
import patchcore.patchcore  # noqa: E402
import patchcore.sampler  # noqa: E402
from ADPretrain.utils import calculate_metrics  # noqa: E402
from neurips2026.patchcore_adapters import VisAOneClassDataset, build_patchcore_backbone  # noqa: E402


def build_dataloaders(
    dataset_root: str,
    class_name: str,
    resize: int,
    imagesize: int,
    batch_size: int,
    num_workers: int,
    mean: tuple[float, float, float],
    std: tuple[float, float, float],
) -> tuple[DataLoader, DataLoader]:
    train_dataset = VisAOneClassDataset(
        root=dataset_root,
        class_name=class_name,
        split="train",
        resize=resize,
        imagesize=imagesize,
        mean=mean,
        std=std,
    )
    test_dataset = VisAOneClassDataset(
        root=dataset_root,
        class_name=class_name,
        split="test",
        resize=resize,
        imagesize=imagesize,
        mean=mean,
        std=std,
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    train_loader.name = f"visa_{class_name}"
    test_loader.name = f"visa_{class_name}"
    return train_loader, test_loader


def build_sampler(name: str, percentage: float, device: torch.device):
    if name == "identity":
        return patchcore.sampler.IdentitySampler()
    if name == "greedy_coreset":
        return patchcore.sampler.GreedyCoresetSampler(percentage, device)
    if name == "approx_greedy_coreset":
        return patchcore.sampler.ApproximateGreedyCoresetSampler(percentage, device)
    raise ValueError(f"Unsupported sampler: {name}")


def evaluate_oneclass(args: argparse.Namespace) -> list[dict]:
    device = torch.device(args.device)
    layers = tuple(int(layer) for layer in args.layers)
    layer_names = [f"layer{layer}" for layer in layers]
    results: list[dict] = []

    for backbone_name in args.backbones:
        backbone, cfg = build_patchcore_backbone(
            backbone_name=backbone_name,
            device=str(device),
            feature_op=args.feature_op,
            layers=layers,
            dataset_root=args.dataset_root,
            class_name=args.class_name,
            resize=args.resize,
            imagesize=args.imagesize,
            clip_teacher=args.clip_teacher,
            teacher_resize=args.teacher_resize,
            teacher_imagesize=args.teacher_imagesize,
            max_fit_normals=args.max_fit_normals,
            bridge_ridge=args.bridge_ridge,
            dino_ours_eta=args.dino_ours_eta,
            dino_gamma=args.dino_gamma,
            dino_topk_ratio=args.dino_topk_ratio,
            ir_ckpt_path=args.ir_ckpt_path,
            ir_fusion_beta=args.ir_fusion_beta,
        )
        train_loader, test_loader = build_dataloaders(
            dataset_root=args.dataset_root,
            class_name=args.class_name,
            resize=args.resize,
            imagesize=args.imagesize,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            mean=cfg.mean,
            std=cfg.std,
        )
        sampler = build_sampler(args.sampler, args.coreset_percentage, device)
        nn_method = patchcore.common.FaissNN(args.faiss_on_gpu, args.faiss_num_workers)
        detector = patchcore.patchcore.PatchCore(device)
        detector.load(
            backbone=backbone,
            layers_to_extract_from=layer_names,
            device=device,
            input_shape=train_loader.dataset.imagesize,
            pretrain_embed_dimension=args.pretrain_embed_dimension,
            target_embed_dimension=args.target_embed_dimension,
            patchsize=args.patchsize,
            patchstride=args.patchstride,
            anomaly_score_num_nn=args.anomaly_scorer_num_nn,
            featuresampler=sampler,
            nn_method=nn_method,
        )

        started = time.time()
        detector.fit(train_loader)
        scores, segmentations, labels_gt, masks_gt = detector.predict(test_loader)
        elapsed = time.time() - started

        image_scores = np.asarray(scores, dtype=np.float32)
        pixel_scores = np.asarray(segmentations, dtype=np.float32)
        gt_labels = np.asarray(labels_gt, dtype=np.int64)
        gt_masks = np.asarray(masks_gt, dtype=np.float32)
        if gt_masks.ndim == 4 and gt_masks.shape[1] == 1:
            gt_masks = gt_masks[:, 0]

        img_auc, img_ap, img_f1, pix_auc, pix_ap, pix_f1, pix_aupro = calculate_metrics(
            image_scores,
            pixel_scores,
            gt_labels,
            gt_masks.astype(bool),
            pro=True,
            only_max_value=True,
        )
        result = {
            "class_name": args.class_name,
            "backbone": backbone_name,
            "feature_op": args.feature_op,
            "layers": "-".join(str(layer) for layer in layers),
            "resize": args.resize,
            "imagesize": args.imagesize,
            "patchsize": args.patchsize,
            "patchstride": args.patchstride,
            "sampler": args.sampler,
            "coreset_percentage": args.coreset_percentage,
            "anomaly_scorer_num_nn": args.anomaly_scorer_num_nn,
            "train_count": len(train_loader.dataset),
            "test_count": len(test_loader.dataset),
            "i_auc": float(img_auc),
            "i_ap": float(img_ap),
            "i_f1": float(img_f1),
            "p_auc": float(pix_auc),
            "p_ap": float(pix_ap),
            "p_f1": float(pix_f1),
            "p_aupro": float(pix_aupro),
            "elapsed_sec": round(elapsed, 3),
        }
        results.append(result)
    return results


def write_outputs(results: list[dict], output_dir: Path, output_tag: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    if not results:
        return
    csv_path = output_dir / f"{output_tag}_summary.csv"
    json_path = output_dir / f"{output_tag}_summary.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)
    with json_path.open("w") as f:
        json.dump(results, f, indent=2)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["dinov2-large", "clip-large"],
        choices=["dinov2-large", "clip-large", "clip-promptad"],
    )
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12, 18])
    parser.add_argument("--feature_op", type=str, default="identity")
    parser.add_argument("--resize", type=int, default=256)
    parser.add_argument("--imagesize", type=int, default=224)
    parser.add_argument("--clip_teacher", type=str, default="clip-large", choices=["clip-large"])
    parser.add_argument("--teacher_resize", type=int, default=224)
    parser.add_argument("--teacher_imagesize", type=int, default=224)
    parser.add_argument("--max_fit_normals", type=int, default=40)
    parser.add_argument("--bridge_ridge", type=float, default=1e-3)
    parser.add_argument("--dino_ours_eta", type=float, default=1.0)
    parser.add_argument("--dino_gamma", type=float, default=1.0)
    parser.add_argument("--dino_topk_ratio", type=float, default=0.1)
    parser.add_argument("--ir_ckpt_path", type=str, default=None)
    parser.add_argument("--ir_fusion_beta", type=float, default=1.0)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--num_workers", type=int, default=8)
    parser.add_argument("--patchsize", type=int, default=3)
    parser.add_argument("--patchstride", type=int, default=1)
    parser.add_argument("--pretrain_embed_dimension", type=int, default=1024)
    parser.add_argument("--target_embed_dimension", type=int, default=1024)
    parser.add_argument("--anomaly_scorer_num_nn", type=int, default=1)
    parser.add_argument(
        "--sampler",
        type=str,
        default="approx_greedy_coreset",
        choices=["identity", "greedy_coreset", "approx_greedy_coreset"],
    )
    parser.add_argument("--coreset_percentage", type=float, default=0.1)
    parser.add_argument("--faiss_on_gpu", action="store_true")
    parser.add_argument("--faiss_num_workers", type=int, default=8)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument(
        "--output_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results"),
    )
    parser.add_argument(
        "--output_tag",
        type=str,
        default="patchcore_backbone_swap_oneclass",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    results = evaluate_oneclass(args)
    output_dir = Path(args.output_dir)
    write_outputs(results, output_dir, f"{args.output_tag}_{args.class_name}")
    for row in results:
        print(
            f"{row['class_name']} | {row['backbone']} | layers={row['layers']} | "
            f"I-AUC={row['i_auc']:.4f} | P-AUC={row['p_auc']:.4f} | P-AUPRO={row['p_aupro']:.4f}"
        )


if __name__ == "__main__":
    main()
