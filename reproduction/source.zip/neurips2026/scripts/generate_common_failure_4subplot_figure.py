from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026" / "results"
PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
PRESET_LABELS = ["VisA→MVTec", "MVTec→VisA", "MVTec→MPDD", "MVTec→BTAD"]
HOSTS = ["AnomalyCLIP", "AdaCLIP", "AdaptCLIP", "FAPrompt"]
HOST_KEYS = {
    "AnomalyCLIP": "anomalyclip",
    "AdaCLIP": "adaclip",
    "AdaptCLIP": "adaptclip",
    "FAPrompt": "faprompt",
}
METRICS = [
    ("inside_outside_gap", "Weak Defect Focus", "raw", "lower_is_worse"),
    ("outside_inside_ratio", "Outside / Inside Leakage", "log10", "higher_is_worse"),
    ("normal_topk_mean", "Normal Top-1% Activation", "raw", "higher_is_worse"),
    ("normal_map_mean", "Normal Mean Activation", "log10", "higher_is_worse"),
]


def load_summary(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def format_value(metric: str, value: float) -> str:
    if metric == "outside_inside_ratio":
        return f"{value:.2f}" if value < 10 else f"{value:.1f}"
    if metric == "normal_map_mean":
        return f"{value:.1e}"
    return f"{value:.3f}"


def transform_for_color(metric: str, transform: str, raw: np.ndarray) -> np.ndarray:
    if transform == "log10":
        raw = np.log10(np.maximum(raw, 1e-10))
    if metric == "inside_outside_gap":
        return -raw
    return raw


def normalize_for_heatmap(mat: np.ndarray) -> np.ndarray:
    valid = np.isfinite(mat)
    if not valid.any():
        return np.zeros_like(mat)
    out = np.zeros_like(mat, dtype=np.float32)
    vals = mat[valid]
    lo = float(vals.min())
    hi = float(vals.max())
    if hi - lo < 1e-12:
        out[valid] = 0.5
        return out
    out[valid] = (vals - lo) / (hi - lo)
    return out


def main() -> None:
    parser = argparse.ArgumentParser("Generate 1x4 common-failure figure across 4 hosts")
    parser.add_argument("--run_tag", type=str, default="rerun1")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULT_ROOT / "common_failure_4subplot_figure"),
    )
    args = parser.parse_args()

    data: dict[str, dict[str, dict]] = {}
    for host_name, host_key in HOST_KEYS.items():
        per_preset = {}
        for preset in PRESETS:
            path = RESULT_ROOT / f"common_failure_{host_key}_{preset}_{args.run_tag}" / "summary.json"
            payload = load_summary(path)
            per_preset[preset] = payload["summary"]
        data[host_name] = per_preset

    fig, axes = plt.subplots(1, 4, figsize=(22, 5.6), constrained_layout=True)
    cmap = plt.get_cmap("magma")

    per_metric_payload = {}
    for ax, (metric, title, transform, _) in zip(axes, METRICS):
        raw = np.array(
            [[float(data[host_name][preset][metric]) for preset in PRESETS] for host_name in HOSTS],
            dtype=np.float32,
        )
        color_base = transform_for_color(metric, transform, raw.copy())
        heat = normalize_for_heatmap(color_base)
        per_metric_payload[metric] = {
            "raw": raw.tolist(),
            "color_base": color_base.tolist(),
            "heat": heat.tolist(),
        }

        im = ax.imshow(heat, cmap=cmap, vmin=0.0, vmax=1.0, aspect="auto")
        ax.set_xticks(np.arange(len(PRESETS)), PRESET_LABELS, rotation=20, ha="right")
        ax.set_yticks(np.arange(len(HOSTS)), HOSTS)
        ax.set_title(title)
        ax.set_xticks(np.arange(-0.5, len(PRESETS), 1), minor=True)
        ax.set_yticks(np.arange(-0.5, len(HOSTS), 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=1.0)
        ax.tick_params(which="minor", bottom=False, left=False)
        for i, host_name in enumerate(HOSTS):
            for j, preset in enumerate(PRESETS):
                color = "white" if heat[i, j] > 0.52 else "black"
                ax.text(
                    j,
                    i,
                    format_value(metric, raw[i, j]),
                    ha="center",
                    va="center",
                    fontsize=9,
                    color=color,
                )
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
        cbar.ax.tick_params(labelsize=8)
        cbar.set_label("Failure intensity", fontsize=9)

    fig.suptitle("Common Dense Localization Failure Across CLIP-Based AD Hosts", fontsize=15)

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    png_path = save_dir / "common_failure_4subplot_heatmap.png"
    pdf_path = save_dir / "common_failure_4subplot_heatmap.pdf"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)

    with open(save_dir / "common_failure_4subplot.json", "w") as f:
        json.dump({"run_tag": args.run_tag, "per_host": data, "per_metric": per_metric_payload}, f, indent=2)

    print(json.dumps({"png": str(png_path), "pdf": str(pdf_path)}, indent=2))


if __name__ == "__main__":
    main()
