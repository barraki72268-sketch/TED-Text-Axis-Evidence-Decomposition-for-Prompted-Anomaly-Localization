from __future__ import annotations

import sys
import csv
from argparse import Namespace
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from generate_rawclip_qualitative import (  # noqa: E402
    GenericMetaDataset,
    build_transforms,
    compute_maps,
    compute_pixel_metrics,
    create_winclip_raw_backbone,
    load_bank_cache,
    overlay_gt,
    overlay_heatmap,
    resize_score_map,
)


def materialize_item(ds: GenericMetaDataset, target_root: Path, image_transform, mask_transform, rel_suffix: str) -> dict:
    meta = None
    for cand in ds.items:
        if str(cand["img_path"]).endswith(rel_suffix):
            meta = cand
            break
    if meta is None:
        raise RuntimeError(f"Could not find {rel_suffix}")

    img_path = target_root / meta["img_path"]
    img = Image.open(img_path).convert("RGB")
    anomaly = int(meta["anomaly"])
    mask_path = meta.get("mask_path")
    if anomaly == 0 or not mask_path:
        mask = Image.fromarray(np.zeros((img.size[1], img.size[0]), dtype=np.uint8), mode="L")
    else:
        raw_mask = np.array(Image.open(target_root / mask_path).convert("L")) > 0
        mask = Image.fromarray(raw_mask.astype(np.uint8) * 255, mode="L")

    return {
        "img": image_transform(img),
        "img_mask": mask_transform(mask),
        "cls_name": meta["cls_name"],
        "anomaly": anomaly,
        "img_path": str(img_path),
        "raw_image": np.array(img.resize((336, 336), resample=Image.BILINEAR)),
    }


def add_metric_text(ax, title: str, metrics: dict[str, float | None]) -> None:
    def fmt(v: float | None) -> str:
        return "--" if v is None else f"{100.0 * v:.1f}"

    ax.set_title(title, fontsize=12, fontweight="bold", pad=4)
    ax.text(
        0.04,
        0.96,
        f"P-AUC {fmt(metrics['auroc'])}\nPRO {fmt(metrics['pro'])}\nAP {fmt(metrics['ap'])}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#DDDDDD", "alpha": 0.88, "pad": 3.0},
    )


def load_support_ablation_means() -> tuple[list[str], list[float]]:
    csv_path = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables" / "raw_vlm_support_ablation_summary_rawclip_support_ablation_maponly_20260505.csv"
    with csv_path.open("r", newline="") as f:
        rows = list(csv.DictReader(f))
    return (
        ["Raw prompt", "Full-feature support", "Text-axis support"],
        [
            float(np.mean([float(row["raw_auc_mean"]) for row in rows])),
            float(np.mean([float(row["visual_auc_mean"]) for row in rows])),
            float(np.mean([float(row["text_auc_mean"]) for row in rows])),
        ],
    )


def main() -> None:
    out_dir = ROOT / "supp_fig"
    out_dir.mkdir(parents=True, exist_ok=True)
    target_root = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
    args = Namespace(
        source_root="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        target_root=str(target_root),
        target_split="test",
        backbone="ViT-L-14-336",
        pretrained_dataset="openai",
        image_size=336,
        prompt_mode="class",
        features_list=[6, 12, 18, 24],
        bank_cache_path=str(ROOT / "neurips2026" / "results" / "bank_cache" / "rawclip_calib_vitl336_mvtec.pt"),
        sigma=4.0,
        tau=20.0,
        image_score_topk=0.01,
        device="cuda:0" if torch.cuda.is_available() else "cpu",
    )

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=args.device,
        img_resize=args.image_size,
        img_cropsize=args.image_size,
    )
    image_transform, mask_transform = build_transforms(args.image_size)
    fp_banks, def_banks, _, _ = load_bank_cache(Path(args.bank_cache_path))
    ds = GenericMetaDataset(
        root=args.target_root,
        image_transform=image_transform,
        mask_transform=mask_transform,
        split=args.target_split,
        class_name="macaroni2",
    )
    item = materialize_item(ds, target_root, image_transform, mask_transform, "macaroni2/test/bad/004.JPG")
    baseline_map, ted_map, baseline_img_score, ted_img_score = compute_maps(backbone, item, fp_banks, def_banks, args)

    image_np = item["raw_image"]
    mask_np = item["img_mask"][0].numpy()
    baseline_score = resize_score_map(baseline_map, mask_np.shape)
    ted_score = resize_score_map(np.clip(ted_map, 0.0, None), mask_np.shape)
    baseline_metrics = compute_pixel_metrics(baseline_score, mask_np)
    ted_metrics = compute_pixel_metrics(ted_score, mask_np)

    fig, axes = plt.subplots(1, 4, figsize=(12.1, 3.15), constrained_layout=True, gridspec_kw={"width_ratios": [1.0, 1.0, 1.0, 1.0]})
    panels = [
        overlay_gt(image_np, mask_np),
        overlay_heatmap(image_np, baseline_score, alpha=0.50, cmap_name="magma"),
        overlay_heatmap(image_np, ted_score, alpha=0.50, cmap_name="Reds", nonnegative_only=True),
    ]
    titles = ["Input + GT", "Raw prompt map", "TED map"]
    for ax, panel, title in zip(axes[:3], panels, titles):
        ax.imshow(panel)
        ax.set_axis_off()
        ax.set_title(title, fontsize=12, fontweight="bold", pad=4)
    add_metric_text(axes[1], "Raw prompt map", baseline_metrics)
    add_metric_text(axes[2], "TED map", ted_metrics)

    ax = axes[3]
    labels, vals = load_support_ablation_means()
    colors = ["#777777", "#E0A13A", "#C62828"]
    x = np.arange(len(labels))
    ax.bar(x, vals, color=colors, width=0.68, alpha=0.9)
    ax.set_xticks(x, labels, rotation=18, ha="right", fontsize=8.5, fontweight="bold")
    ax.set_ylabel("D vs H-FP AUC", fontsize=10, fontweight="bold")
    ax.set_title("Evidence readout", fontsize=12, fontweight="bold", pad=4)
    ax.set_ylim(0.0, 82.0)
    ax.grid(axis="y", alpha=0.22)
    for xi, v in zip(x, vals):
        ax.text(xi, v + 1.2, f"{v:.1f}", ha="center", va="bottom", fontsize=9, fontweight="bold")
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)

    fig.savefig(out_dir / "raw_vlm_clean_heatmap_recovery_20260505.pdf", bbox_inches="tight")
    fig.savefig(out_dir / "raw_vlm_clean_heatmap_recovery_20260505.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
