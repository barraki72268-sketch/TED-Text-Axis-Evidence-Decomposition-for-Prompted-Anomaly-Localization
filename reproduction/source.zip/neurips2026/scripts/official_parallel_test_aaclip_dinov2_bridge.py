#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.models.dino import DinoModel  # noqa: E402
from neurips2026.scripts.official_parallel_test_aaclip import (  # noqa: E402
    PRESET_CONFIGS,
    _add_aaclip_to_syspath,
    build_transforms,
    calculate_aupro,
    ensure_aaclip_pretrained_weight,
    load_state_project_crop,
    logmeanexp_negative_sqdist_1d,
    mean_text_anomaly_axis,
    patch_score_grid,
    prescore_rectify_seg_tokens,
    setup_seed,
)
from neurips2026.scripts.official_parallel_test_dinov2_bridge import (  # noqa: E402
    DualMetaDataset,
    build_dino_transform,
    downsample_mask,
    extract_dino_layers,
    fit_ridge_bridge,
    mask_transform,
    project_dino,
    topk_mean_np,
)


def safe_auc_percent(y_true: np.ndarray, y_score: np.ndarray) -> float:
    y_true = y_true.astype(np.uint8).reshape(-1)
    y_score = y_score.astype(np.float32).reshape(-1)
    if y_true.size == 0 or y_true.min() == y_true.max():
        return 0.0
    return float(roc_auc_score(y_true, y_score) * 100.0)


def safe_ap_percent(y_true: np.ndarray, y_score: np.ndarray) -> float:
    y_true = y_true.astype(np.uint8).reshape(-1)
    y_score = y_score.astype(np.float32).reshape(-1)
    if y_true.size == 0 or y_true.min() == y_true.max():
        return 0.0
    return float(average_precision_score(y_true, y_score) * 100.0)


def compute_metrics_percent(
    masks: np.ndarray,
    labels: np.ndarray,
    maps: np.ndarray,
    img_scores: np.ndarray,
    aupro_max_step: int,
) -> dict:
    return {
        "pixel_auc": safe_auc_percent(masks.reshape(-1), maps.reshape(-1)),
        "pixel_ap": safe_ap_percent(masks.reshape(-1), maps.reshape(-1)),
        "pixel_pro": calculate_aupro(masks, maps, max_step=aupro_max_step),
        "image_auc": safe_auc_percent(labels, img_scores),
        "image_ap": safe_ap_percent(labels, img_scores),
    }


def load_aaclip_model(
    *,
    model_name: str,
    pretrained: str,
    img_size: int,
    levels: list[int],
    ckpt_dir: str,
    adapter_load_mode: str,
    device: torch.device,
):
    _add_aaclip_to_syspath()
    ensure_aaclip_pretrained_weight()
    from model.adapter import AdaptedCLIP
    from model.clip import create_model

    clip_model = create_model(
        model_name=model_name,
        img_size=img_size,
        device=device,
        pretrained=pretrained,
        force_image_size=img_size,
        require_pretrained=True,
    )
    clip_model.eval()
    model = AdaptedCLIP(
        clip_model=clip_model,
        text_adapt_weight=0.1,
        image_adapt_weight=0.1,
        text_adapt_until=3,
        image_adapt_until=6,
        levels=levels,
        relu=False,
    ).to(device)
    model.eval()

    image_ckpt = os.path.join(ckpt_dir, "image_adapter.pth")
    text_ckpt = os.path.join(ckpt_dir, "text_adapter.pth")
    if not os.path.exists(image_ckpt):
        raise FileNotFoundError(image_ckpt)
    image_state = torch.load(image_ckpt, map_location="cpu")["image_adapter"]
    image_info = load_state_project_crop(model.image_adapter, image_state, mode=adapter_load_mode)
    text_info = {"loaded": 0, "cropped": 0, "skipped": 0, "missing": 0}
    if os.path.exists(text_ckpt):
        text_state = torch.load(text_ckpt, map_location="cpu")["text_adapter"]
        text_info = load_state_project_crop(model.text_adapter, text_state, mode=adapter_load_mode)
    for p in model.parameters():
        p.requires_grad = False
    print(
        json.dumps(
            {
                "stage": "aaclip_model_ready",
                "model_name": model_name,
                "pretrained": pretrained,
                "levels": levels,
                "output_dim": int(model.output_dim),
                "image_adapter_load": image_info,
                "text_adapter_load": text_info,
            }
        ),
        flush=True,
    )
    return model


@torch.no_grad()
def collect_bridge_pairs(
    *,
    dino: DinoModel,
    aaclip_model,
    ds: DualMetaDataset,
    dino_layers: list[int],
    device: torch.device,
    max_fit_per_class: int,
    max_patches_per_image: int,
    seed: int,
) -> dict[int, tuple[torch.Tensor, torch.Tensor]]:
    rng = random.Random(seed)
    per_class = {cls: 0 for cls in ds.obj_list}
    xs = {i: [] for i in range(len(dino_layers))}
    ys = {i: [] for i in range(len(dino_layers))}
    for idx, item_meta in enumerate(ds.items):
        if all(count >= max_fit_per_class for count in per_class.values()):
            break
        cls = item_meta["cls_name"]
        if per_class[cls] >= max_fit_per_class:
            continue
        per_class[cls] += 1
        item = ds[idx]
        dino_img = item["dino"].unsqueeze(0).to(device)
        aa_img = item["clip"].unsqueeze(0).to(device)
        dino_out = extract_dino_layers(dino, dino_img, dino_layers)
        aa_tokens, _ = aaclip_model(aa_img)
        for i, layer in enumerate(dino_layers):
            x = F.normalize(dino_out[layer][0].float(), dim=-1).cpu()
            y = F.normalize(aa_tokens[i][0].float(), dim=-1).cpu()
            n = min(x.shape[0], y.shape[0], max_patches_per_image)
            idx = torch.tensor(rng.sample(range(min(x.shape[0], y.shape[0])), n), dtype=torch.long)
            xs[i].append(x[idx])
            ys[i].append(y[idx])
    return {i: (torch.cat(xs[i], dim=0), torch.cat(ys[i], dim=0)) for i in xs}


@torch.no_grad()
def collect_source_banks(
    *,
    dino: DinoModel,
    aaclip_model,
    source_dataset: str,
    source_root: str,
    dino_transform,
    aa_transform,
    mask_t,
    bridges: dict[int, torch.Tensor],
    dino_layers: list[int],
    device: torch.device,
    max_fp_per_class: int,
    max_defect_per_class: int,
    normal_topk_frac: float,
    defect_topk_frac: float,
    source_limit_per_class: int,
) -> dict:
    from forward_utils import get_adapted_text_embedding

    meta = json.loads((Path(source_root) / "meta.json").read_text())
    class_names = sorted(meta["train"].keys())
    text_embeddings = get_adapted_text_embedding(aaclip_model, source_dataset, device)
    bank_fp = {i: [] for i in range(len(dino_layers))}
    bank_def = {i: [] for i in range(len(dino_layers))}
    for cls in class_names:
        text_feature = text_embeddings[cls]
        normal_ds = DualMetaDataset(source_root, dino_transform, aa_transform, mask_t, "train", class_name=cls, normal_only=True)
        anomaly_ds = DualMetaDataset(source_root, dino_transform, aa_transform, mask_t, "test", class_name=cls, anomaly_only=True)
        if source_limit_per_class > 0:
            normal_ds.items = normal_ds.items[:source_limit_per_class]
            anomaly_ds.items = anomaly_ds.items[:source_limit_per_class]
        fp_parts = {i: [] for i in range(len(dino_layers))}
        def_parts = {i: [] for i in range(len(dino_layers))}
        for item in normal_ds:
            dino_img = item["dino"].unsqueeze(0).to(device)
            dino_out = extract_dino_layers(dino, dino_img, dino_layers)
            for i, layer in enumerate(dino_layers):
                z = project_dino(dino_out[layer][0], bridges[i])
                score = patch_score_grid(z.unsqueeze(0), text_feature)[0]
                k = max(1, int(math.ceil(score.numel() * normal_topk_frac)))
                fp_parts[i].append(z[torch.topk(score, k=k, largest=True).indices].detach().cpu())
        for item in anomaly_ds:
            dino_img = item["dino"].unsqueeze(0).to(device)
            mask = item["mask"].unsqueeze(0).to(device)
            dino_out = extract_dino_layers(dino, dino_img, dino_layers)
            for i, layer in enumerate(dino_layers):
                z = project_dino(dino_out[layer][0], bridges[i])
                side = int(round(math.sqrt(z.shape[0])))
                pos = torch.nonzero(downsample_mask(mask, side)[0], as_tuple=False).flatten()
                if pos.numel() == 0:
                    continue
                score = patch_score_grid(z.unsqueeze(0), text_feature)[0][pos]
                k = max(1, int(math.ceil(pos.numel() * defect_topk_frac)))
                k = min(k, pos.numel())
                def_parts[i].append(z[pos[torch.topk(score, k=k, largest=True).indices]].detach().cpu())
        for i in range(len(dino_layers)):
            fp = torch.cat(fp_parts[i], dim=0) if fp_parts[i] else torch.empty(0, bridges[i].shape[1])
            de = torch.cat(def_parts[i], dim=0) if def_parts[i] else torch.empty(0, bridges[i].shape[1])
            if fp.shape[0] > max_fp_per_class:
                fp = fp[torch.randperm(fp.shape[0])[:max_fp_per_class]]
            if de.shape[0] > max_defect_per_class:
                de = de[torch.randperm(de.shape[0])[:max_defect_per_class]]
            bank_fp[i].append(fp)
            bank_def[i].append(de)
        print(json.dumps({"stage": "source_class_done", "class_name": cls}), flush=True)
    return {
        "fp": [F.normalize(torch.cat(bank_fp[i], dim=0).float(), dim=-1) for i in range(len(dino_layers))],
        "defect": [F.normalize(torch.cat(bank_def[i], dim=0).float(), dim=-1) for i in range(len(dino_layers))],
    }


@torch.no_grad()
def evaluate_target(
    *,
    dino: DinoModel,
    aaclip_model,
    source_dataset: str,
    target_dataset: str,
    target_root: str,
    dino_transform,
    aa_transform,
    mask_t,
    bridges: dict[int, torch.Tensor],
    banks: dict,
    dino_layers: list[int],
    device: torch.device,
    alphas: list[float],
    image_size: int,
    support_tau: float,
    gate_sharpness: float,
    fp_weight: float,
    image_score_topk: float,
    aupro_max_step: int,
    target_limit_per_class: int,
) -> dict:
    from dataset.constants import DOMAINS
    from forward_utils import calculate_similarity_map, get_adapted_text_embedding

    ds = DualMetaDataset(target_root, dino_transform, aa_transform, mask_t, "test")
    if target_limit_per_class > 0:
        kept = []
        counts = {cls: 0 for cls in ds.obj_list}
        for item in ds.items:
            cls = item["cls_name"]
            if counts[cls] < target_limit_per_class:
                kept.append(item)
                counts[cls] += 1
        ds.items = kept
    text_embeddings = get_adapted_text_embedding(aaclip_model, target_dataset, device)
    source_text_embeddings = get_adapted_text_embedding(aaclip_model, source_dataset, device)
    source_axis = mean_text_anomaly_axis(source_text_embeddings)
    def_proj = [F.normalize(x.to(device), dim=-1) @ source_axis for x in banks["defect"]]
    fp_proj = [F.normalize(x.to(device), dim=-1) @ source_axis for x in banks["fp"]]
    results = {
        "baseline": {cls: {"maps": [], "imgs": [], "labels": [], "masks": []} for cls in ds.obj_list},
        **{f"prescore_rectify_alpha_{a:g}": {cls: {"maps": [], "imgs": [], "labels": [], "masks": []} for cls in ds.obj_list} for a in alphas},
    }
    for item in ds:
        cls = item["class_name"]
        text_feature = text_embeddings[cls]
        target_axis = F.normalize(text_feature[:, 1] - text_feature[:, 0], dim=0)
        dino_img = item["dino"].unsqueeze(0).to(device)
        mask = item["mask"].numpy()[0].astype(np.float32)
        label = int(item["label"].item())
        dino_out = extract_dino_layers(dino, dino_img, dino_layers)
        baseline_layers = []
        rect_layers = {a: [] for a in alphas}
        for i, layer in enumerate(dino_layers):
            z = project_dino(dino_out[layer][0], bridges[i]).unsqueeze(0)
            base_map = calculate_similarity_map(z, text_feature, image_size, test=True, domain=DOMAINS[target_dataset])
            baseline_layers.append(base_map[:, 0])
            query_proj = z @ source_axis
            q_def = logmeanexp_negative_sqdist_1d(query_proj, def_proj[i], tau=support_tau)
            q_fp = logmeanexp_negative_sqdist_1d(query_proj, fp_proj[i], tau=support_tau)
            for alpha in alphas:
                rect = prescore_rectify_seg_tokens(
                    tokens=z,
                    q_def=q_def,
                    q_fp=q_fp,
                    target_axis=target_axis,
                    alpha=alpha,
                    fp_weight=fp_weight,
                    gate_sharpness=gate_sharpness,
                )
                rect_map = calculate_similarity_map(rect, text_feature, image_size, test=True, domain=DOMAINS[target_dataset])
                rect_layers[alpha].append(rect_map[:, 0])
        base_np = torch.stack(baseline_layers).mean(dim=0).detach().cpu().numpy()
        results["baseline"][cls]["maps"].append(base_np[0])
        results["baseline"][cls]["imgs"].append(topk_mean_np(base_np, image_score_topk)[0])
        results["baseline"][cls]["labels"].append(label)
        results["baseline"][cls]["masks"].append(mask)
        for alpha in alphas:
            rect_np = torch.stack(rect_layers[alpha]).mean(dim=0).detach().cpu().numpy()
            key = f"prescore_rectify_alpha_{alpha:g}"
            results[key][cls]["maps"].append(rect_np[0])
            results[key][cls]["imgs"].append(topk_mean_np(rect_np, image_score_topk)[0])
            results[key][cls]["labels"].append(label)
            results[key][cls]["masks"].append(mask)

    rows = []
    mean = {}
    for mode, by_cls in results.items():
        vals = []
        for cls, pack in by_cls.items():
            maps = np.stack(pack["maps"], axis=0).astype(np.float32)
            masks = np.stack(pack["masks"], axis=0).astype(np.float32)
            labels = np.asarray(pack["labels"], dtype=np.int64)
            imgs = np.asarray(pack["imgs"], dtype=np.float32)
            metrics = compute_metrics_percent(masks, labels, maps, imgs, aupro_max_step)
            rows.append({"mode": mode, "class_name": cls, **metrics})
            vals.append(metrics)
        mean[mode] = {k: float(np.nanmean([v[k] for v in vals])) for k in vals[0]}
    return {"rows": rows, "mean": mean}


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", required=True, choices=sorted(PRESET_CONFIGS))
    ap.add_argument("--dino_backbone", default="dinov2-base", choices=["dinov2-base", "dinov2-large"])
    ap.add_argument("--dino_layers", default="6,12")
    ap.add_argument("--model_name", default="ViT-B-16-plus-240")
    ap.add_argument("--pretrained", default="laion400m_e32")
    ap.add_argument("--adapter_load_mode", default="project_crop", choices=["strict", "project_crop", "skip"])
    ap.add_argument("--aa_levels", default="6,12")
    ap.add_argument("--image_size", type=int, default=518)
    ap.add_argument("--batch_size", type=int, default=1)
    ap.add_argument("--fit_max_per_class", type=int, default=2)
    ap.add_argument("--fit_max_patches_per_image", type=int, default=128)
    ap.add_argument("--ridge", type=float, default=1e-3)
    ap.add_argument("--max_fp_per_class", type=int, default=512)
    ap.add_argument("--max_defect_per_class", type=int, default=512)
    ap.add_argument("--source_limit_per_class", type=int, default=0)
    ap.add_argument("--target_limit_per_class", type=int, default=0)
    ap.add_argument("--normal_topk_frac", type=float, default=0.01)
    ap.add_argument("--defect_topk_frac", type=float, default=0.25)
    ap.add_argument("--support_tau", type=float, default=0.1)
    ap.add_argument("--gate_sharpness", type=float, default=3.0)
    ap.add_argument("--fp_weight", type=float, default=1.0)
    ap.add_argument("--alphas", default="-0.5")
    ap.add_argument("--image_score_topk", type=float, default=0.10)
    ap.add_argument("--aupro_max_step", type=int, default=50)
    ap.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--save_dir", required=True)
    return ap.parse_args()


def main():
    args = parse_args()
    setup_seed(args.seed)
    cfg = PRESET_CONFIGS[args.preset]
    device = torch.device(args.device)
    dino_layers = [int(x) for x in args.dino_layers.split(",") if x.strip()]
    aa_levels = [int(x) for x in args.aa_levels.split(",") if x.strip()]
    if len(dino_layers) != len(aa_levels):
        raise ValueError("--dino_layers and --aa_levels must have the same length")
    dino = DinoModel(args.dino_backbone, device=str(device)).eval()
    dino.visual_encoder = dino.visual_encoder.to(device)
    aaclip_model = load_aaclip_model(
        model_name=args.model_name,
        pretrained=args.pretrained,
        img_size=args.image_size,
        levels=aa_levels,
        ckpt_dir=cfg["ckpt_dir"],
        adapter_load_mode=args.adapter_load_mode,
        device=device,
    )
    dino_t = build_dino_transform(args.image_size)
    aa_t, _ = build_transforms(args.image_size)
    mask_t = mask_transform(args.image_size)
    fit_ds = DualMetaDataset(cfg["source_root"], dino_t, aa_t, mask_t, "train", normal_only=True)
    pairs = collect_bridge_pairs(
        dino=dino,
        aaclip_model=aaclip_model,
        ds=fit_ds,
        dino_layers=dino_layers,
        device=device,
        max_fit_per_class=args.fit_max_per_class,
        max_patches_per_image=args.fit_max_patches_per_image,
        seed=args.seed,
    )
    bridges = {i: fit_ridge_bridge(x, y, args.ridge).to(device) for i, (x, y) in pairs.items()}
    print(json.dumps({"stage": "bridge_fit_done", "dino_layers": dino_layers, "aa_levels": aa_levels}), flush=True)
    banks = collect_source_banks(
        dino=dino,
        aaclip_model=aaclip_model,
        source_dataset=cfg["source_dataset"],
        source_root=cfg["source_root"],
        dino_transform=dino_t,
        aa_transform=aa_t,
        mask_t=mask_t,
        bridges=bridges,
        dino_layers=dino_layers,
        device=device,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        normal_topk_frac=args.normal_topk_frac,
        defect_topk_frac=args.defect_topk_frac,
        source_limit_per_class=args.source_limit_per_class,
    )
    print(json.dumps({"stage": "source_bank_done"}), flush=True)
    alphas = [float(x) for x in args.alphas.split(",") if x.strip()]
    result = evaluate_target(
        dino=dino,
        aaclip_model=aaclip_model,
        source_dataset=cfg["source_dataset"],
        target_dataset=cfg["target_dataset"],
        target_root=cfg["target_root"],
        dino_transform=dino_t,
        aa_transform=aa_t,
        mask_t=mask_t,
        bridges=bridges,
        banks=banks,
        dino_layers=dino_layers,
        device=device,
        alphas=alphas,
        image_size=args.image_size,
        support_tau=args.support_tau,
        gate_sharpness=args.gate_sharpness,
        fp_weight=args.fp_weight,
        image_score_topk=args.image_score_topk,
        aupro_max_step=args.aupro_max_step,
        target_limit_per_class=args.target_limit_per_class,
    )
    result.update(
        {
            "preset": args.preset,
            "source_dataset": cfg["source_dataset"],
            "target_dataset": cfg["target_dataset"],
            "host": "AA-CLIP",
            "image_backbone": args.dino_backbone,
            "bridge_target": args.model_name,
            "dino_layers": dino_layers,
            "aa_levels": aa_levels,
            "image_size": args.image_size,
            "alphas": alphas,
            "image_score_mode": "map_topk",
            "aupro_max_step": args.aupro_max_step,
            "source_limit_per_class": args.source_limit_per_class,
            "target_limit_per_class": args.target_limit_per_class,
        }
    )
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    out = save_dir / "summary.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result["mean"], indent=2), flush=True)
    print(f"[OK] wrote {out}", flush=True)


if __name__ == "__main__":
    main()
