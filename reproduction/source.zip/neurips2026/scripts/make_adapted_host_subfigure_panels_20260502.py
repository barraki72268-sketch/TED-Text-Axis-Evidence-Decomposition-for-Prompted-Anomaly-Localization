#!/usr/bin/env python3
from __future__ import annotations

import csv
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

COMPACT_CSV = OUT / "adapted_host_b_t_c_records_20260502.csv"
FAPROMPT_TTED_CSV = OUT / "faprompt_t_ted_prescore_separate_20260502.csv"
MAIN_HOSTS = ("AA-CLIP", "FAPrompt", "AdaCLIP", "AdaptCLIP", "BayesPFL")
TARGETS = ("MVTec", "VisA", "MPDD", "BTAD")
PIXEL_METRICS = ("p_auc", "p_pro", "p_ap")
SUMMARY_METRICS = ("p_auc", "p_pro", "p_ap", "i_auc")
METRIC_LABELS = {
    "i_auc": "I-AUC",
    "p_auc": "P-AUC",
    "p_pro": "P-PRO",
    "p_ap": "P-AP",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="") as f:
        return list(csv.DictReader(f))


def fnum(value: str | None) -> float | None:
    if value in (None, "", "None"):
        return None
    out = float(value)
    if math.isnan(out):
        return None
    return out


def mean(values: list[float | None]) -> float | None:
    clean = [v for v in values if v is not None]
    return None if not clean else sum(clean) / len(clean)


def load_compact() -> list[dict]:
    rows = []
    for row in read_csv(COMPACT_CSV):
        out = dict(row)
        for key in ("baseline", "t_ted", "c_ted", "delta_t", "delta_c"):
            out[key] = fnum(row.get(key))
        rows.append(out)
    return rows


def faprompt_tted_metric_deltas() -> dict[str, float]:
    rows = read_csv(FAPROMPT_TTED_CSV)
    values: dict[str, float] = {}
    for metric in SUMMARY_METRICS:
        deltas = []
        for row in rows:
            base = fnum(row.get(f"baseline_{metric}"))
            tted = fnum(row.get(f"t_ted_{metric}"))
            if base is not None and tted is not None:
                deltas.append(tted - base)
        if deltas:
            values[metric] = mean(deltas) or 0.0
    return values


def host_metric_matrix(compact: list[dict], method: str) -> np.ndarray:
    delta_key = "delta_t" if method == "t" else "delta_c"
    matrix = np.full((len(MAIN_HOSTS), len(SUMMARY_METRICS)), np.nan)
    faprompt_t = faprompt_tted_metric_deltas() if method == "t" else {}
    for i, host in enumerate(MAIN_HOSTS):
        for j, metric in enumerate(SUMMARY_METRICS):
            if host == "FAPrompt" and method == "t" and metric in faprompt_t:
                matrix[i, j] = faprompt_t[metric]
                continue
            deltas = [
                row[delta_key]
                for row in compact
                if row["host"] == host and row["metric"] == metric and row[delta_key] is not None
            ]
            value = mean(deltas)
            if value is not None:
                matrix[i, j] = value
    return matrix


def cted_metric_deltas(compact: list[dict]) -> dict[str, float]:
    values: dict[str, float] = {}
    for metric in SUMMARY_METRICS:
        subset = [
            row
            for row in compact
            if row["host"] in MAIN_HOSTS
            and row["metric"] == metric
            and row["delta_c"] is not None
        ]
        values[metric] = mean([row["delta_c"] for row in subset]) or 0.0
    return values


def cted_target_ppro_values(compact: list[dict]) -> dict[str, float]:
    values = {}
    for target in TARGETS:
        deltas = [
            row["delta_c"]
            for row in compact
            if row["host"] in MAIN_HOSTS
            and row["target"] == target
            and row["metric"] == "p_pro"
            and row["delta_c"] is not None
        ]
        values[target] = mean(deltas) or 0.0
    return values


def style_axes(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", color="#E7E1D5", linewidth=0.7)
    ax.set_axisbelow(True)


def annotate_bars(ax: plt.Axes, bars, values: list[float], dy: float = 0.35) -> None:
    for bar, value in zip(bars, values):
        label = f"{value:+.1f}"
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + dy if value >= 0 else value - dy,
            label,
            ha="center",
            va="bottom" if value >= 0 else "top",
            fontsize=7,
        )


def fmt_cell(value: float) -> str:
    if not np.isfinite(value):
        return "--"
    if abs(value) < 0.05:
        return "0"
    return f"{value:+.1f}"


def save_panel(fig: plt.Figure, name: str) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(FIG / f"{name}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def panel_response_map(matrix: np.ndarray, title: str, *, ax: plt.Axes | None = None) -> plt.Axes:
    own = ax is None
    if own:
        _, ax = plt.subplots(figsize=(1.95, 1.55))
    assert ax is not None
    finite = matrix[np.isfinite(matrix)]
    vmax = max(1.0, float(np.percentile(np.abs(finite), 92))) if finite.size else 1.0
    ax.imshow(matrix, cmap="RdBu", vmin=-vmax, vmax=vmax, aspect="auto")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, fmt_cell(matrix[i, j]), ha="center", va="center", fontsize=6.3)
    ax.set_title(title)
    ax.set_xticks(np.arange(len(SUMMARY_METRICS)))
    ax.set_xticklabels([METRIC_LABELS[m] for m in SUMMARY_METRICS], rotation=30, ha="right")
    ax.set_yticks(np.arange(len(MAIN_HOSTS)))
    ax.set_yticklabels(MAIN_HOSTS)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    return ax


def panel_metric(values: dict[str, float], *, ax: plt.Axes | None = None) -> plt.Axes:
    own = ax is None
    if own:
        _, ax = plt.subplots(figsize=(1.75, 1.45))
    assert ax is not None
    metrics = list(SUMMARY_METRICS)
    x = np.arange(len(metrics))
    vals = [values[m] for m in metrics]
    colors = ["#2C6B87", "#328A8D", "#73AA8E", "#BDA062"]
    bars = ax.bar(x, vals, color=colors, width=0.62)
    annotate_bars(ax, bars, vals, dy=0.16)
    ax.axhline(0, color="#262626", linewidth=0.7)
    ax.set_title("Metric gain")
    ax.set_ylabel(r"$\Delta$ score")
    ax.set_xticks(x)
    ax.set_xticklabels([METRIC_LABELS[m] for m in metrics], rotation=20, ha="right")
    ax.set_ylim(0, max(vals) * 1.34)
    style_axes(ax)
    return ax


def panel_target(values: dict[str, float], *, ax: plt.Axes | None = None) -> plt.Axes:
    own = ax is None
    if own:
        _, ax = plt.subplots(figsize=(1.75, 1.45))
    assert ax is not None
    names = list(TARGETS)
    vals = [values[name] for name in names]
    colors = ["#315D74", "#417C82", "#6A9C86", "#B58D46"]
    bars = ax.bar(np.arange(len(names)), vals, color=colors, width=0.62)
    annotate_bars(ax, bars, vals, dy=0.2)
    ax.axhline(0, color="#262626", linewidth=0.7)
    ax.set_title("Target transfer")
    ax.set_ylabel(r"$\Delta$ P-PRO")
    ax.set_xticks(np.arange(len(names)))
    ax.set_xticklabels(names, rotation=25, ha="right")
    ax.set_ylim(0, max(vals) * 1.30)
    style_axes(ax)
    return ax


def write_tex_snippet() -> None:
    lines = [
        r"% Requires \usepackage{subcaption}",
        r"\begin{figure*}[t]",
        r"\centering",
        r"\begin{subfigure}[t]{0.24\linewidth}",
        r"\centering",
        r"\includegraphics[width=\linewidth]{figure/adapted_host_subfig_a_tted_mode_20260502.pdf}",
        r"\caption{T-TED response.}",
        r"\end{subfigure}\hfill",
        r"\begin{subfigure}[t]{0.24\linewidth}",
        r"\centering",
        r"\includegraphics[width=\linewidth]{figure/adapted_host_subfig_b_cted_mode_20260502.pdf}",
        r"\caption{C-TED response.}",
        r"\end{subfigure}\hfill",
        r"\begin{subfigure}[t]{0.24\linewidth}",
        r"\centering",
        r"\includegraphics[width=\linewidth]{figure/adapted_host_subfig_c_metric_gain_20260502.pdf}",
        r"\caption{Metric-level summary.}",
        r"\end{subfigure}\hfill",
        r"\begin{subfigure}[t]{0.24\linewidth}",
        r"\centering",
        r"\includegraphics[width=\linewidth]{figure/adapted_host_subfig_d_target_gain_20260502.pdf}",
        r"\caption{Target-transfer summary.}",
        r"\end{subfigure}",
        r"\caption{",
        r"\textbf{Compact summary of TED across adapted VLM anomaly localization hosts.}",
        r"The first two panels show host-specific response profiles over image- and pixel-level metrics; the last two panels summarize the resulting gains without expanding the full host--backbone--target tables.",
        r"}",
        r"\label{fig:adapted_host_compact_summary}",
        r"\end{figure*}",
        "",
    ]
    (OUT / "adapted_host_subfigures_20260502.tex").write_text("\n".join(lines))


def write_value_summary(
    tted: dict[str, float],
    cted: dict[str, float],
    metric_delta: dict[str, float],
    target: dict[str, float],
) -> Path:
    def rows(title: str, data: dict[str, float], value_name: str) -> list[str]:
        lines = [f"## {title}", "", f"| Item | {value_name} |", "|---|---:|"]
        lines.extend(f"| {key} | {value:.2f} |" for key, value in data.items())
        lines.append("")
        return lines

    out = OUT / "adapted_host_subfigures_values_20260502.md"
    lines = [
        "# Adapted Host Subfigure Values",
        "",
        "All values are computed from existing result CSV files; no synthetic numbers are used.",
        "",
        "Sources:",
        f"- `{COMPACT_CSV.relative_to(ROOT)}`",
        f"- `{FAPROMPT_TTED_CSV.relative_to(ROOT)}`",
        "",
    ]
    lines += rows("T-TED mode", tted, "Delta score")
    lines += rows("C-TED mode", cted, "Delta score")
    lines += rows("Metric gain", {METRIC_LABELS[k]: v for k, v in metric_delta.items()}, "Delta score")
    lines += rows("Target transfer", target, "Delta P-PRO")
    out.write_text("\n".join(lines))
    return out


def main() -> int:
    compact = load_compact()
    tted_matrix = host_metric_matrix(compact, "t")
    cted_matrix = host_metric_matrix(compact, "c")
    metric_delta = cted_metric_deltas(compact)
    target = cted_target_ppro_values(compact)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "axes.titlesize": 8.5,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    for make, args, name in (
        (panel_response_map, (tted_matrix, "T-TED response"), "adapted_host_subfig_a_tted_mode_20260502"),
        (panel_response_map, (cted_matrix, "C-TED response"), "adapted_host_subfig_b_cted_mode_20260502"),
        (panel_metric, (metric_delta,), "adapted_host_subfig_c_metric_gain_20260502"),
        (panel_target, (target,), "adapted_host_subfig_d_target_gain_20260502"),
    ):
        fig, ax = plt.subplots(figsize=(1.95 if make is panel_response_map else 1.72, 1.48 if make is panel_response_map else 1.38))
        make(*args, ax=ax)
        save_panel(fig, name)

    fig, axs = plt.subplots(
        1,
        4,
        figsize=(7.25, 1.68),
        constrained_layout=True,
        gridspec_kw={"width_ratios": [1.18, 1.18, 1.0, 1.0]},
    )
    panel_response_map(tted_matrix, "T-TED response", ax=axs[0])
    panel_response_map(cted_matrix, "C-TED response", ax=axs[1])
    panel_metric(metric_delta, ax=axs[2])
    panel_target(target, ax=axs[3])
    save_panel(fig, "adapted_host_subfigures_row_20260502")

    write_tex_snippet()
    values_md = write_value_summary(
        {
            f"{host}/{METRIC_LABELS[metric]}": float(tted_matrix[i, j])
            for i, host in enumerate(MAIN_HOSTS)
            for j, metric in enumerate(SUMMARY_METRICS)
            if np.isfinite(tted_matrix[i, j])
        },
        {
            f"{host}/{METRIC_LABELS[metric]}": float(cted_matrix[i, j])
            for i, host in enumerate(MAIN_HOSTS)
            for j, metric in enumerate(SUMMARY_METRICS)
            if np.isfinite(cted_matrix[i, j])
        },
        metric_delta,
        target,
    )
    print(
        {
            "panels": [
                str(FIG / "adapted_host_subfig_a_tted_mode_20260502.pdf"),
                str(FIG / "adapted_host_subfig_b_cted_mode_20260502.pdf"),
                str(FIG / "adapted_host_subfig_c_metric_gain_20260502.pdf"),
                str(FIG / "adapted_host_subfig_d_target_gain_20260502.pdf"),
            ],
            "row_preview": str(FIG / "adapted_host_subfigures_row_20260502.pdf"),
            "tex": str(OUT / "adapted_host_subfigures_20260502.tex"),
            "values": str(values_md),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
