#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
OUT = ROOT / "neurips2026/results/aaclip_backbone_retrained_hostanchor_20260502"
LOG = OUT / "logs"

VISA_RAW = Path("/mnt/data/VisA_20220922")
VISA_OFFICIAL = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")

BACKBONES = {
    "vitbplus": {
        "label": "ViT-B/16+",
        "model_name": "ViT-B-16-plus-240",
        "pretrained": "laion400m_e32",
        "levels": "6,12",
        "surgery_until_layer": "12",
        "img_size": "518",
        "text_batch_size": "32",
        "image_batch_size": "8",
        "eval_batch_size": "8",
    },
    "vith14": {
        "label": "ViT-H/14",
        "model_name": "ViT-H-14",
        "pretrained": "laion2b_s32b_b79k",
        "levels": "8,16,24,32",
        "surgery_until_layer": "32",
        "img_size": "224",
        "text_batch_size": "8",
        "image_batch_size": "2",
        "eval_batch_size": "4",
    },
}


def wait_pid(pid: int) -> None:
    if pid <= 0:
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            print({"stage": "wait_pid_done", "pid": pid}, flush=True)
            return
        time.sleep(60)


def run(cmd: list[str], log_path: Path, cwd: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"failed: {log_path}")


def train_aaclip(tag: str, cfg: dict[str, str], env: dict[str, str]) -> Path:
    ckpt_dir = OUT / f"aaclip_{tag}_visa_ckpt"
    image_ckpt = ckpt_dir / "image_adapter.pth"
    text_ckpt = ckpt_dir / "text_adapter.pth"
    if image_ckpt.exists() and text_ckpt.exists():
        print({"stage": "skip_train", "tag": tag, "ckpt_dir": str(ckpt_dir)}, flush=True)
        return ckpt_dir
    cmd = [
        PY,
        "-u",
        "train.py",
        "--dataset",
        "VisA",
        "--training_mode",
        "full_shot",
        "--model_name",
        cfg["model_name"],
        "--pretrained",
        cfg["pretrained"],
        "--levels",
        cfg["levels"],
        "--surgery_until_layer",
        cfg["surgery_until_layer"],
        "--img_size",
        cfg["img_size"],
        "--text_batch_size",
        cfg["text_batch_size"],
        "--image_batch_size",
        cfg["image_batch_size"],
        "--text_epoch",
        "5",
        "--image_epoch",
        "20",
        "--save_path",
        str(ckpt_dir),
    ]
    run(cmd, LOG / f"aaclip_train_{tag}.log", ROOT / "neurips2026/AA-CLIP", env)
    return ckpt_dir


def eval_aaclip(tag: str, cfg: dict[str, str], ckpt_dir: Path, env: dict[str, str]) -> None:
    save_dir = OUT / f"aaclip_{tag}_visa2mvtec_eval"
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "tag": tag, "summary": str(save_dir / "summary.json")}, flush=True)
        return
    cmd = [
        PY,
        "-u",
        str(ROOT / "neurips2026/scripts/official_parallel_test_aaclip.py"),
        "--preset",
        "visa2mvtec",
        "--ckpt_dir",
        str(ckpt_dir),
        "--model_name",
        cfg["model_name"],
        "--pretrained",
        cfg["pretrained"],
        "--adapter_load_mode",
        "strict",
        "--levels",
        cfg["levels"],
        "--img_size",
        cfg["img_size"],
        "--batch_size",
        cfg["eval_batch_size"],
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated_residual",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        "0",
        "--device",
        "cuda:0",
        "--save_dir",
        str(save_dir),
    ]
    run(cmd, LOG / f"aaclip_eval_{tag}.log", ROOT, env)


def parse_backbones(raw: str) -> list[str]:
    tags = [tag.strip() for tag in raw.split(",") if tag.strip()]
    unknown = [tag for tag in tags if tag not in BACKBONES]
    if unknown:
        raise SystemExit(f"Unknown backbones {unknown}. Allowed: {sorted(BACKBONES)}")
    return tags


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--backbones", default="vitbplus,vith14")
    args = parser.parse_args()

    wait_pid(args.wait_pid)
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.device_id)
    env["PYTHONUNBUFFERED"] = "1"
    env["AACLIP_VISA_ROOT"] = str(VISA_RAW)
    env["AACLIP_MVTEC_ROOT"] = str(MVTEC)
    env["AACLIP_VISA_OFFICIAL_ROOT"] = str(VISA_OFFICIAL)
    for tag in parse_backbones(args.backbones):
        cfg = BACKBONES[tag]
        print({"stage": "backbone", "tag": tag, "label": cfg["label"]}, flush=True)
        ckpt_dir = train_aaclip(tag, cfg, env)
        eval_aaclip(tag, cfg, ckpt_dir, env)
    print({"stage": "done", "task": "aaclip_backbone_retrained_stress"}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
