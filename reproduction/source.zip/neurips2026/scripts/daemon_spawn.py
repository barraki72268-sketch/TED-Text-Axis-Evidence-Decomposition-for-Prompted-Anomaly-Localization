#!/usr/bin/env python3
"""Spawn a command as a double-fork daemon with stdout/stderr redirected."""

from __future__ import annotations

import argparse
import os
import signal
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True)
    parser.add_argument("--pid-file", required=True)
    parser.add_argument("cmd", nargs=argparse.REMAINDER)
    args = parser.parse_args()

    if args.cmd and args.cmd[0] == "--":
        args.cmd = args.cmd[1:]
    if not args.cmd:
        raise SystemExit("daemon_spawn.py requires a command after --")

    log_path = Path(args.log)
    pid_path = Path(args.pid_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    pid_path.parent.mkdir(parents=True, exist_ok=True)

    first = os.fork()
    if first:
        print(first, flush=True)
        return 0

    os.setsid()
    signal.signal(signal.SIGHUP, signal.SIG_IGN)

    second = os.fork()
    if second:
        os._exit(0)

    pid_path.write_text(str(os.getpid()) + "\n", encoding="utf-8")
    with open(os.devnull, "rb", buffering=0) as stdin:
        with log_path.open("ab", buffering=0) as log:
            os.dup2(stdin.fileno(), 0)
            os.dup2(log.fileno(), 1)
            os.dup2(log.fileno(), 2)
            os.execvp(args.cmd[0], args.cmd)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
