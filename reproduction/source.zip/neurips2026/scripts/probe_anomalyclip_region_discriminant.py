from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from probe_anomalyclip_region_bank_descriptor import (  # noqa: E402
    build_model,
    compute_map,
    extract_region_descriptor,
    iterate_components,
    load_text_features,
)
from utils import get_transform  # noqa: E402


def load_rows(path: Path) -> list[dict]:
    with open(path, "r", newline="") as f:
        return list(csv.DictReader(f))


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def fit_region_classifier(fp_rows: list[dict], defect_rows: list[dict], features: list[str]):
    def rows_to_x(rows: list[dict]) -> np.ndarray:
        return np.asarray([[float(row[f]) for f in features] for row in rows], dtype=np.float32)

    X = np.concatenate([rows_to_x(fp_rows), rows_to_x(defect_rows)], axis=0)
    y = np.concatenate(
        [
            np.zeros(len(fp_rows), dtype=np.int64),
            np.ones(len(defect_rows), dtype=np.int64),
        ],
        axis=0,
    )
    clf = Pipeline(
        [
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
        ]
    )
    clf.fit(X, y)
    train_auc = float(__import__("sklearn.metrics").metrics.roc_auc_score(y, clf.predict_proba(X)[:, 1]))
    return clf, train_auc


def build_dataset(root: str, dataset_name: str, image_size: int):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name=dataset_name)


def save_results(rows: list[dict], summary: dict, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "alpha",
                "image_auroc",
                "pixel_auroc",
                "pixel_aupro",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
                "avg_num_components",
                "avg_mean_defect_prob",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe AnomalyCLIP region-level FP-vs-defect discriminant")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--fp_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_bank_holdout_epoch5" / "fp_rows.csv"),
    )
    parser.add_argument(
        "--defect_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_bank_holdout_epoch5" / "defect_rows.csv"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_discriminant_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--candidate_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.25, 0.5, 0.75, 1.0])
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    parser.add_argument("--skip_pixel_aupro", action="store_true")
    parser.add_argument(
        "--descriptor_combo",
        type=str,
        default="peak,mean,area,fill_ratio,compactness,ring_contrast",
    )
    args = parser.parse_args()

    descriptor_features = [x.strip() for x in args.descriptor_combo.split(",") if x.strip()]
    fp_rows = load_rows(Path(args.fp_csv))
    defect_rows = load_rows(Path(args.defect_csv))
    clf, train_auc = fit_region_classifier(fp_rows, defect_rows, descriptor_features)

    print(
        json.dumps(
            {
                "stage": "region_discriminant_start",
                "descriptor_features": descriptor_features,
                "num_fp_rows": len(fp_rows),
                "num_defect_rows": len(defect_rows),
                "source_train_auc": train_auc,
                "candidate_fracs": args.candidate_fracs,
                "alphas": args.alphas,
            },
            indent=2,
        ),
        flush=True,
    )

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    text_features = load_text_features(model, params, Path(args.checkpoint_path), args.device)
    dataset = build_dataset(args.target_root, args.target_dataset, args.image_size)
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    results_by_alpha = {
        alpha: {
            obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}
            for obj in dataset.obj_list
        }
        for alpha in args.alphas
    }
    stats_by_alpha = {
        alpha: {
            "normal_topk": [],
            "normal_mean": [],
            "inside_outside_gap": [],
            "outside_inside_ratio": [],
            "num_components": [],
            "mean_defect_prob": [],
        }
        for alpha in args.alphas
    }

    with torch.no_grad():
        for idx, items in enumerate(loader, start=1):
            image = items["img"].to(args.device)
            cls_name = items["cls_name"][0]
            anomaly_flag = int(items["anomaly"][0].item())
            gt_mask = items["img_mask"].clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0

            anomaly_map = compute_map(model, text_features, image, args.features_list, args.image_size, args.sigma)

            defect_prob_map = np.zeros_like(anomaly_map, dtype=np.float32)
            num_components = 0
            comp_probs = []
            for frac in args.candidate_fracs:
                mask = top_fraction_mask(anomaly_map, frac)
                for comp in iterate_components(mask):
                    if int(comp.sum()) < args.min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    X = np.asarray([[float(desc[f]) for f in descriptor_features]], dtype=np.float32)
                    prob = float(clf.predict_proba(X)[0, 1])
                    defect_prob_map[comp] = np.maximum(defect_prob_map[comp], prob)
                    comp_probs.append(prob)
                    num_components += 1

            if num_components == 0:
                defect_prob_map.fill(1.0)
            mean_def_prob = float(np.mean(comp_probs)) if comp_probs else 1.0

            for alpha in args.alphas:
                factor = (1.0 - alpha) + alpha * defect_prob_map
                final_map = anomaly_map * factor

                results_by_alpha[alpha][cls_name]["gt_sp"].append(anomaly_flag)
                results_by_alpha[alpha][cls_name]["pr_sp"].append(topk_mean(final_map, args.image_score_topk))
                results_by_alpha[alpha][cls_name]["imgs_masks"].append(gt_mask)
                results_by_alpha[alpha][cls_name]["anomaly_maps"].append(final_map[None, ...])

                stats_by_alpha[alpha]["num_components"].append(num_components)
                stats_by_alpha[alpha]["mean_defect_prob"].append(mean_def_prob)

                if anomaly_flag == 0:
                    stats_by_alpha[alpha]["normal_topk"].append(topk_mean(final_map, args.normal_topk_ratio))
                    stats_by_alpha[alpha]["normal_mean"].append(float(final_map.mean()))
                else:
                    mask_np = gt_mask[0].squeeze(0).numpy().astype(bool)
                    if mask_np.any() and (~mask_np).any():
                        inside = float(final_map[mask_np].mean())
                        outside = float(final_map[~mask_np].mean())
                        stats_by_alpha[alpha]["inside_outside_gap"].append(inside - outside)
                        stats_by_alpha[alpha]["outside_inside_ratio"].append(outside / (inside + 1e-6))

            if idx % 64 == 0 or idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "region_discriminant_progress",
                            "images_done": idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    rows = []
    for alpha in args.alphas:
        results = results_by_alpha[alpha]
        image_scores = []
        pixel_scores = []
        pro_scores = []
        for obj in dataset.obj_list:
            if len(results[obj]["gt_sp"]) == 0:
                continue
            results[obj]["imgs_masks"] = torch.cat(results[obj]["imgs_masks"]).numpy()
            results[obj]["anomaly_maps"] = np.concatenate(results[obj]["anomaly_maps"], axis=0)
            image_scores.append(image_level_metrics(results, obj, "image-auroc"))
            pixel_scores.append(pixel_level_metrics(results, obj, "pixel-auroc"))
            if not args.skip_pixel_aupro:
                pro_scores.append(pixel_level_metrics(results, obj, "pixel-aupro"))

        rows.append(
            {
                "alpha": float(alpha),
                "image_auroc": float(np.mean(image_scores)) if image_scores else float("nan"),
                "pixel_auroc": float(np.mean(pixel_scores)) if pixel_scores else float("nan"),
                "pixel_aupro": float(np.mean(pro_scores)) if pro_scores else float("nan"),
                "inside_outside_gap": float(np.mean(stats_by_alpha[alpha]["inside_outside_gap"]))
                if stats_by_alpha[alpha]["inside_outside_gap"]
                else float("nan"),
                "outside_inside_ratio": float(np.mean(stats_by_alpha[alpha]["outside_inside_ratio"]))
                if stats_by_alpha[alpha]["outside_inside_ratio"]
                else float("nan"),
                "normal_topk_mean": float(np.mean(stats_by_alpha[alpha]["normal_topk"]))
                if stats_by_alpha[alpha]["normal_topk"]
                else float("nan"),
                "normal_map_mean": float(np.mean(stats_by_alpha[alpha]["normal_mean"]))
                if stats_by_alpha[alpha]["normal_mean"]
                else float("nan"),
                "avg_num_components": float(np.mean(stats_by_alpha[alpha]["num_components"]))
                if stats_by_alpha[alpha]["num_components"]
                else float("nan"),
                "avg_mean_defect_prob": float(np.mean(stats_by_alpha[alpha]["mean_defect_prob"]))
                if stats_by_alpha[alpha]["mean_defect_prob"]
                else float("nan"),
            }
        )

    summary = {
        "descriptor_features": descriptor_features,
        "source_train_auc": train_auc,
        "num_fp_rows": len(fp_rows),
        "num_defect_rows": len(defect_rows),
    }
    save_results(rows, summary, Path(args.save_dir))
    print(
        json.dumps(
            {
                "stage": "region_discriminant_saved",
                "save_dir": args.save_dir,
                "rows": rows,
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
