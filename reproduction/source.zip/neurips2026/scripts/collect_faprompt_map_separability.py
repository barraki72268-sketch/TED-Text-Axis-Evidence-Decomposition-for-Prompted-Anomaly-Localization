from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

import AnomalyCLIP_lib  # noqa: E402
from common_map_group_separability import (  # noqa: E402
    best_component_stats,
    plot_hist,
    save_summary,
    summarize_groups,
    top_fraction_mask,
    topk_mean_masked,
)
from dataset import Dataset  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402
from utils import get_transform  # noqa: E402


def main():
    parser = argparse.ArgumentParser("Collect Normal / Hard FP / True Defect separability for FAPrompt")
    parser.add_argument("--data_path", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_baseline_mvtec" / "checkpoints" / "epoch_15.pth"),
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_points", type=int, default=200000)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_map_separability_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = args.device
    params = {
        "Prompt_length": args.n_ctx,
        "learnabel_text_embedding_depth": args.depth,
        "learnabel_text_embedding_length": args.t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.data_path, transform=preprocess, target_transform=target_transform, dataset_name=args.dataset)
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    prompt_learner = FAPrompt(model.to("cpu"), params)
    checkpoint = torch.load(args.checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    model.to(device)
    prompt_learner.eval()
    model.eval()

    groups = {"normal": [], "hard_fp": [], "true_defect": [], "outside": []}
    matched = {
        "hard_fp_topk": [],
        "true_defect_topk": [],
        "outside_topk": [],
        "hard_fp_comp_peak": [],
        "hard_fp_comp_mean": [],
        "hard_fp_comp_area": [],
        "true_defect_comp_peak": [],
        "true_defect_comp_mean": [],
        "true_defect_comp_area": [],
        "outside_comp_peak": [],
        "outside_comp_mean": [],
        "outside_comp_area": [],
    }

    print(
        json.dumps(
            {
                "stage": "map_separability_start",
                "num_images": len(dataset),
                "hard_frac": args.hard_frac,
                "checkpoint_path": args.checkpoint_path,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True)
            patch_features = patch_features / patch_features.norm(dim=-1, keepdim=True)
            prompts_pos, prompts_neg, tokenized_prompts_pos, tokenized_prompts_neg, compound_prompts_text, _ = prompt_learner.forward()
            text_features_pos = model.encode_text_learn(prompts_pos, tokenized_prompts_pos, compound_prompts_text).float()
            text_features_neg = model.encode_text_learn(prompts_neg, tokenized_prompts_neg, compound_prompts_text).float()
            text_features_neg = torch.mean(text_features_neg, dim=0, keepdim=True)
            text_features = torch.cat([text_features_pos, text_features_neg])
            text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

            similarity, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_features[0])
            similarity_map1 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], args.image_size).squeeze(0)

            num = min(10, similarity[1:, :, 1].shape[0])
            pk_indx = torch.topk(similarity[1:, :, 1], k=num, dim=0, largest=True, sorted=True).indices
            pk_indx = pk_indx.permute(1, 0)
            selected_tokens = []
            for i in range(len(pk_indx)):
                selected_tokens2 = []
                for k in range(len(pk_indx[0])):
                    tmp_token = patch_features[1:, :, :].permute(1, 0, 2)[i, k, :]
                    selected_tokens2.append(tmp_token)
                selected_tokens2 = torch.stack(selected_tokens2)
                selected_tokens.append(selected_tokens2)
            selected_tokens = torch.stack(selected_tokens)

            text_features_list = []
            for i in range(selected_tokens.shape[0]):
                p_pos, p_neg, tok_pos, tok_neg, comp_text, _ = prompt_learner.forward(selected_tokens=selected_tokens[i])
                tf_pos = model.encode_text_learn(p_pos, tok_pos, comp_text).float()
                tf_neg = model.encode_text_learn(p_neg, tok_neg, comp_text).float()
                tf_neg = torch.mean(tf_neg, dim=0, keepdim=True)
                tf = torch.cat([tf_pos, tf_neg])
                text_features_list.append(tf)
            text_features = torch.stack(text_features_list)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

            similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_features, text_features)
            similarity_map2 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], args.image_size).squeeze(0)
            anomaly_map = (similarity_map1[1, :] + 1 - similarity_map1[0, :] + similarity_map2[1, :] + 1 - similarity_map2[0, :]) / 4.0
            anomaly_map = gaussian_filter(anomaly_map.detach().cpu().numpy(), sigma=args.sigma)
            score_mask = top_fraction_mask(anomaly_map, args.hard_frac)

            if is_anomaly and gt_mask.any():
                groups["true_defect"].append(anomaly_map[gt_mask].reshape(-1))
                groups["outside"].append(anomaly_map[~gt_mask].reshape(-1))
                matched["true_defect_topk"].append(topk_mean_masked(anomaly_map, gt_mask, args.hard_frac))
                matched["outside_topk"].append(topk_mean_masked(anomaly_map, ~gt_mask, args.hard_frac))
                defect_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="inside")
                outside_comp = best_component_stats(anomaly_map, score_mask, gt_mask=gt_mask, overlap_mode="outside")
                if defect_comp is not None:
                    matched["true_defect_comp_peak"].append(defect_comp["peak"])
                    matched["true_defect_comp_mean"].append(defect_comp["mean"])
                    matched["true_defect_comp_area"].append(defect_comp["area"])
                if outside_comp is not None:
                    matched["outside_comp_peak"].append(outside_comp["peak"])
                    matched["outside_comp_mean"].append(outside_comp["mean"])
                    matched["outside_comp_area"].append(outside_comp["area"])
            else:
                hard_mask = score_mask
                groups["hard_fp"].append(anomaly_map[hard_mask].reshape(-1))
                groups["normal"].append(anomaly_map[~hard_mask].reshape(-1))
                matched["hard_fp_topk"].append(float(anomaly_map[hard_mask].mean()))
                hard_comp = best_component_stats(anomaly_map, score_mask)
                if hard_comp is not None:
                    matched["hard_fp_comp_peak"].append(hard_comp["peak"])
                    matched["hard_fp_comp_mean"].append(hard_comp["mean"])
                    matched["hard_fp_comp_area"].append(hard_comp["area"])

            if img_idx % 64 == 0 or img_idx == len(dataset):
                print(
                    json.dumps(
                        {
                            "stage": "map_separability_progress",
                            "images_done": img_idx,
                            "images_total": len(dataset),
                        }
                    ),
                    flush=True,
                )

    groups_np = {}
    for key, chunks in groups.items():
        vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
        if vals.size > args.max_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(vals.size, size=args.max_points, replace=False)
            vals = vals[idx]
        groups_np[key] = vals.astype(np.float32, copy=False)

    summary = {
        "host": "FAPrompt",
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "num_images": len(dataset),
        "summary": summarize_groups(groups_np, max_summary_points=args.max_points),
    }
    matched_np = {
        key: np.asarray([v for v in vals if np.isfinite(v)], dtype=np.float32)
        for key, vals in matched.items()
    }
    summary["matched_summary"] = summarize_groups(
        matched_np,
        max_summary_points=args.max_points,
        pairs=[
            ("true_defect_topk", "hard_fp_topk"),
            ("true_defect_topk", "outside_topk"),
            ("true_defect_comp_peak", "hard_fp_comp_peak"),
            ("true_defect_comp_peak", "outside_comp_peak"),
            ("true_defect_comp_mean", "hard_fp_comp_mean"),
            ("true_defect_comp_mean", "outside_comp_mean"),
        ],
    )
    save_dir = Path(args.save_dir)
    save_summary(summary, save_dir)
    plot_hist(groups_np, save_dir / "hist.png", "FAPrompt Map Separability")
    plot_hist(
        {
            "hard_fp_topk": matched_np["hard_fp_topk"],
            "true_defect_topk": matched_np["true_defect_topk"],
            "outside_topk": matched_np["outside_topk"],
        },
        save_dir / "matched_topk_hist.png",
        "FAPrompt Matched Top-k Separability",
    )
    plot_hist(
        {
            "hard_fp_comp_peak": matched_np["hard_fp_comp_peak"],
            "true_defect_comp_peak": matched_np["true_defect_comp_peak"],
            "outside_comp_peak": matched_np["outside_comp_peak"],
        },
        save_dir / "matched_component_peak_hist.png",
        "FAPrompt Component Peak Separability",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
