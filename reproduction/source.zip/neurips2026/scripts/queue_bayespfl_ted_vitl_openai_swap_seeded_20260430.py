from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_bayespfl_ted_smoke.py"
RESULT_ROOT = ROOT / "neurips2026/results/bayespfl_ted_vitl_openai_swap_seeded_20260430"
LOG_ROOT = RESULT_ROOT / "_logs"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")

CKPT = str(ROOT / "neurips2026/results/bayespfl_strict_mvtec/epoch_post_15_1.pth")
CONFIG = str(ROOT / "neurips2026/Bayes-PFL/open_clip_local/model_configs/ViT-L-14.json")
PRETRAINED = "/home/jinyoung/.cache/clip/ViT-L-14.pt"

TARGETS = [
    {"name": "mvtec", "dataset": "mvtec", "root": MVTEC_ROOT},
    {"name": "visa", "dataset": "visa", "root": VISA_ROOT},
    {"name": "mpdd", "dataset": "mpdd", "root": MPDD_ROOT},
    {"name": "btad", "dataset": "btad", "root": BTAD_ROOT},
]


def build_cmd(target: dict[str, str], seed: int) -> list[str]:
    save_dir = RESULT_ROOT / f"mvtec2{target['name']}_seed{seed}"
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--dataset",
        "mvtec",
        "--data_path",
        MVTEC_ROOT,
        "--target_dataset",
        target["dataset"],
        "--target_data_path",
        target["root"],
        "--target_class",
        "",
        "--checkpoint_path",
        CKPT,
        "--config_path",
        CONFIG,
        "--pretrained_path",
        PRETRAINED,
        "--image_size",
        "224",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--device_id",
        "0",
        "--seed",
        str(seed),
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--hard_frac",
        "0.01",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--margin_sign",
        "def_minus_fp",
        "--map_activation",
        "sigmoid",
        "--ted_combine",
        "residual",
        "--ted_alpha",
        "0.05",
        "--enable_calibrator",
        "--calib_epochs",
        "80",
        "--calib_lr",
        "0.02",
        "--calib_eta_init",
        "0.01",
        "--calib_eta_max",
        "0.05",
        "--calib_eta_reg",
        "1e-3",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_hard_frac",
        "0.01",
        "--calib_max_good_per_class",
        "8",
        "--calib_max_defect_per_class",
        "8",
        "--calib_max_fp_per_image",
        "64",
        "--calib_max_defect_per_image",
        "128",
        "--calib_max_train_points",
        "8192",
        "--image_topk",
        "0.01",
        "--max_normal_eval",
        "0",
        "--max_anomaly_eval",
        "0",
        "--save_dir",
        str(save_dir),
    ]


def main() -> None:
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    for target in TARGETS:
        for seed in (0, 1, 2):
            save_dir = RESULT_ROOT / f"mvtec2{target['name']}_seed{seed}"
            if (save_dir / "summary.json").exists():
                print({"stage": "skip_existing", "target": target["name"], "seed": seed}, flush=True)
                continue
            log_path = LOG_ROOT / f"mvtec2{target['name']}_seed{seed}.log"
            cmd = build_cmd(target, seed)
            print({"stage": "start", "target": target["name"], "seed": seed, "log": str(log_path)}, flush=True)
            with log_path.open("w") as log_file:
                proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
            print({"stage": "done", "target": target["name"], "seed": seed, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
            if proc.returncode != 0:
                raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
