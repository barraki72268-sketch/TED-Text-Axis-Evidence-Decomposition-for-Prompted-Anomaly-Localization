#!/usr/bin/env python3
"""Build a compact layer/backbone retraining diagnostic for the paper."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026/results/final_metric_and_novelty_tables"
TEX_OUT = ROOT / "tab/layer_backbone_retrain_diagnostic.tex"
VALUES_OUT = OUT_DIR / "layer_backbone_retrain_diagnostic_values_20260503.md"


LAYER_ROWS = [
    ("AdaCLIP", "Full(B)", (89.89, 44.03, 41.60), (89.88, 43.60, 41.46), (89.86, 47.97, 41.85)),
    ("AdaCLIP", "EL-r", (80.21, 18.18, 22.40), (80.21, 17.94, 22.39), (80.96, 26.25, 23.81)),
    ("AdaCLIP", "M2-r", (87.62, 23.50, 36.18), (87.61, 23.63, 36.12), (87.79, 25.42, 36.40)),
    ("AdaCLIP", "L2-r", (89.47, 15.19, 36.35), (89.47, 15.14, 36.31), (90.84, 22.78, 39.28)),
    ("AdaCLIP", "L-r", (88.96, 34.83, 35.78), (88.96, 34.66, 35.77), (89.15, 46.27, 36.77)),
    ("FAPrompt", "Full(B)", (89.95, 73.57, 22.35), (40.41, 25.32, 8.16), (90.19, 76.83, 30.94)),
    ("FAPrompt", "EL-r", (90.49, 74.70, 23.58), (42.46, 26.23, 9.25), (90.78, 77.16, 32.40)),
    ("FAPrompt", "M2-r", (90.05, 74.35, 22.58), (41.66, 25.87, 8.79), (90.52, 76.54, 31.46)),
    ("FAPrompt", "L2-r", (90.08, 72.73, 22.33), (45.33, 30.26, 10.78), (90.61, 76.63, 31.07)),
    ("FAPrompt", "L-r", (89.63, 74.01, 23.01), (44.35, 29.27, 10.40), (89.93, 76.08, 31.68)),
    ("FAPrompt", "F-r", (89.92, 73.37, 22.42), (45.60, 30.49, 10.98), (90.45, 77.23, 31.19)),
]


BACKBONE_CASES = [
    {
        "label": "AdaCLIP",
        "path": "neurips2026/results/backbone_retrained_stress_20260501/adaclip_vitb16_eval/summary.json",
        "format": "rows",
        "baseline": "baseline_txt",
        "cted": "ted_calibrated",
    },
    {
        "label": "AdaptCLIP",
        "path": "neurips2026/results/backbone_retrained_extra_hosts_20260503/adaptclip_vitbplus_visa2mvtec_eval/summary.json",
        "format": "rows_alias",
        "baseline": "baseline_txt",
        "cted": "ted_calibrated_vl",
    },
    {
        "label": "AnomalyCLIP",
        "path": "neurips2026/results/backbone_retrained_stress_20260501/anomalyclip_vitb16_eval/summary.json",
        "format": "rows",
        "baseline": "baseline_txt",
        "cted": "ted_calibrated",
    },
    {
        "label": "FAPrompt",
        "path": "neurips2026/results/backbone_retrained_extra_hosts_20260503/faprompt_vitbplus_visa2mvtec_eval/summary.json",
        "format": "mean_faprompt",
        "baseline": "baseline_official",
        "cted": "branch_calibrated_alpha_0.5",
    },
]


def fmt_triplet(values: tuple[float, float, float]) -> str:
    return " / ".join(f"{v:.2f}" for v in values)


def read_metrics(case: dict[str, str]) -> tuple[float, float, float, float]:
    path = ROOT / case["path"]
    data = json.loads(path.read_text())
    if case["format"] in {"rows", "rows_alias"}:
        found: dict[str, dict] = {}
        for row in data["rows"]:
            if row.get("target_label") == "mean":
                found[row["mode"]] = row
        base = found[case["baseline"]]
        cted = found[case["cted"]]
        return (
            base["pixel_aupro"] * 100.0,
            cted["pixel_aupro"] * 100.0,
            base["pixel_ap"] * 100.0,
            cted["pixel_ap"] * 100.0,
        )
    if case["format"] == "mean_nested":
        mean = data["mean"]
        base = mean[case["baseline"]]
        cted = mean["candidates"][case["cted"]]
        return base["pixel_pro"], cted["pixel_pro"], base["pixel_ap"], cted["pixel_ap"]
    if case["format"] == "mean_faprompt":
        mean = data["mean"]
        base = mean[case["baseline"]]
        cted = mean["parallel"][case["cted"]]
        return (
            base["pixel_aupro"] * 100.0,
            cted["pixel_aupro"] * 100.0,
            base["pixel_ap"] * 100.0,
            cted["pixel_ap"] * 100.0,
        )
    raise ValueError(case["format"])


def make_backbone_plot() -> list[tuple[str, float, float, float, float]]:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    values = []
    for case in BACKBONE_CASES:
        base_pro, cted_pro, base_ap, cted_ap = read_metrics(case)
        values.append((case["label"], base_pro, cted_pro, base_ap, cted_ap))

    labels = [v[0] for v in values]
    base_pro = np.array([v[1] for v in values])
    cted_pro = np.array([v[2] for v in values])
    base_ap = np.array([v[3] for v in values])
    cted_ap = np.array([v[4] for v in values])
    x = np.arange(len(labels))

    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.labelweight": "bold",
        "axes.titleweight": "bold",
    })
    fig, ax = plt.subplots(figsize=(5.3, 3.3))
    ax.plot(x, base_pro, marker="o", markersize=6.5, linewidth=2.1, color="#9aa3ad", label="B P-PRO")
    ax.plot(x, cted_pro, marker="o", markersize=6.5, linewidth=2.4, color="#2b6f8a", label="C P-PRO")
    ax.plot(x, base_ap, marker="s", markersize=5.7, linewidth=1.9, color="#d2a16f", linestyle="--", label="B P-AP")
    ax.plot(x, cted_ap, marker="s", markersize=5.7, linewidth=2.1, color="#9b5a22", linestyle="--", label="C P-AP")

    for i, (bp, cp, ba, ca) in enumerate(zip(base_pro, cted_pro, base_ap, cted_ap)):
        ax.text(i, cp + 1.0, f"+{cp - bp:.1f}", ha="center", va="bottom", fontsize=8.5, fontweight="bold", color="#183946")
        ap_delta = ca - ba
        prefix = "+" if ap_delta >= 0 else ""
        ax.text(i, ca - 1.1, f"{prefix}{ap_delta:.1f}", ha="center", va="top", fontsize=8.0, fontweight="bold", color="#6d3e16")

    ax.set_ylabel("Score")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=32, ha="right", fontweight="bold")
    ymin = max(0.0, min(base_ap.min(), cted_ap.min()) - 8.0)
    ymax = max(base_pro.max(), cted_pro.max()) + 8.0
    ax.set_ylim(ymin, ymax)
    ax.grid(axis="y", color="#d8dde3", linewidth=0.8, alpha=0.8)
    ax.set_axisbelow(True)
    ax.legend(
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.5, 1.26),
        ncol=2,
        handlelength=1.2,
        columnspacing=1.2,
    )
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    fig.tight_layout(pad=0.3)
    fig.savefig(FIG_DIR / "backbone_retrain_recovery_20260503.pdf", bbox_inches="tight")
    fig.savefig(FIG_DIR / "backbone_retrain_recovery_20260503.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    return values


def make_tex(backbone_values: list[tuple[str, float, float, float, float]]) -> None:
    host_spans = {"AdaCLIP": 5, "FAPrompt": 6}
    seen: dict[str, int] = {}
    table_lines = []
    for host, recipe, base, tted, cted in LAYER_ROWS:
        seen[host] = seen.get(host, 0) + 1
        host_cell = rf"\multirow{{{host_spans[host]}}}{{*}}{{{host}}}" if seen[host] == 1 else ""
        table_lines.append(
            f"{host_cell} & {recipe} & {fmt_triplet(base)} & {fmt_triplet(tted)} & {fmt_triplet(cted)} \\\\"
        )
        if host == "AdaCLIP" and seen[host] == host_spans[host]:
            table_lines.append(r"\midrule")

    tex = "\n".join(
        [
            r"\begin{figure*}[t]",
            r"\centering",
            r"\begin{minipage}[t]{0.61\textwidth}",
            r"\centering",
            r"\textbf{(a) Layer-recipe retraining}",
            r"\vspace{2pt}",
            r"\scriptsize",
            r"\setlength{\tabcolsep}{2.2pt}",
            r"\renewcommand{\arraystretch}{1.03}",
            r"\resizebox{\linewidth}{!}{%",
            r"\begin{tabular}{llccc}",
            r"\toprule",
            r"Host & Recipe & B & T & C \\",
            r"\midrule",
            *table_lines,
            r"\bottomrule",
            r"\end{tabular}%",
            r"}",
            r"\end{minipage}",
            r"\hfill",
            r"\begin{minipage}[t]{0.36\textwidth}",
            r"\centering",
            r"\textbf{(b) ViT-B backbone retraining}",
            r"\vspace{2pt}",
            r"\includegraphics[width=\linewidth]{figure/backbone_retrain_recovery_20260503.pdf}",
            r"\end{minipage}",
            r"\caption{",
            r"Recipe-retraining diagnostics on VisA$\rightarrow$MVTec.",
            r"(a) reports P-AUC / P-PRO / P-AP for retrained layer recipes; B, T, and C denote the host baseline, train-free TED, and source-calibrated TED.",
            r"(b) shows representative ViT-B-family backbone-retrained hosts and compares baseline and C-TED scores for P-PRO and P-AP.",
            r"}",
            r"\label{fig:recipe_retrain_diagnostic}",
            r"\end{figure*}",
            "",
        ]
    )
    TEX_OUT.write_text(tex)

    lines = ["# Layer/backbone retraining diagnostic", ""]
    lines.append("## Backbone panel values")
    lines.append("")
    lines.append("| Case | B P-PRO | C-TED P-PRO | Delta PRO | B AP | C-TED AP | Delta AP |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for label, base_pro, cted_pro, base_ap, cted_ap in backbone_values:
        clean = label.replace("\n", " ")
        lines.append(
            f"| {clean} | {base_pro:.2f} | {cted_pro:.2f} | {cted_pro - base_pro:+.2f} | "
            f"{base_ap:.2f} | {cted_ap:.2f} | {cted_ap - base_ap:+.2f} |"
        )
    lines.append("")
    VALUES_OUT.write_text("\n".join(lines))


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    backbone_values = make_backbone_plot()
    make_tex(backbone_values)
    print(TEX_OUT)
    print(FIG_DIR / "backbone_retrain_recovery_20260503.pdf")
    print(VALUES_OUT)


if __name__ == "__main__":
    main()
