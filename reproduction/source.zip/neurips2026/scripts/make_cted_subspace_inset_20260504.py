#!/usr/bin/env python3
"""Make a compact C-TED source-subspace schematic inset."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    out_dir = Path("figure/method_figure")
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(7)
    red = rng.normal(loc=[0.42, 0.34], scale=[0.10, 0.08], size=(18, 2))
    blue = rng.normal(loc=[-0.32, -0.24], scale=[0.12, 0.07], size=(18, 2))
    query = np.array([-0.05, -0.03])
    transported = np.array([0.20, 0.19])

    plt.rcParams.update(
        {
            "font.family": "DejaVu Serif",
            "mathtext.fontset": "dejavuserif",
            "axes.linewidth": 1.0,
        }
    )
    fig, ax = plt.subplots(figsize=(2.55, 1.9), dpi=300)
    fig.patch.set_facecolor("#101010")
    ax.set_facecolor("#101010")

    # Text axis and residual axis.
    ax.axhline(0, color="#d8d8d8", lw=1.2, alpha=0.95)
    ax.annotate(
        "",
        xy=(0.72, 0.0),
        xytext=(-0.70, 0.0),
        arrowprops=dict(arrowstyle="->", color="#d8d8d8", lw=1.2),
    )
    ax.annotate(
        "",
        xy=(0.40, 0.55),
        xytext=(-0.34, -0.45),
        arrowprops=dict(arrowstyle="->", color="#f2c46d", lw=1.6),
    )
    ax.text(0.35, 0.035, r"$t_{\rm axis}$", color="#f2f2f2", fontsize=7)
    ax.text(0.18, 0.40, r"$d$", color="#f2c46d", fontsize=8, fontweight="bold")

    ax.scatter(blue[:, 0], blue[:, 1], s=18, c="#4d82d8", edgecolors="#bcd2ff", linewidths=0.35, alpha=0.95)
    ax.scatter(red[:, 0], red[:, 1], s=18, c="#c85050", edgecolors="#ffd0d0", linewidths=0.35, alpha=0.95)

    # Query transport.
    ax.scatter([query[0]], [query[1]], s=34, c="#ffffff", edgecolors="#111111", linewidths=0.7, zorder=5)
    ax.annotate(
        "",
        xy=transported,
        xytext=query,
        arrowprops=dict(arrowstyle="->", color="#ffffff", lw=1.7, shrinkA=3, shrinkB=2),
    )
    ax.scatter([transported[0]], [transported[1]], s=28, c="#ffffff", edgecolors="#f2c46d", linewidths=1.0, zorder=5)

    ax.text(0.53, 0.26, "defect\nbank", color="#ffc4c4", fontsize=6.5, ha="left", va="center")
    ax.text(-0.66, -0.32, "FP\nbank", color="#c8dbff", fontsize=6.5, ha="left", va="center")
    ax.text(-0.19, 0.08, "query", color="#ffffff", fontsize=6.5, ha="right", va="bottom")
    ax.text(0.05, -0.17, "bounded\ntransport", color="#ffffff", fontsize=6.2, ha="center", va="top")

    ax.text(
        0.5,
        1.02,
        r"source subspace $U$",
        color="#ffffff",
        fontsize=7.5,
        ha="center",
        va="bottom",
        transform=ax.transAxes,
    )

    ax.set_xlim(-0.74, 0.76)
    ax.set_ylim(-0.52, 0.62)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_color("#ffffff")
        spine.set_linewidth(1.1)
    fig.tight_layout(pad=0.25)
    for ext in ["png", "pdf"]:
        fig.savefig(out_dir / f"cted_subspace_inset_20260504.{ext}", facecolor=fig.get_facecolor(), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    print(out_dir / "cted_subspace_inset_20260504.png")


if __name__ == "__main__":
    main()
