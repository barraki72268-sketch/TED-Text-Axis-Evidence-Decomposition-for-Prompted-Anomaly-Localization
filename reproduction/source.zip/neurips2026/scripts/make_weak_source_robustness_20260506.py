#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import re
from collections import defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results" / "weak_source_robustness_20260506"
OUT_DIR = ROOT / "supp_fig"
CSV_OUT = OUT_DIR / "weak_source_robustness_20260506.csv"
TEX_OUT = OUT_DIR / "weak_source_robustness_20260506.tex"


def pct(x: float) -> float:
    return 100.0 * x if abs(x) <= 1.5 else x


def triplet(blob: dict, pro_key: str) -> tuple[float, float, float]:
    return (
        pct(float(blob.get("pixel_auc", float("nan")))),
        pct(float(blob.get(pro_key, blob.get("pixel_aupro", float("nan"))))),
        pct(float(blob.get("pixel_ap", float("nan")))),
    )


def dloc(candidate: tuple[float, float, float], base: tuple[float, float, float]) -> tuple[float, float, float, float]:
    d_auc = candidate[0] - base[0]
    d_pro = candidate[1] - base[1]
    d_ap = candidate[2] - base[2]
    return d_auc, d_pro, d_ap, 0.5 * (d_pro + d_ap)


def first_key(d: dict, prefix: str) -> str | None:
    keys = sorted(k for k in d if k.startswith(prefix))
    return keys[0] if keys else None


def parse_one(path: Path) -> dict | None:
    data = json.load(path.open())
    name = path.parent.name
    if name.startswith("aaclip_"):
        m = re.search(r"_sourcelimit([^_]+)_seed", name)
        if not m:
            return None
        budget = m.group(1)
        mean = data.get("mean", {})
        base_blob = mean.get("baseline")
        candidates = mean.get("candidates", {})
        key = first_key(candidates, "prescore_calibrated_alpha_")
        if not base_blob or not key:
            return None
        base = triplet(base_blob, "pixel_pro")
        cand = triplet(candidates[key], "pixel_pro")
        da, dp, dap, dl = dloc(cand, base)
        return {
            "host": "AA-CLIP",
            "budget_type": "source images/class",
            "budget": budget,
            "setting": name,
            "delta_p_auc": da,
            "delta_pro": dp,
            "delta_ap": dap,
            "delta_loc": dl,
        }
    if name.startswith("faprompt_"):
        m = re.search(r"_bank(\d+)_seed", name)
        if not m:
            return None
        budget = m.group(1)
        mean = data.get("mean", {})
        base_blob = mean.get("baseline_official")
        parallel = mean.get("parallel", {})
        key = first_key(parallel, "branch_calibrated_alpha_")
        if not base_blob or not key:
            return None
        base = triplet(base_blob, "pixel_aupro")
        cand = triplet(parallel[key], "pixel_aupro")
        da, dp, dap, dl = dloc(cand, base)
        return {
            "host": "FAPrompt",
            "budget_type": "retained bank/class",
            "budget": budget,
            "setting": name,
            "delta_p_auc": da,
            "delta_pro": dp,
            "delta_ap": dap,
            "delta_loc": dl,
        }
    return None


def fmt(x: float) -> str:
    if math.isnan(x):
        return "--"
    return f"{x:+.1f}"


def main() -> int:
    rows = []
    for path in sorted(RESULTS.glob("*/summary.json")):
        row = parse_one(path)
        if row:
            rows.append(row)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fields = ["host", "budget_type", "budget", "setting", "delta_p_auc", "delta_pro", "delta_ap", "delta_loc"]
    with CSV_OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    grouped: dict[tuple[str, str, str], list[dict]] = defaultdict(list)
    for row in rows:
        grouped[(row["host"], row["budget_type"], row["budget"])].append(row)
    order = {
        ("AA-CLIP", "source images/class"): ["1", "2", "4", "all"],
        ("FAPrompt", "retained bank/class"): ["8", "16", "32", "64"],
    }
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Weak-source robustness.",
        r"AA-CLIP varies the number of source images per source class used to construct banks.",
        r"FAPrompt varies the retained source-bank budget per class.",
        r"Values are gains over the corresponding host baseline; $\Delta$Loc is the mean of $\Delta$PRO and $\Delta$AP.",
        r"}",
        r"\label{tab:weak_source_robustness}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.2pt}",
        r"\renewcommand{\arraystretch}{1.06}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}llcccc}",
        r"\toprule",
        r"Host & Source budget & $n$ & $\Delta$PRO & $\Delta$AP & $\Delta$Loc \\",
        r"\midrule",
    ]
    for host, budget_type in [("AA-CLIP", "source images/class"), ("FAPrompt", "retained bank/class")]:
        for budget in order[(host, budget_type)]:
            sub = grouped.get((host, budget_type, budget), [])
            if not sub:
                continue
            dpro = float(np.mean([r["delta_pro"] for r in sub]))
            dap = float(np.mean([r["delta_ap"] for r in sub]))
            dl = float(np.mean([r["delta_loc"] for r in sub]))
            budget_label = f"{budget} img/cls" if host == "AA-CLIP" else f"{budget} bank/cls"
            lines.append(f"{host} & {budget_label} & {len(sub)} & {fmt(dpro)} & {fmt(dap)} & {fmt(dl)} \\\\")
    lines += [r"\bottomrule", r"\end{tabular*}", r"\end{table}", ""]
    TEX_OUT.write_text("\n".join(lines))
    print(json.dumps({"rows": len(rows), "csv": str(CSV_OUT.relative_to(ROOT)), "tex": str(TEX_OUT.relative_to(ROOT))}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
