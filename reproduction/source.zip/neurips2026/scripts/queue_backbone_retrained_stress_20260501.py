#!/usr/bin/env python3
"""Run backbone-retrained stress for AnomalyCLIP and AdaCLIP.

Protocol: replace the CLIP visual backbone, retrain the host on the source
recipe, then evaluate B / T-TED / C-TED on VisA -> MVTec. This is intentionally
small for ablation: two backbones (ViT-B, ViT-H) and two hosts.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT = ROOT / "neurips2026/results/backbone_retrained_stress_20260501"
LOG = OUT / "logs"
VISA = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
CLINICDB = Path("/mnt/data/CVC-ClinicDB")
COLONDB = Path("/mnt/data/CVC-ColonDB")

VIT_B = Path("/home/jinyoung/.cache/clip/ViT-B-16.pt")
VIT_H = Path(
    "/mnt/data/hf-cache/hub/models--laion--CLIP-ViT-H-14-laion2B-s32B-b79K/"
    "blobs/9a78ef8e8c73fd0df621682e7a8e8eb36c6916cb3c16b291a082ecd52ab79cc4"
)

ANOMALY = {
    "vitb16": {
        "bb": "ViT-B/16",
        "path": str(VIT_B),
        "features": ["3", "6", "9", "12"],
        "dpam": "12",
        "image": "224",
        "bs": "8",
    },
    "vith14": {
        "bb": "ViT-H/14",
        "path": str(VIT_H),
        "features": ["8", "16", "24", "32"],
        "dpam": "32",
        "image": "224",
        "bs": "2",
    },
}

ADACLIP = {
    "vitb16": {"model": "ViT-B-16", "image": "518", "bs": "1"},
    "vith14": {"model": "ViT-H-14", "image": "518", "bs": "1"},
}


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print("[run]", " ".join(cmd), flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT)
    if proc.returncode:
        raise RuntimeError(f"failed: {log_path}")


def latest_ckpt(root: Path) -> Path:
    pats = ["*_last.pth", "epoch_*.pth", "*.pth"]
    for pat in pats:
        xs = sorted(root.rglob(pat), key=lambda p: p.stat().st_mtime)
        if xs:
            return xs[-1]
    raise FileNotFoundError(root)


def make_table(env: dict[str, str]) -> None:
    run(
        [str(PY), str(ROOT / "neurips2026/scripts/make_backbone_retrained_stress_table_20260501.py")],
        ROOT,
        LOG / "make_table.log",
        env,
    )


def anomalyclip(tag: str, cfg: dict[str, str], gpu: str, env: dict[str, str]) -> None:
    ckpt_dir = OUT / f"anomalyclip_{tag}_ckpt"
    ckpt = ckpt_dir / "epoch_15.pth"
    run_env = dict(env, CUDA_VISIBLE_DEVICES=gpu)
    if not ckpt.exists():
        run(
            [
                str(PY),
                "-u",
                "train.py",
                "--dataset",
                "visa",
                "--train_data_path",
                str(VISA),
                "--save_path",
                str(ckpt_dir),
                "--model_name_or_path",
                cfg["path"],
                "--features_list",
                *cfg["features"],
                "--feature_map_layer",
                "0",
                "1",
                "2",
                "3",
                "--dpam_layer",
                cfg["dpam"],
                "--image_size",
                cfg["image"],
                "--batch_size",
                cfg["bs"],
                "--epoch",
                "15",
                "--save_freq",
                "15",
                "--print_freq",
                "1",
                "--depth",
                "9",
                "--n_ctx",
                "12",
                "--t_n_ctx",
                "4",
                "--seed",
                "111",
            ],
            ROOT / "neurips2026/AnomalyCLIP",
            LOG / f"anomalyclip_train_{tag}.log",
            run_env,
        )
    else:
        print(f"[skip] {ckpt}", flush=True)

    save = OUT / f"anomalyclip_{tag}_eval"
    if (save / "summary.json").exists():
        print(f"[skip] {save / 'summary.json'}", flush=True)
        make_table(env)
        return
    base_eval_cmd = [
        str(PY),
        "-u",
        str(ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"),
        "--device",
        "cuda:0",
        "--checkpoint_path",
        str(ckpt),
        "--source_root",
        str(VISA),
        "--source_dataset",
        "visa",
        "--target_root",
        str(MVTEC),
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--model_name_or_path",
        cfg["path"],
        "--image_size",
        cfg["image"],
        "--dpam_layer",
        cfg["dpam"],
        "--features_list",
        *cfg["features"],
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--bank_cache_path",
        str(OUT / f"bank_cache/anomalyclip_{tag}_visa.pt"),
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--skip_separability_metrics",
        "--save_dir",
        str(save),
    ]
    try:
        run(
            [
                *base_eval_cmd,
                "--enable_calibrator",
                "--calib_seed",
                "0",
                "--calib_epochs",
                "80",
                "--calib_subspace_rank",
                "8",
                "--calib_eta_max",
                "0.5",
                "--calib_lambda",
                "1.0",
                "--calibrated_image_fusion_weight",
                "-0.05",
            ],
            ROOT,
            LOG / f"anomalyclip_eval_{tag}.log",
            run_env,
        )
    except RuntimeError as exc:
        print(f"[warn] calibrated AnomalyCLIP eval failed for {tag}: {exc}", flush=True)
        print(f"[warn] retrying {tag} without calibrator to keep B/T-TED and continue queue", flush=True)
        run(
            base_eval_cmd,
            ROOT,
            LOG / f"anomalyclip_eval_{tag}_trainfree_only.log",
            run_env,
        )
    make_table(env)


def adaclip(tag: str, cfg: dict[str, str], gpu: str, env: dict[str, str]) -> None:
    ckpt_dir = OUT / f"adaclip_{tag}_ckpt"
    run_env = dict(
        env,
        CUDA_VISIBLE_DEVICES=gpu,
        ADACLIP_VISA_ROOT=str(VISA),
        ADACLIP_CLINICDB_ROOT=str(CLINICDB),
        ADACLIP_COLONDB_ROOT=str(COLONDB),
        ADACLIP_MVTEC_ROOT=str(MVTEC),
    )
    try:
        ckpt = latest_ckpt(ckpt_dir)
        print(f"[skip] {ckpt}", flush=True)
    except FileNotFoundError:
        run(
            [
                str(PY),
                "-u",
                "train.py",
                "--save_fig",
                "False",
                "--training_data",
                "visa",
                "clinicdb",
                "--testing_data",
                "mvtec",
                "--save_path",
                str(ckpt_dir),
                "--model",
                cfg["model"],
                "--layer_recipe",
                "all4",
                "--target_val_during_train",
                "False",
                "--save_last_ckpt",
                "True",
                "--epoch",
                "5",
                "--batch_size",
                cfg["bs"],
                "--image_size",
                cfg["image"],
                "--prompting_depth",
                "4",
                "--prompting_length",
                "5",
                "--prompting_branch",
                "VL",
                "--prompting_type",
                "SD",
                "--use_hsf",
                "True",
                "--k_clusters",
                "20",
            ],
            ROOT / "neurips2026/AdaCLIP",
            LOG / f"adaclip_train_{tag}.log",
            run_env,
        )
        ckpt = latest_ckpt(ckpt_dir)

    save = OUT / f"adaclip_{tag}_eval"
    if (save / "summary.json").exists():
        print(f"[skip] {save / 'summary.json'}", flush=True)
        make_table(env)
        return
    run(
        [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/official_parallel_test_adaclip.py"),
            "--source_root",
            str(VISA),
            "--source_dataset",
            "visa",
            "--target_root",
            str(MVTEC),
            "--target_dataset",
            "mvtec",
            "--checkpoint_path",
            str(ckpt),
            "--save_dir",
            str(save),
            "--bank_cache_path",
            str(OUT / f"bank_cache/adaclip_{tag}_visa.pt"),
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--batch_size",
            "1",
            "--num_workers",
            "4",
            "--cpu_threads",
            "4",
            "--backbone",
            cfg["model"],
            "--checkpoint_load_mode",
            "strict",
            "--model_layer_recipe",
            "all4",
            "--layer_recipe",
            "all4",
            "--enable_calibrator",
            "--calib_epochs",
            "30",
            "--calib_subspace_rank",
            "8",
            "--calib_insertion_mode",
            "prescore_rectify",
            "--calib_train_score_space",
            "cache_prob",
            "--calib_lambda",
            "0.3",
            "--calib_eta_max",
            "1.0",
            "--scoring_mode",
            "logit_gate_posneg",
            "--ours_image_score_mode",
            "official_plus_map_topk",
            "--eval_metrics",
            "I-AUROC",
            "I-AP",
            "P-AUROC",
            "P-AP",
            "P-AUPRO",
            "--aupro_max_step",
            "200",
        ],
        ROOT,
        LOG / f"adaclip_eval_{tag}.log",
        run_env,
    )
    make_table(env)


def main() -> int:
    gpu = sys.argv[1] if len(sys.argv) > 1 else "1"
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    (OUT / "bank_cache").mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-backbone-retrained-stress")
    make_table(env)
    for tag, cfg in ANOMALY.items():
        anomalyclip(tag, cfg, gpu, env)
    for tag, cfg in ADACLIP.items():
        adaclip(tag, cfg, gpu, env)
    make_table(env)
    print("[done] backbone-retrained stress", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
