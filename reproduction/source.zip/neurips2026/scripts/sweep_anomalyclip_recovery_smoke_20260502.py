from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
PROBE = ROOT / "neurips2026" / "scripts" / "probe_anomalyclip_text_decomposition_score.py"
CHECKPOINT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
SOURCE_ROOT = ROOT.parent / "ijepa" / "data" / "mvtec"
TARGET_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
BANK_CACHE = (
    ROOT
    / "neurips2026"
    / "results"
    / "anomalyclip_btc_lastlayer_fulltable_20260502"
    / "bank_cache"
    / "anomalyclip_mvtec2visa_lastlayer_withscores.pt"
)
OUT_ROOT = ROOT / "neurips2026" / "results" / "anomalyclip_recovery_smoke_20260502"


def pct(value: float) -> float:
    value = float(value)
    return value * 100.0 if abs(value) <= 1.5 else value


def mean_rows(summary_path: Path) -> dict[str, dict[str, float]]:
    data = json.loads(summary_path.read_text())
    out: dict[str, dict[str, float]] = {}
    for row in data.get("rows", []):
        if row.get("target_label") != "mean":
            continue
        out[str(row["mode"])] = {
            "I-AUC": pct(row["image_auroc"]),
            "P-AUC": pct(row["pixel_auroc"]),
            "P-PRO": pct(row["pixel_aupro"]),
            "P-AP": pct(row["pixel_ap"]),
        }
    return out


def tail_text(path: Path, max_lines: int = 16) -> str:
    if not path.exists():
        return ""
    lines = path.read_text(errors="replace").splitlines()
    return "\n".join(lines[-max_lines:])


def build_cmd(args: argparse.Namespace, cfg: dict[str, object], save_dir: Path) -> list[str]:
    cmd = [
        str(PYTHON),
        "-u",
        str(PROBE),
        "--device",
        args.device,
        "--checkpoint_path",
        str(CHECKPOINT),
        "--model_name_or_path",
        "ViT-L/14@336px",
        "--heldout_class",
        "none",
        "--source_root",
        str(SOURCE_ROOT.resolve()),
        "--source_dataset",
        "mvtec",
        "--target_root",
        str(TARGET_ROOT),
        "--target_dataset",
        "visa",
        "--target_mode",
        "test",
        "--features_list",
        "24",
        "--baseline_features_list",
        "24",
        "--dpam_layer",
        "20",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--ted_margin_sign",
        str(cfg["sign"]),
        "--hard_frac",
        "0.01",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "2048",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--score_bank_cache_path",
        str(BANK_CACHE),
        "--enable_calibrator",
        "--calib_seed",
        "0",
        "--calib_epochs",
        str(args.calib_epochs),
        "--calib_subspace_rank",
        str(cfg["rank"]),
        "--calib_eta_max",
        str(cfg["eta"]),
        "--calib_lambda",
        str(cfg["lam"]),
        "--calib_map_anchor",
        str(cfg["anchor"]),
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "0.2",
        "--calibrated_image_fusion_weight",
        "0.02",
        "--aupro_max_step",
        str(args.aupro_max_step),
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if args.max_normal >= 0:
        cmd.extend(["--max_normal_eval_images", str(args.max_normal)])
    if args.max_anomaly >= 0:
        cmd.extend(["--max_anomaly_eval_images", str(args.max_anomaly)])
    if cfg.get("gate"):
        cmd.extend(["--ted_layer_gate", str(cfg["gate"]), "--ted_layer_gate_fallback", "last"])
    return cmd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--max_normal", type=int, default=2)
    parser.add_argument("--max_anomaly", type=int, default=4)
    parser.add_argument("--calib_epochs", type=int, default=40)
    parser.add_argument("--aupro_max_step", type=int, default=80)
    parser.add_argument("--only", default=None, help="Run a single config by name.")
    parser.add_argument("--tag", default="last", help="Prefix tag used in output directory names.")
    args = parser.parse_args()

    configs = [
        {"name": "def_hostfull_r8_e02_l003", "sign": "def_minus_fp", "anchor": "host_full", "rank": 8, "eta": 0.2, "lam": 0.03},
        {"name": "fp_hostfull_r8_e02_l003", "sign": "fp_minus_def", "anchor": "host_full", "rank": 8, "eta": 0.2, "lam": 0.03},
        {"name": "auto_hostfull_r8_e02_l003", "sign": "auto_source", "anchor": "host_full", "rank": 8, "eta": 0.2, "lam": 0.03},
        {"name": "fp_hostfull_r4_e02_l003", "sign": "fp_minus_def", "anchor": "host_full", "rank": 4, "eta": 0.2, "lam": 0.03},
        {"name": "fp_hostfull_r8_e01_l001", "sign": "fp_minus_def", "anchor": "host_full", "rank": 8, "eta": 0.1, "lam": 0.01},
        {"name": "fp_hostfull_r8_e05_l001", "sign": "fp_minus_def", "anchor": "host_full", "rank": 8, "eta": 0.5, "lam": 0.01},
        {"name": "fp_trainfree_r8_e02_l003", "sign": "fp_minus_def", "anchor": "trainfree", "rank": 8, "eta": 0.2, "lam": 0.03},
        {"name": "def_trainfree_r8_e02_l003", "sign": "def_minus_fp", "anchor": "trainfree", "rank": 8, "eta": 0.2, "lam": 0.03},
    ]
    if args.only:
        configs = [cfg for cfg in configs if cfg["name"] == args.only]
        if not configs:
            raise ValueError(f"Unknown --only config: {args.only}")

    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    records = []
    for cfg in configs:
        save_dir = OUT_ROOT / f"mvtec2visa_{args.tag}_{cfg['name']}"
        summary_path = save_dir / "summary.json"
        if args.force or not summary_path.exists():
            print(json.dumps({"stage": "run_start", **cfg, "save_dir": str(save_dir)}), flush=True)
            save_dir.mkdir(parents=True, exist_ok=True)
            log_path = save_dir / "run.log"
            with log_path.open("w") as log_f:
                try:
                    subprocess.run(
                        build_cmd(args, cfg, save_dir),
                        cwd=str(ROOT),
                        check=True,
                        stdout=log_f,
                        stderr=subprocess.STDOUT,
                    )
                except subprocess.CalledProcessError:
                    print(json.dumps({"stage": "run_failed", "config": cfg["name"], "log": str(log_path)}), flush=True)
                    print(tail_text(log_path), flush=True)
                    raise
        rows = mean_rows(summary_path)
        base = rows.get("baseline_txt", {})
        tted = rows.get("parallel_margin", {})
        cted = rows.get("ted_calibrated", {})
        rec = {"config": cfg["name"], **cfg}
        for prefix, row in [("B", base), ("T", tted), ("C", cted)]:
            for metric, value in row.items():
                rec[f"{prefix}_{metric}"] = value
        records.append(rec)
        print(json.dumps({"stage": "run_done", "config": cfg["name"], "B": base, "T": tted, "C": cted}), flush=True)

    csv_path = OUT_ROOT / f"mvtec2visa_{args.tag}_recovery_sweep.csv"
    keys = list(records[0].keys())
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(records)

    md_path = OUT_ROOT / f"mvtec2visa_{args.tag}_recovery_sweep.md"
    lines = ["| config | sign | anchor | rank | eta | lambda | T P-AUC | T P-PRO | T P-AP | C P-AUC | C P-PRO | C P-AP |", "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for rec in records:
        lines.append(
            f"| {rec['config']} | {rec['sign']} | {rec['anchor']} | {rec['rank']} | {rec['eta']} | {rec['lam']} | "
            f"{rec['T_P-AUC']:.2f} | {rec['T_P-PRO']:.2f} | {rec['T_P-AP']:.2f} | "
            f"{rec['C_P-AUC']:.2f} | {rec['C_P-PRO']:.2f} | {rec['C_P-AP']:.2f} |"
        )
    md_path.write_text("\n".join(lines) + "\n")
    print(json.dumps({"stage": "sweep_done", "csv": str(csv_path), "md": str(md_path)}), flush=True)


if __name__ == "__main__":
    main()
