from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADAPT_ROOT = ROOT / "neurips2026" / "AdaptCLIP"
if str(ADAPT_ROOT) not in sys.path:
    sys.path.insert(0, str(ADAPT_ROOT))
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(1, str(SCRIPT_ROOT))

from adaptcliplib.adaptclip import compute_similarity, get_similarity_map  # noqa: E402
from official_parallel_test_adaptclip import (  # noqa: E402
    Evaluator,
    activate_margin_map,
    aggregate_results,
    build_dataset,
    build_model,
    compute_baseline_outputs,
    decision_axis,
    farthest_point_subsample,
    fusion_fun,
    logmeanexp_negative_sqdist_1d,
    save_bank_cache,
    load_bank_cache,
    smooth_map,
)


def append_result(results: dict, mode: str, sample_id: str, cls_name: str, query_path: str, gt_mask: torch.Tensor, gt_anomaly: torch.Tensor, pr_map: torch.Tensor, pr_score: torch.Tensor) -> None:
    results[mode]["sample_ids"].append(sample_id)
    results[mode]["cls_names"].append(cls_name)
    results[mode]["query_paths"].append(query_path)
    results[mode]["gt_masks"].append(gt_mask.detach().cpu().int())
    results[mode]["pr_masks"].append(pr_map.detach().cpu())
    results[mode]["gt_anomalys"].append(gt_anomaly.detach().cpu())
    results[mode]["pr_anomalys"].append(pr_score.detach().cpu())


def static_text_pair(static_text_features: torch.Tensor) -> torch.Tensor:
    text_pair = torch.stack(torch.chunk(static_text_features, dim=0, chunks=2), dim=1)
    return F.normalize(text_pair, dim=-1)


def adapted_vl_patch_and_map(visual_learner, patch_feature: torch.Tensor, static_pair: torch.Tensor, image_size: int) -> tuple[torch.Tensor, torch.Tensor]:
    patch_feature = visual_learner.local_adater(patch_feature)
    patch_feature = F.normalize(patch_feature.float(), dim=-1)
    similarity, _ = compute_similarity(patch_feature, static_pair[0])
    similarity_map = get_similarity_map(similarity[:, 1:, :], image_size).permute(0, 3, 1, 2)
    vl_map = similarity_map[:, 1]
    patch_tokens = patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1])
    return F.normalize(patch_tokens.float(), dim=-1), vl_map


def collect_vl_banks(
    model,
    textual_learner,
    visual_learner,
    learned_text_features: torch.Tensor,
    source_root: str,
    source_dataset: str,
    image_size: int,
    features_list: list[int],
    dpam_layer: int,
    sigma: float,
    device: str,
    hard_frac: float,
    max_good_per_class: int,
    max_defect_per_class: int,
    max_bank_points: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    use_multilayer: bool,
):
    train_ds = build_dataset(source_root, image_size, source_dataset, "train", str(ROOT / "neurips2026" / "results" / "_tmp_vlcompare"))
    test_ds = build_dataset(source_root, image_size, source_dataset, "test", str(ROOT / "neurips2026" / "results" / "_tmp_vlcompare"))
    static_pair = static_text_pair(textual_learner.static_text_features)

    layer_count = len(features_list) if use_multilayer else 1
    fp_chunks = {i: [] for i in range(layer_count)}
    def_chunks = {i: [] for i in range(layer_count)}
    per_good = {cls_name: 0 for cls_name in train_ds.obj_list}
    per_defect = {cls_name: 0 for cls_name in test_ds.obj_list}

    with torch.no_grad():
        for idx in range(len(train_ds)):
            item = train_ds[idx]
            cls_name = item["cls_name"]
            if per_good[cls_name] >= max_good_per_class:
                continue
            per_good[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            outputs = compute_baseline_outputs(
                model,
                textual_learner,
                visual_learner,
                learned_text_features,
                image,
                features_list,
                dpam_layer,
                image_size,
                sigma,
                "average_mean",
            )
            selected_layers = range(len(outputs["query_patch_feats"])) if use_multilayer else [len(outputs["query_patch_feats"]) - 1]
            for out_idx, layer_idx in enumerate(selected_layers):
                patch_tokens, vl_map = adapted_vl_patch_and_map(
                    visual_learner,
                    outputs["query_patch_feats"][layer_idx],
                    static_pair,
                    image_size,
                )
                mining_map = smooth_map(vl_map, sigma=sigma)[0].to(device)
                h = int(round(patch_tokens.shape[0] ** 0.5))
                score_small = F.interpolate(mining_map[None, None], size=(h, h), mode="bilinear", align_corners=False)[0, 0].reshape(-1)
                k = max(1, int(score_small.numel() * hard_frac))
                top_idx = torch.topk(score_small, k=k, largest=True).indices
                selected = patch_tokens[top_idx]
                if selected.shape[0] > max_fp_per_image:
                    selected = farthest_point_subsample(selected, max_fp_per_image)
                fp_chunks[out_idx].append(selected.cpu())

        for idx in range(len(test_ds)):
            item = test_ds[idx]
            cls_name = item["cls_name"]
            if int(item["anomaly"]) == 0:
                continue
            if per_defect[cls_name] >= max_defect_per_class:
                continue
            per_defect[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"].unsqueeze(0).to(device).float()
            _, query_patch_feats = model.encode_image(image, features_list, DPAM_layer=dpam_layer)
            selected_layers = range(len(query_patch_feats)) if use_multilayer else [len(query_patch_feats) - 1]
            for out_idx, layer_idx in enumerate(selected_layers):
                patch_tokens, _ = adapted_vl_patch_and_map(visual_learner, query_patch_feats[layer_idx], static_pair, image_size)
                h = int(round(patch_tokens.shape[0] ** 0.5))
                gt_small = F.interpolate(gt_mask, size=(h, h), mode="nearest")[0, 0].reshape(-1) > 0.5
                if int(gt_small.sum().item()) == 0:
                    continue
                selected = patch_tokens[gt_small]
                if selected.shape[0] > max_defect_per_image:
                    selected = farthest_point_subsample(selected, max_defect_per_image)
                def_chunks[out_idx].append(selected.cpu())

    fp_banks, def_banks, bank_stats = {}, {}, {}
    for layer_idx in range(layer_count):
        feat_dim = 768
        if fp_chunks[layer_idx]:
            feat_dim = fp_chunks[layer_idx][0].shape[-1]
        elif def_chunks[layer_idx]:
            feat_dim = def_chunks[layer_idx][0].shape[-1]
        fp_bank = torch.cat(fp_chunks[layer_idx], dim=0) if fp_chunks[layer_idx] else torch.empty((0, feat_dim))
        def_bank = torch.cat(def_chunks[layer_idx], dim=0) if def_chunks[layer_idx] else torch.empty((0, feat_dim))
        if fp_bank.shape[0] > max_bank_points:
            fp_bank = farthest_point_subsample(fp_bank, max_bank_points)
        if def_bank.shape[0] > max_bank_points:
            def_bank = farthest_point_subsample(def_bank, max_bank_points)
        fp_bank = F.normalize(fp_bank.float(), dim=-1) if fp_bank.numel() else fp_bank.float()
        def_bank = F.normalize(def_bank.float(), dim=-1) if def_bank.numel() else def_bank.float()
        fp_banks[layer_idx] = fp_bank
        def_banks[layer_idx] = def_bank
        bank_stats[layer_idx] = {"num_fp": int(fp_bank.shape[0]), "num_defect": int(def_bank.shape[0])}
    return fp_banks, def_banks, bank_stats


def get_or_collect_vl_banks(cache_path: Path, requested_meta: dict, **kwargs):
    if cache_path.exists():
        try:
            fp_banks, def_banks, bank_stats, cache_meta = load_bank_cache(cache_path)
            if cache_meta == requested_meta:
                return fp_banks, def_banks, bank_stats, cache_meta
        except Exception:
            pass
    fp_banks, def_banks, bank_stats = collect_vl_banks(**kwargs)
    save_bank_cache(cache_path, fp_banks, def_banks, bank_stats, requested_meta)
    return fp_banks, def_banks, bank_stats, requested_meta


def main() -> None:
    parser = argparse.ArgumentParser("AdaptCLIP VL last-layer vs multilayer comparison")
    parser.add_argument("--source_root", type=str, required=True)
    parser.add_argument("--source_dataset", type=str, required=True)
    parser.add_argument("--target_root", type=str, required=True)
    parser.add_argument("--target_dataset", type=str, required=True)
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument("--save_path", type=str, required=True)
    parser.add_argument("--last_bank_cache_path", type=str, required=True)
    parser.add_argument("--multi_bank_cache_path", type=str, required=True)
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--fusion_type", type=str, default="average_mean")
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_points", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--fp_weight", type=float, default=0.3)
    parser.add_argument("--corr_alpha", type=float, default=0.3)
    parser.add_argument("--map_activation", type=str, default="sigmoid")
    parser.add_argument("--map_temperature", type=float, default=1.0)
    parser.add_argument("--max_eval_images", type=int, default=32)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    save_path = Path(args.save_path)
    save_path.parent.mkdir(parents=True, exist_ok=True)

    model, textual_learner, visual_learner, learned_text_features, dpam_layer = build_model(
        args.device,
        args.checkpoint_path,
        args.image_size,
        args.n_ctx,
        args.vl_reduction,
        args.pretrained_model,
    )
    vl_axis = decision_axis(textual_learner.static_text_features).to(args.device)
    static_pair = static_text_pair(textual_learner.static_text_features)

    common_meta = {
        "kind": "adaptclip_vl_layer_compare_bank",
        "checkpoint_path": args.checkpoint_path,
        "source_root": args.source_root,
        "source_dataset": args.source_dataset,
        "image_size": args.image_size,
        "features_list": list(args.features_list),
        "hard_frac": args.hard_frac,
        "max_good_per_class": args.max_good_per_class,
        "max_defect_per_class": args.max_defect_per_class,
        "max_bank_points": args.max_bank_points,
        "max_fp_per_image": args.max_fp_per_image,
        "max_defect_per_image": args.max_defect_per_image,
    }
    last_fp, last_def, last_stats, last_meta = get_or_collect_vl_banks(
        Path(args.last_bank_cache_path),
        {**common_meta, "vl_layer_mode": "last"},
        model=model,
        textual_learner=textual_learner,
        visual_learner=visual_learner,
        learned_text_features=learned_text_features,
        source_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        dpam_layer=dpam_layer,
        sigma=args.sigma,
        device=args.device,
        hard_frac=args.hard_frac,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_bank_points=args.max_bank_points,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        use_multilayer=False,
    )
    multi_fp, multi_def, multi_stats, multi_meta = get_or_collect_vl_banks(
        Path(args.multi_bank_cache_path),
        {**common_meta, "vl_layer_mode": "multilayer"},
        model=model,
        textual_learner=textual_learner,
        visual_learner=visual_learner,
        learned_text_features=learned_text_features,
        source_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        dpam_layer=dpam_layer,
        sigma=args.sigma,
        device=args.device,
        hard_frac=args.hard_frac,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_bank_points=args.max_bank_points,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        use_multilayer=True,
    )

    dataset = build_dataset(
        args.target_root,
        args.image_size,
        args.target_dataset,
        "test",
        str(ROOT / "neurips2026" / "results" / "_tmp_vlcompare_eval"),
        class_name=args.class_name,
    )
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
    evaluator = Evaluator("cpu", metrics=["I-AUROC", "I-AP", "P-AUROC", "P-AP"], sample_level=False)

    modes = ["baseline_txt", "vl_last_map", "vl_last_refuse", "vl_multi_map", "vl_multi_refuse"]
    results = {
        mode: {"sample_ids": [], "gt_masks": [], "pr_masks": [], "cls_names": [], "gt_anomalys": [], "pr_anomalys": [], "query_paths": []}
        for mode in modes
    }

    with torch.no_grad():
        for idx, items in enumerate(loader, start=1):
            if args.max_eval_images is not None and idx > args.max_eval_images:
                break
            image = items["img"].to(args.device)
            cls_name = items["cls_name"][0]
            sample_id = f"{cls_name}_{idx}"
            query_path = items["img_path"][0]
            gt_mask = items["img_mask"][:, 0].clone().to(args.device)
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask = gt_mask.int()
            gt_anomaly = items["anomaly"].to(args.device).int()

            baseline = compute_baseline_outputs(
                model,
                textual_learner,
                visual_learner,
                learned_text_features,
                image,
                args.features_list,
                dpam_layer,
                args.image_size,
                args.sigma,
                args.fusion_type,
            )

            layer_vl_maps = []
            layer_margin_maps = []
            for layer_pos, patch_feature in enumerate(baseline["query_patch_feats"]):
                patch_tokens, vl_map = adapted_vl_patch_and_map(visual_learner, patch_feature, static_pair, args.image_size)
                coeff = patch_tokens @ vl_axis
                q_fp = logmeanexp_negative_sqdist_1d(coeff, multi_fp[layer_pos].to(args.device) @ vl_axis, tau=args.tau)
                q_def = logmeanexp_negative_sqdist_1d(coeff, multi_def[layer_pos].to(args.device) @ vl_axis, tau=args.tau)
                h = int(round(patch_tokens.shape[0] ** 0.5))
                margin_map = (q_def - args.fp_weight * q_fp).reshape(1, 1, h, h)
                margin_map = F.interpolate(margin_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
                margin_map = smooth_map(margin_map, sigma=args.sigma).to(args.device)
                margin_map = activate_margin_map(margin_map, activation=args.map_activation, temperature=args.map_temperature)
                layer_vl_maps.append(smooth_map(vl_map, sigma=args.sigma).to(args.device))
                layer_margin_maps.append(margin_map)

            vl_multi_map = torch.stack(layer_vl_maps, dim=0).mean(dim=0)
            margin_multi_map = torch.stack(layer_margin_maps, dim=0).mean(dim=0)
            vl_multi_refined = torch.clamp(vl_multi_map + args.corr_alpha * (margin_multi_map - 0.5), 0.0, 1.0)
            vl_multi_refuse = smooth_map(fusion_fun([baseline["local_tl_map"], vl_multi_refined], fusion_type=args.fusion_type), sigma=args.sigma).to(args.device)

            last_patch_tokens, last_vl_raw_map = adapted_vl_patch_and_map(visual_learner, baseline["query_patch_feats"][-1], static_pair, args.image_size)
            last_coeff = last_patch_tokens @ vl_axis
            q_fp_last = logmeanexp_negative_sqdist_1d(last_coeff, last_fp[0].to(args.device) @ vl_axis, tau=args.tau)
            q_def_last = logmeanexp_negative_sqdist_1d(last_coeff, last_def[0].to(args.device) @ vl_axis, tau=args.tau)
            h_last = int(round(last_patch_tokens.shape[0] ** 0.5))
            margin_last_map = (q_def_last - args.fp_weight * q_fp_last).reshape(1, 1, h_last, h_last)
            margin_last_map = F.interpolate(margin_last_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
            margin_last_map = smooth_map(margin_last_map, sigma=args.sigma).to(args.device)
            margin_last_map = activate_margin_map(margin_last_map, activation=args.map_activation, temperature=args.map_temperature)
            vl_last_map = smooth_map(last_vl_raw_map, sigma=args.sigma).to(args.device)
            vl_last_refined = torch.clamp(vl_last_map + args.corr_alpha * (margin_last_map - 0.5), 0.0, 1.0)
            vl_last_refuse = smooth_map(fusion_fun([baseline["local_tl_map"], vl_last_refined], fusion_type=args.fusion_type), sigma=args.sigma).to(args.device)

            score_map = {
                "baseline_txt": baseline["baseline_map"],
                "vl_last_map": vl_last_map,
                "vl_last_refuse": vl_last_refuse,
                "vl_multi_map": vl_multi_map,
                "vl_multi_refuse": vl_multi_refuse,
            }
            global_vl = baseline["global_vl_score"]
            global_tl = baseline["global_tl_score"]
            for mode, map_tensor in score_map.items():
                anomaly_map_max, _ = torch.max(map_tensor.view(image.shape[0], -1), dim=1)
                img_score = fusion_fun([global_vl, global_tl, anomaly_map_max], fusion_type=args.fusion_type)
                append_result(results, mode, sample_id, cls_name, query_path, gt_mask, gt_anomaly, map_tensor, img_score)

    metrics = {}
    for mode in modes:
        result_mode = aggregate_results(results[mode])
        metric_results = evaluator.run(result_mode, args.class_name)
        metrics[mode] = {
            "image_auroc": float(metric_results["I-AUROC"]),
            "image_ap": float(metric_results["I-AP"]),
            "pixel_auroc": float(metric_results["P-AUROC"]),
            "pixel_ap": float(metric_results["P-AP"]),
        }

    output = {
        "class_name": args.class_name,
        "last_bank_stats": last_stats,
        "multi_bank_stats": multi_stats,
        "last_bank_meta": last_meta,
        "multi_bank_meta": multi_meta,
        "metrics": metrics,
    }
    save_path.write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
