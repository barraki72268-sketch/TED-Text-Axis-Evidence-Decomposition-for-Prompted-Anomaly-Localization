#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "efficiency_bank_budget_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "efficiency_bank_budget_20260504"


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_aaclip(preset: str, budget: int, device: str, seed: int) -> tuple[list[str], Path, Path]:
    save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_bank{budget}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        str(budget),
        "--max_defect_per_class",
        str(budget),
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "replace,prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def build_faprompt(preset: str, budget: int, device: str, seed: int) -> tuple[list[str], Path, Path]:
    save_dir = RESULTS / f"faprompt_vitl336_{preset}_bank{budget}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    total = max(2 * int(budget), int(budget))
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        str(budget),
        "--max_defect_per_class",
        str(budget),
        "--max_fp_total",
        str(total),
        "--max_defect_total",
        str(total),
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "support_only,branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def build_job(host: str, preset: str, budget: int, device: str, seed: int) -> tuple[list[str], Path, Path]:
    if host == "aaclip":
        return build_aaclip(preset, budget, device, seed)
    if host == "faprompt":
        return build_faprompt(preset, budget, device, seed)
    raise SystemExit(f"Unsupported host={host}")


def write_worker(worker_id: int, jobs: list[dict], force: bool, sample_interval: float) -> Path:
    LOGS.mkdir(parents=True, exist_ok=True)
    worker_path = LOGS / f"efficiency_worker_{worker_id}.py"
    payload = {"root": str(ROOT), "jobs": jobs, "force": bool(force), "sample_interval": float(sample_interval)}
    worker_path.write_text(
        "from __future__ import annotations\n"
        "import json, subprocess, time\n"
        "from pathlib import Path\n\n"
        f"PAYLOAD = json.loads({json.dumps(json.dumps(payload))})\n\n"
        "def query_gpu_mem(pid: int) -> int:\n"
        "    try:\n"
        "        out = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'], text=True)\n"
        "    except Exception:\n"
        "        return 0\n"
        "    peak = 0\n"
        "    for line in out.splitlines():\n"
        "        parts = [p.strip() for p in line.split(',')]\n"
        "        if len(parts) < 2:\n"
        "            continue\n"
        "        try:\n"
        "            if int(parts[0]) == pid:\n"
        "                peak = max(peak, int(parts[1]))\n"
        "        except ValueError:\n"
        "            pass\n"
        "    return peak\n\n"
        "root = Path(PAYLOAD['root'])\n"
        "for job in PAYLOAD['jobs']:\n"
        "    save_dir = Path(job['save_dir'])\n"
        "    summary = save_dir / 'summary.json'\n"
        "    runtime_path = save_dir / 'runtime.json'\n"
        "    if summary.exists() and runtime_path.exists() and not PAYLOAD['force']:\n"
        "        print(json.dumps({'stage': 'skip_done', 'summary': str(summary)}), flush=True)\n"
        "        continue\n"
        "    save_dir.mkdir(parents=True, exist_ok=True)\n"
        "    log_path = Path(job['log_path'])\n"
        "    log_path.parent.mkdir(parents=True, exist_ok=True)\n"
        "    print(json.dumps({'stage': 'job_start', **{k: job[k] for k in ['host','preset','budget','device']}, 'save_dir': str(save_dir)}), flush=True)\n"
        "    start = time.time()\n"
        "    peak = 0\n"
        "    with log_path.open('ab', buffering=0) as log_f:\n"
        "        proc = subprocess.Popen(job['cmd'], cwd=root, stdout=log_f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)\n"
        "        while proc.poll() is None:\n"
        "            peak = max(peak, query_gpu_mem(proc.pid))\n"
        "            time.sleep(PAYLOAD['sample_interval'])\n"
        "        peak = max(peak, query_gpu_mem(proc.pid))\n"
        "    elapsed = time.time() - start\n"
        "    runtime = {**job, 'elapsed_sec': elapsed, 'peak_gpu_mem_mb': peak, 'returncode': proc.returncode}\n"
        "    runtime_path.write_text(json.dumps(runtime, indent=2))\n"
        "    print(json.dumps({'stage': 'job_done', 'save_dir': str(save_dir), 'returncode': proc.returncode, 'elapsed_sec': elapsed, 'peak_gpu_mem_mb': peak}), flush=True)\n"
    )
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="aaclip,faprompt")
    ap.add_argument("--presets", default="mvtec2visa,mvtec2mpdd,mvtec2btad,visa2mvtec,visa2mpdd,visa2btad")
    ap.add_argument("--budgets", default="64,128,256,512")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--sample_interval", type=float, default=2.0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = parse_csv(args.hosts)
    presets = parse_csv(args.presets)
    budgets = [int(x) for x in parse_csv(args.budgets)]
    devices = parse_csv(args.devices)
    buckets: list[list[dict]] = [[] for _ in devices]
    all_jobs = []
    for host in hosts:
        for preset in presets:
            for budget in budgets:
                bucket_id = len(all_jobs) % len(devices)
                device = devices[bucket_id]
                cmd, save_dir, log_path = build_job(host, preset, budget, device, args.seed)
                job = {
                    "cmd": cmd,
                    "save_dir": str(save_dir),
                    "log_path": str(log_path),
                    "host": host,
                    "preset": preset,
                    "budget": budget,
                    "device": device,
                }
                buckets[bucket_id].append(job)
                all_jobs.append(job)

    launched = []
    for worker_id, jobs in enumerate(buckets):
        if not jobs:
            continue
        worker_path = write_worker(worker_id, jobs, args.force, args.sample_interval)
        worker_log = LOGS / f"efficiency_worker_{worker_id}.log"
        log_f = worker_log.open("ab", buffering=0)
        proc = subprocess.Popen(
            [str(PY), "-u", str(worker_path)],
            cwd=ROOT,
            stdout=log_f,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        launched.append({"worker": worker_id, "pid": proc.pid, "device": devices[worker_id], "num_jobs": len(jobs), "log": str(worker_log)})
    print(json.dumps({"stage": "efficiency_bank_budget_queue", "num_jobs": len(all_jobs), "workers": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
