#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

PY="/mnt/data/envs/patchcore-conda/bin/python"
DEVICE="${DEVICE:-cuda:0}"

run_vitl_openai() {
  local preset="$1"
  local save_dir="$2"
  echo "[$(date '+%F %T')] start AA-CLIP ViT-L/openai ${preset} -> ${save_dir}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip.py \
    --preset "${preset}" \
    --model_name ViT-L-14-336 \
    --pretrained openai \
    --adapter_load_mode strict \
    --levels 6,12,18,24 \
    --img_size 224 \
    --batch_size 8 \
    --num_workers 4 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas=-0.5,0.05 \
    --blend_modes prescore_rectify \
    --candidate_topk_frac 0.10 \
    --gate_sharpness 3.0 \
    --candidate_image_mode map_topk \
    --cal_pro \
    --aupro_max_step 50 \
    --device "${DEVICE}" \
    --save_dir "${save_dir}"
  echo "[$(date '+%F %T')] done AA-CLIP ViT-L/openai ${preset}"
}

run_vitl_openai visa2mvtec neurips2026/results/aaclip_prescore_segtoken_vitl_openai_visa2mvtec_img224_map_topk_pro_20260427
run_vitl_openai mvtec2visa neurips2026/results/aaclip_prescore_segtoken_vitl_openai_mvtec2visa_img224_map_topk_pro_20260427
run_vitl_openai visa2mpdd neurips2026/results/aaclip_prescore_segtoken_vitl_openai_visa2mpdd_img224_map_topk_pro_20260427
run_vitl_openai visa2btad neurips2026/results/aaclip_prescore_segtoken_vitl_openai_visa2btad_img224_map_topk_pro_20260427

echo "[$(date '+%F %T')] AA-CLIP ViT-L/openai full map_topk P-PRO queue finished"
