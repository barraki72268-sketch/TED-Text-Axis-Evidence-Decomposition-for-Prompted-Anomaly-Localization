#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "neurips2026" / "results" / "faprompt_ted_story_vitl336_mvtec2visa_pcb1_alpha15"
FIG = ROOT / "figure"

C_DEFECT = "#D64A2F"
C_HARD = "#2878A7"
C_DARK = "#202020"


def setup_rc() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.weight": "bold",
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def auc_pos_vs_neg(pos: np.ndarray, neg: np.ndarray) -> float:
    scores = np.concatenate([pos, neg])
    labels = np.concatenate([np.ones(pos.size, dtype=np.int64), np.zeros(neg.size, dtype=np.int64)])
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, scores.size + 1, dtype=np.float64)
    pos_ranks = ranks[labels == 1]
    return float((pos_ranks.sum() - pos.size * (pos.size + 1) / 2.0) / (pos.size * neg.size))


def smooth(y: np.ndarray, sigma: float = 1.45, radius: int = 6) -> np.ndarray:
    x = np.arange(-radius, radius + 1, dtype=np.float32)
    k = np.exp(-(x * x) / (2.0 * sigma * sigma))
    k /= k.sum()
    return np.convolve(y, k, mode="same")


def hist_curve(pos: np.ndarray, neg: np.ndarray, bins: int = 70) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    lo = float(min(pos.min(), neg.min()))
    hi = float(max(pos.max(), neg.max()))
    if hi <= lo:
        hi = lo + 1e-6
    pad = 0.04 * (hi - lo)
    edges = np.linspace(lo - pad, hi + pad, bins + 1)
    hp, _ = np.histogram(pos, bins=edges, density=True)
    hn, _ = np.histogram(neg, bins=edges, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    hp = smooth(hp)
    hn = smooth(hn)
    dx = centers[1] - centers[0] if len(centers) > 1 else 1.0
    return centers, hp, hn, {
        "auc": auc_pos_vs_neg(pos, neg),
        "overlap": float(np.minimum(hp, hn).sum() * dx),
    }


def style_axis(ax: plt.Axes, *, labelsize: int = 24, ticksize: int = 21) -> None:
    ax.tick_params(axis="both", labelsize=ticksize, width=1.8, length=6)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("bold")
    ax.grid(alpha=0.16, linewidth=1.0)
    for spine in ax.spines.values():
        spine.set_linewidth(1.9)
    ax.xaxis.label.set_size(labelsize)
    ax.yaxis.label.set_size(labelsize)
    ax.xaxis.label.set_fontweight("bold")
    ax.yaxis.label.set_fontweight("bold")


def baseline_overlap_band_mask(labels: np.ndarray, baseline: np.ndarray) -> np.ndarray:
    pos_b = baseline[labels == 1]
    neg_b = baseline[labels == 0]
    lo = max(float(np.quantile(pos_b, 0.20)), float(np.quantile(neg_b, 0.20)))
    hi = min(float(np.quantile(pos_b, 0.80)), float(np.quantile(neg_b, 0.80)))
    mask = (baseline >= lo) & (baseline <= hi)
    if int(mask.sum()) < 40:
        lo = max(float(np.quantile(pos_b, 0.10)), float(np.quantile(neg_b, 0.10)))
        hi = min(float(np.quantile(pos_b, 0.90)), float(np.quantile(neg_b, 0.90)))
        mask = (baseline >= lo) & (baseline <= hi)
    if int(mask.sum()) < 20:
        mask = np.ones_like(labels, dtype=bool)
    return mask


def oriented_rankr_residual(data: np.lib.npyio.NpzFile) -> np.ndarray:
    labels = data["labels"]
    residual = data["xy"][:, 1].astype(np.float32)
    if np.median(residual[labels == 1]) < np.median(residual[labels == 0]):
        residual = -residual
    return residual


def draw_hist_panel(ax: plt.Axes, pos: np.ndarray, neg: np.ndarray, selected: dict, xlabel: str) -> dict:
    centers, hp, hn, stats = hist_curve(pos, neg)
    overlap = np.minimum(hp, hn)
    ax.fill_between(centers, hp, color=C_DEFECT, alpha=0.30)
    ax.fill_between(centers, hn, color=C_HARD, alpha=0.24)
    ax.fill_between(centers, overlap, color="#4b4b4b", alpha=0.16, hatch="///", edgecolor="#4b4b4b", linewidth=0)
    ax.plot(centers, hp, color=C_DEFECT, linewidth=4.0, linestyle="--", label="defect")
    ax.plot(centers, hn, color=C_HARD, linewidth=4.0, label="hard normal")
    ax.axvline(float(np.median(pos)), color=C_DEFECT, linewidth=3.0, linestyle="--", alpha=0.88)
    ax.axvline(float(np.median(neg)), color=C_HARD, linewidth=3.0, alpha=0.80)
    ymax = max(float(hp.max()), float(hn.max()), 1e-6)
    ax.scatter([selected["defect"]], [0.15 * ymax], s=270, marker="^", color=C_DEFECT, edgecolor="black", linewidth=2.0, zorder=20)
    ax.scatter([selected["hard_normal"]], [0.09 * ymax], s=250, marker="o", color=C_HARD, edgecolor="black", linewidth=2.0, zorder=20)
    ax.set_xlabel(xlabel, fontsize=24, fontweight="bold", labelpad=10)
    ax.set_ylabel("Density", fontsize=24, fontweight="bold", labelpad=10)
    ax.text(
        0.96,
        0.92,
        f"Overlap {stats['overlap']:.3f}",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=21,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#d8d8d8", "alpha": 0.92, "pad": 4.5},
    )
    style_axis(ax)
    return stats


def save_histogram(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    baseline = data["baseline"].astype(np.float32)
    rankr = oriented_rankr_residual(data)
    band = baseline_overlap_band_mask(labels, baseline)
    pos = (labels == 1) & band
    neg = (labels == 0) & band
    selected_ids = {
        "defect": int(meta["selected"]["defect"]["record_id"]),
        "hard_normal": int(meta["selected"]["hard_normal"]["record_id"]),
    }

    fig = plt.figure(figsize=(13.8, 3.45), constrained_layout=False)
    ax0 = fig.add_axes([0.075, 0.18, 0.405, 0.76])
    ax1 = fig.add_axes([0.565, 0.18, 0.405, 0.76])
    draw_hist_panel(
        ax0,
        baseline[pos],
        baseline[neg],
        {"defect": baseline[selected_ids["defect"]], "hard_normal": baseline[selected_ids["hard_normal"]]},
        "",
    )
    draw_hist_panel(
        ax1,
        rankr[pos],
        rankr[neg],
        {"defect": rankr[selected_ids["defect"]], "hard_normal": rankr[selected_ids["hard_normal"]]},
        "",
    )
    ax1.set_ylabel("")
    ax0.set_xlabel("")
    ax1.set_xlabel("")
    # Put a compact custom legend in the top-left margin of the OURS panel,
    # above the main density mass, instead of using a large legend box.
    ymax = ax1.get_ylim()[1]
    ax1.set_ylim(ax1.get_ylim()[0], ymax * 1.56)
    legend_y1 = ymax * 1.43
    legend_y2 = ymax * 1.26
    x0, x1 = ax1.get_xlim()
    dx = x1 - x0
    lx0 = x0 + 0.050 * dx
    lx1 = x0 + 0.175 * dx
    tx = x0 + 0.205 * dx
    ax1.plot([lx0, lx1], [legend_y1, legend_y1], color=C_DEFECT, lw=5.0, ls="--", clip_on=False)
    ax1.text(tx, legend_y1, "defect", fontsize=18, fontweight="bold", ha="left", va="center")
    ax1.plot([lx0, lx1], [legend_y2, legend_y2], color=C_HARD, lw=5.0, clip_on=False)
    ax1.text(tx, legend_y2, "hard normal", fontsize=18, fontweight="bold", ha="left", va="center")
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_pcb_histogram_bigfont.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_pcb_histogram_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_scatter(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    baseline = data["baseline"].astype(np.float32)
    text_coord = data["xy"][:, 0].astype(np.float32)
    residual_coord = oriented_rankr_residual(data)
    band = baseline_overlap_band_mask(labels, baseline)
    rng = np.random.default_rng(0)
    idx_all = np.where(band)[0]
    keep = []
    for lab in (0, 1):
        idx = idx_all[labels[idx_all] == lab]
        if idx.size:
            keep.append(rng.choice(idx, size=min(145, idx.size), replace=False))
    keep = np.concatenate(keep) if keep else idx_all
    selected_ids = {
        "defect": int(meta["selected"]["defect"]["record_id"]),
        "hard_normal": int(meta["selected"]["hard_normal"]["record_id"]),
    }
    keep = np.unique(np.concatenate([keep, np.asarray([selected_ids["defect"], selected_ids["hard_normal"]], dtype=np.int64)]))
    y_jitter = rng.normal(0.0, 0.025, size=keep.shape[0]).astype(np.float32)
    axis_scores = text_coord[band]
    residual_scores = residual_coord[band]
    band_labels = labels[band]
    axis_gap = float(np.median(axis_scores[band_labels == 1]) - np.median(axis_scores[band_labels == 0]))
    lift_gap = float(np.median(residual_scores[band_labels == 1]) - np.median(residual_scores[band_labels == 0]))

    fig = plt.figure(figsize=(12.8, 3.95), constrained_layout=False)
    ax0 = fig.add_axes([0.075, 0.20, 0.405, 0.72])
    ax1 = fig.add_axes([0.565, 0.20, 0.405, 0.72])

    def draw(ax: plt.Axes, mode: str) -> None:
        for lab, color, marker, size in [(0, C_HARD, "o", 72), (1, C_DEFECT, "^", 84)]:
            sub = keep[labels[keep] == lab]
            if sub.size == 0:
                continue
            if mode == "baseline":
                sub_pos = np.isin(keep, sub)
                ax.scatter(text_coord[sub], y_jitter[sub_pos], s=size, color=color, alpha=0.60, edgecolors="white", linewidths=0.7, marker=marker)
            else:
                ax.scatter(text_coord[sub], residual_coord[sub], s=size, color=color, alpha=0.60, edgecolors="white", linewidths=0.7, marker=marker)

        for key, color, marker in [("defect", C_DEFECT, "^"), ("hard_normal", C_HARD, "o")]:
            rid = selected_ids[key]
            y = 0.0 if mode == "baseline" else residual_coord[rid]
            ax.scatter([text_coord[rid]], [y], s=310, color=color, marker=marker, edgecolor="black", linewidth=2.3, zorder=20)
        if mode == "baseline":
            ax.plot(
                [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
                [0.0, 0.0],
                color=C_DARK,
                linewidth=3.4,
                alpha=0.75,
                zorder=18,
            )
            ax.set_ylim(-0.11, 0.11)
        else:
            ax.plot(
                [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
                [residual_coord[selected_ids["defect"]], residual_coord[selected_ids["hard_normal"]]],
                color=C_DARK,
                linewidth=3.7,
                alpha=0.78,
                zorder=18,
            )
            def_med = float(np.median(residual_scores[band_labels == 1]))
            hard_med = float(np.median(residual_scores[band_labels == 0]))
            ax.axhline(def_med, color=C_DEFECT, linewidth=2.2, linestyle="--", alpha=0.72)
            ax.axhline(hard_med, color=C_HARD, linewidth=2.2, alpha=0.66)
            bracket_x = float(np.quantile(text_coord[keep], 0.96))
            ax.annotate(
                "",
                xy=(bracket_x, def_med),
                xytext=(bracket_x, hard_med),
                arrowprops={"arrowstyle": "<->", "lw": 2.8, "color": C_DARK, "alpha": 0.85},
            )
            r_vals = residual_coord[keep]
            rpad = 0.13 * max(float(r_vals.max() - r_vals.min()), 1e-6)
            ax.set_ylim(float(r_vals.min() - rpad), float(r_vals.max() + rpad))
        x_vals = text_coord[keep]
        xpad = 0.10 * max(float(x_vals.max() - x_vals.min()), 1e-6)
        ax.set_xlim(float(x_vals.min() - xpad), float(x_vals.max() + xpad))
        ax.axhline(0.0, color=C_DARK, linewidth=1.6, alpha=0.25)
        ax.set_xlabel("text-axis coordinate", fontsize=23, fontweight="bold", labelpad=8)
        style_axis(ax, labelsize=23, ticksize=20)

    draw(ax0, "baseline")
    draw(ax1, "ours")
    ax0.set_ylabel("")
    ax1.set_ylabel("")
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_pcb_scatter_bigfont.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_pcb_scatter_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def add_image_axis(fig: plt.Figure, rect: list[float], path: Path, color: str) -> None:
    ax = fig.add_axes(rect)
    ax.imshow(Image.open(path).convert("RGB"))
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_linewidth(5.0)
        spine.set_color(color)


def save_trace_pair(meta: dict) -> None:
    selected = meta["selected"]
    defect_full = ROOT / selected["defect"]["full_box_path"]
    defect_crop = ROOT / selected["defect"]["crop_path"]
    hard_full = ROOT / selected["hard_normal"]["full_box_path"]
    hard_crop = ROOT / selected["hard_normal"]["crop_path"]
    pair = meta["pair_info"]

    fig = plt.figure(figsize=(6.8, 4.15), constrained_layout=False)
    fig.text(0.08, 0.735, "defect patch", color=C_DEFECT, fontsize=20, fontweight="bold", ha="left", va="center")
    fig.text(0.08, 0.315, "FP patch", color=C_HARD, fontsize=20, fontweight="bold", ha="left", va="center")
    add_image_axis(fig, [0.365, 0.55, 0.245, 0.34], defect_full, C_DEFECT)
    add_image_axis(fig, [0.68, 0.55, 0.245, 0.34], defect_crop, C_DEFECT)
    add_image_axis(fig, [0.365, 0.13, 0.245, 0.34], hard_full, C_HARD)
    add_image_axis(fig, [0.68, 0.13, 0.245, 0.34], hard_crop, C_HARD)
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_pcb_traced_patch_pair_bigfont.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_pcb_traced_patch_pair_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_histogram_compact(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    baseline = data["baseline"].astype(np.float32)
    rankr = oriented_rankr_residual(data)
    band = baseline_overlap_band_mask(labels, baseline)
    pos = (labels == 1) & band
    neg = (labels == 0) & band
    selected_ids = {
        "defect": int(meta["selected"]["defect"]["record_id"]),
        "hard_normal": int(meta["selected"]["hard_normal"]["record_id"]),
    }

    fig = plt.figure(figsize=(8.2, 2.25), constrained_layout=False)
    ax0 = fig.add_axes([0.105, 0.18, 0.405, 0.78])
    ax1 = fig.add_axes([0.585, 0.18, 0.385, 0.78])
    draw_hist_panel(
        ax0,
        baseline[pos],
        baseline[neg],
        {"defect": baseline[selected_ids["defect"]], "hard_normal": baseline[selected_ids["hard_normal"]]},
        "",
    )
    draw_hist_panel(
        ax1,
        rankr[pos],
        rankr[neg],
        {"defect": rankr[selected_ids["defect"]], "hard_normal": rankr[selected_ids["hard_normal"]]},
        "",
    )
    ax0.set_xlabel("")
    ax1.set_xlabel("")
    ax1.set_ylabel("")
    ax0.yaxis.label.set_size(22)
    ax0.tick_params(axis="both", labelsize=17)
    ax1.tick_params(axis="both", labelsize=17)

    # Compact legend and AUC/overlap boxes for one-line figure placement.
    for txt in list(ax1.texts):
        txt.remove()
    ax0.texts[-1].set_fontsize(14)
    ax1.text(
        0.97,
        0.92,
        f"Overlap {hist_curve(rankr[pos], rankr[neg])[3]['overlap']:.3f}",
        transform=ax1.transAxes,
        ha="right",
        va="top",
        fontsize=14,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#d8d8d8", "alpha": 0.92, "pad": 2.6},
    )
    ax1.plot([0.06, 0.12], [0.91, 0.91], transform=ax1.transAxes, color=C_DEFECT, lw=2.8, ls="--", clip_on=False)
    ax1.text(0.135, 0.91, "D", transform=ax1.transAxes, fontsize=11.5, fontweight="bold", ha="left", va="center")
    ax1.plot([0.06, 0.12], [0.81, 0.81], transform=ax1.transAxes, color=C_HARD, lw=2.8, clip_on=False)
    ax1.text(0.135, 0.81, "H-FP", transform=ax1.transAxes, fontsize=11.5, fontweight="bold", ha="left", va="center")

    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_pcb_histogram_compact.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_pcb_histogram_compact.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_scatter_compact(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    baseline = data["baseline"].astype(np.float32)
    text_coord = data["xy"][:, 0].astype(np.float32)
    residual_coord = oriented_rankr_residual(data)
    band = baseline_overlap_band_mask(labels, baseline)
    rng = np.random.default_rng(0)
    idx_all = np.where(band)[0]
    keep = []
    for lab in (0, 1):
        idx = idx_all[labels[idx_all] == lab]
        if idx.size:
            keep.append(rng.choice(idx, size=min(145, idx.size), replace=False))
    keep = np.concatenate(keep) if keep else idx_all
    selected_ids = {
        "defect": int(meta["selected"]["defect"]["record_id"]),
        "hard_normal": int(meta["selected"]["hard_normal"]["record_id"]),
    }
    keep = np.unique(np.concatenate([keep, np.asarray([selected_ids["defect"], selected_ids["hard_normal"]], dtype=np.int64)]))
    y_jitter = rng.normal(0.0, 0.025, size=keep.shape[0]).astype(np.float32)

    fig = plt.figure(figsize=(6.2, 2.25), constrained_layout=False)
    ax0 = fig.add_axes([0.09, 0.19, 0.405, 0.76])
    ax1 = fig.add_axes([0.565, 0.19, 0.405, 0.76])

    def draw(ax: plt.Axes, mode: str) -> None:
        for lab, color, marker, size in [(0, C_HARD, "o", 54), (1, C_DEFECT, "^", 62)]:
            sub = keep[labels[keep] == lab]
            if sub.size == 0:
                continue
            if mode == "baseline":
                sub_pos = np.isin(keep, sub)
                ax.scatter(text_coord[sub], y_jitter[sub_pos], s=size, color=color, alpha=0.58, edgecolors="white", linewidths=0.45, marker=marker)
            else:
                ax.scatter(text_coord[sub], residual_coord[sub], s=size, color=color, alpha=0.58, edgecolors="white", linewidths=0.45, marker=marker)
        for key, color, marker in [("defect", C_DEFECT, "^"), ("hard_normal", C_HARD, "o")]:
            rid = selected_ids[key]
            y = 0.0 if mode == "baseline" else residual_coord[rid]
            ax.scatter([text_coord[rid]], [y], s=170, color=color, marker=marker, edgecolor="black", linewidth=1.6, zorder=20)
        if mode == "baseline":
            ax.plot(
                [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
                [0.0, 0.0],
                color=C_DARK,
                linewidth=2.4,
                alpha=0.75,
                zorder=18,
            )
            ax.set_ylim(-0.11, 0.11)
        else:
            ax.plot(
                [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
                [residual_coord[selected_ids["defect"]], residual_coord[selected_ids["hard_normal"]]],
                color=C_DARK,
                linewidth=2.5,
                alpha=0.78,
                zorder=18,
            )
            r_vals = residual_coord[keep]
            rpad = 0.10 * max(float(r_vals.max() - r_vals.min()), 1e-6)
            ax.set_ylim(float(r_vals.min() - rpad), float(r_vals.max() + rpad))
        x_vals = text_coord[keep]
        xpad = 0.08 * max(float(x_vals.max() - x_vals.min()), 1e-6)
        ax.set_xlim(float(x_vals.min() - xpad), float(x_vals.max() + xpad))
        ax.axhline(0.0, color=C_DARK, linewidth=1.1, alpha=0.24)
        ax.set_xlabel("")
        style_axis(ax, labelsize=12, ticksize=9)

    draw(ax0, "baseline")
    draw(ax1, "ours")
    ax0.set_ylabel("")
    ax1.set_ylabel("")
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_pcb_scatter_compact.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_pcb_scatter_compact.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_trace_pair_compact(meta: dict) -> None:
    selected = meta["selected"]
    defect_full = ROOT / selected["defect"]["full_box_path"]
    defect_crop = ROOT / selected["defect"]["crop_path"]
    hard_full = ROOT / selected["hard_normal"]["full_box_path"]
    hard_crop = ROOT / selected["hard_normal"]["crop_path"]

    fig = plt.figure(figsize=(3.45, 2.25), constrained_layout=False)
    fig.text(0.02, 0.70, "defect", color=C_DEFECT, fontsize=12.0, fontweight="bold", ha="left", va="center")
    fig.text(0.02, 0.28, "FP", color=C_HARD, fontsize=12.0, fontweight="bold", ha="left", va="center")
    add_image_axis(fig, [0.27, 0.54, 0.28, 0.36], defect_full, C_DEFECT)
    add_image_axis(fig, [0.62, 0.54, 0.28, 0.36], defect_crop, C_DEFECT)
    add_image_axis(fig, [0.27, 0.12, 0.28, 0.36], hard_full, C_HARD)
    add_image_axis(fig, [0.62, 0.12, 0.28, 0.36], hard_crop, C_HARD)
    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_pcb_traced_patch_pair_compact.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_pcb_traced_patch_pair_compact.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_single_compact(data: np.lib.npyio.NpzFile, meta: dict) -> None:
    labels = data["labels"].astype(np.int64)
    baseline = data["baseline"].astype(np.float32)
    rankr = oriented_rankr_residual(data)
    band = baseline_overlap_band_mask(labels, baseline)
    pos = (labels == 1) & band
    neg = (labels == 0) & band
    selected_ids = {
        "defect": int(meta["selected"]["defect"]["record_id"]),
        "hard_normal": int(meta["selected"]["hard_normal"]["record_id"]),
    }

    text_coord = data["xy"][:, 0].astype(np.float32)
    residual_coord = oriented_rankr_residual(data)
    rng = np.random.default_rng(0)
    idx_all = np.where(band)[0]
    keep = []
    for lab in (0, 1):
        idx = idx_all[labels[idx_all] == lab]
        if idx.size:
            keep.append(rng.choice(idx, size=min(145, idx.size), replace=False))
    keep = np.concatenate(keep) if keep else idx_all
    keep = np.unique(np.concatenate([keep, np.asarray([selected_ids["defect"], selected_ids["hard_normal"]], dtype=np.int64)]))
    y_jitter = rng.normal(0.0, 0.025, size=keep.shape[0]).astype(np.float32)

    selected = meta["selected"]
    defect_full = ROOT / selected["defect"]["full_box_path"]
    defect_crop = ROOT / selected["defect"]["crop_path"]
    hard_full = ROOT / selected["hard_normal"]["full_box_path"]
    hard_crop = ROOT / selected["hard_normal"]["crop_path"]

    fig = plt.figure(figsize=(15.8, 2.35), constrained_layout=False)

    # (a) score distributions: two compact histogram panels.
    axh0 = fig.add_axes([0.045, 0.23, 0.190, 0.70])
    axh1 = fig.add_axes([0.252, 0.23, 0.185, 0.70])
    draw_hist_panel(
        axh0,
        baseline[pos],
        baseline[neg],
        {"defect": baseline[selected_ids["defect"]], "hard_normal": baseline[selected_ids["hard_normal"]]},
        "",
    )
    draw_hist_panel(
        axh1,
        rankr[pos],
        rankr[neg],
        {"defect": rankr[selected_ids["defect"]], "hard_normal": rankr[selected_ids["hard_normal"]]},
        "",
    )
    axh0.set_xlabel("")
    axh1.set_xlabel("")
    axh1.set_ylabel("")
    axh0.yaxis.label.set_size(16)
    for ax in (axh0, axh1):
        ax.tick_params(axis="both", labelsize=11, width=1.2, length=4)
        for txt in ax.texts:
            txt.set_fontsize(11)
    for txt in list(axh1.texts):
        txt.remove()
    axh1.text(
        0.97,
        0.92,
        f"Overlap {hist_curve(rankr[pos], rankr[neg])[3]['overlap']:.3f}",
        transform=axh1.transAxes,
        ha="right",
        va="top",
        fontsize=11,
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "#d8d8d8", "alpha": 0.92, "pad": 2.2},
    )
    axh1.plot([0.06, 0.12], [0.91, 0.91], transform=axh1.transAxes, color=C_DEFECT, lw=2.2, ls="--", clip_on=False)
    axh1.text(0.135, 0.91, "D", transform=axh1.transAxes, fontsize=9.5, fontweight="bold", ha="left", va="center")
    axh1.plot([0.06, 0.12], [0.81, 0.81], transform=axh1.transAxes, color=C_HARD, lw=2.2, clip_on=False)
    axh1.text(0.135, 0.81, "H-FP", transform=axh1.transAxes, fontsize=9.5, fontweight="bold", ha="left", va="center")
    fig.text(0.240, 0.055, "(a) Score distributions", ha="center", va="center", fontsize=12, fontweight="bold")

    # (b) evidence-space separation: two compact scatter panels.
    axs0 = fig.add_axes([0.485, 0.23, 0.145, 0.70])
    axs1 = fig.add_axes([0.645, 0.23, 0.145, 0.70])

    def draw_scatter(ax: plt.Axes, mode: str) -> None:
        for lab, color, marker, size in [(0, C_HARD, "o", 34), (1, C_DEFECT, "^", 40)]:
            sub = keep[labels[keep] == lab]
            if sub.size == 0:
                continue
            if mode == "baseline":
                sub_pos = np.isin(keep, sub)
                ax.scatter(text_coord[sub], y_jitter[sub_pos], s=size, color=color, alpha=0.55, edgecolors="white", linewidths=0.35, marker=marker)
            else:
                ax.scatter(text_coord[sub], residual_coord[sub], s=size, color=color, alpha=0.55, edgecolors="white", linewidths=0.35, marker=marker)
        for key, color, marker in [("defect", C_DEFECT, "^"), ("hard_normal", C_HARD, "o")]:
            rid = selected_ids[key]
            y = 0.0 if mode == "baseline" else residual_coord[rid]
            ax.scatter([text_coord[rid]], [y], s=105, color=color, marker=marker, edgecolor="black", linewidth=1.2, zorder=20)
        if mode == "baseline":
            ax.plot(
                [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
                [0.0, 0.0],
                color=C_DARK,
                linewidth=1.8,
                alpha=0.75,
                zorder=18,
            )
            ax.set_ylim(-0.11, 0.11)
        else:
            ax.plot(
                [text_coord[selected_ids["defect"]], text_coord[selected_ids["hard_normal"]]],
                [residual_coord[selected_ids["defect"]], residual_coord[selected_ids["hard_normal"]]],
                color=C_DARK,
                linewidth=1.9,
                alpha=0.78,
                zorder=18,
            )
            r_vals = residual_coord[keep]
            rpad = 0.10 * max(float(r_vals.max() - r_vals.min()), 1e-6)
            ax.set_ylim(float(r_vals.min() - rpad), float(r_vals.max() + rpad))
        x_vals = text_coord[keep]
        xpad = 0.08 * max(float(x_vals.max() - x_vals.min()), 1e-6)
        ax.set_xlim(float(x_vals.min() - xpad), float(x_vals.max() + xpad))
        ax.axhline(0.0, color=C_DARK, linewidth=0.9, alpha=0.24)
        ax.set_xlabel("")
        ax.set_ylabel("")
        style_axis(ax, labelsize=9, ticksize=8)

    draw_scatter(axs0, "baseline")
    draw_scatter(axs1, "ours")
    fig.text(0.637, 0.055, "(b) Evidence-space separation", ha="center", va="center", fontsize=12, fontweight="bold")

    # (c) traced patches.
    fig.text(0.815, 0.66, "defect", color=C_DEFECT, fontsize=9.5, fontweight="bold", ha="left", va="center")
    fig.text(0.815, 0.34, "FP", color=C_HARD, fontsize=9.5, fontweight="bold", ha="left", va="center")
    add_image_axis(fig, [0.875, 0.56, 0.045, 0.29], defect_full, C_DEFECT)
    add_image_axis(fig, [0.935, 0.56, 0.045, 0.29], defect_crop, C_DEFECT)
    add_image_axis(fig, [0.875, 0.22, 0.045, 0.29], hard_full, C_HARD)
    add_image_axis(fig, [0.935, 0.22, 0.045, 0.29], hard_crop, C_HARD)
    fig.text(0.903, 0.055, "(c) Traced patches", ha="center", va="center", fontsize=12, fontweight="bold")

    for out in (FIG, SRC):
        fig.savefig(out / "results_mainfig_compact_single.pdf", pad_inches=0.0)
        fig.savefig(out / "results_mainfig_compact_single.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def main() -> int:
    setup_rc()
    FIG.mkdir(parents=True, exist_ok=True)
    data = np.load(SRC / "scores_with_trace_vitl336.npz", allow_pickle=True)
    meta = json.loads((SRC / "selected_pair.json").read_text(encoding="utf-8"))
    save_histogram(data, meta)
    save_scatter(data, meta)
    save_trace_pair(meta)
    save_histogram_compact(data, meta)
    save_scatter_compact(data, meta)
    save_trace_pair_compact(meta)
    save_single_compact(data, meta)
    print(FIG / "results_mainfig_pcb_histogram_bigfont.pdf")
    print(FIG / "results_mainfig_pcb_scatter_bigfont.pdf")
    print(FIG / "results_mainfig_pcb_traced_patch_pair_bigfont.pdf")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
