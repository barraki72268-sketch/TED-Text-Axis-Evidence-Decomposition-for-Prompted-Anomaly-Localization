#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
LOGS = ROOT / "neurips2026" / "logs" / "appendix_defense_20260504"

sys.path.insert(0, str(ROOT / "neurips2026" / "scripts"))

from queue_efficiency_bank_budget_20260504 import build_aaclip as build_eff_aaclip  # noqa: E402
from queue_extra_training_control_adapt_anomaly_20260504 import (  # noqa: E402
    build_adaptclip_cmd as build_tc_adaptclip,
)
from queue_fullfeature_control_extra_hosts_20260504 import (  # noqa: E402
    aaclip_cmd as build_fullfeat_aaclip,
    adaptclip_cmd as build_fullfeat_adaptclip,
)
from queue_training_control_20260504 import (  # noqa: E402
    build_adaclip_cmd as build_tc_adaclip,
    build_faprompt_cmd as build_tc_faprompt,
)


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def add_job(
    jobs: list[dict],
    *,
    kind: str,
    host: str,
    preset: str,
    variant: str,
    cmd: list[str],
    save_dir: Path,
    log_path: Path,
) -> None:
    jobs.append(
        {
            "kind": kind,
            "host": host,
            "preset": preset,
            "variant": variant,
            "cmd": cmd,
            "save_dir": str(save_dir),
            "log_path": str(log_path),
        }
    )


def build_jobs(device: str, seed: int, tasks: set[str]) -> list[dict]:
    jobs: list[dict] = []

    if "training" in tasks:
        # Extra source-supervision controls beyond the compact main-paper table.
        for preset in ("mvtec2visa", "mvtec2mpdd", "visa2mvtec", "visa2mpdd"):
            for variant in ("correct", "label_swap"):
                cmd, save_dir = build_tc_adaptclip(preset, variant, device, seed)
                add_job(
                    jobs,
                    kind="training_control",
                    host="adaptclip",
                    preset=preset,
                    variant=variant,
                    cmd=cmd,
                    save_dir=save_dir,
                    log_path=LOGS / f"{save_dir.name}.log",
                )

        for preset in ("mvtec2visa", "mvtec2mpdd"):
            for variant in ("correct", "label_swap"):
                cmd, save_dir = build_tc_faprompt(variant, preset, device, seed)
                add_job(
                    jobs,
                    kind="training_control",
                    host="faprompt",
                    preset=preset,
                    variant=variant,
                    cmd=cmd,
                    save_dir=save_dir,
                    log_path=LOGS / f"{save_dir.name}.log",
                )

        for preset in ("visa2mvtec",):
            for variant in ("correct", "label_swap", "random_subspace"):
                cmd, save_dir = build_tc_adaclip(variant, preset, device, seed)
                add_job(
                    jobs,
                    kind="training_control",
                    host="adaclip",
                    preset=preset,
                    variant=variant,
                    cmd=cmd,
                    save_dir=save_dir,
                    log_path=LOGS / f"{save_dir.name}.log",
                )

    if "fullfeature" in tasks:
        # Negative control: direct visual-memory replacement without text-conditioned readout.
        for preset in ("mvtec2mpdd", "mvtec2btad", "visa2mpdd", "visa2mvtec"):
            cmd, save_dir = build_fullfeat_aaclip(preset, device, seed)
            add_job(
                jobs,
                kind="fullfeature_memory",
                host="aaclip",
                preset=preset,
                variant="fullfeat",
                cmd=cmd,
                save_dir=save_dir,
                log_path=LOGS / f"{save_dir.name}.log",
            )

        for preset in ("mvtec2mpdd", "mvtec2btad", "visa2mpdd", "visa2mvtec"):
            cmd, save_dir = build_fullfeat_adaptclip(preset, device, seed)
            add_job(
                jobs,
                kind="fullfeature_memory",
                host="adaptclip",
                preset=preset,
                variant="fullfeat",
                cmd=cmd,
                save_dir=save_dir,
                log_path=LOGS / f"{save_dir.name}.log",
            )

    if "efficiency" in tasks:
        # Complements the FAPrompt budget sweep with AA-CLIP on VisA-source transfers.
        for preset in ("visa2mvtec", "visa2mpdd", "visa2btad"):
            for budget in (64, 128, 512):
                cmd, save_dir, log_path = build_eff_aaclip(preset, budget, device, seed)
                add_job(
                    jobs,
                    kind="efficiency_bank_budget",
                    host="aaclip",
                    preset=preset,
                    variant=f"bank{budget}",
                    cmd=cmd,
                    save_dir=save_dir,
                    log_path=LOGS / log_path.name,
                )

    return jobs


def write_worker(jobs: list[dict], force: bool) -> Path:
    LOGS.mkdir(parents=True, exist_ok=True)
    worker_path = LOGS / "appendix_defense_worker_gpu1.py"
    payload = {"root": str(ROOT), "jobs": jobs, "force": bool(force)}
    worker_path.write_text(
        "from __future__ import annotations\n"
        "import json, subprocess, time\n"
        "from pathlib import Path\n\n"
        f"PAYLOAD = json.loads({json.dumps(json.dumps(payload))})\n\n"
        "root = Path(PAYLOAD['root'])\n"
        "for job in PAYLOAD['jobs']:\n"
        "    save_dir = Path(job['save_dir'])\n"
        "    summary = save_dir / 'summary.json'\n"
        "    if summary.exists() and not PAYLOAD['force']:\n"
        "        print(json.dumps({'stage': 'skip_done', **{k: job[k] for k in ['kind','host','preset','variant']}, 'summary': str(summary)}), flush=True)\n"
        "        continue\n"
        "    save_dir.mkdir(parents=True, exist_ok=True)\n"
        "    log_path = Path(job['log_path'])\n"
        "    log_path.parent.mkdir(parents=True, exist_ok=True)\n"
        "    print(json.dumps({'stage': 'job_start', **{k: job[k] for k in ['kind','host','preset','variant']}, 'save_dir': str(save_dir), 'log': str(log_path)}), flush=True)\n"
        "    start = time.time()\n"
        "    with log_path.open('ab', buffering=0) as log_f:\n"
        "        proc = subprocess.run(job['cmd'], cwd=root, stdout=log_f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)\n"
        "    print(json.dumps({'stage': 'job_done', **{k: job[k] for k in ['kind','host','preset','variant']}, 'returncode': proc.returncode, 'elapsed_sec': time.time() - start, 'save_dir': str(save_dir)}), flush=True)\n"
    )
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tasks", default="training,fullfeature,efficiency")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    tasks = set(parse_csv(args.tasks))
    allowed = {"training", "fullfeature", "efficiency"}
    unknown = tasks - allowed
    if unknown:
        raise SystemExit(f"Unknown tasks={sorted(unknown)}; allowed={sorted(allowed)}")

    jobs = build_jobs(args.device, args.seed, tasks)
    worker_path = write_worker(jobs, args.force)
    worker_log = LOGS / "appendix_defense_worker_gpu1.log"
    log_f = worker_log.open("ab", buffering=0)
    proc = subprocess.Popen(
        [str(PY), "-u", str(worker_path)],
        cwd=ROOT,
        stdout=log_f,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    print(
        json.dumps(
            {
                "stage": "appendix_defense_serial_queue",
                "pid": proc.pid,
                "device": args.device,
                "num_jobs": len(jobs),
                "worker": str(worker_path),
                "log": str(worker_log),
                "tasks": sorted(tasks),
            },
            indent=2,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
