from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from probe_anomalyclip_region_bank_descriptor import (  # noqa: E402
    build_model,
    compute_map,
    extract_region_descriptor,
    iterate_components,
    load_text_features,
)
from utils import get_transform  # noqa: E402


def load_rows(path: Path) -> list[dict]:
    with open(path, "r", newline="") as f:
        return list(csv.DictReader(f))


def build_dataset(root: str, image_size: int):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode="test")


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def fit_classifier(fp_rows: list[dict], defect_rows: list[dict], features: list[str]):
    def rows_to_x(rows: list[dict]) -> np.ndarray:
        return np.asarray([[float(row[f]) for f in features] for row in rows], dtype=np.float32)

    X = np.concatenate([rows_to_x(fp_rows), rows_to_x(defect_rows)], axis=0)
    y = np.concatenate(
        [np.zeros(len(fp_rows), dtype=np.int64), np.ones(len(defect_rows), dtype=np.int64)],
        axis=0,
    )
    clf = Pipeline(
        [
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
        ]
    )
    clf.fit(X, y)
    auc = float(roc_auc_score(y, clf.predict_proba(X)[:, 1]))
    return clf, auc


def save_results(rows: list[dict], per_class_rows: list[dict], summary: dict, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows, "per_class_rows": per_class_rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    if per_class_rows:
        with open(save_dir / "per_class_metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(per_class_rows[0].keys()))
            writer.writeheader()
            writer.writerows(per_class_rows)


def main():
    parser = argparse.ArgumentParser("Probe AnomalyCLIP holdout region discriminant scoring on MVTec")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--fp_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_bank_holdout_epoch5" / "fp_rows.csv"),
    )
    parser.add_argument(
        "--defect_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_bank_holdout_epoch5" / "defect_rows.csv"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_discriminant_holdout_epoch5"),
    )
    parser.add_argument(
        "--descriptor_combo",
        type=str,
        default="peak,mean,area,fill_ratio,compactness,ring_contrast",
    )
    parser.add_argument("--candidate_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.5, 1.0])
    parser.add_argument("--modes", type=str, nargs="+", default=["gate", "dual"])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    parser.add_argument("--skip_pixel_aupro", action="store_true")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    descriptor_features = [x.strip() for x in args.descriptor_combo.split(",") if x.strip()]
    fp_rows_all = load_rows(Path(args.fp_csv))
    defect_rows_all = load_rows(Path(args.defect_csv))
    classes = sorted(set(row["cls_name"] for row in fp_rows_all) & set(row["cls_name"] for row in defect_rows_all))

    print(
        json.dumps(
            {
                "stage": "holdout_region_discriminant_start",
                "descriptor_features": descriptor_features,
                "num_fp_rows": len(fp_rows_all),
                "num_defect_rows": len(defect_rows_all),
                "classes": classes,
                "modes": args.modes,
                "alphas": args.alphas,
            },
            indent=2,
        ),
        flush=True,
    )

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    text_features = load_text_features(model, params, Path(args.checkpoint_path), args.device)
    dataset = build_dataset(args.source_root, args.image_size)

    metric_keys = [
        "image_auroc",
        "pixel_auroc",
        "pixel_aupro",
        "inside_outside_gap",
        "outside_inside_ratio",
        "normal_topk_mean",
        "normal_map_mean",
        "avg_num_components",
        "avg_mean_defect_prob",
    ]
    aggregate: dict[tuple[str, float], list[dict]] = {}
    per_class_rows: list[dict] = []

    for heldout in classes:
        fp_rows = [row for row in fp_rows_all if row["cls_name"] != heldout]
        defect_rows = [row for row in defect_rows_all if row["cls_name"] != heldout]
        clf, train_auc = fit_classifier(fp_rows, defect_rows, descriptor_features)

        result_modes = {
            ("baseline", 0.0): {heldout: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}}
        }
        stat_modes = {
            ("baseline", 0.0): {
                "normal_topk": [],
                "normal_mean": [],
                "inside_outside_gap": [],
                "outside_inside_ratio": [],
                "num_components": [],
                "mean_defect_prob": [],
            }
        }
        for mode in args.modes:
            for alpha in args.alphas:
                result_modes[(mode, float(alpha))] = {heldout: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}}
                stat_modes[(mode, float(alpha))] = {
                    "normal_topk": [],
                    "normal_mean": [],
                    "inside_outside_gap": [],
                    "outside_inside_ratio": [],
                    "num_components": [],
                    "mean_defect_prob": [],
                }

        with torch.no_grad():
            for idx in range(len(dataset)):
                item = dataset[idx]
                if item["cls_name"] != heldout:
                    continue
                anomaly_flag = item["anomaly"]
                if hasattr(anomaly_flag, "item"):
                    anomaly_flag = anomaly_flag.item()
                anomaly_flag = int(anomaly_flag)

                image = item["img"].unsqueeze(0).to(args.device)
                gt_mask = item["img_mask"].unsqueeze(0).clone()
                gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
                gt_mask_np = gt_mask[0, 0].numpy().astype(bool)

                anomaly_map = compute_map(model, text_features, image, args.features_list, args.image_size, args.sigma)

                defect_prob_map = np.zeros_like(anomaly_map, dtype=np.float32)
                covered = np.zeros_like(anomaly_map, dtype=bool)
                num_components = 0
                comp_probs = []
                for frac in args.candidate_fracs:
                    mask = top_fraction_mask(anomaly_map, frac)
                    for comp in iterate_components(mask):
                        if int(comp.sum()) < args.min_area:
                            continue
                        desc = extract_region_descriptor(anomaly_map, comp)
                        if not desc:
                            continue
                        X = np.asarray([[float(desc[f]) for f in descriptor_features]], dtype=np.float32)
                        prob = float(clf.predict_proba(X)[0, 1])
                        defect_prob_map[comp] = np.maximum(defect_prob_map[comp], prob)
                        covered |= comp
                        comp_probs.append(prob)
                        num_components += 1

                mean_def_prob = float(np.mean(comp_probs)) if comp_probs else 0.5

                # baseline
                final_maps = {("baseline", 0.0): anomaly_map.copy()}
                for mode in args.modes:
                    for alpha in args.alphas:
                        final_map = anomaly_map.copy()
                        if covered.any():
                            if mode == "gate":
                                factor = ((1.0 - alpha) + alpha * defect_prob_map)[covered]
                                final_map[covered] = anomaly_map[covered] * factor
                            elif mode == "dual":
                                factor = (defect_prob_map - alpha * (1.0 - defect_prob_map))[covered]
                                final_map[covered] = anomaly_map[covered] * factor
                            else:
                                raise ValueError(f"Unknown mode: {mode}")
                        final_maps[(mode, float(alpha))] = final_map

                for key, final_map in final_maps.items():
                    result_modes[key][heldout]["gt_sp"].append(anomaly_flag)
                    result_modes[key][heldout]["pr_sp"].append(topk_mean(final_map, args.image_score_topk))
                    result_modes[key][heldout]["imgs_masks"].append(gt_mask)
                    result_modes[key][heldout]["anomaly_maps"].append(final_map[None, ...])

                    stat_modes[key]["num_components"].append(num_components)
                    stat_modes[key]["mean_defect_prob"].append(mean_def_prob)
                    if anomaly_flag == 0:
                        stat_modes[key]["normal_topk"].append(topk_mean(final_map, args.normal_topk_ratio))
                        stat_modes[key]["normal_mean"].append(float(final_map.mean()))
                    else:
                        if gt_mask_np.any() and (~gt_mask_np).any():
                            inside = float(final_map[gt_mask_np].mean())
                            outside = float(final_map[~gt_mask_np].mean())
                            stat_modes[key]["inside_outside_gap"].append(inside - outside)
                            stat_modes[key]["outside_inside_ratio"].append(outside / (inside + 1e-6))

        for key, results in result_modes.items():
            results[heldout]["imgs_masks"] = torch.cat(results[heldout]["imgs_masks"]).numpy()
            results[heldout]["anomaly_maps"] = np.concatenate(results[heldout]["anomaly_maps"], axis=0)
            image_auroc = image_level_metrics(results, heldout, "image-auroc")
            pixel_auroc = pixel_level_metrics(results, heldout, "pixel-auroc")
            pixel_aupro = float("nan") if args.skip_pixel_aupro else pixel_level_metrics(results, heldout, "pixel-aupro")
            mode, alpha = key
            row = {
                "heldout_class": heldout,
                "mode": mode,
                "alpha": float(alpha),
                "source_train_auc": float(train_auc),
                "image_auroc": float(image_auroc),
                "pixel_auroc": float(pixel_auroc),
                "pixel_aupro": float(pixel_aupro),
                "inside_outside_gap": float(np.mean(stat_modes[key]["inside_outside_gap"]))
                if stat_modes[key]["inside_outside_gap"]
                else float("nan"),
                "outside_inside_ratio": float(np.mean(stat_modes[key]["outside_inside_ratio"]))
                if stat_modes[key]["outside_inside_ratio"]
                else float("nan"),
                "normal_topk_mean": float(np.mean(stat_modes[key]["normal_topk"]))
                if stat_modes[key]["normal_topk"]
                else float("nan"),
                "normal_map_mean": float(np.mean(stat_modes[key]["normal_mean"]))
                if stat_modes[key]["normal_mean"]
                else float("nan"),
                "avg_num_components": float(np.mean(stat_modes[key]["num_components"]))
                if stat_modes[key]["num_components"]
                else float("nan"),
                "avg_mean_defect_prob": float(np.mean(stat_modes[key]["mean_defect_prob"]))
                if stat_modes[key]["mean_defect_prob"]
                else float("nan"),
            }
            per_class_rows.append(row)
            aggregate.setdefault((mode, float(alpha)), []).append(row)

        print(
            json.dumps(
                {
                    "stage": "holdout_region_discriminant_progress",
                    "heldout_class": heldout,
                    "source_train_auc": train_auc,
                }
            ),
            flush=True,
        )

    rows = []
    for (mode, alpha), vals in aggregate.items():
        row = {"mode": mode, "alpha": float(alpha)}
        for key in metric_keys:
            metric_vals = [float(v[key]) for v in vals if not np.isnan(float(v[key]))]
            row[key] = float(np.mean(metric_vals)) if metric_vals else float("nan")
        rows.append(row)

    rows.sort(key=lambda x: (x["mode"], x["alpha"]))
    summary = {
        "descriptor_features": descriptor_features,
        "num_fp_rows": len(fp_rows_all),
        "num_defect_rows": len(defect_rows_all),
        "num_holdouts": len(classes),
    }
    save_results(rows, per_class_rows, summary, Path(args.save_dir))
    print(
        json.dumps(
            {
                "stage": "holdout_region_discriminant_saved",
                "save_dir": args.save_dir,
                "rows": rows,
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
