#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
EVAL = ROOT / "neurips2026/scripts/official_parallel_test_aaclip.py"
RESULTS = ROOT / "neurips2026/results"
OUT = RESULTS / "aaclip_vitl_openai_ablation_20260503"
LOG = OUT / "logs"


VARIANTS = {
    "rank2": "Use rank-2 residual subspace.",
    "rank4": "Use rank-4 residual subspace.",
    "rank8": "Use rank-8 residual subspace.",
    "no_hardfp": "Disable hard-FP support by fixing fp weight near zero.",
    "no_preserve": "Remove host-margin preservation.",
}


def parse_csv(raw: str) -> list[str]:
    vals = [x.strip() for x in raw.split(",") if x.strip()]
    bad = [x for x in vals if x not in VARIANTS]
    if bad:
        raise SystemExit(f"Unknown variants={bad}; allowed={sorted(VARIANTS)}")
    return vals


def build_cmd(variant: str, seed: int, device: str) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"ablation_ted_aaclip_vitl_openai224_mvtec2btad_{variant}_seed{seed}_20260503"
    cmd = [
        str(PY),
        "-u",
        str(EVAL),
        "--preset",
        "mvtec2btad",
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    if variant == "rank2":
        cmd[cmd.index("--prescore_calib_subspace_rank") + 1] = "2"
    elif variant == "rank4":
        cmd[cmd.index("--prescore_calib_subspace_rank") + 1] = "4"
    elif variant == "rank8":
        cmd[cmd.index("--prescore_calib_subspace_rank") + 1] = "8"
    elif variant == "no_hardfp":
        cmd.remove("--prescore_calib_learn_fp_weight")
        cmd.extend(["--prescore_calib_fp_weight_init", "0.0001"])
    elif variant == "no_preserve":
        cmd[cmd.index("--prescore_calib_preserve_host_margin_weight") + 1] = "0.0"
    return cmd, save_dir


def run_variant(variant: str, seed: int, device: str, force: bool, env: dict[str, str]) -> None:
    cmd, save_dir = build_cmd(variant, seed, device)
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        print({"stage": "skip", "variant": variant, "seed": seed, "summary": str(summary)}, flush=True)
        return
    log_path = LOG / f"{variant}_seed{seed}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "variant": variant, "seed": seed, "log": str(log_path)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "variant": variant, "seed": seed, "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"failed variant={variant} seed={seed}; see {log_path}")


def detach(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    detached_log = OUT / "queue.detached.log"
    cmd = [
        str(PY),
        "-u",
        str(Path(__file__).resolve()),
        "--variants",
        args.variants,
        "--seeds",
        args.seeds,
        "--device_id",
        args.device_id,
    ]
    if args.force:
        cmd.append("--force")
    with detached_log.open("a") as f:
        proc = subprocess.Popen(cmd, cwd=str(ROOT), stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    (OUT / "queue.pid").write_text(str(proc.pid))
    print({"stage": "detached", "pid": proc.pid, "log": str(detached_log), "root": str(OUT)})
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--variants", default="rank2,rank4,rank8,no_hardfp")
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--device_id", default="1")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--detach", action="store_true")
    args = ap.parse_args()

    if args.detach:
        return detach(args)

    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    variants = parse_csv(args.variants)
    seeds = [int(x.strip()) for x in args.seeds.split(",") if x.strip()]
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.device_id)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-aaclip-vitl-openai-ablation-20260503")
    for seed in seeds:
        for variant in variants:
            run_variant(variant, seed, "cuda:0", args.force, env)
    print({"stage": "done", "variants": variants, "seeds": seeds, "root": str(OUT)}, flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
