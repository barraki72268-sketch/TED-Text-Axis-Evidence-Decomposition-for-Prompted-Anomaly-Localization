from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANOMALYCLIP_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANOMALYCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ANOMALYCLIP_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner, encode_text_prompt_bank  # noqa: E402


def load_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    return model, params


def load_prompt_learner(model, params, checkpoint_path: Path, device: str):
    learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    learner.load_state_dict(checkpoint["prompt_learner"])
    learner.to(device)
    learner.eval()
    model.to(device)
    return learner


@torch.no_grad()
def get_learned_text_features(model, learner):
    prompts, tokenized_prompts, compound_prompts_text = learner(cls_id=None)
    prompts = prompts.to(next(model.parameters()).device)
    tokenized_prompts = tokenized_prompts.to(next(model.parameters()).device)
    compound_prompts_text = [prompt.to(next(model.parameters()).device) for prompt in compound_prompts_text]
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = F.normalize(text_features, dim=-1)
    return text_features[0]


def normal_basis(text_bank: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    text_bank = F.normalize(text_bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(text_bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return text_bank.new_zeros((text_bank.shape[-1], 0))
    return vh[:rank].transpose(0, 1).contiguous()


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = vec @ basis
    return float(coeff.pow(2).sum().item())


def cosine(a: torch.Tensor, b: torch.Tensor) -> float:
    a = F.normalize(a.float(), dim=-1)
    b = F.normalize(b.float(), dim=-1)
    return float((a * b).sum().item())


def collect_series(ckpt_dir: Path, label: str, model, params, device: str, norm_anchor: torch.Tensor, anom_anchor: torch.Tensor, norm_basis: torch.Tensor):
    rows = []
    for ckpt_path in sorted(ckpt_dir.glob("epoch_*.pth"), key=lambda p: int(p.stem.split("_")[-1])):
        epoch = int(ckpt_path.stem.split("_")[-1])
        learner = load_prompt_learner(model, params, ckpt_path, device)
        learned = get_learned_text_features(model, learner)
        e_norm = learned[0]
        e_anom = learned[1]
        rows.append({
            "series": label,
            "epoch": epoch,
            "overlap_cos": cosine(e_anom, e_norm),
            "proj_energy_to_normal": projection_energy(e_anom, norm_basis),
            "anchor_retention_norm": cosine(e_norm, norm_anchor),
            "anchor_retention_anom": cosine(e_anom, anom_anchor),
        })
        del learner
        if device.startswith("cuda"):
            torch.cuda.empty_cache()
    return rows


def save_plot(rows, save_path: Path):
    series_names = sorted({row["series"] for row in rows})
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    metric_names = [
        ("overlap_cos", "Normal-Anomaly Cosine"),
        ("proj_energy_to_normal", "Projection Energy to Normal Subspace"),
        ("anchor_retention_anom", "Anomaly Anchor Retention"),
        ("anchor_retention_norm", "Normal Anchor Retention"),
    ]
    axes = axes.flatten()
    colors = {"baseline": "#d04f4f", "ours": "#2a7fff"}
    for ax, (key, title) in zip(axes, metric_names):
        for series in series_names:
            subset = sorted([row for row in rows if row["series"] == series], key=lambda x: x["epoch"])
            if not subset:
                continue
            ax.plot(
                [row["epoch"] for row in subset],
                [row[key] for row in subset],
                marker="o",
                label=series,
                color=colors.get(series, None),
            )
        ax.set_title(title)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(key)
        ax.grid(True, alpha=0.25)
    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", ncol=len(labels))
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(save_path, dpi=180)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser("Collect AnomalyCLIP text-space collapse metrics")
    parser.add_argument("--baseline_ckpt_dir", type=str, default=str(ANOMALYCLIP_ROOT / "checkpoints" / "9_12_4_multiscale_visa"))
    parser.add_argument("--ours_ckpt_dir", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_textreg_mvtec2visa" / "checkpoints"))
    parser.add_argument("--save_dir", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_text_collapse"))
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--object_name", type=str, default="object")
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    model, params = load_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)

    reference_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=None)
    reference_model.eval()
    normal_bank, anomaly_bank = encode_text_prompt_bank(reference_model, args.object_name, "cpu")
    normal_bank = F.normalize(normal_bank.float(), dim=-1)
    anomaly_bank = F.normalize(anomaly_bank.float(), dim=-1)
    norm_anchor = F.normalize(normal_bank.mean(dim=0), dim=-1).to(args.device)
    anom_anchor = F.normalize(anomaly_bank.mean(dim=0), dim=-1).to(args.device)
    norm_basis = normal_basis(normal_bank).to(args.device)
    del reference_model

    rows = []
    rows.extend(collect_series(Path(args.baseline_ckpt_dir), "baseline", model, params, args.device, norm_anchor, anom_anchor, norm_basis))
    rows.extend(collect_series(Path(args.ours_ckpt_dir), "ours", model, params, args.device, norm_anchor, anom_anchor, norm_basis))

    rows = sorted(rows, key=lambda x: (x["series"], x["epoch"]))

    with open(save_dir / "collapse_metrics.json", "w") as f:
        json.dump(rows, f, indent=2)

    with open(save_dir / "collapse_metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["series", "epoch", "overlap_cos", "proj_energy_to_normal", "anchor_retention_norm", "anchor_retention_anom"])
        writer.writeheader()
        writer.writerows(rows)

    save_plot(rows, save_dir / "collapse_metrics.png")
    print(json.dumps({
        "num_rows": len(rows),
        "save_dir": str(save_dir),
    }, indent=2))


if __name__ == "__main__":
    main()
