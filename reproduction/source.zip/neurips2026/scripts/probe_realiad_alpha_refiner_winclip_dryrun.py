from __future__ import annotations

import argparse
import copy
import csv
import json
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD
from WinCLIP import WinClipAD
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts
from neurips2026.learned_refiner import AlphaSpaceKinematicRefiner, AlphaSpaceObjective
from neurips2026.scripts.probe_realiad_alpha_refiner_clip_dryrun import (
    _load_cached_json,
    audit_dataset,
    build_mask_transform,
    collect_records_by_label,
    cosine_decay_lr,
    dilate_mask_tensor,
    filter_trainable_anomalies,
    flatten_records,
    load_mask_tensor,
    load_rgb_tensor,
    sample_balanced_batch,
    set_seed,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--target_layer", type=int, default=6)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--hidden_dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--lambda_sem", type=float, default=1.0)
    parser.add_argument("--lambda_normal", type=float, default=0.1)
    parser.add_argument("--lambda_anomaly", type=float, default=0.1)
    parser.add_argument("--lambda_pairwise", type=float, default=1.0)
    parser.add_argument("--pairwise_margin", type=float, default=0.1)
    parser.add_argument("--sem_threshold", type=float, default=0.02)
    parser.add_argument("--sem_threshold_mode", type=str, choices=["fixed", "dynamic"], default="fixed")
    parser.add_argument("--sem_dynamic_gamma", type=float, default=1.0)
    parser.add_argument("--sem_gas_beta", type=float, default=10.0)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--steps", type=int, default=40)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--probe_normals", type=int, default=8)
    parser.add_argument("--probe_anomalies", type=int, default=8)
    parser.add_argument("--probe_sem_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_penalty", type=float, default=1.0)
    parser.add_argument("--probe_alphaa_target", type=float, default=0.35)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--audit_verify_limit", type=int, default=4000)
    parser.add_argument("--mask_audit_limit", type=int, default=4000)
    parser.add_argument("--reuse_dataset_cache", action="store_true", default=True)
    parser.add_argument("--profile_sem_only", action="store_true")
    parser.add_argument("--lr_decay_start", type=int, default=20)
    parser.add_argument("--lr_min_ratio", type=float, default=0.1)
    parser.add_argument("--eval_interval", type=int, default=10)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--output_tag", type=str, default="realiad_winclip_alpha_dryrun")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _audit_cache_path(output_dir: Path, args: argparse.Namespace) -> Path:
    backbone_tag = args.backbone.replace("-", "").replace("+", "plus").lower()
    return output_dir / (
        f"realiad_winclip_{backbone_tag}_audit_resize{args.img_cropsize}_dilate{args.mask_dilate_kernel}_"
        f"verify{args.audit_verify_limit}_mask{args.mask_audit_limit}.json"
    )


def _trainable_cache_path(output_dir: Path, args: argparse.Namespace, token_side: int) -> Path:
    backbone_tag = args.backbone.replace("-", "").replace("+", "plus").lower()
    return output_dir / (
        f"realiad_winclip_{backbone_tag}_trainable_anomalies_resize{args.img_cropsize}_dilate{args.mask_dilate_kernel}_"
        f"token{token_side}_scan{max(args.mask_audit_limit, args.batch_size * args.steps * 4)}.json"
    )


def build_winclip_prompt_token_basis(model: WinClipAD, class_name: str) -> torch.Tensor:
    prompts = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))

    text = model.tokenizer(prompts).to(model.device)
    with torch.no_grad():
        text_features = model.encode_text(text).float()
        text_features = F.normalize(text_features, dim=-1)
        q_text, _ = torch.linalg.qr(text_features.T, mode="reduced")

        proj = model.model.visual.proj.detach().float().to(text_features.device)
        token_basis = proj @ q_text
        q_token, _ = torch.linalg.qr(token_basis, mode="reduced")
    return q_token.detach().cpu()


def build_batch_tensors_winclip(
    batch: list[dict],
    model: WinClipAD,
    mask_transform,
    semantic_basis_by_class: dict[str, torch.Tensor],
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, list[int]]:
    images = torch.stack([load_rgb_tensor(rec["image_path"], model.transform) for rec in batch], dim=0).to(device)
    masks = []
    basis = []
    labels = []
    for rec in batch:
        if int(rec["label"]) == 1:
            mask = dilate_mask_tensor(load_mask_tensor(rec["mask_path"], mask_transform), args.mask_dilate_kernel)
        else:
            mask = torch.zeros(1, args.img_cropsize, args.img_cropsize)
        masks.append(mask)
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = build_winclip_prompt_token_basis(model, rec["class_name"])
        basis.append(semantic_basis_by_class[rec["class_name"]])
        labels.append(int(rec["label"]))
    return images, torch.stack(masks, dim=0).to(device), torch.stack(basis, dim=0).to(device), labels


def _prepare_visual_patches(visual, images: torch.Tensor) -> torch.Tensor:
    images = images.to(device=visual.conv1.weight.device, dtype=visual.conv1.weight.dtype)
    if visual.input_patchnorm:
        x = images.reshape(
            images.shape[0],
            images.shape[1],
            visual.grid_size[0],
            visual.patch_size[0],
            visual.grid_size[1],
            visual.patch_size[1],
        )
        x = x.permute(0, 2, 4, 1, 3, 5)
        x = x.reshape(x.shape[0], visual.grid_size[0] * visual.grid_size[1], -1)
        x = visual.patchnorm_pre_ln(x)
        x = visual.conv1(x)
    else:
        x = visual.conv1(images)
        x = x.reshape(x.shape[0], x.shape[1], -1)
        x = x.permute(0, 2, 1)
    return x + visual.positional_embedding.to(x.dtype)[1:, :]


def extract_scale_groups(
    visual,
    images: torch.Tensor,
    patch_mask_flat: torch.Tensor,
    target_layer: int,
) -> list[dict[str, torch.Tensor | int]]:
    if getattr(visual, "precision", None) == "fp16":
        images = images.half()
    with torch.no_grad():
        x = _prepare_visual_patches(visual, images)
        mask_xs = visual.window_masking(x)

        groups = []
        for scale_index in range(len(visual.scale_begin_indx)):
            begin = visual.scale_begin_indx[scale_index]
            if scale_index == len(visual.scale_begin_indx) - 1:
                end = len(mask_xs)
            else:
                end = visual.scale_begin_indx[scale_index + 1]

            scale_xs = mask_xs[begin:end]
            scale_masks = visual.masks[begin:end]
            mx = torch.stack(scale_xs, dim=0)
            n_windows, n_batches, num_tokens, dim = mx.shape
            side = int(round(num_tokens ** 0.5))
            if side * side != num_tokens:
                raise ValueError(f"Non-square window size {num_tokens} at scale index {scale_index}")

            flat = mx.reshape((-1, num_tokens, dim))
            cls_tokens = visual.class_embedding.to(x.dtype) + torch.zeros(
                flat.shape[0], 1, flat.shape[-1], dtype=x.dtype, device=x.device
            )
            cls_tokens = cls_tokens + visual.positional_embedding.to(flat.dtype)[0, :]
            flat = torch.cat((cls_tokens, flat), dim=1)
            flat = visual.patch_dropout(flat)
            flat = visual.ln_pre(flat)
            flat = flat.permute(1, 0, 2)

            for block_idx, block in enumerate(visual.transformer.resblocks, start=1):
                block_out = block(flat, attn_mask=None)
                flat = block_out[0] if isinstance(block_out, tuple) else block_out
                if block_idx == target_layer:
                    break

            patch_tokens = flat.permute(1, 0, 2)[:, 1:, :].float()
            window_masks = torch.stack(
                [patch_mask_flat[:, mask.reshape(-1)] for mask in scale_masks],
                dim=0,
            ).reshape(-1, num_tokens)

            groups.append(
                {
                    "tokens": patch_tokens,
                    "window_masks": window_masks,
                    "n_windows": n_windows,
                    "side": side,
                }
            )
    return groups


def evaluate_probe(
    *,
    model: AlphaSpaceKinematicRefiner,
    objective: AlphaSpaceObjective,
    winclip: WinClipAD,
    probe_batch: list[dict],
    semantic_basis_by_class: dict[str, torch.Tensor],
    mask_transform,
    args: argparse.Namespace,
    device: torch.device,
) -> dict[str, float]:
    images, masks_t, basis_t, _ = build_batch_tensors_winclip(
        probe_batch, winclip, mask_transform, semantic_basis_by_class, args, device
    )
    patch_mask_flat = (
        F.interpolate(masks_t.float(), size=winclip.grid_size, mode="nearest")[:, 0].reshape(len(probe_batch), -1) > 0.5
    )
    groups = extract_scale_groups(winclip.model.visual, images, patch_mask_flat, args.target_layer)

    total_weight = sum(int(group["tokens"].shape[0]) for group in groups)
    alpha_n_acc = 0.0
    alpha_a_acc = 0.0
    sem_acc = 0.0
    weight_acc = 0.0
    with torch.no_grad():
        for group in groups:
            tokens = group["tokens"]
            n_windows = int(group["n_windows"])
            basis_group = basis_t.repeat(n_windows, 1, 1)
            out = model(tokens, semantic_basis=basis_group, spatial_shape=(int(group["side"]), int(group["side"])))
            loss_stats = objective(
                raw_features=tokens,
                refined_features=out.refined,
                alpha=out.alpha,
                anomaly_mask=group["window_masks"],
                semantic_basis=basis_group,
                spatial_shape=(int(group["side"]), int(group["side"])),
            )
            w = float(tokens.shape[0]) / float(max(total_weight, 1))
            alpha_n_acc += w * float(loss_stats["alpha_normal_mean"].item())
            alpha_a_acc += w * float(loss_stats["alpha_anomaly_mean"].item())
            sem_acc += w * float(loss_stats["loss_sem"].item())
            weight_acc += w

    alpha_n = alpha_n_acc / max(weight_acc, 1e-8)
    alpha_a = alpha_a_acc / max(weight_acc, 1e-8)
    sem = sem_acc / max(weight_acc, 1e-8)
    gap = alpha_n - alpha_a
    score = gap - args.probe_sem_penalty * sem - args.probe_alphaa_penalty * max(0.0, alpha_a - args.probe_alphaa_target)
    return {
        "probe_score": float(score),
        "probe_alpha_normal_mean": float(alpha_n),
        "probe_alpha_anomaly_mean": float(alpha_a),
        "probe_alpha_gap": float(gap),
        "probe_sem_loss": float(sem),
    }


def profile_normal_sem_error(
    *,
    raw_tokens: torch.Tensor,
    refined_tokens: torch.Tensor,
    window_masks: torch.Tensor,
    basis_group: torch.Tensor,
    sem_gas_beta: float,
) -> dict[str, float]:
    raw_sem = torch.einsum("bnc,bck->bnk", raw_tokens, basis_group)
    ref_sem = torch.einsum("bnc,bck->bnk", refined_tokens, basis_group)
    sem_error = (ref_sem - raw_sem).square().mean(dim=-1)
    normal_bool = ~window_masks.bool()
    normal_vals = sem_error[normal_bool]
    if normal_vals.numel() == 0:
        zero = float(0.0)
        return {
            "normal_sem_error_mean": zero,
            "normal_sem_error_std": zero,
            "normal_sem_error_max": zero,
            "normal_sem_error_p95": zero,
            "normal_safe_weight_mean": zero,
            "normal_safe_weight_min": zero,
        }

    safe_weights = torch.exp(-sem_gas_beta * normal_vals)
    p95 = torch.quantile(normal_vals, q=0.95).item() if normal_vals.numel() > 1 else normal_vals.max().item()
    return {
        "normal_sem_error_mean": float(normal_vals.mean().item()),
        "normal_sem_error_std": float(normal_vals.std(unbiased=False).item()),
        "normal_sem_error_max": float(normal_vals.max().item()),
        "normal_sem_error_p95": float(p95),
        "normal_safe_weight_mean": float(safe_weights.mean().item()),
        "normal_safe_weight_min": float(safe_weights.min().item()),
    }


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    backbone_tag = args.backbone.replace("-", "").replace("+", "plus").lower()
    stem = f"{args.output_tag}_{backbone_tag}_layer{args.target_layer}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    ckpt_path = output_dir / f"{stem}_best.pt"
    png_path = output_dir / f"{stem}_curves.png"

    mask_transform = build_mask_transform(args.img_cropsize)
    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.img_resize,
        crp_size=args.img_cropsize,
        msk_size=args.img_cropsize,
        msk_crp_size=args.img_cropsize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    records = flatten_records(dataset)
    normal_records, anomaly_records = collect_records_by_label(records)
    records_by_image_path = {rec["image_path"]: rec for rec in records}

    winclip = WinClipAD(
        out_size_h=args.img_cropsize,
        out_size_w=args.img_cropsize,
        device=str(device),
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=(2, 3),
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    ).to(device)
    winclip.eval_mode()
    n_blocks = len(winclip.model.visual.transformer.resblocks)
    if not (1 <= args.target_layer <= n_blocks):
        raise ValueError(f"target_layer={args.target_layer} outside [1, {n_blocks}] for WinCLIP backbone.")
    token_side = winclip.grid_size[0]

    audit_cache_path = _audit_cache_path(output_dir, args)
    audit = _load_cached_json(audit_cache_path) if args.reuse_dataset_cache else None
    if audit is None:
        audit = audit_dataset(
            records=records,
            mask_transform=mask_transform,
            image_size=args.img_cropsize,
            token_side=token_side,
            verify_limit=args.audit_verify_limit,
            mask_audit_limit=args.mask_audit_limit,
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with audit_cache_path.open("w") as f:
            json.dump(audit, f, indent=2)

    shared_trainable_cache_path = _trainable_cache_path(output_dir, args, token_side)
    trainable_anomalies = None
    trainable_meta = None
    if args.reuse_dataset_cache:
        cached_trainable = _load_cached_json(shared_trainable_cache_path)
        if cached_trainable is not None:
            cached_records = []
            for rec in cached_trainable.get("records", []):
                current = records_by_image_path.get(rec["image_path"])
                if current is not None:
                    cached_records.append(current)
            if cached_records:
                trainable_anomalies = cached_records
                trainable_meta = cached_trainable.get("pool_meta", {})
    if trainable_anomalies is None or trainable_meta is None:
        trainable_anomalies, trainable_meta = filter_trainable_anomalies(
            anomaly_records=anomaly_records,
            mask_transform=mask_transform,
            token_side=token_side,
            scan_limit=max(args.mask_audit_limit, args.batch_size * args.steps * 4),
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        with shared_trainable_cache_path.open("w") as f:
            json.dump(
                {
                    "config": {
                        "mask_dilate_kernel": args.mask_dilate_kernel,
                        "token_side": token_side,
                        "scan_limit": max(args.mask_audit_limit, args.batch_size * args.steps * 4),
                    },
                    "pool_meta": trainable_meta,
                    "records": [
                        {
                            "image_path": rec["image_path"],
                            "mask_path": rec["mask_path"],
                            "class_name": rec["class_name"],
                            "anomaly_type": rec["anomaly_type"],
                            "sample_id": rec["sample_id"],
                        }
                        for rec in trainable_anomalies
                    ],
                },
                f,
                indent=2,
            )
    if not trainable_anomalies:
        raise RuntimeError("No trainable anomaly samples survived token-grid downsampling.")

    semantic_basis_by_class: dict[str, torch.Tensor] = {}
    feature_dim = winclip.model.visual.proj.shape[0]
    model = AlphaSpaceKinematicRefiner(
        feature_dim=feature_dim,
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
    ).to(device)
    objective = AlphaSpaceObjective(
        lambda_sem=args.lambda_sem,
        lambda_normal=args.lambda_normal,
        lambda_anomaly=args.lambda_anomaly,
        lambda_pairwise=args.lambda_pairwise,
        pairwise_margin=args.pairwise_margin,
        sem_threshold=args.sem_threshold,
        sem_gas_beta=args.sem_gas_beta,
        sem_threshold_mode=args.sem_threshold_mode,
        sem_dynamic_gamma=args.sem_dynamic_gamma,
    ).to(device)
    optimizer = None if args.profile_sem_only else torch.optim.AdamW(
        model.parameters(), lr=args.lr, weight_decay=args.weight_decay
    )

    rng = random.Random(args.seed)
    probe_rng = random.Random(args.seed + 101)
    probe_batch = probe_rng.sample(normal_records, min(len(normal_records), args.probe_normals))
    probe_batch += probe_rng.sample(trainable_anomalies, min(len(trainable_anomalies), args.probe_anomalies))
    probe_rng.shuffle(probe_batch)
    for rec in probe_batch:
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = build_winclip_prompt_token_basis(winclip, rec["class_name"])

    best_probe_score = -float("inf")
    best_probe_step = -1
    best_state = None
    step_rows = []

    for step in range(1, args.steps + 1):
        tic = time.time()
        current_lr = cosine_decay_lr(
            step=step,
            total_steps=args.steps,
            base_lr=args.lr,
            start_step=max(1, args.lr_decay_start),
            min_ratio=args.lr_min_ratio,
        )
        if optimizer is not None:
            for group in optimizer.param_groups:
                group["lr"] = current_lr

        batch = sample_balanced_batch(normal_records, trainable_anomalies, args.batch_size, rng)
        images, masks_t, basis_t, _ = build_batch_tensors_winclip(
            batch, winclip, mask_transform, semantic_basis_by_class, args, device
        )
        patch_mask_flat = (
            F.interpolate(masks_t.float(), size=winclip.grid_size, mode="nearest")[:, 0].reshape(len(batch), -1) > 0.5
        )
        groups = extract_scale_groups(winclip.model.visual, images, patch_mask_flat, args.target_layer)

        total_units = sum(int(group["tokens"].shape[0]) for group in groups)
        if optimizer is not None:
            optimizer.zero_grad()
        total_loss_value = 0.0
        alpha_n_acc = 0.0
        alpha_a_acc = 0.0
        sem_acc = 0.0
        pair_acc = 0.0
        profile_mean_acc = 0.0
        profile_std_acc = 0.0
        profile_max_acc = 0.0
        profile_p95_acc = 0.0
        profile_sw_mean_acc = 0.0
        profile_sw_min_acc = 0.0
        weight_acc = 0.0

        for group_idx, group in enumerate(groups):
            tokens = group["tokens"]
            n_windows = int(group["n_windows"])
            side = int(group["side"])
            basis_group = basis_t.repeat(n_windows, 1, 1)
            if args.profile_sem_only:
                with torch.no_grad():
                    out = model(tokens, semantic_basis=basis_group, spatial_shape=(side, side))
                    loss_stats = objective(
                        raw_features=tokens,
                        refined_features=out.refined,
                        alpha=out.alpha,
                        anomaly_mask=group["window_masks"],
                        semantic_basis=basis_group,
                        spatial_shape=(side, side),
                    )
            else:
                out = model(tokens, semantic_basis=basis_group, spatial_shape=(side, side))
                loss_stats = objective(
                    raw_features=tokens,
                    refined_features=out.refined,
                    alpha=out.alpha,
                    anomaly_mask=group["window_masks"],
                    semantic_basis=basis_group,
                    spatial_shape=(side, side),
                )
            weight = float(tokens.shape[0]) / float(max(total_units, 1))
            profile_stats = profile_normal_sem_error(
                raw_tokens=tokens,
                refined_tokens=out.refined,
                window_masks=group["window_masks"],
                basis_group=basis_group,
                sem_gas_beta=args.sem_gas_beta,
            )
            profile_mean_acc += weight * profile_stats["normal_sem_error_mean"]
            profile_std_acc += weight * profile_stats["normal_sem_error_std"]
            profile_max_acc += weight * profile_stats["normal_sem_error_max"]
            profile_p95_acc += weight * profile_stats["normal_sem_error_p95"]
            profile_sw_mean_acc += weight * profile_stats["normal_safe_weight_mean"]
            profile_sw_min_acc += weight * profile_stats["normal_safe_weight_min"]
            if optimizer is not None:
                scaled = loss_stats["loss"] * weight
                scaled.backward(retain_graph=group_idx + 1 < len(groups))
                total_loss_value += float(scaled.detach().item())
            else:
                total_loss_value += float((loss_stats["loss"] * weight).detach().item())
            alpha_n_acc += weight * float(loss_stats["alpha_normal_mean"].item())
            alpha_a_acc += weight * float(loss_stats["alpha_anomaly_mean"].item())
            sem_acc += weight * float(loss_stats["loss_sem"].item())
            pair_acc += weight * float(loss_stats["loss_pairwise"].item())
            weight_acc += weight

        if optimizer is not None:
            optimizer.step()

        alpha_n = alpha_n_acc / max(weight_acc, 1e-8)
        alpha_a = alpha_a_acc / max(weight_acc, 1e-8)
        row = {
            "step": step,
            "loss": float(total_loss_value),
            "loss_sem": float(sem_acc / max(weight_acc, 1e-8)),
            "loss_pairwise": float(pair_acc / max(weight_acc, 1e-8)),
            "alpha_normal_mean": float(alpha_n),
            "alpha_anomaly_mean": float(alpha_a),
            "alpha_gap": float(alpha_n - alpha_a),
            "normal_sem_error_mean": float(profile_mean_acc / max(weight_acc, 1e-8)),
            "normal_sem_error_std": float(profile_std_acc / max(weight_acc, 1e-8)),
            "normal_sem_error_max": float(profile_max_acc / max(weight_acc, 1e-8)),
            "normal_sem_error_p95": float(profile_p95_acc / max(weight_acc, 1e-8)),
            "normal_safe_weight_mean": float(profile_sw_mean_acc / max(weight_acc, 1e-8)),
            "normal_safe_weight_min": float(profile_sw_min_acc / max(weight_acc, 1e-8)),
            "lr_current": current_lr,
        }

        if step % args.eval_interval == 0 or step == 1 or step == args.steps:
            probe_metrics = evaluate_probe(
                model=model,
                objective=objective,
                winclip=winclip,
                probe_batch=probe_batch,
                semantic_basis_by_class=semantic_basis_by_class,
                mask_transform=mask_transform,
                args=args,
                device=device,
            )
            row.update(probe_metrics)
            if probe_metrics["probe_score"] > best_probe_score:
                best_probe_score = probe_metrics["probe_score"]
                best_probe_step = step
                best_state = copy.deepcopy(model.state_dict())
                torch.save(
                    {
                        "model_state_dict": best_state,
                        "refiner_config": {
                            "feature_dim": feature_dim,
                            "kernel_size": args.kernel_size,
                            "topk_ratio": args.topk_ratio,
                            "hidden_dim": args.hidden_dim,
                            "dropout": args.dropout,
                            "target_layer": args.target_layer,
                        },
                        "target_layer": args.target_layer,
                    },
                    ckpt_path,
                )

        step_rows.append(row)
        print(
            f"[step {step}] loss={row['loss']:.4f} sem={row['loss_sem']:.4f} pair={row['loss_pairwise']:.4f} "
            f"alpha_n={row['alpha_normal_mean']:.4f} alpha_a={row['alpha_anomaly_mean']:.4f} "
            f"gap={row['alpha_gap']:.4f} lr={row['lr_current']:.5f} t={time.time() - tic:.2f}s",
            flush=True,
        )

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(step_rows[0].keys()))
        writer.writeheader()
        writer.writerows(step_rows)

    summary = {
        "config": vars(args),
        "dataset_audit": audit,
        "trainable_anomaly_pool": trainable_meta,
        "best_probe_step": best_probe_step,
        "best_probe_score": best_probe_score,
        "checkpoint_path": str(ckpt_path),
        "final_step": step_rows[-1],
    }
    with json_path.open("w") as f:
        json.dump(summary, f, indent=2)

    steps = [row["step"] for row in step_rows]
    train_gaps = [row["alpha_gap"] for row in step_rows]
    probe_gaps = [row.get("probe_alpha_gap", float("nan")) for row in step_rows]
    fig, ax = plt.subplots(1, 1, figsize=(7, 4))
    ax.plot(steps, train_gaps, label="train gap")
    ax.plot(steps, probe_gaps, label="probe gap")
    ax.set_xlabel("step")
    ax.set_ylabel("alpha gap")
    ax.legend()
    ax.grid(True, alpha=0.2)
    fig.tight_layout()
    fig.savefig(png_path, dpi=200)

    print(f"saved_ckpt={ckpt_path}")
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_png={png_path}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
