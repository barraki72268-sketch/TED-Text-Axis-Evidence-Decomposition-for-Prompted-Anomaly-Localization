#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026" / "scripts" / "probe_bayespfl_ted_smoke.py"
OUT = ROOT / "neurips2026" / "results" / "bayespfl_quick_smoke_20260507"
LOG = ROOT / "neurips2026" / "logs" / "bayespfl_quick_smoke_20260507.log"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls")
CKPT = str(ROOT / "neurips2026" / "results" / "bayespfl_strict_mvtec" / "epoch_post_15_1.pth")
CONFIG = str(ROOT / "neurips2026" / "Bayes-PFL" / "open_clip_local" / "model_configs" / "ViT-L-14-336.json")
PRETRAINED = "/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt"
BANK_CACHE = str(ROOT / "neurips2026" / "results" / "bank_cache" / "bayespfl_quick_mvtec_seed333_20260507.pt")


def pid_alive(pid: int) -> bool:
    return Path(f"/proc/{pid}").exists()


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.parent.mkdir(parents=True, exist_ok=True)
    wait_pids = [3842373, 3842374, 3855872]
    while any(pid_alive(pid) for pid in wait_pids):
        print(
            json.dumps({"stage": "waiting_for_gpus", "alive": [pid for pid in wait_pids if pid_alive(pid)]}),
            flush=True,
        )
        time.sleep(60)

    cmd = [
        PY,
        "-u",
        str(SCRIPT),
        "--dataset",
        "mvtec",
        "--data_path",
        MVTEC_ROOT,
        "--target_dataset",
        "visa",
        "--target_data_path",
        VISA_ROOT,
        "--target_class",
        "capsules",
        "--checkpoint_path",
        CKPT,
        "--config_path",
        CONFIG,
        "--pretrained_path",
        PRETRAINED,
        "--image_size",
        "518",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--device_id",
        "0",
        "--seed",
        "333",
        "--sample_num",
        "10",
        "--max_good_per_class",
        "4",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--bank_cache_path",
        BANK_CACHE,
        "--hard_frac",
        "0.01",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--margin_sign",
        "def_minus_fp",
        "--map_activation",
        "sigmoid",
        "--ted_combine",
        "residual",
        "--ted_alpha",
        "0.05",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_eta_init",
        "0.01",
        "--calib_eta_max",
        "0.05",
        "--calib_eta_reg",
        "1e-3",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_hard_frac",
        "0.01",
        "--calib_max_good_per_class",
        "4",
        "--calib_max_defect_per_class",
        "4",
        "--calib_max_fp_per_image",
        "64",
        "--calib_max_defect_per_image",
        "64",
        "--calib_max_train_points",
        "4096",
        "--image_topk",
        "0.01",
        "--aupro_max_step",
        "120",
        "--max_normal_eval",
        "16",
        "--max_anomaly_eval",
        "16",
        "--save_dir",
        str(OUT / "mvtec2visa_capsules_quick"),
    ]
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    print(json.dumps({"stage": "start_bayespfl_quick", "log": str(LOG)}), flush=True)
    with LOG.open("w") as log:
        proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log, stderr=subprocess.STDOUT, text=True)
    print(json.dumps({"stage": "done_bayespfl_quick", "returncode": proc.returncode, "log": str(LOG)}), flush=True)
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
