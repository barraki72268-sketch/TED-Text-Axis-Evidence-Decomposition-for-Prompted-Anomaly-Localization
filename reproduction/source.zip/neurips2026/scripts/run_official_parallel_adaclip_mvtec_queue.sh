#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_adaclip.py"
CKPT="${ROOT}/neurips2026/AdaCLIP/ckpt/pretrained_mvtec_colondb.pth"
SOURCE_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
SOURCE_DATASET="mvtec"
COMMON_BANK="${ROOT}/neurips2026/results/bank_cache/adaclip_mvtec_full_multilayer.pt"
export MPLCONFIGDIR="/tmp/matplotlib-adaclip-gpu0"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

run_one() {
  local target_root="$1"
  local target_dataset="$2"
  local save_dir="$3"

  CUDA_VISIBLE_DEVICES=0 "${PYTHON}" "${SCRIPT}" \
    --source_root "${SOURCE_ROOT}" \
    --source_dataset "${SOURCE_DATASET}" \
    --target_root "${target_root}" \
    --target_dataset "${target_dataset}" \
    --checkpoint_path "${CKPT}" \
    --save_dir "${save_dir}" \
    --bank_cache_path "${COMMON_BANK}" \
    --image_size 518 \
    --sigma 4 \
    --prompting_depth 4 \
    --prompting_length 5 \
    --prompting_branch VL \
    --prompting_type SD \
    --use_hsf true \
    --k_clusters 20 \
    --max_good_per_class 2 \
    --max_defect_per_class 4 \
    --max_bank_per_layer 512 \
    --max_fp_per_image 64 \
    --max_defect_per_image 64 \
    --cpu_threads 1 \
    --device cuda:0
}

run_one \
  "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  "visa" \
  "${ROOT}/neurips2026/results/official_parallel_test_adaclip_mvtec2visa_all"

run_one \
  "/mnt/data/MPDD" \
  "mpdd" \
  "${ROOT}/neurips2026/results/official_parallel_test_adaclip_mvtec2mpdd_all"

run_one \
  "${ROOT}/neurips2026/data/BTAD_official" \
  "btad" \
  "${ROOT}/neurips2026/results/official_parallel_test_adaclip_mvtec2btad_all"
