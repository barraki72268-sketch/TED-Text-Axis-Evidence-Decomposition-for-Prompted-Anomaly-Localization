from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy.ndimage import gaussian_filter
from skimage import measure
from sklearn.metrics import average_precision_score, roc_auc_score, auc
from torch.utils.data import DataLoader
from torchvision import transforms

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.models.dino import DinoModel  # noqa: E402
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.official_parallel_test_rawclip import encode_prompt_pair  # noqa: E402


PRESET_CONFIGS = {
    "visa2mvtec": {
        "source_dataset": "visa",
        "target_dataset": "mvtec",
        "source_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "target_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
    },
    "visa2mpdd": {
        "source_dataset": "visa",
        "target_dataset": "mpdd",
        "source_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "target_root": "/mnt/data/pilab-kingjinyoung/ADPretrain/datasets/MPDD",
    },
    "visa2btad": {
        "source_dataset": "visa",
        "target_dataset": "btad",
        "source_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "target_root": str(ROOT / "neurips2026" / "data" / "BTAD_official"),
    },
    "mvtec2visa": {
        "source_dataset": "mvtec",
        "target_dataset": "visa",
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "target_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
    },
    "mvtec2mpdd": {
        "source_dataset": "mvtec",
        "target_dataset": "mpdd",
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "target_root": "/mnt/data/pilab-kingjinyoung/ADPretrain/datasets/MPDD",
    },
    "mvtec2btad": {
        "source_dataset": "mvtec",
        "target_dataset": "btad",
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "target_root": str(ROOT / "neurips2026" / "data" / "BTAD_official"),
    },
}

DINO_MEAN = (0.485, 0.456, 0.406)
DINO_STD = (0.229, 0.224, 0.225)


def build_dino_transform(image_size: int):
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size), Image.BICUBIC),
            transforms.CenterCrop(image_size),
            transforms.Lambda(lambda im: im.convert("RGB")),
            transforms.ToTensor(),
            transforms.Normalize(mean=DINO_MEAN, std=DINO_STD),
        ]
    )


class DualMetaDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        root: str,
        dino_transform,
        clip_transform,
        mask_transform,
        split: str,
        class_name: str | None = None,
        anomaly_only: bool | None = None,
        normal_only: bool | None = None,
    ):
        self.root = Path(root)
        self.dino_transform = dino_transform
        self.clip_transform = clip_transform
        self.mask_transform = mask_transform
        meta = json.loads((self.root / "meta.json").read_text())
        split_meta = meta[split]
        if class_name is not None:
            split_meta = {class_name: split_meta[class_name]}
        self.obj_list = sorted(split_meta.keys())
        self.items = []
        for cls_name in self.obj_list:
            for item in split_meta[cls_name]:
                anomaly = int(item["anomaly"])
                if anomaly_only is True and anomaly == 0:
                    continue
                if normal_only is True and anomaly != 0:
                    continue
                self.items.append(item)

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int):
        item = self.items[index]
        image = Image.open(self.root / item["img_path"]).convert("RGB")
        anomaly = int(item["anomaly"])
        mask_path = item.get("mask_path")
        if anomaly == 0 or not mask_path:
            mask = Image.fromarray(np.zeros((image.size[1], image.size[0]), dtype=np.uint8), mode="L")
        else:
            raw_mask = np.array(Image.open(self.root / mask_path).convert("L")) > 0
            mask = Image.fromarray(raw_mask.astype(np.uint8) * 255, mode="L")
        return {
            "dino": self.dino_transform(image),
            "clip": self.clip_transform(image),
            "mask": self.mask_transform(mask),
            "label": torch.tensor(anomaly, dtype=torch.long),
            "class_name": item["cls_name"],
            "img_path": item["img_path"],
        }


def mask_transform(image_size: int):
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.NEAREST),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
        ]
    )


def downsample_mask(mask: torch.Tensor, side: int) -> torch.Tensor:
    ds = F.interpolate(mask.float(), size=(side, side), mode="nearest")
    return ds[:, 0].reshape(mask.shape[0], -1) > 0.5


def safe_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    if y_true.size == 0 or np.min(y_true) == np.max(y_true):
        return float("nan")
    return float(roc_auc_score(y_true, y_score))


def safe_ap(y_true: np.ndarray, y_score: np.ndarray) -> float:
    if y_true.size == 0 or np.min(y_true) == np.max(y_true):
        return float("nan")
    return float(average_precision_score(y_true, y_score))


def precompute_aupro_regions(masks: np.ndarray) -> dict:
    masks = (masks > 0.5).astype(np.uint8)
    inverse_masks = 1 - masks
    regions_by_image = []
    for mask in masks:
        regions = []
        labeled = measure.label(mask)
        for region in measure.regionprops(labeled):
            regions.append(region.coords)
        regions_by_image.append(regions)
    return {
        "masks": masks,
        "inverse_masks": inverse_masks,
        "inverse_total": int(inverse_masks.sum()),
        "regions_by_image": regions_by_image,
        "has_foreground": bool(masks.sum() > 0),
    }


def calculate_aupro(masks: np.ndarray, maps: np.ndarray, max_step: int, precomputed: dict | None = None) -> float:
    pre = precomputed if precomputed is not None else precompute_aupro_regions(masks)
    if not pre["has_foreground"] or pre["inverse_total"] <= 0:
        return float("nan")
    maps = maps.astype(np.float32)
    min_th = float(np.min(maps))
    max_th = float(np.max(maps))
    if not np.isfinite(min_th) or not np.isfinite(max_th) or max_th <= min_th:
        return 0.5
    pros, fprs = [], []
    for th in np.linspace(min_th, max_th, max_step, endpoint=False):
        binary = maps > th
        pro_vals = []
        for binary_map, regions in zip(binary, pre["regions_by_image"]):
            for coords in regions:
                pro_vals.append(float(binary_map[coords[:, 0], coords[:, 1]].mean()))
        if not pro_vals:
            continue
        fp_pixels = np.logical_and(pre["inverse_masks"], binary).sum()
        pros.append(float(np.mean(pro_vals)))
        fprs.append(float(fp_pixels / pre["inverse_total"]))
    if not pros:
        return float("nan")
    pros_np = np.asarray(pros, dtype=np.float32)
    fprs_np = np.asarray(fprs, dtype=np.float32)
    keep = fprs_np < 0.3
    if int(keep.sum()) <= 2:
        return 0.5
    f = fprs_np[keep]
    p = pros_np[keep]
    order = np.argsort(f)
    f = f[order]
    p = p[order]
    denom = float(f.max() - f.min())
    if denom <= 1e-12:
        return 0.5
    return float(auc((f - f.min()) / denom, p) * 100.0)


def compute_metrics(masks: np.ndarray, labels: np.ndarray, maps: np.ndarray, img_scores: np.ndarray, aupro_max_step: int) -> dict:
    pre = precompute_aupro_regions(masks)
    return {
        "pixel_auc": safe_auc(masks.reshape(-1).astype(np.uint8), maps.reshape(-1).astype(np.float32)),
        "pixel_ap": safe_ap(masks.reshape(-1).astype(np.uint8), maps.reshape(-1).astype(np.float32)),
        "pixel_aupro": calculate_aupro(masks, maps, aupro_max_step, pre),
        "image_auc": safe_auc(labels.astype(np.uint8), img_scores.astype(np.float32)),
        "image_ap": safe_ap(labels.astype(np.uint8), img_scores.astype(np.float32)),
    }


def topk_mean_np(arr: np.ndarray, frac: float) -> np.ndarray:
    flat = arr.reshape(arr.shape[0], -1)
    k = max(1, int(math.ceil(flat.shape[1] * frac)))
    idx = np.argpartition(flat, -k, axis=1)[:, -k:]
    return np.take_along_axis(flat, idx, axis=1).mean(axis=1)


def fit_ridge_bridge(x: torch.Tensor, y: torch.Tensor, ridge: float) -> torch.Tensor:
    x64 = x.double()
    y64 = y.double()
    eye = torch.eye(x64.shape[1], dtype=x64.dtype)
    xtx = (x64.T @ x64) / max(x64.shape[0], 1) + ridge * eye
    xty = (x64.T @ y64) / max(x64.shape[0], 1)
    return torch.linalg.solve(xtx, xty).float()


def project_dino(tokens: torch.Tensor, bridge: torch.Tensor) -> torch.Tensor:
    return F.normalize(tokens.float() @ bridge.to(tokens.device), dim=-1)


def extract_dino_layers(dino: DinoModel, image: torch.Tensor, layers: list[int]) -> dict[int, torch.Tensor]:
    outs = dino.encode_image(image, layers)
    return {layer: outs[i].float() for i, layer in enumerate(layers)}


def collect_bridge_pairs(
    dino: DinoModel,
    clip_backbone,
    ds: DualMetaDataset,
    layers: list[int],
    device: torch.device,
    max_fit_per_class: int,
    max_patches_per_image: int,
    seed: int,
) -> dict[int, tuple[torch.Tensor, torch.Tensor]]:
    rng = random.Random(seed)
    per_class = {cls: 0 for cls in ds.obj_list}
    xs = {layer: [] for layer in layers}
    ys = {layer: [] for layer in layers}
    for item in ds:
        cls = item["class_name"]
        if per_class[cls] >= max_fit_per_class:
            continue
        per_class[cls] += 1
        dino_img = item["dino"].unsqueeze(0).to(device)
        clip_img = item["clip"].unsqueeze(0).to(device)
        dino_layers = extract_dino_layers(dino, dino_img, layers)
        clip_layers = clip_backbone.extract_layer_patch_tokens(clip_img, target_layers=layers)
        for layer in layers:
            x = F.normalize(dino_layers[layer][0].float(), dim=-1).cpu()
            y = F.normalize(clip_layers[layer][0].float(), dim=-1).cpu()
            n = min(x.shape[0], y.shape[0], max_patches_per_image)
            idx = torch.tensor(rng.sample(range(min(x.shape[0], y.shape[0])), n), dtype=torch.long)
            xs[layer].append(x[idx])
            ys[layer].append(y[idx])
    return {layer: (torch.cat(xs[layer], dim=0), torch.cat(ys[layer], dim=0)) for layer in layers}


def score_tokens(tokens: torch.Tensor, text_pair: dict, tau: float = 0.07) -> torch.Tensor:
    logits = tokens @ torch.stack([text_pair["norm_tok"], text_pair["anom_tok"]], dim=1).to(tokens.device)
    return (logits / tau).softmax(dim=-1)[:, 1]


def logmeanexp_cosine(query: torch.Tensor, bank: torch.Tensor, tau: float) -> torch.Tensor:
    if bank.numel() == 0:
        return torch.full((query.shape[0],), -1e6, device=query.device, dtype=query.dtype)
    bank = F.normalize(bank.to(query.device).float(), dim=-1)
    query = F.normalize(query.float(), dim=-1)
    sim = query @ bank.t()
    return torch.logsumexp(sim / max(tau, 1e-6), dim=-1) - math.log(max(bank.shape[0], 1))


def collect_source_banks(
    dino: DinoModel,
    clip_backbone,
    source_root: str,
    dino_transform,
    clip_transform,
    mask_t,
    bridges: dict[int, torch.Tensor],
    layers: list[int],
    device: torch.device,
    max_fp_per_class: int,
    max_defect_per_class: int,
    normal_topk_frac: float,
    defect_topk_frac: float,
) -> dict:
    meta = json.loads((Path(source_root) / "meta.json").read_text())
    class_names = sorted(meta["train"].keys())
    fp_by_layer = {layer: [] for layer in layers}
    def_by_layer = {layer: [] for layer in layers}
    for cls in class_names:
        text_pair = encode_prompt_pair(clip_backbone, cls, "class")
        normal_ds = DualMetaDataset(source_root, dino_transform, clip_transform, mask_t, "train", class_name=cls, normal_only=True)
        anomaly_ds = DualMetaDataset(source_root, dino_transform, clip_transform, mask_t, "test", class_name=cls, anomaly_only=True)
        fp_parts = {layer: [] for layer in layers}
        def_parts = {layer: [] for layer in layers}
        for item in normal_ds:
            dino_img = item["dino"].unsqueeze(0).to(device)
            dino_layers = extract_dino_layers(dino, dino_img, layers)
            for layer in layers:
                z = project_dino(dino_layers[layer][0], bridges[layer])
                score = score_tokens(z, text_pair)
                k = max(1, int(math.ceil(score.numel() * normal_topk_frac)))
                fp_parts[layer].append(z[torch.topk(score, k=k, largest=True).indices].detach().cpu())
        for item in anomaly_ds:
            dino_img = item["dino"].unsqueeze(0).to(device)
            mask = item["mask"].unsqueeze(0).to(device)
            dino_layers = extract_dino_layers(dino, dino_img, layers)
            for layer in layers:
                z = project_dino(dino_layers[layer][0], bridges[layer])
                side = int(round(math.sqrt(z.shape[0])))
                pos = torch.nonzero(downsample_mask(mask, side)[0], as_tuple=False).flatten()
                if pos.numel() == 0:
                    continue
                score = score_tokens(z, text_pair)[pos]
                k = max(1, int(math.ceil(pos.numel() * defect_topk_frac)))
                k = min(k, pos.numel())
                def_parts[layer].append(z[pos[torch.topk(score, k=k, largest=True).indices]].detach().cpu())
        for layer in layers:
            fp = torch.cat(fp_parts[layer], dim=0) if fp_parts[layer] else torch.empty(0, bridges[layer].shape[1])
            de = torch.cat(def_parts[layer], dim=0) if def_parts[layer] else torch.empty(0, bridges[layer].shape[1])
            if fp.shape[0] > max_fp_per_class:
                fp = fp[torch.randperm(fp.shape[0])[:max_fp_per_class]]
            if de.shape[0] > max_defect_per_class:
                de = de[torch.randperm(de.shape[0])[:max_defect_per_class]]
            fp_by_layer[layer].append(fp)
            def_by_layer[layer].append(de)
        print(json.dumps({"stage": "source_class_done", "class_name": cls}), flush=True)
    return {
        "fp": {layer: F.normalize(torch.cat(fp_by_layer[layer], dim=0).float(), dim=-1) for layer in layers},
        "defect": {layer: F.normalize(torch.cat(def_by_layer[layer], dim=0).float(), dim=-1) for layer in layers},
    }


def support_mass_gate(q_def: torch.Tensor, q_fp: torch.Tensor, sharpness: float) -> torch.Tensor:
    mass = q_def + q_fp
    mass = (mass - mass.mean()) / mass.std().clamp_min(1e-6)
    return torch.sigmoid(sharpness * torch.tanh(mass))


def evaluate_target(
    dino: DinoModel,
    clip_backbone,
    target_root: str,
    dino_transform,
    clip_transform,
    mask_t,
    bridges: dict[int, torch.Tensor],
    banks: dict,
    layers: list[int],
    device: torch.device,
    alphas: list[float],
    image_size: int,
    sigma: float,
    support_tau: float,
    gate_sharpness: float,
    image_score_topk: float,
    aupro_max_step: int,
) -> dict:
    ds = DualMetaDataset(target_root, dino_transform, clip_transform, mask_t, "test")
    results = {
        "baseline": {cls: {"maps": [], "imgs": [], "labels": [], "masks": []} for cls in ds.obj_list},
        **{f"prescore_rectify_alpha_{a:g}": {cls: {"maps": [], "imgs": [], "labels": [], "masks": []} for cls in ds.obj_list} for a in alphas},
    }
    for item in ds:
        cls = item["class_name"]
        text_pair = encode_prompt_pair(clip_backbone, cls, "class")
        axis = text_pair["axis_tok"].to(device)
        dino_img = item["dino"].unsqueeze(0).to(device)
        label = int(item["label"].item())
        mask = item["mask"].numpy()[0].astype(np.float32)
        dino_layers = extract_dino_layers(dino, dino_img, layers)
        baseline_layers = []
        rect_layers = {a: [] for a in alphas}
        for layer in layers:
            z = project_dino(dino_layers[layer][0], bridges[layer])
            side = int(round(math.sqrt(z.shape[0])))
            score = score_tokens(z, text_pair)
            baseline_layers.append(score.view(1, 1, side, side))
            q_def = logmeanexp_cosine(z, banks["defect"][layer], support_tau)
            q_fp = logmeanexp_cosine(z, banks["fp"][layer], support_tau)
            margin = torch.tanh((q_def - q_fp - (q_def - q_fp).mean()) / (q_def - q_fp).std().clamp_min(1e-6))
            gate = support_mass_gate(q_def, q_fp, gate_sharpness)
            for alpha in alphas:
                z_rect = F.normalize(z + float(alpha) * gate.unsqueeze(-1) * margin.unsqueeze(-1) * axis.view(1, -1), dim=-1)
                rect_layers[alpha].append(score_tokens(z_rect, text_pair).view(1, 1, side, side))
        base = torch.stack(baseline_layers).mean(dim=0)
        base = F.interpolate(base, size=(image_size, image_size), mode="bilinear", align_corners=False)[:, 0]
        if sigma > 0:
            base_np = gaussian_filter(base.detach().cpu().numpy()[0], sigma=sigma)[None, ...]
        else:
            base_np = base.detach().cpu().numpy()
        results["baseline"][cls]["maps"].append(base_np[0])
        results["baseline"][cls]["imgs"].append(topk_mean_np(base_np, image_score_topk)[0])
        results["baseline"][cls]["labels"].append(label)
        results["baseline"][cls]["masks"].append(mask)
        for alpha in alphas:
            rect = torch.stack(rect_layers[alpha]).mean(dim=0)
            rect = F.interpolate(rect, size=(image_size, image_size), mode="bilinear", align_corners=False)[:, 0]
            rect_np = gaussian_filter(rect.detach().cpu().numpy()[0], sigma=sigma)[None, ...] if sigma > 0 else rect.detach().cpu().numpy()
            key = f"prescore_rectify_alpha_{alpha:g}"
            results[key][cls]["maps"].append(rect_np[0])
            results[key][cls]["imgs"].append(topk_mean_np(rect_np, image_score_topk)[0])
            results[key][cls]["labels"].append(label)
            results[key][cls]["masks"].append(mask)

    rows = []
    mean = {}
    for mode, by_cls in results.items():
        vals = []
        for cls, pack in by_cls.items():
            maps = np.stack(pack["maps"], axis=0).astype(np.float32)
            masks = np.stack(pack["masks"], axis=0).astype(np.float32)
            labels = np.asarray(pack["labels"], dtype=np.int64)
            imgs = np.asarray(pack["imgs"], dtype=np.float32)
            metrics = compute_metrics(masks, labels, maps, imgs, aupro_max_step)
            rows.append({"mode": mode, "class_name": cls, **metrics})
            vals.append(metrics)
        mean[mode] = {k: float(np.nanmean([v[k] for v in vals])) for k in vals[0]}
    return {"rows": rows, "mean": mean}


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="visa2mvtec", choices=sorted(PRESET_CONFIGS))
    ap.add_argument("--dino_backbone", default="dinov2-large", choices=["dinov2-base", "dinov2-large"])
    ap.add_argument("--clip_backbone", default="ViT-L-14")
    ap.add_argument("--clip_pretrained", default="openai")
    ap.add_argument("--layers", type=int, nargs="+", default=[6, 12, 18, 24])
    ap.add_argument("--image_size", type=int, default=224)
    ap.add_argument("--fit_max_per_class", type=int, default=2)
    ap.add_argument("--fit_max_patches_per_image", type=int, default=128)
    ap.add_argument("--ridge", type=float, default=1e-3)
    ap.add_argument("--max_fp_per_class", type=int, default=256)
    ap.add_argument("--max_defect_per_class", type=int, default=256)
    ap.add_argument("--normal_topk_frac", type=float, default=0.01)
    ap.add_argument("--defect_topk_frac", type=float, default=0.25)
    ap.add_argument("--support_tau", type=float, default=0.1)
    ap.add_argument("--gate_sharpness", type=float, default=3.0)
    ap.add_argument("--alphas", default="0.02,0.05,0.1")
    ap.add_argument("--sigma", type=float, default=4.0)
    ap.add_argument("--image_score_topk", type=float, default=0.01)
    ap.add_argument("--aupro_max_step", type=int, default=50)
    ap.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--save_dir", required=True)
    return ap.parse_args()


def main():
    args = parse_args()
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    cfg = PRESET_CONFIGS[args.preset]
    device = torch.device(args.device)
    dino = DinoModel(args.dino_backbone, device=str(device)).eval()
    dino.visual_encoder = dino.visual_encoder.to(device)
    clip_backbone = create_winclip_raw_backbone(
        backbone=args.clip_backbone,
        pretrained_dataset=args.clip_pretrained,
        device=device,
        img_resize=args.image_size,
        img_cropsize=args.image_size,
    )
    dino_t = build_dino_transform(args.image_size)
    clip_t = clip_backbone.image_transform
    mask_t = mask_transform(args.image_size)
    fit_ds = DualMetaDataset(cfg["source_root"], dino_t, clip_t, mask_t, "train", normal_only=True)
    pairs = collect_bridge_pairs(
        dino=dino,
        clip_backbone=clip_backbone,
        ds=fit_ds,
        layers=args.layers,
        device=device,
        max_fit_per_class=args.fit_max_per_class,
        max_patches_per_image=args.fit_max_patches_per_image,
        seed=args.seed,
    )
    bridges = {layer: fit_ridge_bridge(x, y, args.ridge).to(device) for layer, (x, y) in pairs.items()}
    print(json.dumps({"stage": "bridge_fit_done", "layers": args.layers}), flush=True)
    banks = collect_source_banks(
        dino=dino,
        clip_backbone=clip_backbone,
        source_root=cfg["source_root"],
        dino_transform=dino_t,
        clip_transform=clip_t,
        mask_t=mask_t,
        bridges=bridges,
        layers=args.layers,
        device=device,
        max_fp_per_class=args.max_fp_per_class,
        max_defect_per_class=args.max_defect_per_class,
        normal_topk_frac=args.normal_topk_frac,
        defect_topk_frac=args.defect_topk_frac,
    )
    print(json.dumps({"stage": "source_bank_done"}), flush=True)
    result = evaluate_target(
        dino=dino,
        clip_backbone=clip_backbone,
        target_root=cfg["target_root"],
        dino_transform=dino_t,
        clip_transform=clip_t,
        mask_t=mask_t,
        bridges=bridges,
        banks=banks,
        layers=args.layers,
        device=device,
        alphas=[float(x) for x in args.alphas.split(",") if x],
        image_size=args.image_size,
        sigma=args.sigma,
        support_tau=args.support_tau,
        gate_sharpness=args.gate_sharpness,
        image_score_topk=args.image_score_topk,
        aupro_max_step=args.aupro_max_step,
    )
    result.update(
        {
            "preset": args.preset,
            "source_dataset": cfg["source_dataset"],
            "target_dataset": cfg["target_dataset"],
            "dino_backbone": args.dino_backbone,
            "clip_backbone": args.clip_backbone,
            "clip_pretrained": args.clip_pretrained,
            "layers": args.layers,
            "image_size": args.image_size,
            "alphas": [float(x) for x in args.alphas.split(",") if x],
        }
    )
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    out = save_dir / "summary.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result["mean"], indent=2), flush=True)
    print(f"[OK] wrote {out}", flush=True)


if __name__ == "__main__":
    main()
