from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = "/mnt/data/envs/patchcore-conda/bin/python"


def log_line(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps(payload) + "\n")


def run_task(name: str, cmd: list[str], log_path: Path, env: dict[str, str]) -> int:
    started = time.time()
    log_line(log_path, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": "task_start", "name": name, "cmd": cmd})
    proc = subprocess.run(cmd, cwd=ROOT, env=env, text=True, capture_output=True)
    ended = time.time()
    log_line(
        log_path,
        {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "stage": "task_end",
            "name": name,
            "returncode": proc.returncode,
            "elapsed_sec": round(ended - started, 2),
            "stdout_tail": proc.stdout[-4000:],
            "stderr_tail": proc.stderr[-4000:],
        },
    )
    return proc.returncode


def output_ready(path: Path) -> bool:
    return path.exists() and path.stat().st_size > 0


def process_alive(pattern: str) -> bool:
    proc = subprocess.run(
        ["bash", "-lc", f"pgrep -f {pattern!r} >/dev/null"],
        cwd=ROOT,
        text=True,
        capture_output=True,
    )
    return proc.returncode == 0


def main():
    parser = argparse.ArgumentParser("Sequential overnight runner for region-bank and transfer probes")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--log_path", type=str, default=str(ROOT / "neurips2026" / "results" / "runtime" / "region_overnight_queue.log"))
    args = parser.parse_args()

    env = os.environ.copy()
    env.setdefault("CUDA_VISIBLE_DEVICES", str(args.gpu))
    env.setdefault("MPLCONFIGDIR", "/tmp/mpl")

    tasks = [
        {
            "name": "adaptclip_region_bank_holdout",
            "cmd": [PYTHON, "neurips2026/scripts/probe_adaptclip_region_bank_holdout.py", "--device", "cuda:0"],
            "done_file": ROOT / "neurips2026/results/adaptclip_region_bank_holdout_epoch15/summary.json",
            "wait_pattern": "probe_adaptclip_region_bank_holdout.py --device cuda:0",
        },
        {
            "name": "adaptclip_region_discriminant",
            "cmd": [PYTHON, "neurips2026/scripts/probe_adaptclip_region_discriminant.py", "--device", "cuda:0"],
            "done_file": ROOT / "neurips2026/results/adaptclip_region_discriminant_epoch15/metrics.json",
        },
        {
            "name": "faprompt_region_bank_holdout",
            "cmd": [PYTHON, "neurips2026/scripts/probe_faprompt_region_bank_holdout.py", "--device", "cuda:0"],
            "done_file": ROOT / "neurips2026/results/faprompt_region_bank_holdout_epoch15/summary.json",
        },
        {
            "name": "faprompt_region_discriminant",
            "cmd": [PYTHON, "neurips2026/scripts/probe_faprompt_region_discriminant.py", "--device", "cuda:0"],
            "done_file": ROOT / "neurips2026/results/faprompt_region_discriminant_epoch15/metrics.json",
        },
        {
            "name": "adaclip_region_bank_holdout",
            "cmd": [PYTHON, "neurips2026/scripts/probe_adaclip_region_bank_holdout.py", "--device", "cuda:0"],
            "done_file": ROOT / "neurips2026/results/adaclip_region_bank_holdout_last/summary.json",
        },
        {
            "name": "adaclip_region_discriminant",
            "cmd": [PYTHON, "neurips2026/scripts/probe_adaclip_region_discriminant.py", "--device", "cuda:0"],
            "done_file": ROOT / "neurips2026/results/adaclip_region_discriminant_last/metrics.json",
        },
        {
            "name": "bayespfl_region_bank_holdout",
            "cmd": [PYTHON, "neurips2026/scripts/probe_bayespfl_region_bank_holdout.py", "--device_id", "0"],
            "done_file": ROOT / "neurips2026/results/bayespfl_region_bank_holdout_epoch15/summary.json",
        },
        {
            "name": "bayespfl_region_discriminant",
            "cmd": [PYTHON, "neurips2026/scripts/probe_bayespfl_region_discriminant.py", "--device_id", "0"],
            "done_file": ROOT / "neurips2026/results/bayespfl_region_discriminant_epoch15/metrics.json",
        },
    ]

    log_path = Path(args.log_path)
    for task in tasks:
        name = task["name"]
        done_file = task["done_file"]
        if output_ready(done_file):
            log_line(log_path, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": "task_skip_done", "name": name, "done_file": str(done_file)})
            continue
        wait_pattern = task.get("wait_pattern")
        if wait_pattern:
            waited = 0
            while process_alive(wait_pattern) and not output_ready(done_file):
                log_line(log_path, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": "task_wait_existing", "name": name, "done_file": str(done_file), "waited_sec": waited})
                time.sleep(300)
                waited += 300
        if output_ready(done_file):
            log_line(log_path, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": "task_skip_done_after_wait", "name": name, "done_file": str(done_file)})
            continue
        rc = run_task(name, task["cmd"], log_path, env)
        if rc != 0:
            log_line(log_path, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": "queue_abort", "name": name, "returncode": rc})
            sys.exit(rc)
    log_line(log_path, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": "queue_done"})


if __name__ == "__main__":
    main()
