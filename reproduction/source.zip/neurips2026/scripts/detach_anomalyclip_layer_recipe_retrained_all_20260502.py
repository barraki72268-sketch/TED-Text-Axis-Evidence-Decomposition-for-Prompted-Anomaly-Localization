#!/usr/bin/env python3
"""Detach the AnomalyCLIP layer-recipe retraining queue."""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
QUEUE = ROOT / "neurips2026/scripts/queue_anomalyclip_layer_recipe_retrained_all_20260502.py"
OUT = ROOT / "neurips2026/results/anomalyclip_layer_recipe_retrained_all_20260502"
LOG = OUT / "queue.detached.log"
PID = OUT / "queue.pid"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--recipes", default="all4,last,last2,mid2,earlylate")
    parser.add_argument("--force_train", action="store_true")
    parser.add_argument("--force_eval", action="store_true")
    parser.add_argument("--force_bank", action="store_true")
    parser.add_argument("--skip_official", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(QUEUE),
        "--device_id",
        str(args.device_id),
        "--recipes",
        args.recipes,
    ]
    if args.force_train:
        cmd.append("--force_train")
    if args.force_eval:
        cmd.append("--force_eval")
    if args.force_bank:
        cmd.append("--force_bank")
    if args.skip_official:
        cmd.append("--skip_official")

    with LOG.open("ab") as log:
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    PID.write_text(str(proc.pid) + "\n", encoding="utf-8")
    print({"stage": "detached", "pid": proc.pid, "root": str(OUT), "log": str(LOG), "cmd": " ".join(cmd)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
