from __future__ import annotations

import json
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"


def load_json(path: Path) -> dict:
    with path.open("r") as f:
        return json.load(f)


def collect_ad_host_map_separability() -> dict:
    host_files = {
        "AnomalyCLIP": (
            RESULTS / "anomalyclip_map_separability_baseline_epoch5" / "summary.json",
            RESULTS / "anomalyclip_map_separability_matched_epoch5" / "summary.json",
        ),
        "AdaptCLIP": (
            RESULTS / "adaptclip_map_separability_baseline_epoch15" / "summary.json",
            RESULTS / "adaptclip_map_separability_matched_epoch15" / "summary.json",
        ),
        "AdaCLIP": (
            RESULTS / "adaclip_map_separability_baseline_last" / "summary.json",
            RESULTS / "adaclip_map_separability_matched_last" / "summary.json",
        ),
        "FAPrompt": (
            RESULTS / "faprompt_map_separability_baseline_epoch15" / "summary.json",
            RESULTS / "faprompt_map_separability_matched_epoch15" / "summary.json",
        ),
        "BayesPFL": (
            RESULTS / "bayespfl_map_separability_matched_epoch15" / "summary.json",
            RESULTS / "bayespfl_map_separability_matched_epoch15" / "summary.json",
        ),
    }
    out = {}
    for host, (baseline_path, matched_path) in host_files.items():
        row = {}
        if baseline_path is not None and baseline_path.exists():
            baseline = load_json(baseline_path)["summary"]
            row["baseline_true_vs_hardfp_auc"] = baseline["pairwise_auc"].get("true_defect_vs_hard_fp")
            row["baseline_true_mean"] = baseline["groups"]["true_defect"]["mean"]
            row["baseline_hardfp_mean"] = baseline["groups"]["hard_fp"]["mean"]
            row["baseline_gap"] = row["baseline_true_mean"] - row["baseline_hardfp_mean"]
            row["baseline_true_p50"] = baseline["groups"]["true_defect"]["p50"]
            row["baseline_hardfp_p50"] = baseline["groups"]["hard_fp"]["p50"]
            row["baseline_p50_gap"] = row["baseline_true_p50"] - row["baseline_hardfp_p50"]
        else:
            row["baseline_true_vs_hardfp_auc"] = None
            row["baseline_true_mean"] = None
            row["baseline_hardfp_mean"] = None
            row["baseline_gap"] = None
            row["baseline_true_p50"] = None
            row["baseline_hardfp_p50"] = None
            row["baseline_p50_gap"] = None

        matched = load_json(matched_path)["matched_summary"]
        row["matched_true_topk_vs_hardfp_topk_auc"] = matched["pairwise_auc"].get("true_defect_topk_vs_hard_fp_topk")
        row["matched_true_topk_mean"] = matched["groups"]["true_defect_topk"]["mean"]
        row["matched_hardfp_topk_mean"] = matched["groups"]["hard_fp_topk"]["mean"]
        row["matched_gap"] = row["matched_true_topk_mean"] - row["matched_hardfp_topk_mean"]
        out[host] = row
    return out


def collect_anomalyclip_gtfree_entanglement() -> dict:
    return load_json(RESULTS / "anomalyclip_gtfree_entanglement" / "metrics.json")


def collect_rawclip_official_vitb() -> dict:
    presets = {
        "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitb_visa2mvtec_all" / "summary.json",
        "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2visa_all" / "summary.json",
        "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2mpdd_all" / "summary.json",
        "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2btad_all" / "summary.json",
    }
    out = {}
    for preset, path in presets.items():
        rows = load_json(path)["rows"]
        baseline = next(r for r in rows if r["mode"] == "baseline_txt" and r["target_label"] == "mean")
        parallel = next(r for r in rows if r["mode"] == "parallel_margin" and r["target_label"] == "mean")
        out[preset] = {
            "baseline_txt": baseline,
            "parallel_margin": parallel,
        }
    return out


def collect_rawclip_gtfree_entanglement() -> dict | None:
    path = RESULTS / "rawclip_vitb_gtfree_entanglement" / "metrics.json"
    if not path.exists():
        return None
    return load_json(path)


def main() -> None:
    report = {
        "AD_host_map_separability": collect_ad_host_map_separability(),
        "AnomalyCLIP_GTFree_subset": collect_anomalyclip_gtfree_entanglement(),
        "RawCLIP_ViTB_official": collect_rawclip_official_vitb(),
        "RawCLIP_ViTB_GTFree_subset": collect_rawclip_gtfree_entanglement(),
    }
    out_path = RESULTS / "quick_host_survey_20260425.json"
    out_path.write_text(json.dumps(report, indent=2))
    print(out_path)


if __name__ == "__main__":
    main()
