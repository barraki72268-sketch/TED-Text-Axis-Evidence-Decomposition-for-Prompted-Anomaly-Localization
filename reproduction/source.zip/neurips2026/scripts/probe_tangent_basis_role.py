from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import RiemannianLowRankRefiner
from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--refiner_ckpt", type=str, required=True)
    parser.add_argument("--target_layer", type=int, default=6)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--rank", type=int, default=4)
    parser.add_argument("--output_tag", type=str, default="tangent_basis_role")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(backbone, batch_np) -> torch.Tensor:
    imgs = [backbone.transform_pil(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(backbone.device)


def load_refiner(ckpt_path: str, device: torch.device) -> tuple[RiemannianLowRankRefiner, dict]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload["refiner_config"]
    refiner = RiemannianLowRankRefiner(
        feature_dim=int(config["feature_dim"]),
        kernel_size=int(config["kernel_size"]),
        topk_ratio=float(config["topk_ratio"]),
        rank=int(config["rank"]),
        hidden_dim=int(config["hidden_dim"]),
        dropout=float(config["dropout"]),
        lambda_max=float(config.get("lambda_max", 2.0)),
    ).to(device)
    refiner.load_state_dict(payload["model_state_dict"], strict=True)
    refiner.eval()
    return refiner, config


@torch.no_grad()
def collect_train_refined_stats(backbone, refiner, loader, target_layer: int, rank: int, num_steps: int):
    normal_feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        images = _preprocess_batch(backbone, data)
        raw_tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        out = refiner(raw_tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps)
        refined = F.normalize(out.refined[normal_idx].float(), dim=-1)
        normal_feats.append(refined.cpu())

    if not normal_feats:
        raise RuntimeError("No normal train features found.")

    feat_bank = torch.cat(normal_feats, dim=0)  # [M, N, D]
    prototype = F.normalize(feat_bank.mean(dim=0, keepdim=True), dim=-1)

    num_patches = feat_bank.shape[1]
    feature_dim = feat_bank.shape[2]
    oracle_basis = []
    for patch_idx in range(num_patches):
        source = feat_bank[:, patch_idx, :]
        centered = source - source.mean(dim=0, keepdim=True)
        q = min(rank, centered.shape[0], feature_dim)
        if q < 1:
            oracle_basis.append(torch.zeros(rank, feature_dim))
            continue
        _u, _s, v = torch.pca_lowrank(centered.float(), q=q, center=False)
        basis = F.normalize(v[:, :q], dim=0).transpose(0, 1)  # [q, D]
        if q < rank:
            pad = torch.zeros(rank - q, feature_dim, dtype=basis.dtype)
            basis = torch.cat([basis, pad], dim=0)
        oracle_basis.append(basis.cpu())
    oracle_basis = torch.stack(oracle_basis, dim=0)  # [N, R, D]
    return prototype, oracle_basis


def _safe_auc(pos_values: np.ndarray, neg_values: np.ndarray, *, positive_high: bool) -> float:
    if pos_values.size == 0 or neg_values.size == 0:
        return float("nan")
    labels = np.concatenate(
        [
            np.ones_like(pos_values, dtype=np.int32),
            np.zeros_like(neg_values, dtype=np.int32),
        ]
    )
    scores = np.concatenate([pos_values, neg_values])
    if not positive_high:
        scores = -scores
    return float(roc_auc_score(labels, scores))


@torch.no_grad()
def evaluate_tangent_role(
    backbone,
    refiner,
    loader,
    prototype: torch.Tensor,
    oracle_basis: torch.Tensor,
    target_layer: int,
    num_steps: int,
):
    normal_capture_global = []
    anomaly_capture_global = []
    normal_off_global = []
    anomaly_off_global = []
    normal_capture_local = []
    anomaly_capture_local = []
    normal_off_local = []
    anomaly_off_local = []
    normal_align = []
    anomaly_align = []

    for data, mask, _label, _name, _img_type in loader:
        images = _preprocess_batch(backbone, data)
        raw_tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        out = refiner(raw_tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps)
        refined = F.normalize(out.refined.float(), dim=-1)
        proto = prototype.to(refined.device, dtype=refined.dtype).expand(refined.shape[0], -1, -1)
        residual_global = refined - proto
        local_mean = F.normalize(out.local_mean.float(), dim=-1)
        residual_local = refined - local_mean
        projected_global = torch.einsum(
            "bnrd,bnr->bnd",
            out.basis.float(),
            torch.einsum("bnrd,bnd->bnr", out.basis.float(), residual_global.float()),
        )
        projected_local = torch.einsum(
            "bnrd,bnr->bnd",
            out.basis.float(),
            torch.einsum("bnrd,bnd->bnr", out.basis.float(), residual_local.float()),
        )

        residual_global_sq = residual_global.float().square().sum(dim=-1).clamp_min(1e-8)
        projected_global_sq = projected_global.float().square().sum(dim=-1)
        capture_global = (projected_global_sq / residual_global_sq).clamp(0.0, 1.0)
        off_global = 1.0 - F.cosine_similarity(residual_global.float(), projected_global.float(), dim=-1, eps=1e-6)
        off_global = torch.where(residual_global_sq > 1e-8, off_global, torch.zeros_like(off_global))

        residual_local_sq = residual_local.float().square().sum(dim=-1).clamp_min(1e-8)
        projected_local_sq = projected_local.float().square().sum(dim=-1)
        capture_local = (projected_local_sq / residual_local_sq).clamp(0.0, 1.0)
        off_local = 1.0 - F.cosine_similarity(residual_local.float(), projected_local.float(), dim=-1, eps=1e-6)
        off_local = torch.where(residual_local_sq > 1e-8, off_local, torch.zeros_like(off_local))

        oracle = oracle_basis.to(refined.device, dtype=refined.dtype).unsqueeze(0).expand(refined.shape[0], -1, -1, -1)
        overlap = torch.einsum("bnrd,bnqd->bnrq", out.basis.float(), oracle.float())
        align = overlap.square().sum(dim=(-2, -1)) / float(out.basis.shape[2])

        mask_t = mask.float()
        if mask_t.ndim == 3:
            mask_t = mask_t.unsqueeze(1)
        patch_mask = (
            F.interpolate(mask_t, size=backbone.grid_size, mode="nearest")[:, 0].reshape(refined.shape[0], -1) > 0.5
        )
        normal_mask = ~patch_mask

        normal_capture_global.append(capture_global[normal_mask].detach().cpu().numpy())
        anomaly_capture_global.append(capture_global[patch_mask].detach().cpu().numpy())
        normal_off_global.append(off_global[normal_mask].detach().cpu().numpy())
        anomaly_off_global.append(off_global[patch_mask].detach().cpu().numpy())
        normal_capture_local.append(capture_local[normal_mask].detach().cpu().numpy())
        anomaly_capture_local.append(capture_local[patch_mask].detach().cpu().numpy())
        normal_off_local.append(off_local[normal_mask].detach().cpu().numpy())
        anomaly_off_local.append(off_local[patch_mask].detach().cpu().numpy())
        normal_align.append(align[normal_mask].detach().cpu().numpy())
        anomaly_align.append(align[patch_mask].detach().cpu().numpy())

    def _cat(xs):
        xs = [x.reshape(-1) for x in xs if x.size > 0]
        if not xs:
            return np.zeros((0,), dtype=np.float32)
        return np.concatenate(xs, axis=0)

    normal_capture_global = _cat(normal_capture_global)
    anomaly_capture_global = _cat(anomaly_capture_global)
    normal_off_global = _cat(normal_off_global)
    anomaly_off_global = _cat(anomaly_off_global)
    normal_capture_local = _cat(normal_capture_local)
    anomaly_capture_local = _cat(anomaly_capture_local)
    normal_off_local = _cat(normal_off_local)
    anomaly_off_local = _cat(anomaly_off_local)
    normal_align = _cat(normal_align)
    anomaly_align = _cat(anomaly_align)

    return {
        "normal_capture_global_mean": float(normal_capture_global.mean()) if normal_capture_global.size else float("nan"),
        "anomaly_capture_global_mean": float(anomaly_capture_global.mean()) if anomaly_capture_global.size else float("nan"),
        "capture_global_gap": float(normal_capture_global.mean() - anomaly_capture_global.mean()) if normal_capture_global.size and anomaly_capture_global.size else float("nan"),
        "capture_global_auc_normal_gt_anom": _safe_auc(normal_capture_global, anomaly_capture_global, positive_high=True),
        "normal_offtangent_global_mean": float(normal_off_global.mean()) if normal_off_global.size else float("nan"),
        "anomaly_offtangent_global_mean": float(anomaly_off_global.mean()) if anomaly_off_global.size else float("nan"),
        "offtangent_global_gap_anom_minus_normal": float(anomaly_off_global.mean() - normal_off_global.mean()) if normal_off_global.size and anomaly_off_global.size else float("nan"),
        "offtangent_global_auc_anom_gt_normal": _safe_auc(anomaly_off_global, normal_off_global, positive_high=True),
        "normal_capture_local_mean": float(normal_capture_local.mean()) if normal_capture_local.size else float("nan"),
        "anomaly_capture_local_mean": float(anomaly_capture_local.mean()) if anomaly_capture_local.size else float("nan"),
        "capture_local_gap": float(normal_capture_local.mean() - anomaly_capture_local.mean()) if normal_capture_local.size and anomaly_capture_local.size else float("nan"),
        "capture_local_auc_normal_gt_anom": _safe_auc(normal_capture_local, anomaly_capture_local, positive_high=True),
        "normal_offtangent_local_mean": float(normal_off_local.mean()) if normal_off_local.size else float("nan"),
        "anomaly_offtangent_local_mean": float(anomaly_off_local.mean()) if anomaly_off_local.size else float("nan"),
        "offtangent_local_gap_anom_minus_normal": float(anomaly_off_local.mean() - normal_off_local.mean()) if normal_off_local.size and anomaly_off_local.size else float("nan"),
        "offtangent_local_auc_anom_gt_normal": _safe_auc(anomaly_off_local, normal_off_local, positive_high=True),
        "normal_oracle_align_mean": float(normal_align.mean()) if normal_align.size else float("nan"),
        "anomaly_oracle_align_mean": float(anomaly_align.mean()) if anomaly_align.size else float("nan"),
        "oracle_align_gap": float(normal_align.mean() - anomaly_align.mean()) if normal_align.size and anomaly_align.size else float("nan"),
        "oracle_align_auc_normal_gt_anom": _safe_auc(normal_align, anomaly_align, positive_high=True),
        "normal_count": int(normal_capture_global.size),
        "anomaly_count": int(anomaly_capture_global.size),
    }


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu")

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    refiner, config = load_refiner(args.refiner_ckpt, device)
    num_steps = int(config.get("num_steps", 2))

    rows = []
    for class_name in args.class_names:
        train_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "train", args.batch_size)
        test_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)
        prototype, oracle_basis = collect_train_refined_stats(
            backbone=backbone,
            refiner=refiner,
            loader=train_loader,
            target_layer=args.target_layer,
            rank=args.rank,
            num_steps=num_steps,
        )
        metrics = evaluate_tangent_role(
            backbone=backbone,
            refiner=refiner,
            loader=test_loader,
            prototype=prototype,
            oracle_basis=oracle_basis,
            target_layer=args.target_layer,
            num_steps=num_steps,
        )
        row = {
            "class_name": class_name,
            "target_layer": args.target_layer,
            "num_steps": num_steps,
            "rank": args.rank,
            **metrics,
        }
        rows.append(row)
        print(
            f"{class_name} | gcap={row['capture_global_gap']:.4f}/{row['capture_global_auc_normal_gt_anom']:.4f} "
            f"lcap={row['capture_local_gap']:.4f}/{row['capture_local_auc_normal_gt_anom']:.4f} "
            f"oracle_gap={row['oracle_align_gap']:.4f} "
            f"oracle_auc={row['oracle_align_auc_normal_gt_anom']:.4f}",
            flush=True,
        )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(rows, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
