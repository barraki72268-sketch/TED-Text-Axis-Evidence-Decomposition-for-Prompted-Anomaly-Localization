from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    build_dataset,
    collect_source_patch_banks,
    decision_axis,
    decompose_with_axis,
    logmeanexp_negative_sqdist,
    logmeanexp_negative_sqdist_1d,
    project_bank,
)
from probe_anomalyclip_text_decomposition_score import (  # noqa: E402
    collect_source_margin_stats,
    normalize_robust,
    patch_text_score,
)


def apply_ad_scoremap(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.5) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, cv2.COLORMAP_JET)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return (alpha * image.astype(float) + (1 - alpha) * scoremap.astype(float)).astype(np.uint8)


def normalize_map(arr: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((arr - vmin) / denom, 0.0, 1.0)


def stable_sigmoid(arr: np.ndarray) -> np.ndarray:
    out = np.empty_like(arr, dtype=np.float32)
    pos = arr >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-arr[pos]))
    exp_x = np.exp(arr[~pos])
    out[~pos] = exp_x / (1.0 + exp_x)
    return out


def pick_sample(dataset, target_classes: set[str] | None, anomaly_only: bool, sample_index: int):
    matches = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        if target_classes is not None and item["cls_name"] not in target_classes:
            continue
        anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
        if anomaly_only and anomaly_flag == 0:
            continue
        matches.append((idx, item))
    if sample_index >= len(matches):
        raise IndexError(f"sample_index={sample_index} out of range, only {len(matches)} matches")
    return matches[sample_index]


def main():
    parser = argparse.ArgumentParser("Visualize baseline vs text-conditioned decomposition score on one sample")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--target_classes", nargs="*", default=["capsules"])
    parser.add_argument("--heldout_class", type=str, default="bottle")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--checkpoint_path", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"))
    parser.add_argument("--save_dir", type=str, required=True)
    parser.add_argument("--sample_index", type=int, default=0)
    parser.add_argument("--beta", type=float, default=1.0)
    parser.add_argument("--mode", type=str, default="parallel_margin", choices=["parallel_margin", "additive_no_gate", "additive_gated"])
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--stats_max_images_per_class", type=int, default=8)
    parser.add_argument("--stats_per_image_patch_samples", type=int, default=128)
    args = parser.parse_args()

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    axis = decision_axis(learned_pair).to(args.device)

    fp_banks, def_banks, bank_stats = collect_source_patch_banks(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=args.heldout_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
    )
    stats_cfg = collect_source_margin_stats(
        model=model,
        text_pair=learned_pair,
        fp_banks=fp_banks,
        def_banks=def_banks,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        source_exclude_class=args.heldout_class,
        axis=axis,
        tau=args.tau,
        max_images_per_class=args.stats_max_images_per_class,
        per_image_patch_samples=args.stats_per_image_patch_samples,
    )

    dataset = build_dataset(args.target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    _, item = pick_sample(dataset, set(args.target_classes) if args.target_classes else None, anomaly_only=True, sample_index=args.sample_index)
    image = item["img"].unsqueeze(0).to(args.device)
    gt_mask = item["img_mask"].unsqueeze(0).float()
    gt_mask_np = gt_mask[0, 0].cpu().numpy().astype(bool)
    input_img = np.transpose(item["img"].cpu().numpy(), (1, 2, 0))
    input_img = np.clip((input_img * np.array([0.26862954, 0.26130258, 0.27577711]) + np.array([0.48145466, 0.4578275, 0.40821073])) * 255.0, 0, 255).astype(np.uint8)

    bank_device = axis.device
    fp_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in fp_banks.items()}
    def_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in def_banks.items()}
    projected_banks = {}
    for layer_idx in range(len(args.features_list)):
        fp_coeff, fp_perp = project_bank(fp_banks[layer_idx], axis)
        def_coeff, def_perp = project_bank(def_banks[layer_idx], axis)
        projected_banks[layer_idx] = {
            "fp_parallel_coeff": fp_coeff,
            "fp_perp": fp_perp,
            "def_parallel_coeff": def_coeff,
            "def_perp": def_perp,
        }

    with torch.no_grad():
        _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
        txt_maps = []
        parallel_maps = []
        for layer_idx, patch_feature in enumerate(patch_features):
            patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
            patch_coeff = patch @ axis
            banks = projected_banks[layer_idx]
            s_txt = patch_text_score(patch_feature, learned_pair)
            q_fp_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["fp_parallel_coeff"], tau=args.tau)
            q_def_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["def_parallel_coeff"], tau=args.tau)
            h = int(round(patch.shape[0] ** 0.5))
            txt_maps.append(s_txt.reshape(h, h).detach().cpu().numpy())
            parallel_maps.append((q_def_parallel - q_fp_parallel).reshape(h, h).detach().cpu().numpy())

    target_h, target_w = gt_mask_np.shape

    def resize_map(arr: np.ndarray) -> np.ndarray:
        return (
            F.interpolate(
                torch.from_numpy(arr).unsqueeze(0).unsqueeze(0).float(),
                size=(target_h, target_w),
                mode="bilinear",
                align_corners=False,
            )[0, 0]
            .cpu()
            .numpy()
        )

    s_txt_map = resize_map(np.mean(np.stack(txt_maps, axis=0), axis=0))
    r_parallel_map = resize_map(np.mean(np.stack(parallel_maps, axis=0), axis=0))
    s_txt_z = normalize_robust(s_txt_map, stats_cfg["s_txt"])
    r_parallel_z = normalize_robust(r_parallel_map, stats_cfg["r_parallel"])
    g_txt = stable_sigmoid(s_txt_z)
    ours_map = r_parallel_map
    if args.mode == "additive_no_gate":
        ours_map = s_txt_z + args.beta * np.tanh(r_parallel_z)
    elif args.mode == "additive_gated":
        ours_map = s_txt_z + args.beta * g_txt * np.tanh(r_parallel_z)

    all_maps = [s_txt_z, ours_map]
    vmin = min(float(x.min()) for x in all_maps)
    vmax = max(float(x.max()) for x in all_maps)
    base_norm = normalize_map(s_txt_z, vmin, vmax)
    ours_norm = normalize_map(ours_map, vmin, vmax)

    fig, axes = plt.subplots(2, 4, figsize=(18, 9))
    axes[0, 0].imshow(input_img)
    axes[0, 0].set_title("input")
    axes[0, 0].axis("off")
    axes[0, 1].imshow(gt_mask_np, cmap="gray")
    axes[0, 1].set_title("GT mask")
    axes[0, 1].axis("off")
    axes[0, 2].imshow(apply_ad_scoremap(input_img, base_norm))
    axes[0, 2].set_title("baseline overlay")
    axes[0, 2].axis("off")
    axes[0, 3].imshow(apply_ad_scoremap(input_img, ours_norm))
    title = f"ours overlay ({args.mode})" if args.mode == "parallel_margin" else f"ours overlay ({args.mode}, beta={args.beta})"
    axes[0, 3].set_title(title)
    axes[0, 3].axis("off")

    im0 = axes[1, 0].imshow(base_norm, cmap="jet", vmin=0.0, vmax=1.0)
    axes[1, 0].set_title("baseline heatmap")
    axes[1, 0].axis("off")
    im1 = axes[1, 1].imshow(ours_norm, cmap="jet", vmin=0.0, vmax=1.0)
    axes[1, 1].set_title("ours heatmap")
    axes[1, 1].axis("off")
    axes[1, 2].hist(s_txt_z[gt_mask_np], bins=40, alpha=0.65, label="inside", color="tab:red")
    axes[1, 2].hist(s_txt_z[~gt_mask_np], bins=40, alpha=0.65, label="outside", color="tab:blue")
    axes[1, 2].set_title("baseline hist")
    axes[1, 2].legend()
    axes[1, 3].hist(ours_map[gt_mask_np], bins=40, alpha=0.65, label="inside", color="tab:red")
    axes[1, 3].hist(ours_map[~gt_mask_np], bins=40, alpha=0.65, label="outside", color="tab:blue")
    axes[1, 3].set_title("ours hist")
    axes[1, 3].legend()

    cbar = fig.colorbar(im1, ax=axes[:, :2].ravel().tolist(), fraction=0.02, pad=0.02)
    cbar.set_label("normalized score")
    fig.tight_layout()

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.target_dataset}_{'_'.join(args.target_classes)}_{item['cls_name']}_{item['specie_name']}_{args.sample_index}"
    png_path = save_dir / f"{stem}.png"
    fig.savefig(png_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    meta = {
        "target_dataset": args.target_dataset,
        "target_classes": args.target_classes,
        "sample_index": args.sample_index,
        "cls_name": item["cls_name"],
        "specie_name": item["specie_name"],
        "mode": args.mode,
        "beta": args.beta,
        "bank_stats": bank_stats,
        "source_stats": stats_cfg,
        "baseline_inside_mean": float(s_txt_z[gt_mask_np].mean()),
        "baseline_outside_mean": float(s_txt_z[~gt_mask_np].mean()),
        "ours_inside_mean": float(ours_map[gt_mask_np].mean()),
        "ours_outside_mean": float(ours_map[~gt_mask_np].mean()),
    }
    with open(save_dir / f"{stem}.json", "w") as f:
        json.dump(meta, f, indent=2)
    print(json.dumps({"png": str(png_path), "meta": meta}, indent=2))


if __name__ == "__main__":
    main()
