from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from common_map_group_separability import auc_from_scores, score_stats, top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner, encode_text_prompt_bank  # noqa: E402
from utils import get_transform  # noqa: E402


def build_model(
    device: str,
    depth: int,
    n_ctx: int,
    t_n_ctx: int,
    model_name_or_path: str = "ViT-L/14@336px",
    dpam_layer: int = 20,
):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load(model_name_or_path, device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=dpam_layer)
    return model, params


def _fit_embedding_bridge(
    source_model,
    target_model,
    ridge: float = 1e-3,
    max_tokens: int = 8192,
) -> tuple[torch.Tensor, torch.Tensor]:
    src = source_model.token_embedding.weight.detach().float()
    tgt = target_model.token_embedding.weight.detach().float()
    n = min(src.shape[0], tgt.shape[0])
    if max_tokens > 0 and n > max_tokens:
        idx = torch.linspace(0, n - 1, steps=max_tokens).long()
        src = src[idx]
        tgt = tgt[idx]
    else:
        src = src[:n]
        tgt = tgt[:n]

    def ridge_map(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        xtx = x.t() @ x
        reg = float(ridge) * torch.eye(xtx.shape[0], dtype=xtx.dtype)
        return torch.linalg.solve(xtx + reg, x.t() @ y)

    return ridge_map(src, tgt), ridge_map(tgt, src)


def _project_prompt_state_dict(
    state_dict: dict[str, torch.Tensor],
    learner,
    source_model,
    target_model,
    ridge: float = 1e-3,
) -> dict[str, torch.Tensor]:
    src_dim = int(state_dict["ctx_pos"].shape[-1])
    tgt_dim = int(learner.ctx_pos.shape[-1])
    if src_dim == tgt_dim:
        return state_dict
    src_to_tgt, tgt_to_src = _fit_embedding_bridge(source_model, target_model, ridge=ridge)
    projected: dict[str, torch.Tensor] = {}
    target_state = learner.state_dict()
    for key, value in state_dict.items():
        if key not in target_state:
            continue
        target_shape = tuple(target_state[key].shape)
        value_shape = tuple(value.shape)
        if value_shape == target_shape:
            projected[key] = value
            continue
        if value.ndim >= 1 and value_shape[-1] == src_dim and target_shape[-1] == tgt_dim:
            projected[key] = (value.reshape(-1, src_dim).float() @ src_to_tgt).reshape(target_shape).to(value.dtype)
            continue
        if key.endswith(".weight") and value.ndim == 2 and value_shape[1] == src_dim and target_shape[1] == tgt_dim:
            if value_shape[0] == target_shape[0]:
                projected[key] = (value.float() @ tgt_to_src.t()).reshape(target_shape).to(value.dtype)
            continue
    return projected


def load_prompt_learner(
    model,
    params,
    checkpoint_path: Path,
    device: str,
    allow_projection: bool = False,
    projection_ridge: float = 1e-3,
):
    learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    prompt_state = checkpoint["prompt_learner"]
    if allow_projection:
        source_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=params)
        prompt_state = _project_prompt_state_dict(
            prompt_state,
            learner=learner,
            source_model=source_model,
            target_model=model,
            ridge=projection_ridge,
        )
        missing, unexpected = learner.load_state_dict(prompt_state, strict=False)
        print(
            {
                "stage": "prompt_projection_load",
                "target_dim": int(learner.ctx_pos.shape[-1]),
                "loaded_keys": len(prompt_state),
                "missing_keys": len(missing),
                "unexpected_keys": len(unexpected),
            },
            flush=True,
        )
    else:
        learner.load_state_dict(prompt_state)
    learner.to(device)
    learner.eval()
    model.to(device)
    model.eval()
    return learner


@torch.no_grad()
def get_learned_text_pair(model, learner) -> torch.Tensor:
    prompts, tokenized_prompts, compound_prompts_text = learner(cls_id=None)
    prompts = prompts.to(next(model.parameters()).device)
    tokenized_prompts = tokenized_prompts.to(next(model.parameters()).device)
    compound_prompts_text = [prompt.to(next(model.parameters()).device) for prompt in compound_prompts_text]
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = F.normalize(text_features, dim=-1)
    return text_features[0]


def load_static_anomaly_text() -> torch.Tensor:
    reference_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=None)
    reference_model.eval()
    _, anomaly_bank = encode_text_prompt_bank(reference_model, "object", "cpu")
    anomaly_bank = F.normalize(anomaly_bank.float(), dim=-1)
    return F.normalize(anomaly_bank.mean(dim=0), dim=-1)


def top_basis(bank: torch.Tensor, max_rank: int, eps: float = 1e-6) -> tuple[torch.Tensor, dict]:
    bank = F.normalize(bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    eff_rank = min(rank, max_rank)
    if eff_rank == 0:
        basis = bank.new_zeros((bank.shape[-1], 0))
        stats = {
            "rank": 0,
            "basis_dim": 0,
            "sv_cum_basis": 0.0,
            "sv_cum_top1": 0.0,
            "sv_cum_top5": 0.0,
            "sv_cum_top10": 0.0,
        }
        return basis, stats
    basis = vh[:eff_rank].transpose(0, 1).contiguous()
    s2 = (s**2) / torch.clamp((s**2).sum(), min=1e-8)
    cum = torch.cumsum(s2, dim=0)
    stats = {
        "rank": rank,
        "basis_dim": eff_rank,
        "sv_cum_basis": float(cum[eff_rank - 1].item()),
        "sv_cum_top1": float(cum[min(0, len(cum) - 1)].item()) if len(cum) else 0.0,
        "sv_cum_top5": float(cum[min(4, len(cum) - 1)].item()) if len(cum) else 0.0,
        "sv_cum_top10": float(cum[min(9, len(cum) - 1)].item()) if len(cum) else 0.0,
    }
    return basis, stats


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = vec @ basis
    return float(coeff.pow(2).sum().item())


def component_decompose(vec: torch.Tensor, basis: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return vec.new_zeros(vec.shape), vec
    proj = basis @ (basis.t() @ vec)
    res = vec - proj
    return proj, res


def build_dataset(root: str, dataset_name: str, image_size: int, mode: str | None = None):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    kwargs = {
        "root": root,
        "transform": preprocess,
        "target_transform": target_transform,
        "dataset_name": dataset_name,
    }
    if mode is not None:
        kwargs["mode"] = mode
    return Dataset(**kwargs)


def collect_source_hardfp_bases(
    model,
    text_pair: torch.Tensor,
    source_root: str,
    image_size: int,
    device: str,
    features_list: list[int],
    feature_map_layer: list[int],
    max_per_class: int,
    hard_frac: float,
    fp_rank: int,
) -> tuple[dict[int, torch.Tensor], dict[int, dict]]:
    dataset = build_dataset(source_root, "mvtec", image_size, mode="train")
    per_class_count: dict[str, int] = {obj: 0 for obj in dataset.obj_list}
    kept_indices = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        anomaly_flag = item["anomaly"]
        if hasattr(anomaly_flag, "item"):
            anomaly_flag = anomaly_flag.item()
        if int(anomaly_flag) != 0:
            continue
        cls_name = item["cls_name"]
        if per_class_count[cls_name] >= max_per_class:
            continue
        per_class_count[cls_name] += 1
        kept_indices.append(idx)

    subset = torch.utils.data.Subset(dataset, kept_indices)
    loader = torch.utils.data.DataLoader(subset, batch_size=1, shuffle=False, num_workers=0)

    layer_chunks: dict[int, list[torch.Tensor]] = {idx: [] for idx in range(len(features_list)) if idx >= feature_map_layer[0]}
    layer_score_chunks: dict[int, list[torch.Tensor]] = {idx: [] for idx in layer_chunks}
    print(
        json.dumps(
            {
                "stage": "collect_source_hardfp_start",
                "num_selected_images": len(kept_indices),
                "hard_frac": hard_frac,
                "max_per_class": max_per_class,
            }
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < feature_map_layer[0]:
                    continue
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                patch_scores = ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)
                k = max(1, int(patch_scores.numel() * hard_frac))
                top_idx = torch.topk(patch_scores, k=k, largest=True).indices
                layer_chunks[layer_idx].append(patch[top_idx].cpu())
                layer_score_chunks[layer_idx].append(patch_scores[top_idx].detach().cpu())
            if img_idx % 16 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "collect_source_hardfp_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    bases: dict[int, torch.Tensor] = {}
    stats: dict[int, dict] = {}
    for layer_idx, chunks in layer_chunks.items():
        bank = torch.cat(chunks, dim=0)
        scores = torch.cat(layer_score_chunks[layer_idx], dim=0)
        basis, basis_stats = top_basis(bank, max_rank=fp_rank)
        bases[layer_idx] = basis
        stats[layer_idx] = {
            "num_source_hardfp_patches": int(bank.shape[0]),
            "source_hardfp_score_mean": float(scores.mean().item()),
            **basis_stats,
        }
    return bases, stats


def sample_np(arr: np.ndarray, max_points: int, seed: int) -> np.ndarray:
    if arr.size <= max_points:
        return arr
    rng = np.random.default_rng(seed)
    idx = rng.choice(arr.size, size=max_points, replace=False)
    return arr[idx]


def evaluate_target_groups(
    model,
    text_pair: torch.Tensor,
    learned_anom: torch.Tensor,
    static_anom: torch.Tensor,
    fp_bases: dict[int, torch.Tensor],
    target_root: str,
    image_size: int,
    device: str,
    features_list: list[int],
    feature_map_layer: list[int],
    hard_frac: float,
    max_points: int,
):
    dataset = build_dataset(target_root, "visa", image_size)
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    groups = {}
    for layer_idx in fp_bases:
        groups[layer_idx] = {
            "total": {"normal": [], "hard_fp": [], "true_defect": [], "outside": []},
            "fp_component": {"normal": [], "hard_fp": [], "true_defect": [], "outside": []},
            "residual_component": {"normal": [], "hard_fp": [], "true_defect": [], "outside": []},
        }

    print(json.dumps({"stage": "target_eval_start", "num_images": len(dataset), "hard_frac": hard_frac}), flush=True)

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            gt_mask = items["img_mask"].to(device).float()
            is_anomaly = int(items["anomaly"][0].item())
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)

            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < feature_map_layer[0] or layer_idx not in fp_bases:
                    continue
                basis = fp_bases[layer_idx].to(device)
                e_fp, e_res = component_decompose(learned_anom.to(device), basis)

                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                total_scores = (patch @ learned_anom.to(device)).detach().cpu().numpy()
                fp_scores = (patch @ e_fp).detach().cpu().numpy()
                res_scores = (patch @ e_res).detach().cpu().numpy()

                h = int(round(total_scores.shape[0] ** 0.5))
                total_grid = total_scores.reshape(h, h)
                fp_grid = fp_scores.reshape(h, h)
                res_grid = res_scores.reshape(h, h)
                gt_small = F.interpolate(gt_mask, size=(h, h), mode="nearest")[0, 0].detach().cpu().numpy() > 0.5

                if is_anomaly and gt_small.any():
                    groups[layer_idx]["total"]["true_defect"].append(total_grid[gt_small].reshape(-1))
                    groups[layer_idx]["total"]["outside"].append(total_grid[~gt_small].reshape(-1))
                    groups[layer_idx]["fp_component"]["true_defect"].append(fp_grid[gt_small].reshape(-1))
                    groups[layer_idx]["fp_component"]["outside"].append(fp_grid[~gt_small].reshape(-1))
                    groups[layer_idx]["residual_component"]["true_defect"].append(res_grid[gt_small].reshape(-1))
                    groups[layer_idx]["residual_component"]["outside"].append(res_grid[~gt_small].reshape(-1))
                else:
                    hard_mask = top_fraction_mask(total_grid, hard_frac)
                    normal_mask = ~hard_mask
                    for key, grid in [
                        ("total", total_grid),
                        ("fp_component", fp_grid),
                        ("residual_component", res_grid),
                    ]:
                        groups[layer_idx][key]["hard_fp"].append(grid[hard_mask].reshape(-1))
                        groups[layer_idx][key]["normal"].append(grid[normal_mask].reshape(-1))

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "target_eval_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    out = {}
    for layer_idx, mode_groups in groups.items():
        layer_out = {
            "learned_fp_proj": projection_energy(learned_anom, fp_bases[layer_idx]),
            "static_fp_proj": projection_energy(static_anom, fp_bases[layer_idx]),
            "learned_minus_static_fp_proj": projection_energy(learned_anom, fp_bases[layer_idx]) - projection_energy(static_anom, fp_bases[layer_idx]),
            "modes": {},
        }
        for mode_name, group_lists in mode_groups.items():
            group_np = {}
            for seed, (group_name, chunks) in enumerate(group_lists.items()):
                vals = np.concatenate(chunks, axis=0) if chunks else np.empty((0,), dtype=np.float32)
                group_np[group_name] = sample_np(vals.astype(np.float32, copy=False), max_points=max_points, seed=seed)
            layer_out["modes"][mode_name] = {
                "groups": {name: score_stats(vals) for name, vals in group_np.items()},
                "pairwise_auc": {
                    "true_defect_vs_hard_fp": auc_from_scores(group_np["true_defect"], group_np["hard_fp"]),
                    "hard_fp_vs_true_defect": auc_from_scores(group_np["hard_fp"], group_np["true_defect"]),
                    "true_defect_vs_outside": auc_from_scores(group_np["true_defect"], group_np["outside"]),
                    "hard_fp_vs_outside": auc_from_scores(group_np["hard_fp"], group_np["outside"]),
                },
            }
        out[layer_idx] = layer_out
    return out


def save_outputs(save_dir: Path, summary: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    rows = []
    for layer_idx, layer_info in summary["layers"].items():
        for mode_name, mode_info in layer_info["modes"].items():
            row = {
                "layer_idx": int(layer_idx),
                "mode": mode_name,
                "learned_fp_proj": layer_info["learned_fp_proj"],
                "static_fp_proj": layer_info["static_fp_proj"],
                "learned_minus_static_fp_proj": layer_info["learned_minus_static_fp_proj"],
                "auc_true_defect_vs_hard_fp": mode_info["pairwise_auc"]["true_defect_vs_hard_fp"],
                "auc_hard_fp_vs_true_defect": mode_info["pairwise_auc"]["hard_fp_vs_true_defect"],
                "hard_fp_mean": mode_info["groups"]["hard_fp"]["mean"],
                "true_defect_mean": mode_info["groups"]["true_defect"]["mean"],
                "outside_mean": mode_info["groups"]["outside"]["mean"],
                "normal_mean": mode_info["groups"]["normal"]["mean"],
            }
            rows.append(row)

    with open(save_dir / "summary.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "layer_idx",
                "mode",
                "learned_fp_proj",
                "static_fp_proj",
                "learned_minus_static_fp_proj",
                "auc_true_defect_vs_hard_fp",
                "auc_hard_fp_vs_true_defect",
                "hard_fp_mean",
                "true_defect_mean",
                "outside_mean",
                "normal_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe FP-specific text decomposition for AnomalyCLIP baseline")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_fp_text_decomposition_baseline_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--source_hard_frac", type=float, default=0.01)
    parser.add_argument("--target_hard_frac", type=float, default=0.01)
    parser.add_argument("--max_source_per_class", type=int, default=8)
    parser.add_argument("--fp_rank", type=int, default=16)
    parser.add_argument("--max_points", type=int, default=200000)
    args = parser.parse_args()

    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    learned_pair = get_learned_text_pair(model, learner)
    learned_anom = learned_pair[1].detach().cpu()
    static_anom = load_static_anomaly_text().cpu()

    fp_bases, fp_stats = collect_source_hardfp_bases(
        model=model,
        text_pair=learned_pair.to(device),
        source_root=args.source_root,
        image_size=args.image_size,
        device=device,
        features_list=args.features_list,
        feature_map_layer=args.feature_map_layer,
        max_per_class=args.max_source_per_class,
        hard_frac=args.source_hard_frac,
        fp_rank=args.fp_rank,
    )

    layer_results = evaluate_target_groups(
        model=model,
        text_pair=learned_pair.to(device),
        learned_anom=learned_anom,
        static_anom=static_anom,
        fp_bases=fp_bases,
        target_root=args.target_root,
        image_size=args.image_size,
        device=device,
        features_list=args.features_list,
        feature_map_layer=args.feature_map_layer,
        hard_frac=args.target_hard_frac,
        max_points=args.max_points,
    )

    summary = {
        "host": "AnomalyCLIP",
        "checkpoint_path": args.checkpoint_path,
        "source_hard_frac": args.source_hard_frac,
        "target_hard_frac": args.target_hard_frac,
        "fp_rank": args.fp_rank,
        "max_source_per_class": args.max_source_per_class,
        "fp_basis_stats": fp_stats,
        "layers": layer_results,
    }
    save_dir = Path(args.save_dir)
    save_outputs(save_dir, summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
