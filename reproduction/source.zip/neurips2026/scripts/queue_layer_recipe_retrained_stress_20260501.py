#!/usr/bin/env python3
"""Queue retrained layer-recipe stress ablations.

This ablation asks whether a host can recover from a stressed layer recipe by
training under that recipe, and whether TED still improves that retrained host.
The training data follows each baseline host's official auxiliary-data recipe.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT_ROOT = ROOT / "neurips2026/results/layer_recipe_retrained_stress_20260501"
LOG_ROOT = OUT_ROOT / "logs"

VISA_1CLS = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
CLINICDB_ROOT = Path("/mnt/data/CVC-ClinicDB")
COLONDB_ROOT = Path("/mnt/data/CVC-ColonDB")


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print(f"[run] {' '.join(cmd)}", flush=True)
    with log_path.open("w") as log:
        proc = subprocess.run(cmd, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed with code {proc.returncode}: {log_path}")


def latest_checkpoint(save_root: Path) -> Path:
    candidates = sorted(save_root.rglob("*_last.pth"), key=lambda p: p.stat().st_mtime)
    if not candidates:
        candidates = sorted(save_root.rglob("*.pth"), key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise FileNotFoundError(f"No checkpoint found under {save_root}")
    return candidates[-1]


def run_anomalyclip_full4(device_id: str, env: dict[str, str]) -> None:
    ckpt_dir = OUT_ROOT / "anomalyclip_visa_full4_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if not ckpt_path.exists():
        train_env = dict(env)
        train_env["CUDA_VISIBLE_DEVICES"] = device_id
        run(
            [
                str(PY),
                "-u",
                "train.py",
                "--dataset",
                "visa",
                "--train_data_path",
                str(VISA_1CLS),
                "--save_path",
                str(ckpt_dir),
                "--features_list",
                "6",
                "12",
                "18",
                "24",
                "--feature_map_layer",
                "0",
                "1",
                "2",
                "3",
                "--image_size",
                "518",
                "--batch_size",
                "8",
                "--print_freq",
                "1",
                "--epoch",
                "15",
                "--save_freq",
                "15",
                "--depth",
                "9",
                "--n_ctx",
                "12",
                "--t_n_ctx",
                "4",
                "--seed",
                "111",
            ],
            ROOT / "neurips2026/AnomalyCLIP",
            LOG_ROOT / "anomalyclip_train_visa_full4.log",
            train_env,
        )
    else:
        print(f"[skip] existing {ckpt_path}", flush=True)

    save_dir = OUT_ROOT / "anomalyclip_visa_full4_eval"
    if (save_dir / "summary.json").exists():
        print(f"[skip] existing {save_dir / 'summary.json'}", flush=True)
        return
    run(
        [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"),
            "--device",
            "cuda:0",
            "--checkpoint_path",
            str(ckpt_path),
            "--source_root",
            str(VISA_1CLS),
            "--source_dataset",
            "visa",
            "--target_root",
            str(MVTEC_ROOT),
            "--target_dataset",
            "mvtec",
            "--target_mode",
            "test",
            "--features_list",
            "6",
            "12",
            "18",
            "24",
            "--bank_cache_path",
            str(OUT_ROOT / "bank_cache/anomalyclip_visa_full4_retrained.pt"),
            "--enable_calibrator",
            "--calib_seed",
            "0",
            "--calib_epochs",
            "80",
            "--calib_subspace_rank",
            "8",
            "--calib_eta_max",
            "0.5",
            "--calib_lambda",
            "0.1",
            "--calib_map_anchor",
            "trainfree",
            "--ted_image_score_mode",
            "host_plus_norm_topk",
            "--parallel_image_fusion_weight",
            "-0.2",
            "--calibrated_image_fusion_weight",
            "-0.02",
            "--skip_separability_metrics",
            "--save_dir",
            str(save_dir),
        ],
        ROOT,
        LOG_ROOT / "anomalyclip_eval_visa_full4.log",
        env,
    )


def run_adaclip_last(device_id: str, env: dict[str, str]) -> None:
    train_root = OUT_ROOT / "adaclip_visa_clinicdb_last_ckpt"
    ckpt_path = None
    try:
        ckpt_path = latest_checkpoint(train_root)
        print(f"[skip] existing AdaCLIP checkpoint {ckpt_path}", flush=True)
    except FileNotFoundError:
        train_env = dict(env)
        train_env["CUDA_VISIBLE_DEVICES"] = device_id
        train_env["ADACLIP_VISA_ROOT"] = str(VISA_1CLS)
        train_env["ADACLIP_CLINICDB_ROOT"] = str(CLINICDB_ROOT)
        train_env["ADACLIP_COLONDB_ROOT"] = str(COLONDB_ROOT)
        train_env["ADACLIP_MVTEC_ROOT"] = str(MVTEC_ROOT)
        run(
            [
                str(PY),
                "-u",
                "train.py",
                "--save_fig",
                "False",
                "--training_data",
                "visa",
                "clinicdb",
                "--testing_data",
                "mvtec",
                "--save_path",
                str(train_root),
                "--model",
                "ViT-L-14-336",
                "--layer_recipe",
                "last",
                "--target_val_during_train",
                "False",
                "--save_last_ckpt",
                "True",
                "--epoch",
                "5",
                "--batch_size",
                "1",
                "--image_size",
                "518",
                "--prompting_depth",
                "4",
                "--prompting_length",
                "5",
                "--prompting_branch",
                "VL",
                "--prompting_type",
                "SD",
                "--use_hsf",
                "True",
                "--k_clusters",
                "20",
            ],
            ROOT / "neurips2026/AdaCLIP",
            LOG_ROOT / "adaclip_train_visa_clinicdb_last.log",
            train_env,
        )
        ckpt_path = latest_checkpoint(train_root)

    save_dir = OUT_ROOT / "adaclip_visa_clinicdb_last_eval"
    if (save_dir / "summary.json").exists():
        print(f"[skip] existing {save_dir / 'summary.json'}", flush=True)
        return
    eval_env = dict(env)
    eval_env["ADACLIP_VISA_ROOT"] = str(VISA_1CLS)
    eval_env["ADACLIP_CLINICDB_ROOT"] = str(CLINICDB_ROOT)
    eval_env["ADACLIP_MVTEC_ROOT"] = str(MVTEC_ROOT)
    run(
        [
            str(PY),
            "-u",
            str(ROOT / "neurips2026/scripts/official_parallel_test_adaclip.py"),
            "--source_root",
            str(VISA_1CLS),
            "--source_dataset",
            "visa",
            "--target_root",
            str(MVTEC_ROOT),
            "--target_dataset",
            "mvtec",
            "--checkpoint_path",
            str(ckpt_path),
            "--save_dir",
            str(save_dir),
            "--bank_cache_path",
            str(OUT_ROOT / "bank_cache/adaclip_visa_clinicdb_last_retrained.pt"),
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--batch_size",
            "1",
            "--num_workers",
            "4",
            "--cpu_threads",
            "4",
            "--backbone",
            "ViT-L-14-336",
            "--checkpoint_load_mode",
            "strict",
            "--model_layer_recipe",
            "last",
            "--layer_recipe",
            "all4",
            "--enable_calibrator",
            "--calib_epochs",
            "30",
            "--calib_subspace_rank",
            "8",
            "--calib_insertion_mode",
            "prescore_rectify",
            "--calib_train_score_space",
            "cache_prob",
            "--calib_lambda",
            "0.3",
            "--calib_eta_max",
            "1.0",
            "--scoring_mode",
            "logit_gate_posneg",
            "--ours_image_score_mode",
            "official_plus_map_topk",
            "--eval_metrics",
            "I-AUROC",
            "I-AP",
            "P-AUROC",
            "P-AP",
            "P-AUPRO",
            "--aupro_max_step",
            "200",
        ],
        ROOT,
        LOG_ROOT / "adaclip_eval_visa_clinicdb_last.log",
        eval_env,
    )


def main() -> int:
    device_id = sys.argv[1] if len(sys.argv) > 1 else "0"
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    (OUT_ROOT / "bank_cache").mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-layer-retrained-stress")

    run_anomalyclip_full4(device_id, env)
    run_adaclip_last(device_id, env)
    print("[done] retrained layer-recipe stress ablation queue", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
