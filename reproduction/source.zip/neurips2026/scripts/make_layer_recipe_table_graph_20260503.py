#!/usr/bin/env python3
from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

ADACLIP_ROOT = RESULTS / "layer_recipe_retrained_all_20260502"
FAPROMPT_ROOT = RESULTS / "faprompt_layer_recipe_retrained_20260502"
ANOMALY_M2V_ROOT = RESULTS / "layer_recipe_retrained_mvtec2visa_20260503"
ANOMALY_FALLBACK_ROOT = RESULTS / "anomalyclip_btc_corrected_fulltable_20260503"

MODE_ALIASES = {
    "B": ("baseline_txt", "baseline", "baseline_official", "baseline_maptopk"),
    "T": ("parallel_margin", "ted_parallel", "support_only_alpha_1", "support_only_alpha_1.0"),
    "C": ("ted_calibrated", "branch_calibrated_alpha_1", "branch_calibrated_alpha_1.0"),
}

ADACLIP_RECIPES = [
    ("Full(B)", "all4_official"),
    ("EL-r", "earlylate"),
    ("M2-r", "mid2"),
    ("L2-r", "last2"),
    ("L-r", "last"),
]

FAPROMPT_RECIPES = [
    ("Full(B)", "all4_official"),
    ("EL-r", "earlylate"),
    ("M2-r", "mid2"),
    ("L2-r", "last2"),
    ("L-r", "last"),
    ("F-r", "all4"),
]


def load(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(value) -> float | None:
    if value is None:
        return None
    value = float(value)
    if math.isnan(value):
        return None
    return value * 100.0 if abs(value) <= 1.5 else value


def row_vals(row: dict | None) -> tuple[float | None, float | None, float | None, float | None] | None:
    if not isinstance(row, dict):
        return None
    return (
        pct(row.get("image_auroc", row.get("image_auc"))),
        pct(row.get("pixel_auroc", row.get("pixel_auc"))),
        pct(row.get("pixel_aupro", row.get("pixel_pro"))),
        pct(row.get("pixel_ap")),
    )


def mean_row(summary: dict | None, key: str) -> tuple[float | None, float | None, float | None, float | None] | None:
    if summary is None:
        return None
    aliases = MODE_ALIASES[key]
    rows = summary.get("rows", [])
    if isinstance(rows, list):
        for alias in aliases:
            for row in rows:
                if row.get("target_label") == "mean" and row.get("mode") == alias:
                    return row_vals(row)
    mean = summary.get("mean", {})
    if isinstance(mean, dict):
        for alias in aliases:
            if alias in mean:
                return row_vals(mean[alias])
        parallel = mean.get("parallel")
        if isinstance(parallel, dict):
            for alias in aliases:
                if alias in parallel:
                    return row_vals(parallel[alias])
    return None


def collect(path: Path) -> tuple[
    tuple[float | None, float | None, float | None, float | None] | None,
    tuple[float | None, float | None, float | None, float | None] | None,
    tuple[float | None, float | None, float | None, float | None] | None,
]:
    summary = load(path / "summary.json")
    return tuple(mean_row(summary, key) for key in ("B", "T", "C"))  # type: ignore[return-value]


def fmt_full(vals: tuple[float | None, float | None, float | None, float | None] | None) -> str:
    if vals is None or any(v is None for v in vals):
        return "--.-- / --.-- / --.-- / --.--"
    return " / ".join(f"{v:.2f}" for v in vals if v is not None)


def fmt_pix(vals: tuple[float | None, float | None, float | None, float | None] | None) -> str:
    if vals is None or any(v is None for v in vals[1:]):
        return "--.-- / --.-- / --.--"
    return f"{vals[1]:.2f} / {vals[2]:.2f} / {vals[3]:.2f}"


def delta_text(base, ours) -> str:
    if base is None or ours is None or any(v is None for v in base[2:4] + ours[2:4]):
        return "--.-- / --.--"
    return f"{ours[2] - base[2]:+.2f} / {ours[3] - base[3]:+.2f}"


def best_bold(cells):
    parsed = [None if cell is None or any(v is None for v in cell) else cell for cell in cells]
    best = []
    for idx in range(4):
        vals = [cell[idx] for cell in parsed if cell is not None]
        best.append(max(vals) if vals else None)
    out = []
    for cell in parsed:
        if cell is None:
            out.append("--.-- / --.-- / --.-- / --.--")
            continue
        parts = []
        for idx, value in enumerate(cell):
            text = f"{value:.2f}"
            if best[idx] is not None and abs(value - best[idx]) < 1e-9:
                text = rf"\textbf{{{text}}}"
            parts.append(text)
        out.append(" / ".join(parts))
    return out


def table_rows():
    rows = []
    for label, adaclip_key in ADACLIP_RECIPES:
        if adaclip_key == "all4_official":
            ad_path = ADACLIP_ROOT / "adaclip_visa_all4_baseline_eval"
        else:
            ad_path = ADACLIP_ROOT / f"adaclip_visa_{adaclip_key}_eval"
        rows.append(("AdaCLIP", label, *collect(ad_path)))

    for label, fap_key in FAPROMPT_RECIPES:
        if fap_key == "all4_official":
            fap_path = FAPROMPT_ROOT / "faprompt_visa_all4_official_eval"
        elif fap_key == "all4":
            fap_path = FAPROMPT_ROOT / "faprompt_visa_all4_eval"
        else:
            fap_path = FAPROMPT_ROOT / f"faprompt_visa_{fap_key}_eval"
        rows.append(("FAPrompt", label, *collect(fap_path)))
    return rows


def write_full_table(rows) -> Path:
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{",
        r"Layer-recipe retraining comparison on VisA$\rightarrow$MVTec for AdaCLIP and FAPrompt.",
        r"Each cell reports I-AUC / P-AUC / PRO / AP.",
        r"B, T, and C denote the host baseline, train-free TED, and source-calibrated TED, respectively.",
        r"Full(B) denotes the original official full-layer baseline recipe.",
        r"EL-r, M2-r, L2-r, L-r, and F-r denote checkpoints retrained with early+last, middle-2, last-2, last-layer, and full-layer recipes, respectively.",
        r"Rows with --.-- are reserved for retraining jobs not yet completed.",
        r"}",
        r"\label{tab:layer_recipe_retrain_adaclip_faprompt}",
        r"\small",
        r"\setlength{\tabcolsep}{2.6pt}",
        r"\renewcommand{\arraystretch}{1.04}",
        r"\resizebox{\textwidth}{!}{",
        r"\begin{tabular}{ll|c|c|c}",
        r"\toprule",
        r"Host & Recipe & B & T & C \\",
        r"\midrule",
    ]
    current = None
    host_counts = {}
    for host, *_ in rows:
        host_counts[host] = host_counts.get(host, 0) + 1
    seen = {}
    for host, recipe, b, t, c in rows:
        if current is not None and host != current:
            lines.append(r"\midrule")
        current = host
        seen[host] = seen.get(host, 0) + 1
        prefix = rf"\multirow{{{host_counts[host]}}}{{*}}{{{host}}}" if seen[host] == 1 else ""
        bb, tt, cc = best_bold((b, t, c))
        lines.append(f"{prefix} & {recipe} & {bb} & {tt} & {cc} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"}", r"\end{table*}", ""]
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "layer_recipe_retrain_adaclip_faprompt_20260503.tex"
    path.write_text("\n".join(lines))
    return path


def write_compact_panel(rows) -> Path:
    lines = [
        r"\begin{tabular}{llccc}",
        r"\toprule",
        r"Host & Recipe & B & C & $\Delta$PRO/AP \\",
        r"\midrule",
    ]
    current = None
    host_counts = {}
    compact_rows = [(host, recipe, b, c) for host, recipe, b, _, c in rows if host in {"AdaCLIP", "FAPrompt"}]
    for host, *_ in compact_rows:
        host_counts[host] = host_counts.get(host, 0) + 1
    seen = {}
    for host, recipe, b, c in compact_rows:
        if current is not None and host != current:
            lines.append(r"\midrule")
        current = host
        seen[host] = seen.get(host, 0) + 1
        prefix = rf"\multirow{{{host_counts[host]}}}{{*}}{{{host}}}" if seen[host] == 1 else ""
        lines.append(f"{prefix} & {recipe} & {fmt_pix(b)} & {fmt_pix(c)} & {delta_text(b, c)} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", ""]
    path = OUT / "layer_recipe_retrain_panel_a_table_20260503.tex"
    path.write_text("\n".join(lines))
    return path


def average_cells(paths: list[Path]):
    vals = []
    for path in paths:
        b, t, c = collect(path)
        vals.append((b, t, c))
    out = []
    for idx in range(3):
        cells = [v[idx] for v in vals if v[idx] is not None and not any(x is None for x in v[idx])]
        if not cells:
            out.append(None)
            continue
        out.append(tuple(sum(cell[j] for cell in cells) / len(cells) for j in range(4)))
    return tuple(out)


def anomaly_recipe_cells():
    recipes = [
        ("Full(B)", ANOMALY_M2V_ROOT / "anomalyclip_mvtec_all4_official_eval"),
        ("EL-r", ANOMALY_M2V_ROOT / "anomalyclip_mvtec_earlylate_eval"),
        ("M2-r", ANOMALY_M2V_ROOT / "anomalyclip_mvtec_mid2_eval"),
        ("L2-r", ANOMALY_M2V_ROOT / "anomalyclip_mvtec_last2_eval"),
        ("L-r", ANOMALY_M2V_ROOT / "anomalyclip_mvtec_last_eval"),
        ("F-r", ANOMALY_M2V_ROOT / "anomalyclip_mvtec_all4_eval"),
    ]
    cells = [(label, *collect(path)) for label, path in recipes if (path / "summary.json").exists()]
    if cells:
        return cells, False
    fallback = sorted(ANOMALY_FALLBACK_ROOT.glob("vitl336_mvtec2visa_seed*/"))
    if fallback:
        b, t, c = average_cells(fallback)
        return [("Last(B)", b, t, c)], True
    return [], True


def make_anomaly_plot() -> Path:
    cells, fallback = anomaly_recipe_cells()
    FIG.mkdir(parents=True, exist_ok=True)
    pdf = FIG / "anomalyclip_mvtec2visa_layer_retrain_curve_20260503.pdf"
    png = FIG / "anomalyclip_mvtec2visa_layer_retrain_curve_20260503.png"

    fig, ax = plt.subplots(figsize=(3.25, 2.05))
    labels = [row[0] for row in cells]
    x = list(range(len(labels)))
    modes = [("B", "#6b7280", "o"), ("T", "#2563eb", "s"), ("C", "#b45309", "^")]
    for mode_idx, (mode, color, marker) in enumerate(modes, start=1):
        y = []
        for row in cells:
            vals = row[mode_idx]
            y.append(float("nan") if vals is None or vals[2] is None else vals[2])
        if x:
            ax.plot(x, y, marker=marker, lw=1.5, ms=3.6, color=color, label=mode)

    ax.set_ylabel("P-PRO", fontsize=8)
    ax.set_title("AnomalyCLIP MVTec$\\rightarrow$VisA", fontsize=9, pad=2)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=25, ha="right", fontsize=8)
    ax.tick_params(axis="y", labelsize=8)
    ax.grid(axis="y", alpha=0.25, linewidth=0.6)
    ax.legend(frameon=False, ncol=3, fontsize=7, loc="upper left", handlelength=1.5, columnspacing=0.8)
    if not cells:
        ax.text(0.5, 0.5, "MVTec$\\rightarrow$VisA layer-retrain\nresults pending", ha="center", va="center", transform=ax.transAxes)
        ax.set_xticks([])
    elif fallback:
        ax.text(
            0.98,
            0.05,
            "layer-retrain queued;\nofficial Last(B) shown",
            ha="right",
            va="bottom",
            fontsize=6.5,
            transform=ax.transAxes,
            color="#4b5563",
        )
    fig.tight_layout(pad=0.3)
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return pdf


def write_combined_tex() -> Path:
    lines = [
        r"\begin{figure*}[t]",
        r"\centering",
        r"\begin{minipage}[t]{0.57\textwidth}",
        r"\centering",
        r"\textbf{(a) Layer-recipe retraining on VisA$\rightarrow$MVTec}",
        r"\vspace{2pt}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.4pt}",
        r"\renewcommand{\arraystretch}{1.02}",
        r"\resizebox{\linewidth}{!}{",
        r"\input{neurips2026/results/final_metric_and_novelty_tables/layer_recipe_retrain_panel_a_table_20260503}",
        r"}",
        r"\end{minipage}",
        r"\hfill",
        r"\begin{minipage}[t]{0.40\textwidth}",
        r"\centering",
        r"\textbf{(b) AnomalyCLIP layer-recipe sweep}",
        r"\vspace{2pt}",
        r"\includegraphics[width=\linewidth]{figure/anomalyclip_mvtec2visa_layer_retrain_curve_20260503.pdf}",
        r"\end{minipage}",
        r"\caption{",
        r"Layer-recipe retraining stress and TED recovery.",
        r"(a) reports compact pixel metrics P-AUC / PRO / AP for AdaCLIP and FAPrompt, with $\Delta$PRO/AP computed from C-TED minus the host baseline.",
        r"(b) tracks AnomalyCLIP on MVTec$\rightarrow$VisA separately because its official baseline uses a different layer recipe from the multi-layer hosts.",
        r"}",
        r"\label{fig:layer_recipe_retrain_ted}",
        r"\end{figure*}",
        "",
    ]
    path = OUT / "layer_recipe_retrain_table_graph_20260503.tex"
    path.write_text("\n".join(lines))
    return path


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    rows = table_rows()
    full = write_full_table(rows)
    compact = write_compact_panel(rows)
    fig = make_anomaly_plot()
    tex = write_combined_tex()
    print({"full_table": str(full), "panel_table": str(compact), "figure": str(fig), "tex": str(tex)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
