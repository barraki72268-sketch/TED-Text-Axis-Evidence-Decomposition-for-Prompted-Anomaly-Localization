from __future__ import annotations

import argparse
import json
from pathlib import Path

from official_parallel_test_adaclip import build_model, get_or_collect_source_patch_banks


def main():
    parser = argparse.ArgumentParser("Collect AdaCLIP source banks only")
    parser.add_argument("--source_root", type=str, required=True)
    parser.add_argument("--source_dataset", type=str, required=True)
    parser.add_argument("--checkpoint_path", type=str, required=True)
    parser.add_argument("--save_path", type=str, required=True)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--prompting_depth", type=int, default=4)
    parser.add_argument("--prompting_length", type=int, default=5)
    parser.add_argument("--prompting_branch", type=str, default="VL")
    parser.add_argument("--prompting_type", type=str, default="SD")
    parser.add_argument("--use_hsf", type=lambda x: x.lower() in {"1", "true", "yes"}, default=True)
    parser.add_argument("--k_clusters", type=int, default=20)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--source_exclude_class", type=str, default=None)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=200)
    parser.add_argument("--max_defect_per_class", type=int, default=80)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    args = parser.parse_args()

    if args.source_exclude_class is not None and args.source_exclude_class.lower() in {"", "none", "null", "all"}:
        args.source_exclude_class = None

    model = build_model(
        device=args.device,
        checkpoint_path=args.checkpoint_path,
        image_size=args.image_size,
        prompting_depth=args.prompting_depth,
        prompting_length=args.prompting_length,
        prompting_branch=args.prompting_branch,
        prompting_type=args.prompting_type,
        use_hsf=args.use_hsf,
        k_clusters=args.k_clusters,
    )

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        source_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        source_exclude_class=args.source_exclude_class,
        hard_frac=args.hard_frac,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        sigma=args.sigma,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.save_path,
        refresh_bank_cache=args.refresh_bank_cache,
    )

    print(
        json.dumps(
            {
                "bank_cache_path": str(bank_cache_path),
                "bank_cache_meta": bank_cache_meta,
                "bank_stats": bank_stats,
                "num_layers": len(fp_banks),
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
