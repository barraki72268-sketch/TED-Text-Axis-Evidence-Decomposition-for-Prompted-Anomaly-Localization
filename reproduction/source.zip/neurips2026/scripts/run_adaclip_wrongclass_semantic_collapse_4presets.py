from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026" / "scripts" / "probe_adaclip_wrongclass_semantic_collapse.py"
RESULT_ROOT = ROOT / "neurips2026" / "results"
PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]


def run_preset(max_per_class: int, gpu_ordinal: int, cpu_threads: int, run_tag: str, preset: str, status_file: Path) -> None:
    save_dir = RESULT_ROOT / f"adaclip_wrongclass_semantic_collapse_{preset}_x{max_per_class}_{run_tag}"
    log_file = Path("/tmp") / f"{save_dir.name}.log"
    env = os.environ.copy()
    env["OMP_NUM_THREADS"] = str(cpu_threads)
    env["OPENBLAS_NUM_THREADS"] = str(cpu_threads)
    env["MKL_NUM_THREADS"] = str(cpu_threads)
    env["NUMEXPR_NUM_THREADS"] = str(cpu_threads)

    cmd = [
        str(PYTHON),
        "-u",
        str(SCRIPT),
        "--preset",
        preset,
        "--max_anomaly_images_per_class",
        str(max_per_class),
        "--progress_every",
        "1",
        "--cpu_threads",
        str(cpu_threads),
        "--device",
        f"cuda:{gpu_ordinal}",
        "--save_dir",
        str(save_dir),
    ]

    print("=" * 60, flush=True)
    print(f"preset={preset}", flush=True)
    print(f"save_dir={save_dir}", flush=True)
    print(f"log_file={log_file}", flush=True)
    print("=" * 60, flush=True)

    with open(log_file, "w") as log_fp:
        proc = subprocess.run(cmd, stdout=log_fp, stderr=subprocess.STDOUT, env=env)

    status = "OK" if proc.returncode == 0 else "FAIL"
    with open(status_file, "a") as f:
        f.write(f"{preset} {status} {save_dir}\n")
    print(f"{preset} {status}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser("Sequential AdaCLIP wrong-class audit runner")
    parser.add_argument("--max_per_class", type=int, default=1)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--cpu_threads", type=int, default=1)
    parser.add_argument("--run_tag", type=str, required=True)
    args = parser.parse_args()

    status_file = RESULT_ROOT / f"adaclip_wrongclass_semantic_collapse_run_{args.run_tag}.status"
    status_file.write_text("")
    for preset in PRESETS:
        run_preset(args.max_per_class, args.gpu, args.cpu_threads, args.run_tag, preset, status_file)


if __name__ == "__main__":
    main()
