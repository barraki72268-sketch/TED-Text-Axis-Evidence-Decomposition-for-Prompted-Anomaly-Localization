from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import RiemannianLowRankRefiner
from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--l6_ckpt", type=str, required=True)
    parser.add_argument("--l12_ckpt", type=str, required=True)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=1)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--top_percent", type=float, default=5.0)
    parser.add_argument("--output_tag", type=str, default="backbone_l6_l12_anchor_tp_fp")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(backbone, batch_np) -> torch.Tensor:
    imgs = [backbone.transform_pil(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(backbone.device)


def load_refiner(ckpt_path: str, device: torch.device) -> tuple[RiemannianLowRankRefiner, dict]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload["refiner_config"]
    refiner = RiemannianLowRankRefiner(
        feature_dim=int(config["feature_dim"]),
        kernel_size=int(config["kernel_size"]),
        topk_ratio=float(config["topk_ratio"]),
        rank=int(config["rank"]),
        hidden_dim=int(config["hidden_dim"]),
        dropout=float(config["dropout"]),
        lambda_max=float(config.get("lambda_max", 2.0)),
    ).to(device)
    refiner.load_state_dict(payload["model_state_dict"], strict=True)
    refiner.eval()
    return refiner, config


@torch.no_grad()
def build_layer_prototype(backbone, loader, target_layer: int, refiner: RiemannianLowRankRefiner, num_steps: int) -> torch.Tensor:
    feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        images = _preprocess_batch(backbone, data)
        tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        out = refiner(tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps)
        feats.append(F.normalize(out.refined[normal_idx].float(), dim=-1))
    if not feats:
        raise RuntimeError(f"No normal train features found for prototype L{target_layer}.")
    proto = torch.cat(feats, dim=0).mean(dim=0, keepdim=True)
    return F.normalize(proto, dim=-1)


def _safe_auc(labels: np.ndarray, scores: np.ndarray) -> float:
    if labels.size == 0 or labels.min() == labels.max():
        return float("nan")
    return float(roc_auc_score(labels.astype(np.uint8), scores.astype(np.float64)))


def _kl_divergence(tp_values: np.ndarray, fp_values: np.ndarray, bins: int = 32) -> float:
    if tp_values.size == 0 or fp_values.size == 0:
        return float("nan")
    lo = float(min(tp_values.min(), fp_values.min()))
    hi = float(max(tp_values.max(), fp_values.max()))
    if hi <= lo:
        return 0.0
    tp_hist, edges = np.histogram(tp_values, bins=bins, range=(lo, hi), density=True)
    fp_hist, _ = np.histogram(fp_values, bins=edges, density=True)
    eps = 1e-8
    tp_hist = tp_hist + eps
    fp_hist = fp_hist + eps
    tp_hist = tp_hist / tp_hist.sum()
    fp_hist = fp_hist / fp_hist.sum()
    return float(np.sum(tp_hist * np.log(tp_hist / fp_hist)))


@torch.no_grad()
def evaluate_tp_fp_anchor(
    backbone,
    loader,
    l6_refiner: RiemannianLowRankRefiner,
    l12_refiner: RiemannianLowRankRefiner,
    l6_proto: torch.Tensor,
    l12_proto: torch.Tensor,
    l6_steps: int,
    l12_steps: int,
    top_percent: float,
) -> dict[str, float]:
    tp_a12_values: list[np.ndarray] = []
    fp_a12_values: list[np.ndarray] = []
    tp_l6_values: list[np.ndarray] = []
    fp_l6_values: list[np.ndarray] = []
    total_selected = 0
    total_tp = 0
    total_fp = 0

    for data, mask, _label, _name, _img_type in loader:
        images = _preprocess_batch(backbone, data)
        token_dict = backbone.extract_layer_patch_tokens(images, target_layers=[6, 12])

        l6_out = l6_refiner(token_dict[6], semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=l6_steps)
        l12_out = l12_refiner(token_dict[12], semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=l12_steps)

        l6_tokens = F.normalize(l6_out.refined.float(), dim=-1)
        l12_tokens = F.normalize(l12_out.refined.float(), dim=-1)
        l6_proto_batch = l6_proto.to(l6_tokens.device, dtype=l6_tokens.dtype).expand(l6_tokens.shape[0], -1, -1)
        l12_proto_batch = l12_proto.to(l12_tokens.device, dtype=l12_tokens.dtype).expand(l12_tokens.shape[0], -1, -1)

        l6_score = 1.0 - F.cosine_similarity(l6_tokens, l6_proto_batch, dim=-1)   # [B, N]
        a12 = 1.0 - F.cosine_similarity(l12_tokens, l12_proto_batch, dim=-1)      # [B, N]

        mask_tensor = mask.float()
        if mask_tensor.ndim == 3:
            mask_tensor = mask_tensor.unsqueeze(1)
        patch_mask = F.interpolate(mask_tensor, size=backbone.grid_size, mode="nearest")[:, 0].reshape(l6_score.shape[0], -1) > 0.5
        flat_score = l6_score.reshape(l6_score.shape[0], -1)
        flat_a12 = a12.reshape(a12.shape[0], -1)

        for b in range(flat_score.shape[0]):
            scores_b = flat_score[b]
            a12_b = flat_a12[b]
            gt_b = patch_mask[b]
            k = max(1, int(np.ceil(scores_b.numel() * top_percent / 100.0)))
            top_idx = torch.topk(scores_b, k=k, largest=True).indices
            top_idx_cpu = top_idx.detach().cpu()
            sel_a12 = a12_b[top_idx].detach().cpu().numpy()
            sel_l6 = scores_b[top_idx].detach().cpu().numpy()
            sel_gt = gt_b[top_idx_cpu].detach().cpu().numpy().astype(bool)

            tp_mask = sel_gt
            fp_mask = ~sel_gt
            total_selected += int(sel_gt.size)
            total_tp += int(tp_mask.sum())
            total_fp += int(fp_mask.sum())
            if tp_mask.any():
                tp_a12_values.append(sel_a12[tp_mask])
                tp_l6_values.append(sel_l6[tp_mask])
            if fp_mask.any():
                fp_a12_values.append(sel_a12[fp_mask])
                fp_l6_values.append(sel_l6[fp_mask])

    tp_a12 = np.concatenate(tp_a12_values) if tp_a12_values else np.empty((0,), dtype=np.float32)
    fp_a12 = np.concatenate(fp_a12_values) if fp_a12_values else np.empty((0,), dtype=np.float32)
    tp_l6 = np.concatenate(tp_l6_values) if tp_l6_values else np.empty((0,), dtype=np.float32)
    fp_l6 = np.concatenate(fp_l6_values) if fp_l6_values else np.empty((0,), dtype=np.float32)

    if tp_a12.size and fp_a12.size:
        labels = np.concatenate([np.ones_like(tp_a12), np.zeros_like(fp_a12)])
        a12_scores = np.concatenate([tp_a12, fp_a12])
    else:
        labels = np.empty((0,), dtype=np.uint8)
        a12_scores = np.empty((0,), dtype=np.float32)

    return {
        "top_percent": float(top_percent),
        "selected_patch_count": int(total_selected),
        "tp_count": int(total_tp),
        "fp_count": int(total_fp),
        "tp_ratio": float(total_tp / max(total_selected, 1)),
        "fp_ratio": float(total_fp / max(total_selected, 1)),
        "a12_tp_mean": float(tp_a12.mean()) if tp_a12.size else float("nan"),
        "a12_fp_mean": float(fp_a12.mean()) if fp_a12.size else float("nan"),
        "a12_mean_gap_tp_minus_fp": float(tp_a12.mean() - fp_a12.mean()) if tp_a12.size and fp_a12.size else float("nan"),
        "a12_tp_std": float(tp_a12.std()) if tp_a12.size else float("nan"),
        "a12_fp_std": float(fp_a12.std()) if fp_a12.size else float("nan"),
        "a12_auc_tp_vs_fp": _safe_auc(labels, a12_scores),
        "a12_kl_tp_vs_fp": _kl_divergence(tp_a12, fp_a12),
        "l6_tp_mean": float(tp_l6.mean()) if tp_l6.size else float("nan"),
        "l6_fp_mean": float(fp_l6.mean()) if fp_l6.size else float("nan"),
    }


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu")

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    l6_refiner, l6_config = load_refiner(args.l6_ckpt, device)
    l12_refiner, l12_config = load_refiner(args.l12_ckpt, device)
    l6_steps = int(l6_config.get("num_steps", 2))
    l12_steps = int(l12_config.get("num_steps", 2))

    rows = []
    details = {}
    for class_name in args.class_names:
        train_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "train", args.batch_size)
        test_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)

        l6_proto = build_layer_prototype(backbone, train_loader, 6, l6_refiner, l6_steps)
        l12_proto = build_layer_prototype(backbone, train_loader, 12, l12_refiner, l12_steps)

        result = evaluate_tp_fp_anchor(
            backbone=backbone,
            loader=test_loader,
            l6_refiner=l6_refiner,
            l12_refiner=l12_refiner,
            l6_proto=l6_proto,
            l12_proto=l12_proto,
            l6_steps=l6_steps,
            l12_steps=l12_steps,
            top_percent=args.top_percent,
        )
        row = {"class_name": class_name, **result}
        rows.append(row)
        details[class_name] = row
        print(
            f"{class_name} | tp={row['tp_count']} fp={row['fp_count']} "
            f"a12_tp={row['a12_tp_mean']:.4f} a12_fp={row['a12_fp_mean']:.4f} "
            f"gap={row['a12_mean_gap_tp_minus_fp']:.4f} auc={row['a12_auc_tp_vs_fp']:.4f}",
            flush=True,
        )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(details, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
