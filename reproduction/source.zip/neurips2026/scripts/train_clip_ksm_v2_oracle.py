from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
    build_text_workspace,
    encode_text_features,
    reconstruct_optimal_text_axis,
)
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("KSM v2 oracle fit on frozen CLIP.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--class_specs",
        nargs="+",
        default=["fryum:6:9", "capsules:12:9"],
        help="Entries: class_name:train_layer:transfer_layer",
    )
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240", "ViT-L-14:laion400m_e32:224"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--use_channel_gate", action="store_true")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--train_normal_images", type=int, default=12)
    parser.add_argument("--train_anomaly_images", type=int, default=12)
    parser.add_argument("--eval_normal_images", type=int, default=12)
    parser.add_argument("--eval_anomaly_images", type=int, default=12)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--lambda_n", type=float, default=1.0)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_ksm_v2_oracle")
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


@dataclass
class Record:
    image_t: torch.Tensor
    patch_mask: np.ndarray
    label: int
    name: str


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int]) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .numpy()
        .astype(np.int64)
    )


def collect_oracle_records(backbone, class_name: str, args: argparse.Namespace) -> tuple[list[Record], list[Record]]:
    train_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "train")
    test_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")

    train_norm_idx = list(range(min(args.train_normal_images, len(train_ds.records))))
    test_norm_idx = [i for i, rec in enumerate(test_ds.records) if rec["label"] == "normal"][: args.eval_normal_images]
    test_anom_all = [i for i, rec in enumerate(test_ds.records) if rec["label"] != "normal"]
    train_anom_idx = test_anom_all[: args.train_anomaly_images]
    eval_anom_idx = test_anom_all[args.train_anomaly_images : args.train_anomaly_images + args.eval_anomaly_images]

    def make_record(ds, idx: int) -> Record:
        image_np, mask_np, label, name, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).cpu()
        return Record(
            image_t=image_t,
            patch_mask=to_patch_mask(mask_np, backbone.grid_size),
            label=int(label != 0),
            name=name,
        )

    train_records = [make_record(train_ds, i) for i in train_norm_idx] + [make_record(test_ds, i) for i in train_anom_idx]
    eval_records = [make_record(test_ds, i) for i in test_norm_idx] + [make_record(test_ds, i) for i in eval_anom_idx]
    return train_records, eval_records


def choose_text_rank(delta_p: torch.Tensor, threshold: float) -> int:
    _, s, _ = torch.linalg.svd(delta_p, full_matrices=False)
    energy = s.pow(2)
    if energy.numel() == 0:
        return 1
    frac = torch.cumsum(energy, dim=0) / energy.sum().clamp_min(1e-8)
    k = int(torch.searchsorted(frac, torch.tensor([threshold], device=frac.device)).item() + 1)
    return max(1, min(k, int(delta_p.shape[0])))


def prepare_text_subspace(prompt_features: torch.Tensor, p_norm: torch.Tensor, k: int) -> torch.Tensor:
    delta_p = prompt_features - p_norm.unsqueeze(0)
    delta_p = delta_p - delta_p.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(delta_p, full_matrices=False)
    basis = vh[:k].contiguous()
    return l2_normalize(basis, dim=-1)


class KinematicSteeringModuleV2(nn.Module):
    def __init__(self, dim: int, U_basis: torch.Tensor, p_norm: torch.Tensor, use_channel_gate: bool = False):
        super().__init__()
        self.dim = int(dim)
        self.k = int(U_basis.shape[0])
        self.use_channel_gate = bool(use_channel_gate)
        self.W_q = nn.Linear(3 * self.dim, self.dim, bias=False)
        nn.init.xavier_uniform_(self.W_q.weight, gain=0.25)

        self.register_buffer("U_basis", l2_normalize(U_basis.detach().float(), dim=-1))
        self.register_buffer("p_norm", l2_normalize(p_norm.detach().float(), dim=0))
        if self.use_channel_gate:
            self.gamma = nn.Parameter(torch.zeros(1, 1, self.dim, dtype=torch.float32))
        else:
            self.gamma = nn.Parameter(torch.zeros(1, dtype=torch.float32))

    def forward(self, v_in: torch.Tensor) -> torch.Tensor:
        bsz, n, dim = v_in.shape
        assert dim == self.dim
        v_in = v_in.float()
        v_bar = v_in.mean(dim=1, keepdim=True)
        v_res = v_in - v_bar
        q_concat = torch.cat([v_in, v_bar.expand(-1, n, -1), v_res], dim=-1)
        q = self.W_q(q_concat)
        logits = torch.matmul(q, self.U_basis.T) / math.sqrt(self.dim)
        a = torch.tanh(logits)
        delta_v = torch.matmul(a, self.U_basis)
        delta_v_proj = delta_v - (delta_v * self.p_norm.view(1, 1, -1)).sum(dim=-1, keepdim=True) * self.p_norm.view(1, 1, -1)
        return v_in + self.gamma * delta_v_proj

    def gamma_abs_mean(self) -> torch.Tensor:
        return self.gamma.abs().mean()


def forward_up_to_layer(backbone, image_t: torch.Tensor, layer_idx: int) -> torch.Tensor:
    seq = backbone.prepare_sequence(image_t)
    return backbone.run_blocks(seq, start_layer=1, end_layer=layer_idx)


def forward_remaining(backbone, sequence: torch.Tensor, start_layer: int) -> torch.Tensor:
    if start_layer < backbone.num_layers:
        sequence = backbone.run_blocks(sequence, start_layer=start_layer + 1, end_layer=backbone.num_layers)
    final = sequence.permute(1, 0, 2)
    return backbone.visual.ln_post(final)[:, 1:, :].float()


def patchify_sequence(seq: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    seq_b = seq.permute(1, 0, 2)
    return seq_b[:, :1, :], seq_b[:, 1:, :]


def rebuild_sequence(cls_tok: torch.Tensor, patches: torch.Tensor) -> torch.Tensor:
    return torch.cat([cls_tok, patches], dim=1).permute(1, 0, 2)


def compute_ksm_loss(v_in: torch.Tensor, v_out: torch.Tensor, p_norm: torch.Tensor, prompt_features: torch.Tensor, mask: torch.Tensor, lambda_n: float = 1.0) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    p_norm = l2_normalize(p_norm, dim=0)
    prompt_features = l2_normalize(prompt_features, dim=-1)
    r_out = v_out - (v_out * p_norm.view(1, 1, -1)).sum(dim=-1, keepdim=True) * p_norm.view(1, 1, -1)
    r_out = l2_normalize(r_out, dim=-1)

    pos = mask > 0
    neg = mask <= 0

    if int(pos.sum().item()) == 0:
        l_anom = torch.zeros([], device=v_out.device)
    else:
        S = torch.matmul(r_out[pos], prompt_features.T)
        j_star = torch.argmax(S.mean(dim=0))
        l_anom = 1.0 - S[:, j_star].mean()

    if int(neg.sum().item()) == 0:
        l_norm = torch.zeros([], device=v_out.device)
    else:
        l_norm = F.mse_loss(v_out[neg], v_in[neg])

    total = l_anom + float(lambda_n) * l_norm
    return total, l_anom, l_norm


def score_reconstructed_axis(v_final: torch.Tensor, p_norm: torch.Tensor, delta_p_recon: torch.Tensor) -> np.ndarray:
    residual = v_final - (v_final * p_norm.view(1, -1)).sum(dim=-1, keepdim=True) * p_norm.view(1, -1)
    residual = l2_normalize(residual, dim=-1)
    return torch.matmul(residual, l2_normalize(delta_p_recon, dim=0)).detach().cpu().numpy()


def score_promptmax(v_final: torch.Tensor, p_norm: torch.Tensor, prompt_features: torch.Tensor) -> np.ndarray:
    residual = v_final - (v_final * p_norm.view(1, -1)).sum(dim=-1, keepdim=True) * p_norm.view(1, -1)
    residual = l2_normalize(residual, dim=-1)
    prompt_features = l2_normalize(prompt_features, dim=-1)
    all_scores = torch.matmul(residual, prompt_features.T)
    return torch.max(all_scores, dim=-1).values.detach().cpu().numpy()


def train_one_epoch(backbone, ksm: KinematicSteeringModuleV2, layer_idx: int, train_records: list[Record], p_norm: torch.Tensor, prompt_features: torch.Tensor, args: argparse.Namespace, optimizer: torch.optim.Optimizer, device: str) -> dict[str, float]:
    ksm.train()
    loss_vals = []
    loss_anom_vals = []
    loss_norm_vals = []
    gamma_vals = []
    for rec in train_records:
        image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        seq = forward_up_to_layer(backbone, image_t, layer_idx)
        cls_tok, patches = patchify_sequence(seq)
        mask = torch.from_numpy(rec.patch_mask.astype(np.int64)).to(device).view(1, -1)
        v_in = patches
        v_out = ksm(v_in)
        loss, l_anom, l_norm = compute_ksm_loss(v_in, v_out, p_norm, prompt_features, mask, lambda_n=args.lambda_n)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        loss_vals.append(float(loss.item()))
        loss_anom_vals.append(float(l_anom.item()))
        loss_norm_vals.append(float(l_norm.item()))
        gamma_vals.append(float(ksm.gamma_abs_mean().item()))
    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "train_loss_anom": float(np.mean(loss_anom_vals)) if loss_anom_vals else float("nan"),
        "train_loss_norm": float(np.mean(loss_norm_vals)) if loss_norm_vals else float("nan"),
        "gamma_abs_mean": float(np.mean(gamma_vals)) if gamma_vals else float("nan"),
    }


def evaluate_model(backbone, ksm: KinematicSteeringModuleV2, layer_idx: int, eval_records: list[Record], p_norm: torch.Tensor, prompt_features: torch.Tensor, delta_p_recon: torch.Tensor, topk_ratio: float, device: str) -> dict[str, float]:
    ksm.eval()
    patch_labels: list[int] = []
    base_recon_patch_scores: list[float] = []
    ksm_recon_patch_scores: list[float] = []
    base_prompt_patch_scores: list[float] = []
    ksm_prompt_patch_scores: list[float] = []
    image_labels: list[int] = []
    base_recon_image_scores: list[float] = []
    ksm_recon_image_scores: list[float] = []
    base_prompt_image_scores: list[float] = []
    ksm_prompt_image_scores: list[float] = []
    sem_drop_vals: list[float] = []

    with torch.no_grad():
        for rec in eval_records:
            image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            cls_tok, patches = patchify_sequence(seq)
            base_final = forward_remaining(backbone, seq, layer_idx)[0]
            out_patches = ksm(patches)
            out_seq = rebuild_sequence(cls_tok, out_patches)
            out_final = forward_remaining(backbone, out_seq, layer_idx)[0]

            base_recon = score_reconstructed_axis(base_final, p_norm, delta_p_recon)
            out_recon = score_reconstructed_axis(out_final, p_norm, delta_p_recon)
            base_prompt = score_promptmax(base_final, p_norm, prompt_features)
            out_prompt = score_promptmax(out_final, p_norm, prompt_features)

            patch_labels.extend(rec.patch_mask.astype(np.int64).tolist())
            base_recon_patch_scores.extend(base_recon.tolist())
            ksm_recon_patch_scores.extend(out_recon.tolist())
            base_prompt_patch_scores.extend(base_prompt.tolist())
            ksm_prompt_patch_scores.extend(out_prompt.tolist())
            image_labels.append(rec.label)
            base_recon_image_scores.append(topk_mean(base_recon, topk_ratio))
            ksm_recon_image_scores.append(topk_mean(out_recon, topk_ratio))
            base_prompt_image_scores.append(topk_mean(base_prompt, topk_ratio))
            ksm_prompt_image_scores.append(topk_mean(out_prompt, topk_ratio))

            base_norm = l2_normalize(base_final, dim=-1)
            out_norm = l2_normalize(out_final, dim=-1)
            sem_drop_vals.append(float((out_norm @ p_norm).mean().item() - (base_norm @ p_norm).mean().item()))

    base_recon_patch_auc = safe_auc(patch_labels, base_recon_patch_scores)
    ksm_recon_patch_auc = safe_auc(patch_labels, ksm_recon_patch_scores)
    base_recon_image_auc = safe_auc(image_labels, base_recon_image_scores)
    ksm_recon_image_auc = safe_auc(image_labels, ksm_recon_image_scores)
    base_prompt_patch_auc = safe_auc(patch_labels, base_prompt_patch_scores)
    ksm_prompt_patch_auc = safe_auc(patch_labels, ksm_prompt_patch_scores)
    base_prompt_image_auc = safe_auc(image_labels, base_prompt_image_scores)
    ksm_prompt_image_auc = safe_auc(image_labels, ksm_prompt_image_scores)

    return {
        "base_recon_patch_auc": base_recon_patch_auc,
        "ksm_recon_patch_auc": ksm_recon_patch_auc,
        "recon_patch_auc_delta": ksm_recon_patch_auc - base_recon_patch_auc,
        "base_recon_image_auc": base_recon_image_auc,
        "ksm_recon_image_auc": ksm_recon_image_auc,
        "recon_image_auc_delta": ksm_recon_image_auc - base_recon_image_auc,
        "base_prompt_patch_auc": base_prompt_patch_auc,
        "ksm_prompt_patch_auc": ksm_prompt_patch_auc,
        "prompt_patch_auc_delta": ksm_prompt_patch_auc - base_prompt_patch_auc,
        "base_prompt_image_auc": base_prompt_image_auc,
        "ksm_prompt_image_auc": ksm_prompt_image_auc,
        "prompt_image_auc_delta": ksm_prompt_image_auc - base_prompt_image_auc,
        "semantic_drop_mean": float(np.mean(sem_drop_vals)) if sem_drop_vals else float("nan"),
        "gamma_abs_mean_eval": float(ksm.gamma_abs_mean().item()),
    }


def parse_class_spec(spec: str) -> tuple[str, int, int]:
    class_name, train_layer, transfer_layer = spec.split(":")
    return class_name, int(train_layer), int(transfer_layer)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, float | str]] = []
    details: list[dict] = []
    skipped: list[dict[str, str]] = []

    class_specs = [parse_class_spec(spec) for spec in args.class_specs]
    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        backbone.eval()
        for param in backbone.parameters():
            param.requires_grad_(False)

        for class_name, train_layer, transfer_layer in class_specs:
            try:
                train_records, eval_records = collect_oracle_records(backbone, class_name, args)
                normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
                p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0]
                prompt_features = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts)
                delta_p = prompt_features - p_norm.unsqueeze(0)
                k = choose_text_rank(delta_p, args.text_var_threshold)
                U_basis = prepare_text_subspace(prompt_features, p_norm, k)
                delta_center = delta_p - delta_p.mean(dim=0, keepdim=True)
                U_text, _, _ = torch.linalg.svd(delta_center.T, full_matrices=False)
                # Build eval/readout axis using visual anomaly subspace from eval-side training anomalies at final layer.
                # Use train-layer train anomalies only for KSM fitting; use prompt basis for module values.
                # Reuse anomaly records to derive a reconstruction target at final layer.
                anom_chunks: list[torch.Tensor] = []
                for rec in train_records:
                    if rec.label != 1:
                        continue
                    image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
                    with torch.no_grad():
                        final = backbone.extract_layer_patch_tokens(image_t, target_layers=[backbone.num_layers])[backbone.num_layers][0]
                    pos = torch.from_numpy(rec.patch_mask > 0).to(final.device)
                    if int(pos.sum().item()) > 0:
                        anom_chunks.append(final[pos].detach())
                if not anom_chunks:
                    raise RuntimeError("No anomaly patches for delta_p_recon construction.")
                patches = torch.cat(anom_chunks, dim=0)
                residual = patches - (patches * p_norm.view(1, -1).to(patches.device)).sum(dim=-1, keepdim=True) * p_norm.view(1, -1).to(patches.device)
                residual = residual - residual.mean(dim=0, keepdim=True)
                _, _, vh = torch.linalg.svd(residual, full_matrices=False)
                V_anom = vh[: min(k, vh.shape[0])].contiguous()
                delta_p_recon, _, singular_values = reconstruct_optimal_text_axis(
                    U_basis.T.to(V_anom.device),
                    V_anom.T.contiguous(),
                )
                sigma1 = float(singular_values[0].item()) if singular_values.numel() else float("nan")
            except RuntimeError as exc:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": str(exc)})
                continue

            ksm = KinematicSteeringModuleV2(
                dim=int(prompt_features.shape[1]),
                U_basis=U_basis.to(device),
                p_norm=p_norm.to(device),
                use_channel_gate=args.use_channel_gate,
            ).to(device)
            optimizer = torch.optim.AdamW(ksm.parameters(), lr=args.lr, weight_decay=args.weight_decay)

            history: list[dict[str, float]] = []
            best_state = None
            best_metric = -float("inf")
            for epoch in range(1, args.epochs + 1):
                train_stats = train_one_epoch(backbone, ksm, train_layer, train_records, p_norm.to(device), prompt_features.to(device), args, optimizer, device)
                eval_same = evaluate_model(backbone, ksm, train_layer, eval_records, p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device), args.topk_ratio, device)
                history.append({"epoch": epoch, **train_stats, **eval_same})
                if eval_same["ksm_recon_image_auc"] > best_metric:
                    best_metric = eval_same["ksm_recon_image_auc"]
                    best_state = {k0: v.detach().cpu() for k0, v in ksm.state_dict().items()}

            if best_state is None:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": "No best state"})
                continue

            ksm.load_state_dict(best_state)
            same_eval = evaluate_model(backbone, ksm, train_layer, eval_records, p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device), args.topk_ratio, device)
            transfer_eval = evaluate_model(backbone, ksm, transfer_layer, eval_records, p_norm.to(device), prompt_features.to(device), delta_p_recon.to(device), args.topk_ratio, device)

            common = {
                "backbone": backbone_name,
                "pretrained": pretrained_name,
                "img_size": img_size_i,
                "class_name": class_name,
                "train_layer": train_layer,
                "text_rank": int(k),
                "epochs": args.epochs,
                "sigma1": float(sigma1),
                "use_channel_gate": int(args.use_channel_gate),
            }
            rows.append({**common, "eval_layer": train_layer, "transfer_eval": 0, **history[-1], **same_eval})
            rows.append({**common, "eval_layer": transfer_layer, "transfer_eval": 1, **history[-1], **transfer_eval})
            details.append({**common, "transfer_layer": transfer_layer, "history": history})

    gate_name = "channel" if args.use_channel_gate else "scalar"
    stem = f"{args.output_tag}_{gate_name}_{'-'.join(s.split(':')[0] for s in args.class_specs)}_{'-'.join(spec.split(':')[0] for spec in args.backbones)}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()}) if rows else []
    with csv_path.open("w", newline="") as f:
        if fieldnames:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"rows": rows, "details": details, "skipped": skipped}, f, indent=2)
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
