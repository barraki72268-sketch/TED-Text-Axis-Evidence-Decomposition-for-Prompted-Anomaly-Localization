from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from generate_rawclip_qualitative import (  # noqa: E402
    GenericMetaDataset,
    build_transforms,
    compute_maps,
    create_winclip_raw_backbone,
    load_bank_cache,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Generate aggregated raw-CLIP patch-score distribution figure")
    parser.add_argument("--target_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_split", type=str, default="test")
    parser.add_argument("--class_name", type=str, default=None)
    parser.add_argument("--backbone", type=str, default="ViT-L-14-336")
    parser.add_argument("--pretrained_dataset", type=str, default="openai")
    parser.add_argument("--image_size", type=int, default=336)
    parser.add_argument("--prompt_mode", type=str, default="class")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument(
        "--bank_cache_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bank_cache" / "rawclip_vitl_visa_multilayer.pt"),
    )
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--hard_fp_frac", type=float, default=0.01)
    parser.add_argument("--max_points_per_group", type=int, default=200000)
    parser.add_argument("--per_image_cap_abnormal", type=int, default=4096)
    parser.add_argument("--per_image_cap_hard_fp", type=int, default=4096)
    parser.add_argument("--per_image_cap_other", type=int, default=4096)
    parser.add_argument("--bins", type=int, default=220)
    parser.add_argument("--smooth_sigma", type=float, default=2.0)
    parser.add_argument("--dist_fig_width", type=float, default=13.5)
    parser.add_argument("--dist_fig_height", type=float, default=4.6)
    parser.add_argument("--focus_fig_width", type=float, default=12.8)
    parser.add_argument("--focus_fig_height", type=float, default=7.2)
    parser.add_argument("--combo_fig_width", type=float, default=20.0)
    parser.add_argument("--combo_fig_height", type=float, default=4.8)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--output_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "rawclip_aggregated_distribution_vitl_visa2mvtec"),
    )
    return parser.parse_args()


def top_fraction_mask(arr: np.ndarray, frac: float) -> np.ndarray:
    flat = arr.reshape(-1)
    k = max(1, int(round(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    mask = np.zeros_like(flat, dtype=bool)
    mask[idx] = True
    return mask.reshape(arr.shape)


def auc_from_scores(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    scores = np.concatenate([pos, neg], axis=0)
    labels = np.concatenate(
        [np.ones(pos.shape[0], dtype=np.int64), np.zeros(neg.shape[0], dtype=np.int64)],
        axis=0,
    )
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(scores) + 1, dtype=np.float64)
    pos_ranks = ranks[labels == 1]
    n_pos = pos.shape[0]
    n_neg = neg.shape[0]
    return float((pos_ranks.sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def sample_chunk(vals: np.ndarray, cap: int, rng: np.random.Generator) -> np.ndarray:
    vals = vals.reshape(-1)
    if vals.size <= cap:
        return vals.astype(np.float32, copy=False)
    idx = rng.choice(vals.size, size=cap, replace=False)
    return vals[idx].astype(np.float32, copy=False)


def finalize_group(chunks: list[np.ndarray], max_points: int, rng: np.random.Generator) -> np.ndarray:
    if not chunks:
        return np.empty((0,), dtype=np.float32)
    vals = np.concatenate(chunks, axis=0).astype(np.float32, copy=False)
    if vals.size <= max_points:
        return vals
    idx = rng.choice(vals.size, size=max_points, replace=False)
    return vals[idx]


def density_curve(vals: np.ndarray, x_lo: float, x_hi: float, bins: int, smooth_sigma: float) -> tuple[np.ndarray, np.ndarray]:
    hist, edges = np.histogram(vals, bins=bins, range=(x_lo, x_hi), density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    if smooth_sigma > 0:
        hist = gaussian_filter1d(hist, sigma=smooth_sigma)
    return centers, hist


def plot_focus_violin(
    abnormal_baseline: np.ndarray,
    hardfp_baseline: np.ndarray,
    abnormal_ours: np.ndarray,
    hardfp_ours: np.ndarray,
    png_path: Path,
    pdf_path: Path,
    seed: int,
    fig_width: float,
    fig_height: float,
) -> None:
    rng = np.random.default_rng(seed)

    def _plot_panel(ax, abnormal: np.ndarray, hardfp: np.ndarray, title: str):
        max_plot = 50000
        if abnormal.size > max_plot:
            abnormal = abnormal[rng.choice(abnormal.size, size=max_plot, replace=False)]
        if hardfp.size > max_plot:
            hardfp = hardfp[rng.choice(hardfp.size, size=max_plot, replace=False)]
        vp = ax.violinplot(
            [abnormal, hardfp],
            positions=[1, 2],
            widths=0.8,
            showmeans=False,
            showmedians=True,
            showextrema=False,
        )
        body_colors = ["#c43c39", "#3568b8"]
        for body, color in zip(vp["bodies"], body_colors):
            body.set_facecolor(color)
            body.set_edgecolor(color)
            body.set_alpha(0.28)
        vp["cmedians"].set_color("#111111")
        vp["cmedians"].set_linewidth(2.0)

        bp = ax.boxplot(
            [abnormal, hardfp],
            positions=[1, 2],
            widths=0.22,
            patch_artist=True,
            showfliers=False,
            medianprops={"color": "#111111", "linewidth": 1.8},
            boxprops={"linewidth": 1.4},
            whiskerprops={"linewidth": 1.2},
            capprops={"linewidth": 1.2},
        )
        for patch, color in zip(bp["boxes"], body_colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.65)
            patch.set_edgecolor(color)

        auc_abn_hfp = auc_from_scores(abnormal, hardfp)
        med_gap = float(np.median(abnormal) - np.median(hardfp))
        ax.set_title(
            f"{title}\nAUC(abn>hard-FP)={auc_abn_hfp:.3f}, median gap={med_gap:.4f}",
            fontsize=13,
            fontweight="bold",
        )
        ax.set_xticks([1, 2], ["GT abnormal", "hard-FP normal"])
        ax.set_ylabel("Patch score", fontsize=11)
        ax.grid(axis="y", linestyle="--", alpha=0.2)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

    fig, axes = plt.subplots(1, 2, figsize=(fig_width, fig_height), constrained_layout=True)
    _plot_panel(axes[0], abnormal_baseline, hardfp_baseline, "(a) Baseline")
    _plot_panel(axes[1], abnormal_ours, hardfp_ours, "(b) Ours")
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)


def plot_focus_violin_horizontal(
    abnormal_baseline: np.ndarray,
    hardfp_baseline: np.ndarray,
    abnormal_ours: np.ndarray,
    hardfp_ours: np.ndarray,
    png_path: Path,
    pdf_path: Path,
    seed: int,
    fig_width: float,
    fig_height: float,
) -> None:
    rng = np.random.default_rng(seed)

    def _plot_panel(ax, abnormal: np.ndarray, hardfp: np.ndarray, title: str):
        max_plot = 50000
        if abnormal.size > max_plot:
            abnormal = abnormal[rng.choice(abnormal.size, size=max_plot, replace=False)]
        if hardfp.size > max_plot:
            hardfp = hardfp[rng.choice(hardfp.size, size=max_plot, replace=False)]
        groups = [abnormal, hardfp]
        positions = [2, 1]
        body_colors = ["#c43c39", "#3568b8"]

        vp = ax.violinplot(
            groups,
            positions=positions,
            vert=False,
            widths=0.72,
            showmeans=False,
            showmedians=True,
            showextrema=False,
        )
        for body, color in zip(vp["bodies"], body_colors):
            body.set_facecolor(color)
            body.set_edgecolor(color)
            body.set_alpha(0.28)
        vp["cmedians"].set_color("#111111")
        vp["cmedians"].set_linewidth(2.0)

        bp = ax.boxplot(
            groups,
            positions=positions,
            vert=False,
            widths=0.24,
            patch_artist=True,
            showfliers=False,
            medianprops={"color": "#111111", "linewidth": 1.8},
            boxprops={"linewidth": 1.4},
            whiskerprops={"linewidth": 1.2},
            capprops={"linewidth": 1.2},
        )
        for patch, color in zip(bp["boxes"], body_colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.65)
            patch.set_edgecolor(color)

        auc_abn_hfp = auc_from_scores(abnormal, hardfp)
        med_gap = float(np.median(abnormal) - np.median(hardfp))
        ax.set_title(
            f"{title}\nAUC(abn>hard-FP)={auc_abn_hfp:.3f}, median gap={med_gap:.4f}",
            fontsize=12.5,
            fontweight="bold",
            pad=8,
        )
        ax.set_yticks(positions, ["GT abnormal", "hard-FP normal"])
        ax.set_xlabel("Patch score", fontsize=11)
        ax.grid(axis="x", linestyle="--", alpha=0.2)
        ax.tick_params(axis="both", labelsize=10.5)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

    fig, axes = plt.subplots(1, 2, figsize=(fig_width, fig_height), constrained_layout=True)
    _plot_panel(axes[0], abnormal_baseline, hardfp_baseline, "(a) Baseline")
    _plot_panel(axes[1], abnormal_ours, hardfp_ours, "(b) Ours")
    fig.savefig(png_path, dpi=240, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)


def plot_combo_four_panel(
    curves: dict[str, dict[str, tuple[np.ndarray, np.ndarray]]],
    finalized: dict[str, dict[str, np.ndarray]],
    png_path: Path,
    pdf_path: Path,
    seed: int,
    fig_width: float,
    fig_height: float,
) -> None:
    rng = np.random.default_rng(seed)
    colors = {
        "abnormal": "#c43c39",
        "hard_fp": "#3568b8",
        "other": "#8a8a8a",
    }
    labels = {
        "abnormal": "GT abnormal",
        "hard_fp": "hard-FP normal",
        "other": "other normal",
    }

    def _plot_density(ax, method: str, title: str):
        for group in ["abnormal", "hard_fp", "other"]:
            x, y = curves[method][group]
            ax.plot(x, y, color=colors[group], linewidth=2.0, label=labels[group])
            ax.fill_between(x, 0.0, y, color=colors[group], alpha=0.12)
        auc_abn_hfp = auc_from_scores(finalized[method]["abnormal"], finalized[method]["hard_fp"])
        ax.set_title(f"{title}\nAUC(abn>hard-FP)={auc_abn_hfp:.3f}", fontsize=12, fontweight="bold")
        ax.set_xlabel("Patch score", fontsize=10)
        ax.set_ylabel("Density", fontsize=10)
        ax.grid(axis="y", linestyle="--", alpha=0.2)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

    def _plot_focus(ax, abnormal: np.ndarray, hardfp: np.ndarray, title: str):
        max_plot = 50000
        if abnormal.size > max_plot:
            abnormal = abnormal[rng.choice(abnormal.size, size=max_plot, replace=False)]
        if hardfp.size > max_plot:
            hardfp = hardfp[rng.choice(hardfp.size, size=max_plot, replace=False)]
        vp = ax.violinplot(
            [abnormal, hardfp],
            positions=[1, 2],
            widths=0.8,
            showmeans=False,
            showmedians=True,
            showextrema=False,
        )
        body_colors = ["#c43c39", "#3568b8"]
        for body, color in zip(vp["bodies"], body_colors):
            body.set_facecolor(color)
            body.set_edgecolor(color)
            body.set_alpha(0.28)
        vp["cmedians"].set_color("#111111")
        vp["cmedians"].set_linewidth(2.0)

        bp = ax.boxplot(
            [abnormal, hardfp],
            positions=[1, 2],
            widths=0.22,
            patch_artist=True,
            showfliers=False,
            medianprops={"color": "#111111", "linewidth": 1.8},
            boxprops={"linewidth": 1.4},
            whiskerprops={"linewidth": 1.2},
            capprops={"linewidth": 1.2},
        )
        for patch, color in zip(bp["boxes"], body_colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.65)
            patch.set_edgecolor(color)

        auc_abn_hfp = auc_from_scores(abnormal, hardfp)
        med_gap = float(np.median(abnormal) - np.median(hardfp))
        ax.set_title(f"{title}\nAUC={auc_abn_hfp:.3f}, median gap={med_gap:.4f}", fontsize=12, fontweight="bold")
        ax.set_xticks([1, 2], ["abnormal", "hard-FP"])
        ax.set_ylabel("Patch score", fontsize=10)
        ax.grid(axis="y", linestyle="--", alpha=0.2)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

    fig, axes = plt.subplots(1, 4, figsize=(fig_width, fig_height), constrained_layout=True)
    _plot_density(axes[0], "baseline", "(a) Baseline density")
    _plot_density(axes[1], "ours", "(b) Ours density")
    _plot_focus(axes[2], finalized["baseline"]["abnormal"], finalized["baseline"]["hard_fp"], "(c) Baseline focus")
    _plot_focus(axes[3], finalized["ours"]["abnormal"], finalized["ours"]["hard_fp"], "(d) Ours focus")
    axes[1].legend(loc="upper right", frameon=False, fontsize=9)
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(args.seed)
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=args.device,
        img_resize=args.image_size,
        img_cropsize=args.image_size,
    )
    image_transform, mask_transform = build_transforms(args.image_size)
    fp_banks, def_banks, _, _ = load_bank_cache(Path(args.bank_cache_path))
    ds = GenericMetaDataset(
        root=args.target_root,
        image_transform=image_transform,
        mask_transform=mask_transform,
        split=args.target_split,
        class_name=args.class_name,
    )

    groups = {
        "baseline": {"abnormal": [], "hard_fp": [], "other": []},
        "ours": {"abnormal": [], "hard_fp": [], "other": []},
    }
    counts = {
        "num_images": len(ds),
        "num_normal_images": 0,
        "num_anomaly_images": 0,
        "num_abnormal_pixels": 0,
        "num_hard_fp_pixels": 0,
        "num_other_pixels": 0,
    }

    print(
        json.dumps(
            {
                "stage": "aggregated_distribution_start",
                "backbone": args.backbone,
                "pretrained_dataset": args.pretrained_dataset,
                "target_root": args.target_root,
                "target_split": args.target_split,
                "class_name": args.class_name,
                "num_images": len(ds),
            }
        ),
        flush=True,
    )

    for idx in range(len(ds)):
        item = ds[idx]
        baseline_map, ours_map, _, _ = compute_maps(backbone, item, fp_banks, def_banks, args)
        gt_mask = (item["img_mask"][0].numpy() > 0.5)

        if int(item["anomaly"]) == 1 and gt_mask.any():
            counts["num_anomaly_images"] += 1
            abnormal_base = sample_chunk(baseline_map[gt_mask], args.per_image_cap_abnormal, rng)
            abnormal_ours = sample_chunk(ours_map[gt_mask], args.per_image_cap_abnormal, rng)
            groups["baseline"]["abnormal"].append(abnormal_base)
            groups["ours"]["abnormal"].append(abnormal_ours)
            counts["num_abnormal_pixels"] += int(gt_mask.sum())
        else:
            counts["num_normal_images"] += 1
            hard_mask = top_fraction_mask(baseline_map, args.hard_fp_frac)
            other_mask = ~hard_mask
            hard_base = sample_chunk(baseline_map[hard_mask], args.per_image_cap_hard_fp, rng)
            hard_ours = sample_chunk(ours_map[hard_mask], args.per_image_cap_hard_fp, rng)
            other_base = sample_chunk(baseline_map[other_mask], args.per_image_cap_other, rng)
            other_ours = sample_chunk(ours_map[other_mask], args.per_image_cap_other, rng)
            groups["baseline"]["hard_fp"].append(hard_base)
            groups["ours"]["hard_fp"].append(hard_ours)
            groups["baseline"]["other"].append(other_base)
            groups["ours"]["other"].append(other_ours)
            counts["num_hard_fp_pixels"] += int(hard_mask.sum())
            counts["num_other_pixels"] += int(other_mask.sum())

        if (idx + 1) % 64 == 0 or (idx + 1) == len(ds):
            print(
                json.dumps(
                    {
                        "stage": "aggregated_distribution_progress",
                        "images_done": idx + 1,
                        "images_total": len(ds),
                    }
                ),
                flush=True,
            )

    finalized = {
        method: {
            group: finalize_group(chunks, args.max_points_per_group, rng)
            for group, chunks in method_groups.items()
        }
        for method, method_groups in groups.items()
    }

    baseline_all = np.concatenate(
        [finalized["baseline"]["abnormal"], finalized["baseline"]["hard_fp"], finalized["baseline"]["other"]],
        axis=0,
    )
    ours_all = np.concatenate(
        [finalized["ours"]["abnormal"], finalized["ours"]["hard_fp"], finalized["ours"]["other"]],
        axis=0,
    )
    base_lo, base_hi = float(np.percentile(baseline_all, 0.2)), float(np.percentile(baseline_all, 99.8))
    ours_lo, ours_hi = float(np.percentile(ours_all, 0.2)), float(np.percentile(ours_all, 99.8))
    if base_hi <= base_lo:
        base_hi = base_lo + 1e-6
    if ours_hi <= ours_lo:
        ours_hi = ours_lo + 1e-6

    curves = {}
    for method, (lo, hi) in {"baseline": (base_lo, base_hi), "ours": (ours_lo, ours_hi)}.items():
        curves[method] = {}
        for group in ["abnormal", "hard_fp", "other"]:
            curves[method][group] = density_curve(
                finalized[method][group],
                lo,
                hi,
                bins=args.bins,
                smooth_sigma=args.smooth_sigma,
            )

    colors = {
        "abnormal": "#c43c39",
        "hard_fp": "#3568b8",
        "other": "#8a8a8a",
    }
    labels = {
        "abnormal": "GT abnormal",
        "hard_fp": "hard-FP normal",
        "other": "other normal",
    }

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(args.dist_fig_width, args.dist_fig_height),
        constrained_layout=True,
    )
    titles = ["(a) Baseline", "(b) Ours"]
    for ax, method, title in zip(axes, ["baseline", "ours"], titles):
        for group in ["abnormal", "hard_fp", "other"]:
            x, y = curves[method][group]
            ax.plot(x, y, color=colors[group], linewidth=2.2, label=labels[group])
            ax.fill_between(x, 0.0, y, color=colors[group], alpha=0.12)
        auc_abn_hfp = auc_from_scores(finalized[method]["abnormal"], finalized[method]["hard_fp"])
        auc_abn_other = auc_from_scores(finalized[method]["abnormal"], finalized[method]["other"])
        ax.set_title(
            f"{title}\nAUC(abn>hard-FP)={auc_abn_hfp:.3f}, AUC(abn>other)={auc_abn_other:.3f}",
            fontsize=13,
            fontweight="bold",
        )
        ax.set_xlabel("Patch score", fontsize=11)
        ax.set_ylabel("Density", fontsize=11)
        ax.grid(axis="y", linestyle="--", alpha=0.2)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)
    axes[1].legend(loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False, fontsize=10)

    png_path = out_dir / "rawclip_aggregated_distribution.png"
    pdf_path = out_dir / "rawclip_aggregated_distribution.pdf"
    focus_png_path = out_dir / "rawclip_abnormal_hardfp_focus.png"
    focus_pdf_path = out_dir / "rawclip_abnormal_hardfp_focus.pdf"
    focus_h_png_path = out_dir / "rawclip_abnormal_hardfp_focus_horizontal.png"
    focus_h_pdf_path = out_dir / "rawclip_abnormal_hardfp_focus_horizontal.pdf"
    combo_png_path = out_dir / "rawclip_distribution_combo_4panel.png"
    combo_pdf_path = out_dir / "rawclip_distribution_combo_4panel.pdf"
    arrays_path = out_dir / "rawclip_aggregated_distribution_arrays.npz"
    summary_path = out_dir / "rawclip_aggregated_distribution.json"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)

    plot_focus_violin(
        abnormal_baseline=finalized["baseline"]["abnormal"],
        hardfp_baseline=finalized["baseline"]["hard_fp"],
        abnormal_ours=finalized["ours"]["abnormal"],
        hardfp_ours=finalized["ours"]["hard_fp"],
        png_path=focus_png_path,
        pdf_path=focus_pdf_path,
        seed=args.seed,
        fig_width=args.focus_fig_width,
        fig_height=args.focus_fig_height,
    )
    plot_focus_violin_horizontal(
        abnormal_baseline=finalized["baseline"]["abnormal"],
        hardfp_baseline=finalized["baseline"]["hard_fp"],
        abnormal_ours=finalized["ours"]["abnormal"],
        hardfp_ours=finalized["ours"]["hard_fp"],
        png_path=focus_h_png_path,
        pdf_path=focus_h_pdf_path,
        seed=args.seed,
        fig_width=args.focus_fig_width,
        fig_height=max(3.2, args.focus_fig_height * 0.46),
    )
    plot_combo_four_panel(
        curves=curves,
        finalized=finalized,
        png_path=combo_png_path,
        pdf_path=combo_pdf_path,
        seed=args.seed,
        fig_width=args.combo_fig_width,
        fig_height=args.combo_fig_height,
    )
    np.savez_compressed(
        arrays_path,
        baseline_abnormal=finalized["baseline"]["abnormal"],
        baseline_hard_fp=finalized["baseline"]["hard_fp"],
        baseline_other=finalized["baseline"]["other"],
        ours_abnormal=finalized["ours"]["abnormal"],
        ours_hard_fp=finalized["ours"]["hard_fp"],
        ours_other=finalized["ours"]["other"],
    )

    summary = {
        "backbone": args.backbone,
        "pretrained_dataset": args.pretrained_dataset,
        "target_root": args.target_root,
        "target_split": args.target_split,
        "class_name": args.class_name,
        "bank_cache_path": args.bank_cache_path,
        "hard_fp_frac": args.hard_fp_frac,
        "counts": counts,
        "summary": {
            method: {
                group: {
                    "count": int(finalized[method][group].size),
                    "mean": float(finalized[method][group].mean()) if finalized[method][group].size else float("nan"),
                    "std": float(finalized[method][group].std()) if finalized[method][group].size else float("nan"),
                    "p50": float(np.percentile(finalized[method][group], 50)) if finalized[method][group].size else float("nan"),
                    "p95": float(np.percentile(finalized[method][group], 95)) if finalized[method][group].size else float("nan"),
                }
                for group in ["abnormal", "hard_fp", "other"]
            }
            for method in ["baseline", "ours"]
        },
        "pairwise_auc": {
            method: {
                "abnormal_vs_hard_fp": auc_from_scores(finalized[method]["abnormal"], finalized[method]["hard_fp"]),
                "abnormal_vs_other": auc_from_scores(finalized[method]["abnormal"], finalized[method]["other"]),
                "hard_fp_vs_other": auc_from_scores(finalized[method]["hard_fp"], finalized[method]["other"]),
            }
            for method in ["baseline", "ours"]
        },
        "png": str(png_path),
        "pdf": str(pdf_path),
        "focus_png": str(focus_png_path),
        "focus_pdf": str(focus_pdf_path),
        "focus_horizontal_png": str(focus_h_png_path),
        "focus_horizontal_pdf": str(focus_h_pdf_path),
        "combo_png": str(combo_png_path),
        "combo_pdf": str(combo_pdf_path),
        "arrays_npz": str(arrays_path),
    }
    summary_path.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
