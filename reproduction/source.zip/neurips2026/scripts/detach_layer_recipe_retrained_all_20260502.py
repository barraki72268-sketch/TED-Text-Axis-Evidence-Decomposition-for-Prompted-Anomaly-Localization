#!/usr/bin/env python3
"""Detach the full layer-recipe retraining queue from the Codex session."""

from __future__ import annotations

import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
QUEUE = ROOT / "neurips2026/scripts/queue_layer_recipe_retrained_all_20260502.py"
OUT = ROOT / "neurips2026/results/layer_recipe_retrained_all_20260502"
LOG = OUT / "queue.detached.log"
PID = OUT / "queue.pid"


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    with LOG.open("ab") as log:
        proc = subprocess.Popen(
            [str(PY), "-u", str(QUEUE)],
            cwd=str(ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    PID.write_text(str(proc.pid) + "\n")
    print({"stage": "detached", "pid": proc.pid, "log": str(LOG), "root": str(OUT)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
