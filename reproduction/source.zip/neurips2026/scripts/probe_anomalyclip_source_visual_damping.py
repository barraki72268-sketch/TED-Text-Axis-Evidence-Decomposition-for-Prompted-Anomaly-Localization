from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from prompt_ensemble import AnomalyCLIP_PromptLearner  # noqa: E402
from utils import get_transform  # noqa: E402


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def normal_basis(bank: torch.Tensor, eps: float = 1e-6) -> tuple[torch.Tensor, torch.Tensor]:
    bank = F.normalize(bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return bank.new_zeros((bank.shape[-1], 0)), s
    return vh[:rank].transpose(0, 1).contiguous(), s


def save_rows(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "beta",
                "class_name",
                "num_anomaly",
                "num_normal",
                "inside_mean",
                "outside_mean",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def build_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_prompt_learner(model, params, checkpoint_path: Path, device: str):
    prompt_learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    prompt_learner.eval()
    model.to(device)
    model.eval()
    return prompt_learner


def collect_source_tail_bases(
    model,
    source_root: str,
    image_size: int,
    device: str,
    features_list: list[int],
    feature_map_layer: list[int],
    max_per_class: int,
    skip_topk: int,
) -> tuple[dict[int, torch.Tensor], dict[int, dict]]:
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=source_root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode="train")

    per_class_count: dict[str, int] = {obj: 0 for obj in dataset.obj_list}
    kept_indices = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        cls_name = item["cls_name"]
        anomaly_flag = item["anomaly"]
        if hasattr(anomaly_flag, "item"):
            anomaly_flag = anomaly_flag.item()
        if int(anomaly_flag) != 0:
            continue
        if per_class_count[cls_name] >= max_per_class:
            continue
        per_class_count[cls_name] += 1
        kept_indices.append(idx)

    subset = torch.utils.data.Subset(dataset, kept_indices)
    loader = torch.utils.data.DataLoader(subset, batch_size=1, shuffle=False, num_workers=0)

    layer_banks: dict[int, list[torch.Tensor]] = {idx: [] for idx in range(len(features_list)) if idx >= feature_map_layer[0]}
    print(
        json.dumps(
            {
                "stage": "collect_source_patches",
                "source_root": source_root,
                "num_selected_images": len(kept_indices),
                "max_per_class": max_per_class,
                "skip_topk": skip_topk,
            }
        ),
        flush=True,
    )
    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < feature_map_layer[0]:
                    continue
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                layer_banks[layer_idx].append(patch.cpu())
            if img_idx % 8 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "collect_source_patches_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    tail_bases: dict[int, torch.Tensor] = {}
    basis_stats: dict[int, dict] = {}
    for layer_idx, chunks in layer_banks.items():
        bank = torch.cat(chunks, dim=0)
        basis, s = normal_basis(bank)
        tail = basis[:, skip_topk:] if basis.shape[1] > skip_topk else basis.new_zeros((basis.shape[0], 0))
        tail_bases[layer_idx] = tail
        s2 = (s**2) / torch.clamp((s**2).sum(), min=1e-8)
        cum = torch.cumsum(s2, dim=0)
        basis_stats[layer_idx] = {
            "num_patches": int(bank.shape[0]),
            "rank": int(basis.shape[1]),
            "tail_dim": int(tail.shape[1]),
            "sv_cum_top1": float(cum[min(0, len(cum) - 1)].item()) if len(cum) else 0.0,
            "sv_cum_top5": float(cum[min(4, len(cum) - 1)].item()) if len(cum) else 0.0,
            "sv_cum_top10": float(cum[min(9, len(cum) - 1)].item()) if len(cum) else 0.0,
        }
    print(json.dumps({"stage": "source_basis_ready", "basis_stats": basis_stats}, indent=2), flush=True)
    return tail_bases, basis_stats


def save_basis_cache(
    cache_path: Path,
    tail_bases: dict[int, torch.Tensor],
    basis_stats: dict[int, dict],
) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "tail_bases": {str(k): v.cpu() for k, v in tail_bases.items()},
        "basis_stats": basis_stats,
    }
    torch.save(payload, cache_path)


def load_basis_cache(cache_path: Path) -> tuple[dict[int, torch.Tensor], dict[int, dict]]:
    payload = torch.load(cache_path, map_location="cpu")
    tail_bases = {int(k): v for k, v in payload["tail_bases"].items()}
    basis_stats = payload["basis_stats"]
    return tail_bases, basis_stats


def main():
    parser = argparse.ArgumentParser("Probe source-only visual-tail damping for AnomalyCLIP")
    parser.add_argument(
        "--source_root",
        type=str,
        default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
    )
    parser.add_argument(
        "--target_root",
        type=str,
        default="/mnt/data/gijeong/MMAD_new/VisA",
    )
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_source_visual_damping"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--max_source_per_class", type=int, default=8)
    parser.add_argument("--skip_topk", type=int, default=1)
    parser.add_argument("--betas", type=float, nargs="+", default=[0.0, 0.1, 0.3, 0.5])
    parser.add_argument("--basis_cache", type=str, default="")
    parser.add_argument("--text_tail_mode", type=str, default="none", choices=["none", "anomaly", "both"])
    parser.add_argument("--text_beta_scale", type=float, default=1.0)
    args = parser.parse_args()

    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    prompt_learner = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    cache_path = Path(args.basis_cache) if args.basis_cache else None
    if cache_path is not None and cache_path.exists():
        tail_bases, basis_stats = load_basis_cache(cache_path)
        print(json.dumps({"stage": "source_basis_loaded_from_cache", "cache_path": str(cache_path), "basis_stats": basis_stats}, indent=2), flush=True)
    else:
        tail_bases, basis_stats = collect_source_tail_bases(
            model=model,
            source_root=args.source_root,
            image_size=args.image_size,
            device=device,
            features_list=args.features_list,
            feature_map_layer=args.feature_map_layer,
            max_per_class=args.max_source_per_class,
            skip_topk=args.skip_topk,
        )
        if cache_path is not None:
            save_basis_cache(cache_path, tail_bases, basis_stats)
            print(json.dumps({"stage": "source_basis_saved_to_cache", "cache_path": str(cache_path)}, indent=2), flush=True)

    class Args:
        pass

    targs = Args()
    targs.image_size = args.image_size
    preprocess, target_transform = get_transform(targs)
    dataset = Dataset(root=args.target_root, transform=preprocess, target_transform=target_transform, dataset_name="visa", mode="test")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    prompts, tokenized_prompts, compound_prompts_text = prompt_learner(cls_id=None)
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    per_beta_class = {
        beta: {
            obj: {
                "num_anomaly": 0,
                "num_normal": 0,
                "inside_sum": 0.0,
                "outside_sum": 0.0,
                "ratio_sum": 0.0,
                "normal_topk_sum": 0.0,
                "normal_mean_sum": 0.0,
            }
            for obj in dataset.obj_list
        }
        for beta in args.betas
    }

    print(json.dumps({"stage": "target_eval_start", "num_target_images": len(dataset), "betas": args.betas}, indent=2), flush=True)
    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            maps_by_beta: dict[float, list[torch.Tensor]] = {beta: [] for beta in args.betas}

            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < args.feature_map_layer[0]:
                    continue
                patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
                cls_tok = patch_feature[:, :1, :]
                patch_tok = patch_feature[:, 1:, :]
                tail = tail_bases[layer_idx].to(device=device, dtype=patch_tok.dtype)

                for beta in args.betas:
                    if tail.shape[1] > 0 and beta > 0:
                        coeff = torch.matmul(patch_tok, tail)
                        proj = torch.matmul(coeff, tail.transpose(0, 1))
                        damped_patch = patch_tok - beta * proj
                        damped_patch = damped_patch / damped_patch.norm(dim=-1, keepdim=True).clamp_min(1e-6)
                    else:
                        damped_patch = patch_tok

                    layer_text = text_features[0].clone()
                    text_beta = beta * args.text_beta_scale
                    if tail.shape[1] > 0 and text_beta > 0 and args.text_tail_mode != "none":
                        if args.text_tail_mode in {"anomaly", "both"}:
                            anom = layer_text[1:2]
                            anom_proj = (anom @ tail) @ tail.transpose(0, 1)
                            anom = anom - text_beta * anom_proj
                            anom = anom / anom.norm(dim=-1, keepdim=True).clamp_min(1e-6)
                            layer_text[1:2] = anom
                        if args.text_tail_mode == "both":
                            norm = layer_text[0:1]
                            norm_proj = (norm @ tail) @ tail.transpose(0, 1)
                            norm = norm - text_beta * norm_proj
                            norm = norm / norm.norm(dim=-1, keepdim=True).clamp_min(1e-6)
                            layer_text[0:1] = norm
                    damped = torch.cat([cls_tok, damped_patch], dim=1)
                    similarity, _ = AnomalyCLIP_lib.compute_similarity(damped, layer_text)
                    similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], args.image_size)
                    anomaly_map = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0
                    maps_by_beta[beta].append(anomaly_map)

            for beta in args.betas:
                anomaly_map = torch.stack(maps_by_beta[beta]).sum(dim=0)[0].detach().cpu().numpy()
                anomaly_map = gaussian_filter(anomaly_map, sigma=args.sigma)

                stats = per_beta_class[beta][cls_name]
                if is_anomaly and gt_mask.any():
                    inside = float(anomaly_map[gt_mask].mean())
                    outside = float(anomaly_map[~gt_mask].mean())
                    stats["num_anomaly"] += 1
                    stats["inside_sum"] += inside
                    stats["outside_sum"] += outside
                    stats["ratio_sum"] += outside / max(inside, 1e-8)
                else:
                    stats["num_normal"] += 1
                    stats["normal_topk_sum"] += topk_mean(anomaly_map, args.topk_frac)
                    stats["normal_mean_sum"] += float(anomaly_map.mean())

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "target_eval_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    rows = []
    summary = {
        "source_root": args.source_root,
        "target_root": args.target_root,
        "checkpoint_path": args.checkpoint_path,
        "skip_topk": args.skip_topk,
        "max_source_per_class": args.max_source_per_class,
        "text_tail_mode": args.text_tail_mode,
        "text_beta_scale": args.text_beta_scale,
        "basis_stats": basis_stats,
        "means": {},
    }
    for beta in args.betas:
        beta_rows = []
        for cls_name, stats in per_beta_class[beta].items():
            row = {
                "beta": beta,
                "class_name": cls_name,
                "num_anomaly": stats["num_anomaly"],
                "num_normal": stats["num_normal"],
                "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
                "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
                "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
                "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
                "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
                "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
            }
            beta_rows.append(row)
            rows.append(row)

        mean_row = {
            "beta": beta,
            "class_name": "mean",
            "num_anomaly": sum(r["num_anomaly"] for r in beta_rows),
            "num_normal": sum(r["num_normal"] for r in beta_rows),
            "inside_mean": float(np.mean([r["inside_mean"] for r in beta_rows])),
            "outside_mean": float(np.mean([r["outside_mean"] for r in beta_rows])),
            "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in beta_rows])),
            "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in beta_rows])),
            "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in beta_rows])),
            "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in beta_rows])),
        }
        rows.append(mean_row)
        summary["means"][str(beta)] = mean_row

    save_rows(rows, summary, Path(args.save_dir))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
