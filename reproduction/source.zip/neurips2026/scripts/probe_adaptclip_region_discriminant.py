from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADAPT_ROOT = ROOT / "neurips2026" / "AdaptCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ADAPT_ROOT) not in sys.path:
    sys.path.insert(0, str(ADAPT_ROOT))

import adaptcliplib  # noqa: E402
from adaptcliplib import TextualAdapter, VisualAdapter, fusion_fun  # noqa: E402
from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from region_descriptor_utils import extract_region_descriptor, iterate_components, load_rows  # noqa: E402
from region_eval_utils import image_auroc, pixel_auroc, topk_mean  # noqa: E402
from tools.utils import get_transform  # noqa: E402


def build_dataset(root: str, image_size: int, dataset_name: str):
    preprocess, target_transform = get_transform(image_size=image_size)
    return Dataset(
        root=root,
        transform=preprocess,
        target_transform=target_transform,
        dataset_name=dataset_name,
        k_shots=0,
        save_dir=str(ROOT / "neurips2026" / "results" / "_tmp"),
        mode="test",
        seed=10,
    )


def build_model(device: str, checkpoint_path: str, image_size: int, n_ctx: int, vl_reduction: int, pretrained_model: str):
    model, _ = adaptcliplib.load(pretrained_model, device=device)
    model.visual.DAPM_replace(DPAM_layer=20)
    patch_size = 14
    input_dim = 768
    textual_learner = TextualAdapter(model.to("cpu"), image_size, n_ctx)
    visual_learner = VisualAdapter(image_size, patch_size, input_dim, vl_reduction)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    textual_learner.load_state_dict(checkpoint["textual_learner"])
    visual_learner.load_state_dict(checkpoint["visual_learner"])
    textual_learner.to(device)
    visual_learner.to(device)
    model.to(device)
    model.eval()
    textual_learner.eval()
    visual_learner.eval()
    textual_learner.prepare_static_text_feature(model)
    prompt_text, token_text = textual_learner.forward()
    learned_text_features = model.encode_text_learn(prompt_text, token_text, None)
    learned_text_features = learned_text_features / learned_text_features.norm(dim=-1, keepdim=True)
    return model, textual_learner, visual_learner, learned_text_features


def compute_map(model, textual_learner, visual_learner, learned_text_features, image: torch.Tensor, features_list: list[int], sigma: int):
    query_feats, query_patch_feats = model.encode_image(image, features_list, DPAM_layer=20)
    _, local_vl_map = visual_learner(query_feats, query_patch_feats, textual_learner.static_text_features)
    local_vl_map = local_vl_map[:, 1].detach()
    _, local_tl_map = textual_learner.compute_global_local_score(query_feats, query_patch_feats, learned_text_features)
    local_tl_map = local_tl_map[:, 1].detach()
    pixel_anomaly_map = fusion_fun([local_vl_map, local_tl_map], fusion_type="average_mean")
    pixel_anomaly_map = torch.stack(
        [torch.from_numpy(gaussian_filter(i, sigma=sigma)) for i in pixel_anomaly_map.cpu()],
        dim=0,
    )
    return pixel_anomaly_map[0].numpy()


def fit_region_classifier(fp_rows: list[dict], defect_rows: list[dict], features: list[str]):
    def rows_to_x(rows: list[dict]) -> np.ndarray:
        return np.asarray([[float(row[f]) for f in features] for row in rows], dtype=np.float32)

    X = np.concatenate([rows_to_x(fp_rows), rows_to_x(defect_rows)], axis=0)
    y = np.concatenate([np.zeros(len(fp_rows), dtype=np.int64), np.ones(len(defect_rows), dtype=np.int64)], axis=0)
    clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
    clf.fit(X, y)
    return clf


def save_results(rows: list[dict], summary: dict, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe AdaptCLIP region discriminant on VisA")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_official_vitl336_mvtec2visa_seed10" / "checkpoints" / "epoch_15.pth"),
    )
    parser.add_argument(
        "--fp_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_region_bank_holdout_epoch15" / "fp_rows.csv"),
    )
    parser.add_argument(
        "--defect_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_region_bank_holdout_epoch15" / "defect_rows.csv"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_region_discriminant_epoch15"),
    )
    parser.add_argument("--descriptor_combo", type=str, default="peak,mean,area,fill_ratio,compactness,ring_contrast")
    parser.add_argument("--candidate_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.25, 0.5, 0.75, 1.0])
    parser.add_argument("--modes", type=str, nargs="+", default=["gate", "dual"])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    descriptor_features = [x.strip() for x in args.descriptor_combo.split(",") if x.strip()]
    fp_rows = load_rows(Path(args.fp_csv))
    defect_rows = load_rows(Path(args.defect_csv))
    clf = fit_region_classifier(fp_rows, defect_rows, descriptor_features)

    model, textual_learner, visual_learner, learned_text_features = build_model(
        args.device, args.checkpoint_path, args.image_size, args.n_ctx, args.vl_reduction, args.pretrained_model
    )
    dataset = build_dataset(args.target_root, args.image_size, args.target_dataset)

    rows = []
    with torch.no_grad():
        for mode in args.modes:
            for alpha in args.alphas:
                image_labels, image_scores = [], []
                masks, maps = [], []
                normal_topk, normal_mean = [], []
                gaps, ratios, num_components, mean_probs = [], [], [], []

                for idx in range(len(dataset)):
                    item = dataset[idx]
                    image = item["img"].unsqueeze(0).to(args.device)
                    gt_mask = item["img_mask"][0].numpy() > 0.5
                    anomaly_flag = item["anomaly"]
                    if hasattr(anomaly_flag, "item"):
                        anomaly_flag = anomaly_flag.item()
                    anomaly_flag = int(anomaly_flag)

                    anomaly_map = compute_map(model, textual_learner, visual_learner, learned_text_features, image, args.features_list, args.sigma)
                    defect_prob_map = np.zeros_like(anomaly_map, dtype=np.float32)
                    covered = np.zeros_like(anomaly_map, dtype=bool)
                    comp_probs = []
                    for frac in args.candidate_fracs:
                        mask = top_fraction_mask(anomaly_map, frac)
                        for comp in iterate_components(mask):
                            if int(comp.sum()) < args.min_area:
                                continue
                            desc = extract_region_descriptor(anomaly_map, comp)
                            if not desc:
                                continue
                            X = np.asarray([[float(desc[f]) for f in descriptor_features]], dtype=np.float32)
                            prob = float(clf.predict_proba(X)[0, 1])
                            defect_prob_map[comp] = np.maximum(defect_prob_map[comp], prob)
                            covered |= comp
                            comp_probs.append(prob)
                    final_map = anomaly_map.copy()
                    if covered.any():
                        if mode == "gate":
                            factor = ((1.0 - alpha) + alpha * defect_prob_map)[covered]
                            final_map[covered] = anomaly_map[covered] * factor
                        elif mode == "dual":
                            factor = (defect_prob_map - alpha * (1.0 - defect_prob_map))[covered]
                            final_map[covered] = anomaly_map[covered] * factor
                        else:
                            raise ValueError(mode)

                    image_labels.append(anomaly_flag)
                    image_scores.append(topk_mean(final_map, args.image_score_topk))
                    masks.append(gt_mask)
                    maps.append(final_map)
                    num_components.append(len(comp_probs))
                    mean_probs.append(float(np.mean(comp_probs)) if comp_probs else 0.5)
                    if anomaly_flag == 0:
                        normal_topk.append(topk_mean(final_map, args.normal_topk_ratio))
                        normal_mean.append(float(final_map.mean()))
                    elif gt_mask.any() and (~gt_mask).any():
                        inside = float(final_map[gt_mask].mean())
                        outside = float(final_map[~gt_mask].mean())
                        gaps.append(inside - outside)
                        ratios.append(outside / (inside + 1e-6))

                rows.append(
                    {
                        "mode": mode,
                        "alpha": float(alpha),
                        "image_auroc": image_auroc(image_labels, image_scores),
                        "pixel_auroc": pixel_auroc(masks, maps),
                        "inside_outside_gap": float(np.mean(gaps)) if gaps else float("nan"),
                        "outside_inside_ratio": float(np.mean(ratios)) if ratios else float("nan"),
                        "normal_topk_mean": float(np.mean(normal_topk)) if normal_topk else float("nan"),
                        "normal_map_mean": float(np.mean(normal_mean)) if normal_mean else float("nan"),
                        "avg_num_components": float(np.mean(num_components)) if num_components else float("nan"),
                        "avg_mean_defect_prob": float(np.mean(mean_probs)) if mean_probs else float("nan"),
                    }
                )
                print(json.dumps({"stage": "region_discriminant_progress", "mode": mode, "alpha": alpha}), flush=True)

    summary = {
        "descriptor_features": descriptor_features,
        "num_fp_rows": len(fp_rows),
        "num_defect_rows": len(defect_rows),
        "checkpoint_path": args.checkpoint_path,
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"stage": "region_discriminant_saved", "save_dir": args.save_dir, "rows": rows}, indent=2), flush=True)


if __name__ == "__main__":
    main()
