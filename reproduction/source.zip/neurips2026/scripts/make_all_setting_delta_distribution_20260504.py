#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
IN_CSV = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables" / "adapted_host_b_t_c_records_20260502.csv"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR = ROOT / "figure"

METRICS = [
    ("p_auc", "P-AUC"),
    ("p_pro", "PRO"),
    ("p_ap", "AP"),
    ("avg", "Avg."),
]

HOST_COLORS = {
    "AA-CLIP": "#2F6F73",
    "AdaCLIP": "#B85450",
    "AdaptCLIP": "#7C6A3A",
    "BayesPFL": "#6F5C8C",
    "FAPrompt": "#D79A2B",
}


def load_rows() -> list[dict[str, object]]:
    by_setting: dict[tuple[str, str, str], dict[str, object]] = defaultdict(dict)
    with IN_CSV.open() as f:
        for row in csv.DictReader(f):
            metric = row.get("metric")
            if metric not in {"p_auc", "p_pro", "p_ap"}:
                continue
            delta = row.get("delta_c")
            if delta in (None, ""):
                continue
            key = (row["host"], row["backbone"], row["target"])
            by_setting[key]["host"] = row["host"]
            by_setting[key]["backbone"] = row["backbone"]
            by_setting[key]["target"] = row["target"]
            by_setting[key][metric] = float(delta)

    rows: list[dict[str, object]] = []
    for (host, backbone, target), vals in sorted(by_setting.items()):
        if not all(m in vals for m in ("p_auc", "p_pro", "p_ap")):
            continue
        vals["avg"] = float(np.mean([vals["p_auc"], vals["p_pro"], vals["p_ap"]]))
        rows.append(vals)
    return rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fieldnames = ["host", "backbone", "target", "p_auc", "p_pro", "p_ap", "avg"]
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})


def draw(rows: list[dict[str, object]]) -> dict[str, dict[str, float]]:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(7)
    fig, axes = plt.subplots(1, 4, figsize=(7.05, 2.05), sharey=True)
    stats: dict[str, dict[str, float]] = {}

    for ax, (metric, label) in zip(axes, METRICS):
        vals = np.array([float(row[metric]) for row in rows], dtype=float)
        hosts = [str(row["host"]) for row in rows]
        x = rng.normal(0.0, 0.055, size=len(vals))
        colors = [HOST_COLORS.get(h, "#777777") for h in hosts]

        ax.axhline(0.0, color="#2C2C2C", lw=0.8, zorder=0)
        ax.scatter(x, vals, s=15, c=colors, alpha=0.68, linewidths=0.0, zorder=2)

        mean = float(vals.mean())
        median = float(np.median(vals))
        pos_frac = float((vals > 0.0).mean())
        stats[metric] = {
            "n": float(len(vals)),
            "mean": mean,
            "median": median,
            "positive_fraction": pos_frac,
            "min": float(vals.min()),
            "max": float(vals.max()),
        }

        ax.plot([-0.18, 0.18], [mean, mean], color="#111111", lw=2.1, solid_capstyle="round", zorder=3)
        ax.plot([-0.16, 0.16], [median, median], color="#FFFFFF", lw=1.0, solid_capstyle="round", zorder=4)
        ax.text(
            0.0,
            0.96,
            f"{pos_frac * 100:.0f}% > 0",
            transform=ax.transAxes,
            ha="center",
            va="top",
            fontsize=7.2,
            fontweight="bold",
            color="#222222",
        )
        ax.set_title(label, fontsize=9.0, fontweight="bold", pad=3)
        ax.set_xlim(-0.28, 0.28)
        ax.set_xticks([])
        ax.grid(axis="y", color="#E5E0D7", lw=0.65)
        ax.set_axisbelow(True)
        for spine in ("top", "right", "bottom"):
            ax.spines[spine].set_visible(False)

    axes[0].set_ylabel(r"$\Delta$ over host baseline", fontsize=8.2, fontweight="bold")
    axes[0].tick_params(axis="y", labelsize=7.5)
    axes[0].set_ylim(-18, 43)

    handles = []
    labels = []
    for host, color in HOST_COLORS.items():
        if any(row["host"] == host for row in rows):
            handles.append(plt.Line2D([0], [0], marker="o", linestyle="", color=color, markersize=4.5, alpha=0.8))
            labels.append(host.replace("-CLIP", ""))
    fig.legend(
        handles,
        labels,
        loc="lower center",
        ncol=min(len(labels), 5),
        frameon=False,
        bbox_to_anchor=(0.5, -0.02),
        fontsize=7.0,
        handletextpad=0.25,
        columnspacing=0.8,
    )
    fig.suptitle("Paired C-TED gains across completed adapted-host settings", x=0.02, y=1.02, ha="left", fontsize=9.4, fontweight="bold")
    fig.tight_layout(rect=(0, 0.09, 1, 0.98), w_pad=0.65)

    out_pdf = FIG_DIR / "all_setting_cted_delta_distribution_20260504.pdf"
    out_png = FIG_DIR / "all_setting_cted_delta_distribution_20260504.png"
    fig.savefig(out_pdf, bbox_inches="tight")
    fig.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return stats


def write_tex(stats: dict[str, dict[str, float]]) -> None:
    tex = r"""\begin{figure}[t]
\centering
\includegraphics[width=1.0\columnwidth]{figure/all_setting_cted_delta_distribution_20260504.pdf}
\caption{
\textbf{Distribution of C-TED gains over all completed adapted-host settings.}
Each point is one host--backbone--target setting from the compact adapted-host evaluation, without filtering by whether TED improves it.
Black bars denote means and white ticks denote medians.
}
\label{fig:all_setting_cted_delta_distribution}
\end{figure}
"""
    (OUT_DIR / "all_setting_cted_delta_distribution_figure_20260504.tex").write_text(tex)


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = load_rows()
    write_csv(OUT_DIR / "all_setting_cted_delta_distribution_20260504.csv", rows)
    stats = draw(rows)
    (OUT_DIR / "all_setting_cted_delta_distribution_stats_20260504.json").write_text(json.dumps(stats, indent=2))
    write_tex(stats)
    print(
        json.dumps(
            {
                "rows": len(rows),
                "figure": "figure/all_setting_cted_delta_distribution_20260504.pdf",
                "stats": str((OUT_DIR / "all_setting_cted_delta_distribution_stats_20260504.json").relative_to(ROOT)),
                "tex": str((OUT_DIR / "all_setting_cted_delta_distribution_figure_20260504.tex").relative_to(ROOT)),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
