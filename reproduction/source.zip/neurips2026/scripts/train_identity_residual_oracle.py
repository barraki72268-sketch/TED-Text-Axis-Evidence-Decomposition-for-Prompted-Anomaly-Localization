from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import ndimage

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.identity_residual_extractor import IdentityResidualExtractor
from neurips2026.scripts.kinematic_text_axis_reconstruction import (
    build_recent_general_prompt_bank,
    encode_text_features,
)
from neurips2026.scripts.train_clip_aqm_oracle import (
    compute_consensus_loss,
    compute_zero_signal_loss,
    normalize_feat,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    forward_up_to_layer,
    patchify_sequence,
    safe_auc,
    score_promptmax,
    topk_mean,
)
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset
from utils.metrics import cal_pro_metric


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Identity-Residual oracle on frozen CLIP.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_specs", nargs="+", default=["capsules:12", "fryum:6"])
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_id_queries", type=int, default=32)
    parser.add_argument("--num_res_queries", type=int, default=32)
    parser.add_argument("--train_normal_images", type=int, default=12)
    parser.add_argument("--train_anomaly_images", type=int, default=12)
    parser.add_argument("--eval_normal_images", type=int, default=12)
    parser.add_argument("--eval_anomaly_images", type=int, default=12)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_id", type=float, default=1.0)
    parser.add_argument("--lambda_res", type=float, default=1.0)
    parser.add_argument("--lambda_ortho", type=float, default=1.0)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--pixel_blur_sigma", type=float, default=4.0)
    parser.add_argument("--selection_metric", type=str, default="prompt_image", choices=["prompt_image", "prompt_pixel"])
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_identity_residual_oracle")
    return parser.parse_args()


def parse_class_spec(spec: str) -> tuple[str, int]:
    class_name, layer = spec.split(":")
    return class_name, int(layer)


@dataclass
class Record:
    image_t: torch.Tensor
    patch_mask: np.ndarray
    pixel_mask: np.ndarray
    label: int
    name: str


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int]) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .numpy()
        .astype(np.int64)
    )


def resize_pixel_mask(mask_np: np.ndarray, target_size: int) -> np.ndarray:
    mask_u8 = (np.asarray(mask_np) > 0).astype(np.uint8) * 255
    return (
        np.asarray(Image.fromarray(mask_u8).resize((target_size, target_size), resample=Image.NEAREST)) > 0
    ).astype(np.uint8)


def collect_oracle_records(backbone, class_name: str, args: argparse.Namespace) -> tuple[list[Record], list[Record]]:
    train_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "train")
    test_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")

    train_norm_idx = list(range(min(args.train_normal_images, len(train_ds.records))))
    test_norm_idx = [i for i, rec in enumerate(test_ds.records) if rec["label"] == "normal"][: args.eval_normal_images]
    test_anom_all = [i for i, rec in enumerate(test_ds.records) if rec["label"] != "normal"]
    train_anom_idx = test_anom_all[: args.train_anomaly_images]
    eval_anom_idx = test_anom_all[args.train_anomaly_images : args.train_anomaly_images + args.eval_anomaly_images]

    def make_record(ds, idx: int) -> Record:
        image_np, mask_np, label, name, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).cpu()
        image_size = int(image_t.shape[-1])
        return Record(
            image_t=image_t,
            patch_mask=to_patch_mask(mask_np, backbone.grid_size),
            pixel_mask=resize_pixel_mask(mask_np, image_size),
            label=int(label != 0),
            name=name,
        )

    train_records = [make_record(train_ds, i) for i in train_norm_idx] + [make_record(test_ds, i) for i in train_anom_idx]
    eval_records = [make_record(test_ds, i) for i in test_norm_idx] + [make_record(test_ds, i) for i in eval_anom_idx]
    return train_records, eval_records


def build_identity_prompt_bank(class_name: str) -> tuple[list[str], list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    normal_prompts = [
        normal_prompt,
        f"a close-up inspection photo of a flawless {cls} with intact shape and clean surface.",
        f"a close-up inspection photo of a normal {cls} with no visible damage or abnormality.",
        f"a close-up inspection photo of an intact {cls} with complete structure and undamaged appearance.",
    ]
    return normal_prompts, abnormal_prompts


def stack_batch(records: list[Record]) -> tuple[torch.Tensor, torch.Tensor]:
    images = torch.cat([rec.image_t for rec in records], dim=0)
    masks = np.stack([rec.patch_mask.astype(np.int64) for rec in records], axis=0)
    return images, torch.from_numpy(masks)


def build_batches(records: list[Record], batch_size: int):
    order = np.random.permutation(len(records))
    for start in range(0, len(order), batch_size):
        idx = order[start : start + batch_size]
        yield [records[int(i)] for i in idx]


def compute_identity_support_loss(
    f_id: torch.Tensor,
    raw_patches: torch.Tensor,
    E_norm: torch.Tensor,
) -> torch.Tensor:
    raw_support = torch.matmul(normalize_feat(raw_patches), normalize_feat(E_norm).T).max(dim=-1).values.detach()
    raw_support = raw_support.clamp_min(0.0)
    if float(raw_support.sum().item()) <= 0.0:
        return torch.zeros([], device=f_id.device)
    id_support = torch.matmul(normalize_feat(f_id), normalize_feat(E_norm).T).max(dim=-1).values.clamp_min(0.0)
    return 1.0 - (id_support * raw_support).sum() / raw_support.sum().clamp_min(1e-6)


def compute_identity_residual_loss(
    outputs: dict[str, torch.Tensor],
    raw_patches: torch.Tensor,
    E_norm: torch.Tensor,
    E_anom: torch.Tensor,
    mask: torch.Tensor,
    hard_neg_ratio: float,
    topk_anom_ratio: float,
    lambda_id: float,
    lambda_res: float,
    lambda_ortho: float,
    lambda_zero: float,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    f_id = outputs["f_id"]
    f_res = outputs["f_res"]
    l_id = compute_identity_support_loss(f_id, raw_patches, E_norm)
    l_res = compute_consensus_loss(normalize_feat(f_res), normalize_feat(E_anom), mask, topk_ratio=topk_anom_ratio)
    l_ortho = outputs["loss_ortho"]
    l_zero = compute_zero_signal_loss(f_res, mask, hard_neg_ratio)
    total = float(lambda_id) * l_id + float(lambda_res) * l_res + float(lambda_ortho) * l_ortho + float(lambda_zero) * l_zero
    return total, {
        "l_id": l_id,
        "l_res": l_res,
        "l_ortho": l_ortho,
        "l_zero": l_zero,
    }


def patch_scores_to_pixel_map(scores: np.ndarray, target_size: int, blur_sigma: float) -> np.ndarray:
    side = int(round(np.sqrt(scores.shape[0])))
    if side * side != scores.shape[0]:
        raise ValueError(f"Cannot reshape patch scores of length {scores.shape[0]} into square grid.")
    score_t = torch.from_numpy(scores.reshape(1, 1, side, side)).float()
    pixel_map = F.interpolate(score_t, size=(target_size, target_size), mode="bilinear", align_corners=False)[
        0, 0
    ].cpu().numpy()
    if blur_sigma > 0:
        pixel_map = ndimage.gaussian_filter(pixel_map, sigma=float(blur_sigma))
    return pixel_map.astype(np.float32)


def safe_pixel_auc(score_maps: list[np.ndarray], gt_masks: list[np.ndarray]) -> float:
    if not score_maps or not gt_masks:
        return float("nan")
    score_arr = np.stack(score_maps, axis=0)
    gt_arr = np.stack(gt_masks, axis=0).astype(np.uint8)
    flat_gt = gt_arr.ravel()
    if flat_gt.min() == flat_gt.max():
        return float("nan")
    try:
        from sklearn.metrics import roc_auc_score

        return float(roc_auc_score(flat_gt, score_arr.ravel()))
    except Exception:
        return float("nan")


def safe_pro(score_maps: list[np.ndarray], gt_masks: list[np.ndarray]) -> float:
    if not score_maps or not gt_masks:
        return float("nan")
    gt_arr = np.stack(gt_masks, axis=0).astype(np.uint8)
    if gt_arr.max() <= 0:
        return float("nan")
    score_arr = np.stack(score_maps, axis=0).astype(np.float32)
    try:
        return float(cal_pro_metric(gt_arr, score_arr, fpr_thresh=0.3))
    except Exception:
        return float("nan")


def train_one_epoch(
    backbone,
    model: IdentityResidualExtractor,
    layer_idx: int,
    train_records: list[Record],
    E_norm: torch.Tensor,
    E_anom: torch.Tensor,
    p_norm: torch.Tensor,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
) -> dict[str, float]:
    model.train()
    loss_vals = []
    l_id_vals = []
    l_res_vals = []
    l_ortho_vals = []
    l_zero_vals = []
    for batch_records in build_batches(train_records, args.batch_size):
        image_t, mask = stack_batch(batch_records)
        image_t = image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        mask = mask.to(device)
        seq = forward_up_to_layer(backbone, image_t, layer_idx)
        _, patches = patchify_sequence(seq)
        outputs = model(patches, E_norm.to(device), E_anom=E_anom.to(device), return_aux=True)
        loss, parts = compute_identity_residual_loss(
            outputs,
            patches,
            E_norm.to(device),
            E_anom.to(device),
            mask,
            hard_neg_ratio=args.hard_neg_ratio,
            topk_anom_ratio=args.topk_anom_ratio,
            lambda_id=args.lambda_id,
            lambda_res=args.lambda_res,
            lambda_ortho=args.lambda_ortho,
            lambda_zero=args.lambda_zero,
        )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        loss_vals.append(float(loss.item()))
        l_id_vals.append(float(parts["l_id"].item()))
        l_res_vals.append(float(parts["l_res"].item()))
        l_ortho_vals.append(float(parts["l_ortho"].item()))
        l_zero_vals.append(float(parts["l_zero"].item()))
    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "train_loss_id": float(np.mean(l_id_vals)) if l_id_vals else float("nan"),
        "train_loss_res": float(np.mean(l_res_vals)) if l_res_vals else float("nan"),
        "train_loss_ortho": float(np.mean(l_ortho_vals)) if l_ortho_vals else float("nan"),
        "train_loss_zero": float(np.mean(l_zero_vals)) if l_zero_vals else float("nan"),
    }


def evaluate_model(
    backbone,
    model: IdentityResidualExtractor,
    layer_idx: int,
    eval_records: list[Record],
    E_norm: torch.Tensor,
    E_anom: torch.Tensor,
    p_norm: torch.Tensor,
    topk_ratio: float,
    batch_size: int,
    pixel_blur_sigma: float,
    device: str,
) -> dict[str, float]:
    model.eval()
    patch_labels = []
    base_patch_scores = []
    model_patch_scores = []
    image_labels = []
    base_image_scores = []
    model_image_scores = []
    gt_masks = []
    base_pixel_maps = []
    model_pixel_maps = []
    ortho_vals = []
    id_support_vals = []
    res_evidence_vals = []

    with torch.no_grad():
        for start in range(0, len(eval_records), batch_size):
            batch_records = eval_records[start : start + batch_size]
            image_t, mask = stack_batch(batch_records)
            image_t = image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            _, patches = patchify_sequence(seq)
            outputs = model(patches, E_norm.to(device), E_anom=E_anom.to(device), return_aux=True)

            base_scores = score_promptmax(patches, p_norm.to(device), E_anom.to(device))
            model_scores = outputs["score"].detach().cpu().numpy()

            for rec, rec_mask, bs, ms in zip(batch_records, mask.cpu().numpy(), base_scores, model_scores):
                patch_labels.extend(rec_mask.astype(np.int64).tolist())
                base_patch_scores.extend(bs.tolist())
                model_patch_scores.extend(ms.tolist())
                image_labels.append(rec.label)
                base_image_scores.append(topk_mean(np.asarray(bs), topk_ratio))
                model_image_scores.append(topk_mean(np.asarray(ms), topk_ratio))
                gt_masks.append(rec.pixel_mask)
                target_size = int(rec.pixel_mask.shape[0])
                base_pixel_maps.append(patch_scores_to_pixel_map(np.asarray(bs), target_size, pixel_blur_sigma))
                model_pixel_maps.append(patch_scores_to_pixel_map(np.asarray(ms), target_size, pixel_blur_sigma))

            ortho_vals.append(float(outputs["loss_ortho"].item()))
            id_support_vals.append(float(outputs["id_support"].mean().item()))
            res_evidence_vals.append(float(outputs["res_evidence"].mean().item()))

    base_patch_auc = safe_auc(patch_labels, base_patch_scores)
    model_patch_auc = safe_auc(patch_labels, model_patch_scores)
    base_image_auc = safe_auc(image_labels, base_image_scores)
    model_image_auc = safe_auc(image_labels, model_image_scores)
    base_pixel_auc = safe_pixel_auc(base_pixel_maps, gt_masks)
    model_pixel_auc = safe_pixel_auc(model_pixel_maps, gt_masks)
    base_p_pro = safe_pro(base_pixel_maps, gt_masks)
    model_p_pro = safe_pro(model_pixel_maps, gt_masks)
    return {
        "base_prompt_patch_auc": base_patch_auc,
        "idres_prompt_patch_auc": model_patch_auc,
        "prompt_patch_auc_delta": model_patch_auc - base_patch_auc,
        "base_prompt_image_auc": base_image_auc,
        "idres_prompt_image_auc": model_image_auc,
        "prompt_image_auc_delta": model_image_auc - base_image_auc,
        "base_prompt_pixel_auc": base_pixel_auc,
        "idres_prompt_pixel_auc": model_pixel_auc,
        "prompt_pixel_auc_delta": model_pixel_auc - base_pixel_auc,
        "base_prompt_p_pro": base_p_pro,
        "idres_prompt_p_pro": model_p_pro,
        "prompt_p_pro_delta": model_p_pro - base_p_pro,
        "eval_loss_ortho": float(np.mean(ortho_vals)) if ortho_vals else float("nan"),
        "eval_id_support_mean": float(np.mean(id_support_vals)) if id_support_vals else float("nan"),
        "eval_res_evidence_mean": float(np.mean(res_evidence_vals)) if res_evidence_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    details = []

    class_specs = [parse_class_spec(spec) for spec in args.class_specs]
    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        backbone.eval()
        for param in backbone.parameters():
            param.requires_grad_(False)

        for class_name, layer_idx in class_specs:
            train_records, eval_records = collect_oracle_records(backbone, class_name, args)
            normal_prompts, abnormal_prompts = build_identity_prompt_bank(class_name)
            E_norm = encode_text_features(backbone, backbone.tokenizer, normal_prompts)
            E_anom = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts)
            p_norm = normalize_feat(E_norm.mean(dim=0))

            model = IdentityResidualExtractor(
                dim=int(E_norm.shape[1]),
                num_id_queries=args.num_id_queries,
                num_res_queries=args.num_res_queries,
                detach_residual_input=True,
            ).to(device)
            token_params = [model.query_id, model.query_res]
            other_params = [p for n, p in model.named_parameters() if n not in {"query_id", "query_res"}]
            optimizer = torch.optim.AdamW(
                [
                    {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
                    {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
                ]
            )

            history = []
            best_state = None
            best_metric = -float("inf")
            for epoch in range(1, args.epochs + 1):
                train_stats = train_one_epoch(
                    backbone,
                    model,
                    layer_idx,
                    train_records,
                    E_norm.to(device),
                    E_anom.to(device),
                    p_norm.to(device),
                    args,
                    optimizer,
                    device,
                )
                eval_stats = evaluate_model(
                    backbone,
                    model,
                    layer_idx,
                    eval_records,
                    E_norm.to(device),
                    E_anom.to(device),
                    p_norm.to(device),
                    args.topk_ratio,
                    args.batch_size,
                    args.pixel_blur_sigma,
                    device,
                )
                history.append({"epoch": epoch, **train_stats, **eval_stats})
                metric_key = "idres_prompt_image_auc" if args.selection_metric == "prompt_image" else "idres_prompt_pixel_auc"
                if eval_stats[metric_key] > best_metric:
                    best_metric = eval_stats[metric_key]
                    best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}

            if best_state is None:
                continue

            model.load_state_dict(best_state)
            best_eval = evaluate_model(
                backbone,
                model,
                layer_idx,
                eval_records,
                E_norm.to(device),
                E_anom.to(device),
                p_norm.to(device),
                args.topk_ratio,
                args.batch_size,
                args.pixel_blur_sigma,
                device,
            )

            row = {
                "class_name": class_name,
                "layer": layer_idx,
                "backbone": backbone_name,
                "pretrained": pretrained_name,
                "img_size": img_size_i,
                "epochs": args.epochs,
                "num_id_queries": args.num_id_queries,
                "num_res_queries": args.num_res_queries,
                "selection_metric": args.selection_metric,
                "lambda_id": args.lambda_id,
                "lambda_res": args.lambda_res,
                "lambda_ortho": args.lambda_ortho,
                "lambda_zero": args.lambda_zero,
                **history[-1],
                **best_eval,
            }
            rows.append(row)
            details.append(
                {
                    "class_name": class_name,
                    "layer": layer_idx,
                    "history": history,
                    "best_eval": best_eval,
                }
            )

    stem = args.output_tag
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"args": vars(args), "rows": rows, "details": details}, f, indent=2)
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
