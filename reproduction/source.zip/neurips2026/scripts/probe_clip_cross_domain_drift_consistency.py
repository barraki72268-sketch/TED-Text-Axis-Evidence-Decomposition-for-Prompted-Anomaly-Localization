from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import PIL.Image
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


MVTEC_CLASSES = [
    "bottle",
    "cable",
    "capsule",
    "carpet",
    "grid",
    "hazelnut",
    "leather",
    "metal_nut",
    "pill",
    "screw",
    "tile",
    "toothbrush",
    "transistor",
    "wood",
    "zipper",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--visa_classes", nargs="*", default=[])
    parser.add_argument("--mvtec_classes", nargs="*", default=[])
    parser.add_argument("--inject_layer", type=int, default=1)
    parser.add_argument("--track_layers", nargs="+", type=int, default=[1, 3, 6, 9, 12])
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--subspace_k", type=int, default=4)
    parser.add_argument("--max_fit_anomaly_images", type=int, default=5)
    parser.add_argument("--max_eval_normal_images", type=int, default=5)
    parser.add_argument("--max_anomaly_patches", type=int, default=2048)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_cross_domain_drift_consistency")
    return parser.parse_args()


class SimpleMVTecDataset:
    def __init__(self, root: str, class_name: str, split: str = "test") -> None:
        self.root = Path(root)
        self.class_name = class_name
        self.split = split
        self.records = self._load_records()

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int):
        rec = self.records[idx]
        image = np.asarray(PIL.Image.open(rec["image_path"]).convert("RGB"), dtype=np.uint8)
        if rec["mask_path"] is None:
            mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
        else:
            mask = np.asarray(PIL.Image.open(rec["mask_path"]).convert("L"), dtype=np.uint8)
            mask = (mask > 0).astype(np.uint8) * 255
        return image, mask, rec["label"], rec["name"], rec["anomaly"]

    def _load_records(self) -> list[dict]:
        image_dir = self.root / self.class_name / self.split
        mask_dir = self.root / self.class_name / "ground_truth"
        records: list[dict] = []
        for img_type in sorted(p.name for p in image_dir.iterdir() if p.is_dir()):
            type_dir = image_dir / img_type
            image_paths = sorted(type_dir.glob("*.png"))
            if img_type == "good":
                for path in image_paths:
                    records.append(
                        {
                            "image_path": str(path),
                            "mask_path": None,
                            "label": 0,
                            "anomaly": "good",
                            "name": f"{self.class_name}-good-{path.stem}",
                        }
                    )
            else:
                gt_dir = mask_dir / img_type
                for path in image_paths:
                    mask_path = gt_dir / f"{path.stem}_mask.png"
                    records.append(
                        {
                            "image_path": str(path),
                            "mask_path": str(mask_path),
                            "label": 1,
                            "anomaly": img_type,
                            "name": f"{self.class_name}-{img_type}-{path.stem}",
                        }
                    )
        return records


def list_visa_classes(split_csv: str) -> list[str]:
    csv_data = pd.read_csv(Path(split_csv))
    return list(dict.fromkeys(csv_data["object"].tolist()))


def build_token_normal_anchor(backbone, class_name: str) -> torch.Tensor:
    prompts: list[str] = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = backbone.visual.proj.detach().float().to(text_anchor.device)
    token_anchor = proj @ text_anchor
    return F.normalize(token_anchor, dim=0)


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> torch.Tensor:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .to(dtype=torch.bool)
    )


def maybe_subsample(tokens: torch.Tensor, max_count: int) -> torch.Tensor:
    if max_count <= 0 or tokens.shape[0] <= max_count:
        return tokens
    idx = torch.linspace(0, tokens.shape[0] - 1, steps=max_count, device=tokens.device).round().long()
    return tokens[idx]


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    v_proj = (v @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return v.float() - v_proj


def forward_up_to_layer(model, image: torch.Tensor, layer_idx: int, return_sequence: bool = False):
    sequence = model.prepare_sequence(image)
    seq_mid = model.run_blocks(sequence, start_layer=1, end_layer=layer_idx)
    tokens_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
    if return_sequence:
        return tokens_mid, seq_mid
    return tokens_mid


def run_remaining_with_capture(
    model,
    v_mid: torch.Tensor,
    cls_token: torch.Tensor,
    start_layer: int,
    target_layers: list[int],
) -> dict[int, torch.Tensor]:
    if not target_layers:
        return {}
    batch_seq = torch.cat([cls_token, v_mid], dim=1)
    sequence = batch_seq.permute(1, 0, 2)
    outputs: dict[int, torch.Tensor] = {}

    def capture(block_idx: int, x: torch.Tensor) -> torch.Tensor:
        if block_idx in target_layers:
            outputs[block_idx] = x.permute(1, 0, 2)[:, 1:, :].float()
        return x

    model.run_blocks(sequence, start_layer=start_layer, end_layer=max(target_layers), layer_callback=capture)
    return outputs


def inject_kinematic_signal(v_mid: torch.Tensor, p_norm: torch.Tensor, V_anom: torch.Tensor, alpha: float) -> torch.Tensor:
    r_mid = get_null_space_residual(v_mid, p_norm)
    delta_v = torch.matmul(torch.matmul(r_mid, V_anom), V_anom.T)
    return v_mid + float(alpha) * delta_v


def get_dataset(domain: str, root: str, split_csv: str, class_name: str):
    if domain == "visa":
        return OfficialVisAWinClipDataset(root, split_csv, class_name, "test")
    if domain == "mvtec":
        return SimpleMVTecDataset(root, class_name, "test")
    raise ValueError(domain)


def is_anomaly_record(rec: dict) -> bool:
    label = rec["label"]
    if isinstance(label, str):
        return label != "normal"
    return int(label) != 0


def is_normal_record(rec: dict) -> bool:
    return not is_anomaly_record(rec)


def extract_anomaly_subspace(
    backbone,
    domain: str,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    layer_idx: int,
    max_images: int,
    max_patches: int,
    subspace_k: int,
) -> torch.Tensor:
    ds = get_dataset(domain, dataset_root, split_csv, class_name)
    anomaly_indices = [i for i, rec in enumerate(ds.records) if is_anomaly_record(rec)][:max_images]
    collected: list[torch.Tensor] = []
    for idx in anomaly_indices:
        image_np, mask_np, label, _, _ = ds[idx]
        assert label == 1
        image_t = backbone.transform_pil(PIL.Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        tokens = forward_up_to_layer(backbone, image_t, layer_idx)
        patch_mask = to_patch_mask(mask_np, backbone.grid_size, backbone.device)
        if int(patch_mask.sum().item()) == 0:
            continue
        collected.append(tokens[0][patch_mask].detach())
    if not collected:
        raise RuntimeError(f"No anomaly patches collected for {domain}:{class_name}")
    patches = maybe_subsample(torch.cat(collected, dim=0), max_patches)
    residual = get_null_space_residual(patches, p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:subspace_k].T.contiguous()


def safe_cosine(a: torch.Tensor, b: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    a_norm = torch.linalg.vector_norm(a, dim=-1)
    b_norm = torch.linalg.vector_norm(b, dim=-1)
    valid = (a_norm > eps) & (b_norm > eps)
    out = torch.full_like(a_norm, float("nan"))
    if valid.any():
        out[valid] = F.cosine_similarity(a[valid], b[valid], dim=-1)
    return out


def compute_layer_metrics(
    delta_init: torch.Tensor,
    delta_cur: torch.Tensor,
    p_norm: torch.Tensor,
    V_anom: torch.Tensor,
) -> dict[str, float]:
    delta_init_null = get_null_space_residual(delta_init, p_norm)
    delta_cur_null = get_null_space_residual(delta_cur, p_norm)
    init_total = torch.linalg.vector_norm(delta_init_null, dim=-1)
    cur_total = torch.linalg.vector_norm(delta_cur_null, dim=-1)
    init_sub = torch.linalg.vector_norm(delta_init_null @ V_anom, dim=-1)
    cur_sub = torch.linalg.vector_norm(delta_cur_null @ V_anom, dim=-1)
    proj_cur = torch.matmul(torch.matmul(delta_cur_null, V_anom), V_anom.T)
    cos_to_init = safe_cosine(delta_cur_null, delta_init_null)
    cos_to_subspace = safe_cosine(delta_cur_null, proj_cur)
    semantic_leak = torch.abs(delta_cur @ p_norm)
    cos_init_arr = cos_to_init[torch.isfinite(cos_to_init)]
    cos_sub_arr = cos_to_subspace[torch.isfinite(cos_to_subspace)]
    init_total_mean = float(init_total.mean().item())
    init_sub_mean = float(init_sub.mean().item())
    cur_total_mean = float(cur_total.mean().item())
    cur_sub_mean = float(cur_sub.mean().item())
    return {
        "total_retention_ratio": cur_total_mean / max(init_total_mean, 1e-8),
        "subspace_retention_ratio": cur_sub_mean / max(init_sub_mean, 1e-8),
        "cos_to_init_mean": float(cos_init_arr.mean().item()) if cos_init_arr.numel() > 0 else float("nan"),
        "cos_to_subspace_mean": float(cos_sub_arr.mean().item()) if cos_sub_arr.numel() > 0 else float("nan"),
        "semantic_leak_mean": float(semantic_leak.mean().item()),
    }


def evaluate_class(
    backbone,
    domain: str,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    V_anom: torch.Tensor,
    inject_layer: int,
    track_layers: list[int],
    alpha: float,
    max_eval_normal_images: int,
) -> list[dict[str, float | str | int]]:
    ds = get_dataset(domain, dataset_root, split_csv, class_name)
    normal_indices = [i for i, rec in enumerate(ds.records) if is_normal_record(rec)][:max_eval_normal_images]
    metric_lists: dict[int, list[dict[str, float]]] = {layer: [] for layer in track_layers}

    for idx in normal_indices:
        image_np, _, label, _, _ = ds[idx]
        assert label == 0
        image_t = backbone.transform_pil(PIL.Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            _, seq_mid = forward_up_to_layer(backbone, image_t, inject_layer, return_sequence=True)
            cls_token = seq_mid.permute(1, 0, 2)[:, :1, :].float()
            v_base_l1 = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
            v_inj_l1 = inject_kinematic_signal(v_base_l1, p_norm, V_anom, alpha)
            future_layers = [layer for layer in track_layers if layer > inject_layer]
            base_caps = run_remaining_with_capture(backbone, v_base_l1, cls_token, inject_layer + 1, future_layers)
            inj_caps = run_remaining_with_capture(backbone, v_inj_l1, cls_token, inject_layer + 1, future_layers)

        base_by_layer = {inject_layer: v_base_l1[0].cpu()}
        inj_by_layer = {inject_layer: v_inj_l1[0].cpu()}
        for layer in future_layers:
            base_by_layer[layer] = base_caps[layer][0].cpu()
            inj_by_layer[layer] = inj_caps[layer][0].cpu()

        delta_init = inj_by_layer[inject_layer] - base_by_layer[inject_layer]
        for layer in track_layers:
            delta_cur = inj_by_layer[layer] - base_by_layer[layer]
            metric_lists[layer].append(compute_layer_metrics(delta_init, delta_cur, p_norm.cpu(), V_anom.cpu()))

    rows: list[dict[str, float | str | int]] = []
    for layer in track_layers:
        row: dict[str, float | str | int] = {
            "domain": domain,
            "class_name": class_name,
            "inject_layer": inject_layer,
            "track_layer": layer,
            "alpha": float(alpha),
            "subspace_k": int(V_anom.shape[1]),
            "num_eval_normals": len(metric_lists[layer]),
        }
        keys = metric_lists[layer][0].keys()
        for key in keys:
            vals = np.asarray([m[key] for m in metric_lists[layer]], dtype=np.float64)
            row[f"{key}_mean"] = float(np.nanmean(vals))
            row[f"{key}_std"] = float(np.nanstd(vals))
        rows.append(row)
    return rows


def aggregate_domain_rows(rows: list[dict[str, float | str | int]]) -> list[dict[str, float | str | int]]:
    out: list[dict[str, float | str | int]] = []
    domains = sorted({str(r["domain"]) for r in rows})
    layers = sorted({int(r["track_layer"]) for r in rows})
    metric_keys = [
        "total_retention_ratio_mean",
        "subspace_retention_ratio_mean",
        "cos_to_init_mean_mean",
        "cos_to_subspace_mean_mean",
        "semantic_leak_mean_mean",
    ]
    for domain in domains:
        for layer in layers:
            group = [r for r in rows if str(r["domain"]) == domain and int(r["track_layer"]) == layer]
            row: dict[str, float | str | int] = {"domain": domain, "track_layer": layer, "num_classes": len(group)}
            for key in metric_keys:
                vals = np.asarray([float(r[key]) for r in group], dtype=np.float64)
                row[key] = float(np.nanmean(vals))
                row[f"{key}_std"] = float(np.nanstd(vals))
            out.append(row)
    return out


def compute_domain_similarity(domain_rows: list[dict[str, float | str | int]]) -> dict[str, float]:
    metrics = [
        "total_retention_ratio_mean",
        "subspace_retention_ratio_mean",
        "cos_to_init_mean_mean",
        "cos_to_subspace_mean_mean",
        "semantic_leak_mean_mean",
    ]
    visa_rows = sorted([r for r in domain_rows if r["domain"] == "visa"], key=lambda x: int(x["track_layer"]))
    mvtec_rows = sorted([r for r in domain_rows if r["domain"] == "mvtec"], key=lambda x: int(x["track_layer"]))
    out: dict[str, float] = {}
    for metric in metrics:
        x = np.asarray([float(r[metric]) for r in visa_rows], dtype=np.float64)
        y = np.asarray([float(r[metric]) for r in mvtec_rows], dtype=np.float64)
        if x.size == y.size and x.size > 1:
            out[f"{metric}_pearson"] = float(np.corrcoef(x, y)[0, 1])
        else:
            out[f"{metric}_pearson"] = float("nan")
    return out


def plot_domain_curves(domain_rows: list[dict[str, float | str | int]], out_dir: Path, stem: str) -> None:
    metrics = [
        ("total_retention_ratio_mean", "Total Retention"),
        ("subspace_retention_ratio_mean", "Subspace Retention"),
        ("cos_to_init_mean_mean", "Direction Cosine To L1"),
        ("cos_to_subspace_mean_mean", "Subspace Alignment Cosine"),
        ("semantic_leak_mean_mean", "Semantic Leak"),
    ]
    domains = sorted({str(r["domain"]) for r in domain_rows})
    layers = sorted({int(r["track_layer"]) for r in domain_rows})
    for metric_key, title in metrics:
        plt.figure(figsize=(6.2, 4.0))
        for domain in domains:
            subset = [r for r in domain_rows if str(r["domain"]) == domain]
            subset = sorted(subset, key=lambda x: int(x["track_layer"]))
            xs = [int(r["track_layer"]) for r in subset]
            ys = [float(r[metric_key]) for r in subset]
            plt.plot(xs, ys, marker="o", label=domain)
        plt.xticks(layers)
        plt.xlabel("Tracked Layer")
        plt.ylabel(title)
        plt.title(title)
        plt.grid(alpha=0.25)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / f"{stem}_{metric_key}.png", dpi=200)
        plt.close()


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    track_layers = sorted(set(args.track_layers + [args.inject_layer]))
    visa_classes = args.visa_classes or list_visa_classes(args.visa_split_csv)
    mvtec_classes = args.mvtec_classes or MVTEC_CLASSES
    rows: list[dict[str, float | str | int]] = []
    class_configs: list[dict[str, object]] = []
    skipped: list[dict[str, str]] = []

    for domain, root, split_csv, class_names in [
        ("visa", args.visa_root, args.visa_split_csv, visa_classes),
        ("mvtec", args.mvtec_root, "", mvtec_classes),
    ]:
        for class_name in class_names:
            p_norm = build_token_normal_anchor(backbone, class_name).to(backbone.device)
            try:
                V_anom = extract_anomaly_subspace(
                    backbone=backbone,
                    domain=domain,
                    dataset_root=root,
                    split_csv=split_csv,
                    class_name=class_name,
                    p_norm=p_norm,
                    layer_idx=args.inject_layer,
                    max_images=args.max_fit_anomaly_images,
                    max_patches=args.max_anomaly_patches,
                    subspace_k=args.subspace_k,
                ).to(backbone.device)
            except RuntimeError as exc:
                skipped.append({"domain": domain, "class_name": class_name, "reason": str(exc)})
                continue
            class_rows = evaluate_class(
                backbone=backbone,
                domain=domain,
                dataset_root=root,
                split_csv=split_csv,
                class_name=class_name,
                p_norm=p_norm,
                V_anom=V_anom,
                inject_layer=args.inject_layer,
                track_layers=track_layers,
                alpha=args.alpha,
                max_eval_normal_images=args.max_eval_normal_images,
            )
            rows.extend(class_rows)
            class_configs.append(
                {
                    "domain": domain,
                    "class_name": class_name,
                    "subspace_k": int(args.subspace_k),
                    "p_norm_norm": float(torch.linalg.vector_norm(p_norm).item()),
                    "V_anom_shape": list(V_anom.shape),
                }
            )

    domain_rows = aggregate_domain_rows(rows)
    similarity = compute_domain_similarity(domain_rows)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_visa{len(visa_classes)}_mvtec{len(mvtec_classes)}_L{args.inject_layer}"
    summary_csv = out_dir / f"{stem}_class_summary.csv"
    domain_csv = out_dir / f"{stem}_domain_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"

    with summary_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with domain_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(domain_rows[0].keys()))
        writer.writeheader()
        writer.writerows(domain_rows)
    with json_path.open("w") as f:
        json.dump(
            {
                "config": vars(args),
                "class_configs": class_configs,
                "skipped": skipped,
                "domain_similarity": similarity,
                "domain_rows": domain_rows,
            },
            f,
            indent=2,
        )
    plot_domain_curves(domain_rows, out_dir, stem)
    print(summary_csv)
    print(domain_csv)
    print(json_path)
    print(json.dumps({"skipped": skipped, "domain_similarity": similarity, "domain_rows": domain_rows}, indent=2))


if __name__ == "__main__":
    main()
