from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PYTHON = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_adaptclip_vlrefine.py"
RESULTS = ROOT / "neurips2026" / "results"
BANK_ROOT = RESULTS / "bank_cache"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"

TRANSFERS = {
    "mvtec2visa": (MVTEC_ROOT, "mvtec", VISA_ROOT, "visa", MVTEC_CKPT),
    "mvtec2mpdd": (MVTEC_ROOT, "mvtec", MPDD_ROOT, "mpdd", MVTEC_CKPT),
    "mvtec2btad": (MVTEC_ROOT, "mvtec", BTAD_ROOT, "btad", MVTEC_CKPT),
    "visa2mvtec": (VISA_ROOT, "visa", MVTEC_ROOT, "mvtec", VISA_CKPT),
}

BACKBONES = {
    "vitl336": {
        "pretrained_model": "ViT-L/14@336px",
        "checkpoint_load_mode": "strict",
        "features_list": [24],
    },
    "vitl14openai": {
        "pretrained_model": "/home/jinyoung/.cache/clip/ViT-L-14.pt",
        "checkpoint_load_mode": "strict",
        "features_list": [24],
    },
    "vitb16plus": {
        "pretrained_model": "VITB16_PLUS_240",
        "checkpoint_load_mode": "compatible",
        "features_list": [12],
    },
    "vith14": {
        "pretrained_model": "ViT-H-14",
        "checkpoint_load_mode": "compatible",
        "features_list": [32],
    },
}


def csv(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def run_cmd(backbone: str, transfer: str, seed: int, device: str, args: argparse.Namespace) -> tuple[Path, list[str]]:
    source_root, source_dataset, target_root, target_dataset, ckpt = TRANSFERS[transfer]
    cfg = BACKBONES[backbone]
    save_dir = RESULTS / f"adaptclip_dualbranch_{backbone}_{transfer}_seed{seed}_20260429"
    bank = BANK_ROOT / f"adaptclip_dualbranch_{backbone}_{source_dataset}_vl_seed{seed}.pt"
    tl_bank = BANK_ROOT / f"adaptclip_dualbranch_{backbone}_{source_dataset}_tl_seed{seed}.pt"
    cmd = [
        str(PYTHON),
        "-u",
        str(SCRIPT),
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(ckpt),
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank),
        "--tl_bank_cache_path",
        str(tl_bank),
        "--pretrained_model",
        cfg["pretrained_model"],
        "--checkpoint_load_mode",
        cfg["checkpoint_load_mode"],
        "--features_list",
        *[str(x) for x in cfg["features_list"]],
        "--image_size",
        "518",
        "--batch_size",
        "1",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        str(args.fp_weight),
        "--corr_alpha",
        str(args.corr_alpha),
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--ted_insertion",
        "dual_branch",
        "--calib_epochs",
        "0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        str(args.rank),
        "--calib_lambda",
        str(args.calib_lambda),
        "--calib_score_mode",
        "rankr_density",
        "--calib_rankr_tau",
        str(args.rankr_tau),
        "--calib_apply_mode",
        "add",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
        "--seed",
        str(seed),
        "--device",
        device,
        "--num_workers",
        str(args.num_workers),
    ]
    return save_dir, cmd


def main() -> None:
    parser = argparse.ArgumentParser("Queue AdaptCLIP dual-branch TED runs.")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--backbones", default="vitl336")
    parser.add_argument("--transfers", default="mvtec2visa,mvtec2mpdd,mvtec2btad,visa2mvtec")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--rank", type=int, default=2)
    parser.add_argument("--rankr_tau", type=float, default=0.1)
    parser.add_argument("--corr_alpha", type=float, default=0.3)
    parser.add_argument("--calib_lambda", type=float, default=0.005)
    parser.add_argument("--fp_weight", type=float, default=0.3)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--stop_after", type=int, default=0)
    args = parser.parse_args()

    jobs = []
    for backbone in csv(args.backbones):
        if backbone not in BACKBONES:
            raise ValueError(f"Unknown backbone: {backbone}")
        for transfer in csv(args.transfers):
            if transfer not in TRANSFERS:
                raise ValueError(f"Unknown transfer: {transfer}")
            for seed_str in csv(args.seeds):
                jobs.append((backbone, transfer, int(seed_str)))

    if args.stop_after > 0:
        jobs = jobs[: args.stop_after]

    for backbone, transfer, seed in jobs:
        save_dir, cmd = run_cmd(backbone, transfer, seed, args.device, args)
        summary = save_dir / "summary.json"
        if summary.exists():
            print(f"[skip] {backbone} {transfer} seed{seed}: {summary}", flush=True)
            continue
        print(f"[run] {backbone} {transfer} seed{seed}: {save_dir}", flush=True)
        subprocess.run(cmd, cwd=str(ROOT), check=True)


if __name__ == "__main__":
    main()
