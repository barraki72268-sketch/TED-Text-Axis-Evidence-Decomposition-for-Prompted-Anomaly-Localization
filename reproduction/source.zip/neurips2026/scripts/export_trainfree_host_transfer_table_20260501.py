#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Callable, Iterable


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT_DIR = RESULTS / "final_metric_and_novelty_tables"

TARGETS = ("MVTec", "VisA", "MPDD", "BTAD")
TRANSFER_BY_TARGET = {
    "MVTec": "visa2mvtec",
    "VisA": "mvtec2visa",
    "MPDD": "mvtec2mpdd",
    "BTAD": "mvtec2btad",
}
METRICS = ("pixel_auc", "pixel_ap", "pixel_aupro", "image_auc")


def load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(value: float | None) -> float | None:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return None
    return float(value) * 100.0 if abs(float(value)) <= 1.5 else float(value)


def metric_value(metrics: dict, key: str) -> float | None:
    if key == "pixel_aupro":
        return pct(metrics.get("pixel_aupro", metrics.get("pixel_pro")))
    return pct(metrics.get(key))


def mean_values(items: list[list[float | None]]) -> list[float | None] | None:
    if not items:
        return None
    out: list[float | None] = []
    for col in zip(*items):
        vals = [float(x) for x in col if x is not None]
        out.append(sum(vals) / len(vals) if vals else None)
    return out


def row_mode(summary: dict | None, mode: str) -> list[float | None] | None:
    if summary is None:
        return None
    candidates = [
        row
        for row in summary.get("rows", [])
        if row.get("target_label") == "mean" and row.get("mode") == mode
    ]
    if not candidates:
        return None
    row = candidates[0]
    return [metric_value(row, key) for key in METRICS]


def mean_mode(summary: dict | None, mode: str) -> list[float | None] | None:
    if summary is None:
        return None
    mean = summary.get("mean", summary)
    if mode == "baseline":
        metrics = mean.get("baseline")
    elif mode == "parallel":
        metrics = mean.get("parallel")
    elif mode == "baseline_official":
        metrics = mean.get("baseline_official")
    else:
        metrics = None
    if not isinstance(metrics, dict):
        return None
    return [metric_value(metrics, key) for key in METRICS]


def aggregate(paths: Iterable[Path], extractor: Callable[[dict | None], list[float | None] | None]) -> list[float | None] | None:
    values: list[list[float | None]] = []
    for path in paths:
        vals = extractor(load_json(path))
        if vals is not None:
            values.append(vals)
    return mean_values(values)


def bold_pair(base: list[float | None] | None, ours: list[float | None] | None) -> tuple[str, str]:
    if base is None or ours is None:
        return "--.-- / --.-- / --.-- / --.--", "--.-- / --.-- / --.-- / --.--"
    base_parts: list[str] = []
    ours_parts: list[str] = []
    for b, o in zip(base, ours):
        b_txt = "--.--" if b is None else f"{b:.2f}"
        o_txt = "--.--" if o is None else f"{o:.2f}"
        if b is not None and o is not None:
            if o > b:
                o_txt = rf"\textbf{{{o_txt}}}"
            elif b > o:
                b_txt = rf"\textbf{{{b_txt}}}"
        base_parts.append(b_txt)
        ours_parts.append(o_txt)
    return " / ".join(base_parts), " / ".join(ours_parts)


def shortstack_cell(text: str, note: str | None) -> str:
    if note is None:
        return text
    return rf"\shortstack{{{text}\\{{\scriptsize {note}}}}}"


def faprompt_path(backbone_key: str, target: str) -> Path:
    preset = {
        "MVTec": "visa2mvtec",
        "VisA": "mvtec2visa",
        "MPDD": "visa2mpdd",
        "BTAD": "visa2btad",
    }[target]
    rows = {
        "vitb": {
            "MVTec": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2mvtec_full_v1" / "summary.json",
            "VisA": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_mvtec2visa_full_20260427" / "summary.json",
            "MPDD": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2mpdd_full_20260427" / "summary.json",
            "BTAD": RESULTS / "faprompt_backbone_swap_vitb_prescore_hostaxis_visa2btad_full_20260427" / "summary.json",
        },
        "vith": {
            target_name: RESULTS / f"faprompt_vith14_prescore_hostaxis_{preset_name}_fast_20260427" / "summary.json"
            for target_name, preset_name in {
                "MVTec": "visa2mvtec",
                "VisA": "mvtec2visa",
                "MPDD": "visa2mpdd",
                "BTAD": "visa2btad",
            }.items()
        },
        "vitl_openai": {
            target_name: RESULTS / f"faprompt_vitl14openai_prescore_hostaxis_{preset_name}_fast_20260427" / "summary.json"
            for target_name, preset_name in {
                "MVTec": "visa2mvtec",
                "VisA": "mvtec2visa",
                "MPDD": "visa2mpdd",
                "BTAD": "visa2btad",
            }.items()
        },
    }
    _ = preset
    return rows[backbone_key][target]


def faprompt_values(backbone_key: str, target: str) -> tuple[list[float | None] | None, list[float | None] | None, str | None]:
    data = load_json(faprompt_path(backbone_key, target))
    if data is None:
        return None, None, None
    mean = data.get("mean", {})
    base_metrics = mean.get("baseline_official")
    candidates = {
        key: value
        for key, value in mean.get("parallel", {}).items()
        if key.startswith("prescore_rectify_alpha_")
    }
    if not isinstance(base_metrics, dict) or not candidates:
        return None, None, None
    best_name, best_metrics = max(candidates.items(), key=lambda item: metric_value(item[1], "pixel_auc") or -1e9)
    alpha = best_name.replace("prescore_rectify_alpha_", r"$\alpha=") + "$"
    return (
        [metric_value(base_metrics, key) for key in METRICS],
        [metric_value(best_metrics, key) for key in METRICS],
        alpha,
    )


def aaclip_paths(backbone_key: str, target: str) -> list[Path]:
    tag = {
        "vitb": "vitbplus",
        "vitl_openai": "vitl_openai224",
        "vitl336": "vitl336",
        "vith": "vith14",
    }[backbone_key]
    transfer = TRANSFER_BY_TARGET[target]
    paths = [RESULTS / f"aaclip_hostres_official_{tag}_{transfer}_seed{seed}_pro_20260428" / "summary.json" for seed in range(3)]
    if backbone_key == "vitb" and target == "BTAD":
        paths[0] = RESULTS / "aaclip_vitbplus_l3-6-9-12_mvtec2btad_subspace_hostres_rank8_preserve1_pro_20260428" / "summary.json"
    return paths


def adaptclip_paths(backbone_key: str, target: str) -> list[Path]:
    tag = {
        "vitb": "vitb16plus",
        "vitl_openai": "vitl14openai",
        "vitl336": "vitl336",
        "vith": "vith14",
    }[backbone_key]
    transfer = TRANSFER_BY_TARGET[target]
    return [RESULTS / f"adaptclip_dualbranch_{tag}_{transfer}_seed{seed}_20260429" / "summary.json" for seed in range(3)]


def adaclip_paths(backbone_key: str, target: str) -> list[Path]:
    tag = {
        "vitb": "vitb16",
        "vitl_openai": "vitl14openai",
        "vitl336": "vitl336",
        "vith": "vith14",
    }[backbone_key]
    transfer = TRANSFER_BY_TARGET[target]
    return [RESULTS / f"maintable_adaclip_{tag}_{transfer}_seed{seed}_20260429" / "summary.json" for seed in range(3)]


def anomalyclip_paths(backbone_key: str, target: str) -> list[Path]:
    transfer = TRANSFER_BY_TARGET[target]
    if backbone_key == "vitl336":
        return [RESULTS / "anomalyclip_ted_trainfree_anchor_seeded_20260430" / f"{transfer}_seed{seed}" / "summary.json" for seed in range(3)]
    tag = {
        "vitb": "vitb16_projected",
        "vitl_openai": "vitl_openai",
        "vith": "vith14_projected",
    }[backbone_key]
    return [RESULTS / "anomalyclip_ted_backbone_swap_seeded_20260430" / f"{tag}_{transfer}_seed{seed}" / "summary.json" for seed in range(3)]


def bayespfl_paths(backbone_key: str, target: str) -> list[Path]:
    transfer = {"MVTec": "mvtec2mvtec", "VisA": "mvtec2visa", "MPDD": "mvtec2mpdd", "BTAD": "mvtec2btad"}[target]
    root = {
        "vitb": RESULTS / "bayespfl_ted_vitbplus_swap_seeded_20260501",
        "vitl_openai": RESULTS / "bayespfl_ted_vitl_openai_swap_seeded_20260430",
        "vitl336": RESULTS / "bayespfl_ted_official_mvtecsource_seeded_20260430",
        "vith": RESULTS / "bayespfl_ted_vith14_swap_seeded_20260501",
    }[backbone_key]
    return [root / f"{transfer}_seed{seed}" / "summary.json" for seed in range(3)]


def aggregate_mean_host(paths: list[Path], base_mode: str, ours_mode: str) -> tuple[list[float | None] | None, list[float | None] | None]:
    base = aggregate(paths, lambda d: mean_mode(d, base_mode))
    ours = aggregate(paths, lambda d: mean_mode(d, ours_mode))
    return base, ours


def aggregate_row_host(paths: list[Path], base_mode: str, ours_mode: str) -> tuple[list[float | None] | None, list[float | None] | None]:
    base = aggregate(paths, lambda d: row_mode(d, base_mode))
    ours = aggregate(paths, lambda d: row_mode(d, ours_mode))
    return base, ours


def render_host(host: str, rows: list[tuple[str, str]], getter) -> list[str]:
    lines: list[str] = [rf"\multirow{{{len(rows)}}}{{*}}{{{host}}}"]
    for idx, (key, label) in enumerate(rows):
        cells: list[str] = []
        for target in TARGETS:
            base, ours, note = getter(key, target)
            base_txt, ours_txt = bold_pair(base, ours)
            cells.extend([base_txt, shortstack_cell(ours_txt, note)])
        prefix = " & " if idx > 0 else ""
        lines.append(prefix + label + " & " + " & ".join(cells) + r" \\")
    return lines


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    table_lines: list[str] = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Dataset-wise train-free TED results under host/backbone transfer. Each cell reports P-AUROC / P-AP / P-PRO / I-AUROC.}",
        r"\label{tab:host_backbone_transfer_trainfree_datasetwise}",
        r"\resizebox{\textwidth}{!}{",
        r"\begin{tabular}{llcccccccc}",
        r"\toprule",
        r"& & \multicolumn{2}{c}{MVTec} & \multicolumn{2}{c}{VisA} & \multicolumn{2}{c}{MPDD} & \multicolumn{2}{c}{BTAD} \\",
        r"\cmidrule(lr){3-4} \cmidrule(lr){5-6} \cmidrule(lr){7-8} \cmidrule(lr){9-10}",
        r"Host & Backbone & Base & T-TED & Base & T-TED & Base & T-TED & Base & T-TED \\",
        r"\midrule",
    ]

    def get_aaclip(key: str, target: str):
        base, ours = aggregate_mean_host(aaclip_paths(key, target), "baseline", "parallel")
        return base, ours, None

    table_lines.extend(render_host("AA-CLIP", [
        ("vitb", "ViT-B/16+"),
        ("vith", "ViT-H/14"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
        ("vitl336", "ViT-L/14-336"),
    ], get_aaclip))
    table_lines.append(r"\midrule")

    table_lines.extend(render_host("FAPrompt", [
        ("vitb", "ViT-B/16+"),
        ("vith", "ViT-H/14"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
    ], faprompt_values))
    table_lines.append(r"\midrule")

    def get_anomalyclip(key: str, target: str):
        base, ours = aggregate_row_host(anomalyclip_paths(key, target), "baseline_txt", "parallel_margin")
        return base, ours, None

    table_lines.extend(render_host("AnomalyCLIP", [
        ("vitb", "ViT-B/16+"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
        ("vitl336", "ViT-L/14-336"),
        ("vith", "ViT-H/14"),
    ], get_anomalyclip))
    table_lines.append(r"\midrule")

    def get_adaptclip(key: str, target: str):
        base, ours = aggregate_row_host(adaptclip_paths(key, target), "baseline_txt", "ted_trainfree_vl")
        return base, ours, None

    table_lines.extend(render_host("AdaptCLIP", [
        ("vitb", "ViT-B/16+"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
        ("vitl336", "ViT-L/14-336"),
        ("vith", "ViT-H/14"),
    ], get_adaptclip))
    table_lines.append(r"\midrule")

    def get_adaclip(key: str, target: str):
        base, ours = aggregate_row_host(adaclip_paths(key, target), "baseline_txt", "parallel_margin")
        return base, ours, None

    table_lines.extend(render_host("AdaCLIP", [
        ("vitb", "ViT-B/16"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
        ("vitl336", "ViT-L/14-336"),
        ("vith", "ViT-H/14"),
    ], get_adaclip))
    table_lines.append(r"\midrule")

    def get_bayespfl(key: str, target: str):
        base, ours = aggregate_row_host(bayespfl_paths(key, target), "baseline_txt", "ted_trainfree")
        return base, ours, None

    table_lines.extend(render_host("BayesPFL", [
        ("vitb", "ViT-B/16+"),
        ("vitl_openai", "ViT-L/14 OpenAI"),
        ("vitl336", "ViT-L/14-336"),
        ("vith", "ViT-H/14"),
    ], get_bayespfl))

    table_lines.extend([
        r"\bottomrule",
        r"\end{tabular}",
        r"}",
        r"\end{table*}",
        "",
    ])
    text = "\n".join(table_lines)
    (OUT_DIR / "host_backbone_transfer_trainfree_datasetwise.tex").write_text(text)
    (OUT_DIR / "host_backbone_transfer_datasetwise.tex").write_text(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
