from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import (  # noqa: E402
    build_model,
    collect_source_hardfp_bases,
    get_learned_text_pair,
    load_prompt_learner,
)
from utils import get_transform  # noqa: E402


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def save_rows(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "temp_scale",
                "class_name",
                "num_anomaly",
                "num_normal",
                "inside_mean",
                "outside_mean",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def build_dataset(root: str, dataset_name: str, image_size: int, mode: str | None = None):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    kwargs = {
        "root": root,
        "transform": preprocess,
        "target_transform": target_transform,
        "dataset_name": dataset_name,
    }
    if mode is not None:
        kwargs["mode"] = mode
    return Dataset(**kwargs)


def collect_source_gate_calibration(
    model,
    text_pair: torch.Tensor,
    fp_bases: dict[int, torch.Tensor],
    source_root: str,
    image_size: int,
    device: str,
    features_list: list[int],
    feature_map_layer: list[int],
    max_per_class: int,
    hard_frac: float,
):
    dataset = build_dataset(source_root, "mvtec", image_size, mode="train")
    per_class_count: dict[str, int] = {obj: 0 for obj in dataset.obj_list}
    kept_indices = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        anomaly_flag = item["anomaly"]
        if hasattr(anomaly_flag, "item"):
            anomaly_flag = anomaly_flag.item()
        if int(anomaly_flag) != 0:
            continue
        cls_name = item["cls_name"]
        if per_class_count[cls_name] >= max_per_class:
            continue
        per_class_count[cls_name] += 1
        kept_indices.append(idx)

    subset = torch.utils.data.Subset(dataset, kept_indices)
    loader = torch.utils.data.DataLoader(subset, batch_size=1, shuffle=False, num_workers=0)

    q_hard: dict[int, list[torch.Tensor]] = {idx: [] for idx in fp_bases}
    q_norm: dict[int, list[torch.Tensor]] = {idx: [] for idx in fp_bases}
    print(
        json.dumps(
            {
                "stage": "fp_gate_calibration_start",
                "num_selected_images": len(kept_indices),
                "hard_frac": hard_frac,
            }
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < feature_map_layer[0] or layer_idx not in fp_bases:
                    continue
                patch_tokens = F.normalize(patch_feature[:, 1:, :].float(), dim=-1)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                patch_scores = ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)
                hard_mask = torch.zeros_like(patch_scores, dtype=torch.bool)
                k = max(1, int(patch_scores.numel() * hard_frac))
                top_idx = torch.topk(patch_scores, k=k, largest=True).indices
                hard_mask[top_idx] = True

                basis = fp_bases[layer_idx].to(device)
                q = (patch_tokens.reshape(-1, patch_tokens.shape[-1]) @ basis).pow(2).sum(dim=-1)
                q_hard[layer_idx].append(q[hard_mask].detach().cpu())
                q_norm[layer_idx].append(q[~hard_mask].detach().cpu())

            if img_idx % 16 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "fp_gate_calibration_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    calib = {}
    for layer_idx in fp_bases:
        hard = torch.cat(q_hard[layer_idx], dim=0).numpy()
        norm = torch.cat(q_norm[layer_idx], dim=0).numpy()
        tau = float(np.percentile(norm, 95))
        hard_mean = float(hard.mean())
        norm_mean = float(norm.mean())
        hard_std = float(hard.std())
        norm_std = float(norm.std())
        temp = max(1e-6, 0.5 * (hard_std + norm_std))
        calib[layer_idx] = {
            "tau_p95_normal": tau,
            "hard_mean": hard_mean,
            "normal_mean": norm_mean,
            "hard_std": hard_std,
            "normal_std": norm_std,
            "base_temperature": temp,
        }
    return calib


def main():
    parser = argparse.ArgumentParser("Probe source-only hard-FP visual gating for AnomalyCLIP")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_fp_visual_gate_baseline_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--source_hard_frac", type=float, default=0.01)
    parser.add_argument("--max_source_per_class", type=int, default=8)
    parser.add_argument("--fp_rank", type=int, default=16)
    parser.add_argument("--temp_scales", type=float, nargs="+", default=[0.5, 1.0, 2.0])
    args = parser.parse_args()

    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    text_pair = get_learned_text_pair(model, learner)

    fp_bases, fp_basis_stats = collect_source_hardfp_bases(
        model=model,
        text_pair=text_pair.to(device),
        source_root=args.source_root,
        image_size=args.image_size,
        device=device,
        features_list=args.features_list,
        feature_map_layer=args.feature_map_layer,
        max_per_class=args.max_source_per_class,
        hard_frac=args.source_hard_frac,
        fp_rank=args.fp_rank,
    )
    gate_calib = collect_source_gate_calibration(
        model=model,
        text_pair=text_pair.to(device),
        fp_bases=fp_bases,
        source_root=args.source_root,
        image_size=args.image_size,
        device=device,
        features_list=args.features_list,
        feature_map_layer=args.feature_map_layer,
        max_per_class=args.max_source_per_class,
        hard_frac=args.source_hard_frac,
    )

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.target_root, transform=preprocess, target_transform=target_transform, dataset_name="visa")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    per_temp_class = {
        temp_scale: {
            obj: {
                "num_anomaly": 0,
                "num_normal": 0,
                "inside_sum": 0.0,
                "outside_sum": 0.0,
                "ratio_sum": 0.0,
                "normal_topk_sum": 0.0,
                "normal_mean_sum": 0.0,
            }
            for obj in dataset.obj_list
        }
        for temp_scale in args.temp_scales
    }

    print(
        json.dumps(
            {
                "stage": "fp_visual_gate_start",
                "num_images": len(dataset),
                "temp_scales": args.temp_scales,
                "fp_basis_stats": fp_basis_stats,
                "gate_calib": gate_calib,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())
            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            layer_maps = {temp_scale: [] for temp_scale in args.temp_scales}

            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < args.feature_map_layer[0] or layer_idx not in fp_bases:
                    continue
                patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], args.image_size)
                base_score = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0

                patch_tokens = F.normalize(patch_feature[:, 1:, :].float(), dim=-1)
                basis = fp_bases[layer_idx].to(device)
                q_token = (patch_tokens @ basis).pow(2).sum(dim=-1, keepdim=True)
                q_map = AnomalyCLIP_lib.get_similarity_map(q_token, args.image_size)[..., 0]

                tau = gate_calib[layer_idx]["tau_p95_normal"]
                base_temp = gate_calib[layer_idx]["base_temperature"]
                for temp_scale in args.temp_scales:
                    gate = torch.sigmoid((q_map - tau) / max(1e-6, base_temp * temp_scale))
                    adj_score = base_score * (1.0 - gate)
                    layer_maps[temp_scale].append(adj_score)

            for temp_scale in args.temp_scales:
                anomaly_map = torch.stack(layer_maps[temp_scale]).sum(dim=0)[0].detach().cpu().numpy()
                anomaly_map = gaussian_filter(anomaly_map, sigma=args.sigma)
                stats = per_temp_class[temp_scale][cls_name]
                if is_anomaly and gt_mask.any():
                    inside = float(anomaly_map[gt_mask].mean())
                    outside = float(anomaly_map[~gt_mask].mean())
                    stats["num_anomaly"] += 1
                    stats["inside_sum"] += inside
                    stats["outside_sum"] += outside
                    stats["ratio_sum"] += outside / max(inside, 1e-8)
                else:
                    stats["num_normal"] += 1
                    stats["normal_topk_sum"] += topk_mean(anomaly_map, args.topk_frac)
                    stats["normal_mean_sum"] += float(anomaly_map.mean())

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "fp_visual_gate_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    rows = []
    summary = {
        "host": "AnomalyCLIP",
        "checkpoint_path": args.checkpoint_path,
        "fp_basis_stats": fp_basis_stats,
        "gate_calib": gate_calib,
        "mean_by_temp_scale": {},
    }
    for temp_scale in args.temp_scales:
        cls_rows = []
        for cls_name, stats in per_temp_class[temp_scale].items():
            row = {
                "temp_scale": temp_scale,
                "class_name": cls_name,
                "num_anomaly": stats["num_anomaly"],
                "num_normal": stats["num_normal"],
                "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
                "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
                "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
                "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
                "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
                "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
            }
            rows.append(row)
            cls_rows.append(row)

        mean_row = {
            "temp_scale": temp_scale,
            "class_name": "mean",
            "num_anomaly": sum(r["num_anomaly"] for r in cls_rows),
            "num_normal": sum(r["num_normal"] for r in cls_rows),
            "inside_mean": float(np.mean([r["inside_mean"] for r in cls_rows])),
            "outside_mean": float(np.mean([r["outside_mean"] for r in cls_rows])),
            "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in cls_rows])),
            "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in cls_rows])),
            "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in cls_rows])),
            "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in cls_rows])),
        }
        rows.append(mean_row)
        summary["mean_by_temp_scale"][str(temp_scale)] = mean_row

    save_rows(rows, summary, Path(args.save_dir))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
