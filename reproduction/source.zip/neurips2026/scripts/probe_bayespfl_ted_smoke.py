from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms as transforms
from scipy.ndimage import gaussian_filter
from skimage import measure
from sklearn.metrics import auc, average_precision_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
BAYES_ROOT = ROOT / "neurips2026" / "Bayes-PFL"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
os.chdir(BAYES_ROOT)
for path in (BAYES_ROOT, SCRIPT_ROOT, ROOT, ANO_ROOT):
    path_str = str(path)
    if path_str in sys.path:
        sys.path.remove(path_str)
for path in (ANO_ROOT, ROOT, SCRIPT_ROOT, BAYES_ROOT):
    sys.path.insert(0, str(path))

from collect_bayespfl_map_separability import build_models, infer_map  # noqa: E402
from collect_bayespfl_source_banks import (  # noqa: E402
    MetaDataset,
    collect_source_patch_banks,
    default_bank_cache_path,
)
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from models.model_CLIP import tokenize  # noqa: E402
from test import _transform_test, setup_seed  # noqa: E402


def logmeanexp_negative_sqdist_1d(coeff: torch.Tensor, bank_coeff: torch.Tensor, tau: float) -> torch.Tensor:
    if bank_coeff.numel() == 0:
        return coeff.new_zeros((coeff.shape[0],))
    dist2 = (coeff.unsqueeze(1) - bank_coeff.unsqueeze(0)) ** 2
    return torch.logsumexp(-dist2 / tau, dim=-1) - np.log(float(bank_coeff.shape[0]))


def topk_mean(arr: np.ndarray, ratio: float) -> float:
    vals = np.asarray(arr).reshape(-1)
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def bayespfl_official_topk_mean(arr: np.ndarray, cls_name: str) -> float:
    vals = np.asarray(arr, dtype=np.float32).reshape(-1)
    special = {"capsules", "macaroni1", "macaroni2", "pipe_fryum", "screw", "cashew", "chewinggum"}
    k = 20 if cls_name in special else 2000
    k = min(k, vals.size)
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def minmax_list(values: list[float]) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float32)
    return (arr - arr.min()) / (arr.max() - arr.min() + 1e-8)


def bayespfl_official_mask_transform(image_size: int):
    # Bayes-PFL applies the same target_transform to masks in datasets.py.
    # Keep this for baseline-exact metric masks; thresholding happens later.
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
        ]
    )


def safe_pixel_metric(results: dict, obj: str, metric: str) -> float:
    try:
        return float(pixel_level_metrics(results, obj, metric))
    except Exception:
        return float("nan")


def precompute_aupro_regions(masks: np.ndarray | torch.Tensor) -> dict:
    if isinstance(masks, torch.Tensor):
        masks = masks.detach().cpu().numpy()
    masks = np.asarray(masks)
    if masks.ndim == 4:
        masks = masks.squeeze(1)
    masks = (masks > 0.5).astype(np.uint8)
    inverse_masks = 1 - masks
    regions_by_image: list[list[np.ndarray]] = []
    for mask in masks:
        regions = []
        labeled = measure.label(mask)
        for region in measure.regionprops(labeled):
            regions.append(region.coords)
        regions_by_image.append(regions)
    return {
        "masks": masks,
        "inverse_masks": inverse_masks,
        "inverse_total": int(inverse_masks.sum()),
        "regions_by_image": regions_by_image,
        "has_foreground": bool(masks.sum() > 0),
    }


def calculate_fast_aupro(
    masks: np.ndarray | torch.Tensor,
    maps: np.ndarray | torch.Tensor,
    max_step: int = 200,
    expect_fpr: float = 0.3,
    precomputed: dict | None = None,
) -> float:
    pre = precomputed if precomputed is not None else precompute_aupro_regions(masks)
    if not pre["has_foreground"] or pre["inverse_total"] <= 0:
        return float("nan")
    if isinstance(maps, torch.Tensor):
        maps = maps.detach().cpu().numpy()
    maps = np.asarray(maps, dtype=np.float32)
    if maps.ndim == 4:
        maps = maps.squeeze(1)
    min_th = float(np.min(maps))
    max_th = float(np.max(maps))
    if not np.isfinite(min_th) or not np.isfinite(max_th) or max_th <= min_th:
        return 0.5
    thresholds = np.linspace(min_th, max_th, num=max(2, int(max_step)), endpoint=False, dtype=np.float32)
    pros: list[float] = []
    fprs: list[float] = []
    inverse_masks = pre["inverse_masks"]
    inverse_total = int(pre["inverse_total"])
    for th in thresholds:
        binary_maps = maps > float(th)
        pro_vals = []
        for binary_map, regions in zip(binary_maps, pre["regions_by_image"]):
            for coords in regions:
                pro_vals.append(float(binary_map[coords[:, 0], coords[:, 1]].sum() / max(coords.shape[0], 1)))
        if not pro_vals:
            continue
        fp_pixels = np.logical_and(inverse_masks, binary_maps).sum()
        pros.append(float(np.mean(pro_vals)))
        fprs.append(float(fp_pixels / inverse_total))
    if not pros:
        return float("nan")
    pros_np = np.asarray(pros, dtype=np.float32)
    fprs_np = np.asarray(fprs, dtype=np.float32)
    keep = fprs_np < float(expect_fpr)
    if int(keep.sum()) <= 2:
        return 0.5
    fprs_keep = fprs_np[keep]
    denom = float(fprs_keep.max() - fprs_keep.min())
    if denom <= 1e-12:
        return 0.5
    fprs_keep = (fprs_keep - fprs_keep.min()) / denom
    return float(auc(fprs_keep, pros_np[keep]))


def infer_local_layers_with_axis(args, device, model_clip, pfl_text_encoder, my_model, image, cls_name, stage):
    with torch.no_grad():
        image_features, _, patch_tokens = model_clip.encode_image(image, args.features_list)
        text_embeddings, _ = my_model.forward_ensemble(
            pfl_text_encoder, image_features, patch_tokens, [cls_name], device, tokenize, mode="test"
        )
        num_hyp = args.prompt_num * args.sample_num
        outputs = []
        for layer_idx, patch_token in enumerate(patch_tokens):
            text_update, dense_feature = my_model.RCA(text_embeddings, patch_token.clone(), layer_idx)
            dense_feature = F.normalize(dense_feature[0].float(), dim=-1)
            text_update = F.normalize(text_update[0].float(), dim=-1)
            normal_tokens = text_update[:num_hyp]
            anomaly_tokens = text_update[num_hyp : 2 * num_hyp]
            normal = F.normalize(normal_tokens.mean(dim=0), dim=0)
            anomaly = F.normalize(anomaly_tokens.mean(dim=0), dim=0)
            axis = F.normalize(anomaly - normal, dim=0)
            pair_axes = F.normalize(anomaly_tokens - normal_tokens, dim=-1)
            logits = my_model.temperature_pixel.exp() * dense_feature @ text_update.t()
            anomaly_scores = []
            pair_margins = []
            for hyp_idx in range(num_hyp):
                pair = torch.stack([logits[:, hyp_idx], logits[:, hyp_idx + num_hyp]], dim=1)
                anomaly_scores.append(pair.softmax(dim=1)[:, 1])
                pair_margins.append(logits[:, hyp_idx + num_hyp] - logits[:, hyp_idx])
            outputs.append(
                {
                    "dense_feature": dense_feature,
                    "axis": axis,
                    "pair_axes": pair_axes,
                    "host_score": torch.stack(anomaly_scores, dim=0).mean(dim=0),
                    "pair_margins": torch.stack(pair_margins, dim=0),
                }
            )
    return outputs


def compute_ted_map(args, outputs, fp_banks, def_banks, device) -> np.ndarray:
    layer_scores = compute_ted_layer_scores(args, outputs, fp_banks, def_banks, device)
    maps = []
    for margin in layer_scores:
        n = margin.shape[0]
        h = int(round(n**0.5))
        w = n // h
        layer_map = margin.reshape(1, 1, h, w)
        layer_map = F.interpolate(layer_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[0, 0]
        maps.append(layer_map.detach().float().cpu().numpy())
    return np.mean(maps, axis=0).astype(np.float32)


def compute_ted_layer_scores(args, outputs, fp_banks, def_banks, device) -> list[torch.Tensor]:
    layer_scores = []
    for layer_idx, out in enumerate(outputs):
        feat = out["dense_feature"]
        fp = fp_banks[layer_idx].to(device)
        defect = def_banks[layer_idx].to(device)
        axes = out["pair_axes"] if args.ted_axis_mode == "pair_ensemble" else out["axis"].unsqueeze(0)
        margins = []
        for axis in axes:
            coeff = feat @ axis
            fp_coeff = fp @ axis if fp.numel() else torch.empty((0,), device=device)
            def_coeff = defect @ axis if defect.numel() else torch.empty((0,), device=device)
            q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=args.tau)
            q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=args.tau)
            if args.margin_sign == "def_minus_fp":
                pair_margin = q_def - args.fp_weight * q_fp
            else:
                pair_margin = q_fp - args.fp_weight * q_def
            margins.append(pair_margin)
        margin = torch.stack(margins, dim=0).mean(dim=0)
        if args.map_activation == "sigmoid":
            margin = torch.sigmoid((margin - margin.mean()) / margin.std().clamp_min(1e-6))
        layer_scores.append(margin)
    return layer_scores


def resize_patch_score(score: torch.Tensor, image_size: int) -> torch.Tensor:
    n = score.shape[0]
    h = int(round(n**0.5))
    w = n // h
    score_map = score.reshape(1, 1, h, w)
    return F.interpolate(score_map, size=(image_size, image_size), mode="bilinear", align_corners=False)[0, 0]


def resize_pair_margins(margins: torch.Tensor, image_size: int) -> torch.Tensor:
    n = margins.shape[-1]
    h = int(round(n**0.5))
    w = n // h
    margin_maps = margins.reshape(margins.shape[0], 1, h, w)
    return F.interpolate(margin_maps, size=(image_size, image_size), mode="bilinear", align_corners=False)[:, 0]


def zscore_np(arr: np.ndarray) -> np.ndarray:
    vals = np.asarray(arr, dtype=np.float32)
    return (vals - vals.mean()) / (vals.std() + 1e-6)


def minmax_np(arr: np.ndarray) -> np.ndarray:
    vals = np.asarray(arr, dtype=np.float32)
    lo = float(vals.min())
    hi = float(vals.max())
    return (vals - lo) / (hi - lo + 1e-6)


def combine_ted_with_host(args, base_map: np.ndarray, ted_map: np.ndarray) -> np.ndarray:
    base = np.asarray(base_map, dtype=np.float32)
    ted = np.asarray(ted_map, dtype=np.float32)
    if args.ted_combine == "replace":
        return ted.astype(np.float32)
    if args.ted_combine == "blend":
        return ((1.0 - args.ted_alpha) * minmax_np(base) + args.ted_alpha * minmax_np(ted)).astype(np.float32)
    scale = float(base.std()) + 1e-6
    return (base + args.ted_alpha * scale * zscore_np(ted)).astype(np.float32)


def combine_calibrated_ted_with_host(
    args,
    base_map: np.ndarray,
    outputs,
    fp_banks,
    def_banks,
    calibrators: dict[int, dict],
    device,
) -> np.ndarray:
    base = torch.as_tensor(np.asarray(base_map, dtype=np.float32), device=device)
    base_scale = base.std().clamp_min(1e-6)
    layer_scores = compute_ted_layer_scores(args, outputs, fp_banks, def_banks, device)
    residual_maps = []
    for layer_idx, score in enumerate(layer_scores):
        cal = calibrators.get(layer_idx, {})
        eta = float(cal.get("eta", 0.0))
        score_map = resize_patch_score(score, args.image_size)
        score_map = (score_map - score_map.mean()) / score_map.std().clamp_min(1e-6)
        residual_maps.append(eta * score_map)
    if not residual_maps:
        return np.asarray(base_map, dtype=np.float32)
    residual = torch.stack(residual_maps, dim=0).mean(dim=0)
    calibrated = base + base_scale * residual
    return calibrated.detach().float().cpu().numpy().astype(np.float32)


def compute_pre_softmax_ted_map(
    args,
    outputs,
    fp_banks,
    def_banks,
    device,
    calibrators: dict[int, dict] | None = None,
) -> np.ndarray:
    """Inject TED before Bayes-PFL's normal/anomaly softmax.

    Bayes-PFL local scoring is an ensemble of pairwise normal-vs-anomaly
    softmax probabilities. Post-map residuals often under-act because this
    ensemble is already saturated. This path shifts each pairwise logit margin
    before the softmax while preserving the official prompt/sample/layer
    averaging rule.
    """
    layer_scores = compute_ted_layer_scores(args, outputs, fp_banks, def_banks, device)
    maps = []
    for layer_idx, (out, residual_score) in enumerate(zip(outputs, layer_scores)):
        residual = (residual_score - residual_score.mean()) / residual_score.std().clamp_min(1e-6)
        residual_map = resize_patch_score(residual, args.image_size)
        pair_margin_maps = resize_pair_margins(out["pair_margins"].float(), args.image_size)
        margin_scale = pair_margin_maps.std().clamp_min(1e-6)
        if calibrators is None:
            coeff = float(args.ted_alpha)
        else:
            coeff = float(calibrators.get(layer_idx, {}).get("eta", 0.0))
        corrected = torch.sigmoid(pair_margin_maps + coeff * margin_scale * residual_map.unsqueeze(0))
        maps.append(corrected.mean(dim=0).detach().float().cpu().numpy())
    return np.mean(maps, axis=0).astype(np.float32)


def _sample_indices(mask: torch.Tensor, max_points: int) -> torch.Tensor:
    idx = torch.nonzero(mask, as_tuple=False).flatten()
    if idx.numel() <= max_points:
        return idx
    perm = torch.randperm(idx.numel(), device=idx.device)[:max_points]
    return idx[perm]


def _collect_calibration_pairs(args, device, model_clip, pfl_text_encoder, my_model, fp_banks, def_banks):
    image_transform = _transform_test(args.image_size)
    mask_transform = bayespfl_official_mask_transform(args.image_size)
    good_ds = MetaDataset(
        root=args.data_path,
        dataset_name=args.dataset,
        split="train",
        image_transform=image_transform,
        mask_transform=mask_transform,
        keep_good=True,
        class_names=[args.source_class] if getattr(args, "source_class", None) else None,
        exclude_class=args.exclude_class,
    )
    defect_ds = MetaDataset(
        root=args.data_path,
        dataset_name=args.dataset,
        split="test",
        image_transform=image_transform,
        mask_transform=mask_transform,
        keep_good=False,
        class_names=[args.source_class] if getattr(args, "source_class", None) else None,
        exclude_class=args.exclude_class,
    )
    per_good = {cls_name: 0 for cls_name in good_ds.obj_list}
    per_defect = {cls_name: 0 for cls_name in defect_ds.obj_list}
    layers = range(len(args.features_list))
    data = {
        layer_idx: {"fp_host": [], "fp_res": [], "def_host": [], "def_res": []}
        for layer_idx in layers
    }

    for img_idx in range(len(good_ds)):
        item = good_ds[img_idx]
        cls_name = item["cls_name"]
        if per_good[cls_name] >= args.calib_max_good_per_class:
            continue
        per_good[cls_name] += 1
        image = item["img"].unsqueeze(0).to(device)
        outputs = infer_local_layers_with_axis(args, device, model_clip, pfl_text_encoder, my_model, image, cls_name, stage=None)
        layer_scores = compute_ted_layer_scores(args, outputs, fp_banks, def_banks, device)
        for layer_idx, (out, residual) in enumerate(zip(outputs, layer_scores)):
            host = out["host_score"].float()
            k = max(1, int(round(host.numel() * args.calib_hard_frac)))
            idx = torch.topk(host, k=k, largest=True).indices
            if idx.numel() > args.calib_max_fp_per_image:
                idx = idx[torch.randperm(idx.numel(), device=idx.device)[: args.calib_max_fp_per_image]]
            res = (residual - residual.mean()) / residual.std().clamp_min(1e-6)
            data[layer_idx]["fp_host"].append(host[idx].detach().cpu())
            data[layer_idx]["fp_res"].append(res[idx].detach().cpu())

    for img_idx in range(len(defect_ds)):
        item = defect_ds[img_idx]
        cls_name = item["cls_name"]
        if per_defect[cls_name] >= args.calib_max_defect_per_class:
            continue
        per_defect[cls_name] += 1
        image = item["img"].unsqueeze(0).to(device)
        gt_mask = item["img_mask"].unsqueeze(0).to(device).float()
        outputs = infer_local_layers_with_axis(args, device, model_clip, pfl_text_encoder, my_model, image, cls_name, stage=None)
        layer_scores = compute_ted_layer_scores(args, outputs, fp_banks, def_banks, device)
        for layer_idx, (out, residual) in enumerate(zip(outputs, layer_scores)):
            host = out["host_score"].float()
            n = host.shape[0]
            h = int(round(n**0.5))
            w = n // h
            gt_small = F.interpolate(gt_mask, size=(h, w), mode="nearest")[0, 0].reshape(-1) > 0.5
            idx = _sample_indices(gt_small, args.calib_max_defect_per_image)
            if idx.numel() == 0:
                continue
            res = (residual - residual.mean()) / residual.std().clamp_min(1e-6)
            data[layer_idx]["def_host"].append(host[idx].detach().cpu())
            data[layer_idx]["def_res"].append(res[idx].detach().cpu())

    packed = {}
    for layer_idx, chunks in data.items():
        packed[layer_idx] = {}
        for key, vals in chunks.items():
            if vals:
                tensor = torch.cat(vals, dim=0).float()
                if tensor.numel() > args.calib_max_train_points:
                    perm = torch.randperm(tensor.numel())[: args.calib_max_train_points]
                    tensor = tensor[perm]
            else:
                tensor = torch.empty((0,), dtype=torch.float32)
            packed[layer_idx][key] = tensor
    return packed


def train_source_calibrators(args, device, model_clip, pfl_text_encoder, my_model, fp_banks, def_banks) -> dict[int, dict]:
    pairs = _collect_calibration_pairs(args, device, model_clip, pfl_text_encoder, my_model, fp_banks, def_banks)
    calibrators: dict[int, dict] = {}
    for layer_idx, pack in pairs.items():
        fp_host = pack["fp_host"].to(device)
        fp_res = pack["fp_res"].to(device)
        def_host = pack["def_host"].to(device)
        def_res = pack["def_res"].to(device)
        if fp_host.numel() == 0 or def_host.numel() == 0:
            calibrators[layer_idx] = {"eta": 0.0, "num_fp": int(fp_host.numel()), "num_defect": int(def_host.numel())}
            continue
        init = max(-args.calib_eta_max + 1e-6, min(args.calib_eta_max - 1e-6, args.calib_eta_init))
        raw_eta = torch.nn.Parameter(torch.atanh(torch.tensor(init / args.calib_eta_max, device=device)))
        opt = torch.optim.Adam([raw_eta], lr=args.calib_lr)
        n_pairs = min(fp_host.numel(), def_host.numel())
        for _ in range(args.calib_epochs):
            fp_idx = torch.randint(0, fp_host.numel(), (n_pairs,), device=device)
            def_idx = torch.randint(0, def_host.numel(), (n_pairs,), device=device)
            eta = args.calib_eta_max * torch.tanh(raw_eta)
            fp_score = fp_host[fp_idx] + eta * fp_host.std().clamp_min(1e-6) * fp_res[fp_idx]
            def_score = def_host[def_idx] + eta * def_host.std().clamp_min(1e-6) * def_res[def_idx]
            rank_loss = F.softplus(-(def_score - fp_score - args.calib_rank_margin) / args.calib_rank_temp).mean()
            loss = rank_loss + args.calib_eta_reg * eta.pow(2)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
        with torch.no_grad():
            eta = float((args.calib_eta_max * torch.tanh(raw_eta)).detach().cpu())
            fp_score = fp_host + eta * fp_host.std().clamp_min(1e-6) * fp_res
            def_score = def_host + eta * def_host.std().clamp_min(1e-6) * def_res
            base_acc = float((def_host.mean() > fp_host.mean()).detach().cpu())
            pair_acc = float((def_score.mean() > fp_score.mean()).detach().cpu())
        calibrators[layer_idx] = {
            "eta": eta,
            "num_fp": int(fp_host.numel()),
            "num_defect": int(def_host.numel()),
            "fp_host_mean": float(fp_host.mean().detach().cpu()),
            "def_host_mean": float(def_host.mean().detach().cpu()),
            "fp_res_mean": float(fp_res.mean().detach().cpu()),
            "def_res_mean": float(def_res.mean().detach().cpu()),
            "source_base_mean_rank_ok": base_acc,
            "source_calibrated_mean_rank_ok": pair_acc,
        }
    print(json.dumps({"stage": "bayespfl_source_calibrators_trained", "calibrators": calibrators}, indent=2), flush=True)
    return calibrators


def get_or_collect_banks(args):
    if not args.bank_cache_path:
        args.bank_cache_path = str(default_bank_cache_path(args))
    cache_path = Path(args.bank_cache_path)
    if cache_path.exists() and not args.refresh_bank_cache:
        payload = torch.load(cache_path, map_location="cpu")
        return (
            {int(k): v.float() for k, v in payload["fp_banks"].items()},
            {int(k): v.float() for k, v in payload["def_banks"].items()},
            payload.get("bank_stats", {}),
            str(cache_path),
        )
    fp_banks, def_banks, bank_stats = collect_source_patch_banks(args)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "fp_banks": {int(k): v.cpu() for k, v in fp_banks.items()},
            "def_banks": {int(k): v.cpu() for k, v in def_banks.items()},
            "bank_stats": bank_stats,
        },
        cache_path,
    )
    return fp_banks, def_banks, bank_stats, str(cache_path)


def evaluate(args):
    setup_seed(args.seed)
    device, model_clip, pfl_text_encoder, my_model = build_models(args)
    fp_banks, def_banks, bank_stats, bank_cache_path = get_or_collect_banks(args)
    source_calibrators = {}
    if args.enable_calibrator:
        source_calibrators = train_source_calibrators(args, device, model_clip, pfl_text_encoder, my_model, fp_banks, def_banks)
    preprocess = _transform_test(args.image_size)
    mask_transform = bayespfl_official_mask_transform(args.image_size)
    target_ds = MetaDataset(
        root=args.target_data_path,
        dataset_name=args.target_dataset,
        split="test",
        image_transform=preprocess,
        mask_transform=mask_transform,
        class_names=[args.target_class] if args.target_class else None,
    )
    loader = torch.utils.data.DataLoader(target_ds, batch_size=1, shuffle=False, num_workers=0)
    stage = int(Path(args.checkpoint_path).stem.split("_")[-1]) if "epoch_post" in args.checkpoint_path else 2
    results = {
        "baseline_txt": {obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for obj in target_ds.obj_list},
        "ted_trainfree": {obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for obj in target_ds.obj_list},
    }
    if args.enable_calibrator:
        results["ted_calibrated"] = {
            obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}
            for obj in target_ds.obj_list
        }
    normal_seen = anomaly_seen = 0
    for idx, item in enumerate(loader, start=1):
        anomaly = int(item["anomaly"].item())
        if anomaly == 0 and args.max_normal_eval and normal_seen >= args.max_normal_eval:
            continue
        if anomaly == 1 and args.max_anomaly_eval and anomaly_seen >= args.max_anomaly_eval:
            continue
        normal_seen += int(anomaly == 0)
        anomaly_seen += int(anomaly == 1)
        image = item["img"].to(device)
        cls_name = item["cls_name"][0] if isinstance(item["cls_name"], (list, tuple)) else item["cls_name"]
        gt_mask = item["img_mask"].clone()
        gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
        base_img_score, base_map = infer_map(args, device, model_clip, pfl_text_encoder, my_model, image, [cls_name], stage)
        outputs = infer_local_layers_with_axis(args, device, model_clip, pfl_text_encoder, my_model, image, cls_name, stage)
        ted_map = compute_ted_map(args, outputs, fp_banks, def_banks, device)
        if args.ted_insertion == "pre_softmax":
            final_ted_map = compute_pre_softmax_ted_map(args, outputs, fp_banks, def_banks, device)
        else:
            final_ted_map = combine_ted_with_host(args, base_map, ted_map)
        mode_payloads = [
            ("baseline_txt", base_img_score, base_map),
            # Keep the official global image branch. Image-level fusion is applied
            # after collecting class-wise map top-k scores, matching Bayes-PFL.
            ("ted_trainfree", base_img_score, final_ted_map),
        ]
        if args.enable_calibrator:
            if args.ted_insertion == "pre_softmax":
                calibrated_map = compute_pre_softmax_ted_map(
                    args,
                    outputs,
                    fp_banks,
                    def_banks,
                    device,
                    calibrators=source_calibrators,
                )
            else:
                calibrated_map = combine_calibrated_ted_with_host(
                    args,
                    base_map,
                    outputs,
                    fp_banks,
                    def_banks,
                    source_calibrators,
                    device,
                )
            mode_payloads.append(("ted_calibrated", base_img_score, calibrated_map))
        for mode, img_score, arr in mode_payloads:
            results[mode][cls_name]["gt_sp"].append(anomaly)
            results[mode][cls_name]["pr_sp"].append(float(img_score))
            results[mode][cls_name]["imgs_masks"].append(gt_mask)
            results[mode][cls_name]["anomaly_maps"].append(torch.from_numpy(np.asarray(arr)).unsqueeze(0))
        if idx % 8 == 0:
            print(json.dumps({"stage": "bayespfl_ted_progress", "images_done": idx, "class": cls_name}), flush=True)

    rows = []
    for mode in results.keys():
        vals = {"image_auroc": [], "pixel_auroc": [], "pixel_aupro": [], "pixel_ap": []}
        for obj in target_ds.obj_list:
            if not results[mode][obj]["gt_sp"]:
                continue
            results[mode][obj]["imgs_masks"] = torch.cat(results[mode][obj]["imgs_masks"])
            maps = torch.cat(results[mode][obj]["anomaly_maps"]).numpy()
            if args.metric_sigma > 0:
                maps = gaussian_filter(maps, sigma=args.metric_sigma, axes=(1, 2))
            results[mode][obj]["anomaly_maps"] = maps
            if args.image_score_mode == "official_fused":
                host_scores = [float(x) for x in results[mode][obj]["pr_sp"]]
                map_scores = [bayespfl_official_topk_mean(m, obj) for m in maps]
                host_norm = minmax_list(host_scores)
                map_norm = minmax_list(map_scores)
                fused = args.image_fusion_alpha * host_norm + (1.0 - args.image_fusion_alpha) * map_norm
                results[mode][obj]["pr_sp"] = [float(x) for x in fused]
            elif args.image_score_mode == "map_topk":
                results[mode][obj]["pr_sp"] = [topk_mean(m, args.image_topk) for m in maps]
            aupro_regions = precompute_aupro_regions(results[mode][obj]["imgs_masks"])
            row = {
                "mode": mode,
                "target_label": obj,
                "image_auroc": float(image_level_metrics(results[mode], obj, "image-auroc")),
                "pixel_auroc": safe_pixel_metric(results[mode], obj, "pixel-auroc"),
                "pixel_aupro": calculate_fast_aupro(
                    results[mode][obj]["imgs_masks"],
                    results[mode][obj]["anomaly_maps"],
                    max_step=args.aupro_max_step,
                    precomputed=aupro_regions,
                ),
                "pixel_ap": float(average_precision_score(np.asarray(results[mode][obj]["imgs_masks"]).ravel(), np.asarray(results[mode][obj]["anomaly_maps"]).ravel())),
            }
            rows.append(row)
            for key in vals:
                vals[key].append(row[key])
        rows.append({"mode": mode, "target_label": "mean", **{k: float(np.mean(v)) for k, v in vals.items() if v}})
    summary = vars(args) | {
        "bank_cache_path": bank_cache_path,
        "bank_stats": bank_stats,
        "source_calibrators": source_calibrators,
        "score_definition": {
            "baseline_txt": "official Bayes-PFL local anomaly map and image score",
            "ted_trainfree": "Bayes-PFL host map combined with fixed TED residual according to ted_combine/ted_alpha",
            "ted_calibrated": "source-only layerwise eta calibration of TED residual on Bayes-PFL local map",
            "pre_softmax": "optional insertion that shifts Bayes-PFL normal-vs-anomaly logit margins before prompt/sample/layer averaging",
        },
        "bayespfl_official_compat": {
            "metric_sigma": args.metric_sigma,
            "image_score_mode": args.image_score_mode,
            "image_fusion_alpha": args.image_fusion_alpha,
            "sample_num": args.sample_num,
        },
        "aupro_max_step": args.aupro_max_step,
        "aupro_backend": "precomputed_region_fast_aupro",
    }
    return rows, summary


def main():
    parser = argparse.ArgumentParser("Bayes-PFL train-free TED smoke.")
    parser.add_argument("--dataset", type=str, default="mvtec")
    parser.add_argument("--data_path", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_data_path", type=str, default=str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"))
    parser.add_argument("--target_class", type=str, default="capsules")
    parser.add_argument("--checkpoint_path", type=str, default=str(ROOT / "neurips2026" / "results" / "bayespfl_strict_mvtec" / "epoch_post_15_1.pth"))
    parser.add_argument("--checkpoint_load_mode", type=str, choices=["strict", "compatible"], default="strict")
    parser.add_argument("--config_path", type=str, default=str(BAYES_ROOT / "open_clip_local" / "model_configs" / "ViT-L-14-336.json"))
    parser.add_argument("--pretrained_path", type=str, default="/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--num_flows", type=int, default=10)
    parser.add_argument("--prompt_context_len", type=int, default=5)
    parser.add_argument("--prompt_num", type=int, default=3)
    parser.add_argument("--prompt_state_len", type=int, default=5)
    parser.add_argument("--sample_num", type=int, default=10)
    parser.add_argument("--device_id", type=int, default=0)
    parser.add_argument("--seed", type=int, default=333)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--source_class", type=str, default=None)
    parser.add_argument("--exclude_class", type=str, default=None)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--fp_weight", type=float, default=1.0)
    parser.add_argument("--margin_sign", type=str, choices=["def_minus_fp", "fp_minus_def"], default="def_minus_fp")
    parser.add_argument("--ted_axis_mode", type=str, choices=["mean", "pair_ensemble"], default="mean")
    parser.add_argument("--map_activation", type=str, choices=["identity", "sigmoid"], default="sigmoid")
    parser.add_argument("--ted_combine", type=str, choices=["replace", "residual", "blend"], default="replace")
    parser.add_argument("--ted_insertion", type=str, choices=["post_map", "pre_softmax"], default="post_map")
    parser.add_argument("--ted_alpha", type=float, default=0.1)
    parser.add_argument("--enable_calibrator", action="store_true")
    parser.add_argument("--calib_epochs", type=int, default=30)
    parser.add_argument("--calib_lr", type=float, default=0.02)
    parser.add_argument("--calib_eta_init", type=float, default=0.05)
    parser.add_argument("--calib_eta_max", type=float, default=0.2)
    parser.add_argument("--calib_eta_reg", type=float, default=1e-3)
    parser.add_argument("--calib_rank_margin", type=float, default=0.05)
    parser.add_argument("--calib_rank_temp", type=float, default=0.05)
    parser.add_argument("--calib_hard_frac", type=float, default=0.01)
    parser.add_argument("--calib_max_good_per_class", type=int, default=2)
    parser.add_argument("--calib_max_defect_per_class", type=int, default=4)
    parser.add_argument("--calib_max_fp_per_image", type=int, default=64)
    parser.add_argument("--calib_max_defect_per_image", type=int, default=64)
    parser.add_argument("--calib_max_train_points", type=int, default=4096)
    parser.add_argument("--image_topk", type=float, default=0.01)
    parser.add_argument("--metric_sigma", type=float, default=8.0)
    parser.add_argument("--image_score_mode", type=str, choices=["official_fused", "host", "map_topk"], default="official_fused")
    parser.add_argument("--image_fusion_alpha", type=float, default=0.5)
    parser.add_argument("--aupro_max_step", type=int, default=200)
    parser.add_argument("--max_normal_eval", type=int, default=16)
    parser.add_argument("--max_anomaly_eval", type=int, default=16)
    parser.add_argument("--save_dir", type=str, default=str(ROOT / "neurips2026" / "results" / "bayespfl_ted_smoke_mvtec2visa_capsules_20260429"))
    args = parser.parse_args()
    rows, summary = evaluate(args)
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
