from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MVTEC_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"

if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from dataset import Dataset  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import (  # noqa: E402
    build_model,
    get_learned_text_pair,
    load_prompt_learner,
)
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    decision_axis,
    get_or_collect_source_patch_banks,
    logmeanexp_negative_sqdist_1d,
    project_bank,
)
from probe_anomalyclip_wrongclass_semantic_collapse import (  # noqa: E402
    aggregate_map_from_patch_features,
    build_eval_dataset,
    build_reference_text_model,
    global_image_score,
    safe_auc,
    safe_corr,
    static_text_pair_for_class,
    top_fraction_mask,
)
from utils import get_transform  # noqa: E402


def resolve_preset(args) -> None:
    if args.preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.source_root = str(OFFICIAL_VISA_ROOT)
        args.source_dataset = "visa"
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtec"
        args.heldout_class = args.target_class if args.heldout_class is None else args.heldout_class
        if args.bank_cache_path is None:
            args.bank_cache_path = str(ROOT / "neurips2026" / "results" / "bank_cache" / "anomalyclip_discuss_visa2mvtec.pt")
    elif args.preset == "mvtec2visa":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.source_root = str(MVTEC_ROOT)
        args.source_dataset = "mvtec"
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
        args.heldout_class = None if args.heldout_class is None else args.heldout_class
        if args.bank_cache_path is None:
            args.bank_cache_path = str(ROOT / "neurips2026" / "results" / "bank_cache" / "anomalyclip_discuss_mvtec2visa.pt")
    else:
        raise ValueError(f"Unknown preset: {args.preset}")


def denormalize_image(img_tensor: torch.Tensor) -> np.ndarray:
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = np.transpose(img_tensor.cpu().numpy(), (1, 2, 0))
    img = np.clip((img * std + mean) * 255.0, 0, 255).astype(np.uint8)
    return img


def apply_score_overlay(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.52, colormap: int = cv2.COLORMAP_JET) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, colormap)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return np.clip(alpha * image.astype(np.float32) + (1.0 - alpha) * scoremap.astype(np.float32), 0, 255).astype(np.uint8)


def overlay_binary_mask(image: np.ndarray, mask: np.ndarray, color=(255, 80, 40), alpha: float = 0.55) -> np.ndarray:
    out = image.astype(np.float32).copy()
    color_arr = np.array(color, dtype=np.float32)
    out[mask] = (1 - alpha) * out[mask] + alpha * color_arr
    return np.clip(out, 0, 255).astype(np.uint8)


def percentile_bounds(arr: np.ndarray, lo: float = 1.0, hi: float = 99.0) -> tuple[float, float]:
    lo_v = float(np.percentile(arr, lo))
    hi_v = float(np.percentile(arr, hi))
    if hi_v <= lo_v:
        lo_v = float(arr.min())
        hi_v = float(arr.max())
    return lo_v, hi_v


def normalize_map(arr: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((arr - vmin) / denom, 0.0, 1.0)


def normalize_abs_map(arr: np.ndarray, q: float = 99.0) -> np.ndarray:
    bound = max(float(np.percentile(np.abs(arr), q)), 1e-8)
    return np.clip(np.abs(arr) / bound, 0.0, 1.0)


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def rank_1_based_desc(values: dict[str, float], target_key: str) -> int:
    ordered = sorted(values.items(), key=lambda kv: kv[1], reverse=True)
    for idx, (key, _) in enumerate(ordered, start=1):
        if key == target_key:
            return idx
    return len(ordered)


def pick_dataset_index(args, audit_path: str | None) -> int:
    if args.dataset_index is not None:
        return args.dataset_index
    if audit_path is None:
        raise ValueError("Either --dataset_index or --audit_metrics_path must be provided.")
    rows = []
    with open(audit_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            if row["class_name"] != args.target_class:
                continue
            rows.append(row)
    if not rows:
        raise ValueError(f"No rows found for class={args.target_class} in {audit_path}")

    def score(row: dict) -> tuple[float, float]:
        semantic_gap = float(row["true_prompt_rank_local"]) - float(row["true_prompt_rank_image"])
        learned_gap = float(row["learned_vs_mean_wrong_corr"]) - float(row["learned_vs_true_corr"])
        return semantic_gap, learned_gap

    rows.sort(key=lambda row: score(row), reverse=True)
    return int(rows[0]["image_id"])


def compute_parallel_support_maps(
    patch_features: list[torch.Tensor],
    axis: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    image_size: int,
    tau: float,
    sigma: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    q_def_layers = []
    q_fp_layers = []
    ours_layers = []
    for layer_idx, patch_feature in enumerate(patch_features):
        patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
        coeff = patch @ axis
        fp_coeff, _ = project_bank(fp_banks[layer_idx].to(axis.device), axis)
        def_coeff, _ = project_bank(def_banks[layer_idx].to(axis.device), axis)
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=tau)
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=tau)
        h = int(round(patch.shape[0] ** 0.5))
        for store, val in ((q_def_layers, q_def), (q_fp_layers, q_fp), (ours_layers, q_def - q_fp)):
            resized = F.interpolate(
                val.reshape(1, 1, h, h),
                size=(image_size, image_size),
                mode="bilinear",
                align_corners=False,
            )[0, 0]
            store.append(resized.detach().cpu().numpy())
    q_def_map = gaussian_filter(np.mean(np.stack(q_def_layers, axis=0), axis=0), sigma=sigma)
    q_fp_map = gaussian_filter(np.mean(np.stack(q_fp_layers, axis=0), axis=0), sigma=sigma)
    ours_map = gaussian_filter(np.mean(np.stack(ours_layers, axis=0), axis=0), sigma=sigma)
    return q_def_map, q_fp_map, ours_map


def main():
    parser = argparse.ArgumentParser("Generate semantic attenuation + OURS refinement explainer for AnomalyCLIP")
    parser.add_argument("--preset", type=str, required=True, choices=["visa2mvtec", "mvtec2visa"])
    parser.add_argument("--target_class", type=str, required=True)
    parser.add_argument("--dataset_index", type=int, default=None)
    parser.add_argument("--audit_metrics_path", type=str, default=None)
    parser.add_argument("--heldout_class", type=str, default=None)
    parser.add_argument("--checkpoint_path", type=str, default=None)
    parser.add_argument("--source_root", type=str, default=None)
    parser.add_argument("--source_dataset", type=str, default=None)
    parser.add_argument("--target_root", type=str, default=None)
    parser.add_argument("--target_dataset", type=str, default=None)
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--save_dir", type=str, required=True)
    args = parser.parse_args()

    resolve_preset(args)
    dataset_index = pick_dataset_index(args, args.audit_metrics_path)

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    axis = decision_axis(learned_pair).to(args.device)
    reference_model = build_reference_text_model(args.device)

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=args.heldout_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.bank_cache_path,
        refresh_bank_cache=args.refresh_bank_cache,
    )

    dataset = build_eval_dataset(args.target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    item = dataset[dataset_index]
    cls_name = item["cls_name"]
    if cls_name != args.target_class:
        raise ValueError(f"dataset_index={dataset_index} has class={cls_name}, expected {args.target_class}")
    image = item["img"].unsqueeze(0).to(args.device)
    gt_mask = item["img_mask"].squeeze().detach().cpu().numpy() > 0.5
    input_img = denormalize_image(item["img"])

    with torch.inference_mode():
        image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
        learned_map = aggregate_map_from_patch_features(patch_features, learned_pair, args.image_size, args.sigma)
        learned_image_score = global_image_score(image_features, learned_pair)

        true_pair = static_text_pair_for_class(reference_model, cls_name, args.device)
        true_map = aggregate_map_from_patch_features(patch_features, true_pair, args.image_size, args.sigma)
        true_image_score = global_image_score(image_features, true_pair)
        true_local_auc = safe_auc(true_map[gt_mask], true_map[~gt_mask])

        prompt_image_scores = {cls_name: true_image_score}
        prompt_local_auc = {cls_name: true_local_auc}
        wrong_records = []
        for prompt_cls in dataset.obj_list:
            if prompt_cls == cls_name:
                continue
            text_pair = static_text_pair_for_class(reference_model, prompt_cls, args.device)
            score_map = aggregate_map_from_patch_features(patch_features, text_pair, args.image_size, args.sigma)
            img_score = global_image_score(image_features, text_pair)
            loc_auc = safe_auc(score_map[gt_mask], score_map[~gt_mask])
            prompt_image_scores[prompt_cls] = img_score
            prompt_local_auc[prompt_cls] = loc_auc
            wrong_records.append(
                {
                    "prompt_cls": prompt_cls,
                    "image_score": img_score,
                    "local_auc": loc_auc,
                    "map": score_map,
                }
            )

        wrong_records.sort(key=lambda row: row["local_auc"], reverse=True)
        conf = wrong_records[0]
        wrong_cls = conf["prompt_cls"]
        wrong_map = conf["map"]
        wrong_image_score = float(conf["image_score"])
        wrong_local_auc = float(conf["local_auc"])

        q_def_map, q_fp_map, ours_map = compute_parallel_support_maps(
            patch_features=patch_features,
            axis=axis,
            fp_banks=fp_banks,
            def_banks=def_banks,
            image_size=args.image_size,
            tau=args.tau,
            sigma=args.sigma,
        )
        ours_local_auc = safe_auc(ours_map[gt_mask], ours_map[~gt_mask])

    true_mask = top_fraction_mask(true_map, args.map_topk)
    wrong_mask = top_fraction_mask(wrong_map, args.map_topk)
    learned_mask = top_fraction_mask(learned_map, args.map_topk)

    problem_delta = np.abs(true_map - wrong_map)
    ours_delta = ours_map - learned_map

    true_vmin, true_vmax = percentile_bounds(np.concatenate([true_map.reshape(-1), wrong_map.reshape(-1), learned_map.reshape(-1), ours_map.reshape(-1)]))
    qdef_vmin, qdef_vmax = percentile_bounds(q_def_map)
    qfp_vmin, qfp_vmax = percentile_bounds(q_fp_map)

    vis_true = apply_score_overlay(input_img, normalize_map(true_map, true_vmin, true_vmax))
    vis_wrong = apply_score_overlay(input_img, normalize_map(wrong_map, true_vmin, true_vmax))
    vis_learned = apply_score_overlay(input_img, normalize_map(learned_map, true_vmin, true_vmax))
    vis_qdef = apply_score_overlay(input_img, normalize_map(q_def_map, qdef_vmin, qdef_vmax))
    vis_qfp = apply_score_overlay(input_img, normalize_map(q_fp_map, qfp_vmin, qfp_vmax))
    vis_ours = apply_score_overlay(input_img, normalize_map(ours_map, true_vmin, true_vmax))
    vis_gt = overlay_binary_mask(input_img, gt_mask)

    fig, axes = plt.subplots(2, 5, figsize=(18, 7.8), constrained_layout=True)
    panels = [
        (input_img, "Input"),
        (vis_gt, "GT"),
        (vis_true, f"True Prompt\n{cls_name}\nAUC={true_local_auc:.3f} rank={rank_1_based_desc(prompt_local_auc, cls_name)}"),
        (vis_wrong, f"Confounding Wrong\n{wrong_cls}\nAUC={wrong_local_auc:.3f} rank={rank_1_based_desc(prompt_local_auc, wrong_cls)}"),
        (problem_delta, f"|True-Wrong|\ncorr={safe_corr(true_map, wrong_map):.3f}\noverlap={mask_overlap(true_mask, wrong_mask):.3f}"),
        (vis_learned, f"Learned Baseline\nAUC={safe_auc(learned_map[gt_mask], learned_map[~gt_mask]):.3f}"),
        (vis_qdef, "Defect Support\n$q_{def}$"),
        (vis_qfp, "Hard-FP Support\n$q_{fp}$"),
        (vis_ours, f"OURS Parallel\nAUC={ours_local_auc:.3f}\nΔ={ours_local_auc - safe_auc(learned_map[gt_mask], learned_map[~gt_mask]):+.3f}"),
        (ours_delta, "OURS-Baseline Δ"),
    ]

    for ax, (panel, title) in zip(axes.flatten(), panels):
        if panel.ndim == 2:
            if "Δ" in title and panel is ours_delta:
                vmax = max(float(np.percentile(np.abs(panel), 99.0)), 1e-8)
                ax.imshow(panel, cmap="coolwarm", vmin=-vmax, vmax=vmax)
            else:
                ax.imshow(normalize_abs_map(panel), cmap="magma")
        else:
            ax.imshow(panel)
        ax.set_title(title, fontsize=10)
        ax.axis("off")

    fig.suptitle(
        f"AnomalyCLIP semantic attenuation + OURS refinement | preset={args.preset} | sample={Path(item['img_path']).name}",
        fontsize=13,
    )

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    png_path = save_dir / f"{args.target_class}_semantic_refinement_explainer.png"
    pdf_path = save_dir / f"{args.target_class}_semantic_refinement_explainer.pdf"
    fig.savefig(png_path, dpi=200)
    fig.savefig(pdf_path)
    plt.close(fig)

    payload = {
        "preset": args.preset,
        "dataset_index": dataset_index,
        "class_name": cls_name,
        "img_path": item["img_path"],
        "checkpoint_path": args.checkpoint_path,
        "source_root": args.source_root,
        "target_root": args.target_root,
        "heldout_class": args.heldout_class,
        "bank_cache_path": str(bank_cache_path),
        "bank_cache_meta": bank_cache_meta,
        "bank_stats": bank_stats,
        "true_prompt": {
            "class": cls_name,
            "image_score": true_image_score,
            "local_auc": true_local_auc,
            "rank_image": rank_1_based_desc(prompt_image_scores, cls_name),
            "rank_local": rank_1_based_desc(prompt_local_auc, cls_name),
        },
        "confounding_wrong_prompt": {
            "class": wrong_cls,
            "image_score": wrong_image_score,
            "local_auc": wrong_local_auc,
            "rank_image": rank_1_based_desc(prompt_image_scores, wrong_cls),
            "rank_local": rank_1_based_desc(prompt_local_auc, wrong_cls),
        },
        "map_similarity": {
            "true_wrong_corr": safe_corr(true_map, wrong_map),
            "true_wrong_topk_overlap": mask_overlap(true_mask, wrong_mask),
            "learned_true_corr": safe_corr(learned_map, true_map),
            "learned_wrong_corr": safe_corr(learned_map, wrong_map),
            "learned_true_topk_overlap": mask_overlap(learned_mask, true_mask),
            "learned_wrong_topk_overlap": mask_overlap(learned_mask, wrong_mask),
        },
        "baseline_vs_ours": {
            "baseline_local_auc": safe_auc(learned_map[gt_mask], learned_map[~gt_mask]),
            "ours_local_auc": ours_local_auc,
            "delta_local_auc": ours_local_auc - safe_auc(learned_map[gt_mask], learned_map[~gt_mask]),
            "baseline_inside_mean": float(learned_map[gt_mask].mean()),
            "baseline_outside_mean": float(learned_map[~gt_mask].mean()),
            "ours_inside_mean": float(ours_map[gt_mask].mean()),
            "ours_outside_mean": float(ours_map[~gt_mask].mean()),
            "q_def_inside_mean": float(q_def_map[gt_mask].mean()),
            "q_def_outside_mean": float(q_def_map[~gt_mask].mean()),
            "q_fp_inside_mean": float(q_fp_map[gt_mask].mean()),
            "q_fp_outside_mean": float(q_fp_map[~gt_mask].mean()),
        },
        "artifacts": {
            "png": str(png_path),
            "pdf": str(pdf_path),
        },
    }
    with open(save_dir / f"{args.target_class}_semantic_refinement_explainer.json", "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
