from __future__ import annotations

import csv
import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

import matplotlib.pyplot as plt

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"

MODEL_SOURCES = {
    "AnomalyCLIP": RESULTS / "problem_spatial_anomalyclip_baseline" / "metrics.json",
    "AdaptCLIP": RESULTS / "problem_spatial_adaptclip_baseline" / "metrics.json",
    "AdaCLIP": RESULTS / "problem_spatial_adaclip_baseline" / "metrics.json",
    "FAPrompt": RESULTS / "problem_spatial_faprompt_baseline" / "metrics.json",
    "Bayes-PFL": RESULTS / "problem_spatial_bayespfl_baseline" / "metrics.json",
}

METRICS = [
    "inside_outside_gap",
    "outside_inside_ratio",
    "normal_topk_mean",
    "normal_map_mean",
]


def load_rows(path: Path):
    if not path.exists():
        return []
    with open(path, "r") as f:
        rows = json.load(f)
    return rows


def final_mean_row(rows):
    for row in rows:
        if row.get("class_name") == "mean":
            return row
    return None


def write_summary(summary_rows, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "spatial_final_summary.json", "w") as f:
        json.dump(summary_rows, f, indent=2)
    with open(save_dir / "spatial_final_summary.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["model", *METRICS, "num_anomaly", "num_normal"])
        writer.writeheader()
        writer.writerows(summary_rows)


def plot_bars(summary_rows, save_dir: Path):
    if not summary_rows:
        return
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes = axes.ravel()
    models = [row["model"] for row in summary_rows]
    for ax, metric in zip(axes, METRICS):
        vals = [row[metric] for row in summary_rows]
        ax.bar(models, vals)
        ax.set_title(metric)
        ax.tick_params(axis="x", rotation=30)
        ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(save_dir / "spatial_final_bars.png", dpi=200)
    plt.close(fig)


def main():
    save_dir = RESULTS / "problem_spatial_dashboard"
    summary_rows = []
    available = {}
    for model_name, path in MODEL_SOURCES.items():
        rows = load_rows(path)
        mean_row = final_mean_row(rows)
        if mean_row is None:
            continue
        summary_rows.append(
            {
                "model": model_name,
                **{metric: mean_row[metric] for metric in METRICS},
                "num_anomaly": mean_row["num_anomaly"],
                "num_normal": mean_row["num_normal"],
            }
        )
        available[model_name] = str(path)

    write_summary(summary_rows, save_dir)
    plot_bars(summary_rows, save_dir)
    with open(save_dir / "available_models.json", "w") as f:
        json.dump(available, f, indent=2)


if __name__ == "__main__":
    main()
