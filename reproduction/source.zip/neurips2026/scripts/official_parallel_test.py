from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter
from sklearn.metrics import average_precision_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from prompt_ensemble import encode_text_with_prompt_ensemble  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    decision_axis,
    get_or_collect_source_patch_banks,
    logmeanexp_negative_sqdist_1d,
    project_bank,
    topk_mean,
)
from utils import get_transform  # noqa: E402


def build_dataset(root: str, dataset_name: str, image_size: int, mode: str):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name=dataset_name, mode=mode)


def patch_text_score_map(patch_feature: torch.Tensor, text_pair: torch.Tensor, image_size: int) -> torch.Tensor:
    patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
    similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], image_size)
    return (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0


def smooth_map(batch_map: torch.Tensor, sigma: float) -> torch.Tensor:
    return torch.stack(
        [torch.from_numpy(gaussian_filter(arr, sigma=sigma)) for arr in batch_map.detach().cpu().numpy()],
        dim=0,
    )


def save_results(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def pixel_average_precision(results: dict, obj: str) -> float:
    gt = np.array(results[obj]["imgs_masks"])
    pr = np.array(results[obj]["anomaly_maps"])
    return float(average_precision_score(gt.ravel(), pr.ravel()))


def build_static_model(device: str):
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=None)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model


def main():
    parser = argparse.ArgumentParser("Official AnomalyCLIP baseline + parallel_margin test runner")
    parser.add_argument("--source_root", type=str, required=True)
    parser.add_argument("--source_dataset", type=str, required=True)
    parser.add_argument("--target_root", type=str, required=True)
    parser.add_argument("--target_dataset", type=str, required=True)
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--checkpoint_path", type=str, default=None)
    parser.add_argument("--save_dir", type=str, required=True)
    parser.add_argument("--text_source", type=str, choices=["learned", "static"], default="learned")
    parser.add_argument("--static_text_input", type=str, default="object")
    parser.add_argument("--heldout_class", type=str, default=None)
    parser.add_argument("--source_exclude_class", type=str, default=None)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=None)
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=None)
    parser.add_argument("--baseline_features_list", type=int, nargs="+", default=None)
    parser.add_argument("--baseline_feature_map_layer", type=int, nargs="+", default=None)
    parser.add_argument("--ours_features_list", type=int, nargs="+", default=None)
    parser.add_argument("--ours_feature_map_layer", type=int, nargs="+", default=None)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=2)
    parser.add_argument("--max_defect_per_class", type=int, default=4)
    parser.add_argument("--max_bank_per_layer", type=int, default=512)
    parser.add_argument("--max_fp_per_image", type=int, default=64)
    parser.add_argument("--max_defect_per_image", type=int, default=64)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--ours_bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_ours_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    args = parser.parse_args()

    if args.heldout_class is not None and str(args.heldout_class).lower() in {"", "none", "null", "all"}:
        args.heldout_class = None

    baseline_features_list = args.baseline_features_list or args.features_list or [24]
    baseline_feature_map_layer = args.baseline_feature_map_layer or args.feature_map_layer or [0]
    ours_features_list = args.ours_features_list or args.features_list or [24]
    ours_feature_map_layer = args.ours_feature_map_layer or args.feature_map_layer or [0]
    ours_bank_cache_path_arg = args.ours_bank_cache_path or args.bank_cache_path
    refresh_ours_bank_cache = args.refresh_ours_bank_cache or args.refresh_bank_cache

    if args.text_source == "learned":
        if not args.checkpoint_path:
            raise ValueError("--checkpoint_path is required when --text_source learned")
        model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
        learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
        text_pair = get_learned_text_pair(model, learner).to(args.device)
        cache_checkpoint_tag = args.checkpoint_path
    else:
        model = build_static_model(args.device)
        text_pair = encode_text_with_prompt_ensemble(model, [args.static_text_input], args.device).float()
        text_pair = F.normalize(text_pair, dim=-1).to(args.device)
        cache_checkpoint_tag = f"rawclip_static::{args.static_text_input}"
    axis = decision_axis(text_pair).to(args.device)
    source_exclude_class = args.source_exclude_class if args.source_exclude_class else args.heldout_class

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        text_pair=text_pair,
        data_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=ours_features_list,
        device=args.device,
        heldout_class=source_exclude_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=cache_checkpoint_tag,
        bank_cache_path=ours_bank_cache_path_arg,
        refresh_bank_cache=refresh_ours_bank_cache,
    )

    dataset = build_dataset(args.target_root, args.target_dataset, args.image_size, args.target_mode)
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)

    projected_banks = {}
    for layer_idx in range(len(ours_features_list)):
        fp_coeff, _ = project_bank(fp_banks[layer_idx].to(args.device), axis)
        def_coeff, _ = project_bank(def_banks[layer_idx].to(args.device), axis)
        projected_banks[layer_idx] = {"fp": fp_coeff, "defect": def_coeff}

    results = {}
    for mode in ("baseline_txt", "parallel_margin"):
        results[mode] = {}
        for obj in dataset.obj_list:
            results[mode][obj] = {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}

    with torch.no_grad():
        for idx, items in enumerate(loader, start=1):
            image = items["img"].to(args.device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"].clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            anomaly_flag = int(items["anomaly"].item()) if hasattr(items["anomaly"], "item") else int(items["anomaly"])

            results["baseline_txt"][cls_name]["gt_sp"].append(anomaly_flag)
            results["parallel_margin"][cls_name]["gt_sp"].append(anomaly_flag)
            results["baseline_txt"][cls_name]["imgs_masks"].append(gt_mask)
            results["parallel_margin"][cls_name]["imgs_masks"].append(gt_mask)

            image_features, baseline_patch_features = model.encode_image(image, baseline_features_list, DPAM_layer=20)
            image_features = F.normalize(image_features.float(), dim=-1)
            text_probs = image_features @ text_pair.unsqueeze(0).permute(0, 2, 1)
            text_probs = (text_probs / 0.07).softmax(-1)[:, 0, 1]

            if baseline_features_list == ours_features_list:
                ours_patch_features = baseline_patch_features
            else:
                _, ours_patch_features = model.encode_image(image, ours_features_list, DPAM_layer=20)

            baseline_layer_maps = []
            parallel_layer_maps = []
            for layer_idx, patch_feature in enumerate(baseline_patch_features):
                if layer_idx < baseline_feature_map_layer[0]:
                    continue
                baseline_layer_maps.append(patch_text_score_map(patch_feature, text_pair, args.image_size))

            for layer_idx, patch_feature in enumerate(ours_patch_features):
                if layer_idx < ours_feature_map_layer[0]:
                    continue

                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                coeff = patch @ axis
                q_fp = logmeanexp_negative_sqdist_1d(coeff, projected_banks[layer_idx]["fp"], tau=args.tau)
                q_def = logmeanexp_negative_sqdist_1d(coeff, projected_banks[layer_idx]["defect"], tau=args.tau)
                h = int(round(patch.shape[0] ** 0.5))
                parallel_map = (q_def - q_fp).reshape(1, 1, h, h)
                parallel_map = F.interpolate(parallel_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[:, 0]
                parallel_layer_maps.append(parallel_map)

            baseline_map = torch.stack(baseline_layer_maps).sum(dim=0)
            parallel_map = torch.stack(parallel_layer_maps).sum(dim=0)
            baseline_map = smooth_map(baseline_map, sigma=args.sigma)
            parallel_map = smooth_map(parallel_map, sigma=args.sigma)

            results["baseline_txt"][cls_name]["pr_sp"].extend(text_probs.detach().cpu())
            results["parallel_margin"][cls_name]["pr_sp"].append(topk_mean(parallel_map[0].numpy(), args.image_score_topk))
            results["baseline_txt"][cls_name]["anomaly_maps"].append(baseline_map)
            results["parallel_margin"][cls_name]["anomaly_maps"].append(parallel_map)

            if idx % 8 == 0:
                print(json.dumps({"stage": "eval_progress", "images_done": idx, "current_class": cls_name}), flush=True)

    rows = []
    for mode in ("baseline_txt", "parallel_margin"):
        pixel_aurocs = []
        pixel_aupros = []
        pixel_aps = []
        image_aurocs = []
        for obj in dataset.obj_list:
            if not results[mode][obj]["gt_sp"]:
                continue
            results[mode][obj]["imgs_masks"] = torch.cat(results[mode][obj]["imgs_masks"])
            results[mode][obj]["anomaly_maps"] = torch.cat(results[mode][obj]["anomaly_maps"]).detach().cpu().numpy()
            row = {
                "mode": mode,
                "target_label": obj,
                "pixel_auroc": float(pixel_level_metrics(results[mode], obj, "pixel-auroc")),
                "pixel_aupro": float(pixel_level_metrics(results[mode], obj, "pixel-aupro")),
                "pixel_ap": float(pixel_average_precision(results[mode], obj)),
                "image_auroc": float(image_level_metrics(results[mode], obj, "image-auroc")),
                "image_ap": float(image_level_metrics(results[mode], obj, "image-ap")),
            }
            rows.append(row)
            pixel_aurocs.append(row["pixel_auroc"])
            pixel_aupros.append(row["pixel_aupro"])
            pixel_aps.append(row["pixel_ap"])
            image_aurocs.append(row["image_auroc"])
        rows.append(
            {
                "mode": mode,
                "target_label": "mean",
                "pixel_auroc": float(np.mean(pixel_aurocs)),
                "pixel_aupro": float(np.mean(pixel_aupros)),
                "pixel_ap": float(np.mean(pixel_aps)),
                "image_auroc": float(np.mean(image_aurocs)),
                "image_ap": float("nan"),
            }
        )

    summary = {
        "checkpoint_path": args.checkpoint_path,
        "text_source": args.text_source,
        "static_text_input": args.static_text_input if args.text_source == "static" else None,
        "source_root": args.source_root,
        "source_dataset": args.source_dataset,
        "source_exclude_class": source_exclude_class,
        "target_root": args.target_root,
        "target_dataset": args.target_dataset,
        "target_mode": args.target_mode,
        "baseline_features_list": baseline_features_list,
        "baseline_feature_map_layer": baseline_feature_map_layer,
        "ours_features_list": ours_features_list,
        "ours_feature_map_layer": ours_feature_map_layer,
        "image_size": args.image_size,
        "sigma": args.sigma,
        "tau": args.tau,
        "image_score_topk": args.image_score_topk,
        "ours_bank_stats": bank_stats,
        "ours_bank_cache_path": str(bank_cache_path),
        "ours_bank_cache_meta": bank_cache_meta,
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
