from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
QUEUE = ROOT / "neurips2026/scripts/queue_rawclip_calibrated_ted_20260430.py"
LOG = ROOT / "neurips2026/results/rawclip_calibrated_ted_20260430/_logs/detached_queue.log"
PID_FILE = ROOT / "neurips2026/results/rawclip_calibrated_ted_20260430/_logs/detached_queue.pid"


def main() -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    log_file = LOG.open("a", buffering=1)
    proc = subprocess.Popen(
        [PY, "-u", str(QUEUE)],
        cwd=str(ROOT),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=log_file,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        close_fds=True,
    )
    PID_FILE.write_text(f"{proc.pid}\n")
    print({"stage": "detached_started", "pid": proc.pid, "log": str(LOG), "pid_file": str(PID_FILE)}, flush=True)


if __name__ == "__main__":
    main()
