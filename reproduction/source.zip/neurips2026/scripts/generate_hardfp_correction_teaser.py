from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"

BASELINE_HIST_IMAGE = RESULTS / "anomalyclip_map_separability_baseline_epoch5" / "hist.png"
OURS_HIST_IMAGE = RESULTS / "anomalyclip_map_separability_matched_epoch5" / "matched_topk_hist.png"
HOSTS = ["AnomalyCLIP", "AdaCLIP", "AdaptCLIP", "FAPrompt"]
HOST_FILES = {
    "AnomalyCLIP": RESULTS / "anomalyclip_map_separability_baseline_epoch5" / "summary.json",
    "AdaCLIP": RESULTS / "adaclip_map_separability_baseline_last" / "summary.json",
    "AdaptCLIP": RESULTS / "adaptclip_map_separability_baseline_epoch15" / "summary.json",
    "FAPrompt": RESULTS / "faprompt_map_separability_baseline_epoch15" / "summary.json",
}
DECOMP_FILES = {
    "VisA→MVTec": RESULTS / "anomalyclip_text_axis_decomposition_visa2mvtec_all_epoch15_discussion" / "summary.json",
    "MVTec→VisA": RESULTS / "anomalyclip_text_axis_decomposition_mvtec2visa_all_epoch15_discussion" / "summary.json",
    "MVTec→MPDD": RESULTS / "anomalyclip_text_axis_decomposition_mvtec2mpdd_epoch15_discussion" / "summary.json",
    "MVTec→BTAD": RESULTS / "anomalyclip_text_axis_decomposition_mvtec2btad_all_epoch15_discussion" / "summary.json",
}
COLORS = {
    "AnomalyCLIP": "#355C7D",
    "AdaCLIP": "#C06C84",
    "AdaptCLIP": "#6C5B7B",
    "FAPrompt": "#F8B195",
}


def load_json(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser("Generate hard-FP teaser with OURS correction panel")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULTS / "hardfp_correction_teaser_figure"),
    )
    args = parser.parse_args()

    baseline_rows = []
    for host in HOSTS:
        payload = load_json(HOST_FILES[host])["summary"]
        baseline_rows.append(
            {
                "host": host,
                "auc_true_defect_vs_hard_fp": float(payload["pairwise_auc"]["true_defect_vs_hard_fp"]),
            }
        )

    correction_rows = []
    for label, path in DECOMP_FILES.items():
        rows = load_json(path)["rows"]
        raw = next(r for r in rows if r["axis"] == "learned" and r["component"] == "raw")
        parallel = next(r for r in rows if r["axis"] == "learned" and r["component"] == "parallel")
        correction_rows.append(
            {
                "preset": label,
                "raw_inside_vs_fpoutside_auc": float(raw["inside_vs_fpoutside_auc"]),
                "parallel_inside_vs_fpoutside_auc": float(parallel["inside_vs_fpoutside_auc"]),
                "raw_pixel_auroc": float(raw["pixel_auroc"]),
                "parallel_pixel_auroc": float(parallel["pixel_auroc"]),
            }
        )

    fig = plt.figure(figsize=(22, 5.2), constrained_layout=True)
    gs = fig.add_gridspec(1, 4, width_ratios=[1.05, 1.05, 1.0, 1.25])
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[0, 2])
    ax3 = fig.add_subplot(gs[0, 3])

    ax0.imshow(mpimg.imread(BASELINE_HIST_IMAGE))
    ax0.axis("off")
    ax0.set_title("Baseline Overlap\n(True Defect vs Hard FP)")

    ax1.imshow(mpimg.imread(OURS_HIST_IMAGE))
    ax1.axis("off")
    ax1.set_title("OURS Overlap\n(Matched Top-k)")

    x = np.arange(len(HOSTS))
    vals = [r["auc_true_defect_vs_hard_fp"] for r in baseline_rows]
    ax2.bar(x, vals, color=[COLORS[h] for h in HOSTS], width=0.62)
    ax2.axhline(0.5, color="black", lw=0.9, ls="--", alpha=0.7)
    ax2.set_xticks(x, HOSTS, rotation=15, ha="right")
    ax2.set_ylim(0.0, 1.0)
    ax2.set_ylabel("AUC(True Defect > Hard FP)")
    ax2.set_title("Common Failure Across Hosts")
    ax2.grid(axis="y", alpha=0.2)
    for xi, y in zip(x, vals):
        ax2.text(xi, y + 0.02, f"{y:.2f}", ha="center", va="bottom", fontsize=9)

    y = np.arange(len(correction_rows))
    raw_vals = [r["raw_inside_vs_fpoutside_auc"] for r in correction_rows]
    par_vals = [r["parallel_inside_vs_fpoutside_auc"] for r in correction_rows]
    for i, row in enumerate(correction_rows):
        ax3.plot([raw_vals[i], par_vals[i]], [i, i], color="#888888", lw=1.8, zorder=1)
        ax3.scatter(raw_vals[i], i, color="#D95F02", s=60, zorder=2, label="Baseline raw" if i == 0 else None)
        ax3.scatter(par_vals[i], i, color="#1B9E77", s=60, zorder=2, label="OURS parallel" if i == 0 else None)
        delta = par_vals[i] - raw_vals[i]
        ax3.text(max(raw_vals[i], par_vals[i]) + 0.005, i, f"{delta:+.3f}", va="center", fontsize=9)
    ax3.set_yticks(y, [r["preset"] for r in correction_rows])
    ax3.set_xlim(0.84, 0.99)
    ax3.set_xlabel("AUC(Inside > FP-Outside)")
    ax3.set_title("OURS Reduces Hard-FP Entanglement\n(AnomalyCLIP raw → parallel)")
    ax3.grid(axis="x", alpha=0.2)
    ax3.legend(frameon=False, loc="lower right")

    fig.suptitle("Main Failure: Hard Normal vs True Defect Entanglement", fontsize=15)

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "baseline_rows": baseline_rows,
        "correction_rows": correction_rows,
        "baseline_hist_image": str(BASELINE_HIST_IMAGE),
        "ours_hist_image": str(OURS_HIST_IMAGE),
    }
    with open(save_dir / "hardfp_correction_teaser.json", "w") as f:
        json.dump(payload, f, indent=2)
    png = save_dir / "hardfp_correction_teaser.png"
    pdf = save_dir / "hardfp_correction_teaser.pdf"
    fig.savefig(png, dpi=220, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print(json.dumps({"png": str(png), "pdf": str(pdf)}, indent=2))


if __name__ == "__main__":
    main()
