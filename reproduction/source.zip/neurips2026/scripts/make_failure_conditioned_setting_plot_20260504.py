#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"

SEARCH_ROOTS = [
    ROOT / "neurips2026" / "results" / "failure_conditioned_separability_20260504",
    ROOT / "neurips2026" / "results" / "failure_conditioned_separability_grid_20260504",
    ROOT / "neurips2026" / "results" / "failure_conditioned_separability_faprompt_seeds_20260506",
    ROOT / "neurips2026" / "results" / "failure_conditioned_separability_extra_20260504",
    ROOT / "neurips2026" / "results" / "failure_conditioned_separability_aaclip_20260506",
    ROOT / "neurips2026" / "results" / "failure_conditioned_separability_anomalyclip_20260506",
]


def pct(x: float) -> float:
    return x * 100.0 if abs(x) <= 1.5 else x


def pick_cted(mapping: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(mapping, dict) or not mapping:
        return None
    for key in ("branch_calibrated_alpha_0.5", "prescore_calibrated_alpha_1"):
        if key in mapping:
            return mapping[key]
    return mapping[sorted(mapping.keys())[0]]


def mean_dict(items: list[dict[str, Any]], keys: list[str]) -> dict[str, float] | None:
    vals: dict[str, list[float]] = {k: [] for k in keys}
    for item in items:
        if not isinstance(item, dict):
            continue
        for key in keys:
            if key in item:
                vals[key].append(float(item[key]))
    if any(not v for v in vals.values()):
        return None
    return {k: float(np.mean(v)) for k, v in vals.items()}


def mean_from_per_class(data: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]] | None:
    per_class = data.get("per_class")
    if not isinstance(per_class, list) or not per_class:
        return None

    metric_keys = ["pixel_auc", "pixel_ap", "pixel_aupro"]
    sep_keys = [
        "auc_defect_vs_hardfp",
        "auc_defect_vs_outside",
        "mean_true_defect",
        "mean_hard_fp",
        "mean_outside",
    ]

    base_metrics = mean_dict([c.get("baseline_official", {}) for c in per_class], metric_keys)
    if base_metrics is None:
        return None

    cted_metric_items = []
    base_sep_items = []
    cted_sep_items = []
    for c in per_class:
        cted = pick_cted(c.get("parallel", {}))
        sep = c.get("separability", {})
        sep_b = sep.get("baseline_official") or sep.get("baseline")
        sep_c = pick_cted(sep.get("parallel", {}))
        if cted is not None:
            cted_metric_items.append(cted)
        if sep_b is not None:
            base_sep_items.append(sep_b)
        if sep_c is not None:
            cted_sep_items.append(sep_c)

    cted_metrics = mean_dict(cted_metric_items, metric_keys)
    base_sep = mean_dict(base_sep_items, sep_keys)
    cted_sep = mean_dict(cted_sep_items, sep_keys)
    if cted_metrics is None or base_sep is None or cted_sep is None:
        return None

    return base_metrics, cted_metrics, base_sep, cted_sep


def parse_setting(path: Path) -> dict[str, Any] | None:
    data = json.loads(path.read_text())
    if "summary" in data and "rows" in data:
        parsed = parse_rows_summary(path, data)
        if parsed is not None:
            return parsed

    mean = data.get("mean", {})
    sep = data.get("separability_mean", {})
    name = path.parent.name
    is_aaclip = "aaclip" in name.lower()
    base = mean.get("baseline_official") or mean.get("baseline")
    if is_aaclip:
        cted = pick_cted(mean.get("candidates", {}))
        sep_b = sep.get("baseline")
        sep_c = pick_cted(sep.get("candidates", {}))
    else:
        cted = pick_cted(mean.get("parallel", mean.get("candidates", {})))
        sep_b = sep.get("baseline_official") or sep.get("baseline")
        sep_c = pick_cted(sep.get("parallel", sep.get("candidates", {})))
    if not base or not cted or not sep_b or not sep_c:
        fallback = mean_from_per_class(data)
        if fallback is None:
            return None
        base, cted, sep_b, sep_c = fallback

    backbone = "ViT-L/14-336"
    if "vitbplus" in name:
        backbone = "ViT-B/16+"
    elif "vitl_openai" in name:
        backbone = "ViT-L/14"
    elif "vith14" in name:
        backbone = "ViT-H/14"
    elif "vitl336" in name:
        backbone = "ViT-L/14-336"

    transfer = name
    for prefix in (
        "faprompt_vitl336_",
        "faprompt_vitl_openai_",
        "faprompt_vith14_",
        "aaclip_vitbplus_",
    ):
        transfer = transfer.replace(prefix, "")
    for suffix in ("_seed0", "_seed1", "_seed2", "_seed3"):
        transfer = transfer.replace(suffix, "")

    pro_key = "pixel_aupro" if "pixel_aupro" in cted else "pixel_pro"
    d_pro = pct(float(cted[pro_key]) - float(base[pro_key]))
    d_ap = pct(float(cted["pixel_ap"]) - float(base["pixel_ap"]))
    d_pauc = pct(float(cted["pixel_auc"]) - float(base["pixel_auc"]))
    base_auc = float(sep_b["auc_defect_vs_hardfp"])
    cted_auc = float(sep_c["auc_defect_vs_hardfp"])
    base_gap = float(sep_b["mean_true_defect"]) - float(sep_b["mean_hard_fp"])
    cted_gap = float(sep_c["mean_true_defect"]) - float(sep_c["mean_hard_fp"])
    host = "AA-CLIP" if is_aaclip else "FAPrompt"
    return {
        "host": host,
        "backbone": backbone,
        "transfer": transfer,
        "baseline_hfp_competition": 1.0 - base_auc,
        "baseline_auc_d_hfp": base_auc,
        "cted_auc_d_hfp": cted_auc,
        "delta_auc_d_hfp": cted_auc - base_auc,
        "baseline_gap_d_hfp": base_gap,
        "cted_gap_d_hfp": cted_gap,
        "delta_gap_d_hfp": cted_gap - base_gap,
        "delta_pauc": d_pauc,
        "delta_pro": d_pro,
        "delta_ap": d_ap,
        "delta_local": 0.5 * (d_pro + d_ap),
        "path": str(path.relative_to(ROOT)),
    }


def row_mean(rows: list[dict[str, Any]], mode_candidates: list[str]) -> dict[str, Any] | None:
    for mode in mode_candidates:
        for row in rows:
            if row.get("mode") == mode and row.get("target_label") == "mean":
                return row
    return None


def sep_mean(sep: dict[str, Any], mode_candidates: list[str]) -> dict[str, Any] | None:
    if not isinstance(sep, dict):
        return None
    for mode in mode_candidates:
        item = sep.get(mode)
        if isinstance(item, dict):
            return item
    return None


def parse_rows_summary(path: Path, data: dict[str, Any]) -> dict[str, Any] | None:
    summary = data.get("summary", {})
    rows = data.get("rows", [])
    if not isinstance(summary, dict) or not isinstance(rows, list):
        return None

    base = row_mean(rows, ["baseline_txt", "baseline_official", "baseline"])
    cted = row_mean(rows, ["ted_calibrated", "ted_calibrated_vl", "parallel_margin", "ted_trainfree_vl"])
    sep = summary.get("separability_mean", {})
    sep_b = sep_mean(sep, ["baseline_txt", "baseline_official", "baseline"])
    sep_c = sep_mean(sep, ["ted_calibrated", "ted_calibrated_vl", "parallel_margin", "ted_trainfree_vl"])
    use_row_separability = False
    if (not sep_b or not sep_c) and "anomalyclip" in path.parent.name.lower():
        if "inside_vs_fpoutside_auc" in base and "inside_vs_fpoutside_auc" in cted:
            sep_b = {
                "auc_defect_vs_hardfp": float(base["inside_vs_fpoutside_auc"]),
                "mean_true_defect": float(base.get("inside_mean", float("nan"))),
                "mean_hard_fp": float(base.get("fpoutside_mean", float("nan"))),
            }
            sep_c = {
                "auc_defect_vs_hardfp": float(cted["inside_vs_fpoutside_auc"]),
                "mean_true_defect": float(cted.get("inside_mean", float("nan"))),
                "mean_hard_fp": float(cted.get("fpoutside_mean", float("nan"))),
            }
            use_row_separability = True
    if not base or not cted or not sep_b or not sep_c:
        return None

    name = path.parent.name
    host = (
        "AdaCLIP"
        if "adaclip" in name.lower()
        else "AdaptCLIP"
        if "adaptclip" in name.lower()
        else "AnomalyCLIP"
        if "anomalyclip" in name.lower()
        else "Host"
    )
    backbone = str(summary.get("backbone") or summary.get("pretrained_model") or "ViT-L/14-336")
    backbone = backbone.replace("ViT-L-14-336", "ViT-L/14-336").replace("ViT-L/14@336px", "ViT-L/14-336")
    transfer = f"{summary.get('source_dataset', 'src')}2{summary.get('target_dataset', 'tgt')}"

    d_pro = pct(float(cted["pixel_aupro"]) - float(base["pixel_aupro"]))
    d_ap = pct(float(cted["pixel_ap"]) - float(base["pixel_ap"]))
    d_pauc = pct(float(cted["pixel_auroc"]) - float(base["pixel_auroc"]))
    base_auc = float(sep_b["auc_defect_vs_hardfp"])
    cted_auc = float(sep_c["auc_defect_vs_hardfp"])
    if use_row_separability and "inside_fpoutside_gap" in base and "inside_fpoutside_gap" in cted:
        base_gap = float(base["inside_fpoutside_gap"])
        cted_gap = float(cted["inside_fpoutside_gap"])
    else:
        base_gap = float(sep_b["mean_true_defect"]) - float(sep_b["mean_hard_fp"])
        cted_gap = float(sep_c["mean_true_defect"]) - float(sep_c["mean_hard_fp"])
    return {
        "host": host,
        "backbone": backbone,
        "transfer": transfer,
        "baseline_hfp_competition": 1.0 - base_auc,
        "baseline_auc_d_hfp": base_auc,
        "cted_auc_d_hfp": cted_auc,
        "delta_auc_d_hfp": cted_auc - base_auc,
        "baseline_gap_d_hfp": base_gap,
        "cted_gap_d_hfp": cted_gap,
        "delta_gap_d_hfp": cted_gap - base_gap,
        "delta_pauc": d_pauc,
        "delta_pro": d_pro,
        "delta_ap": d_ap,
        "delta_local": 0.5 * (d_pro + d_ap),
        "path": str(path.relative_to(ROOT)),
    }


def collect() -> list[dict[str, Any]]:
    rows = []
    seen = set()
    for root in SEARCH_ROOTS:
        if not root.exists():
            continue
        for path in sorted(root.glob("*/summary.json")):
            row = parse_setting(path)
            if not row:
                continue
            key = (row["host"], row["backbone"], row["transfer"], row["path"])
            if key in seen:
                continue
            seen.add(key)
            rows.append(row)
    return sorted(rows, key=lambda r: (r["backbone"], r["transfer"]))


def write_csv(rows: list[dict[str, Any]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields = list(rows[0].keys())
    with (OUT / "failure_conditioned_setting_level_20260504.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def draw(rows: list[dict[str, Any]]) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    colors = {
        "FAPrompt": "#2F6F73",
        "AdaCLIP": "#D79A2B",
        "AdaptCLIP": "#6F5C8C",
    }
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.45))

    x = np.array([100.0 * r["baseline_hfp_competition"] for r in rows], dtype=float)
    y = np.array([r["delta_local"] for r in rows], dtype=float)
    z = np.array([100.0 * r["delta_gap_d_hfp"] for r in rows], dtype=float)
    c = [colors.get(r["host"], "#777777") for r in rows]

    for ax, yy, ylabel, title in [
        (axes[0], y, r"$\Delta$(PRO+AP)/2", "(a) Localization gain"),
        (axes[1], z, r"$\Delta$ score gap", "(b) Evidence margin"),
    ]:
        ax.axhline(0.0, color="#222222", lw=0.8)
        ax.scatter(x, yy, s=38, c=c, edgecolors="white", linewidths=0.6, alpha=0.95, zorder=3)
        if len(rows) >= 3 and np.std(x) > 1e-8:
            coef = np.polyfit(x, yy, 1)
            xs = np.linspace(float(x.min()), float(x.max()), 100)
            ax.plot(xs, coef[0] * xs + coef[1], color="#222222", lw=1.2, alpha=0.75)
            corr = float(np.corrcoef(x, yy)[0, 1])
            ax.text(
                0.03,
                0.95,
                f"r={corr:+.2f}",
                transform=ax.transAxes,
                ha="left",
                va="top",
                fontsize=7.5,
                fontweight="bold",
            )
        ax.set_title(title, fontsize=8.8, fontweight="bold", loc="left")
        ax.set_xlabel("baseline hard-FP competition", fontsize=7.8, fontweight="bold")
        ax.set_ylabel(ylabel, fontsize=7.8, fontweight="bold")
        ax.tick_params(labelsize=7.2)
        ax.grid(color="#E5E0D7", lw=0.65)
        ax.set_axisbelow(True)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)

    handles = []
    labels = []
    for bb, color in colors.items():
        if any(r["host"] == bb for r in rows):
            handles.append(plt.Line2D([0], [0], marker="o", linestyle="", color=color, markersize=4.5))
            labels.append(bb)
    axes[1].legend(handles, labels, frameon=False, fontsize=6.9, loc="lower right")
    fig.tight_layout(w_pad=0.85)
    fig.savefig(FIG / "failure_conditioned_setting_level_20260504.pdf", bbox_inches="tight")
    fig.savefig(FIG / "failure_conditioned_setting_level_20260504.png", dpi=300, bbox_inches="tight")

    tex = r"""\begin{figure}[t]
\centering
\includegraphics[width=1.0\columnwidth]{figure/failure_conditioned_setting_level_20260504.pdf}
\caption{
\textbf{Failure-conditioned gains.}
Each point is one fixed FAPrompt backbone--transfer setting.
The x-axis measures baseline hard-FP competition as $1-\mathrm{AUC}(\mathrm{defect},\mathrm{hard\text{-}FP})$; larger values indicate stronger baseline confusion.
}
\label{fig:failure_conditioned_setting_level}
\end{figure}
"""
    (OUT / "failure_conditioned_setting_level_figure_20260504.tex").write_text(tex)


def main() -> int:
    rows = collect()
    write_csv(rows)
    if rows:
        draw(rows)
    print(
        json.dumps(
            {
                "settings": len(rows),
                "csv": str((OUT / "failure_conditioned_setting_level_20260504.csv").relative_to(ROOT)),
                "figure": "figure/failure_conditioned_setting_level_20260504.pdf",
                "transfers": [f"{r['backbone']}:{r['transfer']}" for r in rows],
            },
            indent=2,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
