from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"


BACKBONES = [
    {
        "key": "rawclip_vitb",
        "label": "ViT-B",
        "pure_visual_metrics": [
            RESULTS / "rawclip_support_ablation_purevisual_maponly_quick" / "rawclip_vitb" / "metrics.json",
            RESULTS / "rawclip_support_ablation_purevisual_smoke" / "rawclip_vitb" / "metrics.json",
        ],
        "text_selected_metrics": RESULTS / "rawclip_support_ablation_textselected_maponly_quick" / "rawclip_vitb" / "metrics.json",
    },
    {
        "key": "rawclip_vitl",
        "label": "ViT-L",
        "pure_visual_metrics": [
            RESULTS / "rawclip_support_ablation_purevisual_maponly_quick" / "rawclip_vitl" / "metrics.json",
            RESULTS / "rawclip_support_ablation_purevisual_smoke" / "rawclip_vitl" / "metrics.json",
        ],
        "text_selected_metrics": RESULTS / "rawclip_support_ablation_maponly" / "rawclip_vitl" / "metrics.json",
    },
    {
        "key": "rawclip_vitl14openai",
        "label": "ViT-L OpenAI",
        "pure_visual_metrics": [
            RESULTS / "rawclip_support_ablation_purevisual_maponly_quick" / "rawclip_vitl14openai" / "metrics.json",
            RESULTS / "rawclip_support_ablation_purevisual_smoke" / "rawclip_vitl14openai" / "metrics.json",
        ],
        "text_selected_metrics": RESULTS / "rawclip_support_ablation_maponly" / "rawclip_vitl14openai" / "metrics.json",
    },
    {
        "key": "rawclip_vith14",
        "label": "ViT-H",
        "pure_visual_metrics": [
            RESULTS / "rawclip_support_ablation_purevisual_maponly_quick" / "rawclip_vith14" / "metrics.json",
            RESULTS / "rawclip_support_ablation_purevisual_smoke" / "rawclip_vith14" / "metrics.json",
        ],
        "text_selected_metrics": RESULTS / "rawclip_support_ablation_maponly" / "rawclip_vith14" / "metrics.json",
    },
]

PRESET = "visa2mvtec"
PRESET_LABEL = "VisA→MVTec"

METHOD_ORDER = [
    ("raw", "Raw"),
    ("pure_visual", "Pure visual only"),
        ("text_bank_visual", "Text-conditioned bank"),
        ("full_ours", "Full method"),
]

COLORS = {
    "raw": "#8C8C8C",
    "pure_visual": "#D95F02",
    "text_bank_visual": "#1B9E77",
    "full_ours": "#377EB8",
}


def load_row(path: Path, preset: str) -> dict:
    payload = json.loads(path.read_text())
    for row in payload["rows"]:
        if row["preset"] == preset:
            return row
    raise KeyError(f"{preset} not found in {path}")


def resolve_existing_path(candidates) -> Path:
    if isinstance(candidates, Path):
        return candidates
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(f"No metrics found in candidates: {candidates}")


def collect_rows() -> list[dict]:
    rows = []
    for spec in BACKBONES:
        pure_path = resolve_existing_path(spec["pure_visual_metrics"])
        pure = load_row(pure_path, PRESET)
        text = load_row(spec["text_selected_metrics"], PRESET)
        rows.append(
            {
                "backbone": spec["label"],
                "pure_visual_metrics_path": str(pure_path),
                "text_selected_metrics_path": str(spec["text_selected_metrics"]),
                "raw_wrong_pair_rate": pure["raw_wrong_pair_rate"],
                "pure_visual_wrong_pair_rate": pure["visual_wrong_pair_rate"],
                "text_bank_visual_wrong_pair_rate": text["visual_wrong_pair_rate"],
                "full_ours_wrong_pair_rate": text["text_wrong_pair_rate"],
                "raw_d": pure["raw_d"],
                "pure_visual_d": pure["visual_d"],
                "text_bank_visual_d": text["visual_d"],
                "full_ours_d": text["text_d"],
            }
        )
    return rows


def render_figure(rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 4.2), constrained_layout=True)

    x = np.arange(len(rows))
    width = 0.18
    offsets = np.array([-1.5, -0.5, 0.5, 1.5]) * width

    metric_specs = [
        ("wrong_pair_rate", "Wrong pair rate ↓", (0.0, 0.65)),
        ("d", "Separation (Cohen's d) ↑", (-0.35, 1.45)),
    ]

    for ax, (suffix, ylabel, ylim) in zip(axes, metric_specs):
        for method_idx, (method_key, method_label) in enumerate(METHOD_ORDER):
            vals = [row[f"{method_key}_{suffix}"] for row in rows]
            bars = ax.bar(
                x + offsets[method_idx],
                vals,
                width=width,
                color=COLORS[method_key],
                label=method_label,
                linewidth=0,
            )
            for bar, val in zip(bars, vals):
                y = val + 0.018 if suffix == "wrong_pair_rate" else val + 0.045
                ax.text(
                    bar.get_x() + bar.get_width() / 2.0,
                    y,
                    f"{val:.2f}",
                    ha="center",
                    va="bottom",
                    fontsize=9,
                    fontweight="bold",
                )

        ax.set_xticks(x, [row["backbone"] for row in rows], fontsize=11, fontweight="bold")
        ax.set_ylabel(ylabel, fontsize=13, fontweight="bold")
        ax.set_ylim(*ylim)
        ax.grid(axis="y", alpha=0.15)
        ax.tick_params(axis="y", labelsize=11)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)

    axes[1].legend(
        loc="upper left",
        bbox_to_anchor=(0.0, 1.02),
        ncol=2,
        frameon=False,
        fontsize=10.5,
    )

    fig.savefig(save_dir / "rawclip_purevision_ablation.png", dpi=260, bbox_inches="tight")
    fig.savefig(save_dir / "rawclip_purevision_ablation.pdf", bbox_inches="tight")
    plt.close(fig)


def render_tex(rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    lines = []
    lines.append("% rawclip pure-vision ablation, preset: VisA->MVTec")
    lines.append("\\begin{tabular}{lcccc}")
    lines.append("\\toprule")
    lines.append("Backbone & Raw & Pure visual only & Text bank + visual & Text bank + text \\\\")
    lines.append("\\midrule")
    for row in rows:
        vals = [
            row["raw_wrong_pair_rate"],
            row["pure_visual_wrong_pair_rate"],
            row["text_bank_visual_wrong_pair_rate"],
            row["full_ours_wrong_pair_rate"],
        ]
        best = int(np.argmin(vals))
        rendered = []
        for idx, val in enumerate(vals):
            token = f"{val:.3f}"
            if idx == best:
                token = f"\\textbf{{{token}}}"
            rendered.append(token)
        lines.append(f"{row['backbone']} & " + " & ".join(rendered) + " \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    (save_dir / "rawclip_purevision_ablation_wrong_pair_rate.tex").write_text("\n".join(lines))


def main() -> None:
    save_dir = RESULTS / "rawclip_purevision_ablation_figure"
    rows = collect_rows()
    render_figure(rows, save_dir)
    render_tex(rows, save_dir)
    with (save_dir / "rawclip_purevision_ablation.json").open("w") as f:
        json.dump({"preset": PRESET, "preset_label": PRESET_LABEL, "rows": rows}, f, indent=2)


if __name__ == "__main__":
    main()
