from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_abnormal_prompts,
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument("--target_layer", type=int, default=-1)
    parser.add_argument("--target_layers", nargs="*", type=int, default=[])
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--max_test_samples", type=int, default=0)
    parser.add_argument("--max_train_normals", type=int, default=50)
    parser.add_argument("--pca_rank", type=int, default=4)
    parser.add_argument("--min_dir_samples", type=int, default=2)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_patch_text_geometry")
    return parser.parse_args()


def resolve_layers(backbone, args: argparse.Namespace) -> list[int]:
    if args.target_layers:
        return sorted({int(x) for x in args.target_layers})
    if args.target_layer < 0:
        return [3, 6, 9, backbone.num_layers]
    return [int(args.target_layer)]


def build_text_anchor(backbone, class_name: str, abnormal: bool) -> torch.Tensor:
    state_prompts = state_level_abnormal_prompts if abnormal else state_level_normal_prompts
    class_text = class_name.replace("_", " ")
    prompts: list[str] = []
    for template in template_level_prompts:
        for state_prompt in state_prompts:
            prompts.append(template.format(state_prompt.format(class_text)))

    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)

    proj = getattr(backbone.visual, "proj", None)
    if proj is None:
        return text_anchor.cpu()

    token_anchor = proj.detach().float().to(text_anchor.device) @ text_anchor
    token_anchor = F.normalize(token_anchor, dim=0)
    return token_anchor.cpu()


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def to_mask_tokens(mask_np: np.ndarray, side_h: int, side_w: int, device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=(side_h, side_w), mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def collect_train_normal_tokens(backbone, class_name: str, layers: list[int], args: argparse.Namespace, device: str):
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "train")
    normal_indices = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"]
    if args.max_train_normals > 0:
        normal_indices = normal_indices[: min(len(normal_indices), int(args.max_train_normals))]

    by_layer: dict[int, list[torch.Tensor]] = {layer: [] for layer in layers}
    for idx in normal_indices:
        image_np, _, _, _, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens_by_layer = backbone.extract_layer_patch_tokens(image_t, target_layers=layers)
        for layer in layers:
            by_layer[layer].append(F.normalize(tokens_by_layer[layer][0].float(), dim=-1).cpu())
    return by_layer


def build_layer_normal_stats(
    token_list: list[torch.Tensor],
    abnormal_axis: torch.Tensor,
    pca_rank: int,
) -> dict[str, torch.Tensor | float]:
    stacked = torch.stack(token_list, dim=0).float()
    proto = F.normalize(stacked.mean(dim=0), dim=-1)
    centered = stacked - proto.unsqueeze(0)
    n_pos = centered.shape[1]
    rank = min(pca_rank, centered.shape[0], centered.shape[2])

    flat = stacked.reshape(-1, stacked.shape[-1])
    flat = flat - flat.mean(dim=0, keepdim=True)
    sv = torch.linalg.svdvals(flat)
    sv = sv[sv > 1e-8]
    if sv.numel() > 0:
        sv2 = sv.pow(2)
        prob = sv2 / sv2.sum()
        effective_rank = float(torch.exp(-(prob * prob.clamp_min(1e-12).log()).sum()).item())
        top1_var_ratio = float((sv2[0] / sv2.sum()).item())
        numeric_rank = int(sv.numel())
    else:
        effective_rank = float("nan")
        top1_var_ratio = float("nan")
        numeric_rank = 0

    bases: list[torch.Tensor] = []
    energies: list[float] = []
    for pos in range(n_pos):
        x = centered[:, pos, :]
        if torch.linalg.vector_norm(x).item() <= 1e-8 or rank <= 0:
            basis = torch.zeros((x.shape[1], 0), dtype=x.dtype)
            energy = 0.0
        else:
            _, _, v = torch.pca_lowrank(x, q=rank, center=False)
            basis = v[:, :rank]
            proj = basis.T @ abnormal_axis
            energy = float(proj.pow(2).sum().item())
        bases.append(basis)
        energies.append(energy)

    return {
        "prototype": proto,
        "bases": bases,
        "subspace_overlap_mean": float(np.mean(energies)),
        "subspace_overlap_median": float(np.median(energies)),
        "subspace_overlap_max": float(np.max(energies)),
        "global_numeric_rank": numeric_rank,
        "global_effective_rank": effective_rank,
        "global_top1_var_ratio": top1_var_ratio,
    }


def compute_directional_field_stats(
    direction_bank: list[list[torch.Tensor]],
    abnormal_axis: torch.Tensor,
    min_dir_samples: int,
) -> dict[str, float]:
    coherence_vals: list[float] = []
    variance_vals: list[float] = []
    axis_align_vals: list[float] = []
    valid_positions = 0
    for dirs in direction_bank:
        if len(dirs) < min_dir_samples:
            continue
        mat = F.normalize(torch.stack(dirs, dim=0).float(), dim=-1)
        mean_dir = mat.mean(dim=0)
        resultant = float(torch.linalg.vector_norm(mean_dir).item())
        coherence_vals.append(resultant)
        variance_vals.append(1.0 - resultant)
        axis_align_vals.append(float((mat @ abnormal_axis).mean().item()))
        valid_positions += 1

    if valid_positions == 0:
        return {
            "dir_valid_positions": 0,
            "dir_coherence_mean": float("nan"),
            "dir_variance_mean": float("nan"),
            "dir_axis_align_mean": float("nan"),
        }
    return {
        "dir_valid_positions": int(valid_positions),
        "dir_coherence_mean": float(np.mean(coherence_vals)),
        "dir_variance_mean": float(np.mean(variance_vals)),
        "dir_axis_align_mean": float(np.mean(axis_align_vals)),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    layers = resolve_layers(backbone, args)

    normal_anchor = build_text_anchor(backbone, args.class_name, abnormal=False).to(device=device, dtype=torch.float32)
    abnormal_anchor = build_text_anchor(backbone, args.class_name, abnormal=True).to(device=device, dtype=torch.float32)
    abnormal_axis = F.normalize(abnormal_anchor - normal_anchor, dim=0)

    train_tokens = collect_train_normal_tokens(backbone, args.class_name, layers, args, device)
    layer_stats = {
        layer: build_layer_normal_stats(train_tokens[layer], abnormal_axis.cpu(), args.pca_rank)
        for layer in layers
    }

    test_ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, args.class_name, "test")
    max_count = len(test_ds) if args.max_test_samples <= 0 else min(len(test_ds), int(args.max_test_samples))
    side_h, side_w = backbone.grid_size
    n_pos = side_h * side_w

    patch_labels_by_layer: dict[int, list[int]] = {layer: [] for layer in layers}
    patch_scores_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    image_labels_by_layer: dict[int, list[int]] = {layer: [] for layer in layers}
    image_scores_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    normal_patch_margin_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    anomaly_patch_margin_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    normal_patch_cos_normal_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    anomaly_patch_cos_normal_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    normal_patch_cos_abnormal_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    anomaly_patch_cos_abnormal_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    normal_patch_proj_scalar_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    anomaly_patch_proj_scalar_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    normal_patch_orth_absdot_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    anomaly_patch_orth_absdot_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    normal_patch_residual_delta_cos_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    anomaly_patch_residual_delta_cos_by_layer: dict[int, list[float]] = {layer: [] for layer in layers}
    direction_bank_by_layer: dict[int, list[list[torch.Tensor]]] = {
        layer: [[] for _ in range(n_pos)] for layer in layers
    }
    rows: list[dict] = []

    for idx in range(max_count):
        image_np, mask_np, label, name, img_type = test_ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        patch_mask = to_mask_tokens(mask_np, side_h, side_w, device)

        with torch.no_grad():
            tokens_by_layer = backbone.extract_layer_patch_tokens(image_t, target_layers=layers)

        row = {"name": name, "img_type": img_type, "label": int(label != 0)}
        for layer in layers:
            tokens = F.normalize(tokens_by_layer[layer][0].float(), dim=-1)
            cos_normal = (tokens @ normal_anchor).cpu().numpy()
            cos_abnormal = (tokens @ abnormal_anchor).cpu().numpy()
            margin = cos_normal - cos_abnormal
            score = cos_abnormal - cos_normal
            proj_scalar = tokens @ normal_anchor
            v_proj = proj_scalar.unsqueeze(-1) * normal_anchor.unsqueeze(0)
            residual_ns = tokens - v_proj
            orth_absdot = (residual_ns @ normal_anchor).abs().cpu().numpy()
            residual_delta_cos = F.cosine_similarity(
                residual_ns,
                abnormal_axis.unsqueeze(0).expand_as(residual_ns),
                dim=-1,
                eps=1e-8,
            ).cpu().numpy()

            proto = layer_stats[layer]["prototype"].to(tokens.device)  # type: ignore[index]
            residual = tokens - proto
            residual_norm = torch.linalg.vector_norm(residual, dim=-1)
            valid_dirs = residual_norm > 1e-8
            residual_dirs = torch.zeros_like(residual)
            residual_dirs[valid_dirs] = residual[valid_dirs] / residual_norm[valid_dirs].unsqueeze(-1)

            for pos, (pm, s, cn, ca, mg) in enumerate(
                zip(patch_mask.tolist(), score.tolist(), cos_normal.tolist(), cos_abnormal.tolist(), margin.tolist())
            ):
                patch_labels_by_layer[layer].append(int(pm))
                patch_scores_by_layer[layer].append(float(s))
                if pm > 0:
                    anomaly_patch_margin_by_layer[layer].append(float(mg))
                    anomaly_patch_cos_normal_by_layer[layer].append(float(cn))
                    anomaly_patch_cos_abnormal_by_layer[layer].append(float(ca))
                    anomaly_patch_proj_scalar_by_layer[layer].append(float(proj_scalar[pos].item()))
                    anomaly_patch_orth_absdot_by_layer[layer].append(float(orth_absdot[pos]))
                    anomaly_patch_residual_delta_cos_by_layer[layer].append(float(residual_delta_cos[pos]))
                    if bool(valid_dirs[pos].item()):
                        direction_bank_by_layer[layer][pos].append(residual_dirs[pos].detach().cpu())
                else:
                    normal_patch_margin_by_layer[layer].append(float(mg))
                    normal_patch_cos_normal_by_layer[layer].append(float(cn))
                    normal_patch_cos_abnormal_by_layer[layer].append(float(ca))
                    normal_patch_proj_scalar_by_layer[layer].append(float(proj_scalar[pos].item()))
                    normal_patch_orth_absdot_by_layer[layer].append(float(orth_absdot[pos]))
                    normal_patch_residual_delta_cos_by_layer[layer].append(float(residual_delta_cos[pos]))

            img_score = topk_mean(score, args.topk_ratio)
            image_labels_by_layer[layer].append(0 if label == 0 else 1)
            image_scores_by_layer[layer].append(img_score)

            row[f"layer{layer}_img_score_topk"] = img_score
            row[f"layer{layer}_patch_score_mean"] = float(score.mean())
            row[f"layer{layer}_margin_mean"] = float(margin.mean())
        rows.append(row)

    summary_rows: list[dict] = []
    for layer in layers:
        directional_stats = compute_directional_field_stats(
            direction_bank_by_layer[layer],
            abnormal_axis.cpu(),
            args.min_dir_samples,
        )
        normal_margin = normal_patch_margin_by_layer[layer]
        anomaly_margin = anomaly_patch_margin_by_layer[layer]
        normal_cos_normal = normal_patch_cos_normal_by_layer[layer]
        anomaly_cos_normal = anomaly_patch_cos_normal_by_layer[layer]
        normal_cos_abnormal = normal_patch_cos_abnormal_by_layer[layer]
        anomaly_cos_abnormal = anomaly_patch_cos_abnormal_by_layer[layer]
        normal_proj_scalar = normal_patch_proj_scalar_by_layer[layer]
        anomaly_proj_scalar = anomaly_patch_proj_scalar_by_layer[layer]
        normal_orth_absdot = normal_patch_orth_absdot_by_layer[layer]
        anomaly_orth_absdot = anomaly_patch_orth_absdot_by_layer[layer]
        normal_residual_delta_cos = normal_patch_residual_delta_cos_by_layer[layer]
        anomaly_residual_delta_cos = anomaly_patch_residual_delta_cos_by_layer[layer]

        summary_rows.append(
            {
                "class_name": args.class_name,
                "layer": int(layer),
                "num_test_images": len(rows),
                "num_train_normals": len(train_tokens[layer]),
                "normal_anchor_norm": float(torch.linalg.vector_norm(normal_anchor).item()),
                "abnormal_anchor_norm": float(torch.linalg.vector_norm(abnormal_anchor).item()),
                "delta_anchor_norm": float(torch.linalg.vector_norm(abnormal_axis).item()),
                "patch_auc_score": safe_auc(patch_labels_by_layer[layer], patch_scores_by_layer[layer]),
                "image_auc_topk_score": safe_auc(image_labels_by_layer[layer], image_scores_by_layer[layer]),
                "normal_patch_cos_normal_mean": float(np.mean(normal_cos_normal)) if normal_cos_normal else float("nan"),
                "anomaly_patch_cos_normal_mean": float(np.mean(anomaly_cos_normal)) if anomaly_cos_normal else float("nan"),
                "normal_patch_cos_abnormal_mean": float(np.mean(normal_cos_abnormal)) if normal_cos_abnormal else float("nan"),
                "anomaly_patch_cos_abnormal_mean": float(np.mean(anomaly_cos_abnormal)) if anomaly_cos_abnormal else float("nan"),
                "normal_patch_proj_scalar_mean": float(np.mean(normal_proj_scalar)) if normal_proj_scalar else float("nan"),
                "anomaly_patch_proj_scalar_mean": float(np.mean(anomaly_proj_scalar)) if anomaly_proj_scalar else float("nan"),
                "normal_patch_orth_absdot_mean": float(np.mean(normal_orth_absdot)) if normal_orth_absdot else float("nan"),
                "anomaly_patch_orth_absdot_mean": float(np.mean(anomaly_orth_absdot)) if anomaly_orth_absdot else float("nan"),
                "normal_patch_residual_delta_cos_mean": float(np.mean(normal_residual_delta_cos)) if normal_residual_delta_cos else float("nan"),
                "anomaly_patch_residual_delta_cos_mean": float(np.mean(anomaly_residual_delta_cos)) if anomaly_residual_delta_cos else float("nan"),
                "normal_patch_margin_mean": float(np.mean(normal_margin)) if normal_margin else float("nan"),
                "anomaly_patch_margin_mean": float(np.mean(anomaly_margin)) if anomaly_margin else float("nan"),
                "normality_margin_gap": (
                    float(np.mean(normal_margin)) - float(np.mean(anomaly_margin))
                    if normal_margin and anomaly_margin
                    else float("nan")
                ),
                "subspace_overlap_mean": float(layer_stats[layer]["subspace_overlap_mean"]),  # type: ignore[index]
                "subspace_overlap_median": float(layer_stats[layer]["subspace_overlap_median"]),  # type: ignore[index]
                "subspace_overlap_max": float(layer_stats[layer]["subspace_overlap_max"]),  # type: ignore[index]
                "global_numeric_rank": int(layer_stats[layer]["global_numeric_rank"]),  # type: ignore[index]
                "global_effective_rank": float(layer_stats[layer]["global_effective_rank"]),  # type: ignore[index]
                "global_top1_var_ratio": float(layer_stats[layer]["global_top1_var_ratio"]),  # type: ignore[index]
                "dir_valid_positions": directional_stats["dir_valid_positions"],
                "dir_coherence_mean": directional_stats["dir_coherence_mean"],
                "dir_variance_mean": directional_stats["dir_variance_mean"],
                "dir_axis_align_mean": directional_stats["dir_axis_align_mean"],
                "topk_ratio": float(args.topk_ratio),
                "pca_rank": int(args.pca_rank),
            }
        )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    layer_tag = "-".join(str(x) for x in layers)
    stem = f"{args.output_tag}_{args.class_name}_layers{layer_tag}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    with json_path.open("w") as f:
        json.dump({"summary_rows": summary_rows, "rows": rows}, f, indent=2)

    print(csv_path)
    print(json_path)
    print(json.dumps(summary_rows, indent=2))


if __name__ == "__main__":
    main()
