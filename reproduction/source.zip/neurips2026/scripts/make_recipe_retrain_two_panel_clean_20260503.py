from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)


RECIPES = ["Full(B)", "EL-r", "M2-r", "L2-r", "L-r"]


LAYER_GAINS = {
    "AdaCLIP": {
        "PRO": [47.97 - 44.03, 26.25 - 18.18, 25.42 - 23.50, 22.78 - 15.19, 46.27 - 34.83],
        "AP": [41.85 - 41.60, 23.81 - 22.40, 36.40 - 36.18, 39.28 - 36.35, 36.77 - 35.78],
    },
    "FAPrompt": {
        "PRO": [76.83 - 73.57, 77.16 - 74.70, 76.54 - 74.35, 76.63 - 72.73, 76.08 - 74.01],
        "AP": [30.94 - 22.35, 32.40 - 23.58, 31.46 - 22.58, 31.07 - 22.33, 31.68 - 23.01],
    },
}


BACKBONE_GAINS = [
    ("AdaCLIP", 21.43 - 19.74, 4.46 - 4.27),
    ("AdaptCLIP", 44.17 - 43.40, 15.92 - 15.22),
    ("AnomalyCLIP", 38.10 - 27.83, 5.23 - 5.06),
    ("FAPrompt", 37.96 - 35.51, 17.22 - 8.78),
]


def mean_band(metric: str):
    arr = np.asarray([LAYER_GAINS[host][metric] for host in ["AdaCLIP", "FAPrompt"]], dtype=float)
    return arr.mean(axis=0), arr.min(axis=0), arr.max(axis=0)


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 12,
            "axes.titlesize": 15,
            "axes.labelsize": 13,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    blue = "#1B5E8A"
    orange = "#B45F06"
    grid = "#D8D8D8"

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(9.6, 3.55),
        gridspec_kw={"width_ratios": [1.12, 0.88]},
        sharey=True,
    )

    # (a) Layer-wise retraining: mean over AdaCLIP and FAPrompt, band shows host range.
    ax = axes[0]
    x = np.arange(len(RECIPES))
    for metric, color, marker in [("PRO", blue, "o"), ("AP", orange, "s")]:
        mean, lo, hi = mean_band(metric)
        ax.fill_between(x, lo, hi, color=color, alpha=0.13, linewidth=0)
        ax.plot(x, mean, color=color, marker=marker, linewidth=2.8, markersize=6.8, label=f"{metric} gain")
        for xi, yi in zip(x, mean):
            ax.text(xi, yi + 0.33, f"{yi:.1f}", ha="center", va="bottom", fontsize=9.5, fontweight="bold", color=color)

    ax.set_title("(a) Layer-wise retraining", fontweight="bold", pad=8)
    ax.set_xticks(x)
    ax.set_xticklabels(RECIPES, rotation=28, ha="right")
    ax.set_ylabel("C-TED gain over B")
    ax.grid(axis="y", color=grid, linewidth=0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.text(
        0.02,
        0.94,
        "mean over AdaCLIP/FAPrompt\nband = host range",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9.5,
        color="#333333",
    )

    # (b) Backbone-wise retraining.
    ax = axes[1]
    labels = [v[0] for v in BACKBONE_GAINS]
    pro = np.asarray([v[1] for v in BACKBONE_GAINS])
    ap = np.asarray([v[2] for v in BACKBONE_GAINS])
    x = np.arange(len(labels))
    w = 0.34
    b1 = ax.bar(x - w / 2, pro, width=w, color=blue, alpha=0.92, label="PRO gain")
    b2 = ax.bar(x + w / 2, ap, width=w, color=orange, alpha=0.92, label="AP gain")
    for bars, color in [(b1, blue), (b2, orange)]:
        for bar in bars:
            h = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                h + 0.33,
                f"{h:.1f}",
                ha="center",
                va="bottom",
                fontsize=9.5,
                fontweight="bold",
                color=color,
            )

    ax.set_title("(b) Backbone-wise retraining", fontweight="bold", pad=8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=28, ha="right")
    ax.grid(axis="y", color=grid, linewidth=0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    for ax in axes:
        ax.axhline(0, color="#555555", linewidth=1.0)
        ax.set_ylim(-0.6, 12.4)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1.05), frameon=False, ncol=2, handlelength=2.0)
    fig.tight_layout(rect=(0, 0, 1, 0.96), w_pad=2.0)

    pdf = FIG_DIR / "recipe_retrain_two_panel_clean_20260503.pdf"
    png = FIG_DIR / "recipe_retrain_two_panel_clean_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")

    tex = OUT_DIR / "recipe_retrain_two_panel_clean_20260503.tex"
    tex.write_text(
        r"""\begin{figure*}[t]
\centering
\includegraphics[width=0.95\textwidth]{figure/recipe_retrain_two_panel_clean_20260503.pdf}
\caption{
Recipe-retraining diagnostics.
(a) Feature-layer recipes are retrained before evaluation; curves report mean C-TED gain over the retrained baseline across AdaCLIP and FAPrompt, with the shaded band indicating the host range.
(b) Backbone-wise retraining changes the host geometry, but C-TED remains useful after rebuilding source banks for the retrained backbone.
}
\label{fig:recipe_retrain_two_panel}
\end{figure*}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)


if __name__ == "__main__":
    main()
