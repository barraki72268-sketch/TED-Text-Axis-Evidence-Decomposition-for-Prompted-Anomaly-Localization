#!/usr/bin/env python3
"""Download a URL with resume support and periodic progress logs."""

from __future__ import annotations

import argparse
import os
import sys
import time
import urllib.request
from pathlib import Path


def format_size(n: float) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    for unit in units:
        if n < 1024 or unit == units[-1]:
            return f"{n:.2f}{unit}"
        n /= 1024
    return f"{n:.2f}TB"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--report-seconds", type=float, default=30.0)
    args = parser.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    existing = out.stat().st_size if out.exists() else 0
    headers = {"User-Agent": "Mozilla/5.0"}
    if existing:
        headers["Range"] = f"bytes={existing}-"

    req = urllib.request.Request(args.url, headers=headers)
    start = time.time()
    last = start
    downloaded = existing

    print(
        {
            "stage": "download_start",
            "url": args.url,
            "out": str(out),
            "resume_bytes": existing,
        },
        flush=True,
    )

    with urllib.request.urlopen(req, timeout=120) as response:
        content_length = response.headers.get("Content-Length")
        total = existing + int(content_length) if content_length is not None else None
        mode = "ab" if existing and response.status == 206 else "wb"
        if mode == "wb":
            downloaded = 0

        print(
            {
                "stage": "download_response",
                "status": response.status,
                "total": total,
                "total_human": format_size(total) if total else None,
                "mode": mode,
            },
            flush=True,
        )

        with out.open(mode + "") as f:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)

                now = time.time()
                if now - last >= args.report_seconds:
                    elapsed = max(now - start, 1e-6)
                    speed = (downloaded - existing) / elapsed
                    record = {
                        "stage": "download_progress",
                        "downloaded": downloaded,
                        "downloaded_human": format_size(downloaded),
                        "speed": format_size(speed) + "/s",
                    }
                    if total:
                        record["total_human"] = format_size(total)
                        record["pct"] = round(downloaded / total * 100, 2)
                    print(record, flush=True)
                    last = now

    final_size = out.stat().st_size
    print(
        {
            "stage": "download_done",
            "out": str(out),
            "bytes": final_size,
            "size_human": format_size(final_size),
        },
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
