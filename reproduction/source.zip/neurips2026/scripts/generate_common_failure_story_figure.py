from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026" / "results"
PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
PRESET_LABELS = ["VisA→MVTec", "MVTec→VisA", "MVTec→MPDD", "MVTec→BTAD"]
HOSTS = ["AnomalyCLIP", "AdaCLIP", "AdaptCLIP", "FAPrompt"]
HOST_KEYS = {
    "AnomalyCLIP": "anomalyclip",
    "AdaCLIP": "adaclip",
    "AdaptCLIP": "adaptclip",
    "FAPrompt": "faprompt",
}
HOST_COLORS = {
    "AnomalyCLIP": "#355C7D",
    "AdaCLIP": "#C06C84",
    "AdaptCLIP": "#6C5B7B",
    "FAPrompt": "#F8B195",
}


def load_summary(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)["summary"]


def zscore(mat: np.ndarray) -> np.ndarray:
    vals = mat.reshape(-1)
    mu = float(vals.mean())
    sigma = float(vals.std())
    if sigma < 1e-12:
        return np.zeros_like(mat)
    return (mat - mu) / sigma


def normalize01(mat: np.ndarray) -> np.ndarray:
    lo = float(np.min(mat))
    hi = float(np.max(mat))
    if hi - lo < 1e-12:
        return np.full_like(mat, 0.5)
    return (mat - lo) / (hi - lo)


def main() -> None:
    parser = argparse.ArgumentParser("Generate discussion-friendly common failure story figure")
    parser.add_argument("--run_tag", type=str, default="rerun1")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(RESULT_ROOT / "common_failure_story_figure"),
    )
    args = parser.parse_args()

    raw = {}
    for host_name, host_key in HOST_KEYS.items():
        raw[host_name] = {}
        for preset in PRESETS:
            path = RESULT_ROOT / f"common_failure_{host_key}_{preset}_{args.run_tag}" / "summary.json"
            raw[host_name][preset] = load_summary(path)

    inside_gap = np.array([[raw[h][p]["inside_outside_gap"] for p in PRESETS] for h in HOSTS], dtype=np.float32)
    outside_ratio = np.array([[raw[h][p]["outside_inside_ratio"] for p in PRESETS] for h in HOSTS], dtype=np.float32)
    normal_topk = np.array([[raw[h][p]["normal_topk_mean"] for p in PRESETS] for h in HOSTS], dtype=np.float32)
    normal_mean = np.array([[raw[h][p]["normal_map_mean"] for p in PRESETS] for h in HOSTS], dtype=np.float32)

    defect_focus_failure = 0.5 * zscore(-inside_gap) + 0.5 * zscore(np.log10(np.maximum(outside_ratio, 1e-10)))
    normal_leakage = 0.5 * zscore(np.log10(np.maximum(normal_topk, 1e-10))) + 0.5 * zscore(np.log10(np.maximum(normal_mean, 1e-10)))

    defect_avg = defect_focus_failure.mean(axis=1)
    normal_avg = normal_leakage.mean(axis=1)

    fig = plt.figure(figsize=(22, 5.8), constrained_layout=True)
    gs = fig.add_gridspec(1, 4, width_ratios=[1.15, 1.15, 1.4, 1.4])
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[0, 2])
    ax3 = fig.add_subplot(gs[0, 3])

    y = np.arange(len(HOSTS))
    colors = [HOST_COLORS[h] for h in HOSTS]

    order0 = np.argsort(defect_avg)
    ax0.barh(np.arange(len(HOSTS)), defect_avg[order0], color=[colors[i] for i in order0], alpha=0.9)
    ax0.set_yticks(np.arange(len(HOSTS)), [HOSTS[i] for i in order0])
    ax0.axvline(0.0, color="black", lw=0.8, alpha=0.6)
    ax0.set_title("Defect Focus Failure\n(higher = worse)")
    ax0.grid(axis="x", alpha=0.2)
    for i, idx in enumerate(order0):
        ax0.text(defect_avg[idx], i, f" {defect_avg[idx]:.2f}", va="center", ha="left", fontsize=9)

    order1 = np.argsort(normal_avg)
    ax1.barh(np.arange(len(HOSTS)), normal_avg[order1], color=[colors[i] for i in order1], alpha=0.9)
    ax1.set_yticks(np.arange(len(HOSTS)), [HOSTS[i] for i in order1])
    ax1.axvline(0.0, color="black", lw=0.8, alpha=0.6)
    ax1.set_title("Normal Leakage\n(higher = worse)")
    ax1.grid(axis="x", alpha=0.2)
    for i, idx in enumerate(order1):
        ax1.text(normal_avg[idx], i, f" {normal_avg[idx]:.2f}", va="center", ha="left", fontsize=9)

    hm0 = ax2.imshow(normalize01(defect_focus_failure), cmap="magma", vmin=0.0, vmax=1.0, aspect="auto")
    ax2.set_title("Per-Preset Defect Focus Failure")
    ax2.set_xticks(np.arange(len(PRESETS)), PRESET_LABELS, rotation=20, ha="right")
    ax2.set_yticks(np.arange(len(HOSTS)), HOSTS)
    ax2.set_xticks(np.arange(-0.5, len(PRESETS), 1), minor=True)
    ax2.set_yticks(np.arange(-0.5, len(HOSTS), 1), minor=True)
    ax2.grid(which="minor", color="white", linewidth=1.0)
    ax2.tick_params(which="minor", bottom=False, left=False)
    for i in range(len(HOSTS)):
        for j in range(len(PRESETS)):
            color = "white" if normalize01(defect_focus_failure)[i, j] > 0.5 else "black"
            ax2.text(j, i, f"{defect_focus_failure[i, j]:.2f}", ha="center", va="center", fontsize=9, color=color)
    cbar2 = fig.colorbar(hm0, ax=ax2, fraction=0.046, pad=0.03)
    cbar2.ax.tick_params(labelsize=8)

    hm1 = ax3.imshow(normalize01(normal_leakage), cmap="magma", vmin=0.0, vmax=1.0, aspect="auto")
    ax3.set_title("Per-Preset Normal Leakage")
    ax3.set_xticks(np.arange(len(PRESETS)), PRESET_LABELS, rotation=20, ha="right")
    ax3.set_yticks(np.arange(len(HOSTS)), HOSTS)
    ax3.set_xticks(np.arange(-0.5, len(PRESETS), 1), minor=True)
    ax3.set_yticks(np.arange(-0.5, len(HOSTS), 1), minor=True)
    ax3.grid(which="minor", color="white", linewidth=1.0)
    ax3.tick_params(which="minor", bottom=False, left=False)
    for i in range(len(HOSTS)):
        for j in range(len(PRESETS)):
            color = "white" if normalize01(normal_leakage)[i, j] > 0.5 else "black"
            ax3.text(j, i, f"{normal_leakage[i, j]:.2f}", ha="center", va="center", fontsize=9, color=color)
    cbar3 = fig.colorbar(hm1, ax=ax3, fraction=0.046, pad=0.03)
    cbar3.ax.tick_params(labelsize=8)

    fig.suptitle("Common Failure Story Across CLIP-Based AD Hosts", fontsize=15)

    payload = {
        "run_tag": args.run_tag,
        "defect_focus_failure": defect_focus_failure.tolist(),
        "normal_leakage": normal_leakage.tolist(),
        "defect_avg": {HOSTS[i]: float(defect_avg[i]) for i in range(len(HOSTS))},
        "normal_avg": {HOSTS[i]: float(normal_avg[i]) for i in range(len(HOSTS))},
        "raw": raw,
    }

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    png = save_dir / "common_failure_story.png"
    pdf = save_dir / "common_failure_story.pdf"
    fig.savefig(png, dpi=220, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    with open(save_dir / "common_failure_story.json", "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps({"png": str(png), "pdf": str(pdf)}, indent=2))


if __name__ == "__main__":
    main()
