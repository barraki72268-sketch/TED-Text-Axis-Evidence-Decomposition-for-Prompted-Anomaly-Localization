from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from scipy.ndimage import gaussian_filter
from sklearn.metrics import average_precision_score
from torchvision import transforms

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
for path in (WINCLIP_ROOT, ANO_ROOT, ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from WinCLIP import WinClipAD  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from neurips2026.scripts.official_parallel_test_rawclip import (  # noqa: E402
    GenericMetaDataset,
    farthest_point_subsample,
    logmeanexp_negative_sqdist_1d,
    topk_mean,
)


def build_mask_transform(image_size: int):
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.NEAREST),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
        ]
    )


def smooth_np(arr: np.ndarray, sigma: float) -> np.ndarray:
    if sigma <= 0:
        return arr
    return gaussian_filter(arr, sigma=sigma)


def spatial_tanh_zscore_np(arr: np.ndarray) -> np.ndarray:
    arr = arr.astype(np.float32)
    scale = float(arr.std())
    if scale < 1e-6:
        return np.zeros_like(arr, dtype=np.float32)
    return np.tanh((arr - float(arr.mean())) / scale).astype(np.float32)


def host_residual_map(
    baseline_arr: np.ndarray,
    residual_arr: np.ndarray,
    lam: float,
    gate_quantile: float,
    gate_temp: float,
) -> np.ndarray:
    base = baseline_arr.astype(np.float32)
    residual = spatial_tanh_zscore_np(residual_arr)
    flat = base.reshape(-1)
    scale = float(flat.std())
    if scale < 1e-6:
        scale = 1.0
    threshold = float(np.quantile(flat, float(gate_quantile)))
    gate = 1.0 / (1.0 + np.exp(-((base - threshold) / (scale * max(float(gate_temp), 1e-6)))))
    return (base + float(lam) * scale * gate.astype(np.float32) * residual).astype(np.float32)


def safe_pixel_metric(results: dict, obj: str, metric: str) -> float:
    try:
        return float(pixel_level_metrics(results, obj, metric))
    except Exception:
        return float("nan")


def text_axis(model: WinClipAD) -> torch.Tensor:
    normal = F.normalize(model.avr_normal_text_features.float(), dim=-1)[0]
    anomaly = F.normalize(model.avr_abnormal_text_features.float(), dim=-1)[0]
    return F.normalize(anomaly - normal, dim=0)


def textual_window_scores(model: WinClipAD, visual_features: list[torch.Tensor]) -> torch.Tensor:
    scores = []
    for features in visual_features:
        logits = 100.0 * features.float() @ model.text_features.float().T
        scores.append(logits.softmax(dim=-1)[:, 1])
    return torch.cat(scores, dim=0)


def textual_window_invnormal_values(model: WinClipAD, visual_features: list[torch.Tensor]) -> list[torch.Tensor]:
    values = []
    for features in visual_features:
        logits = 100.0 * features.float() @ model.text_features.float().T
        normality = logits.softmax(dim=-1)[:, 0]
        values.append((1.0 / normality.clamp_min(1e-6)).float())
    return values


def scale_slices(model: WinClipAD) -> list[tuple[int, int]]:
    starts = list(model.scale_begin_indx)
    ends = starts[1:] + [len(model.masks)]
    return list(zip(starts, ends))


def window_scale_ids(model: WinClipAD) -> list[int]:
    ids = [0] * len(model.masks)
    for scale_idx, (start, end) in enumerate(scale_slices(model)):
        for window_idx in range(start, end):
            ids[window_idx] = scale_idx
    return ids


def window_mask_indices(model: WinClipAD, window_idx: int, device: str | torch.device) -> torch.Tensor:
    mask = model.masks[window_idx].reshape(-1).to(device)
    if mask.dtype == torch.bool and mask.numel() == model.grid_size[0] * model.grid_size[1]:
        return torch.nonzero(mask, as_tuple=False).flatten()
    return mask.long()


def remap_window_values(model: WinClipAD, values: list[torch.Tensor], image_size: int, sigma: float) -> np.ndarray:
    n = values[0].shape[0]
    token_scores = torch.zeros((n, model.grid_size[0] * model.grid_size[1]), device=values[0].device)
    token_weights = torch.zeros_like(token_scores)
    scale_maps = []
    for idx, (score, mask) in enumerate(zip(values, model.masks)):
        if idx in model.scale_begin_indx[1:]:
            scale_maps.append(token_scores / token_weights.clamp_min(1e-6))
            token_scores = torch.zeros_like(token_scores)
            token_weights = torch.zeros_like(token_weights)
        mask_flat = mask.reshape(-1).to(values[0].device)
        if mask_flat.dtype == torch.bool and mask_flat.numel() == token_scores.shape[1]:
            token_idx = mask_flat
        else:
            token_idx = mask_flat.long()
        token_scores[:, token_idx] += score.unsqueeze(1)
        token_weights[:, token_idx] += 1.0
    scale_maps.append(token_scores / token_weights.clamp_min(1e-6))
    fused = torch.stack(scale_maps, dim=0).mean(dim=0)
    fused = fused.reshape(n, 1, model.grid_size[0], model.grid_size[1])
    fused = F.interpolate(fused, size=(image_size, image_size), mode="bilinear", align_corners=False)[:, 0]
    arr = fused[0].detach().float().cpu().numpy()
    return smooth_np(arr, sigma=sigma).astype(np.float32)


def remap_winclip_invnormal_values(model: WinClipAD, values: list[torch.Tensor], image_size: int, sigma: float) -> np.ndarray:
    n = values[0].shape[0]
    token_scores = torch.zeros((n, model.grid_size[0] * model.grid_size[1]), device=values[0].device)
    token_weights = torch.zeros_like(token_scores)
    scale_maps = []
    for idx, (score, mask) in enumerate(zip(values, model.masks)):
        if idx in model.scale_begin_indx[1:]:
            scale_maps.append(token_scores / token_weights.clamp_min(1e-6))
            token_scores = torch.zeros_like(token_scores)
            token_weights = torch.zeros_like(token_weights)
        mask_flat = mask.reshape(-1).to(values[0].device)
        if mask_flat.dtype == torch.bool and mask_flat.numel() == token_scores.shape[1]:
            token_idx = mask_flat
        else:
            token_idx = mask_flat.long()
        token_scores[:, token_idx] += score.unsqueeze(1)
        token_weights[:, token_idx] += 1.0
    scale_maps.append(token_scores / token_weights.clamp_min(1e-6))
    fused_invnormal = torch.stack(scale_maps, dim=0).mean(dim=0)
    fused = 1.0 - 1.0 / fused_invnormal.clamp_min(1e-6)
    fused = fused.reshape(n, 1, model.grid_size[0], model.grid_size[1])
    fused = F.interpolate(fused, size=(image_size, image_size), mode="bilinear", align_corners=False)[:, 0]
    arr = fused[0].detach().float().cpu().numpy()
    return smooth_np(arr, sigma=sigma).astype(np.float32)


def calibrated_window_invnormal_values(
    host_values: list[torch.Tensor],
    residual_values: list[torch.Tensor],
    lam: float,
    gate_quantile: float,
    gate_temp: float,
) -> list[torch.Tensor]:
    host_flat = torch.cat([v.float() for v in host_values], dim=0)
    residual_flat = torch.cat([v.float().to(host_flat.device) for v in residual_values], dim=0)
    host_anom = 1.0 - 1.0 / host_flat.clamp_min(1e-6)
    residual_z = torch.tanh((residual_flat - residual_flat.mean()) / residual_flat.std(unbiased=False).clamp_min(1e-6))
    gate_base = host_anom.detach().float().cpu()
    threshold = torch.tensor(float(torch.quantile(gate_base, float(gate_quantile))), device=host_flat.device)
    gate_scale = host_anom.std(unbiased=False).clamp_min(1e-6)
    gate = torch.sigmoid((host_anom - threshold) / (gate_scale * max(float(gate_temp), 1e-6)))
    host_scale = host_flat.std(unbiased=False).clamp_min(1e-6)
    corrected_flat = (host_flat + float(lam) * host_scale * gate * residual_z).clamp_min(1.000001)
    out = []
    offset = 0
    for values in host_values:
        out.append(corrected_flat[offset : offset + values.numel()])
        offset += values.numel()
    return out


def calibrated_window_invnormal_values_scalewise(
    model: WinClipAD,
    host_values: list[torch.Tensor],
    residual_values: list[torch.Tensor],
    lam: float,
    gate_quantile: float,
    gate_temp: float,
) -> list[torch.Tensor]:
    corrected: list[torch.Tensor | None] = [None] * len(host_values)
    for start, end in scale_slices(model):
        host_flat = torch.cat([v.float() for v in host_values[start:end]], dim=0)
        residual_flat = torch.cat([v.float().to(host_flat.device) for v in residual_values[start:end]], dim=0)
        host_anom = 1.0 - 1.0 / host_flat.clamp_min(1e-6)
        residual_z = torch.tanh((residual_flat - residual_flat.mean()) / residual_flat.std(unbiased=False).clamp_min(1e-6))
        threshold = torch.tensor(
            float(torch.quantile(host_anom.detach().float().cpu(), float(gate_quantile))),
            device=host_flat.device,
        )
        gate_scale = host_anom.std(unbiased=False).clamp_min(1e-6)
        gate = torch.sigmoid((host_anom - threshold) / (gate_scale * max(float(gate_temp), 1e-6)))
        host_scale = host_flat.std(unbiased=False).clamp_min(1e-6)
        corrected_flat = (host_flat + float(lam) * host_scale * gate * residual_z).clamp_min(1.000001)
        offset = 0
        for window_idx in range(start, end):
            n = host_values[window_idx].numel()
            corrected[window_idx] = corrected_flat[offset : offset + n]
            offset += n
    return [v for v in corrected if v is not None]


def logmeanexp_negative_sqdist_nd(query: torch.Tensor, bank: torch.Tensor, tau: float) -> torch.Tensor:
    if bank.numel() == 0:
        return torch.full((query.shape[0],), -20.0, device=query.device, dtype=query.dtype)
    dist = (query[:, None, :] - bank[None, :, :]).pow(2).sum(dim=-1)
    return torch.logsumexp(-dist / max(float(tau), 1e-6), dim=1) - math.log(bank.shape[0])


def _orthonormalize_columns(mat: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    basis = []
    for i in range(mat.shape[1]):
        v = mat[:, i].float()
        for u in basis:
            v = v - torch.dot(v, u) * u
        norm = torch.norm(v)
        if float(norm.item()) > eps:
            basis.append(v / norm)
    if not basis:
        return F.normalize(mat[:, :1].float(), dim=0)
    return torch.stack(basis, dim=1)


def build_defect_parallel_basis(
    fp_bank: torch.Tensor,
    def_bank: torch.Tensor,
    axis: torch.Tensor,
    rank: int,
    device: str,
) -> torch.Tensor:
    fp = F.normalize(fp_bank.float().to(device), dim=-1)
    defect = F.normalize(def_bank.float().to(device), dim=-1)
    axis = F.normalize(axis.float().to(device), dim=0)
    cols = [axis]
    if fp.numel() > 0 and defect.numel() > 0:
        cols.append(F.normalize(defect.mean(dim=0) - fp.mean(dim=0), dim=0))
        n = min(fp.shape[0], defect.shape[0], 4096)
        if n > 4 and rank > 2:
            pair_diff = defect[:n] - fp[:n]
            pair_diff = pair_diff - pair_diff.mean(dim=0, keepdim=True)
            try:
                _, _, vh = torch.linalg.svd(pair_diff.float(), full_matrices=False)
                for pc in vh[: max(0, int(rank) - len(cols))]:
                    cols.append(F.normalize(pc, dim=0))
            except RuntimeError:
                pass
    basis = _orthonormalize_columns(torch.stack(cols, dim=1))
    return basis[:, : max(1, int(rank))]


def build_rankr_density_calibrator(
    fp_bank: torch.Tensor,
    def_bank: torch.Tensor,
    axis: torch.Tensor,
    rank: int,
    rankr_tau: float,
    device: str,
    fp_host: torch.Tensor | None = None,
    def_host: torch.Tensor | None = None,
    eta_max: float = 1.0,
) -> dict | None:
    if fp_bank.numel() == 0 or def_bank.numel() == 0:
        return None
    basis = build_defect_parallel_basis(fp_bank, def_bank, axis, rank=rank, device=device)
    fp = F.normalize(fp_bank.float().to(device), dim=-1)
    defect = F.normalize(def_bank.float().to(device), dim=-1)
    fp_coords_raw = fp @ basis
    def_coords_raw = defect @ basis
    all_coords = torch.cat([fp_coords_raw, def_coords_raw], dim=0)
    coord_mean = all_coords.mean(dim=0)
    coord_std = all_coords.std(dim=0).clamp_min(1e-6)
    fp_coords = (fp_coords_raw - coord_mean) / coord_std
    def_coords = (def_coords_raw - coord_mean) / coord_std
    fp_score = logmeanexp_negative_sqdist_nd(fp_coords, def_coords, rankr_tau) - logmeanexp_negative_sqdist_nd(fp_coords, fp_coords, rankr_tau)
    def_score = logmeanexp_negative_sqdist_nd(def_coords, def_coords, rankr_tau) - logmeanexp_negative_sqdist_nd(def_coords, fp_coords, rankr_tau)
    eta = 1.0
    source_margin = float((def_score.mean() - fp_score.mean()).item())
    if fp_host is not None and def_host is not None and fp_host.numel() and def_host.numel():
        fp_h = (1.0 - 1.0 / fp_host.float().to(device).clamp_min(1e-6)).flatten()
        def_h = (1.0 - 1.0 / def_host.float().to(device).clamp_min(1e-6)).flatten()
        fp_r = (fp_score - fp_score.mean()) / fp_score.std(unbiased=False).clamp_min(1e-6)
        def_r = (def_score - def_score.mean()) / def_score.std(unbiased=False).clamp_min(1e-6)
        candidates = torch.linspace(-float(eta_max), float(eta_max), steps=81, device=device)
        losses = []
        for cand in candidates:
            # Source-only scalar selection: prefer defect windows over hard normal windows.
            margin = (def_h.mean() + cand * def_r.mean()) - (fp_h.mean() + cand * fp_r.mean())
            losses.append(-margin)
        eta = float(candidates[int(torch.argmin(torch.stack(losses)).item())].item())
    return {
        "calibration": "winclip_source_calibrated_rankr_density_no_target",
        "basis": basis.detach().cpu(),
        "coord_mean": coord_mean.detach().cpu(),
        "coord_std": coord_std.detach().cpu(),
        "fp_coords": fp_coords.detach().cpu(),
        "def_coords": def_coords.detach().cpu(),
        "subspace_rank": int(basis.shape[1]),
        "rankr_tau": float(rankr_tau),
        "source_score_fp_mean": float(fp_score.mean().item()),
        "source_score_def_mean": float(def_score.mean().item()),
        "source_margin": source_margin,
        "eta": eta,
    }


def calibrated_density_tokens(tokens: torch.Tensor, calibrator: dict) -> torch.Tensor:
    basis = calibrator["basis"].to(tokens.device).float()
    coord_mean = calibrator["coord_mean"].to(tokens.device).float()
    coord_std = calibrator["coord_std"].to(tokens.device).float().clamp_min(1e-6)
    fp_coords = calibrator["fp_coords"].to(tokens.device).float()
    def_coords = calibrator["def_coords"].to(tokens.device).float()
    coords = (F.normalize(tokens.float(), dim=-1) @ basis - coord_mean) / coord_std
    q_fp = logmeanexp_negative_sqdist_nd(coords, fp_coords, tau=float(calibrator["rankr_tau"]))
    q_def = logmeanexp_negative_sqdist_nd(coords, def_coords, tau=float(calibrator["rankr_tau"]))
    return float(calibrator.get("eta", 1.0)) * (q_def - q_fp)


def collect_banks(
    model: WinClipAD,
    source_root: str,
    class_name: str,
    image_size: int,
    max_good: int,
    max_defect: int,
    hard_frac: float,
    max_bank: int,
    defect_overlap_min: float,
    max_windows_per_image_scale: int,
) -> tuple[dict[int, torch.Tensor], dict[int, torch.Tensor], dict[int, torch.Tensor], dict[int, torch.Tensor], dict]:
    mask_transform = build_mask_transform(image_size)
    train_ds = GenericMetaDataset(source_root, model.transform, mask_transform, "train")
    test_ds = GenericMetaDataset(source_root, model.transform, mask_transform, "test")
    slices = scale_slices(model)
    scale_ids = window_scale_ids(model)
    fp_chunks: dict[int, list[torch.Tensor]] = {idx: [] for idx in range(len(slices))}
    def_chunks: dict[int, list[torch.Tensor]] = {idx: [] for idx in range(len(slices))}
    fp_host_chunks: dict[int, list[torch.Tensor]] = {idx: [] for idx in range(len(slices))}
    def_host_chunks: dict[int, list[torch.Tensor]] = {idx: [] for idx in range(len(slices))}
    good_count = 0
    defect_count = 0
    device = model.device

    with torch.no_grad():
        for item in train_ds:
            if class_name and item["cls_name"] != class_name:
                continue
            if good_count >= max_good:
                break
            model.build_text_feature_gallery(item["cls_name"])
            image = item["img"].unsqueeze(0).to(device)
            visual_features = model.encode_image(image)
            host_values = textual_window_invnormal_values(model, visual_features)
            for scale_idx, (start, end) in enumerate(slices):
                scale_feats = torch.cat([feat.float() for feat in visual_features[start:end]], dim=0)
                scale_scores = torch.cat([v.float() for v in host_values[start:end]], dim=0)
                k = max(1, int(round(scale_scores.numel() * hard_frac)))
                k = min(k, max(1, int(max_windows_per_image_scale)), scale_scores.numel())
                idx = torch.topk(scale_scores, k=k, largest=True).indices
                fp_chunks[scale_idx].append(scale_feats[idx].detach().cpu())
                fp_host_chunks[scale_idx].append(scale_scores[idx].detach().cpu())
            good_count += 1

        for item in test_ds:
            if class_name and item["cls_name"] != class_name:
                continue
            if int(item["anomaly"]) == 0:
                continue
            if defect_count >= max_defect:
                break
            model.build_text_feature_gallery(item["cls_name"])
            image = item["img"].unsqueeze(0).to(device)
            mask = item["img_mask"].unsqueeze(0).to(device).float()
            mask_small = F.interpolate(mask, size=model.grid_size, mode="nearest")[0, 0].reshape(-1) > 0.5
            visual_features = model.encode_image(image)
            host_values = textual_window_invnormal_values(model, visual_features)
            selected_any = False
            candidates: dict[int, list[tuple[float, int]]] = {idx: [] for idx in range(len(slices))}
            for window_idx in range(len(visual_features)):
                token_idx = window_mask_indices(model, window_idx, device)
                if token_idx.numel() == 0:
                    continue
                overlap_ratio = float(mask_small[token_idx].float().mean().item())
                if overlap_ratio > 0:
                    candidates[scale_ids[window_idx]].append((overlap_ratio, window_idx))
            for scale_idx, rows in candidates.items():
                if not rows:
                    continue
                clean_rows = [(ratio, win_idx) for ratio, win_idx in rows if ratio >= float(defect_overlap_min)]
                if not clean_rows:
                    # Keep the best positive-overlap windows as a fallback; this avoids empty
                    # banks on tiny defects while still preferring cleaner windows first.
                    clean_rows = sorted(rows, key=lambda x: x[0], reverse=True)[:1]
                clean_rows = sorted(clean_rows, key=lambda x: x[0], reverse=True)[: max(1, int(max_windows_per_image_scale))]
                feat_rows = [visual_features[win_idx].float() for _, win_idx in clean_rows]
                score_rows = [host_values[win_idx].float() for _, win_idx in clean_rows]
                def_chunks[scale_idx].append(torch.cat(feat_rows, dim=0).detach().cpu())
                def_host_chunks[scale_idx].append(torch.cat(score_rows, dim=0).detach().cpu())
                selected_any = True
            if selected_any:
                defect_count += 1

    fp_banks: dict[int, torch.Tensor] = {}
    def_banks: dict[int, torch.Tensor] = {}
    fp_host_banks: dict[int, torch.Tensor] = {}
    def_host_banks: dict[int, torch.Tensor] = {}
    stats: dict[str, dict] = {}
    dim = int(model.text_features.shape[-1])
    for scale_idx in range(len(slices)):
        fp_bank = torch.cat(fp_chunks[scale_idx], dim=0) if fp_chunks[scale_idx] else torch.empty((0, dim))
        def_bank = torch.cat(def_chunks[scale_idx], dim=0) if def_chunks[scale_idx] else torch.empty((0, dim))
        fp_host = torch.cat(fp_host_chunks[scale_idx], dim=0) if fp_host_chunks[scale_idx] else torch.empty((0,))
        def_host = torch.cat(def_host_chunks[scale_idx], dim=0) if def_host_chunks[scale_idx] else torch.empty((0,))
        if fp_bank.shape[0] > max_bank:
            idx = torch.linspace(0, fp_bank.shape[0] - 1, steps=max_bank).round().long()
            fp_bank = fp_bank[idx]
            fp_host = fp_host[idx]
        if def_bank.shape[0] > max_bank:
            idx = torch.linspace(0, def_bank.shape[0] - 1, steps=max_bank).round().long()
            def_bank = def_bank[idx]
            def_host = def_host[idx]
        fp_banks[scale_idx] = F.normalize(fp_bank.float(), dim=-1)
        def_banks[scale_idx] = F.normalize(def_bank.float(), dim=-1)
        fp_host_banks[scale_idx] = fp_host.float()
        def_host_banks[scale_idx] = def_host.float()
        stats[str(scale_idx)] = {
            "num_fp": int(fp_bank.shape[0]),
            "num_defect": int(def_bank.shape[0]),
            "num_fp_host": int(fp_host.shape[0]),
            "num_defect_host": int(def_host.shape[0]),
        }
    stats["images"] = {"good_images": good_count, "defect_images": defect_count}
    stats["bank_mode"] = "scale_wise_overlap_clean_window_banks"
    stats["defect_overlap_min"] = float(defect_overlap_min)
    stats["max_windows_per_image_scale"] = int(max_windows_per_image_scale)
    return fp_banks, def_banks, fp_host_banks, def_host_banks, stats


def evaluate(args: argparse.Namespace) -> tuple[list[dict], dict]:
    device = args.device if torch.cuda.is_available() else "cpu"
    model = WinClipAD(
        out_size_h=args.image_size,
        out_size_w=args.image_size,
        device=device,
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=tuple(args.scales),
        img_resize=args.image_size,
        img_cropsize=args.image_size,
    ).to(device)
    model.eval_mode()
    fp_banks, def_banks, fp_host_banks, def_host_banks, bank_stats = collect_banks(
        model,
        args.source_root,
        args.source_class,
        args.image_size,
        args.max_good,
        args.max_defect,
        args.hard_frac,
        args.max_bank,
        args.defect_overlap_min,
        args.max_windows_per_image_scale,
    )
    fp_banks = {idx: bank.to(device) for idx, bank in fp_banks.items()}
    def_banks = {idx: bank.to(device) for idx, bank in def_banks.items()}
    fp_host_banks = {idx: bank.to(device) for idx, bank in fp_host_banks.items()}
    def_host_banks = {idx: bank.to(device) for idx, bank in def_host_banks.items()}
    scale_ids = window_scale_ids(model)
    mask_transform = build_mask_transform(args.image_size)
    target_ds = GenericMetaDataset(args.target_root, model.transform, mask_transform, "test", class_name=args.target_class)
    loader = torch.utils.data.DataLoader(target_ds, batch_size=1, shuffle=False, num_workers=0)
    results = {
        "baseline_txt": {obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for obj in target_ds.obj_list},
        "ted_trainfree": {obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for obj in target_ds.obj_list},
    }
    if args.enable_calibrated:
        results["ted_calibrated"] = {obj: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []} for obj in target_ds.obj_list}
    calibrator_cache: dict[str, dict | None] = {}
    normal_seen = anomaly_seen = 0
    with torch.no_grad():
        for idx, item in enumerate(loader, start=1):
            if (
                args.max_normal_eval
                and args.max_anomaly_eval
                and normal_seen >= args.max_normal_eval
                and anomaly_seen >= args.max_anomaly_eval
            ):
                break
            anomaly = int(item["anomaly"].item())
            if anomaly == 0 and args.max_normal_eval and normal_seen >= args.max_normal_eval:
                continue
            if anomaly == 1 and args.max_anomaly_eval and anomaly_seen >= args.max_anomaly_eval:
                continue
            normal_seen += int(anomaly == 0)
            anomaly_seen += int(anomaly == 1)
            cls_name = item["cls_name"][0]
            model.build_text_feature_gallery(cls_name)
            image = item["img"].to(device)
            gt_mask = item["img_mask"].clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            visual_features = model.encode_image(image)
            baseline_map = model.calculate_textual_anomaly_score(visual_features)
            baseline_map = F.interpolate(baseline_map, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)[0, 0]
            baseline_arr = smooth_np(baseline_map.detach().float().cpu().numpy(), args.sigma)

            axis = text_axis(model)
            raw_margins = []
            for window_idx, feat in enumerate(visual_features):
                scale_idx = scale_ids[window_idx]
                fp_bank = fp_banks.get(scale_idx, torch.empty((0, feat.shape[-1]), device=device))
                def_bank = def_banks.get(scale_idx, torch.empty((0, feat.shape[-1]), device=device))
                fp_coeff = fp_bank @ axis
                def_coeff = def_bank @ axis
                coeff = F.normalize(feat.float(), dim=-1) @ axis
                q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=args.tau)
                q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=args.tau)
                if args.margin_sign == "def_minus_fp":
                    raw_margins.append(q_def - args.fp_weight * q_fp)
                else:
                    raw_margins.append(q_fp - args.fp_weight * q_def)
            flat_margin = torch.cat(raw_margins, dim=0)
            scale = flat_margin.std(unbiased=False).clamp_min(1e-6)
            flat_margin = torch.sigmoid((flat_margin - flat_margin.mean()) / scale)
            margin_values = []
            offset = 0
            for margin in raw_margins:
                margin_values.append(flat_margin[offset : offset + margin.numel()])
                offset += margin.numel()
            ted_arr = remap_window_values(model, margin_values, args.image_size, args.sigma)

            outputs = [("baseline_txt", baseline_arr), ("ted_trainfree", ted_arr)]
            if args.enable_calibrated:
                calib_residual_values = None
                calib_residual_map = None
                if args.calib_score_source == "axis":
                    calib_residual_values = raw_margins
                    calib_residual_map = ted_arr
                else:
                    if cls_name not in calibrator_cache:
                        calibrator_cache[cls_name] = {}
                    calib_residual_values = []
                    for window_idx, feat in enumerate(visual_features):
                        scale_idx = scale_ids[window_idx]
                        if scale_idx not in calibrator_cache[cls_name]:
                            calibrator_cache[cls_name][scale_idx] = build_rankr_density_calibrator(
                                fp_bank=fp_banks.get(scale_idx, torch.empty((0, feat.shape[-1]), device=device)),
                                def_bank=def_banks.get(scale_idx, torch.empty((0, feat.shape[-1]), device=device)),
                                axis=axis,
                                rank=args.calib_rank,
                                rankr_tau=args.calib_rankr_tau,
                                device=device,
                                fp_host=fp_host_banks.get(scale_idx),
                                def_host=def_host_banks.get(scale_idx),
                                eta_max=args.calib_eta_max,
                            )
                        calibrator = calibrator_cache[cls_name][scale_idx]
                        if calibrator is None:
                            calib_residual_values.append(raw_margins[window_idx])
                        else:
                            calib_residual_values.append(calibrated_density_tokens(F.normalize(feat.float(), dim=-1), calibrator))
                    if calib_residual_values:
                        calib_residual_map = remap_window_values(model, calib_residual_values, args.image_size, args.sigma)
                if args.calib_fusion_level == "window" and calib_residual_values is not None:
                    host_window_values = textual_window_invnormal_values(model, visual_features)
                    if args.calib_scalewise:
                        corrected_window_values = calibrated_window_invnormal_values_scalewise(
                            model=model,
                            host_values=host_window_values,
                            residual_values=calib_residual_values,
                            lam=args.calib_lambda,
                            gate_quantile=args.calib_gate_quantile,
                            gate_temp=args.calib_gate_temp,
                        )
                    else:
                        corrected_window_values = calibrated_window_invnormal_values(
                            host_values=host_window_values,
                            residual_values=calib_residual_values,
                            lam=args.calib_lambda,
                            gate_quantile=args.calib_gate_quantile,
                            gate_temp=args.calib_gate_temp,
                        )
                    calib_arr = remap_winclip_invnormal_values(model, corrected_window_values, args.image_size, args.sigma)
                    outputs.append(("ted_calibrated", calib_arr))
                elif calib_residual_map is not None:
                    calib_arr = host_residual_map(
                        baseline_arr=baseline_arr,
                        residual_arr=calib_residual_map,
                        lam=args.calib_lambda,
                        gate_quantile=args.calib_gate_quantile,
                        gate_temp=args.calib_gate_temp,
                    )
                    outputs.append(("ted_calibrated", calib_arr))

            for mode, arr in outputs:
                results[mode][cls_name]["gt_sp"].append(anomaly)
                if mode == "ted_calibrated" and args.calib_image_score_mode == "baseline":
                    image_score = topk_mean(baseline_arr, args.image_topk)
                else:
                    image_score = topk_mean(arr, args.image_topk)
                results[mode][cls_name]["pr_sp"].append(image_score)
                results[mode][cls_name]["imgs_masks"].append(gt_mask)
                results[mode][cls_name]["anomaly_maps"].append(torch.from_numpy(arr).unsqueeze(0))
            if idx % 8 == 0:
                print(json.dumps({"stage": "winclip_ted_progress", "images_done": idx, "class": cls_name}), flush=True)

    rows = []
    mode_order = ["baseline_txt", "ted_trainfree"] + (["ted_calibrated"] if args.enable_calibrated else [])
    for mode in mode_order:
        vals = {"image_auroc": [], "pixel_auroc": [], "pixel_aupro": [], "pixel_ap": []}
        for obj in target_ds.obj_list:
            if not results[mode][obj]["gt_sp"]:
                continue
            results[mode][obj]["imgs_masks"] = torch.cat(results[mode][obj]["imgs_masks"])
            results[mode][obj]["anomaly_maps"] = torch.cat(results[mode][obj]["anomaly_maps"]).numpy()
            row = {
                "mode": mode,
                "target_label": obj,
                "image_auroc": float(image_level_metrics(results[mode], obj, "image-auroc")),
                "pixel_auroc": safe_pixel_metric(results[mode], obj, "pixel-auroc"),
                "pixel_aupro": safe_pixel_metric(results[mode], obj, "pixel-aupro"),
                "pixel_ap": float(average_precision_score(np.asarray(results[mode][obj]["imgs_masks"]).ravel(), np.asarray(results[mode][obj]["anomaly_maps"]).ravel())),
            }
            rows.append(row)
            for key in vals:
                vals[key].append(row[key])
        rows.append({"mode": mode, "target_label": "mean", **{k: float(np.mean(v)) for k, v in vals.items() if v}})
    summary = vars(args) | {
        "bank_stats": bank_stats,
        "calibrator_summary": {
            cls_name: {
                str(scale_idx): None
                if value is None
                else {
                    k: v
                    for k, v in value.items()
                    if k not in {"basis", "coord_mean", "coord_std", "fp_coords", "def_coords"}
                }
                for scale_idx, value in per_scale.items()
            }
            for cls_name, per_scale in calibrator_cache.items()
        },
    }
    return rows, summary


def main() -> None:
    parser = argparse.ArgumentParser("WinCLIP train-free TED smoke.")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default=str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"))
    parser.add_argument("--source_class", type=str, default="")
    parser.add_argument("--target_class", type=str, default="capsules")
    parser.add_argument("--save_dir", type=str, default=str(ROOT / "neurips2026" / "results" / "winclip_ted_smoke_mvtec2visa_capsules_20260429"))
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--image_size", type=int, default=240)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good", type=int, default=8)
    parser.add_argument("--max_defect", type=int, default=8)
    parser.add_argument("--max_bank", type=int, default=512)
    parser.add_argument("--defect_overlap_min", type=float, default=0.25)
    parser.add_argument("--max_windows_per_image_scale", type=int, default=64)
    parser.add_argument("--max_normal_eval", type=int, default=16)
    parser.add_argument("--max_anomaly_eval", type=int, default=16)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--fp_weight", type=float, default=1.0)
    parser.add_argument("--margin_sign", type=str, choices=["def_minus_fp", "fp_minus_def"], default="def_minus_fp")
    parser.add_argument("--enable_calibrated", action="store_true")
    parser.add_argument("--calib_fusion_level", type=str, choices=["map", "window"], default="map")
    parser.add_argument("--calib_score_source", type=str, choices=["axis", "rankr_density"], default="rankr_density")
    parser.add_argument("--calib_rank", type=int, default=8)
    parser.add_argument("--calib_rankr_tau", type=float, default=0.1)
    parser.add_argument("--calib_lambda", type=float, default=0.5)
    parser.add_argument("--calib_eta_max", type=float, default=1.0)
    parser.add_argument("--calib_scalewise", action="store_true")
    parser.add_argument("--calib_gate_quantile", type=float, default=0.75)
    parser.add_argument("--calib_gate_temp", type=float, default=0.5)
    parser.add_argument("--calib_image_score_mode", type=str, choices=["map_topk", "baseline"], default="map_topk")
    parser.add_argument("--image_topk", type=float, default=0.01)
    parser.add_argument("--device", type=str, default="cuda:0")
    args = parser.parse_args()
    for attr in ("source_class", "target_class"):
        value = getattr(args, attr)
        if value is not None and value.lower() in {"", "none", "null", "all"}:
            setattr(args, attr, None)
    rows, summary = evaluate(args)
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
