from __future__ import annotations

import argparse
import gc
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from common_failure_metrics import (  # noqa: E402
    BTAD_ROOT,
    MPDD_ROOT,
    MVTEC_ROOT,
    OFFICIAL_VISA_ROOT,
    build_rows_and_summary,
    current_rss_mb,
    init_per_class,
    reached_cap,
    save_outputs,
    update_per_class,
    validate_visa_root,
    write_progress,
)
from probe_anomalyclip_fp_text_decomposition import get_learned_text_pair, load_prompt_learner  # noqa: E402
from probe_anomalyclip_wrongclass_semantic_collapse import (  # noqa: E402
    MVTED_CKPT,
    VISA_CKPT,
    aggregate_map_from_patch_features,
    build_eval_dataset,
    build_model,
)


def resolve_preset(args) -> None:
    if args.preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtec"
    elif args.preset == "mvtec2visa":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif args.preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif args.preset == "mvtec2btad":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {args.preset}")


def cleanup(device: str) -> None:
    gc.collect()
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()


def main() -> None:
    parser = argparse.ArgumentParser("Collect common dense-failure metrics for AnomalyCLIP")
    parser.add_argument("--preset", required=True, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=-1)
    parser.add_argument("--max_normal_images_per_class", type=int, default=-1)
    parser.add_argument("--progress_every", type=int, default=50)
    parser.add_argument("--cpu_threads", type=int, default=1)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "common_failure_anomalyclip"),
    )
    args = parser.parse_args()

    resolve_preset(args)
    torch.set_num_threads(max(1, int(args.cpu_threads)))
    try:
        torch.set_num_interop_threads(max(1, int(args.cpu_threads)))
    except RuntimeError:
        pass

    validate_visa_root(args.target_root, args.target_dataset)
    save_dir = Path(args.save_dir)
    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    dataset = build_eval_dataset(args.target_root, args.target_dataset, args.image_size, mode="test")
    per_class = init_per_class(list(dataset.obj_list))

    write_progress(
        save_dir,
        {
            "event": "start",
            "pid": os.getpid(),
            "preset": args.preset,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "rss_mb": round(current_rss_mb(), 2),
        },
    )

    with torch.inference_mode():
        for idx in range(len(dataset)):
            item = dataset[idx]
            cls_name = item["cls_name"]
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            is_anomaly = int(anomaly_flag) == 1
            stats = per_class[cls_name]
            if is_anomaly and reached_cap(int(stats["num_anomaly"]), args.max_anomaly_images_per_class):
                continue
            if (not is_anomaly) and reached_cap(int(stats["num_normal"]), args.max_normal_images_per_class):
                continue

            image = item["img"].unsqueeze(0).to(args.device)
            mask_tensor = item["img_mask"]
            gt_mask = (mask_tensor.squeeze().detach().cpu().numpy() > 0.5) if torch.is_tensor(mask_tensor) else (np.asarray(mask_tensor).squeeze() > 0.5)

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            anomaly_map = aggregate_map_from_patch_features(patch_features, learned_pair, args.image_size, args.sigma)
            update_per_class(stats, anomaly_map, gt_mask, is_anomaly, args.topk_frac)

            if args.progress_every > 0 and (idx + 1) % args.progress_every == 0:
                print(
                    json.dumps(
                        {
                            "event": "progress",
                            "preset": args.preset,
                            "dataset_index": idx,
                            "rss_mb": round(current_rss_mb(), 2),
                        }
                    ),
                    flush=True,
                )
                write_progress(
                    save_dir,
                    {
                        "event": "progress",
                        "pid": os.getpid(),
                        "preset": args.preset,
                        "dataset_index": idx,
                        "rss_mb": round(current_rss_mb(), 2),
                    },
                )
            cleanup(args.device)

    rows, summary = build_rows_and_summary(per_class)
    settings = {
        "host": "AnomalyCLIP",
        "preset": args.preset,
        "checkpoint_path": args.checkpoint_path,
        "target_root": args.target_root,
        "target_dataset": args.target_dataset,
        "image_size": args.image_size,
        "sigma": args.sigma,
        "features_list": args.features_list,
        "topk_frac": args.topk_frac,
        "max_anomaly_images_per_class": args.max_anomaly_images_per_class,
        "max_normal_images_per_class": args.max_normal_images_per_class,
    }
    save_outputs(save_dir, settings, summary, rows)
    print(json.dumps({"settings": settings, "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
