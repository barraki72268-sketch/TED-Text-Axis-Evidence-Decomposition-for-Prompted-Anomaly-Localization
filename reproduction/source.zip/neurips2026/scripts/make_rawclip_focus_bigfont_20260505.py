#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch
from matplotlib.ticker import FuncFormatter, MaxNLocator


ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "neurips2026" / "results" / "rawclip_aggregated_distribution_vitl_visa2mvtec"
ARRAYS = SRC / "rawclip_aggregated_distribution_arrays.npz"
FIG = ROOT / "figure"

PANEL_FIGSIZE = (7.8, 3.05)


def auc_from_scores(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    scores = np.concatenate([pos, neg], axis=0)
    labels = np.concatenate(
        [np.ones(pos.shape[0], dtype=np.int64), np.zeros(neg.shape[0], dtype=np.int64)],
        axis=0,
    )
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(scores) + 1, dtype=np.float64)
    pos_ranks = ranks[labels == 1]
    n_pos = pos.shape[0]
    n_neg = neg.shape[0]
    return float((pos_ranks.sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def subsample(vals: np.ndarray, rng: np.random.Generator, max_plot: int = 50000) -> np.ndarray:
    vals = vals.reshape(-1)
    if vals.size <= max_plot:
        return vals
    return vals[rng.choice(vals.size, size=max_plot, replace=False)]


def draw_panel(
    ax: plt.Axes,
    abnormal: np.ndarray,
    hardfp: np.ndarray,
    title: str,
    rng: np.random.Generator,
    *,
    show_title: bool = False,
    show_ylabels: bool = True,
    compact_ylabels: bool = False,
    xlabel: str | None = None,
    show_xlabel: bool = True,
) -> None:
    abnormal = subsample(abnormal, rng)
    hardfp = subsample(hardfp, rng)
    groups = [abnormal, hardfp]
    positions = [2, 1]
    colors = ["#c43c39", "#3568b8"]

    vp = ax.violinplot(
        groups,
        positions=positions,
        vert=False,
        widths=0.72,
        showmeans=False,
        showmedians=True,
        showextrema=False,
    )
    for body, color in zip(vp["bodies"], colors):
        body.set_facecolor(color)
        body.set_edgecolor(color)
        body.set_alpha(0.26)
        body.set_linewidth(1.8)
    vp["cmedians"].set_color("#111111")
    vp["cmedians"].set_linewidth(3.0)

    bp = ax.boxplot(
        groups,
        positions=positions,
        vert=False,
        widths=0.26,
        patch_artist=True,
        showfliers=False,
        medianprops={"color": "#111111", "linewidth": 2.8},
        boxprops={"linewidth": 2.2},
        whiskerprops={"linewidth": 2.0},
        capprops={"linewidth": 2.0},
    )
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.65)
        patch.set_edgecolor(color)

    auc = auc_from_scores(abnormal, hardfp)
    med_gap = float(np.median(abnormal) - np.median(hardfp))
    if show_title:
        ax.set_title(f"{title}: AUC={auc:.3f}, median gap={med_gap:.4f}", fontsize=22, fontweight="bold", pad=12)
    if show_ylabels:
        ylabels = ["Defect", "H-FP"] if compact_ylabels else ["GT abnormal", "hard-FP normal"]
    else:
        ylabels = ["", ""]
    ax.set_yticks(positions, ylabels)
    all_vals = np.concatenate(groups)
    if float(np.nanmax(np.abs(all_vals))) < 0.01:
        ax.xaxis.set_major_locator(MaxNLocator(nbins=5))
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x * 1e3:.1f}"))
        default_xlabel = r"Patch score ($\times10^{-3}$)"
    else:
        ax.xaxis.set_major_locator(MaxNLocator(nbins=5))
        default_xlabel = "Patch score"
    xlabel = default_xlabel if xlabel is None else xlabel
    if show_xlabel:
        ax.set_xlabel(xlabel, fontsize=21, fontweight="bold", labelpad=8)
    else:
        ax.set_xlabel("")
    ax.grid(axis="x", linestyle="--", linewidth=1.1, alpha=0.23)
    ax.tick_params(axis="both", labelsize=18, width=1.8, length=6)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    for spine in ["left", "bottom"]:
        ax.spines[spine].set_linewidth(1.8)


def save_panel(
    name: str,
    abnormal: np.ndarray,
    hardfp: np.ndarray,
    rng: np.random.Generator,
    handles: list[Patch],
    *,
    show_ylabels: bool,
    add_legend: bool,
) -> None:
    fig = plt.figure(figsize=PANEL_FIGSIZE, constrained_layout=False)
    # Draw directly on a fixed canvas. These margins are deliberately generous,
    # so the exported files do not rely on bbox cropping.
    ax = fig.add_axes([0.34, 0.305, 0.62, 0.61])
    draw_panel(ax, abnormal, hardfp, name, rng, show_title=False, show_ylabels=show_ylabels)
    if add_legend:
        ax.legend(
            handles=handles,
            loc="lower right",
            bbox_to_anchor=(1.055, 0.04),
            frameon=False,
            fontsize=19,
            handlelength=1.7,
            borderaxespad=0.0,
        )
    for target in (FIG, SRC):
        fig.savefig(target / f"{name}.pdf", pad_inches=0.0)
        fig.savefig(target / f"{name}.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def save_compact_twopanel(data: np.lib.npyio.NpzFile, rng: np.random.Generator) -> None:
    fig = plt.figure(figsize=(12.2, 2.05), constrained_layout=False)
    ax0 = fig.add_axes([0.115, 0.28, 0.390, 0.62])
    ax1 = fig.add_axes([0.585, 0.28, 0.385, 0.62])

    draw_panel(
        ax0,
        data["baseline_abnormal"],
        data["baseline_hard_fp"],
        "",
        rng,
        show_title=False,
        show_ylabels=True,
        compact_ylabels=True,
        show_xlabel=False,
    )
    draw_panel(
        ax1,
        data["ours_abnormal"],
        data["ours_hard_fp"],
        "",
        rng,
        show_title=False,
        show_ylabels=False,
        compact_ylabels=True,
        show_xlabel=False,
    )

    for target in (FIG, SRC):
        fig.savefig(target / "rawclip_abnormal_hardfp_focus_twopanel_compact.pdf", pad_inches=0.0)
        fig.savefig(target / "rawclip_abnormal_hardfp_focus_twopanel_compact.png", dpi=260, pad_inches=0.0)
    plt.close(fig)


def main() -> int:
    data = np.load(ARRAYS)
    rng = np.random.default_rng(0)
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.weight": "bold",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig = plt.figure(figsize=(16.6, 3.15), constrained_layout=False)
    axes = [
        fig.add_axes([0.085, 0.29, 0.395, 0.61]),
        fig.add_axes([0.545, 0.29, 0.425, 0.61]),
    ]
    draw_panel(axes[0], data["baseline_abnormal"], data["baseline_hard_fp"], "(a) Baseline", rng, show_title=False)
    draw_panel(
        axes[1],
        data["ours_abnormal"],
        data["ours_hard_fp"],
        "(b) Ours",
        rng,
        show_title=False,
        show_ylabels=True,
    )

    handles = [
        Patch(facecolor="#c43c39", edgecolor="#c43c39", alpha=0.65, label="GT abnormal"),
        Patch(facecolor="#3568b8", edgecolor="#3568b8", alpha=0.65, label="hard-FP normal"),
    ]
    axes[1].legend(
        handles=handles,
        loc="lower right",
        bbox_to_anchor=(1.055, 0.04),
        frameon=False,
        fontsize=19,
        handlelength=1.7,
        borderaxespad=0.0,
    )

    FIG.mkdir(parents=True, exist_ok=True)
    out_pdf = FIG / "rawclip_abnormal_hardfp_focus_horizontal_clean.pdf"
    out_png = FIG / "rawclip_abnormal_hardfp_focus_horizontal_clean.png"
    fig.savefig(out_pdf, pad_inches=0.0)
    fig.savefig(out_png, dpi=260, pad_inches=0.0)
    fig.savefig(SRC / "rawclip_abnormal_hardfp_focus_horizontal_clean_bigfont.pdf", pad_inches=0.0)
    fig.savefig(SRC / "rawclip_abnormal_hardfp_focus_horizontal_clean_bigfont.png", dpi=260, pad_inches=0.0)
    plt.close(fig)

    save_compact_twopanel(data, rng)

    save_panel(
        "rawclip_abnormal_hardfp_focus_baseline_bigfont",
        data["baseline_abnormal"],
        data["baseline_hard_fp"],
        rng,
        handles,
        show_ylabels=True,
        add_legend=False,
    )
    save_panel(
        "rawclip_abnormal_hardfp_focus_ours_bigfont",
        data["ours_abnormal"],
        data["ours_hard_fp"],
        rng,
        handles,
        show_ylabels=True,
        add_legend=True,
    )
    print(out_pdf)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
