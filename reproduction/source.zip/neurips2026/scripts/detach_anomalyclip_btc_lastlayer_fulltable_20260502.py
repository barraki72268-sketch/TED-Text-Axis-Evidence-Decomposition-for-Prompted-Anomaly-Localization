#!/usr/bin/env python3
"""Detach AnomalyCLIP B/T/C full-table queue from the Codex session."""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
QUEUE = ROOT / "neurips2026/scripts/queue_anomalyclip_btc_lastlayer_fulltable_20260502.py"
OUT = ROOT / "neurips2026/results/anomalyclip_btc_lastlayer_autosign_fulltable_20260502"
LOG = OUT / "queue.detached.log"
PID = OUT / "queue.pid"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--transfers", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--force_bank", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(QUEUE),
        "--device_id",
        str(args.device_id),
        "--wait_pid",
        str(args.wait_pid),
        "--transfers",
        args.transfers,
        "--seeds",
        args.seeds,
    ]
    if args.force:
        cmd.append("--force")
    if args.force_bank:
        cmd.append("--force_bank")
    with LOG.open("ab") as log:
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    PID.write_text(str(proc.pid) + "\n", encoding="utf-8")
    print({"stage": "detached", "pid": proc.pid, "log": str(LOG), "root": str(OUT), "cmd": " ".join(cmd)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
