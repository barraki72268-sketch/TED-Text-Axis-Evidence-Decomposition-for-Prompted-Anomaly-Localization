from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_bayespfl_ted_smoke.py"
OUT = ROOT / "neurips2026/results/bayespfl_pre_softmax_smoke_20260502"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")
CKPT = str(ROOT / "neurips2026/results/bayespfl_strict_mvtec/epoch_post_15_1.pth")
CONFIG = str(ROOT / "neurips2026/Bayes-PFL/open_clip_local/model_configs/ViT-L-14-336.json")
PRETRAINED = "/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt"
BANK_CACHE = str(OUT / "mvtec_fullsource_bank.pt")


VARIANTS = [
    {
        "name": "post_map_current",
        "ted_insertion": "post_map",
        "margin_sign": "def_minus_fp",
        "map_activation": "sigmoid",
        "ted_alpha": "0.05",
        "eta_max": "0.05",
        "eta_init": "0.01",
    },
    {
        "name": "pre_softmax_alpha02",
        "ted_insertion": "pre_softmax",
        "margin_sign": "def_minus_fp",
        "map_activation": "sigmoid",
        "ted_alpha": "0.2",
        "eta_max": "0.2",
        "eta_init": "0.05",
    },
    {
        "name": "pre_softmax_alpha05",
        "ted_insertion": "pre_softmax",
        "margin_sign": "def_minus_fp",
        "map_activation": "sigmoid",
        "ted_alpha": "0.5",
        "eta_max": "0.5",
        "eta_init": "0.10",
    },
    {
        "name": "pre_softmax_alpha05_identity",
        "ted_insertion": "pre_softmax",
        "margin_sign": "def_minus_fp",
        "map_activation": "identity",
        "ted_alpha": "0.5",
        "eta_max": "0.5",
        "eta_init": "0.10",
    },
    {
        "name": "pre_softmax_fpminus_alpha05",
        "ted_insertion": "pre_softmax",
        "margin_sign": "fp_minus_def",
        "map_activation": "sigmoid",
        "ted_alpha": "0.5",
        "eta_max": "0.5",
        "eta_init": "0.10",
    },
]


def wait_pid(pid: int | None) -> None:
    if not pid:
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while Path(f"/proc/{pid}").exists():
        time.sleep(30)
    print({"stage": "wait_pid_done", "pid": pid}, flush=True)


def build_cmd(variant: dict[str, str]) -> list[str]:
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--dataset",
        "mvtec",
        "--data_path",
        MVTEC_ROOT,
        "--target_dataset",
        "btad",
        "--target_data_path",
        BTAD_ROOT,
        "--target_class",
        "01",
        "--checkpoint_path",
        CKPT,
        "--config_path",
        CONFIG,
        "--pretrained_path",
        PRETRAINED,
        "--image_size",
        "518",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--device_id",
        "0",
        "--seed",
        "0",
        "--sample_num",
        "10",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--bank_cache_path",
        BANK_CACHE,
        "--hard_frac",
        "0.01",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--margin_sign",
        variant["margin_sign"],
        "--map_activation",
        variant["map_activation"],
        "--ted_combine",
        "residual",
        "--ted_insertion",
        variant["ted_insertion"],
        "--ted_alpha",
        variant["ted_alpha"],
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_eta_init",
        variant["eta_init"],
        "--calib_eta_max",
        variant["eta_max"],
        "--calib_eta_reg",
        "1e-3",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_hard_frac",
        "0.01",
        "--calib_max_good_per_class",
        "4",
        "--calib_max_defect_per_class",
        "4",
        "--calib_max_fp_per_image",
        "64",
        "--calib_max_defect_per_image",
        "128",
        "--calib_max_train_points",
        "8192",
        "--image_topk",
        "0.01",
        "--metric_sigma",
        "8",
        "--image_score_mode",
        "official_fused",
        "--image_fusion_alpha",
        "0.5",
        "--aupro_max_step",
        "80",
        "--max_normal_eval",
        "0",
        "--max_anomaly_eval",
        "0",
        "--save_dir",
        str(OUT / variant["name"]),
    ]


def main() -> None:
    parser = argparse.ArgumentParser("Queue BayesPFL pre-softmax TED smoke.")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--gpu", type=str, default="0")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    wait_pid(args.wait_pid)
    OUT.mkdir(parents=True, exist_ok=True)
    log_root = OUT / "_logs"
    log_root.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = args.gpu
    for variant in VARIANTS:
        save_dir = OUT / variant["name"]
        if (save_dir / "summary.json").exists() and not args.force:
            print({"stage": "skip_existing", "variant": variant["name"]}, flush=True)
            continue
        log_path = log_root / f"{variant['name']}.log"
        print({"stage": "start", "variant": variant["name"], "log": str(log_path)}, flush=True)
        with log_path.open("w") as log:
            proc = subprocess.run(
                build_cmd(variant),
                cwd=str(ROOT),
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
            )
        print({"stage": "done", "variant": variant["name"], "returncode": proc.returncode, "log": str(log_path)}, flush=True)
        if proc.returncode != 0:
            raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
