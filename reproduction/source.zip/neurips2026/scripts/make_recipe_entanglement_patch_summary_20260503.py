from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)

CASE_DIR = ROOT / "neurips2026/results/faprompt_ted_story_vitl336_visa2mvtec_capsule_alpha15"
DEFECT = CASE_DIR / "defect_crop.png"
HARD_FP = CASE_DIR / "hard_normal_crop.png"

BASE = np.array([58.12, 60.18, 57.51, 57.92])
CTED = np.array([60.59, 61.96, 59.66, 60.12])

RED = "#D84A32"
BLUE = "#1B5E8A"
GRAY = "#8C939B"
GRID = "#D8D8D8"


def load_image(path: Path) -> Image.Image:
    return Image.open(path).convert("RGB")


def minmax_err(values: np.ndarray):
    mean = values.mean()
    return np.array([[mean - values.min()], [values.max() - mean]])


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9.5,
            "axes.titlesize": 10.5,
            "axes.labelsize": 9.5,
            "xtick.labelsize": 9.5,
            "ytick.labelsize": 8.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig = plt.figure(figsize=(6.45, 2.25))
    gs = fig.add_gridspec(1, 3, width_ratios=[0.98, 0.98, 1.12], wspace=0.42)

    ax_def = fig.add_subplot(gs[0, 0])
    ax_fp = fig.add_subplot(gs[0, 1])
    ax_bar = fig.add_subplot(gs[0, 2])

    for ax, img_path, title, color in [
        (ax_def, DEFECT, "defect", RED),
        (ax_fp, HARD_FP, "hard-FP", BLUE),
    ]:
        ax.imshow(load_image(img_path))
        ax.set_title(title, color=color, fontweight="bold", pad=4)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.add_patch(
            Rectangle(
                (0, 0),
                1,
                1,
                transform=ax.transAxes,
                fill=False,
                edgecolor=color,
                linewidth=3.0,
            )
        )

    means = np.array([BASE.mean(), CTED.mean()])
    yerr = np.concatenate([minmax_err(BASE), minmax_err(CTED)], axis=1)
    x = np.arange(2)
    bars = ax_bar.bar(x, means, color=[GRAY, BLUE], width=0.58, alpha=0.94, zorder=3)
    ax_bar.errorbar(
        x,
        means,
        yerr=yerr,
        fmt="none",
        ecolor="#2F3337",
        elinewidth=1.35,
        capsize=4,
        capthick=1.35,
        zorder=4,
    )

    for bar, value in zip(bars, means):
        ax_bar.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.35,
            f"{value:.1f}",
            ha="center",
            va="bottom",
            fontsize=9.5,
            fontweight="bold",
        )

    delta = means[1] - means[0]
    ax_bar.text(
        0.5,
        63.05,
        f"+{delta:.1f} avg.",
        ha="center",
        va="top",
        fontsize=9.8,
        fontweight="bold",
        color=BLUE,
    )
    ax_bar.set_title("aggregate separation", fontweight="bold", pad=4)
    ax_bar.set_ylabel("AUC")
    ax_bar.set_xticks(x)
    ax_bar.set_xticklabels(["B", "C-TED"], fontweight="bold")
    ax_bar.set_ylim(55.5, 64.0)
    ax_bar.grid(axis="y", color=GRID, linewidth=0.72, zorder=0)
    ax_bar.spines["top"].set_visible(False)
    ax_bar.spines["right"].set_visible(False)

    fig.text(
        0.31,
        0.02,
        "top-scoring patch pair under the retrained host",
        ha="center",
        va="bottom",
        fontsize=9.0,
        color="#333333",
    )
    fig.tight_layout(pad=0.22, rect=(0.0, 0.05, 1.0, 1.0))

    pdf = FIG_DIR / "recipe_entanglement_patch_summary_20260503.pdf"
    png = FIG_DIR / "recipe_entanglement_patch_summary_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")

    tex = OUT_DIR / "recipe_entanglement_patch_summary_20260503.tex"
    tex.write_text(
        r"""\begin{figure}[t]
\centering
\includegraphics[width=0.96\linewidth]{figure/recipe_entanglement_patch_summary_20260503.pdf}
\caption{
Recipe-consistent retraining does not remove the hard-FP competition.
Left: a true defect patch and a hard normal patch that are both favored by the host score.
Right: across four retrained layer recipes, C-TED improves defect-versus-hard-FP separation without changing the retrained host.
}
\label{fig:recipe_entanglement_patch_summary}
\end{figure}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)


if __name__ == "__main__":
    main()
