#!/usr/bin/env python3
"""Detached corrected all-class AnomalyCLIP ViT-B backbone-retrain eval.

The previous backbone-retrained AnomalyCLIP ViT-B summary used the evaluator
default heldout_class=bottle, so its "mean" row was a single-class result.
This launcher reruns evaluation with heldout_class disabled and a fresh bank
cache so all MVTec classes are included.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
OUT = ROOT / "neurips2026/results/anomalyclip_backbone_retrained_vitb_allclass_20260503"
LOG = OUT / "logs"


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def wait_pids(pids: list[int], log) -> None:
    remaining = [pid for pid in pids if pid > 0]
    while remaining:
        alive = [pid for pid in remaining if pid_alive(pid)]
        done = sorted(set(remaining) - set(alive))
        for pid in done:
            print(json.dumps({"stage": "wait_pid_done", "pid": pid}), file=log, flush=True)
        remaining = alive
        if remaining:
            print(json.dumps({"stage": "wait_pid", "pids": remaining}), file=log, flush=True)
            time.sleep(60)


def eval_cmd(gpu: str) -> list[str]:
    return [
        str(PY),
        "-u",
        str(ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"),
        "--device",
        "cuda:0",
        "--checkpoint_path",
        str(ROOT / "neurips2026/results/backbone_retrained_stress_20260501/anomalyclip_vitb16_ckpt/epoch_15.pth"),
        "--source_root",
        str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls"),
        "--source_dataset",
        "visa",
        "--target_root",
        "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "--target_dataset",
        "mvtec",
        "--target_mode",
        "test",
        "--heldout_class",
        "none",
        "--source_exclude_class",
        "none",
        "--model_name_or_path",
        "/home/jinyoung/.cache/clip/ViT-B-16.pt",
        "--image_size",
        "224",
        "--dpam_layer",
        "12",
        "--features_list",
        "3",
        "6",
        "9",
        "12",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--bank_cache_path",
        str(OUT / "bank_cache/anomalyclip_vitb16_visa_allclass_withscores.pt"),
        "--refresh_bank_cache",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--skip_separability_metrics",
        "--enable_calibrator",
        "--calib_seed",
        "0",
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "1.0",
        "--calibrated_image_fusion_weight",
        "-0.05",
        "--save_dir",
        str(OUT / "eval"),
    ]


def run(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    (OUT / "bank_cache").mkdir(parents=True, exist_ok=True)
    log_path = LOG / "eval.log"
    with log_path.open("a", encoding="utf-8") as log:
        print(json.dumps({"stage": "start", "gpu": args.gpu, "wait_pids": args.wait_pids}), file=log, flush=True)
        wait_pids(args.wait_pids, log)
        summary = OUT / "eval/summary.json"
        if summary.exists() and not args.force:
            print(json.dumps({"stage": "skip_existing", "summary": str(summary)}), file=log, flush=True)
            return 0
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
        env["PYTHONUNBUFFERED"] = "1"
        env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-anomalyclip-vitb-allclass-20260503")
        cmd = eval_cmd(str(args.gpu))
        print(json.dumps({"stage": "run", "cmd": cmd}), file=log, flush=True)
        proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log, stderr=subprocess.STDOUT, text=True)
        print(json.dumps({"stage": "done", "returncode": proc.returncode}), file=log, flush=True)
        return proc.returncode


def detach(args: argparse.Namespace) -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(Path(__file__).resolve()),
        "--gpu",
        str(args.gpu),
    ]
    for pid in args.wait_pids:
        cmd.extend(["--wait-pid", str(pid)])
    if args.force:
        cmd.append("--force")
    log_path = OUT / "detached.log"
    pid_path = OUT / "detached.pid"
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    log = log_path.open("a", encoding="utf-8")
    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        close_fds=True,
    )
    pid_path.write_text(str(proc.pid), encoding="utf-8")
    print(json.dumps({"stage": "detached_started", "pid": proc.pid, "log": str(log_path), "pid_file": str(pid_path)}), flush=True)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", default="1")
    parser.add_argument("--wait-pid", dest="wait_pids", type=int, action="append", default=[])
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--detach", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.detach:
        return detach(args)
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
