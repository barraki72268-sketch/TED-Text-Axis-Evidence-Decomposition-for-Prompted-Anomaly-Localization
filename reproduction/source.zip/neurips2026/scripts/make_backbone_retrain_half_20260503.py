from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
FIG_DIR.mkdir(parents=True, exist_ok=True)


# Confirmed backbone-retrained values. Each tuple is:
# host, B PRO, C PRO, B AP, C AP.
VALUES = [
    ("AdaCLIP", 19.74, 21.43, 4.27, 4.46),
    ("AdaptCLIP", 43.40, 44.17, 15.22, 15.92),
    ("AnomalyCLIP", 27.83, 38.10, 5.06, 5.23),
    ("FAPrompt", 35.51, 37.96, 8.78, 17.22),
]


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.titlesize": 15,
            "axes.labelsize": 12,
            "xtick.labelsize": 10,
            "ytick.labelsize": 10,
            "legend.fontsize": 9.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    labels = [v[0] for v in VALUES]
    base_pro = np.asarray([v[1] for v in VALUES])
    cted_pro = np.asarray([v[2] for v in VALUES])
    base_ap = np.asarray([v[3] for v in VALUES])
    cted_ap = np.asarray([v[4] for v in VALUES])
    x = np.arange(len(labels))

    fig, ax = plt.subplots(figsize=(5.8, 3.55))
    ax.plot(x, base_pro, marker="o", markersize=6.3, linewidth=2.2, color="#9AA3AD", label="B PRO")
    ax.plot(x, cted_pro, marker="o", markersize=6.3, linewidth=2.5, color="#1B5E8A", label="C PRO")
    ax.plot(x, base_ap, marker="s", markersize=5.8, linewidth=2.0, color="#D2A16F", linestyle="--", label="B AP")
    ax.plot(x, cted_ap, marker="s", markersize=5.8, linewidth=2.3, color="#B45F06", linestyle="--", label="C AP")

    for i, (bp, cp, ba, ca) in enumerate(zip(base_pro, cted_pro, base_ap, cted_ap)):
        ax.text(i, cp + 1.0, f"+{cp - bp:.1f}", ha="center", va="bottom", fontsize=8.8, fontweight="bold", color="#123B4F")
        ax.text(i, ca - 1.0, f"+{ca - ba:.1f}", ha="center", va="top", fontsize=8.4, fontweight="bold", color="#7A3E06")

    ax.set_title("(b) Backbone-wise retraining", fontweight="bold", pad=8)
    ax.set_ylabel("Score")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=28, ha="right")
    ax.set_ylim(0, max(cted_pro.max(), base_pro.max()) + 8)
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.02), frameon=False, ncol=4, handlelength=1.6, columnspacing=1.0)

    fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.98))
    pdf = FIG_DIR / "backbone_retrain_recovery_half_20260503.pdf"
    png = FIG_DIR / "backbone_retrain_recovery_half_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    print(pdf)
    print(png)


if __name__ == "__main__":
    main()
