from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["fryum", "pcb1", "capsules", "candle"])
    parser.add_argument("--target_layer", type=int, default=12)
    parser.add_argument("--temperatures", nargs="+", type=float, default=[0.1, 1.0, 5.0])
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_dynamic_routing")
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def build_recent_general_prompt_bank(class_name: str) -> tuple[str, list[str]]:
    cls = class_name.replace("_", " ")
    normal_prompt = (
        f"a close-up inspection photo of a {cls} that is intact, complete, clean, "
        f"and free of visible damage, defects, cracks, missing parts, contamination, "
        f"deformation, discoloration, or abnormal surface patterns."
    )
    abnormal_prompts = [
        (
            f"a close-up inspection photo of a {cls} showing visible damage, cracks, holes, "
            f"broken regions, missing material, or structural defects."
        ),
        (
            f"a close-up inspection photo of a {cls} with scratches, dents, tears, surface flaws, "
            f"contamination, stains, discoloration, or abnormal marks."
        ),
        (
            f"a close-up inspection photo of a {cls} whose shape, texture, edge, or surface pattern "
            f"looks irregular, deformed, incomplete, or visibly defective."
        ),
        (
            f"a detailed inspection photo of a {cls} with missing parts, broken edges, foreign material, "
            f"local damage, or manufacturing defects."
        ),
        (
            f"a detailed inspection photo of a {cls} that appears damaged, defective, incomplete, "
            f"deformed, contaminated, or inconsistent with a normal intact item."
        ),
        (
            f"a close-up inspection photo of a {cls} with visible surface damage, structural breakage, "
            f"missing components, contamination, or abnormal appearance."
        ),
    ]
    return normal_prompt, abnormal_prompts


def encode_text_features(backbone, prompts: list[str]) -> torch.Tensor:
    device = backbone.device
    text = backbone.tokenizer(prompts).to(device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = l2_normalize(text_features, dim=-1)
    proj = getattr(backbone.visual, "proj", None)
    if proj is not None:
        text_features = (proj.detach().float().to(text_features.device) @ text_features.T).T
        text_features = l2_normalize(text_features, dim=-1)
    return text_features


def prepare_text_bank(backbone, text_prompts: list[str], p_norm: torch.Tensor) -> torch.Tensor:
    P_anom_raw = encode_text_features(backbone, text_prompts)
    Delta_P = P_anom_raw - p_norm.unsqueeze(0)
    return l2_normalize(Delta_P, dim=-1)


def extract_residual(v_test: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    v_test = l2_normalize(v_test, dim=-1)
    p_norm = l2_normalize(p_norm, dim=0)
    return v_test - (v_test @ p_norm).unsqueeze(1) * p_norm.unsqueeze(0)


def evaluate_static_axis(r_test: torch.Tensor, Delta_P: torch.Tensor, labels: np.ndarray) -> tuple[float, np.ndarray]:
    delta_static = l2_normalize(Delta_P.mean(dim=0), dim=0)
    scores = (r_test @ delta_static).cpu().numpy()
    auc = safe_auc(labels.tolist(), scores.tolist())
    return auc, scores


def evaluate_max_pooling_routing(r_test: torch.Tensor, Delta_P: torch.Tensor, labels: np.ndarray) -> tuple[float, np.ndarray]:
    Scores_all = r_test @ Delta_P.T
    Score_max, _ = torch.max(Scores_all, dim=-1)
    scores = Score_max.cpu().numpy()
    auc = safe_auc(labels.tolist(), scores.tolist())
    return auc, scores


def evaluate_vanilla_attention_routing(
    r_test: torch.Tensor,
    Delta_P: torch.Tensor,
    labels: np.ndarray,
    temperature: float = 1.0,
) -> tuple[float, np.ndarray]:
    Logits = (r_test @ Delta_P.T) / float(temperature)
    A = F.softmax(Logits, dim=-1)
    p_dynamic = A @ Delta_P
    p_dynamic = l2_normalize(p_dynamic, dim=-1)
    Score_dynamic = (r_test * p_dynamic).sum(dim=-1)
    scores = Score_dynamic.cpu().numpy()
    auc = safe_auc(labels.tolist(), scores.tolist())
    return auc, scores


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def collect_test_tokens(backbone, class_name: str, target_layer: int, args: argparse.Namespace, device: str) -> list[dict]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    side_h, side_w = backbone.grid_size
    records: list[dict] = []
    for idx, rec in enumerate(ds.records):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens = backbone.extract_layer_patch_tokens(image_t, target_layers=[target_layer])[target_layer][0]
        records.append(
            {
                "index": idx,
                "name": name,
                "img_type": img_type,
                "label": int(label != 0),
                "patch_tokens": l2_normalize(tokens.float(), dim=-1).cpu(),
                "patch_mask": to_patch_mask(mask_np, (side_h, side_w), device),
            }
        )
    return records


def evaluate_class(backbone, class_name: str, args: argparse.Namespace, device: str) -> list[dict]:
    p_norm_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    p_norm = encode_text_features(backbone, [p_norm_prompt])[0].cpu()
    Delta_P = prepare_text_bank(backbone, abnormal_prompts, p_norm.to(backbone.device)).cpu()
    records = collect_test_tokens(backbone, class_name, args.target_layer, args, device)

    patch_labels: list[int] = []
    image_labels: list[int] = []
    static_patch_scores: list[float] = []
    max_patch_scores: list[float] = []
    temp_patch_scores: dict[float, list[float]] = {temp: [] for temp in args.temperatures}
    static_image_scores: list[float] = []
    max_image_scores: list[float] = []
    temp_image_scores: dict[float, list[float]] = {temp: [] for temp in args.temperatures}

    for rec in records:
        labels_patch = rec["patch_mask"].astype(np.int64)
        r_test = extract_residual(rec["patch_tokens"], p_norm)
        _, static_scores = evaluate_static_axis(r_test, Delta_P, labels_patch)
        _, max_scores = evaluate_max_pooling_routing(r_test, Delta_P, labels_patch)

        patch_labels.extend(labels_patch.tolist())
        static_patch_scores.extend(static_scores.tolist())
        max_patch_scores.extend(max_scores.tolist())
        image_labels.append(int(rec["label"]))
        static_image_scores.append(topk_mean(static_scores, args.topk_ratio))
        max_image_scores.append(topk_mean(max_scores, args.topk_ratio))

        for temp in args.temperatures:
            _, dyn_scores = evaluate_vanilla_attention_routing(r_test, Delta_P, labels_patch, temperature=float(temp))
            temp_patch_scores[temp].extend(dyn_scores.tolist())
            temp_image_scores[temp].append(topk_mean(dyn_scores, args.topk_ratio))

    rows: list[dict] = []
    static_patch_auc = safe_auc(patch_labels, static_patch_scores)
    static_image_auc = safe_auc(image_labels, static_image_scores)
    max_patch_auc = safe_auc(patch_labels, max_patch_scores)
    max_image_auc = safe_auc(image_labels, max_image_scores)
    rows.append(
        {
            "class_name": class_name,
            "routing": "static",
            "temperature": "",
            "num_prompts": int(Delta_P.shape[0]),
            "patch_auc": static_patch_auc,
            "image_auc": static_image_auc,
        }
    )
    rows.append(
        {
            "class_name": class_name,
            "routing": "max_pool",
            "temperature": "",
            "num_prompts": int(Delta_P.shape[0]),
            "patch_auc": max_patch_auc,
            "image_auc": max_image_auc,
            "patch_auc_delta_vs_static": max_patch_auc - static_patch_auc,
            "image_auc_delta_vs_static": max_image_auc - static_image_auc,
        }
    )
    for temp in args.temperatures:
        patch_auc = safe_auc(patch_labels, temp_patch_scores[temp])
        image_auc = safe_auc(image_labels, temp_image_scores[temp])
        rows.append(
            {
                "class_name": class_name,
                "routing": "softmax",
                "temperature": float(temp),
                "num_prompts": int(Delta_P.shape[0]),
                "patch_auc": patch_auc,
                "image_auc": image_auc,
                "patch_auc_delta_vs_static": patch_auc - static_patch_auc,
                "image_auc_delta_vs_static": image_auc - static_image_auc,
            }
        )
    return rows


def save_plots(rows: list[dict], out_dir: Path, stem: str, temperatures: list[float]) -> None:
    classes = sorted({row["class_name"] for row in rows})
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    x = np.arange(len(classes))
    width = 0.14
    routing_specs = [("static", ""), ("max_pool", "")] + [("softmax", temp) for temp in temperatures]

    for j, (routing, temp) in enumerate(routing_specs):
        patch_vals = []
        image_vals = []
        for cls in classes:
            row = next(r for r in rows if r["class_name"] == cls and r["routing"] == routing and str(r["temperature"]) == str(temp))
            patch_vals.append(float(row["patch_auc"]))
            image_vals.append(float(row["image_auc"]))
        label = routing if routing != "softmax" else f"softmax@T={temp}"
        offset = (j - (len(routing_specs) - 1) / 2.0) * width
        axes[0].bar(x + offset, patch_vals, width, label=label)
        axes[1].bar(x + offset, image_vals, width, label=label)

    axes[0].set_title("Patch AUC")
    axes[1].set_title("Image AUC")
    for ax in axes:
        ax.set_xticks(x)
        ax.set_xticklabels(classes, rotation=30, ha="right")
        ax.set_ylim(0.0, 1.0)
        ax.grid(True, axis="y", alpha=0.3)
    axes[1].legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(out_dir / f"{stem}_auc_compare.png", dpi=180)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    rows: list[dict] = []
    for class_name in args.class_names:
        rows.extend(evaluate_class(backbone, class_name, args, device))

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    stem = f"{args.output_tag}_{class_tag}_L{args.target_layer}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_summary.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=sorted({k for row in rows for k in row.keys()}))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump({"rows": rows, "config": vars(args)}, f, indent=2)

    save_plots(rows, out_dir, stem, args.temperatures)
    print(csv_path)
    print(json_path)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
