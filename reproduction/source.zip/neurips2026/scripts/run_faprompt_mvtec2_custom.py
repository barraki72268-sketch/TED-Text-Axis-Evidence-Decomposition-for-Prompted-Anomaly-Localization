#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OFFICIAL = ROOT / "neurips2026" / "scripts" / "official_parallel_test_faprompt.py"
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
SOURCE_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
TARGET_ROOT = str(ROOT / "neurips2026/results/rawvlm_mvtec2_20260503/mvtec_ad2_meta_view")
CKPT = str(FAP_ROOT / "checkpoints" / "trained_on_mvtecad" / "epoch_15.pth")


def _load_official_module():
    spec = importlib.util.spec_from_file_location("official_parallel_test_faprompt_mvtec2", OFFICIAL)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load {OFFICIAL}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    official = _load_official_module()
    official.PRESET_CONFIGS["mvtec2mvtec2"] = {
        "source_dataset": "mvtecad",
        "target_dataset": "mvtec2",
        "source_root": SOURCE_ROOT,
        "target_root": TARGET_ROOT,
        "checkpoint_path": CKPT,
    }
    sys.argv = [str(OFFICIAL), "--preset", "mvtec2mvtec2", *sys.argv[1:]]
    return int(official.main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())
