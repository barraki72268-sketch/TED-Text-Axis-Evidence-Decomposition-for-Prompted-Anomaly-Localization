#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_ted_mvtec2btad_mpdd_full_20260501"
LOG_ROOT = RESULT_ROOT / "_logs"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")
MPDD_ROOT = "/mnt/data/MPDD"
MVTEC_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth")


TRANSFERS = [
    ("mvtec2btad", BTAD_ROOT, "btad"),
    ("mvtec2mpdd", MPDD_ROOT, "mpdd"),
]


def wait_pid(pid: int) -> None:
    if pid <= 0:
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            print({"stage": "wait_pid_done", "pid": pid}, flush=True)
            return
        time.sleep(60)


def build_cmd(name: str, target_root: str, target_dataset: str, device: str, seed: int) -> tuple[list[str], Path]:
    save_dir = RESULT_ROOT / f"{name}_seed{seed}"
    cmd = [
        PY,
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        MVTEC_CKPT,
        "--heldout_class",
        "none",
        "--source_root",
        MVTEC_ROOT,
        "--source_dataset",
        "mvtec",
        "--target_root",
        target_root,
        "--target_dataset",
        target_dataset,
        "--target_mode",
        "test",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        "8",
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "trainfree",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--aupro_max_step",
        "200",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    return cmd, save_dir


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    wait_pid(args.wait_pid)

    for name, target_root, target_dataset in TRANSFERS:
        cmd, save_dir = build_cmd(name, target_root, target_dataset, args.device, args.seed)
        summary = save_dir / "summary.json"
        if summary.exists() and not args.force:
            print({"stage": "skip_completed", "name": name, "summary": str(summary)}, flush=True)
            continue
        save_dir.mkdir(parents=True, exist_ok=True)
        log_path = LOG_ROOT / f"{name}_seed{args.seed}.log"
        print({"stage": "run", "name": name, "save_dir": str(save_dir), "log": str(log_path)}, flush=True)
        print(" ".join(cmd), flush=True)
        with log_path.open("w") as log_file:
            proc = subprocess.run(cmd, cwd=str(ROOT), stdout=log_file, stderr=subprocess.STDOUT, text=True)
        print({"stage": "done", "name": name, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
        if proc.returncode != 0:
            return proc.returncode
    print({"stage": "done_all", "result_root": str(RESULT_ROOT)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
