from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.scripts.kinematic_text_axis_reconstruction import (
    build_recent_general_prompt_bank,
    encode_text_features,
    reconstruct_optimal_text_axis,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import (
    choose_text_rank,
    collect_oracle_records,
    forward_remaining,
    forward_up_to_layer,
    l2_normalize,
    parse_class_spec,
    patchify_sequence,
    prepare_text_subspace,
    rebuild_sequence,
    safe_auc,
    score_promptmax,
    score_reconstructed_axis,
    topk_mean,
)
from neurips2026.common_backbones import create_winclip_raw_backbone


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("KSM v3-min oracle fit on frozen CLIP.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--class_specs",
        nargs="+",
        default=["fryum:6:9", "capsules:12:9"],
        help="Entries: class_name:train_layer:transfer_layer",
    )
    parser.add_argument(
        "--backbones",
        nargs="+",
        default=["ViT-B-16-plus-240:laion400m_e32:240"],
        help="Entries: backbone:pretrained:imgsize",
    )
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--lr", type=float, default=1e-2)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--gamma_init", type=float, default=0.0)
    parser.add_argument("--train_normal_images", type=int, default=12)
    parser.add_argument("--train_anomaly_images", type=int, default=12)
    parser.add_argument("--eval_normal_images", type=int, default=12)
    parser.add_argument("--eval_anomaly_images", type=int, default=12)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--lambda_n", type=float, default=1.0)
    parser.add_argument("--u_subspace_ratio", type=float, default=0.0)
    parser.add_argument("--lambda_u", type=float, default=0.5)
    parser.add_argument("--lambda_smooth", type=float, default=0.0)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--u_topk_ratio", type=float, default=-1.0)
    parser.add_argument("--router_topk_ratio", type=float, default=-1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--entropy_beta_max", type=float, default=0.05)
    parser.add_argument("--entropy_hold_epochs", type=int, default=2)
    parser.add_argument("--entropy_decay_epochs", type=int, default=5)
    parser.add_argument("--text_var_threshold", type=float, default=0.9)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_ksm_v3_oracle")
    return parser.parse_args()


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = l2_normalize(p_norm, dim=0)
    return v.float() - (v.float() * p_norm.view(*([1] * (v.dim() - 1)), -1)).sum(dim=-1, keepdim=True) * p_norm.view(
        *([1] * (v.dim() - 1)),
        -1,
    )


class KinematicSteeringModuleV3Min(nn.Module):
    def __init__(
        self,
        dim: int,
        delta_bank: torch.Tensor,
        U_basis: torch.Tensor,
        p_norm: torch.Tensor,
        gamma_init: float = 0.0,
    ):
        super().__init__()
        self.dim = int(dim)
        self.num_prompts = int(delta_bank.shape[0])
        self.k = int(U_basis.shape[0])
        self.q_proj_simplex = nn.Linear(3 * self.dim, self.dim, bias=False)
        self.q_proj_subspace = nn.Linear(3 * self.dim, self.dim, bias=False)
        self.router = nn.Linear(self.dim, 1, bias=True)
        nn.init.xavier_uniform_(self.q_proj_simplex.weight, gain=0.25)
        nn.init.xavier_uniform_(self.q_proj_subspace.weight, gain=0.25)
        nn.init.zeros_(self.router.weight)
        nn.init.zeros_(self.router.bias)

        self.register_buffer("p_norm", l2_normalize(p_norm.detach().float(), dim=0))

        delta_bank = delta_bank.detach().float()
        delta_key = l2_normalize(delta_bank, dim=-1)
        delta_val = get_null_space_residual(delta_bank, self.p_norm)
        delta_val = l2_normalize(delta_val, dim=-1)
        self.register_buffer("delta_key", delta_key)
        self.register_buffer("delta_val", delta_val)

        U_basis = l2_normalize(U_basis.detach().float(), dim=-1)
        self.register_buffer("U_basis", U_basis)

        self.gamma_simplex = nn.Parameter(torch.full((1,), float(gamma_init), dtype=torch.float32))
        self.gamma_subspace = nn.Parameter(torch.full((1,), float(gamma_init), dtype=torch.float32))

    def forward(self, v_in: torch.Tensor, return_aux: bool = False):
        bsz, n, dim = v_in.shape
        assert dim == self.dim
        v_in = v_in.float()
        v_bar = v_in.mean(dim=1, keepdim=True)
        v_res = v_in - v_bar
        q_ctx = torch.cat([v_in, v_bar.expand(-1, n, -1), v_res], dim=-1)
        q_simplex = self.q_proj_simplex(q_ctx)
        q_subspace = self.q_proj_subspace(q_ctx)

        simplex_logits = torch.matmul(q_simplex, self.delta_key.T) / math.sqrt(self.dim)
        simplex_attn = torch.softmax(simplex_logits, dim=-1)
        delta_simplex = torch.matmul(simplex_attn, self.delta_val)

        subspace_logits = torch.matmul(q_subspace, self.U_basis.T) / math.sqrt(self.dim)
        subspace_attn = torch.tanh(subspace_logits)
        delta_subspace = torch.matmul(subspace_attn, self.U_basis)

        alpha = torch.sigmoid(self.router(v_bar.squeeze(1))).view(bsz, 1, 1)
        simplex_delta = get_null_space_residual(self.gamma_simplex.view(1, 1, 1) * delta_simplex, self.p_norm)
        subspace_delta = get_null_space_residual(self.gamma_subspace.view(1, 1, 1) * delta_subspace, self.p_norm)
        delta_mix = (
            alpha * simplex_delta
            + (1.0 - alpha) * subspace_delta
        )
        delta_final = get_null_space_residual(delta_mix, self.p_norm)
        v_out = v_in + delta_final
        if not return_aux:
            return v_out
        return v_out, {
            "alpha_tensor": alpha,
            "alpha_mean": float(alpha.mean().item()),
            "gamma_simplex_abs": float(self.gamma_simplex.abs().item()),
            "gamma_subspace_abs": float(self.gamma_subspace.abs().item()),
            "simplex_attn_entropy": float((-(simplex_attn.clamp_min(1e-8) * simplex_attn.clamp_min(1e-8).log()).sum(dim=-1)).mean().item()),
            "simplex_top1_mass": float(simplex_attn.max(dim=-1).values.mean().item()),
            "simplex_delta": simplex_delta,
            "subspace_delta": subspace_delta,
        }


def compute_consensus_loss(
    r_out: torch.Tensor,
    prompt_features: torch.Tensor,
    mask: torch.Tensor,
    topk_ratio: float | None = None,
) -> torch.Tensor:
    pos = mask > 0
    if int(pos.sum().item()) == 0:
        return torch.zeros([], device=r_out.device)
    scores = torch.matmul(r_out[pos], prompt_features.T)
    j_star = torch.argmax(scores.mean(dim=0))
    patch_scores = scores[:, j_star]
    if topk_ratio is None:
        return 1.0 - patch_scores.mean()
    k_anom = max(1, int(float(topk_ratio) * float(patch_scores.numel())))
    topk_scores = torch.topk(patch_scores, k=min(k_anom, patch_scores.numel()), largest=True).values
    return 1.0 - topk_scores.mean()


def compute_hard_norm(
    v_out_raw: torch.Tensor,
    v_in: torch.Tensor,
    mask: torch.Tensor,
    hard_neg_ratio: float,
) -> torch.Tensor:
    neg = mask <= 0
    if int(neg.sum().item()) == 0:
        return torch.zeros([], device=v_out_raw.device)
    v_in_neg = v_in[neg]
    v_out_neg = v_out_raw[neg]
    diff = (v_out_neg - v_in_neg).norm(dim=-1)
    hard_k = max(1, int(round(float(hard_neg_ratio) * float(diff.numel())))) if diff.numel() > 0 else 0
    if hard_k > 0:
        hard_idx = torch.topk(diff, k=min(hard_k, diff.numel()), largest=True).indices
        return torch.nn.functional.mse_loss(v_out_neg[hard_idx], v_in_neg[hard_idx])
    return torch.nn.functional.mse_loss(v_out_neg, v_in_neg)


def compute_spatial_smooth(
    delta_u: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    bsz, num_patches, dim = delta_u.shape
    grid = int(round(math.sqrt(num_patches)))
    if grid * grid != num_patches:
        raise ValueError(f"Expected square patch grid, got {num_patches} patches")

    delta_grid = delta_u.view(bsz, grid, grid, dim)
    mask_grid = mask.view(bsz, grid, grid).float()

    diff_h = delta_grid[:, 1:, :, :] - delta_grid[:, :-1, :, :]
    diff_w = delta_grid[:, :, 1:, :] - delta_grid[:, :, :-1, :]

    mask_h = mask_grid[:, 1:, :] * mask_grid[:, :-1, :]
    mask_w = mask_grid[:, :, 1:] * mask_grid[:, :, :-1]

    loss_h = torch.zeros([], device=delta_u.device)
    loss_w = torch.zeros([], device=delta_u.device)

    if float(mask_h.sum().item()) > 0:
        sq_h = diff_h.pow(2).mean(dim=-1)
        loss_h = (sq_h * mask_h).sum() / (mask_h.sum() + 1e-6)
    if float(mask_w.sum().item()) > 0:
        sq_w = diff_w.pow(2).mean(dim=-1)
        loss_w = (sq_w * mask_w).sum() / (mask_w.sum() + 1e-6)

    return loss_h + loss_w


def compute_ksm_v36_loss(
    v_in: torch.Tensor,
    aux: dict[str, torch.Tensor | float],
    p_norm: torch.Tensor,
    prompt_features: torch.Tensor,
    U_basis: torch.Tensor,
    mask: torch.Tensor,
    lambda_n: float = 1.0,
    u_subspace_ratio: float = 0.0,
    lambda_smooth: float = 0.0,
    topk_anom_ratio: float = 0.3,
    u_topk_ratio: float = -1.0,
    router_topk_ratio: float = -1.0,
    hard_neg_ratio: float = 0.2,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    p_norm = l2_normalize(p_norm, dim=0)
    prompt_features = l2_normalize(prompt_features, dim=-1)
    U_basis = l2_normalize(U_basis, dim=-1)

    simplex_delta = aux["simplex_delta"]
    subspace_delta = aux["subspace_delta"]
    alpha = aux["alpha_tensor"]

    v_out_s_raw = v_in + simplex_delta
    v_out_u_raw = v_in + subspace_delta

    r_out_s = l2_normalize(get_null_space_residual(v_out_s_raw, p_norm), dim=-1)
    r_out_u = l2_normalize(get_null_space_residual(v_out_u_raw, p_norm), dim=-1)

    delta_v_mixed_detached = alpha * simplex_delta.detach() + (1.0 - alpha) * subspace_delta.detach()
    v_out_mixed_raw = v_in + delta_v_mixed_detached
    r_out_mixed = l2_normalize(get_null_space_residual(v_out_mixed_raw, p_norm), dim=-1)

    l_s = compute_consensus_loss(r_out_s, prompt_features, mask, topk_ratio=topk_anom_ratio)
    l_u_global = compute_consensus_loss(
        r_out_u,
        prompt_features,
        mask,
        topk_ratio=(u_topk_ratio if u_topk_ratio > 0 else None),
    )
    pos = mask > 0
    if int(pos.sum().item()) == 0:
        l_u_subspace = torch.zeros([], device=v_in.device)
    else:
        proj_norm = torch.norm(torch.matmul(r_out_u[pos], U_basis.T), dim=-1)
        l_u_subspace = 1.0 - proj_norm.mean()
    rho = float(u_subspace_ratio)
    l_u = (1.0 - rho) * l_u_global + rho * l_u_subspace
    l_router = compute_consensus_loss(
        r_out_mixed,
        prompt_features,
        mask,
        topk_ratio=(router_topk_ratio if router_topk_ratio > 0 else None),
    )

    l_smooth = compute_spatial_smooth(subspace_delta, mask)

    l_norm_s = compute_hard_norm(v_out_s_raw, v_in, mask, hard_neg_ratio)
    l_norm_u = compute_hard_norm(v_out_u_raw, v_in, mask, hard_neg_ratio)

    total = l_s + l_u + l_router + float(lambda_smooth) * l_smooth + float(lambda_n) * (l_norm_s + l_norm_u)
    return total, {
        "l_s": l_s,
        "l_u": l_u,
        "l_u_global": l_u_global,
        "l_u_subspace": l_u_subspace,
        "l_router": l_router,
        "l_smooth": l_smooth,
        "l_norm_s": l_norm_s,
        "l_norm_u": l_norm_u,
    }


def entropy_beta(epoch: int, beta_max: float, hold_epochs: int, decay_epochs: int) -> float:
    if beta_max <= 0:
        return 0.0
    if epoch <= hold_epochs:
        return float(beta_max)
    decay_step = epoch - hold_epochs
    if decay_step >= decay_epochs:
        return 0.0
    frac = 1.0 - (float(decay_step) / float(decay_epochs))
    return float(beta_max) * max(0.0, frac)


def train_one_epoch(
    backbone,
    ksm: KinematicSteeringModuleV3Min,
    layer_idx: int,
    train_records,
    p_norm: torch.Tensor,
    prompt_features: torch.Tensor,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch_idx: int,
) -> dict[str, float]:
    ksm.train()
    loss_vals = []
    loss_s_vals = []
    loss_u_vals = []
    loss_u_global_vals = []
    loss_u_subspace_vals = []
    loss_router_vals = []
    loss_smooth_vals = []
    loss_norm_s_vals = []
    loss_norm_u_vals = []
    alpha_vals = []
    gamma_simplex_vals = []
    gamma_subspace_vals = []
    entropy_vals = []
    top1_vals = []
    entropy_loss_vals = []
    beta = entropy_beta(
        epoch_idx,
        beta_max=args.entropy_beta_max,
        hold_epochs=args.entropy_hold_epochs,
        decay_epochs=args.entropy_decay_epochs,
    )
    for rec in train_records:
        image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
        seq = forward_up_to_layer(backbone, image_t, layer_idx)
        _, patches = patchify_sequence(seq)
        mask = torch.from_numpy(rec.patch_mask.astype(np.int64)).to(device).view(1, -1)
        v_in = patches
        v_out, aux = ksm(v_in, return_aux=True)
        loss, loss_parts = compute_ksm_v36_loss(
            v_in,
            aux,
            p_norm,
            prompt_features,
            ksm.U_basis,
            mask,
            lambda_n=args.lambda_n,
            u_subspace_ratio=args.u_subspace_ratio,
            lambda_smooth=args.lambda_smooth,
            topk_anom_ratio=args.topk_anom_ratio,
            u_topk_ratio=args.u_topk_ratio,
            router_topk_ratio=args.router_topk_ratio,
            hard_neg_ratio=args.hard_neg_ratio,
        )
        alpha_mean = aux["alpha_tensor"].clamp(1e-6, 1.0 - 1e-6)
        l_entropy = (alpha_mean * torch.log(alpha_mean) + (1.0 - alpha_mean) * torch.log(1.0 - alpha_mean)).mean()
        loss = loss + beta * l_entropy
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        loss_vals.append(float(loss.item()))
        loss_s_vals.append(float(loss_parts["l_s"].item()))
        loss_u_vals.append(float(loss_parts["l_u"].item()))
        loss_u_global_vals.append(float(loss_parts["l_u_global"].item()))
        loss_u_subspace_vals.append(float(loss_parts["l_u_subspace"].item()))
        loss_router_vals.append(float(loss_parts["l_router"].item()))
        loss_smooth_vals.append(float(loss_parts["l_smooth"].item()))
        loss_norm_s_vals.append(float(loss_parts["l_norm_s"].item()))
        loss_norm_u_vals.append(float(loss_parts["l_norm_u"].item()))
        entropy_loss_vals.append(float(l_entropy.item()))
        alpha_vals.append(aux["alpha_mean"])
        gamma_simplex_vals.append(aux["gamma_simplex_abs"])
        gamma_subspace_vals.append(aux["gamma_subspace_abs"])
        entropy_vals.append(aux["simplex_attn_entropy"])
        top1_vals.append(aux["simplex_top1_mass"])
    return {
        "train_loss": float(np.mean(loss_vals)) if loss_vals else float("nan"),
        "train_loss_s": float(np.mean(loss_s_vals)) if loss_s_vals else float("nan"),
        "train_loss_u": float(np.mean(loss_u_vals)) if loss_u_vals else float("nan"),
        "train_loss_u_global": float(np.mean(loss_u_global_vals)) if loss_u_global_vals else float("nan"),
        "train_loss_u_subspace": float(np.mean(loss_u_subspace_vals)) if loss_u_subspace_vals else float("nan"),
        "train_loss_router": float(np.mean(loss_router_vals)) if loss_router_vals else float("nan"),
        "train_loss_smooth": float(np.mean(loss_smooth_vals)) if loss_smooth_vals else float("nan"),
        "train_loss_norm_s": float(np.mean(loss_norm_s_vals)) if loss_norm_s_vals else float("nan"),
        "train_loss_norm_u": float(np.mean(loss_norm_u_vals)) if loss_norm_u_vals else float("nan"),
        "train_loss_entropy": float(np.mean(entropy_loss_vals)) if entropy_loss_vals else float("nan"),
        "entropy_beta": float(beta),
        "alpha_mean": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean": float(np.mean(gamma_simplex_vals)) if gamma_simplex_vals else float("nan"),
        "gamma_subspace_abs_mean": float(np.mean(gamma_subspace_vals)) if gamma_subspace_vals else float("nan"),
        "simplex_attn_entropy": float(np.mean(entropy_vals)) if entropy_vals else float("nan"),
        "simplex_top1_mass": float(np.mean(top1_vals)) if top1_vals else float("nan"),
    }


def evaluate_model(
    backbone,
    ksm: KinematicSteeringModuleV3Min,
    layer_idx: int,
    eval_records,
    p_norm: torch.Tensor,
    prompt_features: torch.Tensor,
    delta_p_recon: torch.Tensor,
    topk_ratio: float,
    device: str,
) -> dict[str, float]:
    ksm.eval()
    patch_labels = []
    base_recon_patch_scores = []
    ksm_recon_patch_scores = []
    simplex_recon_patch_scores = []
    subspace_recon_patch_scores = []
    image_labels = []
    base_recon_image_scores = []
    ksm_recon_image_scores = []
    simplex_recon_image_scores = []
    subspace_recon_image_scores = []
    base_prompt_image_scores = []
    ksm_prompt_image_scores = []
    alpha_vals = []
    sem_drop_vals = []
    gamma_s_vals = []
    gamma_u_vals = []
    entropy_vals = []
    top1_vals = []
    with torch.no_grad():
        for rec in eval_records:
            image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            cls_tok, patches = patchify_sequence(seq)
            base_final = forward_remaining(backbone, seq, layer_idx)[0]
            out_patches, aux = ksm(patches, return_aux=True)
            simplex_patches = patches + aux["simplex_delta"]
            subspace_patches = patches + aux["subspace_delta"]
            out_seq = rebuild_sequence(cls_tok, out_patches)
            simplex_seq = rebuild_sequence(cls_tok, simplex_patches)
            subspace_seq = rebuild_sequence(cls_tok, subspace_patches)
            out_final = forward_remaining(backbone, out_seq, layer_idx)[0]
            simplex_final = forward_remaining(backbone, simplex_seq, layer_idx)[0]
            subspace_final = forward_remaining(backbone, subspace_seq, layer_idx)[0]

            base_recon = score_reconstructed_axis(base_final, p_norm, delta_p_recon)
            out_recon = score_reconstructed_axis(out_final, p_norm, delta_p_recon)
            simplex_recon = score_reconstructed_axis(simplex_final, p_norm, delta_p_recon)
            subspace_recon = score_reconstructed_axis(subspace_final, p_norm, delta_p_recon)
            base_prompt = score_promptmax(base_final, p_norm, prompt_features)
            out_prompt = score_promptmax(out_final, p_norm, prompt_features)

            patch_labels.extend(rec.patch_mask.astype(np.int64).tolist())
            base_recon_patch_scores.extend(base_recon.tolist())
            ksm_recon_patch_scores.extend(out_recon.tolist())
            simplex_recon_patch_scores.extend(simplex_recon.tolist())
            subspace_recon_patch_scores.extend(subspace_recon.tolist())
            image_labels.append(rec.label)
            base_recon_image_scores.append(topk_mean(base_recon, topk_ratio))
            ksm_recon_image_scores.append(topk_mean(out_recon, topk_ratio))
            simplex_recon_image_scores.append(topk_mean(simplex_recon, topk_ratio))
            subspace_recon_image_scores.append(topk_mean(subspace_recon, topk_ratio))
            base_prompt_image_scores.append(topk_mean(base_prompt, topk_ratio))
            ksm_prompt_image_scores.append(topk_mean(out_prompt, topk_ratio))

            base_norm = l2_normalize(base_final, dim=-1)
            out_norm = l2_normalize(out_final, dim=-1)
            sem_drop_vals.append(float((out_norm @ p_norm).mean().item() - (base_norm @ p_norm).mean().item()))
            alpha_vals.append(aux["alpha_mean"])
            gamma_s_vals.append(aux["gamma_simplex_abs"])
            gamma_u_vals.append(aux["gamma_subspace_abs"])
            entropy_vals.append(aux["simplex_attn_entropy"])
            top1_vals.append(aux["simplex_top1_mass"])

    base_recon_patch_auc = safe_auc(patch_labels, base_recon_patch_scores)
    ksm_recon_patch_auc = safe_auc(patch_labels, ksm_recon_patch_scores)
    simplex_recon_patch_auc = safe_auc(patch_labels, simplex_recon_patch_scores)
    subspace_recon_patch_auc = safe_auc(patch_labels, subspace_recon_patch_scores)
    base_recon_image_auc = safe_auc(image_labels, base_recon_image_scores)
    ksm_recon_image_auc = safe_auc(image_labels, ksm_recon_image_scores)
    simplex_recon_image_auc = safe_auc(image_labels, simplex_recon_image_scores)
    subspace_recon_image_auc = safe_auc(image_labels, subspace_recon_image_scores)
    base_prompt_image_auc = safe_auc(image_labels, base_prompt_image_scores)
    ksm_prompt_image_auc = safe_auc(image_labels, ksm_prompt_image_scores)
    return {
        "base_recon_patch_auc": base_recon_patch_auc,
        "ksm_recon_patch_auc": ksm_recon_patch_auc,
        "recon_patch_auc_delta": ksm_recon_patch_auc - base_recon_patch_auc,
        "simplex_recon_patch_auc": simplex_recon_patch_auc,
        "simplex_recon_patch_auc_delta": simplex_recon_patch_auc - base_recon_patch_auc,
        "subspace_recon_patch_auc": subspace_recon_patch_auc,
        "subspace_recon_patch_auc_delta": subspace_recon_patch_auc - base_recon_patch_auc,
        "base_recon_image_auc": base_recon_image_auc,
        "ksm_recon_image_auc": ksm_recon_image_auc,
        "recon_image_auc_delta": ksm_recon_image_auc - base_recon_image_auc,
        "simplex_recon_image_auc": simplex_recon_image_auc,
        "simplex_recon_image_auc_delta": simplex_recon_image_auc - base_recon_image_auc,
        "subspace_recon_image_auc": subspace_recon_image_auc,
        "subspace_recon_image_auc_delta": subspace_recon_image_auc - base_recon_image_auc,
        "base_prompt_image_auc": base_prompt_image_auc,
        "ksm_prompt_image_auc": ksm_prompt_image_auc,
        "prompt_image_auc_delta": ksm_prompt_image_auc - base_prompt_image_auc,
        "semantic_drop_mean": float(np.mean(sem_drop_vals)) if sem_drop_vals else float("nan"),
        "alpha_mean_eval": float(np.mean(alpha_vals)) if alpha_vals else float("nan"),
        "gamma_simplex_abs_mean_eval": float(np.mean(gamma_s_vals)) if gamma_s_vals else float("nan"),
        "gamma_subspace_abs_mean_eval": float(np.mean(gamma_u_vals)) if gamma_u_vals else float("nan"),
        "simplex_attn_entropy_eval": float(np.mean(entropy_vals)) if entropy_vals else float("nan"),
        "simplex_top1_mass_eval": float(np.mean(top1_vals)) if top1_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    details = []
    skipped = []

    class_specs = [parse_class_spec(spec) for spec in args.class_specs]
    for backbone_spec in args.backbones:
        backbone_name, pretrained_name, img_size = backbone_spec.split(":")
        img_size_i = int(img_size)
        backbone = create_winclip_raw_backbone(
            backbone=backbone_name,
            pretrained_dataset=pretrained_name,
            device=device,
            img_resize=img_size_i,
            img_cropsize=img_size_i,
        )
        backbone.eval()
        for param in backbone.parameters():
            param.requires_grad_(False)

        for class_name, train_layer, transfer_layer in class_specs:
            try:
                train_records, eval_records = collect_oracle_records(backbone, class_name, args)
                normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
                p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0]
                prompt_features = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts)
                delta_bank = prompt_features - p_norm.unsqueeze(0)
                k = choose_text_rank(delta_bank, args.text_var_threshold)
                U_basis = prepare_text_subspace(prompt_features, p_norm, k)

                anom_chunks = []
                for rec in train_records:
                    if rec.label != 1:
                        continue
                    image_t = rec.image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
                    with torch.no_grad():
                        final = backbone.extract_layer_patch_tokens(image_t, target_layers=[backbone.num_layers])[backbone.num_layers][0]
                    pos = torch.from_numpy(rec.patch_mask > 0).to(final.device)
                    if int(pos.sum().item()) > 0:
                        anom_chunks.append(final[pos].detach())
                if not anom_chunks:
                    raise RuntimeError("No anomaly patches for delta_p_recon construction.")
                patches = torch.cat(anom_chunks, dim=0)
                residual = get_null_space_residual(patches, p_norm.view(-1).to(patches.device))
                residual = residual - residual.mean(dim=0, keepdim=True)
                _, _, vh = torch.linalg.svd(residual, full_matrices=False)
                V_anom = vh[: min(k, vh.shape[0])].contiguous()
                delta_p_recon, _, singular_values = reconstruct_optimal_text_axis(U_basis.T.to(V_anom.device), V_anom.T.contiguous())
                sigma1 = float(singular_values[0].item()) if singular_values.numel() else float("nan")
            except RuntimeError as exc:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": str(exc)})
                continue

            ksm = KinematicSteeringModuleV3Min(
                dim=int(prompt_features.shape[1]),
                delta_bank=delta_bank.to(device),
                U_basis=U_basis.to(device),
                p_norm=p_norm.to(device),
                gamma_init=args.gamma_init,
            ).to(device)
            optimizer = torch.optim.AdamW(ksm.parameters(), lr=args.lr, weight_decay=args.weight_decay)

            history = []
            best_state = None
            best_metric = -float("inf")
            for epoch in range(1, args.epochs + 1):
                train_stats = train_one_epoch(
                    backbone,
                    ksm,
                    train_layer,
                    train_records,
                    p_norm.to(device),
                    prompt_features.to(device),
                    args,
                    optimizer,
                    device,
                    epoch,
                )
                eval_same = evaluate_model(
                    backbone,
                    ksm,
                    train_layer,
                    eval_records,
                    p_norm.to(device),
                    prompt_features.to(device),
                    delta_p_recon.to(device),
                    args.topk_ratio,
                    device,
                )
                history.append({"epoch": epoch, **train_stats, **eval_same})
                if eval_same["ksm_recon_image_auc"] > best_metric:
                    best_metric = eval_same["ksm_recon_image_auc"]
                    best_state = {k0: v.detach().cpu() for k0, v in ksm.state_dict().items()}

            if best_state is None:
                skipped.append({"backbone": backbone_name, "class_name": class_name, "reason": "No best state"})
                continue

            ksm.load_state_dict(best_state)
            same_eval = evaluate_model(
                backbone,
                ksm,
                train_layer,
                eval_records,
                p_norm.to(device),
                prompt_features.to(device),
                delta_p_recon.to(device),
                args.topk_ratio,
                device,
            )
            transfer_eval = evaluate_model(
                backbone,
                ksm,
                transfer_layer,
                eval_records,
                p_norm.to(device),
                prompt_features.to(device),
                delta_p_recon.to(device),
                args.topk_ratio,
                device,
            )

            common = {
                "backbone": backbone_name,
                "pretrained": pretrained_name,
                "img_size": img_size_i,
                "class_name": class_name,
                "train_layer": train_layer,
                "text_rank": int(k),
                "epochs": args.epochs,
                "sigma1": sigma1,
            }
            rows.append({**common, "eval_layer": train_layer, "transfer_eval": 0, **history[-1], **same_eval})
            rows.append({**common, "eval_layer": transfer_layer, "transfer_eval": 1, **history[-1], **transfer_eval})
            details.append({**common, "transfer_layer": transfer_layer, "history": history})

    stem = f"{args.output_tag}_{'-'.join(s.split(':')[0] for s in args.class_specs)}_{'-'.join(spec.split(':')[0] for spec in args.backbones)}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()}) if rows else []
    with csv_path.open("w", newline="") as f:
        if fieldnames:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"rows": rows, "details": details, "skipped": skipped}, f, indent=2)
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
