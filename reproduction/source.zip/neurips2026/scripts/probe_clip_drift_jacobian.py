from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import PIL.Image
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


MVTEC_CLASSES = [
    "bottle",
    "cable",
    "capsule",
    "carpet",
    "grid",
    "hazelnut",
    "leather",
    "metal_nut",
    "pill",
    "screw",
    "tile",
    "toothbrush",
    "transistor",
    "wood",
    "zipper",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--visa_classes", nargs="*", default=[])
    parser.add_argument("--mvtec_classes", nargs="*", default=[])
    parser.add_argument("--inject_layer", type=int, default=1)
    parser.add_argument("--track_layers", nargs="+", type=int, default=[1, 3, 6, 9, 12])
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--subspace_k", type=int, default=4)
    parser.add_argument("--max_fit_anomaly_images", type=int, default=5)
    parser.add_argument("--max_eval_normal_images", type=int, default=5)
    parser.add_argument("--max_anomaly_patches", type=int, default=2048)
    parser.add_argument("--max_delta_rows", type=int, default=2048)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_drift_jacobian")
    return parser.parse_args()


class SimpleMVTecDataset:
    def __init__(self, root: str, class_name: str, split: str = "test") -> None:
        self.root = Path(root)
        self.class_name = class_name
        self.split = split
        self.records = self._load_records()

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int):
        rec = self.records[idx]
        image = np.asarray(PIL.Image.open(rec["image_path"]).convert("RGB"), dtype=np.uint8)
        if rec["mask_path"] is None:
            mask = np.zeros((image.shape[0], image.shape[1]), dtype=np.uint8)
        else:
            mask = np.asarray(PIL.Image.open(rec["mask_path"]).convert("L"), dtype=np.uint8)
            mask = (mask > 0).astype(np.uint8) * 255
        return image, mask, rec["label"], rec["name"], rec["anomaly"]

    def _load_records(self) -> list[dict]:
        image_dir = self.root / self.class_name / self.split
        mask_dir = self.root / self.class_name / "ground_truth"
        records: list[dict] = []
        for img_type in sorted(p.name for p in image_dir.iterdir() if p.is_dir()):
            type_dir = image_dir / img_type
            image_paths = sorted(type_dir.glob("*.png"))
            if img_type == "good":
                for path in image_paths:
                    records.append(
                        {
                            "image_path": str(path),
                            "mask_path": None,
                            "label": 0,
                            "anomaly": "good",
                            "name": f"{self.class_name}-good-{path.stem}",
                        }
                    )
            else:
                gt_dir = mask_dir / img_type
                for path in image_paths:
                    mask_path = gt_dir / f"{path.stem}_mask.png"
                    records.append(
                        {
                            "image_path": str(path),
                            "mask_path": str(mask_path),
                            "label": 1,
                            "anomaly": img_type,
                            "name": f"{self.class_name}-{img_type}-{path.stem}",
                        }
                    )
        return records


def list_visa_classes(split_csv: str) -> list[str]:
    csv_data = pd.read_csv(Path(split_csv))
    return list(dict.fromkeys(csv_data["object"].tolist()))


def build_token_normal_anchor(backbone, class_name: str) -> torch.Tensor:
    prompts: list[str] = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = backbone.visual.proj.detach().float().to(text_anchor.device)
    token_anchor = proj @ text_anchor
    return F.normalize(token_anchor, dim=0)


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> torch.Tensor:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .to(dtype=torch.bool)
    )


def maybe_subsample_rows(x: torch.Tensor, max_rows: int) -> torch.Tensor:
    if max_rows <= 0 or x.shape[0] <= max_rows:
        return x
    idx = torch.linspace(0, x.shape[0] - 1, steps=max_rows, device=x.device).round().long()
    return x[idx]


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    v_proj = (v @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return v.float() - v_proj


def forward_up_to_layer(model, image: torch.Tensor, layer_idx: int, return_sequence: bool = False):
    sequence = model.prepare_sequence(image)
    seq_mid = model.run_blocks(sequence, start_layer=1, end_layer=layer_idx)
    tokens_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
    if return_sequence:
        return tokens_mid, seq_mid
    return tokens_mid


def run_remaining_with_capture(
    model,
    v_mid: torch.Tensor,
    cls_token: torch.Tensor,
    start_layer: int,
    target_layers: list[int],
) -> dict[int, torch.Tensor]:
    if not target_layers:
        return {}
    batch_seq = torch.cat([cls_token, v_mid], dim=1)
    sequence = batch_seq.permute(1, 0, 2)
    outputs: dict[int, torch.Tensor] = {}

    def capture(block_idx: int, x: torch.Tensor) -> torch.Tensor:
        if block_idx in target_layers:
            outputs[block_idx] = x.permute(1, 0, 2)[:, 1:, :].float()
        return x

    model.run_blocks(sequence, start_layer=start_layer, end_layer=max(target_layers), layer_callback=capture)
    return outputs


def inject_kinematic_signal(v_mid: torch.Tensor, p_norm: torch.Tensor, V_anom: torch.Tensor, alpha: float) -> torch.Tensor:
    r_mid = get_null_space_residual(v_mid, p_norm)
    delta_v = torch.matmul(torch.matmul(r_mid, V_anom), V_anom.T)
    return v_mid + float(alpha) * delta_v


def get_dataset(domain: str, root: str, split_csv: str, class_name: str):
    if domain == "visa":
        return OfficialVisAWinClipDataset(root, split_csv, class_name, "test")
    if domain == "mvtec":
        return SimpleMVTecDataset(root, class_name, "test")
    raise ValueError(domain)


def is_anomaly_record(rec: dict) -> bool:
    label = rec["label"]
    if isinstance(label, str):
        return label != "normal"
    return int(label) != 0


def is_normal_record(rec: dict) -> bool:
    return not is_anomaly_record(rec)


def extract_anomaly_subspace(
    backbone,
    domain: str,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    layer_idx: int,
    max_images: int,
    max_patches: int,
    subspace_k: int,
) -> torch.Tensor:
    ds = get_dataset(domain, dataset_root, split_csv, class_name)
    anomaly_indices = [i for i, rec in enumerate(ds.records) if is_anomaly_record(rec)][:max_images]
    collected: list[torch.Tensor] = []
    for idx in anomaly_indices:
        image_np, mask_np, label, _, _ = ds[idx]
        assert int(label) == 1
        image_t = backbone.transform_pil(PIL.Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        tokens = forward_up_to_layer(backbone, image_t, layer_idx)
        patch_mask = to_patch_mask(mask_np, backbone.grid_size, backbone.device)
        if int(patch_mask.sum().item()) == 0:
            continue
        collected.append(tokens[0][patch_mask].detach())
    if not collected:
        raise RuntimeError(f"No anomaly patches collected for {domain}:{class_name}")
    patches = maybe_subsample_rows(torch.cat(collected, dim=0), max_patches)
    residual = get_null_space_residual(patches, p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:subspace_k].T.contiguous()


def fit_transport_operator(delta_l: torch.Tensor, delta_next: torch.Tensor) -> torch.Tensor:
    # delta_l @ T ≈ delta_next
    return torch.linalg.lstsq(delta_l, delta_next).solution


def normalized_flatten(x: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    flat = x.reshape(-1).float()
    norm = torch.linalg.vector_norm(flat)
    if norm <= eps:
        return flat
    return flat / norm


def local_angle_deg(delta_l: torch.Tensor, delta_next: torch.Tensor) -> float:
    cos = F.cosine_similarity(delta_l, delta_next, dim=-1)
    cos = torch.clamp(cos, -1.0, 1.0)
    ang = torch.rad2deg(torch.arccos(cos))
    return float(ang.mean().item())


def compute_transport_metrics(delta_l: torch.Tensor, delta_next: torch.Tensor) -> dict[str, object]:
    T = fit_transport_operator(delta_l, delta_next)
    sv = torch.linalg.svdvals(T)
    top_vals = sv[:5].detach().cpu().tolist()
    stable_rank = float((sv.square().sum() / (sv.max().square() + 1e-8)).item())
    return {
        "transport": T.detach().cpu(),
        "transport_vec": normalized_flatten(T.detach().cpu()),
        "local_angle_deg": local_angle_deg(delta_l, delta_next),
        "top_sv": float(sv[0].item()),
        "stable_rank": stable_rank,
        "top5_singular_values": [float(v) for v in top_vals],
    }


def evaluate_class(
    backbone,
    domain: str,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    V_anom: torch.Tensor,
    inject_layer: int,
    track_layers: list[int],
    alpha: float,
    max_eval_normal_images: int,
    max_delta_rows: int,
) -> list[dict[str, object]]:
    ds = get_dataset(domain, dataset_root, split_csv, class_name)
    normal_indices = [i for i, rec in enumerate(ds.records) if is_normal_record(rec)][:max_eval_normal_images]
    per_layer_rows: dict[int, list[torch.Tensor]] = {layer: [] for layer in track_layers}

    for idx in normal_indices:
        image_np, _, label, _, _ = ds[idx]
        assert int(label) == 0
        image_t = backbone.transform_pil(PIL.Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            _, seq_mid = forward_up_to_layer(backbone, image_t, inject_layer, return_sequence=True)
            cls_token = seq_mid.permute(1, 0, 2)[:, :1, :].float()
            v_base_l1 = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
            v_inj_l1 = inject_kinematic_signal(v_base_l1, p_norm, V_anom, alpha)
            future_layers = [layer for layer in track_layers if layer > inject_layer]
            base_caps = run_remaining_with_capture(backbone, v_base_l1, cls_token, inject_layer + 1, future_layers)
            inj_caps = run_remaining_with_capture(backbone, v_inj_l1, cls_token, inject_layer + 1, future_layers)

        base_by_layer = {inject_layer: v_base_l1[0].cpu()}
        inj_by_layer = {inject_layer: v_inj_l1[0].cpu()}
        for layer in future_layers:
            base_by_layer[layer] = base_caps[layer][0].cpu()
            inj_by_layer[layer] = inj_caps[layer][0].cpu()
        for layer in track_layers:
            delta = inj_by_layer[layer] - base_by_layer[layer]
            per_layer_rows[layer].append(delta)

    flat_by_layer: dict[int, torch.Tensor] = {}
    for layer in track_layers:
        flat = torch.cat([x.reshape(-1, x.shape[-1]) for x in per_layer_rows[layer]], dim=0)
        flat_by_layer[layer] = maybe_subsample_rows(flat, max_delta_rows)

    rows: list[dict[str, object]] = []
    for l0, l1 in zip(track_layers[:-1], track_layers[1:]):
        metrics = compute_transport_metrics(flat_by_layer[l0], flat_by_layer[l1])
        rows.append(
            {
                "domain": domain,
                "class_name": class_name,
                "transition": f"{l0}->{l1}",
                "from_layer": l0,
                "to_layer": l1,
                "alpha": float(alpha),
                "subspace_k": int(V_anom.shape[1]),
                "num_eval_normals": len(normal_indices),
                "num_delta_rows": int(flat_by_layer[l0].shape[0]),
                "local_angle_deg": metrics["local_angle_deg"],
                "top_sv": metrics["top_sv"],
                "stable_rank": metrics["stable_rank"],
                "top5_singular_values": metrics["top5_singular_values"],
                "transport_vec": metrics["transport_vec"].tolist(),
            }
        )
    return rows


def aggregate_domain(rows: list[dict[str, object]]) -> tuple[list[dict[str, object]], dict[tuple[str, str], torch.Tensor]]:
    out: list[dict[str, object]] = []
    mean_vecs: dict[tuple[str, str], torch.Tensor] = {}
    domains = sorted({str(r["domain"]) for r in rows})
    transitions = sorted({str(r["transition"]) for r in rows}, key=lambda s: int(s.split("->")[0]))
    for domain in domains:
        for transition in transitions:
            group = [r for r in rows if str(r["domain"]) == domain and str(r["transition"]) == transition]
            vecs = [torch.tensor(r["transport_vec"], dtype=torch.float32) for r in group]
            mean_vec = normalized_flatten(torch.stack(vecs, dim=0).mean(dim=0))
            mean_vecs[(domain, transition)] = mean_vec
            cos_to_mean = [float(F.cosine_similarity(v.unsqueeze(0), mean_vec.unsqueeze(0)).item()) for v in vecs]
            local_angles = np.asarray([float(r["local_angle_deg"]) for r in group], dtype=np.float64)
            top_svs = np.asarray([float(r["top_sv"]) for r in group], dtype=np.float64)
            stable_ranks = np.asarray([float(r["stable_rank"]) for r in group], dtype=np.float64)
            out.append(
                {
                    "domain": domain,
                    "transition": transition,
                    "num_classes": len(group),
                    "local_angle_deg_mean": float(local_angles.mean()),
                    "local_angle_deg_std": float(local_angles.std()),
                    "top_sv_mean": float(top_svs.mean()),
                    "top_sv_std": float(top_svs.std()),
                    "stable_rank_mean": float(stable_ranks.mean()),
                    "stable_rank_std": float(stable_ranks.std()),
                    "operator_cos_to_domain_mean_mean": float(np.mean(cos_to_mean)),
                    "operator_cos_to_domain_mean_std": float(np.std(cos_to_mean)),
                }
            )
    return out, mean_vecs


def cross_domain_similarity(mean_vecs: dict[tuple[str, str], torch.Tensor]) -> list[dict[str, object]]:
    transitions = sorted({transition for (_, transition) in mean_vecs.keys()}, key=lambda s: int(s.split("->")[0]))
    rows: list[dict[str, object]] = []
    for transition in transitions:
        v = mean_vecs[("visa", transition)]
        m = mean_vecs[("mvtec", transition)]
        rows.append(
            {
                "transition": transition,
                "mean_operator_cosine": float(F.cosine_similarity(v.unsqueeze(0), m.unsqueeze(0)).item()),
            }
        )
    return rows


def plot_domain_summary(domain_rows: list[dict[str, object]], out_dir: Path, stem: str) -> None:
    metrics = [
        ("local_angle_deg_mean", "Local Angle (deg)"),
        ("top_sv_mean", "Top Singular Value"),
        ("stable_rank_mean", "Stable Rank"),
        ("operator_cos_to_domain_mean_mean", "Operator Cosine To Domain Mean"),
    ]
    domains = sorted({str(r["domain"]) for r in domain_rows})
    transitions = sorted({str(r["transition"]) for r in domain_rows}, key=lambda s: int(s.split("->")[0]))
    xs = np.arange(len(transitions))
    for metric_key, title in metrics:
        plt.figure(figsize=(6.5, 4.0))
        for domain in domains:
            subset = [r for r in domain_rows if str(r["domain"]) == domain]
            subset = sorted(subset, key=lambda x: int(str(x["transition"]).split("->")[0]))
            ys = [float(r[metric_key]) for r in subset]
            plt.plot(xs, ys, marker="o", label=domain)
        plt.xticks(xs, transitions)
        plt.xlabel("Layer Transition")
        plt.ylabel(title)
        plt.title(title)
        plt.grid(alpha=0.25)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / f"{stem}_{metric_key}.png", dpi=200)
        plt.close()


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    track_layers = sorted(set(args.track_layers + [args.inject_layer]))
    visa_classes = args.visa_classes or list_visa_classes(args.visa_split_csv)
    mvtec_classes = args.mvtec_classes or MVTEC_CLASSES
    class_rows: list[dict[str, object]] = []
    skipped: list[dict[str, str]] = []

    for domain, root, split_csv, class_names in [
        ("visa", args.visa_root, args.visa_split_csv, visa_classes),
        ("mvtec", args.mvtec_root, "", mvtec_classes),
    ]:
        for class_name in class_names:
            p_norm = build_token_normal_anchor(backbone, class_name).to(backbone.device)
            try:
                V_anom = extract_anomaly_subspace(
                    backbone=backbone,
                    domain=domain,
                    dataset_root=root,
                    split_csv=split_csv,
                    class_name=class_name,
                    p_norm=p_norm,
                    layer_idx=args.inject_layer,
                    max_images=args.max_fit_anomaly_images,
                    max_patches=args.max_anomaly_patches,
                    subspace_k=args.subspace_k,
                ).to(backbone.device)
            except RuntimeError as exc:
                skipped.append({"domain": domain, "class_name": class_name, "reason": str(exc)})
                continue
            class_rows.extend(
                evaluate_class(
                    backbone=backbone,
                    domain=domain,
                    dataset_root=root,
                    split_csv=split_csv,
                    class_name=class_name,
                    p_norm=p_norm,
                    V_anom=V_anom,
                    inject_layer=args.inject_layer,
                    track_layers=track_layers,
                    alpha=args.alpha,
                    max_eval_normal_images=args.max_eval_normal_images,
                    max_delta_rows=args.max_delta_rows,
                )
            )

    domain_rows, mean_vecs = aggregate_domain(class_rows)
    cross_rows = cross_domain_similarity(mean_vecs)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_visa{len(visa_classes)}_mvtec{len(mvtec_classes)}_L{args.inject_layer}"
    class_csv = out_dir / f"{stem}_class_summary.csv"
    domain_csv = out_dir / f"{stem}_domain_summary.csv"
    cross_csv = out_dir / f"{stem}_cross_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"

    with class_csv.open("w", newline="") as f:
        fieldnames = [k for k in class_rows[0].keys() if k != "transport_vec"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in class_rows:
            writer.writerow({k: v for k, v in row.items() if k != "transport_vec"})
    with domain_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(domain_rows[0].keys()))
        writer.writeheader()
        writer.writerows(domain_rows)
    with cross_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(cross_rows[0].keys()))
        writer.writeheader()
        writer.writerows(cross_rows)
    with json_path.open("w") as f:
        json.dump(
            {
                "config": vars(args),
                "skipped": skipped,
                "domain_rows": domain_rows,
                "cross_rows": cross_rows,
            },
            f,
            indent=2,
        )
    plot_domain_summary(domain_rows, out_dir, stem)
    print(class_csv)
    print(domain_csv)
    print(cross_csv)
    print(json_path)
    print(json.dumps({"skipped": skipped, "domain_rows": domain_rows, "cross_rows": cross_rows}, indent=2))


if __name__ == "__main__":
    main()
