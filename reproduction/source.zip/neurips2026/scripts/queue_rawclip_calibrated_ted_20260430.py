from __future__ import annotations

import os
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
RAWCLIP_SCRIPT = ROOT / "neurips2026/scripts/official_parallel_test_rawclip.py"
IMAGEBIND_SCRIPT = ROOT / "neurips2026/scripts/official_parallel_test_rawimagebind.py"
RESULT_ROOT = ROOT / "neurips2026/results/rawclip_calibrated_ted_20260430"
LOG_ROOT = RESULT_ROOT / "_logs"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT = str(ROOT / "neurips2026/data/VisA_pytorch_official/1cls")
MPDD_ROOT = "/mnt/data/MPDD"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")

TRANSFERS = [
    {"name": "visa2mvtec", "source_root": VISA_ROOT, "source_dataset": "visa", "target_root": MVTEC_ROOT, "target_dataset": "mvtec"},
    {"name": "mvtec2visa", "source_root": MVTEC_ROOT, "source_dataset": "mvtec", "target_root": VISA_ROOT, "target_dataset": "visa"},
    {"name": "mvtec2mpdd", "source_root": MVTEC_ROOT, "source_dataset": "mvtec", "target_root": MPDD_ROOT, "target_dataset": "mpdd"},
    {"name": "mvtec2btad", "source_root": MVTEC_ROOT, "source_dataset": "mvtec", "target_root": BTAD_ROOT, "target_dataset": "btad"},
]

CLIP_BACKBONES = [
    {"tag": "vitl336", "backbone": "ViT-L-14-336", "pretrained": "openai", "image_size": "336"},
    {"tag": "vitbplus", "backbone": "ViT-B-16-plus-240", "pretrained": "laion400m_e32", "image_size": "240"},
    {"tag": "vitl_openai", "backbone": "ViT-L-14", "pretrained": "openai", "image_size": "224"},
    {"tag": "vith14", "backbone": "ViT-H-14", "pretrained": "laion2b_s32b_b79k", "image_size": "224"},
]


def clip_cmd(backbone: dict[str, str], transfer: dict[str, str]) -> list[str]:
    save_dir = RESULT_ROOT / f"rawclip_{backbone['tag']}_{transfer['name']}"
    bank_cache = ROOT / "neurips2026/results/bank_cache" / f"rawclip_calib_{backbone['tag']}_{transfer['source_dataset']}.pt"
    return [
        PY,
        "-u",
        str(RAWCLIP_SCRIPT),
        "--source_root",
        transfer["source_root"],
        "--source_dataset",
        transfer["source_dataset"],
        "--target_root",
        transfer["target_root"],
        "--target_dataset",
        transfer["target_dataset"],
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank_cache),
        "--backbone",
        backbone["backbone"],
        "--pretrained_dataset",
        backbone["pretrained"],
        "--image_size",
        backbone["image_size"],
        "--prompt_mode",
        "class",
        "--sigma",
        "4",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--map_activation",
        "identity",
        "--enable_calibrator",
        "--calib_epochs",
        "80",
        "--calib_eta_init",
        "0.02",
        "--calib_eta_max",
        "0.2",
        "--calib_max_good_per_class",
        "8",
        "--calib_max_defect_per_class",
        "8",
        "--calib_max_train_points",
        "8192",
        "--device",
        "cuda:0",
    ]


def imagebind_cmd(transfer: dict[str, str]) -> list[str]:
    save_dir = RESULT_ROOT / f"rawimagebind_{transfer['name']}"
    bank_cache = ROOT / "neurips2026/results/bank_cache" / f"rawimagebind_calib_{transfer['source_dataset']}.pt"
    return [
        PY,
        "-u",
        str(IMAGEBIND_SCRIPT),
        "--source_root",
        transfer["source_root"],
        "--source_dataset",
        transfer["source_dataset"],
        "--target_root",
        transfer["target_root"],
        "--target_dataset",
        transfer["target_dataset"],
        "--save_dir",
        str(save_dir),
        "--bank_cache_path",
        str(bank_cache),
        "--prompt_mode",
        "class",
        "--image_size",
        "224",
        "--sigma",
        "4",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--map_activation",
        "identity",
        "--enable_calibrator",
        "--calib_epochs",
        "80",
        "--calib_eta_init",
        "0.02",
        "--calib_eta_max",
        "0.2",
        "--calib_max_good_per_class",
        "8",
        "--calib_max_defect_per_class",
        "8",
        "--calib_max_train_points",
        "8192",
        "--device",
        "cuda:0",
    ]


def run_one(name: str, cmd: list[str]) -> None:
    save_dir = Path(cmd[cmd.index("--save_dir") + 1])
    summary_path = save_dir / "summary.json"
    if summary_path.exists():
        print({"stage": "skip_existing", "job": name, "summary": str(summary_path)}, flush=True)
        return
    log_path = LOG_ROOT / f"{name}.log"
    print({"stage": "start", "job": name, "log": str(log_path)}, flush=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    with log_path.open("w") as log_file:
        proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=log_file, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "job": name, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
    if proc.returncode != 0:
        raise SystemExit(proc.returncode)


def main() -> None:
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    for backbone in CLIP_BACKBONES:
        for transfer in TRANSFERS:
            run_one(f"rawclip_{backbone['tag']}_{transfer['name']}", clip_cmd(backbone, transfer))
    for transfer in TRANSFERS:
        run_one(f"rawimagebind_{transfer['name']}", imagebind_cmd(transfer))


if __name__ == "__main__":
    main()
