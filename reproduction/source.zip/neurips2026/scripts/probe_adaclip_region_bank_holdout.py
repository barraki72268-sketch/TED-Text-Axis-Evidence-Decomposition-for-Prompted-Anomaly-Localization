from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADA_ROOT = ROOT / "neurips2026" / "AdaCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ADA_ROOT) not in sys.path:
    sys.path.insert(0, str(ADA_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

from dataset.mvtec import MVTEC_CLS_NAMES, MVTecDataset  # noqa: E402
from method.trainer import AdaCLIP_Trainer  # noqa: E402
from region_descriptor_utils import (  # noqa: E402
    FEATURE_NAMES,
    extract_region_descriptor,
    iterate_components,
    rows_to_matrix,
    save_json,
    save_rows,
)


COMBOS = [
    ["peak", "area"],
    ["peak", "mean"],
    ["peak", "top10_mean"],
    ["peak", "fill_ratio"],
    ["peak", "compactness"],
    ["peak", "ring_contrast"],
    ["peak", "area", "fill_ratio"],
    ["peak", "mean", "area", "fill_ratio", "compactness", "ring_contrast"],
]


def build_model(device: str, checkpoint_path: str):
    model = AdaCLIP_Trainer(
        backbone="ViT-L-14-336",
        feat_list=[6, 12, 18, 24],
        input_dim=1024,
        output_dim=768,
        learning_rate=0.001,
        device=device,
        image_size=518,
        prompting_depth=4,
        prompting_length=5,
        prompting_branch="VL",
        prompting_type="SD",
        use_hsf=True,
        k_clusters=20,
        use_ir_scorer=False,
        text_leakage_reg=False,
    )
    model.load(checkpoint_path)
    model.eval()
    model.clip_model.eval()
    return model


def build_dataset(model, root: str, training: bool):
    return MVTecDataset(
        transform=model.preprocess,
        target_transform=model.transform,
        clsnames=MVTEC_CLS_NAMES,
        root=root,
        training=training,
    )


def compute_map(model, image: torch.Tensor, cls_name: str):
    anomaly_map, _ = model.clip_model(image, [cls_name], aggregation=True)
    return gaussian_filter(anomaly_map[0].detach().cpu().numpy(), sigma=4)


def collect_rows(model, dataset, device: str, top_fracs: list[float], min_area: int, max_per_class: int, bank_name: str):
    per_class = {cls_name: 0 for cls_name in dataset.cls_names}
    rows = []
    with torch.no_grad():
        for img_idx in range(len(dataset)):
            item = dataset[img_idx]
            cls_name = item["cls_name"]
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            anomaly_flag = int(anomaly_flag)
            if bank_name == "fp" and anomaly_flag != 0:
                continue
            if bank_name == "defect" and anomaly_flag == 0:
                continue
            if per_class[cls_name] >= max_per_class:
                continue
            per_class[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            anomaly_map = compute_map(model, image, cls_name)
            if bank_name == "fp":
                from common_map_group_separability import top_fraction_mask  # noqa: WPS433

                for frac in top_fracs:
                    mask = top_fraction_mask(anomaly_map, frac)
                    for comp in iterate_components(mask):
                        if int(comp.sum()) < min_area:
                            continue
                        desc = extract_region_descriptor(anomaly_map, comp)
                        if not desc:
                            continue
                        desc.update({"bank": "fp", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": frac})
                        rows.append(desc)
            else:
                gt_mask = item["img_mask"][0].numpy() > 0.5
                for comp in iterate_components(gt_mask):
                    if int(comp.sum()) < min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    desc.update({"bank": "defect", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": -1.0})
                    rows.append(desc)
            if (img_idx + 1) % 50 == 0:
                print(json.dumps({f"{bank_name}_bank_progress": img_idx + 1, "num_regions": len(rows)}), flush=True)
    return rows


def compute_holdout_summary(fp_rows: list[dict], defect_rows: list[dict]):
    classes = sorted(set(row["cls_name"] for row in fp_rows) & set(row["cls_name"] for row in defect_rows))
    name_to_idx = {name: i for i, name in enumerate(FEATURE_NAMES)}
    holdout_rows = []
    for heldout in classes:
        fp_train = [row for row in fp_rows if row["cls_name"] != heldout]
        df_train = [row for row in defect_rows if row["cls_name"] != heldout]
        fp_eval = [row for row in fp_rows if row["cls_name"] == heldout]
        df_eval = [row for row in defect_rows if row["cls_name"] == heldout]
        if not fp_train or not df_train or not fp_eval or not df_eval:
            continue
        X_train = np.concatenate([rows_to_matrix(fp_train, FEATURE_NAMES), rows_to_matrix(df_train, FEATURE_NAMES)], axis=0)
        y_train = np.concatenate([np.zeros(len(fp_train), dtype=np.int64), np.ones(len(df_train), dtype=np.int64)], axis=0)
        X_eval = np.concatenate([rows_to_matrix(fp_eval, FEATURE_NAMES), rows_to_matrix(df_eval, FEATURE_NAMES)], axis=0)
        y_eval = np.concatenate([np.zeros(len(fp_eval), dtype=np.int64), np.ones(len(df_eval), dtype=np.int64)], axis=0)

        for feat_idx, feature_name in enumerate(FEATURE_NAMES):
            auc = roc_auc_score(y_eval, X_eval[:, feat_idx])
            eff_auc = max(float(auc), float(1.0 - auc))
            direction = "defect_high" if auc >= 0.5 else "fp_high"
            holdout_rows.append({"heldout_class": heldout, "kind": "single", "name": feature_name, "auc_eval": eff_auc, "direction": direction})

        for combo in COMBOS:
            idxs = [name_to_idx[c] for c in combo]
            clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
            clf.fit(X_train[:, idxs], y_train)
            pred = clf.predict_proba(X_eval[:, idxs])[:, 1]
            auc = roc_auc_score(y_eval, pred)
            holdout_rows.append({"heldout_class": heldout, "kind": "combo", "name": "+".join(combo), "auc_eval": float(auc), "direction": "defect_high"})

    def aggregate(rows: list[dict]):
        grouped: dict[str, list[float]] = {}
        for row in rows:
            grouped.setdefault(row["name"], []).append(float(row["auc_eval"]))
        out = []
        for name, vals in grouped.items():
            out.append({"name": name, "mean_auc": float(np.mean(vals)), "std_auc": float(np.std(vals)), "num_holdouts": len(vals)})
        out.sort(key=lambda x: x["mean_auc"], reverse=True)
        return out

    return {
        "num_fp_regions": len(fp_rows),
        "num_defect_regions": len(defect_rows),
        "single_summary": aggregate([row for row in holdout_rows if row["kind"] == "single"]),
        "combo_summary": aggregate([row for row in holdout_rows if row["kind"] == "combo"]),
        "holdout_rows": holdout_rows,
    }


def main():
    parser = argparse.ArgumentParser("Build AdaCLIP source region banks and leave-one-class-out descriptor sanity")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_fair_baseline_mvtec2visa" / "models" / "0s-pretrained-['mvtec']-ViT-L-14-336-SD-VL-D4-L5-HSF-K20_last.pth"),
    )
    parser.add_argument("--top_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--max_per_class_fp", type=int, default=200)
    parser.add_argument("--max_per_class_defect", type=int, default=80)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaclip_region_bank_holdout_last"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    model = build_model(args.device, args.checkpoint_path)
    train_dataset = build_dataset(model, args.source_root, training=True)
    test_dataset = build_dataset(model, args.source_root, training=False)

    fp_rows = collect_rows(model, train_dataset, args.device, args.top_fracs, args.min_area, args.max_per_class_fp, "fp")
    save_rows(fp_rows, Path(args.save_dir) / "fp_rows.csv")
    defect_rows = collect_rows(model, test_dataset, args.device, args.top_fracs, args.min_area, args.max_per_class_defect, "defect")
    save_rows(defect_rows, Path(args.save_dir) / "defect_rows.csv")

    summary = compute_holdout_summary(fp_rows, defect_rows)
    save_rows(summary["single_summary"], Path(args.save_dir) / "single_summary.csv")
    save_rows(summary["combo_summary"], Path(args.save_dir) / "combo_summary.csv")
    save_rows(summary["holdout_rows"], Path(args.save_dir) / "holdout_rows.csv")
    save_json(summary, Path(args.save_dir) / "summary.json")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
