from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ADAPT_ROOT = ROOT / "neurips2026" / "AdaptCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ADAPT_ROOT) not in sys.path:
    sys.path.insert(0, str(ADAPT_ROOT))

import adaptcliplib  # noqa: E402
from adaptcliplib import TextualAdapter, VisualAdapter, fusion_fun  # noqa: E402
from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from region_descriptor_utils import (  # noqa: E402
    FEATURE_NAMES,
    extract_region_descriptor,
    iterate_components,
    rows_to_matrix,
    save_json,
    save_rows,
)
from tools.utils import get_transform  # noqa: E402


COMBOS = [
    ["peak", "area"],
    ["peak", "mean"],
    ["peak", "top10_mean"],
    ["peak", "fill_ratio"],
    ["peak", "compactness"],
    ["peak", "ring_contrast"],
    ["peak", "area", "fill_ratio"],
    ["peak", "mean", "area", "fill_ratio", "compactness", "ring_contrast"],
]


def build_dataset(root: str, image_size: int, dataset_name: str, mode: str, save_dir: str):
    preprocess, target_transform = get_transform(image_size=image_size)
    return Dataset(
        root=root,
        transform=preprocess,
        target_transform=target_transform,
        dataset_name=dataset_name,
        k_shots=0,
        save_dir=save_dir,
        mode=mode,
        seed=10,
    )


def build_model(device: str, checkpoint_path: str, image_size: int, n_ctx: int, vl_reduction: int, pretrained_model: str):
    model, _ = adaptcliplib.load(pretrained_model, device=device)
    model.visual.DAPM_replace(DPAM_layer=20)
    patch_size = 14
    input_dim = 768
    textual_learner = TextualAdapter(model.to("cpu"), image_size, n_ctx)
    visual_learner = VisualAdapter(image_size, patch_size, input_dim, vl_reduction)

    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    textual_learner.load_state_dict(checkpoint["textual_learner"])
    visual_learner.load_state_dict(checkpoint["visual_learner"])
    textual_learner.to(device)
    visual_learner.to(device)
    model.to(device)
    model.eval()
    textual_learner.eval()
    visual_learner.eval()
    textual_learner.prepare_static_text_feature(model)
    prompt_text, token_text = textual_learner.forward()
    learned_text_features = model.encode_text_learn(prompt_text, token_text, None)
    learned_text_features = learned_text_features / learned_text_features.norm(dim=-1, keepdim=True)
    return model, textual_learner, visual_learner, learned_text_features


def compute_map(model, textual_learner, visual_learner, learned_text_features, image: torch.Tensor, features_list: list[int], sigma: int):
    query_feats, query_patch_feats = model.encode_image(image, features_list, DPAM_layer=20)
    _, local_vl_map = visual_learner(query_feats, query_patch_feats, textual_learner.static_text_features)
    local_vl_map = local_vl_map[:, 1].detach()
    _, local_tl_map = textual_learner.compute_global_local_score(query_feats, query_patch_feats, learned_text_features)
    local_tl_map = local_tl_map[:, 1].detach()
    pixel_anomaly_map = fusion_fun([local_vl_map, local_tl_map], fusion_type="average_mean")
    pixel_anomaly_map = torch.stack(
        [torch.from_numpy(gaussian_filter(i, sigma=sigma)) for i in pixel_anomaly_map.cpu()],
        dim=0,
    )
    return pixel_anomaly_map[0].numpy()


def collect_fp_rows(
    model,
    textual_learner,
    visual_learner,
    learned_text_features,
    data_root: str,
    image_size: int,
    features_list: list[int],
    sigma: int,
    device: str,
    top_fracs: list[float],
    min_area: int,
    max_per_class: int,
    save_dir: str,
):
    dataset = build_dataset(data_root, image_size, "mvtec", "train", save_dir)
    per_class = {cls_name: 0 for cls_name in dataset.cls_names}
    rows = []
    with torch.no_grad():
        for img_idx in range(len(dataset)):
            item = dataset[img_idx]
            cls_name = item["cls_name"]
            if per_class[cls_name] >= max_per_class:
                continue
            per_class[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            anomaly_map = compute_map(model, textual_learner, visual_learner, learned_text_features, image, features_list, sigma)
            for frac in top_fracs:
                mask = top_fraction_mask(anomaly_map, frac)
                for comp in iterate_components(mask):
                    if int(comp.sum()) < min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    desc.update({"bank": "fp", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": frac})
                    rows.append(desc)
            if (img_idx + 1) % 50 == 0:
                print(json.dumps({"stage": "fp_bank_progress", "img_idx": img_idx + 1, "num_regions": len(rows)}), flush=True)
    return rows


def collect_defect_rows(
    model,
    textual_learner,
    visual_learner,
    learned_text_features,
    data_root: str,
    image_size: int,
    features_list: list[int],
    sigma: int,
    device: str,
    min_area: int,
    max_images_per_class: int,
    save_dir: str,
):
    dataset = build_dataset(data_root, image_size, "mvtec", "test", save_dir)
    per_class = {cls_name: 0 for cls_name in dataset.cls_names}
    rows = []
    with torch.no_grad():
        for img_idx in range(len(dataset)):
            item = dataset[img_idx]
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            if int(anomaly_flag) == 0:
                continue
            cls_name = item["cls_name"]
            if per_class[cls_name] >= max_images_per_class:
                continue
            per_class[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"][0].numpy() > 0.5
            anomaly_map = compute_map(model, textual_learner, visual_learner, learned_text_features, image, features_list, sigma)
            for comp in iterate_components(gt_mask):
                if int(comp.sum()) < min_area:
                    continue
                desc = extract_region_descriptor(anomaly_map, comp)
                if not desc:
                    continue
                desc.update({"bank": "defect", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": -1.0})
                rows.append(desc)
            if (img_idx + 1) % 50 == 0:
                print(json.dumps({"stage": "defect_bank_progress", "img_idx": img_idx + 1, "num_regions": len(rows)}), flush=True)
    return rows


def compute_holdout_summary(fp_rows: list[dict], defect_rows: list[dict]):
    classes = sorted(set(row["cls_name"] for row in fp_rows) & set(row["cls_name"] for row in defect_rows))
    name_to_idx = {name: i for i, name in enumerate(FEATURE_NAMES)}
    holdout_rows = []

    for heldout in classes:
        fp_train = [row for row in fp_rows if row["cls_name"] != heldout]
        df_train = [row for row in defect_rows if row["cls_name"] != heldout]
        fp_eval = [row for row in fp_rows if row["cls_name"] == heldout]
        df_eval = [row for row in defect_rows if row["cls_name"] == heldout]
        if not fp_train or not df_train or not fp_eval or not df_eval:
            continue

        X_train = np.concatenate([rows_to_matrix(fp_train, FEATURE_NAMES), rows_to_matrix(df_train, FEATURE_NAMES)], axis=0)
        y_train = np.concatenate([np.zeros(len(fp_train), dtype=np.int64), np.ones(len(df_train), dtype=np.int64)], axis=0)
        X_eval = np.concatenate([rows_to_matrix(fp_eval, FEATURE_NAMES), rows_to_matrix(df_eval, FEATURE_NAMES)], axis=0)
        y_eval = np.concatenate([np.zeros(len(fp_eval), dtype=np.int64), np.ones(len(df_eval), dtype=np.int64)], axis=0)

        for feat_idx, feature_name in enumerate(FEATURE_NAMES):
            auc = roc_auc_score(y_eval, X_eval[:, feat_idx])
            eff_auc = max(float(auc), float(1.0 - auc))
            direction = "defect_high" if auc >= 0.5 else "fp_high"
            holdout_rows.append(
                {
                    "heldout_class": heldout,
                    "kind": "single",
                    "name": feature_name,
                    "auc_eval": eff_auc,
                    "direction": direction,
                    "num_train_fp": len(fp_train),
                    "num_train_defect": len(df_train),
                    "num_eval_fp": len(fp_eval),
                    "num_eval_defect": len(df_eval),
                }
            )

        for combo in COMBOS:
            idxs = [name_to_idx[c] for c in combo]
            clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
            clf.fit(X_train[:, idxs], y_train)
            pred = clf.predict_proba(X_eval[:, idxs])[:, 1]
            auc = roc_auc_score(y_eval, pred)
            holdout_rows.append(
                {
                    "heldout_class": heldout,
                    "kind": "combo",
                    "name": "+".join(combo),
                    "auc_eval": float(auc),
                    "direction": "defect_high",
                    "num_train_fp": len(fp_train),
                    "num_train_defect": len(df_train),
                    "num_eval_fp": len(fp_eval),
                    "num_eval_defect": len(df_eval),
                }
            )

    def aggregate(rows: list[dict]):
        grouped: dict[str, list[float]] = {}
        for row in rows:
            grouped.setdefault(row["name"], []).append(float(row["auc_eval"]))
        summary_rows = []
        for name, vals in grouped.items():
            summary_rows.append(
                {
                    "name": name,
                    "mean_auc": float(np.mean(vals)),
                    "std_auc": float(np.std(vals)),
                    "num_holdouts": len(vals),
                }
            )
        summary_rows.sort(key=lambda x: x["mean_auc"], reverse=True)
        return summary_rows

    single_rows = [row for row in holdout_rows if row["kind"] == "single"]
    combo_rows = [row for row in holdout_rows if row["kind"] == "combo"]
    return {
        "num_fp_regions": len(fp_rows),
        "num_defect_regions": len(defect_rows),
        "single_summary": aggregate(single_rows),
        "combo_summary": aggregate(combo_rows),
        "holdout_rows": holdout_rows,
    }


def main():
    parser = argparse.ArgumentParser("Build AdaptCLIP source region banks and leave-one-class-out descriptor sanity")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_official_vitl336_mvtec2visa_seed10" / "checkpoints" / "epoch_15.pth"),
    )
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--top_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--max_per_class_fp", type=int, default=200)
    parser.add_argument("--max_per_class_defect", type=int, default=80)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_region_bank_holdout_epoch15"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    model, textual_learner, visual_learner, learned_text_features = build_model(
        args.device, args.checkpoint_path, args.image_size, args.n_ctx, args.vl_reduction, args.pretrained_model
    )
    fp_rows = collect_fp_rows(
        model,
        textual_learner,
        visual_learner,
        learned_text_features,
        args.source_root,
        args.image_size,
        args.features_list,
        args.sigma,
        args.device,
        args.top_fracs,
        args.min_area,
        args.max_per_class_fp,
        args.save_dir,
    )
    save_rows(fp_rows, Path(args.save_dir) / "fp_rows.csv")

    defect_rows = collect_defect_rows(
        model,
        textual_learner,
        visual_learner,
        learned_text_features,
        args.source_root,
        args.image_size,
        args.features_list,
        args.sigma,
        args.device,
        args.min_area,
        args.max_per_class_defect,
        args.save_dir,
    )
    save_rows(defect_rows, Path(args.save_dir) / "defect_rows.csv")

    summary = compute_holdout_summary(fp_rows, defect_rows)
    save_rows(summary["single_summary"], Path(args.save_dir) / "single_summary.csv")
    save_rows(summary["combo_summary"], Path(args.save_dir) / "combo_summary.csv")
    save_rows(summary["holdout_rows"], Path(args.save_dir) / "holdout_rows.csv")
    save_json(summary, Path(args.save_dir) / "summary.json")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
