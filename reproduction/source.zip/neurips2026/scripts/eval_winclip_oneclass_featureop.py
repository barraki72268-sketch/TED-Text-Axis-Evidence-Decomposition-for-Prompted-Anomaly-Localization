from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import open_clip
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from WinCLIP import WinClipAD  # noqa: E402
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts  # noqa: E402
from neurips2026.learned_refiner import AlphaSpaceKinematicRefiner  # noqa: E402
from neurips2026.winclip_adapters import (  # noqa: E402
    LearnedRefinerWindowVisualWrapper,
    MultiLearnedRefinerWindowVisualWrapper,
    OfficialVisAWinClipDataset,
    NonDestructiveResidualVisualWrapper,
    RawBackboneCascadeToWindowVisualWrapper,
)
from utils.eval_utils import specify_resolution  # noqa: E402
from utils.metrics import metric_cal  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, required=True)
    parser.add_argument("--feature_ops", nargs="+", default=["identity", "residual_raw"])
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--k_shot", type=int, default=0)
    parser.add_argument("--cal_pro", action="store_true")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="winclip_featureop_oneclass")
    parser.add_argument("--refiner_ckpt", type=str, default="")
    parser.add_argument("--refiner_ckpts", nargs="*", default=[])
    return parser.parse_args()


def build_dataloader(dataset_root: str, split_csv: str, class_name: str, split: str, batch_size: int) -> DataLoader:
    ds = OfficialVisAWinClipDataset(dataset_root, split_csv, class_name, split)
    return DataLoader(ds, batch_size=batch_size, shuffle=(split == "train"), num_workers=0)


def build_winclip_prompt_token_basis(model: WinClipAD, class_name: str) -> torch.Tensor:
    prompts = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))

    tokens = model.tokenizer(prompts).to(model.device)
    with torch.no_grad():
        text_features = model.encode_text(tokens).float()
    text_features = F.normalize(text_features, dim=-1)
    q_text, _ = torch.linalg.qr(text_features.T, mode="reduced")

    visual = model.model.visual
    proj = getattr(visual, "proj", None)
    if proj is None:
        q_token = q_text
    else:
        token_basis = proj.float().to(text_features.device) @ q_text
        q_token, _ = torch.linalg.qr(token_basis, mode="reduced")
    return q_token.cpu()


def load_refiner_checkpoint(
    ckpt_path: str,
    feature_dim: int,
    device: str,
) -> tuple[AlphaSpaceKinematicRefiner, int]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload.get("refiner_config", {})
    target_layer = int(payload.get("target_layer", config.get("target_layer", 12)))
    refiner = AlphaSpaceKinematicRefiner(
        feature_dim=feature_dim,
        kernel_size=int(config.get("kernel_size", 3)),
        topk_ratio=float(config.get("topk_ratio", 0.1)),
        hidden_dim=int(config.get("hidden_dim", 64)),
        dropout=float(config.get("dropout", 0.0)),
        basis_rank=int(config.get("basis_rank", 4)),
        gate_temperature=float(config.get("gate_temperature", 0.25)),
    ).to(device)
    state_dict = payload.get("model_state_dict", payload)
    refiner.load_state_dict(state_dict, strict=True)
    refiner.eval()
    return refiner, target_layer


def load_refiner_checkpoints(
    ckpt_paths: list[str],
    feature_dim: int,
    device: str,
) -> dict[int, AlphaSpaceKinematicRefiner]:
    refiners: dict[int, AlphaSpaceKinematicRefiner] = {}
    for ckpt_path in ckpt_paths:
        refiner, target_layer = load_refiner_checkpoint(ckpt_path, feature_dim=feature_dim, device=device)
        if target_layer in refiners:
            raise ValueError(f"Duplicate target_layer={target_layer} in --refiner_ckpts")
        refiners[target_layer] = refiner
    if not refiners:
        raise ValueError("--refiner_ckpts did not produce any refiner")
    return refiners


def load_multiseam_refiner_checkpoint(
    ckpt_path: str,
    feature_dim: int,
    device: str,
) -> dict[int, AlphaSpaceKinematicRefiner]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload.get("refiner_config", {})
    target_layers = payload.get("target_layers", config.get("target_layers"))
    if not target_layers:
        raise ValueError(f"{ckpt_path} does not contain target_layers for multiseam loading")
    state_dict = payload.get("model_state_dict", payload)
    refiners: dict[int, AlphaSpaceKinematicRefiner] = {}
    for layer in [int(x) for x in target_layers]:
        prefix = f"refiners.{layer}."
        layer_state = {
            key[len(prefix):]: value
            for key, value in state_dict.items()
            if key.startswith(prefix)
        }
        if not layer_state:
            raise ValueError(f"No state for layer {layer} in multiseam checkpoint {ckpt_path}")
        refiner = AlphaSpaceKinematicRefiner(
            feature_dim=feature_dim,
            kernel_size=int(config.get("kernel_size", 3)),
            topk_ratio=float(config.get("topk_ratio", 0.1)),
            hidden_dim=int(config.get("hidden_dim", 64)),
            dropout=float(config.get("dropout", 0.0)),
            basis_rank=int(config.get("basis_rank", 4)),
            gate_temperature=float(config.get("gate_temperature", 0.25)),
        ).to(device)
        refiner.load_state_dict(layer_state, strict=True)
        refiner.eval()
        refiners[layer] = refiner
    return refiners


def maybe_wrap_feature_op(model: WinClipAD, feature_op: str, args: argparse.Namespace) -> None:
    if feature_op == "identity":
        return
    if feature_op == "residual_raw":
        model.model.visual = NonDestructiveResidualVisualWrapper(model.model.visual)
        model.masks = model.model.visual.masks
        model.scale_begin_indx = model.model.visual.scale_begin_indx
        model.grid_size = model.model.visual.grid_size
        return
    if feature_op == "learned_refiner":
        if args.refiner_ckpts:
            refiners_by_layer = load_refiner_checkpoints(
                args.refiner_ckpts,
                feature_dim=model.model.visual.proj.shape[0],
                device=model.device,
            )
            model.model.visual = MultiLearnedRefinerWindowVisualWrapper(
                model.model.visual,
                refiners_by_layer=refiners_by_layer,
            )
        else:
            if not args.refiner_ckpt:
                raise ValueError("Either --refiner_ckpt or --refiner_ckpts is required for feature_op=learned_refiner")
            payload = torch.load(args.refiner_ckpt, map_location="cpu")
            config = payload.get("refiner_config", {})
            target_layers = payload.get("target_layers", config.get("target_layers"))
            state_dict = payload.get("model_state_dict", payload)
            has_multiseam_state = any(str(key).startswith("refiners.") for key in state_dict.keys())
            if target_layers and (len(target_layers) > 1 or has_multiseam_state):
                refiners_by_layer = load_multiseam_refiner_checkpoint(
                    args.refiner_ckpt,
                    feature_dim=model.model.visual.proj.shape[0],
                    device=model.device,
                )
                route = payload.get("route", config.get("route", "window"))
                if route == "raw_backbone":
                    model.model.visual = RawBackboneCascadeToWindowVisualWrapper(
                        model.model.visual,
                        refiners_by_layer=refiners_by_layer,
                    )
                else:
                    model.model.visual = MultiLearnedRefinerWindowVisualWrapper(
                        model.model.visual,
                        refiners_by_layer=refiners_by_layer,
                    )
            else:
                refiner, target_layer = load_refiner_checkpoint(
                    args.refiner_ckpt,
                    feature_dim=model.model.visual.proj.shape[0],
                    device=model.device,
                )
                route = payload.get("route", config.get("route", "window"))
                if route == "raw_backbone":
                    model.model.visual = RawBackboneCascadeToWindowVisualWrapper(
                        model.model.visual,
                        refiners_by_layer={target_layer: refiner},
                    )
                else:
                    model.model.visual = LearnedRefinerWindowVisualWrapper(
                        model.model.visual,
                        refiner=refiner,
                        target_layer=target_layer,
                    )
        token_basis = build_winclip_prompt_token_basis(model, args.class_name)
        model.model.visual.set_semantic_basis(token_basis)
        model.masks = model.model.visual.masks
        model.scale_begin_indx = model.model.visual.scale_begin_indx
        model.grid_size = model.model.visual.grid_size
        return
    raise ValueError(f"Unsupported feature_op: {feature_op}. Supported: identity, residual_raw, learned_refiner")


def run_eval(args: argparse.Namespace) -> list[dict]:
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    test_loader = build_dataloader(args.dataset_root, args.split_csv, args.class_name, "test", args.batch_size)
    train_loader = None
    if args.k_shot > 0:
        train_loader = build_dataloader(args.dataset_root, args.split_csv, args.class_name, "train", args.batch_size)

    rows: list[dict] = []
    for feature_op in args.feature_ops:
        model = WinClipAD(
            out_size_h=args.resolution,
            out_size_w=args.resolution,
            device=device,
            backbone=args.backbone,
            pretrained_dataset=args.pretrained_dataset,
            scales=tuple(args.scales),
            img_resize=args.img_resize,
            img_cropsize=args.img_cropsize,
        ).to(device)
        model.eval_mode()
        model.build_text_feature_gallery(args.class_name)
        maybe_wrap_feature_op(model, feature_op, args)
        if train_loader is not None:
            for data, *_ in train_loader:
                data = [model.transform(Image.fromarray(f.numpy())) for f in data]
                data = torch.stack(data, dim=0).to(device)
                model.build_image_feature_gallery(data)

        scores = []
        test_imgs = []
        gt_list = []
        gt_mask_list = []
        for data, mask, label, name, img_type in test_loader:
            for f in data:
                test_imgs.append(f.numpy())
            data = [model.transform(Image.fromarray(f.numpy())) for f in data]
            data = torch.stack(data, dim=0).to(device)
            score = model(data)
            score_batch = []
            for s in score:
                if isinstance(s, np.ndarray):
                    score_batch.append(np.asarray(s).squeeze())
                else:
                    score_batch.append(s.squeeze().detach().cpu().numpy())
            scores += score_batch
            for l, m in zip(label, mask):
                gt_list.append(int(l.numpy() if hasattr(l, "numpy") else l))
                gt_mask_list.append((m.numpy() > 0).astype(np.uint8))

        test_imgs, scores, gt_mask_list = specify_resolution(
            test_imgs, scores, gt_mask_list, resolution=(args.resolution, args.resolution)
        )
        metrics = metric_cal(np.array(scores), gt_list, gt_mask_list, cal_pro=args.cal_pro)
        rows.append(
            {
                "class_name": args.class_name,
                "feature_op": feature_op,
                "backbone": args.backbone,
                "pretrained_dataset": args.pretrained_dataset,
                "resolution": args.resolution,
                "img_resize": args.img_resize,
                "img_cropsize": args.img_cropsize,
                "k_shot": args.k_shot,
                "i_roc": float(metrics["i_roc"]),
                "p_roc": float(metrics["p_roc"]),
                "p_pro": float(metrics["p_pro"]),
                "i_f1": float(metrics["i_f1"]),
                "p_f1": float(metrics["p_f1"]),
                "r_f1": float(metrics["r_f1"]),
            }
        )
    return rows


def write_outputs(rows: list[dict], output_dir: Path, output_tag: str, class_name: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / f"{output_tag}_{class_name}_summary.csv"
    json_path = output_dir / f"{output_tag}_{class_name}_summary.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(rows, f, indent=2)


def main() -> None:
    args = parse_args()
    rows = run_eval(args)
    write_outputs(rows, Path(args.output_dir), args.output_tag, args.class_name)
    for row in rows:
        print(
            f"{row['class_name']} | {row['feature_op']} | "
            f"I-ROC={row['i_roc']:.2f} | P-ROC={row['p_roc']:.2f} | P-PRO={row['p_pro']:.2f}"
        )


if __name__ == "__main__":
    main()
