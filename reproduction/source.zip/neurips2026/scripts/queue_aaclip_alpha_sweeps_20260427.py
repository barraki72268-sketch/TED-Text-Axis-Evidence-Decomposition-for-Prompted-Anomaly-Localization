#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = "/mnt/data/envs/patchcore-conda/bin/python"


def run(cmd: list[str], save_dir: Path) -> None:
    if (save_dir / "summary.json").exists():
        print(f"[skip] {save_dir}", flush=True)
        return
    print(f"[run] {save_dir}", flush=True)
    subprocess.run(cmd, cwd=str(ROOT), check=True)


def main() -> None:
    vitl_alphas = "-0.2,-0.1,-0.05,-0.02,-0.01,0.005,0.01,0.02,0.05,0.1,0.2"
    vitl_jobs = [
        ("visa2mvtec", "cuda:0"),
        ("mvtec2visa", "cuda:0"),
        ("visa2mpdd", "cuda:0"),
        ("visa2btad", "cuda:0"),
    ]
    for preset, device in vitl_jobs:
        save_dir = ROOT / "neurips2026" / "results" / f"aaclip_vitl_openai_{preset}_alpha_wide_map_topk_pro_20260427"
        cmd = [
            PY,
            "-u",
            "neurips2026/scripts/official_parallel_test_aaclip.py",
            "--preset",
            preset,
            "--model_name",
            "ViT-L-14-336",
            "--pretrained",
            "openai",
            "--adapter_load_mode",
            "strict",
            "--levels",
            "6,12,18,24",
            "--img_size",
            "224",
            "--batch_size",
            "8",
            "--num_workers",
            "4",
            "--max_fp_per_class",
            "512",
            "--max_defect_per_class",
            "512",
            "--normal_topk_frac",
            "0.01",
            "--defect_topk_frac",
            "0.25",
            "--tau",
            "0.1",
            "--fp_weight",
            "1.0",
            f"--alphas={vitl_alphas}",
            "--blend_modes",
            "prescore_rectify",
            "--candidate_topk_frac",
            "0.10",
            "--gate_sharpness",
            "3.0",
            "--candidate_image_mode",
            "map_topk",
            "--cal_pro",
            "--aupro_max_step",
            "50",
            "--device",
            device,
            "--save_dir",
            str(save_dir),
        ]
        run(cmd, save_dir)

    dino_save_dir = ROOT / "neurips2026" / "results" / "aaclip_dinov2base_bridge_visa2mpdd_img224_src64_alpha_wide_map_topk_pro_20260427"
    dino_cmd = [
        PY,
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip_dinov2_bridge.py",
        "--preset",
        "visa2mpdd",
        "--dino_backbone",
        "dinov2-base",
        "--dino_layers",
        "6,12",
        "--model_name",
        "ViT-B-16-plus-240",
        "--pretrained",
        "laion400m_e32",
        "--adapter_load_mode",
        "project_crop",
        "--aa_levels",
        "6,12",
        "--image_size",
        "224",
        "--batch_size",
        "1",
        "--fit_max_per_class",
        "2",
        "--fit_max_patches_per_image",
        "128",
        "--max_fp_per_class",
        "256",
        "--max_defect_per_class",
        "256",
        "--source_limit_per_class",
        "64",
        "--target_limit_per_class",
        "0",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--support_tau",
        "0.1",
        "--gate_sharpness",
        "3.0",
        "--fp_weight",
        "1.0",
        "--alphas=-1.0,-0.75,-0.5,-0.25,-0.1,0.05,0.1,0.25,0.5,0.75,1.0",
        "--image_score_topk",
        "0.10",
        "--aupro_max_step",
        "50",
        "--device",
        "cuda:1",
        "--save_dir",
        str(dino_save_dir),
    ]
    run(dino_cmd, dino_save_dir)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        sys.exit(exc.returncode)
