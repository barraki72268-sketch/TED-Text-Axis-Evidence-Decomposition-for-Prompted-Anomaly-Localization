from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"
INPUT_JSON = RESULTS / "quick_host_survey_20260425.json"
OUT_DIR = RESULTS / "host_entanglement_correction_figure"

HOST_ORDER = ["AnomalyCLIP", "AdaptCLIP", "AdaCLIP", "FAPrompt", "BayesPFL"]
COLORS = {
    "AnomalyCLIP": "#24455C",
    "AdaptCLIP": "#2A7F62",
    "AdaCLIP": "#C06C2B",
    "FAPrompt": "#B0433A",
    "BayesPFL": "#7A5EA8",
}


def load_rows() -> list[dict]:
    with INPUT_JSON.open("r") as f:
        report = json.load(f)["AD_host_map_separability"]
    rows = []
    for host in HOST_ORDER:
        row = report[host]
        rows.append(
            {
                "host": host,
                "baseline_auc": row["baseline_true_vs_hardfp_auc"],
                "matched_auc": row["matched_true_topk_vs_hardfp_topk_auc"],
                "baseline_gap": row["baseline_gap"],
                "matched_gap": row["matched_gap"],
            }
        )
    return rows


def add_slope_panel(ax, rows: list[dict], left_key: str, right_key: str, title: str, ylabel: str, ref: float | None = None) -> None:
    x0, x1 = 0.0, 1.0
    for row in rows:
        y0 = row[left_key]
        y1 = row[right_key]
        color = COLORS[row["host"]]
        ax.plot([x0, x1], [y0, y1], color=color, lw=2.2, alpha=0.95)
        ax.scatter([x0, x1], [y0, y1], color=color, s=48, zorder=3)
        ax.text(x0 - 0.06, y0, f"{y0:.3f}", ha="right", va="center", fontsize=9, color=color)
        ax.text(x1 + 0.06, y1, f"{y1:.3f}", ha="left", va="center", fontsize=9, color=color)
        ax.text(x1 + 0.21, y1, row["host"], ha="left", va="center", fontsize=10, color=color, fontweight="bold")

    ax.set_xlim(-0.18, 1.78)
    vals = [row[left_key] for row in rows] + [row[right_key] for row in rows]
    ymin = min(vals)
    ymax = max(vals)
    pad = max(0.04, 0.08 * (ymax - ymin if ymax > ymin else 1.0))
    ax.set_ylim(ymin - pad, ymax + pad)
    ax.set_xticks([x0, x1], ["Baseline", "OURS"])
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.grid(axis="y", alpha=0.22, linewidth=0.8)
    if ref is not None:
        ax.axhline(ref, color="#555555", linestyle="--", linewidth=1.1, alpha=0.8)


def main() -> None:
    rows = load_rows()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(12.8, 4.6), constrained_layout=True)

    add_slope_panel(
        axes[0],
        rows,
        "baseline_auc",
        "matched_auc",
        title="Hard-FP Separability",
        ylabel="AUC(True-Defect > Hard-FP)",
        ref=0.5,
    )
    add_slope_panel(
        axes[1],
        rows,
        "baseline_gap",
        "matched_gap",
        title="Score Gap",
        ylabel="Mean(True-Defect) - Mean(Hard-FP)",
        ref=0.0,
    )

    fig.suptitle(
        "Across Hosts, Baseline Maps Entangle True Defect and Hard False Positives,\n"
        "while Support-Based Re-ranking Consistently Widens the Separation",
        fontsize=14,
        fontweight="bold",
    )

    png_path = OUT_DIR / "host_entanglement_correction.png"
    pdf_path = OUT_DIR / "host_entanglement_correction.pdf"
    json_path = OUT_DIR / "host_entanglement_correction.json"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)

    out = {"rows": rows}
    json_path.write_text(json.dumps(out, indent=2))
    print(png_path)
    print(pdf_path)
    print(json_path)


if __name__ == "__main__":
    main()
