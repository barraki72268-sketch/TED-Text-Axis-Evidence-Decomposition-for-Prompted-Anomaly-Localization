#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_rawclip.py"
export MPLCONFIGDIR="/tmp/matplotlib-rawclip-vitb-gpu1"

CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" \
  --source_root "${ROOT}/neurips2026/data/VisA_pytorch_official/1cls" \
  --source_dataset visa \
  --target_root "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec" \
  --target_dataset mvtec \
  --save_dir "${ROOT}/neurips2026/results/official_parallel_test_rawclip_vitb_visa2mvtec_all" \
  --bank_cache_path "${ROOT}/neurips2026/results/bank_cache/rawclip_vitb_visa_multilayer.pt" \
  --backbone "ViT-B-16-plus-240" \
  --pretrained_dataset "laion400m_e32" \
  --image_size 240 \
  --prompt_mode class \
  --sigma 4 \
  --max_good_per_class 2 \
  --max_defect_per_class 4 \
  --max_bank_per_layer 512 \
  --max_fp_per_image 64 \
  --max_defect_per_image 64 \
  --device cuda:0
