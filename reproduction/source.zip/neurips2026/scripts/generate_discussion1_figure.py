from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"

HOST_TICK_LABELS = {
    "AnomalyCLIP": "Anomaly\nCLIP",
    "AdaptCLIP": "Adapt\nCLIP",
    "AdaCLIP": "Ada\nCLIP",
    "FAPrompt": "FAPrompt",
    "AA-CLIP": "AA-CLIP",
    "Bayes-PFL": "Bayes-PFL",
}


def load_host_competition(exclude_hosts: set[str] | None = None):
    path = RESULTS / "map_separability_dashboard_matched" / "matched_summary.csv"
    with path.open() as f:
        rows = list(csv.DictReader(f))
    if exclude_hosts:
        rows = [r for r in rows if r["host"] not in exclude_hosts]
    hosts = [r["host"] for r in rows]
    auc_hfp = [float(r["auc_true_defect_topk_vs_hard_fp_topk"]) for r in rows]
    auc_out = [float(r["auc_true_defect_topk_vs_outside_topk"]) for r in rows]
    return hosts, auc_hfp, auc_out


def load_axis_summary(path: Path, label: str):
    rows = json.loads(path.read_text())["rows"]
    out = {"label": label}
    for r in rows:
        if r["axis"] == "learned" and r["component"] == "parallel":
            out["learned_parallel"] = float(r["inside_vs_outside_auc"])
        elif r["axis"] == "learned" and r["component"] == "perp":
            out["learned_perp"] = float(r["inside_vs_outside_auc"])
        elif r["axis"] == "static" and r["component"] == "parallel":
            out["static_parallel"] = float(r["inside_vs_outside_auc"])
    return out


def load_axis_results():
    return [
        load_axis_summary(
            RESULTS / "anomalyclip_text_axis_decomposition_epoch5_bottle_full_small" / "summary.json",
            "Bottle",
        ),
        load_axis_summary(
            RESULTS / "anomalyclip_text_axis_decomposition_mvtec2visa_pcb4_full" / "summary.json",
            "PCB4",
        ),
        load_axis_summary(
            RESULTS / "anomalyclip_text_axis_decomposition_mvtec2visa_macaroni2_full" / "summary.json",
            "Macaroni2",
        ),
    ]


def load_axis_datasetwise_row(path: Path, label: str):
    with path.open() as f:
        rows = list(csv.DictReader(f))
    out = {"label": label}
    for r in rows:
        if r["target_label"] != "all" or r["axis"] != "learned":
            continue
        if r["component"] == "parallel":
            out["learned_parallel"] = float(r["inside_vs_outside_auc"])
        elif r["component"] == "perp":
            out["learned_perp"] = float(r["inside_vs_outside_auc"])
    return out


def load_axis_datasetwise_results():
    return [
        load_axis_datasetwise_row(
            RESULTS / "anomalyclip_text_axis_decomposition_visa2mvtec_all_epoch15_discussion" / "metrics.csv",
            "MVTec",
        ),
        load_axis_datasetwise_row(
            RESULTS / "anomalyclip_text_axis_decomposition_mvtec2visa_all_epoch15_discussion" / "metrics.csv",
            "VisA",
        ),
        load_axis_datasetwise_row(
            RESULTS / "anomalyclip_text_axis_decomposition_mvtec2mpdd_epoch15_discussion" / "metrics.csv",
            "MPDD",
        ),
        load_axis_datasetwise_row(
            RESULTS / "anomalyclip_text_axis_decomposition_mvtec2btad_all_epoch15_discussion" / "metrics.csv",
            "BTAD",
        ),
    ]


def render_figure(out_dir: Path, suffix: str, exclude_hosts: set[str] | None = None):
    out_dir.mkdir(parents=True, exist_ok=True)

    cache_path = out_dir / f"discussion1_adaptation_axis_competition{suffix}.json"
    if cache_path.exists():
        cache = json.loads(cache_path.read_text())
        hosts = cache["panel_a"]["hosts"]
        auc_hfp = cache["panel_a"]["auc_defect_vs_hardfp"]
        auc_out = cache["panel_a"]["auc_defect_vs_outside"]
        axis_rows = cache["panel_b"]
    else:
        hosts, auc_hfp, auc_out = load_host_competition(exclude_hosts=exclude_hosts)
        axis_rows = load_axis_datasetwise_results()

    plt.rcParams.update(
        {
            "font.size": 22,
            "axes.titlesize": 28,
            "axes.labelsize": 26,
            "xtick.labelsize": 22,
            "ytick.labelsize": 22,
            "legend.fontsize": 21,
            "font.weight": "bold",
            "axes.titleweight": "bold",
            "axes.labelweight": "bold",
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(24.0, 5.35), constrained_layout=False)

    # Panel A: multi-host competition
    ax = axes[0]
    x = np.arange(len(hosts))
    w = 0.36
    ax.bar(
        x - w / 2,
        auc_hfp,
        width=w,
        color="#d55e00",
        edgecolor="black",
        linewidth=1.6,
        hatch="///",
        label="Defect vs Hard-FP",
    )
    ax.bar(
        x + w / 2,
        auc_out,
        width=w,
        color="#0072b2",
        edgecolor="black",
        linewidth=1.6,
        hatch="\\\\\\\\",
        label="Defect vs Outside",
    )
    ax.axhline(1.0, color="black", linewidth=1.2, linestyle="--", alpha=0.4)
    ax.axhline(0.5, color="black", linewidth=1.2, linestyle=":", alpha=0.4)
    ax.set_ylim(0.5, 1.02)
    ax.set_xticks(x)
    ax.set_xticklabels([HOST_TICK_LABELS.get(h, h) for h in hosts], rotation=0, ha="center", fontweight="bold")
    ax.set_ylabel("AUC")
    ax.legend(
        frameon=False,
        loc="upper left",
        bbox_to_anchor=(0.01, 0.98),
        handlelength=1.25,
        borderaxespad=0.0,
        labelspacing=0.28,
    )

    # Panel B: dataset-wise axis concentration
    ax = axes[1]
    labels = [r["label"] for r in axis_rows]
    x = np.arange(len(labels))
    w = 0.34
    lp = [r["learned_parallel"] for r in axis_rows]
    lperp = [r["learned_perp"] for r in axis_rows]
    ax.bar(
        x - w / 2,
        lp,
        width=w,
        color="#cc79a7",
        edgecolor="black",
        linewidth=1.6,
        hatch="///",
        label="Learned parallel",
    )
    ax.bar(
        x + w / 2,
        lperp,
        width=w,
        color="#56b4e9",
        edgecolor="black",
        linewidth=1.6,
        hatch="\\\\\\\\",
        label="Learned perp",
    )
    ax.set_ylim(0.65, 1.0)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontweight="bold")
    ax.set_ylabel("AUC")
    ax.legend(
        frameon=False,
        loc="upper left",
        bbox_to_anchor=(0.00, 1.18),
        ncol=2,
        handlelength=1.2,
        columnspacing=0.9,
        borderaxespad=0.0,
    )

    for xpos, val in zip(x - w / 2, lp):
        ax.text(xpos, val + 0.007, f"{val:.3f}", ha="center", va="bottom", fontsize=20, fontweight="bold")
    for xpos, val in zip(x + w / 2, lperp):
        ax.text(xpos, val + 0.007, f"{val:.3f}", ha="center", va="bottom", fontsize=20, fontweight="bold")

    png_path = out_dir / f"discussion1_adaptation_axis_competition{suffix}.png"
    pdf_path = out_dir / f"discussion1_adaptation_axis_competition{suffix}.pdf"
    fig.subplots_adjust(left=0.070, right=0.995, bottom=0.31, top=0.76, wspace=0.36)
    fig.savefig(png_path, dpi=220, bbox_inches="tight", pad_inches=0.08)
    fig.savefig(pdf_path, bbox_inches="tight", pad_inches=0.08)
    if suffix == "_main":
        fig_dir = ROOT / "figure"
        fig_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(fig_dir / "discussion1_adaptation_axis_competition_main.png", dpi=220, bbox_inches="tight", pad_inches=0.08)
        fig.savefig(fig_dir / "discussion1_adaptation_axis_competition_main.pdf", bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)

    panel_names = [
        "discussion1_spatial_competition",
        "discussion1_text_axis_signal",
    ]
    for panel_idx, panel_name in enumerate(panel_names):
        panel_fig, panel_ax = plt.subplots(figsize=(11.2, 5.35), constrained_layout=False)
        if panel_idx == 0:
            x = np.arange(len(hosts))
            w = 0.36
            panel_ax.bar(
                x - w / 2,
                auc_hfp,
                width=w,
                color="#d55e00",
                edgecolor="black",
                linewidth=1.6,
                hatch="///",
                label="Defect vs Hard-FP",
            )
            panel_ax.bar(
                x + w / 2,
                auc_out,
                width=w,
                color="#0072b2",
                edgecolor="black",
                linewidth=1.6,
                hatch="\\\\\\\\",
                label="Defect vs Outside",
            )
            panel_ax.axhline(1.0, color="black", linewidth=1.2, linestyle="--", alpha=0.4)
            panel_ax.axhline(0.5, color="black", linewidth=1.2, linestyle=":", alpha=0.4)
            panel_ax.set_ylim(0.5, 1.02)
            panel_ax.set_xticks(x)
            panel_ax.set_xticklabels([HOST_TICK_LABELS.get(h, h) for h in hosts], rotation=0, ha="center", fontweight="bold")
            panel_ax.set_ylabel("AUC")
            panel_ax.legend(
                frameon=False,
                loc="upper left",
                bbox_to_anchor=(0.01, 0.98),
                handlelength=1.25,
                borderaxespad=0.0,
                labelspacing=0.28,
            )
        else:
            labels = [r["label"] for r in axis_rows]
            x = np.arange(len(labels))
            w = 0.34
            lp = [r["learned_parallel"] for r in axis_rows]
            lperp = [r["learned_perp"] for r in axis_rows]
            panel_ax.bar(
                x - w / 2,
                lp,
                width=w,
                color="#cc79a7",
                edgecolor="black",
                linewidth=1.6,
                hatch="///",
                label="Learned parallel",
            )
            panel_ax.bar(
                x + w / 2,
                lperp,
                width=w,
                color="#56b4e9",
                edgecolor="black",
                linewidth=1.6,
                hatch="\\\\\\\\",
                label="Learned perp",
            )
            panel_ax.set_ylim(0.65, 1.0)
            panel_ax.set_xticks(x)
            panel_ax.set_xticklabels(labels, fontweight="bold")
            panel_ax.set_ylabel("AUC")
            panel_ax.legend(
                frameon=False,
                loc="upper left",
                bbox_to_anchor=(0.00, 1.18),
                ncol=2,
                handlelength=1.2,
                columnspacing=0.9,
                borderaxespad=0.0,
            )
            for xpos, val in zip(x - w / 2, lp):
                panel_ax.text(xpos, val + 0.007, f"{val:.3f}", ha="center", va="bottom", fontsize=20, fontweight="bold")
            for xpos, val in zip(x + w / 2, lperp):
                panel_ax.text(xpos, val + 0.007, f"{val:.3f}", ha="center", va="bottom", fontsize=20, fontweight="bold")

        panel_fig.subplots_adjust(left=0.13, right=0.99, bottom=0.31, top=0.76)
        panel_png = out_dir / f"{panel_name}{suffix}.png"
        panel_pdf = out_dir / f"{panel_name}{suffix}.pdf"
        panel_fig.savefig(panel_png, dpi=220, bbox_inches="tight", pad_inches=0.08)
        panel_fig.savefig(panel_pdf, bbox_inches="tight", pad_inches=0.08)
        if suffix == "_main":
            fig_dir = ROOT / "figure"
            panel_fig.savefig(fig_dir / f"{panel_name}_main.png", dpi=220, bbox_inches="tight", pad_inches=0.08)
            panel_fig.savefig(fig_dir / f"{panel_name}_main.pdf", bbox_inches="tight", pad_inches=0.08)
        plt.close(panel_fig)

    payload = {
        "exclude_hosts": sorted(exclude_hosts) if exclude_hosts else [],
        "panel_a": {
            "hosts": hosts,
            "auc_defect_vs_hardfp": auc_hfp,
            "auc_defect_vs_outside": auc_out,
        },
        "panel_b": axis_rows,
    }
    with open(out_dir / f"discussion1_adaptation_axis_competition{suffix}.json", "w") as f:
        json.dump(payload, f, indent=2)

    print(png_path)


def main():
    out_dir = RESULTS / "discussion_figure_1"
    render_figure(out_dir, suffix="_main", exclude_hosts={"Bayes-PFL"})
    render_figure(out_dir, suffix="_all", exclude_hosts=None)


if __name__ == "__main__":
    main()
