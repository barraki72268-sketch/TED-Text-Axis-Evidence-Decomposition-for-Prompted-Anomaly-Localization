from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")

if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from probe_anomalyclip_fp_text_decomposition import (  # noqa: E402
    build_model,
    get_learned_text_pair,
    load_prompt_learner,
)
from probe_anomalyclip_text_axis_decomposition import (  # noqa: E402
    decision_axis,
    load_source_patch_banks_cache,
    logmeanexp_negative_sqdist_1d,
    project_bank,
)
from probe_anomalyclip_wrongclass_semantic_collapse import (  # noqa: E402
    aggregate_map_from_patch_features,
    build_eval_dataset,
    build_reference_text_model,
    safe_auc,
    safe_corr,
    static_text_pair_for_class,
    top_fraction_mask,
)


def denormalize_image(img_tensor: torch.Tensor) -> np.ndarray:
    mean = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
    std = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
    img = np.transpose(img_tensor.cpu().numpy(), (1, 2, 0))
    img = np.clip((img * std + mean) * 255.0, 0, 255).astype(np.uint8)
    return img


def apply_score_overlay(image: np.ndarray, scoremap: np.ndarray, alpha: float = 0.52, colormap: int = cv2.COLORMAP_JET) -> np.ndarray:
    scoremap = np.clip(scoremap * 255.0, 0, 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, colormap)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return np.clip(alpha * image.astype(np.float32) + (1.0 - alpha) * scoremap.astype(np.float32), 0, 255).astype(np.uint8)


def overlay_binary_mask(image: np.ndarray, mask: np.ndarray, color=(255, 80, 40), alpha: float = 0.55) -> np.ndarray:
    out = image.astype(np.float32).copy()
    color_arr = np.array(color, dtype=np.float32)
    out[mask] = (1 - alpha) * out[mask] + alpha * color_arr
    return np.clip(out, 0, 255).astype(np.uint8)


def percentile_bounds(arr: np.ndarray, lo: float = 1.0, hi: float = 99.0) -> tuple[float, float]:
    lo_v = float(np.percentile(arr, lo))
    hi_v = float(np.percentile(arr, hi))
    if hi_v <= lo_v:
        lo_v = float(arr.min())
        hi_v = float(arr.max())
    return lo_v, hi_v


def normalize_map(arr: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    denom = max(vmax - vmin, 1e-8)
    return np.clip((arr - vmin) / denom, 0.0, 1.0)


def normalize_abs_map(arr: np.ndarray, q: float = 99.0) -> np.ndarray:
    bound = max(float(np.percentile(np.abs(arr), q)), 1e-8)
    return np.clip(np.abs(arr) / bound, 0.0, 1.0)


def symmetric_bound(arrays: list[np.ndarray], q: float = 99.0) -> float:
    flat = np.concatenate([arr.reshape(-1) for arr in arrays], axis=0)
    return max(float(np.percentile(np.abs(flat), q)), 1e-8)


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def pick_anomaly_sample(dataset, cls_name: str, sample_index: int):
    matches = []
    for idx in range(len(dataset)):
        item = dataset[idx]
        if item["cls_name"] != cls_name:
            continue
        anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
        if anomaly_flag == 0:
            continue
        matches.append(item)
    if sample_index >= len(matches):
        raise IndexError(f"sample_index={sample_index} out of range for {len(matches)} anomaly images of class={cls_name}")
    return matches[sample_index]


def compute_parallel_map(
    patch_features: list[torch.Tensor],
    axis: torch.Tensor,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    image_size: int,
    sigma: float,
    tau: float,
) -> np.ndarray:
    layers = []
    for layer_idx, patch_feature in enumerate(patch_features):
        patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
        coeff = patch @ axis
        fp_coeff, _ = project_bank(fp_banks[layer_idx].to(axis.device), axis)
        def_coeff, _ = project_bank(def_banks[layer_idx].to(axis.device), axis)
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=tau)
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=tau)
        h = int(round(patch.shape[0] ** 0.5))
        margin = F.interpolate(
            (q_def - q_fp).reshape(1, 1, h, h),
            size=(image_size, image_size),
            mode="bilinear",
            align_corners=False,
        )[0, 0]
        layers.append(margin.detach().cpu().numpy())
    return gaussian_filter(np.mean(np.stack(layers, axis=0), axis=0), sigma=sigma)


def resolve_target_root(target_dataset: str) -> str:
    if target_dataset == "visa":
        return str(OFFICIAL_VISA_ROOT)
    if target_dataset == "mvtec":
        return str(MVTEC_ROOT)
    raise ValueError(f"Unsupported target_dataset={target_dataset}")


def main():
    parser = argparse.ArgumentParser("Generate prompt-swap refinement figure for AnomalyCLIP")
    parser.add_argument("--dashboard_json", type=str, required=True)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--save_dir", type=str, required=True)
    args = parser.parse_args()

    with open(args.dashboard_json, "r") as f:
        cfg = json.load(f)
    bank_meta = cfg["bank_cache_meta"]
    checkpoint_path = bank_meta["checkpoint_path"]
    features_list = bank_meta["features_list"]
    image_size = int(bank_meta["image_size"])
    bank_cache_path = cfg["bank_cache_path"]
    target_dataset = cfg["target_dataset"]
    target_class = cfg["cls_name"]
    sample_index = int(cfg["sample_index"])

    target_root = resolve_target_root(target_dataset)
    dataset = build_eval_dataset(target_root, target_dataset, image_size, mode="test")
    item = pick_anomaly_sample(dataset, target_class, sample_index)

    model, params = build_model(args.device, 9, 12, 4)
    learner = load_prompt_learner(model, params, Path(checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    reference_model = build_reference_text_model(args.device)
    fp_banks, def_banks, bank_stats, cache_meta = load_source_patch_banks_cache(Path(bank_cache_path))

    image = item["img"].unsqueeze(0).to(args.device)
    gt_mask = item["img_mask"].squeeze().detach().cpu().numpy() > 0.5
    input_img = denormalize_image(item["img"])

    with torch.inference_mode():
        _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
        learned_map = aggregate_map_from_patch_features(patch_features, learned_pair, image_size, args.sigma)
        true_pair = static_text_pair_for_class(reference_model, target_class, args.device)
        true_baseline = aggregate_map_from_patch_features(patch_features, true_pair, image_size, args.sigma)

        wrong_candidates = []
        for prompt_cls in dataset.obj_list:
            if prompt_cls == target_class:
                continue
            text_pair = static_text_pair_for_class(reference_model, prompt_cls, args.device)
            score_map = aggregate_map_from_patch_features(patch_features, text_pair, image_size, args.sigma)
            wrong_candidates.append(
                {
                    "class": prompt_cls,
                    "map": score_map,
                    "auc": safe_auc(score_map[gt_mask], score_map[~gt_mask]),
                }
            )
        wrong_candidates.sort(key=lambda row: row["auc"], reverse=True)
        wrong = wrong_candidates[0]
        wrong_cls = wrong["class"]
        wrong_baseline = wrong["map"]

        true_axis = decision_axis(true_pair).to(args.device)
        wrong_pair = static_text_pair_for_class(reference_model, wrong_cls, args.device)
        wrong_axis = decision_axis(wrong_pair).to(args.device)
        true_ours = compute_parallel_map(patch_features, true_axis, fp_banks, def_banks, image_size, args.sigma, args.tau)
        wrong_ours = compute_parallel_map(patch_features, wrong_axis, fp_banks, def_banks, image_size, args.sigma, args.tau)

    learned_auc = safe_auc(learned_map[gt_mask], learned_map[~gt_mask])
    true_baseline_auc = safe_auc(true_baseline[gt_mask], true_baseline[~gt_mask])
    wrong_baseline_auc = safe_auc(wrong_baseline[gt_mask], wrong_baseline[~gt_mask])
    true_ours_auc = safe_auc(true_ours[gt_mask], true_ours[~gt_mask])
    wrong_ours_auc = safe_auc(wrong_ours[gt_mask], wrong_ours[~gt_mask])

    baseline_true_mask = top_fraction_mask(true_baseline, args.map_topk)
    baseline_wrong_mask = top_fraction_mask(wrong_baseline, args.map_topk)
    ours_true_mask = top_fraction_mask(true_ours, args.map_topk)
    ours_wrong_mask = top_fraction_mask(wrong_ours, args.map_topk)

    baseline_corr = safe_corr(true_baseline, wrong_baseline)
    baseline_overlap = mask_overlap(baseline_true_mask, baseline_wrong_mask)
    ours_corr = safe_corr(true_ours, wrong_ours)
    ours_overlap = mask_overlap(ours_true_mask, ours_wrong_mask)

    baseline_vmin, baseline_vmax = percentile_bounds(
        np.concatenate(
            [
                learned_map.reshape(-1),
                true_baseline.reshape(-1),
                wrong_baseline.reshape(-1),
            ]
        )
    )
    ours_bound = symmetric_bound([true_ours, wrong_ours], q=99.0)

    panels = {
        "input": input_img,
        "gt": overlay_binary_mask(input_img, gt_mask),
        "learned": apply_score_overlay(input_img, normalize_map(learned_map, baseline_vmin, baseline_vmax)),
        "baseline_true": apply_score_overlay(input_img, normalize_map(true_baseline, baseline_vmin, baseline_vmax)),
        "baseline_wrong": apply_score_overlay(input_img, normalize_map(wrong_baseline, baseline_vmin, baseline_vmax)),
        "ours_true": true_ours,
        "ours_wrong": wrong_ours,
        "baseline_delta": normalize_abs_map(true_baseline - wrong_baseline),
        "ours_delta": normalize_abs_map(true_ours - wrong_ours),
    }

    fig, axes = plt.subplots(2, 5, figsize=(18, 8), constrained_layout=True)
    layout = [
        ("input", "Input"),
        ("gt", "GT"),
        ("learned", f"Host Learned\nAUC={learned_auc:.3f}"),
        ("baseline_true", f"Baseline(True)\n{target_class}\nAUC={true_baseline_auc:.3f}"),
        ("baseline_wrong", f"Baseline(Wrong)\n{wrong_cls}\nAUC={wrong_baseline_auc:.3f}"),
        ("ours_true", f"OURS(True)\nparallel score\n{target_class}\nAUC={true_ours_auc:.3f}"),
        ("ours_wrong", f"OURS(Wrong)\nparallel score\n{wrong_cls}\nAUC={wrong_ours_auc:.3f}"),
        ("baseline_delta", f"|B true-wrong|\ncorr={baseline_corr:.3f}\noverlap={baseline_overlap:.3f}"),
        ("ours_delta", f"|O true-wrong|\ncorr={ours_corr:.3f}\noverlap={ours_overlap:.3f}"),
        ("input", ""),
    ]

    for ax, (key, title) in zip(axes.flatten(), layout):
        if key == "input" and title == "":
            ax.axis("off")
            summary_lines = [
                f"wrong prompt: {wrong_cls}",
                f"baseline gap: {true_baseline_auc - wrong_baseline_auc:+.3f}",
                f"ours gap: {true_ours_auc - wrong_ours_auc:+.3f}",
                f"baseline corr / overlap: {baseline_corr:.3f} / {baseline_overlap:.3f}",
                f"ours corr / overlap: {ours_corr:.3f} / {ours_overlap:.3f}",
                f"bank cache: {Path(bank_cache_path).name}",
            ]
            ax.text(0.02, 0.95, "\n".join(summary_lines), va="top", ha="left", fontsize=12, family="monospace")
            continue
        img = panels[key]
        if img.ndim == 2:
            if key in {"ours_true", "ours_wrong"}:
                ax.imshow(img, cmap="coolwarm", vmin=-ours_bound, vmax=ours_bound)
            else:
                ax.imshow(img, cmap="magma")
        else:
            ax.imshow(img)
        ax.set_title(title, fontsize=11)
        ax.axis("off")

    fig.suptitle(
        f"AnomalyCLIP prompt-swap refinement | class={target_class} | sample={Path(item['img_path']).name}",
        fontsize=14,
    )

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    png_path = save_dir / f"{target_class}_prompt_swap_refinement.png"
    pdf_path = save_dir / f"{target_class}_prompt_swap_refinement.pdf"
    fig.savefig(png_path, dpi=220)
    fig.savefig(pdf_path)
    plt.close(fig)

    payload = {
        "class_name": target_class,
        "img_path": item["img_path"],
        "sample_index": sample_index,
        "target_dataset": target_dataset,
        "target_root": target_root,
        "bank_cache_path": bank_cache_path,
        "bank_cache_meta": cache_meta,
        "bank_stats": bank_stats,
        "wrong_prompt": wrong_cls,
        "baseline": {
            "true_auc": true_baseline_auc,
            "wrong_auc": wrong_baseline_auc,
            "auc_gap": true_baseline_auc - wrong_baseline_auc,
            "corr": baseline_corr,
            "topk_overlap": baseline_overlap,
        },
        "ours": {
            "true_auc": true_ours_auc,
            "wrong_auc": wrong_ours_auc,
            "auc_gap": true_ours_auc - wrong_ours_auc,
            "corr": ours_corr,
            "topk_overlap": ours_overlap,
        },
        "learned_host_auc": learned_auc,
        "artifacts": {
            "png": str(png_path),
            "pdf": str(pdf_path),
        },
    }
    with open(save_dir / f"{target_class}_prompt_swap_refinement.json", "w") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
