#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_rawimagebind.py"
SOURCE_ROOT="${ROOT}/neurips2026/data/VisA_pytorch_official/1cls"
SOURCE_DATASET="visa"
TARGET_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
TARGET_DATASET="mvtec"
SAVE_DIR="${ROOT}/neurips2026/results/official_parallel_test_rawimagebind_visa2mvtec_all"
BANK_CACHE="${ROOT}/neurips2026/results/bank_cache/rawimagebind_visa_official1cls_class_exclude-none_all.pt"

export MPLCONFIGDIR="/tmp/matplotlib-rawimagebind-visa2mvtec"
CUDA_VISIBLE_DEVICES=1 "${PYTHON}" "${SCRIPT}" \
  --source_root "${SOURCE_ROOT}" \
  --source_dataset "${SOURCE_DATASET}" \
  --target_root "${TARGET_ROOT}" \
  --target_dataset "${TARGET_DATASET}" \
  --save_dir "${SAVE_DIR}" \
  --bank_cache_path "${BANK_CACHE}" \
  --prompt_mode class \
  --image_size 224 \
  --device cuda:0
