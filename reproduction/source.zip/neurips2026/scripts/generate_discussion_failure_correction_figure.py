from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026" / "results"

ANOMALY_CROSSHOST_JSON = RESULT_ROOT / "semantic_attenuation_crosshost_figure" / "semantic_attenuation_crosshost.json"

ADAPTCLIP_SUMMARIES = [
    RESULT_ROOT / "adaptclip_branch_dominance_visa2mvtec_x1_rerun1" / "summary.json",
    RESULT_ROOT / "adaptclip_branch_dominance_mvtec2visa_x1_rerun1" / "summary.json",
    RESULT_ROOT / "adaptclip_branch_dominance_mvtec2mpdd_x1_rerun1" / "summary.json",
    RESULT_ROOT / "adaptclip_branch_dominance_mvtec2btad_x1_rerun1" / "summary.json",
]

FAPROMPT_SUMMARIES = [
    RESULT_ROOT / "faprompt_prompt_diversity_visa2mvtec_x1_rerun1" / "summary.json",
    RESULT_ROOT / "faprompt_prompt_diversity_mvtec2visa_x1_rerun1" / "summary.json",
]

PROMPT_REFINEMENT_JSONS = [
    RESULT_ROOT / "anomalyclip_prompt_swap_refinement_macaroni2_v1" / "macaroni2_prompt_swap_refinement.json",
    RESULT_ROOT / "anomalyclip_prompt_swap_refinement_pcb4_v2" / "pcb4_prompt_swap_refinement.json",
    RESULT_ROOT / "anomalyclip_prompt_swap_refinement_fryum_v1" / "fryum_prompt_swap_refinement.json",
    RESULT_ROOT / "anomalyclip_prompt_swap_refinement_capsules_v1" / "capsules_prompt_swap_refinement.json",
]


def load_json(path: Path) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def weighted_average(summary_paths: list[Path], field_names: list[str]) -> dict[str, float]:
    rows = []
    for path in summary_paths:
        payload = load_json(path)
        summary = payload["summary"]
        rows.append(summary)
    weights = np.array([row["num_images"] for row in rows], dtype=float)
    weights = weights / weights.sum()
    out: dict[str, float] = {}
    for field in field_names:
        values = np.array([row[field] for row in rows], dtype=float)
        out[field] = float(np.sum(values * weights))
    out["num_images"] = int(np.sum([row["num_images"] for row in rows]))
    return out


def main():
    crosshost = load_json(ANOMALY_CROSSHOST_JSON)
    anomaly = crosshost["aggregate"]["AnomalyCLIP"]
    adaclip = crosshost["aggregate"]["AdaCLIP"]

    adaptclip = weighted_average(
        ADAPTCLIP_SUMMARIES,
        [
            "mean_fused_vs_vl_corr",
            "mean_fused_vs_tl_corr",
            "mean_fused_vs_vl_topk_overlap",
            "mean_fused_vs_tl_topk_overlap",
            "mean_fused_local_auc",
            "mean_vl_local_auc",
            "mean_tl_local_auc",
        ],
    )
    faprompt = weighted_average(
        FAPROMPT_SUMMARIES,
        [
            "mean_prompt_pair_corr",
            "mean_prompt_pair_topk_overlap",
            "mean_prompt_pair_local_auc_absdiff",
            "mean_baseline_vs_prompt_corr",
            "mean_baseline_vs_prompt_topk_overlap",
            "mean_prompt_auc_std",
        ],
    )

    prompt_rows = [load_json(path) for path in PROMPT_REFINEMENT_JSONS]
    sample_names = [row["class_name"] for row in prompt_rows]
    baseline_gaps = np.array([row["baseline"]["auc_gap"] for row in prompt_rows], dtype=float)
    ours_gaps = np.array([row["ours"]["auc_gap"] for row in prompt_rows], dtype=float)
    gap_improvements = ours_gaps - baseline_gaps

    fig, axes = plt.subplots(2, 3, figsize=(16, 9), constrained_layout=True)

    # Panel A: class-conditioned hosts, image vs local top1
    ax = axes[0, 0]
    hosts = ["AnomalyCLIP", "AdaCLIP"]
    image_vals = [anomaly["true_prompt_top1_rate_image"], adaclip["true_prompt_top1_rate_image"]]
    local_vals = [anomaly["true_prompt_top1_rate_local"], adaclip["true_prompt_top1_rate_local"]]
    x = np.arange(len(hosts))
    w = 0.35
    ax.bar(x - w / 2, image_vals, width=w, color="#355C7D", label="image top1")
    ax.bar(x + w / 2, local_vals, width=w, color="#F67280", label="local top1")
    ax.set_xticks(x, hosts)
    ax.set_ylim(0.0, 0.28)
    ax.set_title("Class-Conditioned Semantic Attenuation")
    ax.set_ylabel("Top1 rate")
    ax.legend(frameon=False, fontsize=9, loc="upper right")
    for xi, v in zip(x - w / 2, image_vals):
        ax.text(xi, v + 0.01, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    for xi, v in zip(x + w / 2, local_vals):
        ax.text(xi, v + 0.01, f"{v:.3f}", ha="center", va="bottom", fontsize=9)

    # Panel B: prompt invariance
    ax = axes[0, 1]
    corr_vals = [anomaly["mean_true_wrong_corr"], adaclip["mean_true_wrong_corr"]]
    overlap_vals = [anomaly["mean_true_wrong_topk_overlap"], adaclip["mean_true_wrong_topk_overlap"]]
    ax.bar(x - w / 2, corr_vals, width=w, color="#6C5B7B", label="true/wrong corr")
    ax.bar(x + w / 2, overlap_vals, width=w, color="#C06C84", label="top-k overlap")
    ax.set_xticks(x, hosts)
    ax.set_ylim(0.0, 1.05)
    ax.set_title("Prompt Invariance of Dense Maps")
    ax.legend(frameon=False, fontsize=9, loc="upper left")
    for xi, v in zip(x - w / 2, corr_vals):
        ax.text(xi, v + 0.02, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    for xi, v in zip(x + w / 2, overlap_vals):
        ax.text(xi, v + 0.02, f"{v:.3f}", ha="center", va="bottom", fontsize=9)

    # Panel C: AdaptCLIP branch dominance
    ax = axes[0, 2]
    labels = ["corr", "top-k overlap", "local AUC"]
    vl_vals = [
        adaptclip["mean_fused_vs_vl_corr"],
        adaptclip["mean_fused_vs_vl_topk_overlap"],
        adaptclip["mean_vl_local_auc"],
    ]
    tl_vals = [
        adaptclip["mean_fused_vs_tl_corr"],
        adaptclip["mean_fused_vs_tl_topk_overlap"],
        adaptclip["mean_tl_local_auc"],
    ]
    x2 = np.arange(len(labels))
    ax.bar(x2 - w / 2, vl_vals, width=w, color="#2A9D8F", label="fused vs VL / VL AUC")
    ax.bar(x2 + w / 2, tl_vals, width=w, color="#E76F51", label="fused vs TL / TL AUC")
    ax.set_xticks(x2, labels)
    ax.set_ylim(0.0, 1.05)
    ax.set_title("AdaptCLIP: Generic VL Branch Dominance")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    for xi, v in zip(x2 - w / 2, vl_vals):
        ax.text(xi, v + 0.02, f"{v:.3f}", ha="center", va="bottom", fontsize=8)
    for xi, v in zip(x2 + w / 2, tl_vals):
        ax.text(xi, v + 0.02, f"{v:.3f}", ha="center", va="bottom", fontsize=8)

    # Panel D: FAPrompt prompt diversity collapse
    ax = axes[1, 0]
    fp_labels = ["pair corr", "pair overlap", "baseline-prompt corr", "AUC std"]
    fp_vals = [
        faprompt["mean_prompt_pair_corr"],
        faprompt["mean_prompt_pair_topk_overlap"],
        faprompt["mean_baseline_vs_prompt_corr"],
        faprompt["mean_prompt_auc_std"],
    ]
    colors = ["#577590", "#90BE6D", "#277DA1", "#F9C74F"]
    bars = ax.bar(np.arange(len(fp_labels)), fp_vals, color=colors)
    ax.set_xticks(np.arange(len(fp_labels)), fp_labels)
    ax.set_ylim(0.0, 1.05)
    ax.set_title("FAPrompt: Prompt Diversity Collapse")
    for bar, v in zip(bars, fp_vals):
        ax.text(bar.get_x() + bar.get_width() / 2, v + 0.02, f"{v:.3f}", ha="center", va="bottom", fontsize=9)

    # Panel E: OURS correction slope chart
    ax = axes[1, 1]
    ax.axhline(0.0, color="black", lw=1.0, alpha=0.7)
    for name, b, o in zip(sample_names, baseline_gaps, ours_gaps):
        ax.plot([0, 1], [b, o], marker="o", lw=2.2, label=name)
        ax.text(1.03, o, name, va="center", fontsize=9)
    ax.set_xlim(-0.15, 1.55)
    ax.set_xticks([0, 1], ["Baseline gap", "OURS gap"])
    ax.set_ylabel("true AUC - wrong AUC")
    ax.set_title("OURS Reduces Wrong-Prompt Advantage")

    # Panel F: improvement summary bars
    ax = axes[1, 2]
    improve_labels = sample_names + ["mean"]
    improve_vals = list(gap_improvements) + [float(gap_improvements.mean())]
    bar_colors = ["#43AA8B" if v > 0 else "#F94144" for v in improve_vals]
    bars = ax.bar(np.arange(len(improve_labels)), improve_vals, color=bar_colors)
    ax.axhline(0.0, color="black", lw=1.0, alpha=0.7)
    ax.set_xticks(np.arange(len(improve_labels)), improve_labels, rotation=20)
    ax.set_ylabel("OURS gap - baseline gap")
    ax.set_title("Gap Improvement by OURS")
    for bar, v in zip(bars, improve_vals):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            v + (0.004 if v >= 0 else -0.008),
            f"{v:+.3f}",
            ha="center",
            va="bottom" if v >= 0 else "top",
            fontsize=9,
        )

    fig.suptitle(
        "Dense localization failure modes across CLIP-based AD hosts and support-based ranking correction",
        fontsize=15,
    )

    save_dir = RESULT_ROOT / "discussion_failure_correction_figure"
    save_dir.mkdir(parents=True, exist_ok=True)
    png_path = save_dir / "discussion_failure_correction.png"
    pdf_path = save_dir / "discussion_failure_correction.pdf"
    fig.savefig(png_path, dpi=220)
    fig.savefig(pdf_path)
    plt.close(fig)

    payload = {
        "anomalyclip": anomaly,
        "adaclip": adaclip,
        "adaptclip_weighted": adaptclip,
        "faprompt_weighted": faprompt,
        "prompt_correction": {
            "samples": sample_names,
            "baseline_gaps": baseline_gaps.tolist(),
            "ours_gaps": ours_gaps.tolist(),
            "gap_improvements": gap_improvements.tolist(),
            "mean_gap_improvement": float(gap_improvements.mean()),
        },
        "artifacts": {
            "png": str(png_path),
            "pdf": str(pdf_path),
        },
    }
    with open(save_dir / "discussion_failure_correction.json", "w") as f:
        json.dump(payload, f, indent=2)

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
