from __future__ import annotations

import argparse
import csv
import gc
import json
import os
import sys
from itertools import combinations
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from sklearn.metrics import roc_auc_score


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"
FAPROMPT_ROOT = ROOT / "neurips2026" / "FAPrompt"
VISA_CKPT = FAPROMPT_ROOT / "checkpoints" / "trained_on_visa" / "epoch_15.pth"
MVTEC_CKPT = FAPROMPT_ROOT / "checkpoints" / "trained_on_mvtecad" / "epoch_15.pth"

sys.path.insert(0, str(FAPROMPT_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402
from dataset import Dataset  # noqa: E402
from utils import get_transform  # noqa: E402


def validate_visa_root(root: str, dataset_name: str) -> None:
    if dataset_name.lower() != "visa":
        return
    resolved = Path(root).resolve()
    official = OFFICIAL_VISA_ROOT.resolve()
    if resolved != official:
        raise ValueError(f"VisA experiments must use the official root only: {official}. Got: {resolved}")


def resolve_preset(args) -> None:
    if args.preset is None:
        return
    if args.preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTEC_ROOT)
        args.target_dataset = "mvtecad"
    elif args.preset == "mvtec2visa":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif args.preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif args.preset == "mvtec2btad":
        args.checkpoint_path = str(MVTEC_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {args.preset}")


def current_rss_mb() -> float:
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    parts = line.split()
                    if len(parts) >= 2:
                        return float(parts[1]) / 1024.0
    except OSError:
        pass
    return float("nan")


def cleanup_image_state(device: str) -> None:
    gc.collect()
    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()


def mean_ignoring_nan(values: list[float]) -> float:
    vals = [v for v in values if np.isfinite(v)]
    if not vals:
        return float("nan")
    return float(np.mean(vals))


def safe_corr(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float32).reshape(-1)
    y = np.asarray(b, dtype=np.float32).reshape(-1)
    if x.size < 2 or y.size < 2:
        return float("nan")
    sx = float(np.std(x))
    sy = float(np.std(y))
    if sx < 1e-12 or sy < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def top_fraction_mask(score_map: np.ndarray, frac: float) -> np.ndarray:
    flat = score_map.reshape(-1)
    k = max(1, int(np.ceil(flat.size * frac)))
    thresh = np.partition(flat, -k)[-k]
    return score_map >= thresh


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    inter = float(np.logical_and(a, b).sum())
    union = float(np.logical_or(a, b).sum())
    if union <= 0:
        return float("nan")
    return inter / union


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def append_partial_row(save_dir: Path, row: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.jsonl", "a") as f:
        f.write(json.dumps(row) + "\n")


def write_progress(save_dir: Path, payload: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "progress.json", "w") as f:
        json.dump(payload, f, indent=2)


def save_outputs(summary: dict, rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def normalize_pair(pos: torch.Tensor, neg: torch.Tensor) -> torch.Tensor:
    pair = torch.stack([pos, neg], dim=0)
    pair = pair / pair.norm(dim=-1, keepdim=True)
    return pair


def anomaly_term_from_similarity_map(sim_map: torch.Tensor) -> torch.Tensor:
    return (sim_map[1, :] + 1.0 - sim_map[0, :]) / 2.0


def build_selected_tokens(patch_features: torch.Tensor, text_pair_mean: torch.Tensor, prompt_learner) -> torch.Tensor:
    similarity, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_pair_mean)
    topk = prompt_learner.k
    _, pk_indx = torch.topk(similarity[1:, :, 1], k=topk, dim=0, largest=True, sorted=True)
    pk_indx = pk_indx.permute(1, 0)
    selected_tokens = []
    for i in range(len(pk_indx)):
        selected_tokens_i = []
        for k in range(len(pk_indx[0])):
            tmp_token = patch_features[1:, :, :].permute(1, 0, 2)[i, k, :]
            selected_tokens_i.append(tmp_token)
        selected_tokens_i = torch.stack(selected_tokens_i)
        selected_tokens.append(selected_tokens_i)
    return torch.stack(selected_tokens)


def gaussian_np(map_2d: np.ndarray, sigma: float) -> np.ndarray:
    return gaussian_filter(map_2d.astype(np.float32), sigma=sigma)


def main() -> None:
    parser = argparse.ArgumentParser("Prompt diversity collapse audit for FAPrompt baseline localization")
    parser.add_argument("--preset", type=str, default=None, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument("--checkpoint_path", type=str, default=str(VISA_CKPT))
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=1)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=10.0)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--progress_every", type=int, default=1)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_prompt_diversity"),
    )
    args = parser.parse_args()

    resolve_preset(args)
    validate_visa_root(args.target_root, "visa" if args.target_dataset == "visa" else args.target_dataset)
    save_dir = Path(args.save_dir)

    params = {
        "Prompt_length": args.n_ctx,
        "learnabel_text_embedding_depth": args.depth,
        "learnabel_text_embedding_length": args.t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=args.device, design_details=params)
    model.eval()
    print(json.dumps({"event": "stage", "name": "model_ready", "pid": os.getpid(), "rss_mb": round(current_rss_mb(), 2)}), flush=True)

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.target_root, transform=preprocess, target_transform=target_transform, dataset_name=args.target_dataset)
    print(json.dumps({"event": "stage", "name": "dataset_ready", "pid": os.getpid(), "rss_mb": round(current_rss_mb(), 2)}), flush=True)

    prompt_learner = FAPrompt(model.to("cpu"), params)
    checkpoint = torch.load(args.checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(args.device)
    prompt_learner.eval()

    model.to(args.device)
    model.visual.DAPM_replace(DPAM_layer=20)
    model.eval()

    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
    target_classes = set(args.target_classes) if args.target_classes else set(dataset.obj_list)
    per_class_seen = {cls: 0 for cls in dataset.obj_list}
    rows: list[dict] = []

    write_progress(
        save_dir,
        {
            "event": "start",
            "pid": os.getpid(),
            "preset": args.preset,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "max_anomaly_images_per_class": args.max_anomaly_images_per_class,
            "rss_mb": round(current_rss_mb(), 2),
        },
    )

    with torch.no_grad():
        for idx, items in enumerate(loader):
            if all(per_class_seen.get(cls, 0) >= args.max_anomaly_images_per_class for cls in sorted(target_classes)):
                break
            cls_name = items["cls_name"][0]
            if cls_name not in target_classes:
                continue
            anomaly_flag = int(items["anomaly"].item())
            if anomaly_flag == 0:
                continue
            if per_class_seen[cls_name] >= args.max_anomaly_images_per_class:
                continue
            per_class_seen[cls_name] += 1

            if args.progress_every > 0:
                print(json.dumps({"event": "image_start", "pid": os.getpid(), "dataset_index": idx, "class_name": cls_name, "rows_done": len(rows), "rss_mb": round(current_rss_mb(), 2)}), flush=True)

            image = items["img"].to(args.device)
            gt_mask = items["img_mask"][:, 0].squeeze().detach().cpu().numpy() > 0.5
            if not gt_mask.any():
                continue

            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True)
            patch_features = patch_features / patch_features.norm(dim=-1, keepdim=True)

            prompts_pos, prompts_neg, tokenized_pos, tokenized_neg, compound_prompts_text, _ = prompt_learner.forward()
            pos_stage1 = model.encode_text_learn(prompts_pos, tokenized_pos, compound_prompts_text).float().squeeze(0)
            neg_stage1 = model.encode_text_learn(prompts_neg, tokenized_neg, compound_prompts_text).float()
            neg_stage1 = neg_stage1 / neg_stage1.norm(dim=-1, keepdim=True)
            pos_stage1 = pos_stage1 / pos_stage1.norm(dim=-1, keepdim=True)

            mean_pair_stage1 = normalize_pair(pos_stage1, neg_stage1.mean(dim=0))
            selected_tokens = build_selected_tokens(patch_features, mean_pair_stage1, prompt_learner)

            prompts_pos2, prompts_neg2, tokenized_pos2, tokenized_neg2, compound_prompts_text2, _ = prompt_learner.forward(selected_tokens=selected_tokens[0])
            pos_stage2 = model.encode_text_learn(prompts_pos2, tokenized_pos2, compound_prompts_text2).float().squeeze(0)
            neg_stage2 = model.encode_text_learn(prompts_neg2, tokenized_neg2, compound_prompts_text2).float()
            neg_stage2 = neg_stage2 / neg_stage2.norm(dim=-1, keepdim=True)
            pos_stage2 = pos_stage2 / pos_stage2.norm(dim=-1, keepdim=True)

            prompt_maps: list[np.ndarray] = []
            prompt_aucs: list[float] = []
            for p_idx in range(prompt_learner.num_p):
                pair1 = normalize_pair(pos_stage1, neg_stage1[p_idx])
                sim1, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, pair1)
                sim_map1 = AnomalyCLIP_lib.get_similarity_map(sim1[1:, :], args.image_size).squeeze(0)
                term1 = anomaly_term_from_similarity_map(sim_map1)

                pair2 = normalize_pair(pos_stage2, neg_stage2[p_idx]).unsqueeze(0)
                sim2, _ = AnomalyCLIP_lib.compute_similarity(patch_features, pair2)
                sim_map2 = AnomalyCLIP_lib.get_similarity_map(sim2[1:, :], args.image_size).squeeze(0)
                term2 = anomaly_term_from_similarity_map(sim_map2)

                final_map = ((term1 + term2) / 2.0).detach().cpu().numpy()
                final_map = gaussian_np(final_map, args.sigma)
                prompt_maps.append(final_map)

                inside = final_map[gt_mask]
                outside = final_map[~gt_mask]
                prompt_aucs.append(safe_auc(inside, outside))

            mean_pair1 = mean_pair_stage1.unsqueeze(0)
            sim1_mean, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, mean_pair_stage1)
            sim_map1_mean = AnomalyCLIP_lib.get_similarity_map(sim1_mean[1:, :], args.image_size).squeeze(0)
            term1_mean = anomaly_term_from_similarity_map(sim_map1_mean)

            mean_pair2 = normalize_pair(pos_stage2, neg_stage2.mean(dim=0)).unsqueeze(0)
            sim2_mean, _ = AnomalyCLIP_lib.compute_similarity(patch_features, mean_pair2)
            sim_map2_mean = AnomalyCLIP_lib.get_similarity_map(sim2_mean[1:, :], args.image_size).squeeze(0)
            term2_mean = anomaly_term_from_similarity_map(sim_map2_mean)
            baseline_map = ((term1_mean + term2_mean) / 2.0).detach().cpu().numpy()
            baseline_map = gaussian_np(baseline_map, args.sigma)

            prompt_corr = []
            prompt_overlap = []
            prompt_iou = []
            prompt_auc_absdiff = []
            baseline_corr = []
            baseline_overlap = []
            baseline_iou = []
            prompt_masks = [top_fraction_mask(m, args.map_topk) for m in prompt_maps]
            baseline_mask = top_fraction_mask(baseline_map, args.map_topk)

            for i, j in combinations(range(len(prompt_maps)), 2):
                prompt_corr.append(safe_corr(prompt_maps[i], prompt_maps[j]))
                prompt_overlap.append(mask_overlap(prompt_masks[i], prompt_masks[j]))
                prompt_iou.append(mask_iou(prompt_masks[i], prompt_masks[j]))
                if np.isfinite(prompt_aucs[i]) and np.isfinite(prompt_aucs[j]):
                    prompt_auc_absdiff.append(abs(prompt_aucs[i] - prompt_aucs[j]))

            for i in range(len(prompt_maps)):
                baseline_corr.append(safe_corr(baseline_map, prompt_maps[i]))
                baseline_overlap.append(mask_overlap(baseline_mask, prompt_masks[i]))
                baseline_iou.append(mask_iou(baseline_mask, prompt_masks[i]))

            baseline_auc = safe_auc(baseline_map[gt_mask], baseline_map[~gt_mask])
            prompt_stack = np.stack(prompt_maps, axis=0)
            row = {
                "dataset_index": idx,
                "class_name": cls_name,
                "num_prompts": len(prompt_maps),
                "baseline_local_auc": baseline_auc,
                "prompt_auc_mean": mean_ignoring_nan(prompt_aucs),
                "prompt_auc_std": float(np.std([a for a in prompt_aucs if np.isfinite(a)])) if any(np.isfinite(prompt_aucs)) else float("nan"),
                "mean_prompt_pair_corr": mean_ignoring_nan(prompt_corr),
                "mean_prompt_pair_topk_overlap": mean_ignoring_nan(prompt_overlap),
                "mean_prompt_pair_topk_iou": mean_ignoring_nan(prompt_iou),
                "mean_prompt_pair_local_auc_absdiff": mean_ignoring_nan(prompt_auc_absdiff),
                "mean_baseline_vs_prompt_corr": mean_ignoring_nan(baseline_corr),
                "mean_baseline_vs_prompt_topk_overlap": mean_ignoring_nan(baseline_overlap),
                "mean_baseline_vs_prompt_topk_iou": mean_ignoring_nan(baseline_iou),
                "mean_prompt_map_std": float(prompt_stack.std(axis=0).mean()),
                "rss_mb": round(current_rss_mb(), 2),
            }
            rows.append(row)
            append_partial_row(save_dir, row)
            write_progress(
                save_dir,
                {
                    "event": "image_done",
                    "pid": os.getpid(),
                    "dataset_index": idx,
                    "class_name": cls_name,
                    "rows_done": len(rows),
                    "rss_mb": round(current_rss_mb(), 2),
                },
            )
            if args.progress_every > 0:
                print(json.dumps({"event": "image_done", "pid": os.getpid(), "dataset_index": idx, "rows_done": len(rows), "class_name": cls_name, "rss_mb": round(current_rss_mb(), 2)}), flush=True)
            cleanup_image_state(args.device)

    summary = {
        "settings": {
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "target_classes": sorted(target_classes),
            "image_size": args.image_size,
            "sigma": args.sigma,
            "features_list": args.features_list,
            "num_prompts": 10,
        },
        "summary": {
            "num_images": len(rows),
            "mean_baseline_local_auc": mean_ignoring_nan([r["baseline_local_auc"] for r in rows]),
            "mean_prompt_auc_mean": mean_ignoring_nan([r["prompt_auc_mean"] for r in rows]),
            "mean_prompt_auc_std": mean_ignoring_nan([r["prompt_auc_std"] for r in rows]),
            "mean_prompt_pair_corr": mean_ignoring_nan([r["mean_prompt_pair_corr"] for r in rows]),
            "mean_prompt_pair_topk_overlap": mean_ignoring_nan([r["mean_prompt_pair_topk_overlap"] for r in rows]),
            "mean_prompt_pair_topk_iou": mean_ignoring_nan([r["mean_prompt_pair_topk_iou"] for r in rows]),
            "mean_prompt_pair_local_auc_absdiff": mean_ignoring_nan([r["mean_prompt_pair_local_auc_absdiff"] for r in rows]),
            "mean_baseline_vs_prompt_corr": mean_ignoring_nan([r["mean_baseline_vs_prompt_corr"] for r in rows]),
            "mean_baseline_vs_prompt_topk_overlap": mean_ignoring_nan([r["mean_baseline_vs_prompt_topk_overlap"] for r in rows]),
            "mean_baseline_vs_prompt_topk_iou": mean_ignoring_nan([r["mean_baseline_vs_prompt_topk_iou"] for r in rows]),
            "mean_prompt_map_std": mean_ignoring_nan([r["mean_prompt_map_std"] for r in rows]),
        },
    }
    save_outputs(summary, rows, save_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
