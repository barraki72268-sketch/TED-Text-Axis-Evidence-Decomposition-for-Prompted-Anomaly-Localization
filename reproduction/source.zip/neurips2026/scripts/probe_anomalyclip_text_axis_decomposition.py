from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from prompt_ensemble import encode_text_with_prompt_ensemble  # noqa: E402
from utils import get_transform  # noqa: E402


def build_dataset(root: str, dataset_name: str, image_size: int, mode: str):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name=dataset_name, mode=mode)


def farthest_point_subsample(feat: torch.Tensor, max_points: int) -> torch.Tensor:
    if feat.shape[0] <= max_points:
        return feat
    feat = F.normalize(feat.float(), dim=-1)
    mean_dir = F.normalize(feat.mean(dim=0, keepdim=True), dim=-1)
    min_dist = 1.0 - (feat @ mean_dir.t()).squeeze(1)
    selected = []
    for _ in range(max_points):
        idx = int(torch.argmax(min_dist).item())
        selected.append(idx)
        candidate_dist = 1.0 - (feat @ feat[idx : idx + 1].t()).squeeze(1)
        min_dist = torch.minimum(min_dist, candidate_dist)
        min_dist[idx] = -1.0
    return feat[torch.tensor(selected, dtype=torch.long)]


def logmeanexp_negative_sqdist(patch: torch.Tensor, bank: torch.Tensor, tau: float) -> torch.Tensor:
    if bank.numel() == 0:
        return patch.new_zeros((patch.shape[0],))
    dist2 = torch.cdist(patch, bank, p=2.0) ** 2
    logits = -dist2 / tau
    return torch.logsumexp(logits, dim=-1) - math.log(bank.shape[0])


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def load_static_text_pair(device: str) -> torch.Tensor:
    reference_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=None)
    reference_model.eval()
    pair = encode_text_with_prompt_ensemble(reference_model, ["object"], "cpu").float()
    return F.normalize(pair, dim=-1).to(device)


def decision_axis(text_pair: torch.Tensor) -> torch.Tensor:
    axis = text_pair[1] - text_pair[0]
    return F.normalize(axis.float(), dim=-1)


def decompose_with_axis(feat: torch.Tensor, axis: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    coeff = feat @ axis
    parallel = coeff.unsqueeze(-1) * axis.unsqueeze(0)
    perp = feat - parallel
    return parallel, perp


def logmeanexp_negative_sqdist_1d(coeff: torch.Tensor, bank_coeff: torch.Tensor, tau: float) -> torch.Tensor:
    if bank_coeff.numel() == 0:
        return coeff.new_zeros((coeff.shape[0],))
    dist2 = (coeff.unsqueeze(1) - bank_coeff.unsqueeze(0)) ** 2
    logits = -dist2 / tau
    return torch.logsumexp(logits, dim=-1) - math.log(bank_coeff.shape[0])


def collect_source_patch_banks(
    model,
    text_pair: torch.Tensor,
    data_root: str,
    source_dataset: str,
    image_size: int,
    features_list: list[int],
    device: str,
    heldout_class: str | None,
    max_good_per_class: int,
    max_defect_per_class: int,
    hard_frac: float,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
):
    train_ds = build_dataset(data_root, source_dataset, image_size, mode="train")
    test_ds = build_dataset(data_root, source_dataset, image_size, mode="test")

    fp_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    def_chunks: dict[int, list[torch.Tensor]] = {i: [] for i in range(len(features_list))}
    per_good: dict[str, int] = {cls_name: 0 for cls_name in train_ds.obj_list}
    per_defect: dict[str, int] = {cls_name: 0 for cls_name in test_ds.obj_list}
    target_good_classes = [cls_name for cls_name in train_ds.obj_list if heldout_class is None or cls_name != heldout_class]
    target_defect_classes = [cls_name for cls_name in test_ds.obj_list if heldout_class is None or cls_name != heldout_class]

    with torch.no_grad():
        for idx in range(len(train_ds)):
            if all(per_good[cls_name] >= max_good_per_class for cls_name in target_good_classes):
                break
            item = train_ds[idx]
            cls_name = item["cls_name"]
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_good[cls_name] >= max_good_per_class:
                continue
            per_good[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                patch_scores = ((similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0).reshape(-1)
                k = max(1, int(patch_scores.numel() * hard_frac))
                top_idx = torch.topk(patch_scores, k=k, largest=True).indices
                selected = patch[top_idx]
                if selected.shape[0] > max_fp_per_image:
                    selected = farthest_point_subsample(selected, max_fp_per_image)
                fp_chunks[layer_idx].append(selected.cpu())

        for idx in range(len(test_ds)):
            if all(per_defect[cls_name] >= max_defect_per_class for cls_name in target_defect_classes):
                break
            item = test_ds[idx]
            cls_name = item["cls_name"]
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0:
                continue
            if heldout_class is not None and cls_name == heldout_class:
                continue
            if per_defect[cls_name] >= max_defect_per_class:
                continue
            per_defect[cls_name] += 1

            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"].unsqueeze(0).to(device).float()
            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                h = int(round(patch.shape[0] ** 0.5))
                gt_small = F.interpolate(gt_mask, size=(h, h), mode="nearest")[0, 0].reshape(-1) > 0.5
                if int(gt_small.sum().item()) == 0:
                    continue
                selected = patch[gt_small]
                if selected.shape[0] > max_defect_per_image:
                    selected = farthest_point_subsample(selected, max_defect_per_image)
                def_chunks[layer_idx].append(selected.cpu())

    fp_banks: dict[int, torch.Tensor] = {}
    def_banks: dict[int, torch.Tensor] = {}
    bank_stats: dict[int, dict] = {}
    for layer_idx in range(len(features_list)):
        fp_bank = torch.cat(fp_chunks[layer_idx], dim=0) if fp_chunks[layer_idx] else torch.empty((0, 768))
        def_bank = torch.cat(def_chunks[layer_idx], dim=0) if def_chunks[layer_idx] else torch.empty((0, 768))
        if fp_bank.shape[0] > max_bank_per_layer:
            fp_bank = farthest_point_subsample(fp_bank, max_bank_per_layer)
        if def_bank.shape[0] > max_bank_per_layer:
            def_bank = farthest_point_subsample(def_bank, max_bank_per_layer)
        fp_banks[layer_idx] = F.normalize(fp_bank.float(), dim=-1) if fp_bank.numel() else fp_bank.float()
        def_banks[layer_idx] = F.normalize(def_bank.float(), dim=-1) if def_bank.numel() else def_bank.float()
        bank_stats[layer_idx] = {
            "num_fp": int(fp_banks[layer_idx].shape[0]),
            "num_defect": int(def_banks[layer_idx].shape[0]),
        }
    return fp_banks, def_banks, bank_stats


def default_bank_cache_path(
    checkpoint_path: str,
    source_root: str,
    source_dataset: str,
    heldout_class: str | None,
    image_size: int,
    features_list: list[int],
    hard_frac: float,
    max_good_per_class: int,
    max_defect_per_class: int,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
) -> Path:
    cache_cfg = {
        "checkpoint_path": str(checkpoint_path),
        "source_root": str(source_root),
        "source_dataset": source_dataset,
        "heldout_class": heldout_class,
        "image_size": int(image_size),
        "features_list": list(features_list),
        "hard_frac": float(hard_frac),
        "max_good_per_class": int(max_good_per_class),
        "max_defect_per_class": int(max_defect_per_class),
        "max_bank_per_layer": int(max_bank_per_layer),
        "max_fp_per_image": int(max_fp_per_image),
        "max_defect_per_image": int(max_defect_per_image),
    }
    digest = hashlib.md5(json.dumps(cache_cfg, sort_keys=True).encode("utf-8")).hexdigest()[:12]
    source_tag = f"{source_dataset}_{Path(source_root).name.replace('/', '_')}"
    heldout_tag = heldout_class or "none"
    return ROOT / "neurips2026" / "results" / "bank_cache" / f"anomalyclip_{source_tag}_exclude-{heldout_tag}_{digest}.pt"


def load_source_patch_banks_cache(cache_path: Path):
    payload = torch.load(cache_path, map_location="cpu")
    fp_banks = {int(k): v.float() for k, v in payload["fp_banks"].items()}
    def_banks = {int(k): v.float() for k, v in payload["def_banks"].items()}
    bank_stats = {int(k): v for k, v in payload["bank_stats"].items()}
    cache_meta = payload.get("cache_meta", {})
    return fp_banks, def_banks, bank_stats, cache_meta


def save_source_patch_banks_cache(
    cache_path: Path,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    bank_stats: dict[int, dict],
    cache_meta: dict,
) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "fp_banks": {int(k): v.detach().cpu() for k, v in fp_banks.items()},
        "def_banks": {int(k): v.detach().cpu() for k, v in def_banks.items()},
        "bank_stats": bank_stats,
        "cache_meta": cache_meta,
    }
    torch.save(payload, cache_path)


def get_or_collect_source_patch_banks(
    model,
    text_pair: torch.Tensor,
    data_root: str,
    source_dataset: str,
    image_size: int,
    features_list: list[int],
    device: str,
    heldout_class: str | None,
    max_good_per_class: int,
    max_defect_per_class: int,
    hard_frac: float,
    max_bank_per_layer: int,
    max_fp_per_image: int,
    max_defect_per_image: int,
    checkpoint_path: str,
    bank_cache_path: str | None = None,
    refresh_bank_cache: bool = False,
):
    requested_cache_meta = {
        "checkpoint_path": str(checkpoint_path),
        "source_root": str(data_root),
        "source_dataset": source_dataset,
        "heldout_class": heldout_class,
        "image_size": int(image_size),
        "features_list": list(features_list),
        "hard_frac": float(hard_frac),
        "max_good_per_class": int(max_good_per_class),
        "max_defect_per_class": int(max_defect_per_class),
        "max_bank_per_layer": int(max_bank_per_layer),
        "max_fp_per_image": int(max_fp_per_image),
        "max_defect_per_image": int(max_defect_per_image),
    }
    cache_path = Path(bank_cache_path) if bank_cache_path else default_bank_cache_path(
        checkpoint_path=checkpoint_path,
        source_root=data_root,
        source_dataset=source_dataset,
        heldout_class=heldout_class,
        image_size=image_size,
        features_list=features_list,
        hard_frac=hard_frac,
        max_good_per_class=max_good_per_class,
        max_defect_per_class=max_defect_per_class,
        max_bank_per_layer=max_bank_per_layer,
        max_fp_per_image=max_fp_per_image,
        max_defect_per_image=max_defect_per_image,
    )
    if cache_path.exists() and not refresh_bank_cache:
        fp_banks, def_banks, bank_stats, cache_meta = load_source_patch_banks_cache(cache_path)
        if cache_meta == requested_cache_meta:
            return fp_banks, def_banks, bank_stats, cache_path, cache_meta
        print(
            json.dumps(
                {
                    "stage": "bank_cache_mismatch",
                    "cache_path": str(cache_path),
                    "cached_meta": cache_meta,
                    "requested_meta": requested_cache_meta,
                }
            ),
            flush=True,
        )

    fp_banks, def_banks, bank_stats = collect_source_patch_banks(
        model=model,
        text_pair=text_pair,
        data_root=data_root,
        source_dataset=source_dataset,
        image_size=image_size,
        features_list=features_list,
        device=device,
        heldout_class=heldout_class,
        max_good_per_class=max_good_per_class,
        max_defect_per_class=max_defect_per_class,
        hard_frac=hard_frac,
        max_bank_per_layer=max_bank_per_layer,
        max_fp_per_image=max_fp_per_image,
        max_defect_per_image=max_defect_per_image,
    )
    cache_meta = requested_cache_meta
    save_source_patch_banks_cache(cache_path, fp_banks, def_banks, bank_stats, cache_meta)
    return fp_banks, def_banks, bank_stats, cache_path, cache_meta


def project_bank(bank: torch.Tensor, axis: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    coeff = bank @ axis
    _, perp = decompose_with_axis(bank, axis)
    return coeff, perp


def evaluate_heldout_class(
    model,
    fp_banks: dict[int, torch.Tensor],
    def_banks: dict[int, torch.Tensor],
    dataset,
    target_dataset: str,
    heldout_class: str | None,
    target_classes: set[str] | None,
    features_list: list[int],
    tau: float,
    learned_axis: torch.Tensor,
    static_axis: torch.Tensor,
    image_score_topk: float,
    max_normal_eval_images: int | None,
    max_anomaly_eval_images: int | None,
):
    bank_device = learned_axis.device
    fp_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in fp_banks.items()}
    def_banks = {layer_idx: bank.to(bank_device) for layer_idx, bank in def_banks.items()}
    projected_banks = {}
    for axis_name, axis in [("learned", learned_axis), ("static", static_axis)]:
        projected_banks[axis_name] = {}
        for layer_idx in range(len(features_list)):
            fp_coeff, fp_perp = project_bank(fp_banks[layer_idx], axis)
            def_coeff, def_perp = project_bank(def_banks[layer_idx], axis)
            projected_banks[axis_name][layer_idx] = {
                "fp_parallel_coeff": fp_coeff,
                "fp_perp": fp_perp,
                "def_parallel_coeff": def_coeff,
                "def_perp": def_perp,
            }

    results = {}
    stats = {}
    for axis_name in ["learned", "static"]:
        for comp_name in ["raw", "parallel", "perp"]:
            key = (axis_name, comp_name)
            label = heldout_class or ",".join(sorted(target_classes)) if target_classes else "all"
            results[key] = {label: {"gt_sp": [], "pr_sp": [], "imgs_masks": [], "anomaly_maps": []}}
            stats[key] = {
                "inside_outside_gap": [],
                "margin_inside": [],
                "margin_outside": [],
                "margin_fpoutside": [],
                "parallel_coeff_inside": [],
                "parallel_coeff_outside": [],
                "inside_scores": [],
                "outside_scores": [],
                "fpoutside_scores": [],
            }

    num_normal_done = 0
    num_anomaly_done = 0
    with torch.no_grad():
        for idx in range(len(dataset)):
            item = dataset[idx]
            if target_classes is not None:
                if item["cls_name"] not in target_classes:
                    continue
            elif target_dataset == "mvtec" and heldout_class is not None and item["cls_name"] != heldout_class:
                continue
            anomaly_flag = int(item["anomaly"].item()) if hasattr(item["anomaly"], "item") else int(item["anomaly"])
            if anomaly_flag == 0 and max_normal_eval_images is not None and num_normal_done >= max_normal_eval_images:
                continue
            if anomaly_flag == 1 and max_anomaly_eval_images is not None and num_anomaly_done >= max_anomaly_eval_images:
                continue
            image = item["img"].unsqueeze(0).to(next(model.parameters()).device)
            gt_mask = item["img_mask"].unsqueeze(0).clone()
            gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
            gt_mask_np = gt_mask[0, 0].numpy().astype(bool)
            if anomaly_flag == 0:
                num_normal_done += 1
            else:
                num_anomaly_done += 1

            _, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
            layer_maps = {("learned", "raw"): [], ("learned", "parallel"): [], ("learned", "perp"): [], ("static", "raw"): [], ("static", "parallel"): [], ("static", "perp"): []}
            layer_coeff_maps = {"learned": [], "static": []}
            for layer_idx, patch_feature in enumerate(patch_features):
                patch = F.normalize(patch_feature[:, 1:, :].reshape(-1, patch_feature.shape[-1]).float(), dim=-1)
                for axis_name, axis in [("learned", learned_axis), ("static", static_axis)]:
                    patch_coeff = patch @ axis
                    _, patch_perp = decompose_with_axis(patch, axis)
                    banks = projected_banks[axis_name][layer_idx]
                    q_fp_raw = logmeanexp_negative_sqdist(patch, fp_banks[layer_idx], tau=tau)
                    q_def_raw = logmeanexp_negative_sqdist(patch, def_banks[layer_idx], tau=tau)
                    q_fp_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["fp_parallel_coeff"], tau=tau)
                    q_def_parallel = logmeanexp_negative_sqdist_1d(patch_coeff, banks["def_parallel_coeff"], tau=tau)
                    q_fp_perp = logmeanexp_negative_sqdist(patch_perp, banks["fp_perp"], tau=tau)
                    q_def_perp = logmeanexp_negative_sqdist(patch_perp, banks["def_perp"], tau=tau)

                    h = int(round(patch.shape[0] ** 0.5))
                    layer_maps[(axis_name, "raw")].append((q_def_raw - q_fp_raw).reshape(h, h).detach().cpu().numpy())
                    layer_maps[(axis_name, "parallel")].append((q_def_parallel - q_fp_parallel).reshape(h, h).detach().cpu().numpy())
                    layer_maps[(axis_name, "perp")].append((q_def_perp - q_fp_perp).reshape(h, h).detach().cpu().numpy())
                    layer_coeff_maps[axis_name].append(patch_coeff.reshape(h, h).detach().cpu().numpy())

            target_h, target_w = gt_mask_np.shape
            coeff_mean_maps = {}
            margin_mean_maps = {}
            for axis_name, coeff_maps in layer_coeff_maps.items():
                coeff_map = np.mean(np.stack(coeff_maps, axis=0), axis=0)
                coeff_map = (
                    F.interpolate(
                        torch.from_numpy(coeff_map).unsqueeze(0).unsqueeze(0).float(),
                        size=(target_h, target_w),
                        mode="bilinear",
                        align_corners=False,
                    )[0, 0]
                    .cpu()
                    .numpy()
                )
                coeff_mean_maps[axis_name] = coeff_map
            for key, maps in layer_maps.items():
                margin_map = np.mean(np.stack(maps, axis=0), axis=0)
                margin_map = (
                    F.interpolate(
                        torch.from_numpy(margin_map).unsqueeze(0).unsqueeze(0).float(),
                        size=(target_h, target_w),
                        mode="bilinear",
                        align_corners=False,
                    )[0, 0]
                    .cpu()
                    .numpy()
                )
                margin_mean_maps[key] = margin_map
            shared_fpoutside_mask = (~gt_mask_np) & (margin_mean_maps[("learned", "raw")] < 0.0)
            for key, maps in layer_maps.items():
                margin_map = margin_mean_maps[key]
                label = next(iter(results[key].keys()))
                results[key][label]["gt_sp"].append(anomaly_flag)
                results[key][label]["pr_sp"].append(topk_mean(margin_map, image_score_topk))
                results[key][label]["imgs_masks"].append(gt_mask.numpy())
                results[key][label]["anomaly_maps"].append(margin_map[None, ...])
                if gt_mask_np.any() and (~gt_mask_np).any():
                    inside_scores = margin_map[gt_mask_np]
                    outside_scores = margin_map[~gt_mask_np]
                    fpoutside_scores = margin_map[shared_fpoutside_mask]
                    stats[key]["inside_scores"].append(inside_scores.astype(np.float32, copy=False))
                    stats[key]["outside_scores"].append(outside_scores.astype(np.float32, copy=False))
                    stats[key]["fpoutside_scores"].append(fpoutside_scores.astype(np.float32, copy=False))
                    stats[key]["margin_inside"].append(float(inside_scores.mean()))
                    stats[key]["margin_outside"].append(float(outside_scores.mean()))
                    stats[key]["margin_fpoutside"].append(float(fpoutside_scores.mean()) if fpoutside_scores.size else float("nan"))
                    stats[key]["inside_outside_gap"].append(float(inside_scores.mean() - outside_scores.mean()))
                    if key[1] == "parallel":
                        coeff_map = coeff_mean_maps[key[0]]
                        stats[key]["parallel_coeff_inside"].append(float(coeff_map[gt_mask_np].mean()))
                        stats[key]["parallel_coeff_outside"].append(float(coeff_map[~gt_mask_np].mean()))
            if (num_normal_done + num_anomaly_done) % 4 == 0:
                print(
                    json.dumps(
                        {
                            "stage": "eval_progress",
                            "normal_done": num_normal_done,
                            "anomaly_done": num_anomaly_done,
                        }
                    ),
                    flush=True,
                )

    rows = []
    for key, result in results.items():
        label = next(iter(result.keys()))
        result[label]["imgs_masks"] = np.concatenate(result[label]["imgs_masks"], axis=0)
        result[label]["anomaly_maps"] = np.concatenate(result[label]["anomaly_maps"], axis=0)
        inside = np.concatenate(stats[key]["inside_scores"], axis=0) if stats[key]["inside_scores"] else np.empty((0,), dtype=np.float32)
        outside = np.concatenate(stats[key]["outside_scores"], axis=0) if stats[key]["outside_scores"] else np.empty((0,), dtype=np.float32)
        fpoutside = np.concatenate(stats[key]["fpoutside_scores"], axis=0) if stats[key]["fpoutside_scores"] else np.empty((0,), dtype=np.float32)
        row = {
            "axis": key[0],
            "component": key[1],
            "target_label": label,
            "image_auroc": float(image_level_metrics(result, label, "image-auroc")),
            "pixel_auroc": float(pixel_level_metrics(result, label, "pixel-auroc")),
            "pixel_aupro": float(pixel_level_metrics(result, label, "pixel-aupro")),
            "inside_vs_outside_auc": safe_auc(inside, outside),
            "inside_vs_fpoutside_auc": safe_auc(inside, fpoutside),
            "margin_inside_mean": float(np.mean(stats[key]["margin_inside"])) if stats[key]["margin_inside"] else float("nan"),
            "margin_outside_mean": float(np.mean(stats[key]["margin_outside"])) if stats[key]["margin_outside"] else float("nan"),
            "margin_fpoutside_mean": float(np.nanmean(stats[key]["margin_fpoutside"])) if stats[key]["margin_fpoutside"] else float("nan"),
            "parallel_coeff_inside_mean": float(np.mean(stats[key]["parallel_coeff_inside"])) if stats[key]["parallel_coeff_inside"] else float("nan"),
            "parallel_coeff_outside_mean": float(np.mean(stats[key]["parallel_coeff_outside"])) if stats[key]["parallel_coeff_outside"] else float("nan"),
            "inside_outside_gap": float(np.mean(stats[key]["inside_outside_gap"])) if stats[key]["inside_outside_gap"] else float("nan"),
            "num_inside": int(inside.size),
            "num_outside": int(outside.size),
            "num_fpoutside": int(fpoutside.size),
        }
        rows.append(row)
    return rows


def save_results(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe text-axis decomposition on AnomalyCLIP heldout MVTec")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--source_dataset", type=str, default="mvtec")
    parser.add_argument("--target_root", type=str, default=None)
    parser.add_argument("--target_dataset", type=str, default="mvtec")
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument("--source_exclude_class", type=str, default=None)
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_text_axis_decomposition_epoch5"),
    )
    parser.add_argument("--heldout_class", type=str, default="bottle")
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--hard_frac", type=float, default=0.01)
    parser.add_argument("--max_good_per_class", type=int, default=8)
    parser.add_argument("--max_defect_per_class", type=int, default=16)
    parser.add_argument("--max_bank_per_layer", type=int, default=4096)
    parser.add_argument("--max_fp_per_image", type=int, default=128)
    parser.add_argument("--max_defect_per_image", type=int, default=128)
    parser.add_argument("--bank_cache_path", type=str, default=None)
    parser.add_argument("--refresh_bank_cache", action="store_true")
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--max_normal_eval_images", type=int, default=None)
    parser.add_argument("--max_anomaly_eval_images", type=int, default=None)
    args = parser.parse_args()

    def normalize_optional_str(value: str | None) -> str | None:
        if value is None:
            return None
        if value.strip().lower() in {"", "none", "null", "all"}:
            return None
        return value

    args.heldout_class = normalize_optional_str(args.heldout_class)
    args.source_exclude_class = normalize_optional_str(args.source_exclude_class)

    model, params = build_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), args.device)
    learned_pair = get_learned_text_pair(model, learner).to(args.device)
    static_pair = load_static_text_pair(args.device)
    learned_axis = decision_axis(learned_pair).to(args.device)
    static_axis = decision_axis(static_pair).to(args.device)
    source_exclude_class = args.source_exclude_class if args.source_exclude_class else args.heldout_class

    fp_banks, def_banks, bank_stats, bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        text_pair=learned_pair,
        data_root=args.source_root,
        source_dataset=args.source_dataset,
        image_size=args.image_size,
        features_list=args.features_list,
        device=args.device,
        heldout_class=source_exclude_class,
        max_good_per_class=args.max_good_per_class,
        max_defect_per_class=args.max_defect_per_class,
        hard_frac=args.hard_frac,
        max_bank_per_layer=args.max_bank_per_layer,
        max_fp_per_image=args.max_fp_per_image,
        max_defect_per_image=args.max_defect_per_image,
        checkpoint_path=args.checkpoint_path,
        bank_cache_path=args.bank_cache_path,
        refresh_bank_cache=args.refresh_bank_cache,
    )
    target_root = args.target_root or args.source_root
    dataset = build_dataset(target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    rows = evaluate_heldout_class(
        model=model,
        fp_banks=fp_banks,
        def_banks=def_banks,
        dataset=dataset,
        target_dataset=args.target_dataset,
        heldout_class=args.heldout_class if args.target_dataset == "mvtec" else None,
        target_classes=set(args.target_classes) if args.target_classes else None,
        features_list=args.features_list,
        tau=args.tau,
        learned_axis=learned_axis,
        static_axis=static_axis,
        image_score_topk=args.image_score_topk,
        max_normal_eval_images=args.max_normal_eval_images,
        max_anomaly_eval_images=args.max_anomaly_eval_images,
    )
    summary = {
        "heldout_class": args.heldout_class,
        "source_exclude_class": source_exclude_class,
        "source_root": args.source_root,
        "source_dataset": args.source_dataset,
        "target_root": target_root,
        "target_dataset": args.target_dataset,
        "target_mode": args.target_mode,
        "target_classes": sorted(args.target_classes) if args.target_classes else "all",
        "checkpoint_path": args.checkpoint_path,
        "hard_frac": args.hard_frac,
        "tau": args.tau,
        "image_score_topk": args.image_score_topk,
        "max_normal_eval_images": args.max_normal_eval_images,
        "max_anomaly_eval_images": args.max_anomaly_eval_images,
        "bank_stats": bank_stats,
        "bank_cache_path": str(bank_cache_path),
        "bank_cache_meta": bank_cache_meta,
        "axis_definition": {
            "learned": "normalize(e_anom_learned - e_norm_learned)",
            "static": "normalize(e_anom_static - e_norm_static)",
        },
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"summary": summary, "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
