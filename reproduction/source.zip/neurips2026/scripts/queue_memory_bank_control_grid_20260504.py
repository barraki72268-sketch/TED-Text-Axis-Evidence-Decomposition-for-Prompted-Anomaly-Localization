#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

from queue_source_bank_control_20260504 import aaclip_official_cmd, faprompt_cmd


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "source_bank_control_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "source_bank_control_20260504"
BANK = ROOT / "neurips2026" / "results" / "bank_cache"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADACLIP_CKPTS = {
    "mvtec": ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth",
    "visa": ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth",
}

DATASETS = {
    "mvtec": MVTEC_ROOT,
    "visa": VISA_ROOT,
    "mpdd": MPDD_ROOT,
    "btad": BTAD_ROOT,
}


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def split_preset(preset: str) -> tuple[str, str]:
    if "2" not in preset:
        raise SystemExit(f"Unsupported preset={preset}; expected source2target")
    source, target = preset.split("2", 1)
    if source not in DATASETS or target not in DATASETS:
        raise SystemExit(f"Unsupported preset={preset}")
    return source, target


def build_adaclip_cmd(mode: str, device: str, seed: int, preset: str) -> tuple[list[str], Path]:
    source_dataset, target_dataset = split_preset(preset)
    if source_dataset not in ADACLIP_CKPTS:
        raise SystemExit(f"AdaCLIP source must be mvtec or visa, got {source_dataset}")
    save_dir = RESULTS / f"adaclip_vitl336_{preset}_{mode}_seed{seed}"
    bank_cache = BANK / f"adaclip_{source_dataset}_{mode}_multilayer_seed{seed}.pt"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaclip.py",
        "--source_root",
        str(DATASETS[source_dataset]),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(DATASETS[target_dataset]),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(ADACLIP_CKPTS[source_dataset]),
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
        "--bank_cache_path",
        str(bank_cache),
        "--source_fp_mode",
        mode,
        "--backbone",
        "ViT-L-14-336",
        "--checkpoint_load_mode",
        "strict",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--prompting_depth",
        "4",
        "--prompting_length",
        "5",
        "--prompting_branch",
        "VL",
        "--prompting_type",
        "SD",
        "--use_hsf",
        "true",
        "--k_clusters",
        "20",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--layer_recipe",
        "all4",
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "2",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_subspace_basis_control",
        "source",
        "--calib_pair_label_control",
        "correct",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_gate_mode",
        "host",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--scoring_mode",
        "logit_gate_posneg",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--image_topk_frac",
        "0.01",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--seed",
        str(seed),
        "--device",
        device,
    ]
    return cmd, save_dir


def build_job(host: str, mode: str, preset: str, device: str, seed: int) -> tuple[list[str], Path, Path]:
    if host in {"aaclip", "aaclip_official", "aaclip_vitl_openai224"}:
        cmd, save_dir = aaclip_official_cmd(mode, device, seed, preset)
        host_tag = "aaclip_official"
    elif host == "faprompt":
        cmd, save_dir = faprompt_cmd(mode, device, seed, preset)
        host_tag = host
    elif host == "adaclip":
        cmd, save_dir = build_adaclip_cmd(mode, device, seed, preset)
        host_tag = host
    else:
        raise SystemExit(f"Unsupported host={host}")
    log_path = LOGS / f"{host_tag}_{preset}_{mode}_seed{seed}.log"
    return cmd, save_dir, log_path


def write_worker(worker_id: int, jobs: list[dict], force: bool) -> Path:
    LOGS.mkdir(parents=True, exist_ok=True)
    worker_path = LOGS / f"memory_bank_worker_{worker_id}.py"
    payload = {
        "root": str(ROOT),
        "jobs": jobs,
        "force": bool(force),
    }
    worker_path.write_text(
        "from __future__ import annotations\n"
        "import json, subprocess\n"
        "from pathlib import Path\n\n"
        f"PAYLOAD = json.loads({json.dumps(json.dumps(payload))})\n\n"
        "root = Path(PAYLOAD['root'])\n"
        "for job in PAYLOAD['jobs']:\n"
        "    save_dir = Path(job['save_dir'])\n"
        "    summary = save_dir / 'summary.json'\n"
        "    if summary.exists() and not PAYLOAD['force']:\n"
        "        print(json.dumps({'stage': 'skip_done', 'summary': str(summary)}), flush=True)\n"
        "        continue\n"
        "    save_dir.mkdir(parents=True, exist_ok=True)\n"
        "    log_path = Path(job['log_path'])\n"
        "    log_path.parent.mkdir(parents=True, exist_ok=True)\n"
        "    print(json.dumps({'stage': 'job_start', 'save_dir': str(save_dir), 'log': str(log_path)}), flush=True)\n"
        "    with log_path.open('ab', buffering=0) as log_f:\n"
        "        proc = subprocess.run(job['cmd'], cwd=root, stdout=log_f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)\n"
        "    print(json.dumps({'stage': 'job_done', 'save_dir': str(save_dir), 'returncode': proc.returncode}), flush=True)\n"
    )
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="aaclip_official,faprompt,adaclip")
    ap.add_argument("--presets", default="mvtec2visa,mvtec2mpdd,mvtec2btad,visa2mvtec,visa2mpdd,visa2btad")
    ap.add_argument("--modes", default="random_normal,easy_normal")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = parse_csv(args.hosts)
    presets = parse_csv(args.presets)
    modes = parse_csv(args.modes)
    devices = parse_csv(args.devices)
    if not devices:
        raise SystemExit("--devices cannot be empty")
    for mode in modes:
        if mode not in {"hardfp", "random_normal", "easy_normal"}:
            raise SystemExit(f"Unsupported mode={mode}")

    buckets: list[list[dict]] = [[] for _ in devices]
    all_jobs = []
    for host in hosts:
        for preset in presets:
            for mode in modes:
                bucket_id = len(all_jobs) % len(devices)
                device = devices[bucket_id]
                cmd, save_dir, log_path = build_job(host, mode, preset, device, args.seed)
                job = {
                    "cmd": cmd,
                    "save_dir": str(save_dir),
                    "log_path": str(log_path),
                    "host": host,
                    "preset": preset,
                    "mode": mode,
                    "device": device,
                }
                buckets[bucket_id].append(job)
                all_jobs.append(job)

    launched = []
    for worker_id, jobs in enumerate(buckets):
        if not jobs:
            continue
        worker_path = write_worker(worker_id, jobs, args.force)
        worker_log = LOGS / f"memory_bank_worker_{worker_id}.log"
        log_f = worker_log.open("ab", buffering=0)
        proc = subprocess.Popen(
            [str(PY), "-u", str(worker_path)],
            cwd=ROOT,
            stdout=log_f,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        launched.append(
            {
                "worker": worker_id,
                "pid": proc.pid,
                "device": devices[worker_id],
                "num_jobs": len(jobs),
                "script": str(worker_path),
                "log": str(worker_log),
            }
        )

    print(json.dumps({"stage": "memory_bank_control_grid_queue", "num_jobs": len(all_jobs), "workers": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
