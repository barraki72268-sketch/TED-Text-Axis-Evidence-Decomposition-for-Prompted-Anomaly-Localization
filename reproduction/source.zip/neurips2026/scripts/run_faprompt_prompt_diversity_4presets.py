from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT = ROOT / "neurips2026" / "scripts" / "probe_faprompt_prompt_diversity.py"
RESULTS = ROOT / "neurips2026" / "results"


def append_status(path: Path, line: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(line.rstrip() + "\n")


def main() -> int:
    parser = argparse.ArgumentParser("Run FAPrompt prompt-diversity audit across 4 presets")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=1)
    parser.add_argument("--run_tag", type=str, default="rerun1")
    args = parser.parse_args()

    presets = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]
    status_path = RESULTS / f"faprompt_prompt_diversity_run_{args.run_tag}.status"
    if status_path.exists():
        status_path.unlink()

    env = os.environ.copy()
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("OPENBLAS_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    env.setdefault("NUMEXPR_NUM_THREADS", "1")

    for preset in presets:
        save_dir = RESULTS / f"faprompt_prompt_diversity_{preset}_x{args.max_anomaly_images_per_class}_{args.run_tag}"
        cmd = [
            sys.executable,
            str(SCRIPT),
            "--preset",
            preset,
            "--max_anomaly_images_per_class",
            str(args.max_anomaly_images_per_class),
            "--device",
            args.device,
            "--save_dir",
            str(save_dir),
        ]
        proc = subprocess.run(cmd, env=env)
        if proc.returncode != 0:
            append_status(status_path, f"{preset} FAIL {save_dir} rc={proc.returncode}")
            return proc.returncode
        append_status(status_path, f"{preset} OK {save_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
