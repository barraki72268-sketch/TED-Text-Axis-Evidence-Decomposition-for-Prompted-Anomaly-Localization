#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
RUN_ROOT = ROOT / "neurips2026" / "results" / "efficiency_bank_budget_20260504"
OUT = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"


def pct(x: float | int | None) -> float:
    if x is None:
        return float("nan")
    v = float(x)
    return 100.0 * v if abs(v) <= 1.5 else v


def read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    return json.loads(path.read_text())


def get_metric(m: dict[str, Any] | None, key: str) -> float:
    if not m:
        return float("nan")
    return pct(m.get(key))


def parse_run_name(name: str) -> tuple[str, str, int] | None:
    m = re.match(r"(aaclip|faprompt)_.*?_([a-z]+2[a-z]+)_bank(\d+)_seed\d+$", name)
    if not m:
        return None
    return m.group(1), m.group(2), int(m.group(3))


def num_images(summary: dict[str, Any]) -> int:
    return int(sum(int(row.get("num_images", 0)) for row in summary.get("per_class", [])))


def extract_row(run_dir: Path) -> dict[str, Any] | None:
    parsed = parse_run_name(run_dir.name)
    if parsed is None:
        return None
    host, preset, budget = parsed
    summary = read_json(run_dir / "summary.json")
    runtime = read_json(run_dir / "runtime.json")
    if summary is None:
        return None
    mean = summary.get("mean", {})
    if host == "aaclip":
        base = mean.get("baseline", {})
        tted = mean.get("parallel", {})
        cted = mean.get("candidates", {}).get("prescore_calibrated_alpha_1", {})
        bank = summary.get("bank", {})
        retained = (bank.get("num_fp") or 0) + (bank.get("num_defect") or 0)
    elif host == "faprompt":
        base = mean.get("baseline_official", {})
        tted = mean.get("parallel", {}).get("support_only_alpha_0.5", {})
        cted = mean.get("parallel", {}).get("branch_calibrated_alpha_0.5", {})
        bank = summary.get("bank", {})
        retained = (bank.get("num_fp") or 0) + (bank.get("num_defect") or 0)
    else:
        return None
    n_img = num_images(summary)
    elapsed = float(runtime.get("elapsed_sec", float("nan"))) if runtime else float("nan")
    latency = elapsed * 1000.0 / max(n_img, 1) if math.isfinite(elapsed) else float("nan")
    return {
        "host": "AA-CLIP" if host == "aaclip" else "FAPrompt",
        "transfer": preset,
        "budget": budget,
        "retained_bank": int(retained) if retained else "",
        "num_images": n_img,
        "latency_ms_per_image": latency,
        "peak_gpu_mem_mb": runtime.get("peak_gpu_mem_mb", "") if runtime else "",
        "base_pauc": get_metric(base, "pixel_auc"),
        "base_pro": get_metric(base, "pixel_pro" if host == "aaclip" else "pixel_aupro"),
        "base_ap": get_metric(base, "pixel_ap"),
        "t_pauc": get_metric(tted, "pixel_auc"),
        "t_pro": get_metric(tted, "pixel_pro" if host == "aaclip" else "pixel_aupro"),
        "t_ap": get_metric(tted, "pixel_ap"),
        "c_pauc": get_metric(cted, "pixel_auc"),
        "c_pro": get_metric(cted, "pixel_pro" if host == "aaclip" else "pixel_aupro"),
        "c_ap": get_metric(cted, "pixel_ap"),
    }


def fmt(x: Any, nd: int = 2) -> str:
    if x == "":
        return "--"
    try:
        v = float(x)
    except Exception:
        return str(x)
    if not math.isfinite(v):
        return "--"
    return f"{v:.{nd}f}"


def write_outputs(rows: list[dict[str, Any]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / "efficiency_bank_budget_20260504.csv"
    if rows:
        with csv_path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    tex_path = OUT / "efficiency_bank_budget_table_20260504.tex"
    # Compact table for the strongest completed rows can be selected later;
    # here we emit all completed rows to avoid hiding failed or weak settings.
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Efficiency and source-bank budget sensitivity. Values are measured under matched resolution and post-processing. Latency is wall-clock evaluation time per image from the cached-bank worker run.}",
        r"\label{tab:efficiency_bank_budget}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.2pt}",
        r"\renewcommand{\arraystretch}{1.03}",
        r"\resizebox{\linewidth}{!}{%",
        r"\begin{tabular}{llrrrrrrr}",
        r"\toprule",
        r"Host & Transfer & Budget & Bank & ms/img & Mem & B PRO/AP & T PRO/AP & C PRO/AP \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(
            f"{row['host']} & {row['transfer']} & {row['budget']} & {row['retained_bank']} & "
            f"{fmt(row['latency_ms_per_image'], 1)} & {fmt(row['peak_gpu_mem_mb'], 0)} & "
            f"{fmt(row['base_pro'], 1)}/{fmt(row['base_ap'], 1)} & "
            f"{fmt(row['t_pro'], 1)}/{fmt(row['t_ap'], 1)} & "
            f"{fmt(row['c_pro'], 1)}/{fmt(row['c_ap'], 1)} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}%", r"}", r"\end{table}"])
    tex_path.write_text("\n".join(lines) + "\n")
    print(json.dumps({"rows": len(rows), "csv": str(csv_path), "tex": str(tex_path)}, indent=2))


def main() -> int:
    rows = []
    for run_dir in sorted(RUN_ROOT.iterdir() if RUN_ROOT.exists() else []):
        if run_dir.is_dir():
            row = extract_row(run_dir)
            if row is not None:
                rows.append(row)
    rows.sort(key=lambda r: (r["host"], r["transfer"], r["budget"]))
    write_outputs(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
