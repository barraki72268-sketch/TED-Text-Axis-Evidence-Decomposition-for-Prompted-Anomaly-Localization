from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

import AnomalyCLIP_lib  # noqa: E402
from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402
from region_descriptor_utils import (  # noqa: E402
    FEATURE_NAMES,
    extract_region_descriptor,
    iterate_components,
    rows_to_matrix,
    save_json,
    save_rows,
)
from utils import get_transform  # noqa: E402


COMBOS = [
    ["peak", "area"],
    ["peak", "mean"],
    ["peak", "top10_mean"],
    ["peak", "fill_ratio"],
    ["peak", "compactness"],
    ["peak", "ring_contrast"],
    ["peak", "area", "fill_ratio"],
    ["peak", "mean", "area", "fill_ratio", "compactness", "ring_contrast"],
]


def build_dataset(root: str, image_size: int, mode: str):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode=mode)


def build_model(device: str, checkpoint_path: str, image_size: int, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)

    prompt_learner = FAPrompt(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    model.to(device)
    prompt_learner.eval()
    model.eval()
    return model, prompt_learner


def compute_map(model, prompt_learner, image: torch.Tensor, features_list: list[int], image_size: int, sigma: int):
    image_features, patch_features = model.encode_image(image, features_list, DPAM_layer=20)
    image_features = image_features / image_features.norm(dim=-1, keepdim=True)
    patch_features = patch_features / patch_features.norm(dim=-1, keepdim=True)
    prompts_pos, prompts_neg, tokenized_prompts_pos, tokenized_prompts_neg, compound_prompts_text, _ = prompt_learner.forward()
    text_features_pos = model.encode_text_learn(prompts_pos, tokenized_prompts_pos, compound_prompts_text).float()
    text_features_neg = model.encode_text_learn(prompts_neg, tokenized_prompts_neg, compound_prompts_text).float()
    text_features_neg = torch.mean(text_features_neg, dim=0, keepdim=True)
    text_features = torch.cat([text_features_pos, text_features_neg])
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    similarity, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_features[0])
    similarity_map1 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], image_size).squeeze(0)

    num = min(10, similarity[1:, :, 1].shape[0])
    pk_indx = torch.topk(similarity[1:, :, 1], k=num, dim=0, largest=True, sorted=True).indices
    pk_indx = pk_indx.permute(1, 0)
    selected_tokens = []
    for i in range(len(pk_indx)):
        selected_tokens2 = []
        for k in range(len(pk_indx[0])):
            tmp_token = patch_features[1:, :, :].permute(1, 0, 2)[i, k, :]
            selected_tokens2.append(tmp_token)
        selected_tokens2 = torch.stack(selected_tokens2)
        selected_tokens.append(selected_tokens2)
    selected_tokens = torch.stack(selected_tokens)

    text_features_list = []
    for i in range(selected_tokens.shape[0]):
        p_pos, p_neg, tok_pos, tok_neg, comp_text, _ = prompt_learner.forward(selected_tokens=selected_tokens[i])
        tf_pos = model.encode_text_learn(p_pos, tok_pos, comp_text).float()
        tf_neg = model.encode_text_learn(p_neg, tok_neg, comp_text).float()
        tf_neg = torch.mean(tf_neg, dim=0, keepdim=True)
        tf = torch.cat([tf_pos, tf_neg])
        text_features_list.append(tf)
    text_features = torch.stack(text_features_list)
    text_features = text_features / text_features.norm(dim=-1, keepdim=True)

    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_features, text_features)
    similarity_map2 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], image_size).squeeze(0)
    anomaly_map = (similarity_map1[1, :] + 1 - similarity_map1[0, :] + similarity_map2[1, :] + 1 - similarity_map2[0, :]) / 4.0
    return gaussian_filter(anomaly_map.detach().cpu().numpy(), sigma=sigma)


def collect_rows(model, prompt_learner, dataset, features_list, image_size, sigma, device, top_fracs, min_area, max_per_class, bank_name: str):
    per_class = {cls_name: 0 for cls_name in dataset.cls_names}
    rows = []
    with torch.no_grad():
        for img_idx in range(len(dataset)):
            item = dataset[img_idx]
            cls_name = item["cls_name"]
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            anomaly_flag = int(anomaly_flag)
            if bank_name == "fp" and anomaly_flag != 0:
                continue
            if bank_name == "defect" and anomaly_flag == 0:
                continue
            if per_class[cls_name] >= max_per_class:
                continue
            per_class[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            anomaly_map = compute_map(model, prompt_learner, image, features_list, image_size, sigma)
            if bank_name == "fp":
                for frac in top_fracs:
                    mask = top_fraction_mask(anomaly_map, frac)
                    for comp in iterate_components(mask):
                        if int(comp.sum()) < min_area:
                            continue
                        desc = extract_region_descriptor(anomaly_map, comp)
                        if not desc:
                            continue
                        desc.update({"bank": "fp", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": frac})
                        rows.append(desc)
            else:
                gt_mask = item["img_mask"][0].numpy() > 0.5
                for comp in iterate_components(gt_mask):
                    if int(comp.sum()) < min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    desc.update({"bank": "defect", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": -1.0})
                    rows.append(desc)
            if (img_idx + 1) % 50 == 0:
                print(json.dumps({f"{bank_name}_bank_progress": img_idx + 1, "num_regions": len(rows)}), flush=True)
    return rows


def compute_holdout_summary(fp_rows: list[dict], defect_rows: list[dict]):
    classes = sorted(set(row["cls_name"] for row in fp_rows) & set(row["cls_name"] for row in defect_rows))
    name_to_idx = {name: i for i, name in enumerate(FEATURE_NAMES)}
    holdout_rows = []
    for heldout in classes:
        fp_train = [row for row in fp_rows if row["cls_name"] != heldout]
        df_train = [row for row in defect_rows if row["cls_name"] != heldout]
        fp_eval = [row for row in fp_rows if row["cls_name"] == heldout]
        df_eval = [row for row in defect_rows if row["cls_name"] == heldout]
        if not fp_train or not df_train or not fp_eval or not df_eval:
            continue
        X_train = np.concatenate([rows_to_matrix(fp_train, FEATURE_NAMES), rows_to_matrix(df_train, FEATURE_NAMES)], axis=0)
        y_train = np.concatenate([np.zeros(len(fp_train), dtype=np.int64), np.ones(len(df_train), dtype=np.int64)], axis=0)
        X_eval = np.concatenate([rows_to_matrix(fp_eval, FEATURE_NAMES), rows_to_matrix(df_eval, FEATURE_NAMES)], axis=0)
        y_eval = np.concatenate([np.zeros(len(fp_eval), dtype=np.int64), np.ones(len(df_eval), dtype=np.int64)], axis=0)

        for feat_idx, feature_name in enumerate(FEATURE_NAMES):
            auc = roc_auc_score(y_eval, X_eval[:, feat_idx])
            eff_auc = max(float(auc), float(1.0 - auc))
            direction = "defect_high" if auc >= 0.5 else "fp_high"
            holdout_rows.append({"heldout_class": heldout, "kind": "single", "name": feature_name, "auc_eval": eff_auc, "direction": direction})

        for combo in COMBOS:
            idxs = [name_to_idx[c] for c in combo]
            clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
            clf.fit(X_train[:, idxs], y_train)
            pred = clf.predict_proba(X_eval[:, idxs])[:, 1]
            auc = roc_auc_score(y_eval, pred)
            holdout_rows.append({"heldout_class": heldout, "kind": "combo", "name": "+".join(combo), "auc_eval": float(auc), "direction": "defect_high"})

    def aggregate(rows: list[dict]):
        grouped: dict[str, list[float]] = {}
        for row in rows:
            grouped.setdefault(row["name"], []).append(float(row["auc_eval"]))
        out = []
        for name, vals in grouped.items():
            out.append({"name": name, "mean_auc": float(np.mean(vals)), "std_auc": float(np.std(vals)), "num_holdouts": len(vals)})
        out.sort(key=lambda x: x["mean_auc"], reverse=True)
        return out

    single_rows = [row for row in holdout_rows if row["kind"] == "single"]
    combo_rows = [row for row in holdout_rows if row["kind"] == "combo"]
    return {
        "num_fp_regions": len(fp_rows),
        "num_defect_regions": len(defect_rows),
        "single_summary": aggregate(single_rows),
        "combo_summary": aggregate(combo_rows),
        "holdout_rows": holdout_rows,
    }


def main():
    parser = argparse.ArgumentParser("Build FAPrompt source region banks and leave-one-class-out descriptor sanity")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_baseline_mvtec" / "checkpoints" / "epoch_15.pth"),
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--top_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--max_per_class_fp", type=int, default=200)
    parser.add_argument("--max_per_class_defect", type=int, default=80)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_region_bank_holdout_epoch15"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    model, prompt_learner = build_model(args.device, args.checkpoint_path, args.image_size, args.depth, args.n_ctx, args.t_n_ctx)
    train_dataset = build_dataset(args.source_root, args.image_size, mode="train")
    test_dataset = build_dataset(args.source_root, args.image_size, mode="test")

    fp_rows = collect_rows(
        model, prompt_learner, train_dataset, args.features_list, args.image_size, args.sigma, args.device,
        args.top_fracs, args.min_area, args.max_per_class_fp, "fp",
    )
    save_rows(fp_rows, Path(args.save_dir) / "fp_rows.csv")
    defect_rows = collect_rows(
        model, prompt_learner, test_dataset, args.features_list, args.image_size, args.sigma, args.device,
        args.top_fracs, args.min_area, args.max_per_class_defect, "defect",
    )
    save_rows(defect_rows, Path(args.save_dir) / "defect_rows.csv")

    summary = compute_holdout_summary(fp_rows, defect_rows)
    save_rows(summary["single_summary"], Path(args.save_dir) / "single_summary.csv")
    save_rows(summary["combo_summary"], Path(args.save_dir) / "combo_summary.csv")
    save_rows(summary["holdout_rows"], Path(args.save_dir) / "holdout_rows.csv")
    save_json(summary, Path(args.save_dir) / "summary.json")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
