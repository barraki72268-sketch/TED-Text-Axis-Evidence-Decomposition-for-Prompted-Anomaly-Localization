#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import roc_auc_score


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RESULTS = ROOT / "neurips2026" / "results"

C_DEFECT = "#D64A2F"
C_HARD = "#2878A7"
C_DARK = "#202020"


def zscore(x: np.ndarray) -> np.ndarray:
    return (x - float(np.mean(x))) / max(float(np.std(x)), 1e-6)


def logmeanexp_negative_sqdist(query: np.ndarray, bank: np.ndarray, tau: float) -> np.ndarray:
    if bank.size == 0:
        return np.full((query.shape[0],), -20.0, dtype=np.float32)
    dist = ((query[:, None, :] - bank[None, :, :]) ** 2).sum(axis=-1)
    logits = -dist / max(float(tau), 1e-6)
    m = logits.max(axis=1, keepdims=True)
    return (m[:, 0] + np.log(np.exp(logits - m).mean(axis=1))).astype(np.float32)


def auc(labels: np.ndarray, scores: np.ndarray) -> float:
    return float(roc_auc_score(labels.astype(np.int32), scores.astype(np.float32)))


def candidate_npz_paths(results_dir: Path, class_name: str | None) -> list[Path]:
    paths = sorted(results_dir.glob("faprompt_ted_story_vitl336_visa2mvtec_*/scores_with_trace_vitl336.npz"))
    if class_name:
        paths = [p for p in paths if f"_{class_name}" in p.parent.name or p.parent.name.endswith(class_name)]
    return paths


def load_candidate(path: Path, tau: float) -> dict | None:
    arr = np.load(path, allow_pickle=True)
    required = {"labels", "support_xy", "source_support_xy", "source_labels"}
    if not required.issubset(set(arr.files)):
        return None
    labels = arr["labels"].astype(np.int32)
    support_xy = arr["support_xy"].astype(np.float32)
    source_xy = arr["source_support_xy"].astype(np.float32)
    source_labels = arr["source_labels"].astype(np.int32)
    defect_bank = source_xy[source_labels == 1]
    hard_bank = source_xy[source_labels == 0]
    q_def = logmeanexp_negative_sqdist(support_xy, defect_bank, tau=tau)
    q_hard = logmeanexp_negative_sqdist(support_xy, hard_bank, tau=tau)
    without_hard = q_def
    with_hard = q_def - q_hard
    with_auc = auc(labels, with_hard)
    if with_auc < 0.5:
        with_hard = -with_hard
        with_auc = 1.0 - with_auc
    without_auc = auc(labels, without_hard)
    return {
        "path": str(path),
        "class_name": path.parent.name.replace("faprompt_ted_story_vitl336_visa2mvtec_", "").replace("_alpha15", ""),
        "labels": labels,
        "without_hard": without_hard,
        "with_hard": with_hard,
        "q_def": q_def,
        "q_hard": q_hard,
        "without_auc": without_auc,
        "with_auc": with_auc,
        "improvement": with_auc - without_auc,
        "without_gap": float(np.median(without_hard[labels == 1]) - np.median(without_hard[labels == 0])),
        "with_gap": float(np.median(with_hard[labels == 1]) - np.median(with_hard[labels == 0])),
        "num_defect": int((labels == 1).sum()),
        "num_hard": int((labels == 0).sum()),
    }


def pick_candidate(results_dir: Path, class_name: str | None, tau: float) -> dict:
    candidates = []
    for path in candidate_npz_paths(results_dir, class_name):
        loaded = load_candidate(path, tau=tau)
        if loaded is not None:
            candidates.append(loaded)
    if not candidates:
        raise FileNotFoundError("No compatible scores_with_trace_vitl336.npz file found.")
    return max(candidates, key=lambda x: (x["improvement"], x["with_auc"]))


def draw_score_strip(
    ax,
    scores: np.ndarray,
    labels: np.ndarray,
    title: str,
    auc_value: float,
    rng: np.random.Generator,
    show_gap: bool,
) -> dict:
    x = zscore(scores)
    keep = []
    for lab in (0, 1):
        idx = np.where(labels == lab)[0]
        if idx.size:
            keep.append(rng.choice(idx, size=min(300, idx.size), replace=False))
    keep = np.concatenate(keep) if keep else np.arange(labels.size)
    jitter = rng.normal(0.0, 0.040, size=keep.shape[0]).astype(np.float32)
    xlo, xhi = np.quantile(x[keep], [0.04, 0.96])
    pad = 0.12 * max(float(xhi - xlo), 1e-6)
    xlo = float(xlo - pad)
    xhi = float(xhi + pad)

    for lab, color, marker, label, size, alpha in [
        (0, C_HARD, "o", "hard normal", 42, 0.70),
        (1, C_DEFECT, "^", "defect", 58, 0.84),
    ]:
        idx = keep[labels[keep] == lab]
        pos = np.isin(keep, idx)
        visible = (x[idx] >= xlo) & (x[idx] <= xhi)
        ax.scatter(
            x[idx][visible],
            jitter[pos][visible],
            s=size,
            c=color,
            marker=marker,
            alpha=alpha,
            edgecolors="white",
            linewidths=0.55,
            label=label,
            zorder=4 if lab else 3,
        )

    defect_med = float(np.median(x[labels == 1]))
    hard_med = float(np.median(x[labels == 0]))
    ax.axvline(defect_med, color=C_DEFECT, lw=2.2, ls="--", alpha=0.82)
    ax.axvline(hard_med, color=C_HARD, lw=2.2, ls="-", alpha=0.74)
    ax.axhline(0, color=C_DARK, lw=1.0, alpha=0.18)
    if title:
        ax.set_title(title, fontsize=13.8, fontweight="bold", pad=8)
    ax.set_xlabel("normalized patch score", fontsize=11.5, fontweight="bold", labelpad=7)
    ax.set_yticks([])
    ax.tick_params(axis="x", labelsize=10.5, width=1.2)
    ax.grid(axis="x", alpha=0.13)
    ax.set_xlim(xlo, xhi)
    ax.set_ylim(-0.22, 0.22)
    return {
        "median_defect": defect_med,
        "median_hard_normal": hard_med,
        "median_gap": defect_med - hard_med,
    }


def draw_summary_panel(ax, case: dict, left_stats: dict, right_stats: dict, *, show_title: bool = True) -> None:
    auc_values = [case["without_auc"], case["with_auc"]]
    gap_values = [left_stats["median_gap"], right_stats["median_gap"]]
    x = np.arange(2, dtype=np.float32)
    width = 0.34
    colors = ["#B8B8B8", "#2A7F62"]
    grouped_values = np.asarray(
        [
            [auc_values[0], gap_values[0]],
            [auc_values[1], gap_values[1]],
        ],
        dtype=np.float32,
    )
    for offset, values, color in [
        (-width / 2, grouped_values[0], colors[0]),
        (width / 2, grouped_values[1], colors[1]),
    ]:
        bars = ax.bar(x + offset, values, width=width, color=color, alpha=0.94, zorder=3)
        for bar, value in zip(bars, values):
            va = "bottom" if value >= 0 else "top"
            y = value + (0.04 if value >= 0 else -0.04)
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                y,
                f"{value:.2f}",
                ha="center",
                va=va,
                fontsize=9.2,
                fontweight="bold",
            )
    ax.axhline(0, color=C_DARK, lw=1.0, alpha=0.28)
    if show_title:
        ax.set_title("separation gain", fontsize=13.2, fontweight="bold", pad=8)
    ax.set_xticks(x)
    ax.set_xticklabels(["AUC", "median\ngap"], fontsize=10.4, fontweight="bold")
    ax.set_ylabel("value", fontsize=9.5, fontweight="bold", labelpad=2)
    ax.tick_params(axis="y", labelsize=8.8, width=1.0)
    ax.set_ylim(-0.14, 1.00)
    ax.grid(axis="y", alpha=0.13, zorder=0)
    ax.plot([0.50, 0.62], [0.92, 0.92], transform=ax.transAxes, color=colors[0], lw=5.6, solid_capstyle="butt")
    ax.text(0.65, 0.92, "w/o H-FP", transform=ax.transAxes, ha="left", va="center", fontsize=8.7, fontweight="bold")
    ax.plot([0.50, 0.62], [0.82, 0.82], transform=ax.transAxes, color=colors[1], lw=5.6, solid_capstyle="butt")
    ax.text(0.65, 0.82, "w/ H-FP", transform=ax.transAxes, ha="left", va="center", fontsize=8.7, fontweight="bold")


def draw_scatter(case: dict, out_dir: Path) -> dict:
    labels = case["labels"]
    rng = np.random.default_rng(7)

    plt.rcParams.update({"axes.linewidth": 1.3, "font.family": "DejaVu Sans"})
    fig, axs = plt.subplots(1, 2, figsize=(8.4, 3.35), sharey=True)
    left_stats = draw_score_strip(
        axs[0],
        case["without_hard"],
        labels,
        "w/o hard-FP support",
        case["without_auc"],
        rng,
        show_gap=False,
    )
    right_stats = draw_score_strip(
        axs[1],
        case["with_hard"],
        labels,
        "with hard-FP support",
        case["with_auc"],
        rng,
        show_gap=True,
    )
    axs[1].legend(frameon=False, fontsize=9.8, loc="lower right", handletextpad=0.30, borderpad=0.2)
    fig.suptitle("Hard-FP evidence separates ambiguous defect support", fontsize=14.5, fontweight="bold", y=1.02)
    fig.subplots_adjust(left=0.055, right=0.995, top=0.77, bottom=0.20, wspace=0.13)

    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"ted_wo_vs_w_scatter_{case['class_name']}"
    png = out_dir / f"{stem}.png"
    pdf = out_dir / f"{stem}.pdf"
    fig.savefig(png, dpi=270, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {"png": str(png), "pdf": str(pdf), "left_stats": left_stats, "right_stats": right_stats}


def draw_scatter_with_summary(case: dict, out_dir: Path) -> dict:
    labels = case["labels"]
    rng = np.random.default_rng(7)

    plt.rcParams.update({"axes.linewidth": 1.3, "font.family": "DejaVu Sans"})
    fig, axs = plt.subplots(
        1,
        3,
        figsize=(10.8, 3.05),
        gridspec_kw={"width_ratios": [1.0, 1.0, 0.60]},
    )
    left_stats = draw_score_strip(
        axs[0],
        case["without_hard"],
        labels,
        "(a) w/o hard-FP support",
        case["without_auc"],
        rng,
        show_gap=False,
    )
    right_stats = draw_score_strip(
        axs[1],
        case["with_hard"],
        labels,
        "(b) with hard-FP support",
        case["with_auc"],
        rng,
        show_gap=True,
    )
    axs[1].legend(frameon=False, fontsize=8.8, loc="lower right", handletextpad=0.25, borderpad=0.2)
    draw_summary_panel(axs[2], case, left_stats, right_stats)
    axs[2].set_title("(c) separation gain", fontsize=13.2, fontweight="bold", pad=8)
    fig.subplots_adjust(left=0.046, right=0.995, top=0.83, bottom=0.24, wspace=0.15)

    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"ted_wo_vs_w_scatter_{case['class_name']}_summary"
    png = out_dir / f"{stem}.png"
    pdf = out_dir / f"{stem}.pdf"
    fig.savefig(png, dpi=270, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return {
        "summary_png": str(png),
        "summary_pdf": str(pdf),
        "summary_left_stats": left_stats,
        "summary_right_stats": right_stats,
    }


def draw_split_panels(case: dict, out_dir: Path) -> dict:
    labels = case["labels"]
    out_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"axes.linewidth": 1.3, "font.family": "DejaVu Sans"})

    rng = np.random.default_rng(7)
    fig_a, ax_a = plt.subplots(1, 1, figsize=(4.7, 3.05))
    left_stats = draw_score_strip(
        ax_a,
        case["without_hard"],
        labels,
        "",
        case["without_auc"],
        rng,
        show_gap=False,
    )
    fig_a.subplots_adjust(left=0.08, right=0.99, top=0.98, bottom=0.24)
    a_png = out_dir / f"ted_wo_vs_w_scatter_{case['class_name']}_a_without_hardfp.png"
    a_pdf = out_dir / f"ted_wo_vs_w_scatter_{case['class_name']}_a_without_hardfp.pdf"
    fig_a.savefig(a_png, dpi=270, bbox_inches="tight")
    fig_a.savefig(a_pdf, bbox_inches="tight")
    plt.close(fig_a)

    rng = np.random.default_rng(7)
    fig_b, ax_b = plt.subplots(1, 1, figsize=(4.7, 3.05))
    right_stats = draw_score_strip(
        ax_b,
        case["with_hard"],
        labels,
        "",
        case["with_auc"],
        rng,
        show_gap=True,
    )
    ax_b.legend(frameon=False, fontsize=9.2, loc="lower right", handletextpad=0.25, borderpad=0.2)
    fig_b.subplots_adjust(left=0.08, right=0.99, top=0.98, bottom=0.24)
    b_png = out_dir / f"ted_wo_vs_w_scatter_{case['class_name']}_b_with_hardfp.png"
    b_pdf = out_dir / f"ted_wo_vs_w_scatter_{case['class_name']}_b_with_hardfp.pdf"
    fig_b.savefig(b_png, dpi=270, bbox_inches="tight")
    fig_b.savefig(b_pdf, bbox_inches="tight")
    plt.close(fig_b)

    fig_c, ax_c = plt.subplots(1, 1, figsize=(3.0, 3.05))
    draw_summary_panel(ax_c, case, left_stats, right_stats, show_title=False)
    fig_c.subplots_adjust(left=0.20, right=0.99, top=0.98, bottom=0.24)
    c_png = out_dir / f"ted_wo_vs_w_scatter_{case['class_name']}_c_separation_gain.png"
    c_pdf = out_dir / f"ted_wo_vs_w_scatter_{case['class_name']}_c_separation_gain.pdf"
    fig_c.savefig(c_png, dpi=270, bbox_inches="tight")
    fig_c.savefig(c_pdf, bbox_inches="tight")
    plt.close(fig_c)

    return {
        "panel_a_png": str(a_png),
        "panel_a_pdf": str(a_pdf),
        "panel_b_png": str(b_png),
        "panel_b_pdf": str(b_pdf),
        "panel_c_png": str(c_png),
        "panel_c_pdf": str(c_pdf),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results_dir", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--save_dir", type=Path, default=DEFAULT_RESULTS / "ted_wo_vs_w_scatter")
    parser.add_argument("--class_name", type=str, default="capsule")
    parser.add_argument("--tau", type=float, default=0.35)
    args = parser.parse_args()

    case = pick_candidate(args.results_dir, args.class_name, tau=args.tau)
    outputs = draw_scatter(case, args.save_dir)
    summary_outputs = draw_scatter_with_summary(case, args.save_dir)
    split_outputs = draw_split_panels(case, args.save_dir)
    summary = {
        "source_npz": case["path"],
        "class_name": case["class_name"],
        "tau": args.tau,
        "num_defect": case["num_defect"],
        "num_hard": case["num_hard"],
        "without_hard_fp_auc": case["without_auc"],
        "with_hard_fp_auc": case["with_auc"],
        "auc_improvement": case["improvement"],
        "without_median_gap": case["without_gap"],
        "with_median_gap": case["with_gap"],
        **outputs,
        **summary_outputs,
        **split_outputs,
    }
    with (args.save_dir / "summary.json").open("w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
