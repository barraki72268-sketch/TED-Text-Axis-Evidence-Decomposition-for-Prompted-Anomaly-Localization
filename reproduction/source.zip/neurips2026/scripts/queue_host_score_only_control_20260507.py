#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "host_score_only_control_20260507"
LOGS = ROOT / "neurips2026" / "logs" / "host_score_only_control_20260507"

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADACLIP_MVTEC_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"
ADACLIP_VISA_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"
ADAPT_MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
ADAPT_VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"

DATASETS = {
    "mvtec": MVTEC_ROOT,
    "visa": VISA_ROOT,
    "mpdd": MPDD_ROOT,
    "btad": BTAD_ROOT,
}


def split_preset(preset: str) -> tuple[str, str]:
    source, target = preset.split("2", 1)
    if source not in {"mvtec", "visa"} or target not in DATASETS:
        raise SystemExit(f"Unsupported preset={preset}")
    return source, target


def faprompt_cmd(preset: str, device: str, seed: int, save_dir: Path) -> list[str]:
    return [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "plugin_replace,plugin_residual,branch_calibrated",
        "--plugin_epochs",
        "40",
        "--plugin_lr",
        "0.01",
        "--plugin_max_train_points",
        "4096",
        "--plugin_loss",
        "pair_rank",
        "--plugin_feature_space",
        "hostscore",
        "--plugin_rank_margin",
        "0.05",
        "--plugin_rank_temp",
        "0.05",
        "--plugin_hidden_dim",
        "16",
        "--plugin_gate_topk_frac",
        "0.10",
        "--plugin_gate_sharpness",
        "6.0",
        "--plugin_ambiguity_temp",
        "0.5",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]


def aaclip_cmd(preset: str, device: str, seed: int, save_dir: Path) -> list[str]:
    return [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=0.5",
        "--blend_modes",
        "plugin_replace,plugin_residual,prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--plugin_epochs",
        "40",
        "--plugin_lr",
        "0.01",
        "--plugin_max_train_points",
        "8192",
        "--plugin_loss",
        "host_rank",
        "--plugin_rank_margin",
        "0.05",
        "--plugin_rank_temp",
        "0.05",
        "--plugin_hidden_dim",
        "16",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]


def adaclip_cmd(preset: str, device: str, seed: int, save_dir: Path) -> list[str]:
    source, target = split_preset(preset)
    ckpt = ADACLIP_VISA_CKPT if source == "visa" else ADACLIP_MVTEC_CKPT
    bank = ROOT / "neurips2026" / "results" / "bank_cache" / (
        "adaclip_visa_official1cls_multilayer.pt" if source == "visa" else "adaclip_mvtec_full_multilayer.pt"
    )
    return [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaclip.py",
        "--source_root",
        str(DATASETS[source]),
        "--source_dataset",
        source,
        "--target_root",
        str(DATASETS[target]),
        "--target_dataset",
        target,
        "--checkpoint_path",
        str(ckpt),
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
        "--bank_cache_path",
        str(bank),
        "--backbone",
        "ViT-L-14-336",
        "--checkpoint_load_mode",
        "strict",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--prompting_depth",
        "4",
        "--prompting_length",
        "5",
        "--prompting_branch",
        "VL",
        "--prompting_type",
        "SD",
        "--use_hsf",
        "true",
        "--k_clusters",
        "20",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--layer_recipe",
        "all4",
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "2",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_subspace_basis_control",
        "source",
        "--calib_pair_label_control",
        "correct",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_gate_mode",
        "host",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--scoring_mode",
        "logit_gate_posneg",
        "--plugin_epochs",
        "40",
        "--plugin_lr",
        "0.01",
        "--plugin_max_train_points",
        "4096",
        "--plugin_hardpair_frac",
        "0.0",
        "--plugin_alpha",
        "0.5",
        "--plugin_loss",
        "pair_rank",
        "--plugin_feature_space",
        "hostscore",
        "--plugin_hidden_dim",
        "16",
        "--plugin_rank_margin",
        "0.05",
        "--plugin_rank_temp",
        "0.05",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--image_topk_frac",
        "0.01",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--seed",
        str(seed),
        "--device",
        device,
    ]


def adaptclip_cmd(preset: str, device: str, seed: int, save_dir: Path) -> list[str]:
    source, target = split_preset(preset)
    ckpt = ADAPT_VISA_CKPT if source == "visa" else ADAPT_MVTEC_CKPT
    bank_cache = ROOT / "neurips2026" / "results" / "bank_cache" / f"adaptclip_hostscore_{source}_vl_last24_seed{seed}.pt"
    return [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaptclip_vlrefine.py",
        "--source_root",
        str(DATASETS[source]),
        "--source_dataset",
        source,
        "--target_root",
        str(DATASETS[target]),
        "--target_dataset",
        target,
        "--checkpoint_path",
        str(ckpt),
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
        "--bank_cache_path",
        str(bank_cache),
        "--pretrained_model",
        "ViT-L/14@336px",
        "--checkpoint_load_mode",
        "strict",
        "--features_list",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "8",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--corr_alpha",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_pair_label_control",
        "correct",
        "--plugin_epochs",
        "40",
        "--plugin_lr",
        "0.01",
        "--plugin_max_train_points",
        "4096",
        "--plugin_hardpair_frac",
        "0.0",
        "--plugin_alpha",
        "0.5",
        "--plugin_loss",
        "pair_rank",
        "--plugin_feature_space",
        "hostscore",
        "--plugin_hidden_dim",
        "16",
        "--plugin_rank_margin",
        "0.05",
        "--plugin_rank_temp",
        "0.05",
        "--seed",
        str(seed),
        "--device",
        device,
        "--num_workers",
        "4",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
    ]


def build_jobs(hosts: list[str], presets: list[str], devices: list[str], seed: int) -> list[dict]:
    jobs = []
    for preset in presets:
        if "faprompt" in hosts:
            save_dir = RESULTS / f"faprompt_vitl336_{preset}_hostscore_rank_seed{seed}"
            jobs.append({
                "host": "faprompt",
                "preset": preset,
                "cmd": faprompt_cmd(preset, devices[len(jobs) % len(devices)], seed, save_dir),
                "save_dir": save_dir,
            })
        if "aaclip" in hosts:
            save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_hostscore_rank_seed{seed}"
            jobs.append({
                "host": "aaclip",
                "preset": preset,
                "cmd": aaclip_cmd(preset, devices[len(jobs) % len(devices)], seed, save_dir),
                "save_dir": save_dir,
            })
        if "adaclip" in hosts:
            save_dir = RESULTS / f"adaclip_vitl336_{preset}_hostscore_rank_seed{seed}"
            jobs.append({
                "host": "adaclip",
                "preset": preset,
                "cmd": adaclip_cmd(preset, devices[len(jobs) % len(devices)], seed, save_dir),
                "save_dir": save_dir,
            })
        if "adaptclip" in hosts:
            save_dir = RESULTS / f"adaptclip_vl_last24_{preset}_hostscore_rank_seed{seed}"
            jobs.append({
                "host": "adaptclip",
                "preset": preset,
                "cmd": adaptclip_cmd(preset, devices[len(jobs) % len(devices)], seed, save_dir),
                "save_dir": save_dir,
            })
    return jobs


def write_worker(jobs: list[dict], worker_id: int, force: bool) -> Path:
    worker_path = LOGS / f"worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess, time",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        f"FORCE = {bool(force)!r}",
        "jobs = [",
    ]
    for job in jobs:
        log_path = LOGS / f"{job['save_dir'].name}.log"
        lines.append(
            "    "
            + repr({
                "host": job["host"],
                "preset": job["preset"],
                "cmd": job["cmd"],
                "save_dir": str(job["save_dir"]),
                "log_path": str(log_path),
            })
            + ","
        )
    lines += [
        "]",
        "for job in jobs:",
        "    save_dir = Path(job['save_dir'])",
        "    summary = save_dir / 'summary.json'",
        "    log_path = Path(job['log_path'])",
        "    log_path.parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists() and not FORCE:",
        "        print({'stage': 'skip_done', **{k: job[k] for k in ('host', 'preset')}, 'summary': str(summary)}, flush=True)",
        "        continue",
        "    save_dir.mkdir(parents=True, exist_ok=True)",
        "    print({'stage': 'job_start', **{k: job[k] for k in ('host', 'preset')}, 'save_dir': str(save_dir), 'log': str(log_path)}, flush=True)",
        "    start = time.time()",
        "    with log_path.open('w') as f:",
        "        proc = subprocess.run(job['cmd'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)",
        "    print({'stage': 'job_done', **{k: job[k] for k in ('host', 'preset')}, 'returncode': proc.returncode, 'elapsed_sec': time.time() - start}, flush=True)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    worker_path.write_text("\n".join(lines))
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="faprompt,aaclip")
    ap.add_argument("--presets", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = [x.strip().lower() for x in args.hosts.split(",") if x.strip()]
    presets = [x.strip().lower() for x in args.presets.split(",") if x.strip()]
    devices = [x.strip() for x in args.devices.split(",") if x.strip()]
    unknown_hosts = set(hosts) - {"faprompt", "aaclip", "adaclip", "adaptclip"}
    unknown_presets = set(presets) - set(PRESETS)
    if unknown_hosts:
        raise SystemExit(f"Unknown hosts={sorted(unknown_hosts)}")
    if unknown_presets:
        raise SystemExit(f"Unknown presets={sorted(unknown_presets)}")
    if not devices:
        raise SystemExit("No devices provided")

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    jobs = build_jobs(hosts, presets, devices, args.seed)
    buckets = [[] for _ in devices]
    for idx, job in enumerate(jobs):
        buckets[idx % len(buckets)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        worker_path = write_worker(bucket, worker_id, args.force)
        worker_log = LOGS / f"worker_{worker_id}.log"
        with worker_log.open("a") as f:
            proc = subprocess.Popen([str(PY), "-u", str(worker_path)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "worker": str(worker_path), "log": str(worker_log)})

    print(json.dumps({"stage": "queued_host_score_only_control", "launched": launched, "num_jobs": len(jobs)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
