from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import RiemannianLowRankRefiner
from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader
from utils.eval_utils import specify_resolution
from utils.metrics import cal_pro_metric


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--refiner_ckpt", type=str, required=True)
    parser.add_argument("--target_layer", type=int, default=6)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--geo_lambda", type=float, default=0.5)
    parser.add_argument("--img_topk_ratio", type=float, default=0.05)
    parser.add_argument("--no_pro", action="store_true")
    parser.add_argument("--output_tag", type=str, default="backbone_l6_geometric_score")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(backbone, batch_np) -> torch.Tensor:
    imgs = [backbone.transform_pil(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(backbone.device)


def load_refiner(ckpt_path: str, device: torch.device) -> tuple[RiemannianLowRankRefiner, dict]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload["refiner_config"]
    refiner = RiemannianLowRankRefiner(
        feature_dim=int(config["feature_dim"]),
        kernel_size=int(config["kernel_size"]),
        topk_ratio=float(config["topk_ratio"]),
        rank=int(config["rank"]),
        hidden_dim=int(config["hidden_dim"]),
        dropout=float(config["dropout"]),
        lambda_max=float(config.get("lambda_max", 2.0)),
    ).to(device)
    refiner.load_state_dict(payload["model_state_dict"], strict=True)
    refiner.eval()
    return refiner, config


@torch.no_grad()
def build_class_prototype(
    backbone,
    loader,
    target_layer: int,
    refiner: RiemannianLowRankRefiner | None,
    num_steps: int,
) -> torch.Tensor:
    feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        images = _preprocess_batch(backbone, data)
        tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        if refiner is not None:
            out = refiner(tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps)
            tokens = out.refined
        feats.append(F.normalize(tokens[normal_idx].float(), dim=-1))
    if not feats:
        raise RuntimeError("No normal train features found for prototype.")
    proto = torch.cat(feats, dim=0).mean(dim=0, keepdim=True)
    return F.normalize(proto, dim=-1)


def compute_image_scores(score_maps: np.ndarray, topk_ratio: float) -> np.ndarray:
    flat = score_maps.reshape(score_maps.shape[0], -1)
    k = max(1, int(math.ceil(flat.shape[1] * topk_ratio)))
    part = np.partition(flat, flat.shape[1] - k, axis=1)[:, -k:]
    return part.mean(axis=1)


def metric_summary(
    score_maps: np.ndarray,
    gt_list: list[int],
    gt_mask_list: list[np.ndarray],
    *,
    topk_ratio: float,
    cal_pro: bool,
) -> dict[str, float]:
    gt = np.asarray(gt_list, dtype=int)
    gt_mask = np.asarray(gt_mask_list, dtype=int)
    img_scores = compute_image_scores(score_maps, topk_ratio=topk_ratio)
    i_roc = roc_auc_score(gt, img_scores) * 100.0
    p_roc = roc_auc_score(gt_mask.flatten(), score_maps.flatten()) * 100.0
    p_pro = cal_pro_metric(gt_mask_list, score_maps, fpr_thresh=0.3) * 100.0 if cal_pro else 0.0
    return {"i_roc": float(i_roc), "p_roc": float(p_roc), "p_pro": float(p_pro)}


@torch.no_grad()
def evaluate_variants(
    backbone,
    loader,
    target_layer: int,
    raw_prototype: torch.Tensor,
    refined_prototype: torch.Tensor,
    refiner: RiemannianLowRankRefiner,
    *,
    num_steps: int,
    resolution: int,
    topk_ratio: float,
    geo_lambda: float,
    cal_pro: bool,
) -> dict[str, dict[str, float]]:
    raw_maps = []
    refined_cos_maps = []
    refined_geo_maps = []
    test_imgs = []
    gt_list = []
    gt_mask_list = []

    for data, mask, label, _name, _img_type in loader:
        for f in data:
            test_imgs.append(f.numpy())
        images = _preprocess_batch(backbone, data)
        raw_tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        out = refiner(raw_tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps)
        refined_tokens = out.refined

        raw_tokens = F.normalize(raw_tokens.float(), dim=-1)
        refined_tokens = F.normalize(refined_tokens.float(), dim=-1)
        raw_proto = raw_prototype.to(raw_tokens.device, dtype=raw_tokens.dtype).expand(raw_tokens.shape[0], -1, -1)
        ref_proto = refined_prototype.to(refined_tokens.device, dtype=refined_tokens.dtype).expand(refined_tokens.shape[0], -1, -1)

        raw_score = 1.0 - F.cosine_similarity(raw_tokens, raw_proto, dim=-1)
        refined_cos = 1.0 - F.cosine_similarity(refined_tokens, ref_proto, dim=-1)

        residual = refined_tokens - ref_proto
        basis = out.basis.float()
        projected = torch.einsum(
            "bnrd,bnr->bnd",
            basis,
            torch.einsum("bnrd,bnd->bnr", basis, residual.float()),
        )
        residual_norm = residual.float().norm(dim=-1)
        geom = 1.0 - F.cosine_similarity(residual.float(), projected, dim=-1, eps=1e-6)
        geom = torch.where(residual_norm > 1e-6, geom, torch.zeros_like(geom))
        refined_geo = refined_cos + geo_lambda * geom

        side = backbone.grid_size[0]
        raw_maps.extend(raw_score.view(raw_tokens.shape[0], side, side).cpu().numpy())
        refined_cos_maps.extend(refined_cos.view(refined_tokens.shape[0], side, side).cpu().numpy())
        refined_geo_maps.extend(refined_geo.view(refined_tokens.shape[0], side, side).cpu().numpy())
        for l, m in zip(label, mask):
            gt_list.append(int(l.numpy() if hasattr(l, "numpy") else l))
            gt_mask_list.append((m.numpy() > 0).astype(np.uint8))

    test_imgs, raw_maps, gt_mask_list = specify_resolution(
        test_imgs, raw_maps, gt_mask_list, resolution=(resolution, resolution)
    )
    _, refined_cos_maps, _ = specify_resolution(
        test_imgs, refined_cos_maps, gt_mask_list, resolution=(resolution, resolution)
    )
    _, refined_geo_maps, _ = specify_resolution(
        test_imgs, refined_geo_maps, gt_mask_list, resolution=(resolution, resolution)
    )

    raw_maps = np.asarray(raw_maps)
    refined_cos_maps = np.asarray(refined_cos_maps)
    refined_geo_maps = np.asarray(refined_geo_maps)

    return {
        "raw": metric_summary(raw_maps, gt_list, gt_mask_list, topk_ratio=topk_ratio, cal_pro=cal_pro),
        "refined_cos": metric_summary(refined_cos_maps, gt_list, gt_mask_list, topk_ratio=topk_ratio, cal_pro=cal_pro),
        "refined_geo": metric_summary(refined_geo_maps, gt_list, gt_mask_list, topk_ratio=topk_ratio, cal_pro=cal_pro),
    }


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu")

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    refiner, config = load_refiner(args.refiner_ckpt, device)
    num_steps = int(config.get("num_steps", 2))

    rows = []
    for class_name in args.class_names:
        train_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "train", args.batch_size)
        test_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)
        raw_proto = build_class_prototype(backbone, train_loader, args.target_layer, refiner=None, num_steps=num_steps)
        refined_proto = build_class_prototype(backbone, train_loader, args.target_layer, refiner=refiner, num_steps=num_steps)

        metrics = evaluate_variants(
            backbone=backbone,
            loader=test_loader,
            target_layer=args.target_layer,
            raw_prototype=raw_proto,
            refined_prototype=refined_proto,
            refiner=refiner,
            num_steps=num_steps,
            resolution=args.resolution,
            topk_ratio=args.img_topk_ratio,
            geo_lambda=args.geo_lambda,
            cal_pro=not args.no_pro,
        )
        row = {
            "class_name": class_name,
            "target_layer": args.target_layer,
            "geo_lambda": args.geo_lambda,
            "img_topk_ratio": args.img_topk_ratio,
            "raw_i_roc": metrics["raw"]["i_roc"],
            "raw_p_roc": metrics["raw"]["p_roc"],
            "raw_p_pro": metrics["raw"]["p_pro"],
            "refined_cos_i_roc": metrics["refined_cos"]["i_roc"],
            "refined_cos_p_roc": metrics["refined_cos"]["p_roc"],
            "refined_cos_p_pro": metrics["refined_cos"]["p_pro"],
            "refined_geo_i_roc": metrics["refined_geo"]["i_roc"],
            "refined_geo_p_roc": metrics["refined_geo"]["p_roc"],
            "refined_geo_p_pro": metrics["refined_geo"]["p_pro"],
            "delta_cos_i_roc": metrics["refined_cos"]["i_roc"] - metrics["raw"]["i_roc"],
            "delta_cos_p_roc": metrics["refined_cos"]["p_roc"] - metrics["raw"]["p_roc"],
            "delta_cos_p_pro": metrics["refined_cos"]["p_pro"] - metrics["raw"]["p_pro"],
            "delta_geo_i_roc": metrics["refined_geo"]["i_roc"] - metrics["raw"]["i_roc"],
            "delta_geo_p_roc": metrics["refined_geo"]["p_roc"] - metrics["raw"]["p_roc"],
            "delta_geo_p_pro": metrics["refined_geo"]["p_pro"] - metrics["raw"]["p_pro"],
        }
        rows.append(row)
        print(
            f"{class_name} | cos dI={row['delta_cos_i_roc']:.2f} dP={row['delta_cos_p_roc']:.2f} | "
            f"geo dI={row['delta_geo_i_roc']:.2f} dP={row['delta_geo_p_roc']:.2f}",
            flush=True,
        )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(rows, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
