from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.scripts.eval_winclip_oneclass_featureop import run_eval


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "cashew", "pcb1", "capsules"])
    parser.add_argument("--ckpt_paths", nargs="+", required=True)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--k_shot", type=int, default=0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--cal_pro", action="store_true")
    parser.add_argument(
        "--output_tag",
        type=str,
        default="winclip_sidecar_transport",
    )
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _build_eval_args(args: argparse.Namespace, class_name: str, feature_ops: list[str], refiner_ckpt: str = "") -> SimpleNamespace:
    return SimpleNamespace(
        dataset_root=args.dataset_root,
        split_csv=args.split_csv,
        class_name=class_name,
        feature_ops=feature_ops,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
        resolution=args.resolution,
        batch_size=args.batch_size,
        k_shot=args.k_shot,
        cal_pro=args.cal_pro,
        gpu_id=args.gpu_id,
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=[2, 3],
        output_dir=args.output_dir,
        output_tag=args.output_tag,
        refiner_ckpt=refiner_ckpt,
        refiner_ckpts=[],
    )


def _find_identity_row(rows: list[dict]) -> dict:
    for row in rows:
        if row["feature_op"] == "identity":
            return row
    raise ValueError("identity row missing")


def _find_learned_row(rows: list[dict]) -> dict:
    for row in rows:
        if row["feature_op"] == "learned_refiner":
            return row
    raise ValueError("learned_refiner row missing")


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    identity_cache: dict[str, dict] = {}
    aggregate_rows: list[dict] = []

    for class_name in args.class_names:
        if class_name not in identity_cache:
            identity_rows = run_eval(_build_eval_args(args, class_name, ["identity"]))
            identity_cache[class_name] = _find_identity_row(identity_rows)

        identity_row = identity_cache[class_name]
        for ckpt_path in args.ckpt_paths:
            ckpt_name = Path(ckpt_path).stem
            learned_rows = run_eval(
                _build_eval_args(args, class_name, ["identity", "learned_refiner"], refiner_ckpt=ckpt_path)
            )
            learned_row = _find_learned_row(learned_rows)
            aggregate_rows.append(
                {
                    "class_name": class_name,
                    "ckpt_name": ckpt_name,
                    "ckpt_path": ckpt_path,
                    "identity_i_roc": float(identity_row["i_roc"]),
                    "identity_p_roc": float(identity_row["p_roc"]),
                    "identity_p_pro": float(identity_row["p_pro"]),
                    "learned_i_roc": float(learned_row["i_roc"]),
                    "learned_p_roc": float(learned_row["p_roc"]),
                    "learned_p_pro": float(learned_row["p_pro"]),
                    "delta_i_roc": float(learned_row["i_roc"] - identity_row["i_roc"]),
                    "delta_p_roc": float(learned_row["p_roc"] - identity_row["p_roc"]),
                    "delta_p_pro": float(learned_row["p_pro"] - identity_row["p_pro"]),
                }
            )
            print(
                f"{class_name} | {ckpt_name} | "
                f"dI={learned_row['i_roc'] - identity_row['i_roc']:.2f} "
                f"dP={learned_row['p_roc'] - identity_row['p_roc']:.2f} "
                f"dPRO={learned_row['p_pro'] - identity_row['p_pro']:.2f}",
                flush=True,
            )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(aggregate_rows[0].keys()))
        writer.writeheader()
        writer.writerows(aggregate_rows)
    with json_path.open("w") as f:
        json.dump(aggregate_rows, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
