from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)


BASE = np.array([58.12, 60.18, 57.51, 57.92])
CTED = np.array([60.59, 61.96, 59.66, 60.12])


def minmax_err(values):
    mean = values.mean()
    return np.array([[mean - values.min()], [values.max() - mean]])


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "xtick.labelsize": 11,
            "ytick.labelsize": 10,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    means = np.array([BASE.mean(), CTED.mean()])
    yerr = np.concatenate([minmax_err(BASE), minmax_err(CTED)], axis=1)
    colors = ["#8C939B", "#1B5E8A"]
    labels = ["B", "C-TED"]
    delta = means[1] - means[0]

    fig, ax = plt.subplots(figsize=(2.55, 2.75))
    x = np.arange(2)
    bars = ax.bar(x, means, color=colors, width=0.58, alpha=0.94, zorder=3)
    ax.errorbar(
        x,
        means,
        yerr=yerr,
        fmt="none",
        ecolor="#2F3337",
        elinewidth=1.4,
        capsize=4,
        capthick=1.4,
        zorder=4,
    )

    for bar, value in zip(bars, means):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.42,
            f"{value:.1f}",
            ha="center",
            va="bottom",
            fontsize=10,
            fontweight="bold",
        )

    ax.annotate(
        f"+{delta:.1f} avg.",
        xy=(0.5, max(means) + 1.25),
        xytext=(0.5, max(means) + 2.05),
        ha="center",
        va="bottom",
        fontsize=10.5,
        fontweight="bold",
        color="#1B5E8A",
        arrowprops=dict(arrowstyle="-", color="#1B5E8A", linewidth=1.3),
    )

    ax.set_title("Hard-FP separation after retraining", fontweight="bold", pad=6)
    ax.set_ylabel("Defect vs. hard-FP AUC")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontweight="bold")
    ax.set_ylim(55.5, 64.3)
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.75, zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.text(
        0.5,
        0.04,
        "range over 4 retrained recipes",
        transform=ax.transAxes,
        ha="center",
        va="bottom",
        fontsize=8.4,
        color="#333333",
    )

    fig.tight_layout(pad=0.25)
    pdf = FIG_DIR / "recipe_entanglement_range_summary_20260503.pdf"
    png = FIG_DIR / "recipe_entanglement_range_summary_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")

    tex = OUT_DIR / "recipe_entanglement_range_summary_20260503.tex"
    tex.write_text(
        r"""\begin{figure}[t]
\centering
\includegraphics[width=0.62\linewidth]{figure/recipe_entanglement_range_summary_20260503.pdf}
\caption{
Recipe-consistent retraining does not remove hard-FP competition.
Bars show mean defect-versus-hard-FP AUC across four retrained layer recipes, with error bars indicating the recipe range.
C-TED improves the separation without changing the retrained host.
}
\label{fig:recipe_entanglement_range}
\end{figure}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)


if __name__ == "__main__":
    main()
