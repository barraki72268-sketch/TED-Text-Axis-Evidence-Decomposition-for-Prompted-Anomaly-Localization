#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
PRESETS = ("visa2mvtec", "mvtec2visa", "visa2mpdd", "visa2btad")
METRICS = ("pixel_auc", "pixel_ap", "pixel_pro", "image_auc")


def summary_path(preset: str) -> Path:
    return (
        RESULTS
        / f"aaclip_official_vitl336_img518_{preset}_alpha_sweep_map_topk_pro_20260427"
        / "summary.json"
    )


def fmt(x: float) -> str:
    return f"{x:.2f}"


def metric_tuple(values: dict[str, float]) -> str:
    return " / ".join(fmt(float(values[m])) for m in METRICS)


def bold_tuple(base: dict[str, float], ours: dict[str, float], ours_side: bool) -> str:
    parts = []
    for metric in METRICS:
        value = float(ours[metric] if ours_side else base[metric])
        text = fmt(value)
        if (float(ours[metric]) > float(base[metric])) == ours_side:
            text = rf"\textbf{{{text}}}"
        parts.append(text)
    return " / ".join(parts)


def average(rows: list[dict[str, float]]) -> dict[str, float]:
    return {metric: sum(float(row[metric]) for row in rows) / len(rows) for metric in METRICS}


def best_candidate(mean: dict) -> tuple[str, dict[str, float]]:
    candidates = mean["candidates"]
    return max(candidates.items(), key=lambda item: float(item[1]["pixel_auc"]))


def main() -> int:
    bases = []
    ours_rows = []
    pending = []
    for preset in PRESETS:
        path = summary_path(preset)
        if not path.exists():
            pending.append(str(path))
            continue
        data = json.loads(path.read_text())
        base = data["mean"]["baseline"]
        name, ours = best_candidate(data["mean"])
        bases.append(base)
        ours_rows.append(ours)
        print(preset)
        print(f"  best: {name}")
        print(f"  base: {metric_tuple(base)}")
        print(f"  ours: {metric_tuple(ours)}")

    if len(bases) == len(PRESETS):
        base_mean = average(bases)
        ours_mean = average(ours_rows)
        print("\nMean row")
        print(f"Base: {metric_tuple(base_mean)}")
        print(f"OURS: {metric_tuple(ours_mean)}")
        print("\nLaTeX")
        print(r"\multirow{4}{*}{AA-CLIP}")
        print(r"  & ViT-L/14-336 Official")
        print(f"  & {bold_tuple(base_mean, ours_mean, ours_side=False)}")
        print(f"  & {bold_tuple(base_mean, ours_mean, ours_side=True)} \\\\")
    else:
        print("\nPending")
        for path in pending:
            print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
