from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
BAYES_ROOT = ROOT / "neurips2026" / "Bayes-PFL"
os.chdir(BAYES_ROOT)
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(BAYES_ROOT) not in sys.path:
    sys.path.insert(0, str(BAYES_ROOT))

from collect_bayespfl_map_separability import build_models, infer_map  # noqa: E402
from datasets import Makedataset  # noqa: E402
from region_descriptor_utils import (  # noqa: E402
    FEATURE_NAMES,
    extract_region_descriptor,
    iterate_components,
    rows_to_matrix,
    save_json,
    save_rows,
)
from test import _transform_test, setup_seed  # noqa: E402


COMBOS = [
    ["peak", "area"],
    ["peak", "mean"],
    ["peak", "top10_mean"],
    ["peak", "fill_ratio"],
    ["peak", "compactness"],
    ["peak", "ring_contrast"],
    ["peak", "area", "fill_ratio"],
    ["peak", "mean", "area", "fill_ratio", "compactness", "ring_contrast"],
]


def build_dataset(root: str, image_size: int):
    preprocess_test = _transform_test(image_size)
    maker = Makedataset(train_data_path=root, preprocess_test=preprocess_test, mode="test", image_size=image_size)
    loader, _ = maker.mask_dataset(name="mvtec", product_list=None, batchsize=1, shuf=False)
    return loader


def collect_rows(args, device, model_clip, pfl_text_encoder, my_model, loader, bank_name: str):
    rows = []
    per_class = {}
    stage = int(Path(args.checkpoint_path).stem.split("_")[-1]) if "epoch_post" in args.checkpoint_path else 2
    from common_map_group_separability import top_fraction_mask  # noqa: WPS433

    for img_idx, items in enumerate(loader, start=1):
        anomaly_flag = int(items["anomaly"][0].item())
        cls_name = items["cls_name"][0]
        per_class.setdefault(cls_name, 0)
        limit = args.max_per_class_fp if bank_name == "fp" else args.max_per_class_defect
        if per_class[cls_name] >= limit:
            continue
        if bank_name == "fp" and anomaly_flag != 0:
            continue
        if bank_name == "defect" and anomaly_flag == 0:
            continue
        per_class[cls_name] += 1

        image = items["img"].to(device)
        _, anomaly_map = infer_map(args, device, model_clip, pfl_text_encoder, my_model, image, items["cls_name"], stage)
        if bank_name == "fp":
            for frac in args.top_fracs:
                mask = top_fraction_mask(anomaly_map, frac)
                for comp in iterate_components(mask):
                    if int(comp.sum()) < args.min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    desc.update({"bank": "fp", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": frac})
                    rows.append(desc)
        else:
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            for comp in iterate_components(gt_mask):
                if int(comp.sum()) < args.min_area:
                    continue
                desc = extract_region_descriptor(anomaly_map, comp)
                if not desc:
                    continue
                desc.update({"bank": "defect", "cls_name": cls_name, "img_idx": img_idx, "threshold_frac": -1.0})
                rows.append(desc)
        if img_idx % 50 == 0:
            print(json.dumps({f"{bank_name}_bank_progress": img_idx, "num_regions": len(rows)}), flush=True)
    return rows


def compute_holdout_summary(fp_rows: list[dict], defect_rows: list[dict]):
    classes = sorted(set(row["cls_name"] for row in fp_rows) & set(row["cls_name"] for row in defect_rows))
    name_to_idx = {name: i for i, name in enumerate(FEATURE_NAMES)}
    holdout_rows = []
    for heldout in classes:
        fp_train = [row for row in fp_rows if row["cls_name"] != heldout]
        df_train = [row for row in defect_rows if row["cls_name"] != heldout]
        fp_eval = [row for row in fp_rows if row["cls_name"] == heldout]
        df_eval = [row for row in defect_rows if row["cls_name"] == heldout]
        if not fp_train or not df_train or not fp_eval or not df_eval:
            continue
        X_train = np.concatenate([rows_to_matrix(fp_train, FEATURE_NAMES), rows_to_matrix(df_train, FEATURE_NAMES)], axis=0)
        y_train = np.concatenate([np.zeros(len(fp_train), dtype=np.int64), np.ones(len(df_train), dtype=np.int64)], axis=0)
        X_eval = np.concatenate([rows_to_matrix(fp_eval, FEATURE_NAMES), rows_to_matrix(df_eval, FEATURE_NAMES)], axis=0)
        y_eval = np.concatenate([np.zeros(len(fp_eval), dtype=np.int64), np.ones(len(df_eval), dtype=np.int64)], axis=0)

        for feat_idx, feature_name in enumerate(FEATURE_NAMES):
            auc = roc_auc_score(y_eval, X_eval[:, feat_idx])
            eff_auc = max(float(auc), float(1.0 - auc))
            direction = "defect_high" if auc >= 0.5 else "fp_high"
            holdout_rows.append({"heldout_class": heldout, "kind": "single", "name": feature_name, "auc_eval": eff_auc, "direction": direction})

        for combo in COMBOS:
            idxs = [name_to_idx[c] for c in combo]
            clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
            clf.fit(X_train[:, idxs], y_train)
            pred = clf.predict_proba(X_eval[:, idxs])[:, 1]
            auc = roc_auc_score(y_eval, pred)
            holdout_rows.append({"heldout_class": heldout, "kind": "combo", "name": "+".join(combo), "auc_eval": float(auc), "direction": "defect_high"})

    def aggregate(rows: list[dict]):
        grouped: dict[str, list[float]] = {}
        for row in rows:
            grouped.setdefault(row["name"], []).append(float(row["auc_eval"]))
        out = []
        for name, vals in grouped.items():
            out.append({"name": name, "mean_auc": float(np.mean(vals)), "std_auc": float(np.std(vals)), "num_holdouts": len(vals)})
        out.sort(key=lambda x: x["mean_auc"], reverse=True)
        return out

    return {
        "num_fp_regions": len(fp_rows),
        "num_defect_regions": len(defect_rows),
        "single_summary": aggregate([row for row in holdout_rows if row["kind"] == "single"]),
        "combo_summary": aggregate([row for row in holdout_rows if row["kind"] == "combo"]),
        "holdout_rows": holdout_rows,
    }


def main():
    parser = argparse.ArgumentParser("Build Bayes-PFL source region banks and leave-one-class-out descriptor sanity")
    parser.add_argument("--dataset", type=str, default="mvtec")
    parser.add_argument(
        "--data_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_data_bridge"),
    )
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_strict_mvtec" / "epoch_post_15_1.pth"),
    )
    parser.add_argument(
        "--config_path",
        type=str,
        default=str(BAYES_ROOT / "open_clip_local" / "model_configs" / "ViT-L-14-336.json"),
    )
    parser.add_argument(
        "--pretrained_path",
        type=str,
        default="/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt",
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--num_flows", type=int, default=10)
    parser.add_argument("--prompt_context_len", type=int, default=5)
    parser.add_argument("--prompt_num", type=int, default=3)
    parser.add_argument("--prompt_state_len", type=int, default=5)
    parser.add_argument("--sample_num", type=int, default=5)
    parser.add_argument("--device_id", type=int, default=0)
    parser.add_argument("--seed", type=int, default=333)
    parser.add_argument("--top_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--max_per_class_fp", type=int, default=200)
    parser.add_argument("--max_per_class_defect", type=int, default=80)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_region_bank_holdout_epoch15"),
    )
    args = parser.parse_args()

    setup_seed(args.seed)
    device, model_clip, pfl_text_encoder, my_model = build_models(args)
    loader = build_dataset(args.data_path, args.image_size)

    fp_rows = collect_rows(args, device, model_clip, pfl_text_encoder, my_model, loader, "fp")
    save_rows(fp_rows, Path(args.save_dir) / "fp_rows.csv")
    defect_rows = collect_rows(args, device, model_clip, pfl_text_encoder, my_model, loader, "defect")
    save_rows(defect_rows, Path(args.save_dir) / "defect_rows.csv")

    summary = compute_holdout_summary(fp_rows, defect_rows)
    save_rows(summary["single_summary"], Path(args.save_dir) / "single_summary.csv")
    save_rows(summary["combo_summary"], Path(args.save_dir) / "combo_summary.csv")
    save_rows(summary["holdout_rows"], Path(args.save_dir) / "holdout_rows.csv")
    save_json(summary, Path(args.save_dir) / "summary.json")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
