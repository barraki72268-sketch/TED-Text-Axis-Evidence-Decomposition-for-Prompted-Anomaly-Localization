from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
OUT_DIR = ROOT / "supp_fig"


CASES = [
    ROOT / "neurips2026/results/faprompt_ted_story_vitl336_mvtec2visa_capsules_alpha15/selected_pair.json",
    ROOT / "neurips2026/results/faprompt_ted_story_vitl336_visa2mvtec_metal_nut_alpha15/selected_pair.json",
    ROOT / "neurips2026/results/faprompt_ted_story_vitl336_visa2mvtec_wood_alpha15/selected_pair.json",
]


def load_pair(path: Path) -> dict:
    with path.open("r") as f:
        payload = json.load(f)
    defect = payload["selected"]["defect"]
    hard = payload["selected"]["hard_normal"]
    return {
        "preset": payload["preset"],
        "class_name": payload["class_name"],
        "defect_crop": ROOT / defect["crop_path"],
        "hard_crop": ROOT / hard["crop_path"],
        "baseline_gap": float(defect["baseline"] - hard["baseline"]),
        "cted_gap": float(defect["calibrated"] - hard["calibrated"]),
        "defect_baseline": float(defect["baseline"]),
        "hard_baseline": float(hard["baseline"]),
        "defect_cted": float(defect["calibrated"]),
        "hard_cted": float(hard["calibrated"]),
    }


def add_crop(ax, path: Path, title: str, edge_color: str) -> None:
    image = Image.open(path).convert("RGB")
    ax.imshow(image)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(title, fontsize=10, fontweight="bold", color=edge_color, pad=2)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(2.2)
        spine.set_edgecolor(edge_color)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = [load_pair(path) for path in CASES]

    fig = plt.figure(figsize=(10.6, 6.8), constrained_layout=True)
    gs = fig.add_gridspec(len(rows), 4, width_ratios=[1.0, 1.0, 1.45, 1.2])

    for i, row in enumerate(rows):
        ax_d = fig.add_subplot(gs[i, 0])
        ax_h = fig.add_subplot(gs[i, 1])
        ax_gap = fig.add_subplot(gs[i, 2])
        ax_score = fig.add_subplot(gs[i, 3])

        title_prefix = f"{row['preset']} / {row['class_name']}"
        add_crop(ax_d, row["defect_crop"], "Defect patch", "#C62828")
        add_crop(ax_h, row["hard_crop"], "Hard-normal patch", "#1E5AA8")

        gaps = [row["baseline_gap"], row["cted_gap"]]
        ax_gap.axhline(0.0, color="#333333", lw=1.0, alpha=0.75)
        ax_gap.plot([0, 1], gaps, color="#333333", lw=2.0, marker="o", ms=7)
        ax_gap.scatter([0], [gaps[0]], color="#777777", s=58, zorder=3)
        ax_gap.scatter([1], [gaps[1]], color="#C62828", s=58, zorder=3)
        ax_gap.set_xticks([0, 1], ["Baseline", "C-TED"], fontsize=9, fontweight="bold")
        ax_gap.set_ylabel("D minus H-FP", fontsize=9, fontweight="bold")
        ax_gap.set_title(title_prefix, fontsize=10, fontweight="bold", loc="left")
        pad = max(0.002, 0.45 * (max(gaps) - min(gaps) + 1e-6))
        ax_gap.set_ylim(min(gaps) - pad, max(gaps) + pad)
        ax_gap.grid(axis="y", alpha=0.25)
        ax_gap.text(0, gaps[0], f"{gaps[0]:+.4f}", ha="center", va="bottom" if gaps[0] >= 0 else "top", fontsize=8)
        ax_gap.text(1, gaps[1], f"{gaps[1]:+.4f}", ha="center", va="bottom" if gaps[1] >= 0 else "top", fontsize=8)
        for spine in ["top", "right"]:
            ax_gap.spines[spine].set_visible(False)

        labels = ["D", "H-FP", "D", "H-FP"]
        vals = [row["defect_baseline"], row["hard_baseline"], row["defect_cted"], row["hard_cted"]]
        colors = ["#C62828", "#1E5AA8", "#C62828", "#1E5AA8"]
        x = np.array([0, 1, 2.5, 3.5])
        ax_score.bar(x, vals, color=colors, alpha=0.82, width=0.72)
        ax_score.set_xticks(x, labels, fontsize=8, fontweight="bold")
        ax_score.set_title("Patch scores", fontsize=10, fontweight="bold")
        ax_score.text(0.5, max(vals), "B", ha="center", va="bottom", fontsize=9, fontweight="bold")
        ax_score.text(3.0, max(vals), "C", ha="center", va="bottom", fontsize=9, fontweight="bold")
        lo, hi = min(vals), max(vals)
        margin = max(0.002, 0.35 * (hi - lo + 1e-6))
        ax_score.set_ylim(lo - margin, hi + margin)
        ax_score.grid(axis="y", alpha=0.22)
        for spine in ["top", "right"]:
            ax_score.spines[spine].set_visible(False)

    fig.suptitle(
        "Patch-level hard-FP recovery in adapted hosts",
        fontsize=14,
        fontweight="bold",
    )
    fig.savefig(OUT_DIR / "host_patch_pair_recovery_gallery_20260505.pdf", bbox_inches="tight")
    fig.savefig(OUT_DIR / "host_patch_pair_recovery_gallery_20260505.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
