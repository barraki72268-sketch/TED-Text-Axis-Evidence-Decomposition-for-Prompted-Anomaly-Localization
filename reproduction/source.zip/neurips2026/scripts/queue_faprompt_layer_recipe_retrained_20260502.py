#!/usr/bin/env python3
"""Queue FAPrompt layer-recipe retraining rows for the retrain-only table.

The queue mirrors the AdaCLIP/AnomalyCLIP layer-recipe stress protocol:
1. evaluate the official full-layer checkpoint as Full(B),
2. retrain FAPrompt on VisA under each layer recipe,
3. rebuild source evidence banks for that checkpoint/recipe,
4. evaluate B / train-free TED / source-calibrated TED on VisA -> MVTec.

The process can wait for the existing global retraining queue so it does not
compete for GPU memory.
"""

from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")

OUT = ROOT / "neurips2026/results/faprompt_layer_recipe_retrained_20260502"
LOG = OUT / "logs"

UPSTREAM_PID_FILE = ROOT / "neurips2026/results/layer_recipe_retrained_all_20260502/queue.pid"

VISA_1CLS = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
FAP_ROOT = ROOT / "neurips2026/FAPrompt"
FAP_OFFICIAL_VISA = FAP_ROOT / "checkpoints/trained_on_visa/epoch_15.pth"
FAP_EVAL = ROOT / "neurips2026/scripts/official_parallel_test_faprompt.py"

RECIPES = {
    "earlylate": [6, 24],
    "mid2": [12, 18],
    "last2": [18, 24],
    "last": [24],
    "all4": [6, 12, 18, 24],
}


def live_pid(pid: int) -> bool:
    return pid > 0 and Path(f"/proc/{pid}").exists()


def upstream_pid() -> int:
    env_pid = os.environ.get("WAIT_FOR_PID", "").strip()
    if env_pid:
        return int(env_pid)
    if UPSTREAM_PID_FILE.exists():
        text = UPSTREAM_PID_FILE.read_text(encoding="utf-8").strip()
        if text:
            return int(text)
    return 0


def wait_for_upstream() -> None:
    pid = upstream_pid()
    if not live_pid(pid):
        return
    print({"stage": "wait_for_upstream", "pid": pid}, flush=True)
    while live_pid(pid):
        time.sleep(60)
    print({"stage": "upstream_finished", "pid": pid}, flush=True)


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def train_faprompt(recipe: str, features: list[int], env: dict[str, str]) -> Path:
    ckpt_dir = OUT / f"faprompt_visa_{recipe}_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if ckpt_path.exists():
        print({"stage": "skip_train", "checkpoint": str(ckpt_path)}, flush=True)
        return ckpt_path

    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "visa",
            "--train_data_path",
            str(VISA_1CLS),
            "--save_path",
            str(ckpt_dir),
            "--features_list",
            *[str(x) for x in features],
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ],
        FAP_ROOT,
        LOG / f"faprompt_train_visa_{recipe}.log",
        env,
    )
    return ckpt_path


def eval_faprompt(recipe: str, checkpoint: Path, features: list[int], save_dir: Path, env: dict[str, str]) -> None:
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "summary": str(save_dir / "summary.json")}, flush=True)
        return

    run(
        [
            str(PY),
            "-u",
            str(FAP_EVAL),
            "--preset",
            "visa2mvtec",
            "--checkpoint_path",
            str(checkpoint),
            "--save_dir",
            str(save_dir),
            "--model_name",
            "ViT-L/14@336px",
            "--prompt_load_mode",
            "strict",
            "--features_list",
            *[str(x) for x in features],
            "--image_size",
            "518",
            "--batch_size",
            "2",
            "--num_workers",
            "4",
            "--dap_token_mode",
            "official_firstk",
            "--dpam_layer",
            "20",
            "--max_fp_per_class",
            "512",
            "--max_defect_per_class",
            "512",
            "--max_fp_total",
            "4096",
            "--max_defect_total",
            "4096",
            "--normal_topk_frac",
            "0.01",
            "--tau",
            "0.1",
            "--fp_weight",
            "1.0",
            "--alphas",
            "0.5,1.0",
            "--ours_image_score_mode",
            "official",
            "--insert_modes",
            "support_only,branch_calibrated",
            "--prescore_calib_epochs",
            "30",
            "--prescore_calib_lr",
            "0.02",
            "--prescore_calib_max_train_points",
            "2048",
            "--prescore_calib_alpha_init",
            "0.05",
            "--prescore_calib_alpha_max",
            "0.2",
            "--prescore_calib_subspace_rank",
            "4",
            "--aupro_max_step",
            "50",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--force_rebuild_bank",
        ],
        ROOT,
        LOG / f"faprompt_eval_visa_{recipe}.log",
        env,
    )


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    wait_for_upstream()

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-faprompt-layer-retrained-20260502")

    eval_faprompt(
        "all4_official",
        FAP_OFFICIAL_VISA,
        RECIPES["all4"],
        OUT / "faprompt_visa_all4_official_eval",
        env,
    )

    for recipe, features in RECIPES.items():
        ckpt = train_faprompt(recipe, features, env)
        eval_faprompt(recipe, ckpt, features, OUT / f"faprompt_visa_{recipe}_eval", env)

    print({"stage": "done", "root": str(OUT)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
