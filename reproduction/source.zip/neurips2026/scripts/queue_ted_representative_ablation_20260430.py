#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results"


VARIANTS = {
    "rank1": "Use a rank-1 text-axis subspace instead of the default rank-r basis.",
    "rank2": "Use a rank-2 residual subspace.",
    "rank4": "Use a rank-4 residual subspace.",
    "no_hardfp": "Disable hard-false-positive support by fixing its support weight near zero.",
    "no_preserve": "Remove the source host-margin preservation term during calibration.",
}


def run(cmd: list[str], save_dir: Path, force: bool) -> None:
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        print(f"[skip] {summary}", flush=True)
        return
    save_dir.mkdir(parents=True, exist_ok=True)
    print(f"[run] {save_dir}", flush=True)
    print(" ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def faprompt_cmd(variant: str, device: str, seed: int) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"ablation_ted_faprompt_vitl336_mvtec2btad_{variant}_seed{seed}_20260430"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        "mvtec2btad",
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    if variant == "rank1":
        idx = cmd.index("--prescore_calib_subspace_rank") + 1
        cmd[idx] = "1"
    elif variant == "rank2":
        idx = cmd.index("--prescore_calib_subspace_rank") + 1
        cmd[idx] = "2"
    elif variant == "rank4":
        idx = cmd.index("--prescore_calib_subspace_rank") + 1
        cmd[idx] = "4"
    elif variant == "no_hardfp":
        cmd.extend(["--prescore_calib_fp_weight_init", "0.0001"])
    elif variant == "no_preserve":
        idx = cmd.index("--prescore_calib_preserve_host_margin_weight") + 1
        cmd[idx] = "0.0"
    else:
        raise ValueError(f"unknown FAPrompt variant: {variant}")
    return cmd, save_dir


def aaclip_cmd(variant: str, device: str, seed: int) -> tuple[list[str], Path]:
    save_dir = RESULTS / f"ablation_ted_aaclip_vith14_mvtec2btad_{variant}_seed{seed}_20260430"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        "mvtec2btad",
        "--model_name",
        "ViT-H-14",
        "--pretrained",
        "laion2b_s32b_b79k",
        "--adapter_load_mode",
        "project_crop",
        "--levels",
        "8,16,24,32",
        "--img_size",
        "224",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    if variant == "rank1":
        idx = cmd.index("--prescore_calib_subspace_rank") + 1
        cmd[idx] = "1"
    elif variant == "rank2":
        idx = cmd.index("--prescore_calib_subspace_rank") + 1
        cmd[idx] = "2"
    elif variant == "rank4":
        idx = cmd.index("--prescore_calib_subspace_rank") + 1
        cmd[idx] = "4"
    elif variant == "no_hardfp":
        cmd.remove("--prescore_calib_learn_fp_weight")
        cmd.extend(["--prescore_calib_fp_weight_init", "0.0001"])
    elif variant == "no_preserve":
        idx = cmd.index("--prescore_calib_preserve_host_margin_weight") + 1
        cmd[idx] = "0.0"
    else:
        raise ValueError(f"unknown AA-CLIP variant: {variant}")
    return cmd, save_dir


def parse_csv(text: str, allowed: set[str]) -> list[str]:
    values = [v.strip() for v in text.split(",") if v.strip()]
    bad = [v for v in values if v not in allowed]
    if bad:
        raise SystemExit(f"Unknown values {bad}. Allowed: {sorted(allowed)}")
    return values


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", choices=["faprompt", "aaclip"], required=True)
    ap.add_argument("--variants", default="rank1,no_hardfp,no_preserve")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    variants = parse_csv(args.variants, set(VARIANTS))
    for variant in variants:
        print(f"[variant] {variant}: {VARIANTS[variant]}", flush=True)
        if args.host == "faprompt":
            cmd, save_dir = faprompt_cmd(variant, args.device, args.seed)
        else:
            cmd, save_dir = aaclip_cmd(variant, args.device, args.seed)
        run(cmd, save_dir, force=args.force)
    print(f"[done] representative TED ablation host={args.host}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
