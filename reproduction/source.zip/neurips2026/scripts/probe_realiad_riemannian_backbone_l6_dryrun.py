from __future__ import annotations

import csv
import json
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F
from PIL import Image
from tqdm.auto import tqdm

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.datasets.real_iad import RealIAD
from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import RiemannianLowRankRefiner, RiemannianObjective
from neurips2026.scripts.probe_realiad_alpha_refiner_clip_dryrun import (
    build_group_balanced_epoch_batches,
    filter_trainable_anomalies,
    flatten_records,
    sample_balanced_batch,
    set_seed,
    summarize_grouped_records,
)
from neurips2026.scripts.probe_realiad_alpha_refiner_winclip_dryrun import (
    _audit_cache_path,
    _load_cached_json,
    audit_dataset,
    build_mask_transform,
    dilate_mask_tensor,
    load_mask_tensor,
)


def parse_args():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--target_layer", type=int, default=6)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument("--rank", type=int, default=4)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--lambda_max", type=float, default=2.0)
    parser.add_argument("--num_steps", type=int, default=2)
    parser.add_argument("--lambda_sep", type=float, default=1.0)
    parser.add_argument("--lambda_project", type=float, default=1.0)
    parser.add_argument("--lambda_vol", type=float, default=0.05)
    parser.add_argument("--separation_margin", type=float, default=0.2)
    parser.add_argument("--project_epsilon", type=float, default=0.1)
    parser.add_argument("--det_target", type=float, default=20.0)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--epochs", type=int, default=0)
    parser.add_argument("--max_epoch_steps", type=int, default=0)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--probe_normals", type=int, default=8)
    parser.add_argument("--probe_anomalies", type=int, default=8)
    parser.add_argument("--mask_dilate_kernel", type=int, default=15)
    parser.add_argument("--audit_verify_limit", type=int, default=4000)
    parser.add_argument("--mask_audit_limit", type=int, default=4000)
    parser.add_argument("--reuse_dataset_cache", action="store_true", default=True)
    parser.add_argument("--eval_interval", type=int, default=5)
    parser.add_argument("--save_eval_ckpts", action="store_true")
    parser.add_argument("--save_epoch_ckpts", action="store_true")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:1")
    parser.add_argument("--output_tag", type=str, default="realiad_riemannian_backbone_l6")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def build_batch_tensors(
    batch: list[dict],
    backbone,
    mask_transform,
    semantic_basis_by_class: dict[str, torch.Tensor],
    args,
    device: torch.device,
):
    images = torch.stack(
        [backbone.transform_pil(Image.open(rec["image_path"]).convert("RGB")) for rec in batch],
        dim=0,
    ).to(device)
    masks = []
    basis = []
    for rec in batch:
        if int(rec["label"]) == 1:
            mask = dilate_mask_tensor(load_mask_tensor(rec["mask_path"], mask_transform), args.mask_dilate_kernel)
        else:
            mask = torch.zeros(1, args.img_cropsize, args.img_cropsize)
        masks.append(mask)
        if rec["class_name"] not in semantic_basis_by_class:
            semantic_basis_by_class[rec["class_name"]] = backbone.build_prompt_token_basis(rec["class_name"])
        basis.append(semantic_basis_by_class[rec["class_name"]])
    return images, torch.stack(masks, dim=0).to(device), torch.stack(basis, dim=0).to(device)


@torch.no_grad()
def compute_pca_alignment(raw_tokens: torch.Tensor, patch_mask_flat: torch.Tensor, learned_basis: torch.Tensor, rank: int) -> torch.Tensor:
    scores = []
    for b in range(raw_tokens.shape[0]):
        normal_mask = ~patch_mask_flat[b]
        source = raw_tokens[b, normal_mask]
        if source.shape[0] < rank:
            source = raw_tokens[b]
        if source.shape[0] < rank:
            continue
        centered = source - source.mean(dim=0, keepdim=True)
        q = min(rank, centered.shape[0], centered.shape[1])
        if q < 1:
            continue
        _u, _s, v = torch.pca_lowrank(centered.float(), q=q, center=False)
        oracle_basis = F.normalize(v[:, :q], dim=0).transpose(0, 1)  # [q, D]
        pred = learned_basis[b, :, :q, :]  # [N, q, D]
        overlap = torch.einsum("nrd,qd->nrq", pred.float(), oracle_basis.float())
        score = overlap.square().sum(dim=(-2, -1)) / float(q)
        scores.append(score.mean())
    if not scores:
        return raw_tokens.new_zeros(())
    return torch.stack(scores).mean()


def aggregate_probe_metrics(
    refiner: RiemannianLowRankRefiner,
    objective: RiemannianObjective,
    backbone,
    probe_batch: list[dict],
    semantic_basis_by_class: dict[str, torch.Tensor],
    mask_transform,
    args,
    device: torch.device,
):
    images, masks_t, basis_t = build_batch_tensors(
        probe_batch, backbone, mask_transform, semantic_basis_by_class, args, device
    )
    layer_tokens = backbone.extract_layer_patch_tokens(images, target_layers=[args.target_layer])[args.target_layer]
    patch_mask_flat = (
        F.interpolate(masks_t.float(), size=backbone.grid_size, mode="nearest")[:, 0].reshape(len(probe_batch), -1) > 0.5
    )
    out = refiner(layer_tokens, semantic_basis=basis_t, spatial_shape=backbone.grid_size, num_steps=args.num_steps)
    loss_stats = objective(
        raw_features=layer_tokens,
        refined_features=out.refined,
        anomaly_mask=patch_mask_flat,
        local_mean=out.local_mean,
        basis=out.basis,
        metric_det=out.metric_det,
        spatial_shape=backbone.grid_size,
    )
    pca_align = compute_pca_alignment(layer_tokens, patch_mask_flat, out.basis, rank=args.rank)
    return {
        "probe_contrast_gap": float(loss_stats["contrast_gap"].item()),
        "probe_project": float(loss_stats["loss_project"].item()),
        "probe_vol": float(loss_stats["loss_vol"].item()),
        "probe_delta_norm": float(out.delta.float().norm(dim=-1).mean().item()),
        "probe_metric_det": float(out.metric_det.float().mean().item()),
        "probe_alpha_mean": float(out.alpha.float().mean().item()),
        "probe_eta_mean": float(out.eta.float().mean().item()),
        "probe_lambda_mean": float(out.lambda_diag.float().mean().item()),
        "probe_pca_align": float(pca_align.item()),
        "probe_score": float(loss_stats["contrast_gap"].item() - loss_stats["loss_project"].item()),
    }


def main():
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{args.backbone.replace('-', '').replace('+', 'plus').lower()}_layer{args.target_layer}"
    csv_path = output_dir / f"{stem}_steps.csv"
    json_path = output_dir / f"{stem}_summary.json"
    ckpt_path = output_dir / f"{stem}_best.pt"
    ckpt_dir = output_dir / f"{stem}_ckpts"
    png_path = output_dir / f"{stem}_curves.png"
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    dataset = RealIAD(
        args.dataset_root,
        class_name=None,
        train=True,
        normalize="imagebind",
        img_size=args.img_resize,
        crp_size=args.img_cropsize,
        msk_size=args.img_cropsize,
        msk_crp_size=args.img_cropsize,
        sub_dir=RealIAD._resolve_sub_dir(args.dataset_root, None),
    )
    train_records = flatten_records(dataset)
    train_records = [rec for rec in train_records if int(rec["label"]) in (0, 1)]
    mask_transform = build_mask_transform(args.img_cropsize)
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    audit_path = _audit_cache_path(output_dir, args)
    scan_limit = -1 if args.epochs > 0 else max(args.mask_audit_limit, args.batch_size * args.steps * 4)
    scan_tag = "all" if scan_limit < 0 else str(scan_limit)
    backbone_tag = args.backbone.replace("-", "").replace("+", "plus").lower()
    trainable_path = output_dir / (
        f"realiad_riemannian_{backbone_tag}_trainable_anomalies_resize{args.img_cropsize}_"
        f"dilate{args.mask_dilate_kernel}_token{backbone.grid_size[0]}_scan{scan_tag}.json"
    )
    if args.reuse_dataset_cache and audit_path.exists():
        audit = _load_cached_json(audit_path)
    else:
        audit = audit_dataset(
            train_records,
            mask_transform=mask_transform,
            img_cropsize=args.img_cropsize,
            verify_limit=args.audit_verify_limit,
            mask_limit=args.mask_audit_limit,
        )
        audit_path.write_text(json.dumps(audit, indent=2))
    if args.reuse_dataset_cache and trainable_path.exists():
        trainable_meta = _load_cached_json(trainable_path)
    else:
        anomaly_records_all = [rec for rec in train_records if int(rec["label"]) == 1]
        trainable_records, trainable_pool_meta = filter_trainable_anomalies(
            anomaly_records=anomaly_records_all,
            mask_transform=mask_transform,
            token_side=backbone.grid_size[0],
            scan_limit=scan_limit,
            seed=args.seed,
            mask_dilate_kernel=args.mask_dilate_kernel,
        )
        trainable_meta = {
            "config": {
                "mask_dilate_kernel": args.mask_dilate_kernel,
                "token_side": backbone.grid_size[0],
                "scan_limit": scan_limit,
            },
            "pool_meta": trainable_pool_meta,
            "records": [
                {
                    "image_path": rec["image_path"],
                    "mask_path": rec["mask_path"],
                    "class_name": rec["class_name"],
                    "anomaly_type": rec["anomaly_type"],
                    "sample_id": rec["sample_id"],
                }
                for rec in trainable_records
            ],
        }
        trainable_path.write_text(json.dumps(trainable_meta, indent=2))

    usable_anomaly_set = {item["image_path"] for item in trainable_meta.get("records", [])}
    normal_pool = [rec for rec in train_records if int(rec["label"]) == 0]
    anomaly_pool = [rec for rec in train_records if int(rec["label"]) == 1 and rec["image_path"] in usable_anomaly_set]
    if not normal_pool or not anomaly_pool:
        raise RuntimeError("Failed to build balanced pools.")

    normal_group_meta = summarize_grouped_records(normal_pool)
    anomaly_group_meta = summarize_grouped_records(anomaly_pool)
    half_batch = max(1, args.batch_size // 2)
    steps_per_epoch = max(1, (anomaly_group_meta["groups"] + half_batch - 1) // half_batch)
    total_steps = args.steps
    if args.epochs > 0:
        total_steps = args.epochs * steps_per_epoch
        if args.max_epoch_steps > 0:
            total_steps = min(total_steps, args.max_epoch_steps)

    rng = random.Random(args.seed)
    probe_normals = rng.sample(normal_pool, min(args.probe_normals, len(normal_pool)))
    probe_anomalies = rng.sample(anomaly_pool, min(args.probe_anomalies, len(anomaly_pool)))
    probe_batch = probe_normals + probe_anomalies

    feature_dim = backbone.token_dim
    refiner = RiemannianLowRankRefiner(
        feature_dim=feature_dim,
        kernel_size=args.kernel_size,
        topk_ratio=args.topk_ratio,
        rank=args.rank,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
        lambda_max=args.lambda_max,
    ).to(device)
    objective = RiemannianObjective(
        lambda_sep=args.lambda_sep,
        lambda_project=args.lambda_project,
        lambda_vol=args.lambda_vol,
        separation_margin=args.separation_margin,
        project_epsilon=args.project_epsilon,
        det_target=args.det_target,
    )
    optimizer = torch.optim.AdamW(refiner.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    semantic_basis_by_class: dict[str, torch.Tensor] = {}

    def checkpoint_payload():
        return {
            "model_state_dict": refiner.state_dict(),
            "refiner_config": {
                "feature_dim": feature_dim,
                "kernel_size": args.kernel_size,
                "topk_ratio": args.topk_ratio,
                "rank": args.rank,
                "hidden_dim": args.hidden_dim,
                "dropout": args.dropout,
                "lambda_max": args.lambda_max,
                "num_steps": args.num_steps,
                "target_layer": args.target_layer,
                "route": "raw_backbone",
                "family": "riemannian_lowrank",
            },
            "target_layer": args.target_layer,
            "route": "raw_backbone",
        }

    rows = []
    best_probe_score = float("-inf")
    best_step = 0
    start = time.time()
    global_step = 0
    epoch_index = 0
    while global_step < total_steps:
        epoch_index += 1
        if args.epochs > 0:
            epoch_batches = build_group_balanced_epoch_batches(
                normal_pool,
                anomaly_pool,
                batch_size=args.batch_size,
                rng=rng,
            )
        else:
            epoch_batches = [
                sample_balanced_batch(normal_pool, anomaly_pool, batch_size=args.batch_size, rng=rng)
                for _ in range(args.steps)
            ]

        epoch_total = min(len(epoch_batches), max(0, total_steps - global_step))
        progress = tqdm(
            total=epoch_total,
            desc=f"epoch {epoch_index}/{args.epochs}" if args.epochs > 0 else "train",
            leave=True,
            dynamic_ncols=True,
        )

        for epoch_step, batch in enumerate(epoch_batches, start=1):
            global_step += 1
            if global_step > total_steps:
                break

            images, masks_t, basis_t = build_batch_tensors(
                batch, backbone, mask_transform, semantic_basis_by_class, args, device
            )
            layer_tokens = backbone.extract_layer_patch_tokens(images, target_layers=[args.target_layer])[args.target_layer]
            patch_mask_flat = (
                F.interpolate(masks_t.float(), size=backbone.grid_size, mode="nearest")[:, 0].reshape(len(batch), -1) > 0.5
            )

            optimizer.zero_grad(set_to_none=True)
            out = refiner(layer_tokens, semantic_basis=basis_t, spatial_shape=backbone.grid_size, num_steps=args.num_steps)
            loss_stats = objective(
                raw_features=layer_tokens,
                refined_features=out.refined,
                anomaly_mask=patch_mask_flat,
                local_mean=out.local_mean,
                basis=out.basis,
                metric_det=out.metric_det,
                spatial_shape=backbone.grid_size,
            )
            loss = loss_stats["loss"]
            loss.backward()
            optimizer.step()

            row = {
                "step": global_step,
                "epoch": epoch_index,
                "epoch_step": epoch_step,
                "batch_size_actual": len(batch),
                "loss": float(loss.item()),
                "loss_sep": float(loss_stats["loss_sep"].item()),
                "loss_project": float(loss_stats["loss_project"].item()),
                "loss_vol": float(loss_stats["loss_vol"].item()),
                "contrast_gap": float(loss_stats["contrast_gap"].item()),
                "delta_norm": float(out.delta.float().norm(dim=-1).mean().item()),
                "metric_det": float(out.metric_det.float().mean().item()),
                "alpha_mean": float(out.alpha.float().mean().item()),
                "eta_mean": float(out.eta.float().mean().item()),
                "lambda_mean": float(out.lambda_diag.float().mean().item()),
                "basis_orth_mean": float(out.basis_orthogonality.float().mean().item()),
            }
            if global_step == 1 or global_step % args.eval_interval == 0 or global_step == total_steps:
                probe = aggregate_probe_metrics(
                    refiner=refiner,
                    objective=objective,
                    backbone=backbone,
                    probe_batch=probe_batch,
                    semantic_basis_by_class=semantic_basis_by_class,
                    mask_transform=mask_transform,
                    args=args,
                    device=device,
                )
                row.update(probe)
                if probe["probe_score"] > best_probe_score:
                    best_probe_score = probe["probe_score"]
                    best_step = global_step
                    torch.save(checkpoint_payload(), ckpt_path)
                if args.save_eval_ckpts:
                    eval_ckpt_path = ckpt_dir / f"step{global_step:05d}_epoch{epoch_index:02d}_eval.pt"
                    torch.save(checkpoint_payload(), eval_ckpt_path)
            rows.append(row)
            progress.set_postfix(
                step=global_step,
                loss=f"{row['loss']:.4f}",
                gap=f"{row.get('probe_contrast_gap', float('nan')):.4f}",
                proj=f"{row['loss_project']:.4f}",
                vol=f"{row['loss_vol']:.4f}",
                det=f"{row['metric_det']:.2f}",
                pca=f"{row.get('probe_pca_align', float('nan')):.4f}",
            )
            progress.update(1)
        if args.save_epoch_ckpts:
            epoch_ckpt_path = ckpt_dir / f"epoch{epoch_index:02d}_last_step{global_step:05d}.pt"
            torch.save(checkpoint_payload(), epoch_ckpt_path)
        progress.close()

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "route": "raw_backbone",
        "family": "riemannian_lowrank",
        "backbone": args.backbone,
        "target_layer": args.target_layer,
        "rank": args.rank,
        "num_steps": args.num_steps,
        "steps": total_steps,
        "requested_steps": args.steps,
        "epochs": args.epochs,
        "steps_per_epoch": steps_per_epoch if args.epochs > 0 else None,
        "sampling_mode": "group_epoch" if args.epochs > 0 else "random_image_resample",
        "save_eval_ckpts": args.save_eval_ckpts,
        "save_epoch_ckpts": args.save_epoch_ckpts,
        "ckpt_dir": str(ckpt_dir),
        "best_probe_step": best_step,
        "best_probe_score": best_probe_score,
        "final_row": rows[-1],
        "runtime_sec": time.time() - start,
        "audit": audit,
        "trainable_meta": trainable_meta,
        "normal_group_meta": normal_group_meta,
        "anomaly_group_meta": anomaly_group_meta,
    }
    json_path.write_text(json.dumps(summary, indent=2))

    try:
        fig, ax = plt.subplots(1, 1, figsize=(7, 4))
        ax.plot([r["step"] for r in rows], [r["loss"] for r in rows], label="loss")
        probe_rows = [r for r in rows if "probe_score" in r]
        if probe_rows:
            ax.plot([r["step"] for r in probe_rows], [r["probe_score"] for r in probe_rows], label="probe_score")
            ax.plot([r["step"] for r in probe_rows], [r["probe_contrast_gap"] for r in probe_rows], label="probe_gap")
        ax.legend()
        ax.set_xlabel("step")
        fig.tight_layout()
        fig.savefig(png_path, dpi=150)
        plt.close(fig)
    except Exception:
        pass

    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")
    print(f"saved_ckpt={ckpt_path}")


if __name__ == "__main__":
    main()
