from __future__ import annotations

import argparse
import csv
import gc
import json
import math
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter
from sklearn.metrics import roc_auc_score

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
OFFICIAL_VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MVTED_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"
MVTED_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale" / "epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026" / "AnomalyCLIP" / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from prompt_ensemble import encode_text_with_prompt_ensemble  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import build_model, get_learned_text_pair, load_prompt_learner  # noqa: E402
from utils import get_transform  # noqa: E402


def build_eval_dataset(root: str, dataset_name: str, image_size: int, mode: str = "test"):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name=dataset_name, mode=mode)


def validate_visa_root(root: str, dataset_name: str) -> None:
    if dataset_name.lower() != "visa":
        return
    resolved = Path(root).resolve()
    official = OFFICIAL_VISA_ROOT.resolve()
    if resolved != official:
        raise ValueError(
            "VisA experiments must use the official root only: "
            f"{official}. Got: {resolved}"
        )


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = np.asarray(arr, dtype=np.float32).reshape(-1)
    if flat.size == 0:
        return float("nan")
    k = max(1, int(math.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def safe_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    y = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    s = np.concatenate([pos, neg])
    return float(roc_auc_score(y, s))


def top_fraction_mask(score_map: np.ndarray, frac: float) -> np.ndarray:
    flat = score_map.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    thresh = np.partition(flat, -k)[-k]
    return score_map >= thresh


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    inter = float(np.logical_and(a, b).sum())
    union = float(np.logical_or(a, b).sum())
    if union <= 0:
        return float("nan")
    return inter / union


def mask_overlap(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(a.sum())
    if denom <= 0:
        return float("nan")
    return float(np.logical_and(a, b).sum()) / denom


def safe_corr(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float32).reshape(-1)
    y = np.asarray(b, dtype=np.float32).reshape(-1)
    if x.size < 2 or y.size < 2:
        return float("nan")
    sx = float(np.std(x))
    sy = float(np.std(y))
    if sx < 1e-12 or sy < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def anomaly_score_map(patch_feature: torch.Tensor, text_pair: torch.Tensor) -> torch.Tensor:
    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
    return (similarity[:, 1:, 1] + 1 - similarity[:, 1:, 0]) / 2.0


def aggregate_map_from_patch_features(
    patch_features: list[torch.Tensor],
    text_pair: torch.Tensor,
    image_size: int,
    sigma: float,
) -> np.ndarray:
    maps = []
    for patch_feature in patch_features:
        flat_score = anomaly_score_map(patch_feature, text_pair)
        sim_map = AnomalyCLIP_lib.get_similarity_map(flat_score.unsqueeze(-1), image_size)[..., 0]
        maps.append(sim_map)
    score_map = torch.stack(maps).mean(dim=0)[0].detach().cpu().numpy()
    return gaussian_filter(score_map, sigma=sigma)


def build_reference_text_model(device: str):
    reference_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=None)
    reference_model.eval()
    return reference_model


def static_text_pair_for_class(reference_model, cls_name: str, device: str) -> torch.Tensor:
    text_pair = encode_text_with_prompt_ensemble(reference_model, [cls_name.replace("_", " ")], device)
    text_pair = F.normalize(text_pair.float(), dim=-1)
    return text_pair.detach()


def global_image_score(image_features: torch.Tensor, text_pair: torch.Tensor) -> float:
    image_features = F.normalize(image_features.float(), dim=-1)
    return float(((image_features @ text_pair.t()) / 0.07).softmax(dim=-1)[0, 1].item())


def cleanup_image_state(device: str) -> None:
    gc.collect()
    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()


def current_rss_mb() -> float:
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    parts = line.split()
                    if len(parts) >= 2:
                        return float(parts[1]) / 1024.0
    except OSError:
        pass
    return float("nan")


def mean_ignoring_nan(values: list[float]) -> float:
    vals = [v for v in values if np.isfinite(v)]
    if not vals:
        return float("nan")
    return float(np.mean(vals))


def rank_1_based_desc(values: dict[str, float], target_key: str) -> int:
    ordered = sorted(values.items(), key=lambda kv: kv[1], reverse=True)
    for idx, (key, _) in enumerate(ordered, start=1):
        if key == target_key:
            return idx
    return len(ordered)


def save_outputs(summary: dict, rows: list[dict], save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    if rows:
        with open(save_dir / "metrics.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)


def append_partial_row(save_dir: Path, row: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.jsonl", "a") as f:
        f.write(json.dumps(row) + "\n")


def write_progress(save_dir: Path, payload: dict) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "progress.json", "w") as f:
        json.dump(payload, f, indent=2)


def resolve_preset(args) -> None:
    preset = args.preset
    if preset is None:
        return
    if preset == "visa2mvtec":
        args.checkpoint_path = str(VISA_CKPT)
        args.target_root = str(MVTED_ROOT)
        args.target_dataset = "mvtec"
    elif preset == "mvtec2visa":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(OFFICIAL_VISA_ROOT)
        args.target_dataset = "visa"
    elif preset == "mvtec2mpdd":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(MPDD_ROOT)
        args.target_dataset = "mpdd"
    elif preset == "mvtec2btad":
        args.checkpoint_path = str(MVTED_CKPT)
        args.target_root = str(BTAD_ROOT)
        args.target_dataset = "btad"
    else:
        raise ValueError(f"Unknown preset: {preset}")


def main():
    parser = argparse.ArgumentParser("Wrong-class prompt semantic-collapse audit for AnomalyCLIP")
    parser.add_argument("--preset", type=str, default=None, choices=["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"])
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(VISA_CKPT),
    )
    parser.add_argument("--target_root", type=str, default=str(OFFICIAL_VISA_ROOT))
    parser.add_argument("--target_dataset", type=str, default="visa")
    parser.add_argument("--target_mode", type=str, default="test")
    parser.add_argument("--target_classes", nargs="*", default=None)
    parser.add_argument("--candidate_classes", nargs="*", default=None)
    parser.add_argument("--max_anomaly_images_per_class", type=int, default=24)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--map_topk", type=float, default=0.01)
    parser.add_argument("--progress_every", type=int, default=1)
    parser.add_argument("--cpu_threads", type=int, default=1)
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_wrongclass_semantic_collapse"),
    )
    args = parser.parse_args()

    resolve_preset(args)
    torch.set_num_threads(max(1, int(args.cpu_threads)))
    try:
        torch.set_num_interop_threads(max(1, int(args.cpu_threads)))
    except RuntimeError:
        pass
    device = args.device
    validate_visa_root(args.target_root, args.target_dataset)
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    learned_pair = get_learned_text_pair(model, learner).to(device)
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "model_ready",
                "pid": os.getpid(),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )
    reference_model = build_reference_text_model(device)
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "reference_model_ready",
                "pid": os.getpid(),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )
    save_dir = Path(args.save_dir)
    write_progress(
        save_dir,
        {
            "event": "start",
            "pid": os.getpid(),
            "preset": args.preset,
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "candidate_classes": args.candidate_classes,
            "max_anomaly_images_per_class": args.max_anomaly_images_per_class,
            "rss_mb": round(current_rss_mb(), 2),
        },
    )

    dataset = build_eval_dataset(args.target_root, args.target_dataset, args.image_size, mode=args.target_mode)
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "dataset_ready",
                "pid": os.getpid(),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )
    target_class_filter = set(args.target_classes) if args.target_classes else None
    candidate_classes = args.candidate_classes or list(dataset.obj_list)
    candidate_classes = sorted(dict.fromkeys(candidate_classes))
    target_classes = target_class_filter or set(dataset.obj_list)
    print(
        json.dumps(
            {
                "event": "stage",
                "name": "candidate_classes_ready",
                "pid": os.getpid(),
                "candidate_count": len(candidate_classes),
                "rss_mb": round(current_rss_mb(), 2),
            }
        ),
        flush=True,
    )
    cleanup_image_state(device)

    rows: list[dict] = []
    per_class_seen = {cls: 0 for cls in dataset.obj_list}
    target_class_list = sorted(target_classes)

    with torch.inference_mode():
        for idx in range(len(dataset)):
            if all(per_class_seen.get(cls, 0) >= args.max_anomaly_images_per_class for cls in target_class_list):
                break
            item = dataset[idx]
            cls_name = item["cls_name"]
            if cls_name not in target_classes:
                continue
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            if int(anomaly_flag) == 0:
                continue
            if per_class_seen[cls_name] >= args.max_anomaly_images_per_class:
                continue
            per_class_seen[cls_name] += 1
            if args.progress_every > 0:
                print(
                    json.dumps(
                        {
                            "event": "image_start",
                            "pid": os.getpid(),
                            "dataset_index": idx,
                            "class_name": cls_name,
                            "rows_done": len(rows),
                            "rss_mb": round(current_rss_mb(), 2),
                        }
                    ),
                    flush=True,
                )

            image = item["img"].unsqueeze(0).to(device)
            mask_tensor = item["img_mask"]
            if torch.is_tensor(mask_tensor):
                gt_mask = mask_tensor.squeeze().detach().cpu().numpy() > 0.5
            else:
                gt_mask = np.asarray(mask_tensor).squeeze() > 0.5
            if not gt_mask.any():
                continue

            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            learned_map = aggregate_map_from_patch_features(patch_features, learned_pair, args.image_size, args.sigma)
            learned_image_score = global_image_score(image_features, learned_pair)

            prompt_image_scores: dict[str, float] = {}
            prompt_local_auc: dict[str, float] = {}
            true_text_pair = static_text_pair_for_class(reference_model, cls_name, device)
            true_map = aggregate_map_from_patch_features(patch_features, true_text_pair, args.image_size, args.sigma)
            prompt_image_scores[cls_name] = global_image_score(image_features, true_text_pair)
            prompt_local_auc[cls_name] = safe_auc(true_map[gt_mask], true_map[~gt_mask])
            true_mask = top_fraction_mask(true_map, args.map_topk)
            learned_mask = top_fraction_mask(learned_map, args.map_topk)

            wrong_classes = [name for name in candidate_classes if name != cls_name]
            wrong_corr: list[float] = []
            wrong_overlap: list[float] = []
            wrong_iou: list[float] = []
            wrong_image_scores: list[float] = []
            wrong_local_auc: list[float] = []
            learned_vs_wrong_corr: list[float] = []
            learned_vs_wrong_overlap: list[float] = []

            del true_text_pair

            for prompt_cls in wrong_classes:
                text_pair = static_text_pair_for_class(reference_model, prompt_cls, device)
                score_map = aggregate_map_from_patch_features(patch_features, text_pair, args.image_size, args.sigma)
                prompt_image_scores[prompt_cls] = global_image_score(image_features, text_pair)
                prompt_local_auc[prompt_cls] = safe_auc(score_map[gt_mask], score_map[~gt_mask])
                wrong_image_scores.append(prompt_image_scores[prompt_cls])
                wrong_local_auc.append(prompt_local_auc[prompt_cls])
                wrong_corr.append(safe_corr(true_map, score_map))
                wrong_mask = top_fraction_mask(score_map, args.map_topk)
                wrong_overlap.append(mask_overlap(true_mask, wrong_mask))
                wrong_iou.append(mask_iou(true_mask, wrong_mask))
                learned_vs_wrong_corr.append(safe_corr(learned_map, score_map))
                learned_vs_wrong_overlap.append(mask_overlap(learned_mask, wrong_mask))
                del text_pair, score_map, wrong_mask
                cleanup_image_state(device)

            row = {
                "image_id": idx,
                "class_name": cls_name,
                "candidate_count": len(candidate_classes),
                "true_prompt_image_score": prompt_image_scores[cls_name],
                "true_prompt_local_auc": prompt_local_auc[cls_name],
                "true_prompt_rank_image": rank_1_based_desc(prompt_image_scores, cls_name),
                "true_prompt_rank_local": rank_1_based_desc(prompt_local_auc, cls_name),
                "true_minus_wrong_mean_image": float(prompt_image_scores[cls_name] - np.mean(wrong_image_scores)),
                "true_minus_wrong_mean_local_auc": float(prompt_local_auc[cls_name] - np.mean(wrong_local_auc)),
                "mean_true_wrong_corr": mean_ignoring_nan(wrong_corr),
                "mean_true_wrong_topk_overlap": mean_ignoring_nan(wrong_overlap),
                "mean_true_wrong_topk_iou": mean_ignoring_nan(wrong_iou),
                "learned_image_score": learned_image_score,
                "learned_vs_true_corr": safe_corr(learned_map, true_map),
                "learned_vs_mean_wrong_corr": mean_ignoring_nan(learned_vs_wrong_corr),
                "learned_vs_true_topk_overlap": mask_overlap(learned_mask, true_mask),
                "learned_vs_mean_wrong_topk_overlap": mean_ignoring_nan(learned_vs_wrong_overlap),
            }
            rows.append(row)
            append_partial_row(save_dir, row)
            write_progress(
                save_dir,
                {
                    "event": "row_saved",
                    "pid": os.getpid(),
                    "dataset_index": idx,
                    "rows_done": len(rows),
                    "class_name": cls_name,
                    "rss_mb": round(current_rss_mb(), 2),
                },
            )
            if args.progress_every > 0 and (len(rows) % args.progress_every == 0):
                print(
                    json.dumps(
                        {
                            "event": "image_done",
                            "pid": os.getpid(),
                            "dataset_index": idx,
                            "rows_done": len(rows),
                            "class_name": cls_name,
                            "rss_mb": round(current_rss_mb(), 2),
                        }
                    ),
                    flush=True,
                )
            del image, image_features, patch_features, learned_map, true_map, true_mask, learned_mask
            cleanup_image_state(device)

    num_classes = len(candidate_classes)
    image_top1 = [1.0 if r["true_prompt_rank_image"] == 1 else 0.0 for r in rows]
    local_top1 = [1.0 if r["true_prompt_rank_local"] == 1 else 0.0 for r in rows]
    summary = {
        "settings": {
            "checkpoint_path": args.checkpoint_path,
            "target_root": args.target_root,
            "target_dataset": args.target_dataset,
            "target_classes": sorted(target_classes),
            "candidate_classes": candidate_classes,
            "image_score_topk": args.image_score_topk,
            "map_topk": args.map_topk,
            "sigma": args.sigma,
            "features_list": args.features_list,
        },
        "summary": {
            "num_images": len(rows),
            "num_candidate_classes": num_classes,
            "chance_top1_rate": 1.0 / max(1, num_classes),
            "true_prompt_top1_rate_image": mean_ignoring_nan(image_top1),
            "true_prompt_top1_rate_local": mean_ignoring_nan(local_top1),
            "true_prompt_mean_rank_image": mean_ignoring_nan([float(r["true_prompt_rank_image"]) for r in rows]),
            "true_prompt_mean_rank_local": mean_ignoring_nan([float(r["true_prompt_rank_local"]) for r in rows]),
            "mean_true_minus_wrong_image": mean_ignoring_nan([r["true_minus_wrong_mean_image"] for r in rows]),
            "mean_true_minus_wrong_local_auc": mean_ignoring_nan([r["true_minus_wrong_mean_local_auc"] for r in rows]),
            "mean_true_wrong_corr": mean_ignoring_nan([r["mean_true_wrong_corr"] for r in rows]),
            "mean_true_wrong_topk_overlap": mean_ignoring_nan([r["mean_true_wrong_topk_overlap"] for r in rows]),
            "mean_true_wrong_topk_iou": mean_ignoring_nan([r["mean_true_wrong_topk_iou"] for r in rows]),
            "mean_learned_vs_true_corr": mean_ignoring_nan([r["learned_vs_true_corr"] for r in rows]),
            "mean_learned_vs_wrong_corr": mean_ignoring_nan([r["learned_vs_mean_wrong_corr"] for r in rows]),
            "mean_learned_vs_true_topk_overlap": mean_ignoring_nan([r["learned_vs_true_topk_overlap"] for r in rows]),
            "mean_learned_vs_wrong_topk_overlap": mean_ignoring_nan([r["learned_vs_mean_wrong_topk_overlap"] for r in rows]),
            "semantic_gap_top1": mean_ignoring_nan(image_top1) - mean_ignoring_nan(local_top1),
            "semantic_gap_rank": mean_ignoring_nan([float(r["true_prompt_rank_local"]) for r in rows])
            - mean_ignoring_nan([float(r["true_prompt_rank_image"]) for r in rows]),
            "learned_true_wrong_corr_gap": mean_ignoring_nan([r["learned_vs_mean_wrong_corr"] for r in rows])
            - mean_ignoring_nan([r["learned_vs_true_corr"] for r in rows]),
            "learned_true_wrong_topk_overlap_gap": mean_ignoring_nan([r["learned_vs_mean_wrong_topk_overlap"] for r in rows])
            - mean_ignoring_nan([r["learned_vs_true_topk_overlap"] for r in rows]),
        },
    }
    save_outputs(summary, rows, save_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
