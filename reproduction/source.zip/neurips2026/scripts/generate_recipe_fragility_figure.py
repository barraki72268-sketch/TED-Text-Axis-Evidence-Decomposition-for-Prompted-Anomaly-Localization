#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
INPUT = ROOT / "neurips2026" / "results" / "adaclip_recipe_fragility" / "collected_pilot_v1" / "recipe_fragility_summary.json"
OUT_DIR = ROOT / "neurips2026" / "results" / "recipe_fragility_figure"


def main() -> None:
    rows = json.loads(INPUT.read_text())
    rows = [r for r in rows if r["mode"] == "baseline_txt"]
    presets = ["visa2mvtec", "mvtec2btad"]
    recipes = ["all4", "mid2", "last2", "earlylate", "last"]
    colors = {
        "all4": "#18202c",
        "mid2": "#2f9e66",
        "last2": "#4f8bd6",
        "earlylate": "#e6a23c",
        "last": "#d14b3f",
    }

    fig = plt.figure(figsize=(12.5, 5.2), constrained_layout=True)
    gs = fig.add_gridspec(1, 2, width_ratios=[1.35, 1.0])
    ax = fig.add_subplot(gs[0, 0])
    x = np.arange(len(presets))
    width = 0.15
    for i, recipe in enumerate(recipes):
        vals = []
        for preset in presets:
            row = next(r for r in rows if r["preset"] == preset and r["layer_recipe"] == recipe)
            vals.append(float(row["pixel_ap"]) * 100.0)
        ax.bar(x + (i - 2) * width, vals, width, label=recipe, color=colors[recipe])

    ax.set_xticks(x)
    ax.set_xticklabels(["VisA -> MVTec", "MVTec -> BTAD"], fontsize=11, fontweight="bold")
    ax.set_ylabel("pixel AP (%)", fontsize=11, fontweight="bold")
    ax.set_title("Layer recipe changes can collapse a CLIP-AD host", fontsize=14, fontweight="bold", loc="left")
    ax.set_ylim(0, 58)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False, ncols=5, fontsize=9, loc="upper right")

    for j, preset in enumerate(presets):
        all4 = next(r for r in rows if r["preset"] == preset and r["layer_recipe"] == "all4")
        last = next(r for r in rows if r["preset"] == preset and r["layer_recipe"] == "last")
        drop = (float(all4["pixel_ap"]) - float(last["pixel_ap"])) * 100.0
        y = min(max(float(all4["pixel_ap"]), float(last["pixel_ap"])) * 100.0 + 2.0, 52.0)
        ax.text(j, y, f"last-layer drop\n-{drop:.1f} AP", ha="center", va="bottom", fontsize=10, fontweight="bold")

    ax2 = fig.add_subplot(gs[0, 1])
    ax2.axis("off")
    ax2.text(0.0, 0.97, "What this supports", fontsize=14, fontweight="bold", va="top")
    bullets = [
        ("Host recipes are not plug-and-play.", "A small layer-hook change changes the score geometry."),
        ("Backbone transfer is not free.", "A new backbone likely needs another layer/search recipe."),
        ("OURS is a correction module.", "It reuses frozen local features and text-conditioned support banks."),
        ("The advantage is lower search cost.", "We avoid training a new prompt/head for each host/backbone."),
    ]
    y = 0.82
    for head, body in bullets:
        ax2.text(0.02, y, head, fontsize=11.5, fontweight="bold", color="#111827", va="top")
        ax2.text(0.02, y - 0.07, body, fontsize=10.2, color="#4b5563", va="top")
        y -= 0.20

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT_DIR / "recipe_fragility_story.png", dpi=240, bbox_inches="tight")
    fig.savefig(OUT_DIR / "recipe_fragility_story.pdf", bbox_inches="tight")
    print(OUT_DIR / "recipe_fragility_story.png")
    print(OUT_DIR / "recipe_fragility_story.pdf")


if __name__ == "__main__":
    main()
