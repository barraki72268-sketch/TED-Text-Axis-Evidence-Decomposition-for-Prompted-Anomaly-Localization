#!/usr/bin/env python3
from __future__ import annotations

import csv
import random
import subprocess
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
SETTING_SCRIPT = ROOT / "neurips2026" / "scripts" / "make_failure_conditioned_setting_plot_20260504.py"
CSV_PATH = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables" / "failure_conditioned_setting_level_20260504.csv"
OUT = ROOT / "supp_fig" / "failure_conditioned_separability_bootstrap_20260506.tex"
MIN_HOST_SETTINGS = 3
EXCLUDED_HOSTS = {"AnomalyCLIP"}


def boot(vals: list[float], draws: int = 20000, seed: int = 0) -> tuple[float, float]:
    rng = random.Random(seed)
    n = len(vals)
    means = []
    for _ in range(draws):
        means.append(sum(vals[rng.randrange(n)] for _ in range(n)) / n)
    means.sort()
    return means[int(0.025 * draws)], means[int(0.975 * draws)]


def fmt_pct(x: float) -> str:
    return f"{100.0 * x:+.1f}"


def fmt_loc(x: float) -> str:
    return f"{x:+.1f}"


def main() -> int:
    subprocess.run([str(PY), str(SETTING_SCRIPT.relative_to(ROOT))], cwd=ROOT, check=True)
    rows = list(csv.DictReader(CSV_PATH.open()))
    host_order = ["FAPrompt", "AA-CLIP", "AdaCLIP", "AdaptCLIP", "AnomalyCLIP"]
    scopes = []
    included_rows = []
    for host in host_order:
        if host in EXCLUDED_HOSTS:
            continue
        sub = [r for r in rows if r["host"] == host]
        if len(sub) < MIN_HOST_SETTINGS:
            continue
        scopes.append((host, sub))
        included_rows.extend(sub)
    scopes.append(("All adapted hosts", included_rows))

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{",
        r"Failure-conditioned separability robustness.",
        r"Intervals are setting-level percentile bootstrap 95\% CIs over completed adapted-host settings.",
        r"$\Delta$AUC measures the change in AUC for ranking anomalous regions above hard normal regions.",
        r"$\Delta$Loc is the mean of $\Delta$PRO and $\Delta$AP.",
        r"}",
        r"\label{tab:failure_tab}",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{4.0pt}",
        r"\renewcommand{\arraystretch}{1.08}",
        r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}lccc@{}}",
        r"\toprule",
        r"Scope & $n$ & $\Delta$AUC [95\% CI] & $\Delta$Loc [95\% CI] \\",
        r"\midrule",
    ]
    for name, sub in scopes:
        if not sub:
            continue
        vals_auc = [float(r["delta_auc_d_hfp"]) for r in sub]
        vals_loc = [float(r["delta_local"]) for r in sub]
        ci_auc = boot(vals_auc)
        ci_loc = boot(vals_loc)
        lines.append(
            f"{name} & {len(sub)} "
            f"& {fmt_pct(float(np.mean(vals_auc)))} [{fmt_pct(ci_auc[0])}, {fmt_pct(ci_auc[1])}] "
            f"& {fmt_loc(float(np.mean(vals_loc)))} [{fmt_loc(ci_loc[0])}, {fmt_loc(ci_loc[1])}] \\\\"
        )
    lines += [r"\bottomrule", r"\end{tabular*}", r"\end{table}", ""]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines))
    print({"rows": len(rows), "table": str(OUT.relative_to(ROOT))})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
