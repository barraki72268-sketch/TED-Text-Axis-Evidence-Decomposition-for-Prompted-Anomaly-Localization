#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "adapted_hosts_mvtec2_20260503"
LOG_DIR = RESULTS / "logs"


BACKBONES = {
    "vitbplus": {
        "label": "ViT-B/16+",
        "model_name": "ViT-B-16-plus-240",
        "pretrained": "laion400m_e32",
        "adapter": "project_crop",
        "levels": "3,6,9,12",
        "img_size": "518",
        "batch_size": "8",
    },
    "vitl_openai224": {
        "label": "ViT-L/14 OpenAI",
        "model_name": "ViT-L-14-336",
        "pretrained": "openai",
        "adapter": "strict",
        "levels": "6,12,18,24",
        "img_size": "224",
        "batch_size": "8",
    },
    "vitl336": {
        "label": "ViT-L/14-336",
        "model_name": "ViT-L-14-336",
        "pretrained": "openai",
        "adapter": "strict",
        "levels": "6,12,18,24",
        "img_size": "518",
        "batch_size": "4",
    },
    "vith14": {
        "label": "ViT-H/14",
        "model_name": "ViT-H-14",
        "pretrained": "laion2b_s32b_b79k",
        "adapter": "project_crop",
        "levels": "8,16,24,32",
        "img_size": "224",
        "batch_size": "4",
    },
}


def parse_csv(text: str, allowed: set[str] | None = None) -> list[str]:
    values = [v.strip() for v in text.split(",") if v.strip()]
    if allowed is not None:
        bad = [v for v in values if v not in allowed]
        if bad:
            raise SystemExit(f"unknown values {bad}; allowed={sorted(allowed)}")
    return values


def run_one(tag: str, seed: int, device: str, force: bool) -> int:
    cfg = BACKBONES[tag]
    save_dir = RESULTS / f"aaclip_{tag}_mvtec2mvtecad2_seed{seed}"
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        print({"stage": "skip", "tag": tag, "label": cfg["label"], "summary": str(summary)}, flush=True)
        return 0
    if force and summary.exists():
        summary.unlink()

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/run_aaclip_mvtec2_custom.py",
        "--model_name",
        cfg["model_name"],
        "--pretrained",
        cfg["pretrained"],
        "--adapter_load_mode",
        cfg["adapter"],
        "--levels",
        cfg["levels"],
        "--img_size",
        cfg["img_size"],
        "--batch_size",
        cfg["batch_size"],
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    log_path = LOG_DIR / f"aaclip_{tag}_mvtec2_seed{seed}.log"
    print({"stage": "run", "tag": tag, "label": cfg["label"], "log": str(log_path), "cmd": cmd}, flush=True)
    with log_path.open("w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "finished", "tag": tag, "returncode": proc.returncode, "log": str(log_path)}, flush=True)
    return proc.returncode


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backbones", default="vitbplus,vitl_openai224,vitl336,vith14")
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    env = os.environ
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-aaclip-mvtec2-20260504")
    env.setdefault("TRANSFORMERS_CACHE", "/mnt/data/hf-cache")

    RESULTS.mkdir(parents=True, exist_ok=True)
    tags = parse_csv(args.backbones, set(BACKBONES))
    seeds = [int(x) for x in parse_csv(args.seeds)]
    failed = 0
    for seed in seeds:
        for tag in tags:
            failed += int(run_one(tag=tag, seed=seed, device=args.device, force=args.force) != 0)
            time.sleep(3)
    print({"stage": "done", "failed": failed}, flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
