#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026/scripts/official_parallel_test_adaptclip_vlrefine.py"
OUT = ROOT / "neurips2026/results/adaptclip_layer_stress_cted_recovery_20260502"
LOG = OUT / "logs"
BANK = ROOT / "neurips2026/results/bank_cache"

MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
MPDD = Path("/mnt/data/MPDD")
BTAD = ROOT / "neurips2026/data/BTAD_official"

MVTEC_CKPT = ROOT / "neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_mvtec_3adpaters_batch8/epoch_15.pth"
VISA_CKPT = ROOT / "neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth"

TRANSFERS = {
    "visa2mvtec": (VISA, "visa", MVTEC, "mvtec", VISA_CKPT),
    "mvtec2visa": (MVTEC, "mvtec", VISA, "visa", MVTEC_CKPT),
    "mvtec2mpdd": (MVTEC, "mvtec", MPDD, "mpdd", MVTEC_CKPT),
    "mvtec2btad": (MVTEC, "mvtec", BTAD, "btad", MVTEC_CKPT),
}

RECIPES = {
    "all4": [6, 12, 18, 24],
    "earlylate": [6, 24],
    "last": [24],
}


def wait_for_pid(pid: int) -> None:
    if pid <= 0:
        return
    print({"stage": "wait", "pid": pid}, flush=True)
    while Path(f"/proc/{pid}").exists():
        time.sleep(30)
    print({"stage": "wait_done", "pid": pid}, flush=True)


def run(cmd: list[str], log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(ROOT), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"failed: {log_path}")


def main() -> int:
    parser = argparse.ArgumentParser("AdaptCLIP layer-selection burden queue.")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--gpu", default="1")
    parser.add_argument("--transfers", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    parser.add_argument("--recipes", default="all4,earlylate,last")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    wait_for_pid(args.wait_pid)

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-adaptclip-layer-selection")

    for transfer in [x.strip() for x in args.transfers.split(",") if x.strip()]:
        if transfer not in TRANSFERS:
            raise ValueError(f"unknown transfer: {transfer}")
        source_root, source_dataset, target_root, target_dataset, ckpt = TRANSFERS[transfer]
        for recipe in [x.strip() for x in args.recipes.split(",") if x.strip()]:
            if recipe not in RECIPES:
                raise ValueError(f"unknown recipe: {recipe}")
            features = RECIPES[recipe]
            save_dir = OUT / f"{transfer}_{recipe}"
            summary = save_dir / "summary.json"
            if summary.exists():
                print({"stage": "skip", "summary": str(summary)}, flush=True)
                continue
            bank = BANK / f"adaptclip_layer_stress_vitl336_{source_dataset}_{recipe}_vl_seed{args.seed}.pt"
            tl_bank = BANK / f"adaptclip_layer_stress_vitl336_{source_dataset}_{recipe}_tl_seed{args.seed}.pt"
            cmd = [
                str(PY),
                "-u",
                str(SCRIPT),
                "--source_root",
                str(source_root),
                "--source_dataset",
                source_dataset,
                "--target_root",
                str(target_root),
                "--target_dataset",
                target_dataset,
                "--checkpoint_path",
                str(ckpt),
                "--save_dir",
                str(save_dir),
                "--bank_cache_path",
                str(bank),
                "--tl_bank_cache_path",
                str(tl_bank),
                "--pretrained_model",
                "ViT-L/14@336px",
                "--checkpoint_load_mode",
                "strict",
                "--features_list",
                *[str(x) for x in features],
                "--image_size",
                "518",
                "--batch_size",
                "1",
                "--n_ctx",
                "12",
                "--sigma",
                "4",
                "--vl_reduction",
                "4",
                "--fusion_type",
                "average_mean",
                "--tau",
                "20.0",
                "--fp_weight",
                "0.3",
                "--corr_alpha",
                "0.3",
                "--map_activation",
                "sigmoid",
                "--map_temperature",
                "1.0",
                "--vl_gate_mode",
                "host",
                "--vl_gate_quantile",
                "0.9",
                "--vl_gate_temp",
                "0.25",
                "--max_good_per_class",
                "2",
                "--max_defect_per_class",
                "4",
                "--max_bank_points",
                "512",
                "--max_fp_per_image",
                "64",
                "--max_defect_per_image",
                "64",
                "--ted_insertion",
                "dual_branch",
                "--calib_epochs",
                "30",
                "--calib_hardpair_frac",
                "0.75",
                "--calib_subspace_rank",
                "8",
                "--calib_lambda",
                "0.03",
                "--calib_score_mode",
                "rankr_readout",
                "--calib_rankr_tau",
                "0.1",
                "--calib_apply_mode",
                "add",
                "--eval_metrics",
                "I-AUROC",
                "I-AP",
                "P-AUROC",
                "P-AP",
                "P-AUPRO",
                "--aupro_max_step",
                "200",
                "--aupro_expect_fpr",
                "0.3",
                "--seed",
                str(args.seed),
                "--device",
                "cuda:0",
                "--num_workers",
                "4",
            ]
            run(cmd, LOG / f"adaptclip_vitl336_{transfer}_{recipe}.log", env)

    print({"stage": "done", "task": "adaptclip_layer_selection_burden"}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
