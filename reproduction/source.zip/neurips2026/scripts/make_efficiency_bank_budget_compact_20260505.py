#!/usr/bin/env python3
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
IN_CSV = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables" / "efficiency_bank_budget_20260504.csv"
OUT = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"


def f(x: str) -> float:
    return float(x)


def main() -> int:
    rows = list(csv.DictReader(IN_CSV.open()))
    groups: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        groups[(row["host"], int(row["budget"]))].append(row)

    summary = []
    for (host, budget), items in sorted(groups.items()):
        dpro = np.array([f(r["c_pro"]) - f(r["base_pro"]) for r in items])
        dap = np.array([f(r["c_ap"]) - f(r["base_ap"]) for r in items])
        dpauc = np.array([f(r["c_pauc"]) - f(r["base_pauc"]) for r in items])
        loc = 0.5 * (dpro + dap)
        latency = np.array([f(r["latency_ms_per_image"]) for r in items])
        mem = np.array([f(r["peak_gpu_mem_mb"]) / 1024.0 for r in items])
        retained = np.array([f(r["retained_bank"]) for r in items])
        summary.append(
            {
                "host": host,
                "budget": budget,
                "n": len(items),
                "retained_mean": float(retained.mean()),
                "latency_mean": float(latency.mean()),
                "mem_mean": float(mem.mean()),
                "delta_pauc": float(dpauc.mean()),
                "delta_pro": float(dpro.mean()),
                "delta_ap": float(dap.mean()),
                "delta_loc": float(loc.mean()),
            }
        )

    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / "efficiency_bank_budget_compact_20260505.csv"
    with csv_path.open("w", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)

    def fmt(x: float) -> str:
        return f"{x:.1f}"

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Fixed source-bank budget sensitivity. Values are averaged over completed transfer settings for each host and bank budget. $\Delta$Loc is the mean of $\Delta$PRO and $\Delta$AP over the host baseline.}",
        r"\label{tab:supp_efficiency_bank_budget_compact}",
        r"\small",
        r"\setlength{\tabcolsep}{3.6pt}",
        r"\renewcommand{\arraystretch}{1.08}",
        r"\resizebox{\linewidth}{!}{%",
        r"\begin{tabular}{lrrrrrr}",
        r"\toprule",
        r"Host & Budget & $n$ & Retained & ms/img & Mem. & $\Delta$Loc \\",
        r"\midrule",
    ]
    for row in summary:
        lines.append(
            f"{row['host']} & {row['budget']} & {row['n']} & {fmt(row['retained_mean'])} & "
            f"{fmt(row['latency_mean'])} & {fmt(row['mem_mean'])}GB & {fmt(row['delta_loc'])} \\\\"
        )
    lines += [
        r"\bottomrule",
        r"\end{tabular}%",
        r"}",
        r"\end{table}",
        "",
    ]
    tex_path = OUT / "efficiency_bank_budget_compact_20260505.tex"
    tex_path.write_text("\n".join(lines))
    print({"csv": str(csv_path), "tex": str(tex_path), "rows": len(summary)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
