#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
SCRIPT = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
RESULTS = ROOT / "neurips2026/results"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")
MVTEC_CKPT = str(ROOT / "neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth")


VARIANTS = {
    "rank2": "Use a rank-2 residual subspace.",
    "rank4": "Use a rank-4 residual subspace.",
    "rank8": "Use the default rank-8 residual subspace.",
    "no_hardfp": "Disable hard-false-positive support in the calibrated residual.",
    "no_preserve": "Remove the source host-margin preservation term during calibration.",
}


def wait_pid(pid: int | None) -> None:
    if pid is None or pid <= 0:
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            print({"stage": "wait_pid_done", "pid": pid}, flush=True)
            return
        time.sleep(60)


def parse_csv(text: str) -> list[str]:
    values = [v.strip() for v in text.split(",") if v.strip()]
    bad = [v for v in values if v not in VARIANTS]
    if bad:
        raise SystemExit(f"Unknown variants {bad}. Allowed: {sorted(VARIANTS)}")
    return values


def build_cmd(variant: str, device: str, seed: int) -> tuple[list[str], Path]:
    rank = {
        "rank2": "2",
        "rank4": "4",
        "rank8": "8",
        "no_hardfp": "8",
        "no_preserve": "8",
    }[variant]
    save_dir = RESULTS / f"ablation_ted_anomalyclip_vitl336_mvtec2btad_{variant}_seed{seed}_hostanchor_normfix_20260502"
    cmd = [
        str(PY),
        "-u",
        str(SCRIPT),
        "--device",
        device,
        "--checkpoint_path",
        MVTEC_CKPT,
        "--heldout_class",
        "none",
        "--source_root",
        MVTEC_ROOT,
        "--source_dataset",
        "mvtec",
        "--target_root",
        BTAD_ROOT,
        "--target_dataset",
        "btad",
        "--target_mode",
        "test",
        "--features_list",
        "24",
        "--host_patch_score_mode",
        "prob",
        "--baseline_patch_score_mode",
        "prob",
        "--enable_calibrator",
        "--calib_seed",
        str(seed),
        "--calib_epochs",
        "80",
        "--calib_subspace_rank",
        rank,
        "--calib_eta_max",
        "0.5",
        "--calib_lambda",
        "0.1",
        "--calib_map_anchor",
        "host",
        "--ted_image_score_mode",
        "host_plus_norm_topk",
        "--parallel_image_fusion_weight",
        "-0.2",
        "--calibrated_image_fusion_weight",
        "-0.02",
        "--aupro_max_step",
        "50",
        "--skip_separability_metrics",
        "--save_dir",
        str(save_dir),
    ]
    if variant == "no_hardfp":
        cmd.extend(["--calib_fp_weight_init", "0.0001"])
    elif variant == "no_preserve":
        cmd.extend(["--calib_preserve_host_margin_weight", "0.0"])
    return cmd, save_dir


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--variants", default="rank2,rank4,rank8,no_hardfp,no_preserve")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--wait_pid", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    wait_pid(args.wait_pid if args.wait_pid > 0 else None)
    for variant in parse_csv(args.variants):
        print({"stage": "variant", "variant": variant, "description": VARIANTS[variant]}, flush=True)
        cmd, save_dir = build_cmd(variant, args.device, args.seed)
        summary = save_dir / "summary.json"
        if summary.exists() and not args.force:
            print({"stage": "skip_completed", "summary": str(summary)}, flush=True)
            continue
        save_dir.mkdir(parents=True, exist_ok=True)
        print({"stage": "run", "save_dir": str(save_dir)}, flush=True)
        print(" ".join(cmd), flush=True)
        subprocess.run(cmd, cwd=str(ROOT), check=True)
    print({"stage": "done", "host": "anomalyclip", "task": "representative_ablation_normfix"}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
