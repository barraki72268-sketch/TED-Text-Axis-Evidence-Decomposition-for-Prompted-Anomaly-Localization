from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
BAYES_ROOT = ROOT / "neurips2026" / "Bayes-PFL"
os.chdir(BAYES_ROOT)
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(BAYES_ROOT) not in sys.path:
    sys.path.insert(0, str(BAYES_ROOT))

from collect_bayespfl_map_separability import build_models, infer_map  # noqa: E402
from datasets import Makedataset  # noqa: E402
from region_descriptor_utils import extract_region_descriptor, iterate_components, load_rows  # noqa: E402
from region_eval_utils import image_auroc, pixel_auroc, topk_mean  # noqa: E402
from test import _transform_test, setup_seed  # noqa: E402


def build_dataset(root: str, image_size: int):
    preprocess_test = _transform_test(image_size)
    maker = Makedataset(train_data_path=root, preprocess_test=preprocess_test, mode="test", image_size=image_size)
    loader, _ = maker.mask_dataset(name="visa", product_list=None, batchsize=1, shuf=False)
    return loader


def fit_region_classifier(fp_rows: list[dict], defect_rows: list[dict], features: list[str]):
    def rows_to_x(rows: list[dict]) -> np.ndarray:
        return np.asarray([[float(row[f]) for f in features] for row in rows], dtype=np.float32)
    X = np.concatenate([rows_to_x(fp_rows), rows_to_x(defect_rows)], axis=0)
    y = np.concatenate([np.zeros(len(fp_rows), dtype=np.int64), np.ones(len(defect_rows), dtype=np.int64)], axis=0)
    clf = Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
    clf.fit(X, y)
    return clf


def save_results(rows: list[dict], summary: dict, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe Bayes-PFL region discriminant on VisA")
    parser.add_argument("--data_path", type=str, default=str(ROOT / "neurips2026" / "Bayes-PFL" / "dataset" / "mvisa" / "data"))
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_strict_mvtec" / "epoch_post_15_1.pth"),
    )
    parser.add_argument(
        "--fp_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_region_bank_holdout_epoch15" / "fp_rows.csv"),
    )
    parser.add_argument(
        "--defect_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_region_bank_holdout_epoch15" / "defect_rows.csv"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bayespfl_region_discriminant_epoch15"),
    )
    parser.add_argument("--descriptor_combo", type=str, default="peak,mean,area,fill_ratio,compactness,ring_contrast")
    parser.add_argument("--candidate_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.25, 0.5, 0.75, 1.0])
    parser.add_argument("--modes", type=str, nargs="+", default=["gate", "dual"])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    parser.add_argument(
        "--config_path",
        type=str,
        default=str(BAYES_ROOT / "open_clip_local" / "model_configs" / "ViT-L-14-336.json"),
    )
    parser.add_argument(
        "--pretrained_path",
        type=str,
        default="/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt",
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--num_flows", type=int, default=10)
    parser.add_argument("--prompt_context_len", type=int, default=5)
    parser.add_argument("--prompt_num", type=int, default=3)
    parser.add_argument("--prompt_state_len", type=int, default=5)
    parser.add_argument("--sample_num", type=int, default=5)
    parser.add_argument("--device_id", type=int, default=0)
    parser.add_argument("--seed", type=int, default=333)
    args = parser.parse_args()

    descriptor_features = [x.strip() for x in args.descriptor_combo.split(",") if x.strip()]
    fp_rows = load_rows(Path(args.fp_csv))
    defect_rows = load_rows(Path(args.defect_csv))
    clf = fit_region_classifier(fp_rows, defect_rows, descriptor_features)
    setup_seed(args.seed)
    device, model_clip, pfl_text_encoder, my_model = build_models(args)
    loader = build_dataset(args.data_path, args.image_size)
    stage = int(Path(args.checkpoint_path).stem.split("_")[-1]) if "epoch_post" in args.checkpoint_path else 2

    rows = []
    from common_map_group_separability import top_fraction_mask  # noqa: WPS433
    for mode in args.modes:
        for alpha in args.alphas:
            image_labels, image_scores = [], []
            masks, maps = [], []
            normal_topk, normal_mean = [], []
            gaps, ratios, num_components, mean_probs = [], [], [], []
            for items in loader:
                anomaly_flag = int(items["anomaly"][0].item())
                gt_mask = items["img_mask"][0, 0].numpy() > 0.5
                image = items["img"].to(device)
                _, anomaly_map = infer_map(args, device, model_clip, pfl_text_encoder, my_model, image, items["cls_name"], stage)

                defect_prob_map = np.zeros_like(anomaly_map, dtype=np.float32)
                covered = np.zeros_like(anomaly_map, dtype=bool)
                comp_probs = []
                for frac in args.candidate_fracs:
                    mask = top_fraction_mask(anomaly_map, frac)
                    for comp in iterate_components(mask):
                        if int(comp.sum()) < args.min_area:
                            continue
                        desc = extract_region_descriptor(anomaly_map, comp)
                        if not desc:
                            continue
                        X = np.asarray([[float(desc[f]) for f in descriptor_features]], dtype=np.float32)
                        prob = float(clf.predict_proba(X)[0, 1])
                        defect_prob_map[comp] = np.maximum(defect_prob_map[comp], prob)
                        covered |= comp
                        comp_probs.append(prob)

                final_map = anomaly_map.copy()
                if covered.any():
                    if mode == "gate":
                        factor = ((1.0 - alpha) + alpha * defect_prob_map)[covered]
                        final_map[covered] = anomaly_map[covered] * factor
                    elif mode == "dual":
                        factor = (defect_prob_map - alpha * (1.0 - defect_prob_map))[covered]
                        final_map[covered] = anomaly_map[covered] * factor
                    else:
                        raise ValueError(mode)

                image_labels.append(anomaly_flag)
                image_scores.append(topk_mean(final_map, args.image_score_topk))
                masks.append(gt_mask)
                maps.append(final_map)
                num_components.append(len(comp_probs))
                mean_probs.append(float(np.mean(comp_probs)) if comp_probs else 0.5)
                if anomaly_flag == 0:
                    normal_topk.append(topk_mean(final_map, args.normal_topk_ratio))
                    normal_mean.append(float(final_map.mean()))
                elif gt_mask.any() and (~gt_mask).any():
                    inside = float(final_map[gt_mask].mean())
                    outside = float(final_map[~gt_mask].mean())
                    gaps.append(inside - outside)
                    ratios.append(outside / (inside + 1e-6))

            rows.append(
                {
                    "mode": mode,
                    "alpha": float(alpha),
                    "image_auroc": image_auroc(image_labels, image_scores),
                    "pixel_auroc": pixel_auroc(masks, maps),
                    "inside_outside_gap": float(np.mean(gaps)) if gaps else float("nan"),
                    "outside_inside_ratio": float(np.mean(ratios)) if ratios else float("nan"),
                    "normal_topk_mean": float(np.mean(normal_topk)) if normal_topk else float("nan"),
                    "normal_map_mean": float(np.mean(normal_mean)) if normal_mean else float("nan"),
                    "avg_num_components": float(np.mean(num_components)) if num_components else float("nan"),
                    "avg_mean_defect_prob": float(np.mean(mean_probs)) if mean_probs else float("nan"),
                }
            )
            print(json.dumps({"stage": "region_discriminant_progress", "mode": mode, "alpha": alpha}), flush=True)

    summary = {
        "descriptor_features": descriptor_features,
        "num_fp_rows": len(fp_rows),
        "num_defect_rows": len(defect_rows),
        "checkpoint_path": args.checkpoint_path,
    }
    save_results(rows, summary, Path(args.save_dir))
    print(json.dumps({"stage": "region_discriminant_saved", "save_dir": args.save_dir, "rows": rows}, indent=2), flush=True)


if __name__ == "__main__":
    main()
