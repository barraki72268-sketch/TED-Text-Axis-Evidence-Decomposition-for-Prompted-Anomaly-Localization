#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PYTHON="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="${ROOT}/neurips2026/scripts/official_parallel_test_adaptclip_vlrefine.py"
MVTEC_CKPT="${ROOT}/neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_mvtec_3adpaters_batch8/epoch_15.pth"
VISA_CKPT="${ROOT}/neurips2026/AdaptCLIP/checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth"
MVTEC_ROOT="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
VISA_ROOT="${ROOT}/neurips2026/data/VisA_pytorch_official/1cls"
MPDD_ROOT="/mnt/data/MPDD"
BTAD_ROOT="${ROOT}/neurips2026/data/BTAD_official"
DEVICE="${DEVICE:-cuda:1}"

export MPLCONFIGDIR="/tmp/matplotlib-adaptclip-ted-vlcalib"

run_one() {
  local source_root="$1"
  local source_dataset="$2"
  local target_root="$3"
  local target_dataset="$4"
  local ckpt="$5"
  local save_dir="$6"
  local bank_cache="$7"
  local seed="$8"

  "${PYTHON}" "${SCRIPT}" \
    --source_root "${source_root}" \
    --source_dataset "${source_dataset}" \
    --target_root "${target_root}" \
    --target_dataset "${target_dataset}" \
    --checkpoint_path "${ckpt}" \
    --save_dir "${save_dir}" \
    --bank_cache_path "${bank_cache}" \
    --pretrained_model "ViT-L/14@336px" \
    --features_list 24 \
    --image_size 518 \
    --batch_size 8 \
    --n_ctx 12 \
    --sigma 4 \
    --vl_reduction 4 \
    --fusion_type average_mean \
    --tau 20.0 \
    --fp_weight 0.3 \
    --corr_alpha 0.3 \
    --map_activation sigmoid \
    --map_temperature 1.0 \
    --max_good_per_class 2 \
    --max_defect_per_class 4 \
    --max_bank_points 512 \
    --max_fp_per_image 64 \
    --max_defect_per_image 64 \
    --calib_epochs 30 \
    --calib_lr 0.02 \
    --calib_max_train_points 2048 \
    --calib_rank_margin 0.05 \
    --calib_rank_temp 0.05 \
    --calib_eta_init 0.2 \
    --calib_eta_max 1.0 \
    --calib_eta_reg 0.001 \
    --calib_fp_weight_init 1.0 \
    --calib_hardpair_frac 0.75 \
    --calib_subspace_rank 8 \
    --calib_preserve_host_margin_weight 1.0 \
    --calib_lambda 0.3 \
    --seed "${seed}" \
    --device "${DEVICE}" \
    --num_workers 4
}

for seed in 0 1 2; do
  run_one "${MVTEC_ROOT}" "mvtec" "${VISA_ROOT}" "visa" "${MVTEC_CKPT}" \
    "${ROOT}/neurips2026/results/adaptclip_ted_vlcalib_mvtec2visa_seed${seed}_20260428" \
    "${ROOT}/neurips2026/results/bank_cache/adaptclip_ted_mvtec_vl_lastlayer_seed${seed}.pt" "${seed}"

  run_one "${MVTEC_ROOT}" "mvtec" "${MPDD_ROOT}" "mpdd" "${MVTEC_CKPT}" \
    "${ROOT}/neurips2026/results/adaptclip_ted_vlcalib_mvtec2mpdd_seed${seed}_20260428" \
    "${ROOT}/neurips2026/results/bank_cache/adaptclip_ted_mvtec_vl_lastlayer_seed${seed}.pt" "${seed}"

  run_one "${MVTEC_ROOT}" "mvtec" "${BTAD_ROOT}" "btad" "${MVTEC_CKPT}" \
    "${ROOT}/neurips2026/results/adaptclip_ted_vlcalib_mvtec2btad_seed${seed}_20260428" \
    "${ROOT}/neurips2026/results/bank_cache/adaptclip_ted_mvtec_vl_lastlayer_seed${seed}.pt" "${seed}"

  run_one "${VISA_ROOT}" "visa" "${MVTEC_ROOT}" "mvtec" "${VISA_CKPT}" \
    "${ROOT}/neurips2026/results/adaptclip_ted_vlcalib_visa2mvtec_seed${seed}_20260428" \
    "${ROOT}/neurips2026/results/bank_cache/adaptclip_ted_visa_vl_lastlayer_seed${seed}.pt" "${seed}"
done
