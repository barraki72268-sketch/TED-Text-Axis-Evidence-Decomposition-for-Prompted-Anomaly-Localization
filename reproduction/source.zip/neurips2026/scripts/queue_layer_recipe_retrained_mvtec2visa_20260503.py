#!/usr/bin/env python3
"""Queue layer-recipe retraining rows for MVTec -> VisA.

This is the source-direction extension of the layer-retrain table. It trains
each host on MVTec under a layer recipe, rebuilds the source bank from MVTec,
and evaluates B / T / C on VisA. The queue can wait for currently running
layer-retrain jobs to avoid GPU contention.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")

OUT = ROOT / "neurips2026/results/layer_recipe_retrained_mvtec2visa_20260503"
LOG = OUT / "logs"
BANK = OUT / "bank_cache"

MVTEC = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_1CLS = ROOT / "neurips2026/data/VisA_pytorch_official/1cls"
COLONDB = Path("/mnt/data/CVC-ColonDB")

ADACLIP_ROOT = ROOT / "neurips2026/AdaCLIP"
ADACLIP_EVAL = ROOT / "neurips2026/scripts/official_parallel_test_adaclip.py"
ADACLIP_OFFICIAL_MVTEC = ADACLIP_ROOT / "ckpt/pretrained_mvtec_colondb.pth"

ANOMALY_ROOT = ROOT / "neurips2026/AnomalyCLIP"
ANOMALY_EVAL = ROOT / "neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
ANOMALY_OFFICIAL_MVTEC = ANOMALY_ROOT / "checkpoints/9_12_4_multiscale/epoch_15.pth"

FAP_ROOT = ROOT / "neurips2026/FAPrompt"
FAP_EVAL = ROOT / "neurips2026/scripts/official_parallel_test_faprompt.py"
FAP_OFFICIAL_MVTEC = FAP_ROOT / "checkpoints/trained_on_mvtecad/epoch_15.pth"

RECIPES = {
    "all4": [6, 12, 18, 24],
    "earlylate": [6, 24],
    "mid2": [12, 18],
    "last2": [18, 24],
    "last": [24],
}


def live_pid(pid: int) -> bool:
    return pid > 0 and Path(f"/proc/{pid}").exists()


def wait_for_pids(raw: str) -> None:
    pids = [int(x) for x in raw.split(",") if x.strip()]
    for pid in pids:
        if not live_pid(pid):
            continue
        print({"stage": "wait_pid", "pid": pid}, flush=True)
        while live_pid(pid):
            time.sleep(60)
        print({"stage": "wait_done", "pid": pid}, flush=True)


def run(cmd: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print({"stage": "run", "log": str(log_path), "cmd": " ".join(cmd)}, flush=True)
    with log_path.open("w") as f:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
    print({"stage": "done", "log": str(log_path), "returncode": proc.returncode}, flush=True)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed; see {log_path}")


def latest_checkpoint(save_root: Path) -> Path:
    candidates = sorted(save_root.rglob("*_last.pth"), key=lambda p: p.stat().st_mtime)
    if not candidates:
        candidates = sorted(save_root.rglob("*.pth"), key=lambda p: p.stat().st_mtime)
    if not candidates:
        raise FileNotFoundError(f"No checkpoint found under {save_root}")
    return candidates[-1]


def parse_recipes(raw: str) -> list[str]:
    recipes = [x.strip() for x in raw.split(",") if x.strip()]
    unknown = [x for x in recipes if x not in RECIPES]
    if unknown:
        raise SystemExit(f"Unknown recipes {unknown}; allowed={sorted(RECIPES)}")
    return recipes


def adaclip_env(base_env: dict[str, str]) -> dict[str, str]:
    env = dict(base_env)
    env["ADACLIP_MVTEC_ROOT"] = str(MVTEC)
    env["ADACLIP_COLONDB_ROOT"] = str(COLONDB)
    env["ADACLIP_VISA_ROOT"] = str(VISA_1CLS)
    return env


def train_adaclip(recipe: str, env: dict[str, str]) -> Path:
    train_root = OUT / f"adaclip_mvtec_{recipe}_ckpt"
    try:
        ckpt = latest_checkpoint(train_root)
        print({"stage": "skip_train", "host": "AdaCLIP", "recipe": recipe, "checkpoint": str(ckpt)}, flush=True)
        return ckpt
    except FileNotFoundError:
        pass
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--save_fig",
            "False",
            "--training_data",
            "mvtec",
            "colondb",
            "--testing_data",
            "visa",
            "--save_path",
            str(train_root),
            "--model",
            "ViT-L-14-336",
            "--layer_recipe",
            recipe,
            "--target_val_during_train",
            "False",
            "--save_last_ckpt",
            "True",
            "--epoch",
            "5",
            "--batch_size",
            "1",
            "--image_size",
            "518",
            "--prompting_depth",
            "4",
            "--prompting_length",
            "5",
            "--prompting_branch",
            "VL",
            "--prompting_type",
            "SD",
            "--use_hsf",
            "True",
            "--k_clusters",
            "20",
        ],
        ADACLIP_ROOT,
        LOG / f"adaclip_train_mvtec_{recipe}.log",
        env,
    )
    return latest_checkpoint(train_root)


def eval_adaclip(recipe: str, checkpoint: Path, env: dict[str, str]) -> None:
    save_dir = OUT / f"adaclip_mvtec_{recipe}_eval"
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "host": "AdaCLIP", "recipe": recipe, "summary": str(save_dir / "summary.json")}, flush=True)
        return
    model_recipe = "all4" if recipe == "all4_official" else recipe
    run(
        [
            str(PY),
            "-u",
            str(ADACLIP_EVAL),
            "--source_root",
            str(MVTEC),
            "--source_dataset",
            "mvtec",
            "--target_root",
            str(VISA_1CLS),
            "--target_dataset",
            "visa",
            "--checkpoint_path",
            str(checkpoint),
            "--save_dir",
            str(save_dir),
            "--bank_cache_path",
            str(BANK / f"adaclip_mvtec_{recipe}_retrained.pt"),
            "--refresh_bank_cache",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--batch_size",
            "1",
            "--num_workers",
            "4",
            "--cpu_threads",
            "4",
            "--backbone",
            "ViT-L-14-336",
            "--checkpoint_load_mode",
            "strict",
            "--model_layer_recipe",
            model_recipe,
            "--layer_recipe",
            "all4",
            "--enable_calibrator",
            "--calib_epochs",
            "30",
            "--calib_subspace_rank",
            "8",
            "--calib_insertion_mode",
            "prescore_rectify",
            "--calib_train_score_space",
            "cache_prob",
            "--calib_lambda",
            "0.3",
            "--calib_eta_max",
            "1.0",
            "--scoring_mode",
            "logit_gate_posneg",
            "--ours_image_score_mode",
            "official_plus_map_topk",
            "--eval_metrics",
            "I-AUROC",
            "I-AP",
            "P-AUROC",
            "P-AP",
            "P-AUPRO",
            "--aupro_max_step",
            "200",
        ],
        ROOT,
        LOG / f"adaclip_eval_mvtec_{recipe}.log",
        env,
    )


def run_adaclip(base_env: dict[str, str], recipes: list[str]) -> None:
    env = adaclip_env(base_env)
    eval_adaclip("all4_official", ADACLIP_OFFICIAL_MVTEC, env)
    for recipe in recipes:
        if recipe == "all4":
            continue
        eval_adaclip(recipe, train_adaclip(recipe, env), env)


def train_anomalyclip(recipe: str, env: dict[str, str]) -> Path:
    features = RECIPES[recipe]
    ckpt_dir = OUT / f"anomalyclip_mvtec_{recipe}_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if ckpt_path.exists():
        print({"stage": "skip_train", "host": "AnomalyCLIP", "recipe": recipe, "checkpoint": str(ckpt_path)}, flush=True)
        return ckpt_path
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "mvtec",
            "--train_data_path",
            str(MVTEC),
            "--save_path",
            str(ckpt_dir),
            "--features_list",
            *[str(x) for x in features],
            "--feature_map_layer",
            *[str(i) for i in range(len(features))],
            "--model_name_or_path",
            "ViT-L/14@336px",
            "--dpam_layer",
            "20",
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ],
        ANOMALY_ROOT,
        LOG / f"anomalyclip_train_mvtec_{recipe}.log",
        env,
    )
    return ckpt_path


def eval_anomalyclip(recipe: str, checkpoint: Path, env: dict[str, str]) -> None:
    save_dir = OUT / f"anomalyclip_mvtec_{recipe}_eval"
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "host": "AnomalyCLIP", "recipe": recipe, "summary": str(save_dir / "summary.json")}, flush=True)
        return
    features = RECIPES["all4"] if recipe == "all4_official" else RECIPES[recipe]
    run(
        [
            str(PY),
            "-u",
            str(ANOMALY_EVAL),
            "--device",
            "cuda:0",
            "--checkpoint_path",
            str(checkpoint),
            "--model_name_or_path",
            "ViT-L/14@336px",
            "--heldout_class",
            "none",
            "--source_root",
            str(MVTEC),
            "--source_dataset",
            "mvtec",
            "--target_root",
            str(VISA_1CLS),
            "--target_dataset",
            "visa",
            "--target_mode",
            "test",
            "--baseline_features_list",
            *[str(x) for x in features],
            "--features_list",
            *[str(x) for x in features],
            "--dpam_layer",
            "20",
            "--image_size",
            "518",
            "--sigma",
            "4",
            "--host_patch_score_mode",
            "prob",
            "--baseline_patch_score_mode",
            "prob",
            "--ted_margin_sign",
            "fp_minus_def",
            "--hard_frac",
            "0.01",
            "--max_good_per_class",
            "8",
            "--max_defect_per_class",
            "8",
            "--max_bank_per_layer",
            "2048",
            "--max_fp_per_image",
            "64",
            "--max_defect_per_image",
            "64",
            "--score_bank_cache_path",
            str(BANK / f"anomalyclip_mvtec_{recipe}_withscores.pt"),
            "--refresh_bank_cache",
            "--enable_calibrator",
            "--calib_seed",
            "0",
            "--calib_epochs",
            "80",
            "--calib_subspace_rank",
            "8",
            "--calib_eta_max",
            "0.2",
            "--calib_lambda",
            "0.03",
            "--calib_map_anchor",
            "trainfree",
            "--ted_image_score_mode",
            "host_plus_norm_topk",
            "--parallel_image_fusion_weight",
            "0.2",
            "--calibrated_image_fusion_weight",
            "0.02",
            "--skip_separability_metrics",
            "--save_dir",
            str(save_dir),
        ],
        ROOT,
        LOG / f"anomalyclip_eval_mvtec_{recipe}.log",
        env,
    )


def run_anomalyclip(env: dict[str, str], recipes: list[str]) -> None:
    eval_anomalyclip("all4_official", ANOMALY_OFFICIAL_MVTEC, env)
    for recipe in recipes:
        eval_anomalyclip(recipe, train_anomalyclip(recipe, env), env)


def train_faprompt(recipe: str, env: dict[str, str]) -> Path:
    features = RECIPES[recipe]
    ckpt_dir = OUT / f"faprompt_mvtec_{recipe}_ckpt"
    ckpt_path = ckpt_dir / "epoch_15.pth"
    if ckpt_path.exists():
        print({"stage": "skip_train", "host": "FAPrompt", "recipe": recipe, "checkpoint": str(ckpt_path)}, flush=True)
        return ckpt_path
    run(
        [
            str(PY),
            "-u",
            "train.py",
            "--dataset",
            "mvtecad",
            "--train_data_path",
            str(MVTEC),
            "--save_path",
            str(ckpt_dir),
            "--features_list",
            *[str(x) for x in features],
            "--image_size",
            "518",
            "--batch_size",
            "8",
            "--print_freq",
            "1",
            "--epoch",
            "15",
            "--save_freq",
            "15",
            "--depth",
            "9",
            "--n_ctx",
            "12",
            "--t_n_ctx",
            "4",
            "--seed",
            "111",
        ],
        FAP_ROOT,
        LOG / f"faprompt_train_mvtec_{recipe}.log",
        env,
    )
    return ckpt_path


def eval_faprompt(recipe: str, checkpoint: Path, env: dict[str, str]) -> None:
    save_dir = OUT / f"faprompt_mvtec_{recipe}_eval"
    if (save_dir / "summary.json").exists():
        print({"stage": "skip_eval", "host": "FAPrompt", "recipe": recipe, "summary": str(save_dir / "summary.json")}, flush=True)
        return
    features = RECIPES["all4"] if recipe == "all4_official" else RECIPES[recipe]
    run(
        [
            str(PY),
            "-u",
            str(FAP_EVAL),
            "--preset",
            "mvtec2visa",
            "--checkpoint_path",
            str(checkpoint),
            "--save_dir",
            str(save_dir),
            "--model_name",
            "ViT-L/14@336px",
            "--prompt_load_mode",
            "strict",
            "--features_list",
            *[str(x) for x in features],
            "--image_size",
            "518",
            "--batch_size",
            "2",
            "--num_workers",
            "4",
            "--dap_token_mode",
            "official_firstk",
            "--dpam_layer",
            "20",
            "--max_fp_per_class",
            "512",
            "--max_defect_per_class",
            "512",
            "--max_fp_total",
            "4096",
            "--max_defect_total",
            "4096",
            "--normal_topk_frac",
            "0.01",
            "--tau",
            "0.1",
            "--fp_weight",
            "1.0",
            "--alphas",
            "0.5,1.0",
            "--ours_image_score_mode",
            "official",
            "--insert_modes",
            "support_only,branch_calibrated",
            "--prescore_calib_epochs",
            "30",
            "--prescore_calib_lr",
            "0.02",
            "--prescore_calib_max_train_points",
            "2048",
            "--prescore_calib_alpha_init",
            "0.05",
            "--prescore_calib_alpha_max",
            "0.2",
            "--prescore_calib_subspace_rank",
            "4",
            "--aupro_max_step",
            "50",
            "--seed",
            "0",
            "--device",
            "cuda:0",
            "--force_rebuild_bank",
        ],
        ROOT,
        LOG / f"faprompt_eval_mvtec_{recipe}.log",
        env,
    )


def run_faprompt(env: dict[str, str], recipes: list[str]) -> None:
    eval_faprompt("all4_official", FAP_OFFICIAL_MVTEC, env)
    for recipe in recipes:
        eval_faprompt(recipe, train_faprompt(recipe, env), env)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device_id", default="1")
    parser.add_argument("--hosts", default="adaclip,anomalyclip,faprompt")
    parser.add_argument("--recipes", default="all4,last,last2,mid2,earlylate")
    parser.add_argument("--wait_pids", default="")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    LOG.mkdir(parents=True, exist_ok=True)
    BANK.mkdir(parents=True, exist_ok=True)

    wait_for_pids(args.wait_pids)
    recipes = parse_recipes(args.recipes)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.device_id)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-layer-retrained-mvtec2visa-20260503")

    hosts = [x.strip().lower() for x in args.hosts.split(",") if x.strip()]
    if "adaclip" in hosts:
        run_adaclip(env, recipes)
    if "anomalyclip" in hosts:
        run_anomalyclip(env, recipes)
    if "faprompt" in hosts:
        run_faprompt(env, recipes)

    print({"stage": "done", "root": str(OUT), "hosts": hosts, "recipes": recipes}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
