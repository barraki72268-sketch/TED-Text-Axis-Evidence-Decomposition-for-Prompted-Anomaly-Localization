from __future__ import annotations

import math

import numpy as np
from sklearn.metrics import roc_auc_score


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(math.ceil(flat.size * frac)))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def image_auroc(labels: list[int], scores: list[float]) -> float:
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def pixel_auroc(masks: list[np.ndarray], maps: list[np.ndarray]) -> float:
    y_true = np.concatenate([m.reshape(-1).astype(np.uint8) for m in masks], axis=0)
    y_score = np.concatenate([s.reshape(-1).astype(np.float64) for s in maps], axis=0)
    return float(roc_auc_score(y_true, y_score))
