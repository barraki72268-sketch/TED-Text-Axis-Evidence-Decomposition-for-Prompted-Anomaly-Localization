from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
import torch.nn.functional as F


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANOMALYCLIP_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANOMALYCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ANOMALYCLIP_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from prompt_ensemble import (  # noqa: E402
    AnomalyCLIP_PromptLearner,
    encode_text_prompt_bank,
)


def load_base_bank(object_name: str = "object"):
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=None)
    model.eval()
    normal_bank, anomaly_bank = encode_text_prompt_bank(model, object_name, "cpu")
    normal_bank = F.normalize(normal_bank.float(), dim=-1)
    anomaly_bank = F.normalize(anomaly_bank.float(), dim=-1)
    normal_anchor = F.normalize(normal_bank.mean(dim=0), dim=-1)
    anomaly_anchor = F.normalize(anomaly_bank.mean(dim=0), dim=-1)
    _, singular_values, vh = torch.linalg.svd(normal_bank, full_matrices=False)
    basis = vh.transpose(0, 1).contiguous()
    return {
        "normal_bank": normal_bank,
        "anomaly_bank": anomaly_bank,
        "normal_anchor": normal_anchor,
        "anomaly_anchor": anomaly_anchor,
        "singular_values": singular_values,
        "basis": basis,
    }


def load_learned_anomaly_text(checkpoint_path: Path):
    params = {
        "Prompt_length": 12,
        "learnabel_text_embedding_depth": 9,
        "learnabel_text_embedding_length": 4,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device="cpu", design_details=params)
    model.eval()
    learner = AnomalyCLIP_PromptLearner(model, params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    learner.load_state_dict(checkpoint["prompt_learner"])
    learner.eval()
    prompts, tokenized_prompts, compound_prompts_text = learner(cls_id=None)
    text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
    text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
    text_features = F.normalize(text_features, dim=-1)[0]
    return {
        "learned_norm": text_features[0],
        "learned_anom": text_features[1],
    }


def component_energy(vector: torch.Tensor, basis: torch.Tensor):
    vector = F.normalize(vector.float(), dim=-1)
    coeff = vector @ basis
    return coeff.pow(2)


def summarize_energy(vector: torch.Tensor, basis: torch.Tensor, ks: list[int]):
    energy = component_energy(vector, basis)
    out = {"full": float(energy.sum().item())}
    n = energy.numel()
    for k in ks:
        k_eff = min(k, n)
        out[f"top{k}"] = float(energy[:k_eff].sum().item())
        out[f"tail{k}"] = float(energy[k_eff:].sum().item()) if k_eff < n else 0.0
    return out


def main():
    parser = argparse.ArgumentParser("Analyze AnomalyCLIP normal-subspace structure")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--object_name", type=str, default="object")
    parser.add_argument("--ks", type=int, nargs="+", default=[1, 2, 4, 8, 16, 32, 64, 128])
    args = parser.parse_args()

    base = load_base_bank(args.object_name)
    learned = load_learned_anomaly_text(Path(args.checkpoint))

    singular = base["singular_values"]
    sv_var = singular.pow(2) / singular.pow(2).sum()

    result = {
        "normal_rank": int((singular > 1e-6).sum().item()),
        "sv_cum_top1": float(sv_var[:1].sum().item()),
        "sv_cum_top4": float(sv_var[:4].sum().item()),
        "sv_cum_top8": float(sv_var[:8].sum().item()),
        "sv_cum_top16": float(sv_var[:16].sum().item()),
        "sv_top10": [float(x) for x in sv_var[:10].tolist()],
        "static_anom_anchor": summarize_energy(base["anomaly_anchor"], base["basis"], args.ks),
        "static_norm_anchor": summarize_energy(base["normal_anchor"], base["basis"], args.ks),
        "learned_anom": summarize_energy(learned["learned_anom"], base["basis"], args.ks),
        "learned_norm": summarize_energy(learned["learned_norm"], base["basis"], args.ks),
        "cos_static_anom_vs_norm_anchor": float(
            (base["anomaly_anchor"] * base["normal_anchor"]).sum().item()
        ),
    }
    result["relative_margin_proj_base_vs_learned"] = (
        result["learned_anom"]["full"] - result["static_anom_anchor"]["full"]
    )

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
