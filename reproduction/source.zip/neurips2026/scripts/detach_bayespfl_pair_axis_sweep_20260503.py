from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
QUEUE = ROOT / "neurips2026/scripts/queue_bayespfl_pair_axis_sweep_20260503.py"
OUT = ROOT / "neurips2026/results/bayespfl_pair_axis_sweep_20260503"
LOG = OUT / "queue.detached.log"
PID = OUT / "queue.pid"


def main() -> int:
    parser = argparse.ArgumentParser("Detach BayesPFL pair-axis sweep.")
    parser.add_argument("--gpu", default="0")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(QUEUE),
        "--gpu",
        str(args.gpu),
        "--wait_pid",
        str(args.wait_pid),
    ]
    if args.force:
        cmd.append("--force")
    with LOG.open("ab") as log:
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    PID.write_text(str(proc.pid) + "\n", encoding="utf-8")
    print({"stage": "detached", "pid": proc.pid, "log": str(LOG), "root": str(OUT), "cmd": " ".join(cmd)}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
