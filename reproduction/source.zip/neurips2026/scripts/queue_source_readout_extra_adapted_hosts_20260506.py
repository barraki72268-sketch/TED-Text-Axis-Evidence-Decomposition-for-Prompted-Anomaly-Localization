#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "source_readout_extra_baselines_20260506"
LOGS = ROOT / "neurips2026" / "logs" / "source_readout_extra_baselines_20260506"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADACLIP_MVTEC_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"
ADACLIP_VISA_CKPT = ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"

ADAPT_MVTEC_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth"
ADAPT_VISA_CKPT = ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth"

DATASETS = {
    "mvtec": MVTEC_ROOT,
    "visa": VISA_ROOT,
    "mpdd": MPDD_ROOT,
    "btad": BTAD_ROOT,
}
PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]


def csv_list(text: str) -> list[str]:
    return [x.strip().lower() for x in text.split(",") if x.strip()]


def split_preset(preset: str) -> tuple[str, str]:
    source, target = preset.split("2", 1)
    if source not in {"mvtec", "visa"} or target not in DATASETS:
        raise SystemExit(f"Unsupported preset={preset}")
    return source, target


def loss_for_variant(variant: str) -> str:
    if variant == "mlp_rank":
        return "pair_rank"
    if variant == "support_affine":
        return "support_rank"
    raise SystemExit(f"Unsupported variant={variant}")


def adaclip_cmd(preset: str, variant: str, device: str, seed: int) -> tuple[list[str], Path, Path]:
    source, target = split_preset(preset)
    ckpt = ADACLIP_VISA_CKPT if source == "visa" else ADACLIP_MVTEC_CKPT
    bank = ROOT / "neurips2026" / "results" / "bank_cache" / (
        "adaclip_visa_official1cls_multilayer.pt" if source == "visa" else "adaclip_mvtec_full_multilayer.pt"
    )
    save_dir = RESULTS / f"adaclip_vitl336_{preset}_{variant}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY), "-u", "neurips2026/scripts/official_parallel_test_adaclip.py",
        "--source_root", str(DATASETS[source]),
        "--source_dataset", source,
        "--target_root", str(DATASETS[target]),
        "--target_dataset", target,
        "--checkpoint_path", str(ckpt),
        "--save_dir", str(save_dir.relative_to(ROOT)),
        "--bank_cache_path", str(bank),
        "--backbone", "ViT-L-14-336",
        "--checkpoint_load_mode", "strict",
        "--image_size", "518",
        "--sigma", "4",
        "--prompting_depth", "4",
        "--prompting_length", "5",
        "--prompting_branch", "VL",
        "--prompting_type", "SD",
        "--use_hsf", "true",
        "--k_clusters", "20",
        "--max_good_per_class", "2",
        "--max_defect_per_class", "4",
        "--max_bank_per_layer", "512",
        "--max_fp_per_image", "64",
        "--max_defect_per_image", "64",
        "--layer_recipe", "all4",
        "--batch_size", "1",
        "--num_workers", "4",
        "--cpu_threads", "2",
        "--tau", "20.0",
        "--fp_weight", "1.0",
        "--enable_calibrator",
        "--calib_epochs", "30",
        "--calib_lr", "0.02",
        "--calib_max_train_points", "2048",
        "--calib_rank_margin", "0.05",
        "--calib_rank_temp", "0.05",
        "--calib_eta_init", "0.2",
        "--calib_eta_max", "1.0",
        "--calib_eta_reg", "0.001",
        "--calib_fp_weight_init", "1.0",
        "--calib_hardpair_frac", "0.75",
        "--calib_subspace_rank", "8",
        "--calib_subspace_basis_control", "source",
        "--calib_pair_label_control", "correct",
        "--calib_preserve_host_margin_weight", "1.0",
        "--calib_lambda", "0.3",
        "--calib_gate_mode", "host",
        "--calib_insertion_mode", "prescore_rectify",
        "--calib_train_score_space", "cache_prob",
        "--scoring_mode", "logit_gate_posneg",
        "--plugin_epochs", "40",
        "--plugin_lr", "0.01",
        "--plugin_max_train_points", "4096",
        "--plugin_hardpair_frac", "0.0",
        "--plugin_alpha", "0.5",
        "--plugin_loss", loss_for_variant(variant),
        "--plugin_hidden_dim", "32",
        "--plugin_rank_margin", "0.05",
        "--plugin_rank_temp", "0.05",
        "--ours_image_score_mode", "official_plus_map_topk",
        "--image_topk_frac", "0.01",
        "--eval_metrics", "I-AUROC", "I-AP", "P-AUROC", "P-AP", "P-AUPRO",
        "--aupro_max_step", "200",
        "--seed", str(seed),
        "--device", device,
    ]
    return cmd, save_dir, log_path


def adaptclip_cmd(preset: str, variant: str, device: str, seed: int) -> tuple[list[str], Path, Path]:
    source, target = split_preset(preset)
    ckpt = ADAPT_VISA_CKPT if source == "visa" else ADAPT_MVTEC_CKPT
    save_dir = RESULTS / f"adaptclip_vl_last24_{preset}_{variant}_seed{seed}"
    bank_cache = ROOT / "neurips2026" / "results" / "bank_cache" / f"adaptclip_simple_plugin_{source}_vl_last24_seed{seed}.pt"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY), "-u", "neurips2026/scripts/official_parallel_test_adaptclip_vlrefine.py",
        "--source_root", str(DATASETS[source]),
        "--source_dataset", source,
        "--target_root", str(DATASETS[target]),
        "--target_dataset", target,
        "--checkpoint_path", str(ckpt),
        "--save_dir", str(save_dir),
        "--bank_cache_path", str(bank_cache),
        "--pretrained_model", "ViT-L/14@336px",
        "--checkpoint_load_mode", "strict",
        "--features_list", "24",
        "--image_size", "518",
        "--batch_size", "8",
        "--n_ctx", "12",
        "--sigma", "4",
        "--vl_reduction", "4",
        "--fusion_type", "average_mean",
        "--tau", "20.0",
        "--fp_weight", "0.3",
        "--corr_alpha", "0.3",
        "--map_activation", "sigmoid",
        "--map_temperature", "1.0",
        "--vl_gate_mode", "host",
        "--vl_gate_quantile", "0.9",
        "--vl_gate_temp", "0.25",
        "--max_good_per_class", "2",
        "--max_defect_per_class", "4",
        "--max_bank_points", "512",
        "--max_fp_per_image", "64",
        "--max_defect_per_image", "64",
        "--calib_epochs", "30",
        "--calib_lr", "0.02",
        "--calib_max_train_points", "2048",
        "--calib_rank_margin", "0.05",
        "--calib_rank_temp", "0.05",
        "--calib_eta_init", "0.2",
        "--calib_eta_max", "1.0",
        "--calib_eta_reg", "0.001",
        "--calib_fp_weight_init", "1.0",
        "--calib_hardpair_frac", "0.75",
        "--calib_subspace_rank", "8",
        "--calib_preserve_host_margin_weight", "1.0",
        "--calib_lambda", "0.3",
        "--calib_pair_label_control", "correct",
        "--plugin_epochs", "40",
        "--plugin_lr", "0.01",
        "--plugin_max_train_points", "4096",
        "--plugin_hardpair_frac", "0.0",
        "--plugin_alpha", "0.5",
        "--plugin_loss", loss_for_variant(variant),
        "--plugin_hidden_dim", "32",
        "--plugin_rank_margin", "0.05",
        "--plugin_rank_temp", "0.05",
        "--seed", str(seed),
        "--device", device,
        "--num_workers", "4",
        "--aupro_max_step", "200",
        "--aupro_expect_fpr", "0.3",
    ]
    return cmd, save_dir, log_path


def build_jobs(hosts: list[str], variants: list[str], presets: list[str], devices: list[str], seed: int) -> list[dict]:
    builders = {"adaclip": adaclip_cmd, "adaptclip": adaptclip_cmd}
    jobs = []
    for host in hosts:
        if host not in builders:
            raise SystemExit(f"Unsupported host={host}")
        for variant in variants:
            for preset in presets:
                device = devices[len(jobs) % len(devices)]
                cmd, save_dir, log_path = builders[host](preset, variant, device, seed)
                jobs.append({"host": host, "variant": variant, "preset": preset, "cmd": cmd, "save_dir": save_dir, "log_path": log_path})
    return jobs


def write_worker(jobs: list[dict], worker_id: int, force: bool) -> Path:
    worker_path = LOGS / f"extra_adapted_worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess, time",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        f"FORCE = {bool(force)!r}",
        "jobs = [",
    ]
    for job in jobs:
        lines.append("    " + repr({k: (str(v) if isinstance(v, Path) else v) for k, v in job.items()}) + ",")
    lines += [
        "]",
        "for job in jobs:",
        "    save_dir = Path(job['save_dir'])",
        "    summary = save_dir / 'summary.json'",
        "    log_path = Path(job['log_path'])",
        "    log_path.parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists() and not FORCE:",
        "        print({'stage': 'skip_done', 'host': job['host'], 'variant': job['variant'], 'preset': job['preset'], 'summary': str(summary)}, flush=True)",
        "        continue",
        "    save_dir.mkdir(parents=True, exist_ok=True)",
        "    print({'stage': 'job_start', 'host': job['host'], 'variant': job['variant'], 'preset': job['preset'], 'save_dir': str(save_dir), 'log': str(log_path)}, flush=True)",
        "    start = time.time()",
        "    with log_path.open('w') as f:",
        "        proc = subprocess.run(job['cmd'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)",
        "    print({'stage': 'job_done', 'host': job['host'], 'variant': job['variant'], 'preset': job['preset'], 'returncode': proc.returncode, 'elapsed_sec': time.time() - start}, flush=True)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    worker_path.write_text("\n".join(lines))
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="adaclip,adaptclip")
    ap.add_argument("--variants", default="mlp_rank,support_affine")
    ap.add_argument("--presets", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--devices", default="cuda:0")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = csv_list(args.hosts)
    variants = csv_list(args.variants)
    presets = csv_list(args.presets)
    devices = [x.strip() for x in args.devices.split(",") if x.strip()]
    if set(variants) - {"mlp_rank", "support_affine"}:
        raise SystemExit(f"Unsupported variants={variants}")
    if set(presets) - set(PRESETS):
        raise SystemExit(f"Unsupported presets={presets}")
    if not devices:
        raise SystemExit("No devices provided")

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    jobs = build_jobs(hosts, variants, presets, devices, int(args.seed))
    buckets = [[] for _ in devices]
    for idx, job in enumerate(jobs):
        buckets[idx % len(buckets)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        worker_path = write_worker(bucket, worker_id, bool(args.force))
        worker_log = LOGS / f"extra_adapted_worker_{worker_id}.log"
        with worker_log.open("a") as f:
            proc = subprocess.Popen([str(PY), "-u", str(worker_path)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "worker": str(worker_path), "log": str(worker_log)})

    print(json.dumps({"stage": "queued_source_readout_extra_adapted_hosts", "launched": launched, "num_jobs": len(jobs)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
