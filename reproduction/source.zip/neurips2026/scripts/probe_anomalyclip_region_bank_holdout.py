from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

from common_map_group_separability import top_fraction_mask  # noqa: E402
from dataset import Dataset  # noqa: E402
from probe_anomalyclip_region_bank_descriptor import (  # noqa: E402
    build_model,
    compute_map,
    extract_region_descriptor,
    iterate_components,
    load_text_features,
)
from utils import get_transform  # noqa: E402


FEATURE_NAMES = [
    "peak",
    "mean",
    "top10_mean",
    "p90",
    "std",
    "area",
    "fill_ratio",
    "compactness",
    "boundary_mean",
    "interior_mean",
    "boundary_gap",
    "ring_mean",
    "ring_contrast",
    "peak_over_mean",
    "top10_over_mean",
    "aspect_ratio",
]

COMBOS = [
    ["peak", "area"],
    ["peak", "mean"],
    ["peak", "top10_mean"],
    ["peak", "fill_ratio"],
    ["peak", "compactness"],
    ["peak", "ring_contrast"],
    ["peak", "area", "fill_ratio"],
    ["peak", "mean", "area", "fill_ratio", "compactness", "ring_contrast"],
]


def build_dataset(root: str, image_size: int, mode: str):
    class Args:
        pass

    args = Args()
    args.image_size = image_size
    preprocess, target_transform = get_transform(args)
    return Dataset(root=root, transform=preprocess, target_transform=target_transform, dataset_name="mvtec", mode=mode)


def save_rows(rows: list[dict], path: Path) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def collect_fp_rows(
    model,
    text_features: torch.Tensor,
    data_root: str,
    image_size: int,
    features_list: list[int],
    sigma: int,
    device: str,
    top_fracs: list[float],
    min_area: int,
    max_per_class: int,
):
    dataset = build_dataset(data_root, image_size, mode="train")
    per_class = {cls_name: 0 for cls_name in dataset.cls_names}
    rows = []
    with torch.no_grad():
        for img_idx in range(len(dataset)):
            item = dataset[img_idx]
            cls_name = item["cls_name"]
            if per_class[cls_name] >= max_per_class:
                continue
            per_class[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            anomaly_map = compute_map(model, text_features, image, features_list, image_size, sigma)
            for frac in top_fracs:
                mask = top_fraction_mask(anomaly_map, frac)
                for comp in iterate_components(mask):
                    if int(comp.sum()) < min_area:
                        continue
                    desc = extract_region_descriptor(anomaly_map, comp)
                    if not desc:
                        continue
                    desc.update(
                        {
                            "bank": "fp",
                            "cls_name": cls_name,
                            "img_idx": img_idx,
                            "threshold_frac": frac,
                        }
                    )
                    rows.append(desc)
    return rows


def collect_defect_rows(
    model,
    text_features: torch.Tensor,
    data_root: str,
    image_size: int,
    features_list: list[int],
    sigma: int,
    device: str,
    min_area: int,
    max_images_per_class: int,
):
    dataset = build_dataset(data_root, image_size, mode="test")
    per_class = {cls_name: 0 for cls_name in dataset.cls_names}
    rows = []
    with torch.no_grad():
        for img_idx in range(len(dataset)):
            item = dataset[img_idx]
            anomaly_flag = item["anomaly"]
            if hasattr(anomaly_flag, "item"):
                anomaly_flag = anomaly_flag.item()
            if int(anomaly_flag) == 0:
                continue
            cls_name = item["cls_name"]
            if per_class[cls_name] >= max_images_per_class:
                continue
            per_class[cls_name] += 1
            image = item["img"].unsqueeze(0).to(device)
            gt_mask = item["img_mask"][0].numpy() > 0.5
            anomaly_map = compute_map(model, text_features, image, features_list, image_size, sigma)
            for comp in iterate_components(gt_mask):
                if int(comp.sum()) < min_area:
                    continue
                desc = extract_region_descriptor(anomaly_map, comp)
                if not desc:
                    continue
                desc.update(
                    {
                        "bank": "defect",
                        "cls_name": cls_name,
                        "img_idx": img_idx,
                        "threshold_frac": -1.0,
                    }
                )
                rows.append(desc)
    return rows


def rows_to_matrix(rows: list[dict], feature_names: list[str]) -> np.ndarray:
    return np.asarray([[float(row[name]) for name in feature_names] for row in rows], dtype=np.float32)


def compute_holdout_summary(fp_rows: list[dict], defect_rows: list[dict]):
    classes = sorted(set(row["cls_name"] for row in fp_rows) & set(row["cls_name"] for row in defect_rows))
    name_to_idx = {name: i for i, name in enumerate(FEATURE_NAMES)}
    holdout_rows = []

    for heldout in classes:
        fp_train = [row for row in fp_rows if row["cls_name"] != heldout]
        df_train = [row for row in defect_rows if row["cls_name"] != heldout]
        fp_eval = [row for row in fp_rows if row["cls_name"] == heldout]
        df_eval = [row for row in defect_rows if row["cls_name"] == heldout]
        if not fp_train or not df_train or not fp_eval or not df_eval:
            continue

        X_train = np.concatenate([rows_to_matrix(fp_train, FEATURE_NAMES), rows_to_matrix(df_train, FEATURE_NAMES)], axis=0)
        y_train = np.concatenate(
            [np.zeros(len(fp_train), dtype=np.int64), np.ones(len(df_train), dtype=np.int64)],
            axis=0,
        )
        X_eval = np.concatenate([rows_to_matrix(fp_eval, FEATURE_NAMES), rows_to_matrix(df_eval, FEATURE_NAMES)], axis=0)
        y_eval = np.concatenate(
            [np.zeros(len(fp_eval), dtype=np.int64), np.ones(len(df_eval), dtype=np.int64)],
            axis=0,
        )

        for feat_idx, feature_name in enumerate(FEATURE_NAMES):
            auc = roc_auc_score(y_eval, X_eval[:, feat_idx])
            eff_auc = max(float(auc), float(1.0 - auc))
            direction = "defect_high" if auc >= 0.5 else "fp_high"
            holdout_rows.append(
                {
                    "heldout_class": heldout,
                    "kind": "single",
                    "name": feature_name,
                    "auc_eval": eff_auc,
                    "direction": direction,
                    "num_train_fp": len(fp_train),
                    "num_train_defect": len(df_train),
                    "num_eval_fp": len(fp_eval),
                    "num_eval_defect": len(df_eval),
                }
            )

        for combo in COMBOS:
            idxs = [name_to_idx[c] for c in combo]
            clf = Pipeline(
                [
                    ("scaler", StandardScaler()),
                    ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
                ]
            )
            clf.fit(X_train[:, idxs], y_train)
            pred = clf.predict_proba(X_eval[:, idxs])[:, 1]
            auc = roc_auc_score(y_eval, pred)
            holdout_rows.append(
                {
                    "heldout_class": heldout,
                    "kind": "combo",
                    "name": "+".join(combo),
                    "auc_eval": float(auc),
                    "direction": "defect_high",
                    "num_train_fp": len(fp_train),
                    "num_train_defect": len(df_train),
                    "num_eval_fp": len(fp_eval),
                    "num_eval_defect": len(df_eval),
                }
            )

    single_rows = [row for row in holdout_rows if row["kind"] == "single"]
    combo_rows = [row for row in holdout_rows if row["kind"] == "combo"]

    def aggregate(rows: list[dict]):
        if not rows:
            return []
        grouped: dict[str, list[float]] = {}
        for row in rows:
            grouped.setdefault(row["name"], []).append(float(row["auc_eval"]))
        summary_rows = []
        for name, vals in grouped.items():
            summary_rows.append(
                {
                    "name": name,
                    "mean_auc": float(np.mean(vals)),
                    "std_auc": float(np.std(vals)),
                    "num_holdouts": len(vals),
                }
            )
        summary_rows.sort(key=lambda x: x["mean_auc"], reverse=True)
        return summary_rows

    return {
        "classes": classes,
        "holdout_rows": holdout_rows,
        "single_summary": aggregate(single_rows),
        "combo_summary": aggregate(combo_rows),
    }


def main():
    parser = argparse.ArgumentParser("Probe AnomalyCLIP source region descriptor class hold-out separability")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--fp_fracs", type=float, nargs="+", default=[0.01, 0.02, 0.05])
    parser.add_argument("--min_area", type=int, default=16)
    parser.add_argument("--max_fp_per_class", type=int, default=8)
    parser.add_argument("--max_defect_images_per_class", type=int, default=24)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_region_bank_holdout_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    save_dir = Path(args.save_dir)
    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    text_features = load_text_features(model, params, Path(args.checkpoint_path), device)

    print(
        json.dumps(
            {
                "stage": "holdout_start",
                "checkpoint_path": args.checkpoint_path,
                "fp_fracs": args.fp_fracs,
                "max_fp_per_class": args.max_fp_per_class,
                "max_defect_images_per_class": args.max_defect_images_per_class,
            },
            indent=2,
        ),
        flush=True,
    )

    fp_rows = collect_fp_rows(
        model=model,
        text_features=text_features,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        sigma=args.sigma,
        device=device,
        top_fracs=args.fp_fracs,
        min_area=args.min_area,
        max_per_class=args.max_fp_per_class,
    )
    print(json.dumps({"stage": "fp_rows_done", "num_regions": len(fp_rows)}, indent=2), flush=True)

    defect_rows = collect_defect_rows(
        model=model,
        text_features=text_features,
        data_root=args.source_root,
        image_size=args.image_size,
        features_list=args.features_list,
        sigma=args.sigma,
        device=device,
        min_area=args.min_area,
        max_images_per_class=args.max_defect_images_per_class,
    )
    print(json.dumps({"stage": "defect_rows_done", "num_regions": len(defect_rows)}, indent=2), flush=True)

    summary = compute_holdout_summary(fp_rows, defect_rows)
    save_dir.mkdir(parents=True, exist_ok=True)
    save_rows(fp_rows, save_dir / "fp_rows.csv")
    save_rows(defect_rows, save_dir / "defect_rows.csv")
    with open(save_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    if summary["holdout_rows"]:
        with open(save_dir / "holdout_rows.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(summary["holdout_rows"][0].keys()))
            writer.writeheader()
            writer.writerows(summary["holdout_rows"])
    if summary["single_summary"]:
        with open(save_dir / "single_summary.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(summary["single_summary"][0].keys()))
            writer.writeheader()
            writer.writerows(summary["single_summary"])
    if summary["combo_summary"]:
        with open(save_dir / "combo_summary.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(summary["combo_summary"][0].keys()))
            writer.writeheader()
            writer.writerows(summary["combo_summary"])

    print(
        json.dumps(
            {
                "stage": "holdout_saved",
                "save_dir": str(save_dir),
                "num_fp_regions": len(fp_rows),
                "num_defect_regions": len(defect_rows),
                "best_single": summary["single_summary"][:3],
                "best_combo": summary["combo_summary"][:3],
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
