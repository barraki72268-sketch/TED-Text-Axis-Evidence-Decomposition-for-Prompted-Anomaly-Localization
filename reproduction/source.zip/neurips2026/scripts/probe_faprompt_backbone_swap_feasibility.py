#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))

os.environ.setdefault("FAPROMPT_CACHE_DIR", "/mnt/data/pilab-kingjinyoung/ADPretrain/FAPrompt/.cache/clip")

import AnomalyCLIP_lib  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402


def model_filename_from_url(url: str) -> str:
    return os.path.basename(url)


def local_model_path(model_name: str, cache_dirs: list[Path]) -> Path | None:
    url = AnomalyCLIP_lib.model_load._MODELS[model_name]
    filename = model_filename_from_url(url)
    for cache_dir in cache_dirs:
        candidate = cache_dir / filename
        if candidate.is_file():
            return candidate
    return None


def checkpoint_prompt_shapes(checkpoint_path: Path) -> dict:
    ckpt = torch.load(checkpoint_path, map_location="cpu")
    state = ckpt["prompt_learner"] if isinstance(ckpt, dict) and "prompt_learner" in ckpt else ckpt
    out = {}
    for key in [
        "ctx_pos",
        "ctx_neg",
        "patch_meta_net.linear1.weight",
        "patch_meta_net.linear1.bias",
        "patch_meta_net.linear2.weight",
        "patch_meta_net.linear2.bias",
    ]:
        if key in state:
            out[key] = list(state[key].shape)
    comp_shapes = [list(v.shape) for k, v in sorted(state.items()) if k.startswith("compound_prompts_text.")]
    proj_shapes = {
        k: list(v.shape)
        for k, v in sorted(state.items())
        if k.startswith("compound_prompt_projections.") and k.endswith(".weight")
    }
    out["compound_prompts_text"] = comp_shapes
    out["compound_prompt_projection_weights"] = proj_shapes
    if "patch_meta_net.linear1.weight" in state:
        out["implied_selected_token_dim"] = int(state["patch_meta_net.linear1.weight"].shape[1] // 10)
    if "patch_meta_net.linear2.bias" in state:
        out["implied_prompt_bias_dim"] = int(state["patch_meta_net.linear2.bias"].shape[0])
    return out


def try_build_and_load(model_name: str, checkpoint_path: Path, device: str, allow_download: bool) -> dict:
    cache_dirs = [
        Path(os.environ.get("FAPROMPT_CACHE_DIR", "")),
        Path("/mnt/data/hf-cache/anomalyclip"),
        Path("/mnt/data/pilab-kingjinyoung/ADPretrain/checkpoints/anomalyclip_clip_cache"),
    ]
    local_path = local_model_path(model_name, cache_dirs)
    result = {
        "model_name": model_name,
        "local_model_path": str(local_path) if local_path else None,
        "status": "not_run",
    }
    if local_path is None and not allow_download:
        result["status"] = "missing_local_weight"
        result["reason"] = "Run with --allow_download to test actual construction."
        return result

    params = {
        "Prompt_length": 12,
        "learnabel_text_embedding_depth": 9,
        "learnabel_text_embedding_length": 4,
    }
    try:
        model, _ = AnomalyCLIP_lib.load(model_name, device=device, design_details=params)
        result["model_text_width"] = int(model.ln_final.weight.shape[0])
        result["model_visual_width"] = int(model.visual.conv1.weight.shape[0])
        result["model_embed_dim"] = int(model.text_projection.shape[1])
        result["model_num_visual_layers"] = int(model.visual.transformer.layers)
        learner = FAPrompt(model.to("cpu"), params)
        ckpt = torch.load(checkpoint_path, map_location="cpu")
        learner.load_state_dict(ckpt["prompt_learner"], strict=True)
        result["status"] = "strict_prompt_load_ok"
    except Exception as exc:  # noqa: BLE001
        result["status"] = "failed"
        result["error_type"] = type(exc).__name__
        result["error"] = str(exc)
    return result


def main() -> None:
    parser = argparse.ArgumentParser("Probe whether FAPrompt can swap CLIP ViT backbones without surgery.")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(FAP_ROOT / "checkpoints" / "trained_on_visa" / "epoch_15.pth"),
    )
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--allow_download", action="store_true")
    parser.add_argument(
        "--save_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_backbone_swap_feasibility.json"),
    )
    args = parser.parse_args()

    checkpoint_path = Path(args.checkpoint_path)
    payload = {
        "checkpoint_path": str(checkpoint_path),
        "checkpoint_prompt_shapes": checkpoint_prompt_shapes(checkpoint_path),
        "available_faprompt_backbones": AnomalyCLIP_lib.available_models(),
        "allow_download": bool(args.allow_download),
        "backbone_results": [],
    }
    for model_name in AnomalyCLIP_lib.available_models():
        payload["backbone_results"].append(
            try_build_and_load(model_name, checkpoint_path, args.device, args.allow_download)
        )

    save_path = Path(args.save_path)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    save_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2), flush=True)


if __name__ == "__main__":
    main()
