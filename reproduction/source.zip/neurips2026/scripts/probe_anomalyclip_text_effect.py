from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ANOMALYCLIP_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(ANOMALYCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ANOMALYCLIP_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from metrics import image_level_metrics, pixel_level_metrics  # noqa: E402
from prompt_ensemble import (  # noqa: E402
    AnomalyCLIP_PromptLearner,
    encode_text_prompt_bank,
    encode_text_with_prompt_ensemble,
)
from utils import get_transform  # noqa: E402


def setup_seed(seed: int) -> None:
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def normal_basis(text_bank: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    text_bank = F.normalize(text_bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(text_bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return text_bank.new_zeros((text_bank.shape[-1], 0))
    return vh[:rank].transpose(0, 1).contiguous()


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = torch.matmul(vec, basis)
    return float(coeff.pow(2).sum().item())


def cosine(a: torch.Tensor, b: torch.Tensor) -> float:
    a = F.normalize(a.float(), dim=-1)
    b = F.normalize(b.float(), dim=-1)
    return float((a * b).sum().item())


def load_model(device: str, depth: int, n_ctx: int, t_n_ctx: int):
    params = {
        "Prompt_length": n_ctx,
        "learnabel_text_embedding_depth": depth,
        "learnabel_text_embedding_length": t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)
    return model, params


def load_prompt_learner(model, params, checkpoint_path: str, device: str):
    learner = AnomalyCLIP_PromptLearner(model.to("cpu"), params)
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    learner.load_state_dict(checkpoint["prompt_learner"])
    learner.to(device)
    learner.eval()
    model.to(device)
    return learner


def get_learned_text_features(model, learner) -> torch.Tensor:
    with torch.no_grad():
        model_device = next(model.parameters()).device
        prompts, tokenized_prompts, compound_prompts_text = learner(cls_id=None)
        prompts = prompts.to(model_device)
        tokenized_prompts = tokenized_prompts.to(model_device)
        compound_prompts_text = [prompt.to(model_device) for prompt in compound_prompts_text]
        text_features = model.encode_text_learn(prompts, tokenized_prompts, compound_prompts_text).float()
        text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)
    return text_features


def get_raw_text_features(reference_model, text_device: str, output_device: str) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    raw_text = encode_text_with_prompt_ensemble(reference_model, ["object"], text_device)
    raw_text = F.normalize(raw_text.float(), dim=-1)
    raw_text = raw_text.unsqueeze(0).to(output_device)
    normal_bank, anomaly_bank = encode_text_prompt_bank(reference_model, "object", text_device)
    normal_bank = F.normalize(normal_bank.float(), dim=-1)
    anomaly_bank = F.normalize(anomaly_bank.float(), dim=-1)
    normal_anchor = F.normalize(normal_bank.mean(dim=0, keepdim=True), dim=-1)
    anomaly_anchor = F.normalize(anomaly_bank.mean(dim=0, keepdim=True), dim=-1)
    return (
        raw_text,
        normal_bank.to(output_device),
        anomaly_bank.to(output_device),
        (normal_anchor.to(output_device), anomaly_anchor.to(output_device)),
    )


def score_one_mode(model, dataloader, text_features, args, class_filter: set[str] | None):
    results = {}
    topk_normal = []
    inside_outside_gap = []
    outside_inside_ratio = []

    for obj in dataloader.dataset.obj_list:
        results[obj] = {
            "gt_sp": [],
            "pr_sp": [],
            "imgs_masks": [],
            "anomaly_maps": [],
        }

    for items in dataloader:
        cls_name = items["cls_name"][0]
        if class_filter and cls_name not in class_filter:
            continue

        image = items["img"].to(args.device)
        gt_mask = items["img_mask"].clone()
        gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
        anomaly_label = int(items["anomaly"][0])

        results[cls_name]["imgs_masks"].append(gt_mask)
        results[cls_name]["gt_sp"].append(anomaly_label)

        with torch.no_grad():
            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True)

            text_probs = image_features @ text_features.permute(0, 2, 1)
            text_probs = (text_probs / 0.07).softmax(-1)
            image_score = float(text_probs[:, 0, 1].item())
            results[cls_name]["pr_sp"].append(image_score)

            anomaly_map_list = []
            for idx, patch_feature in enumerate(patch_features):
                if idx >= args.feature_map_layer[0]:
                    patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
                    similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_features[0])
                    similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], args.image_size)
                    anomaly_map = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0
                    anomaly_map_list.append(anomaly_map)

            anomaly_map = torch.stack(anomaly_map_list).sum(dim=0)
            anomaly_map = torch.stack(
                [torch.from_numpy(gaussian_filter(x, sigma=args.sigma)) for x in anomaly_map.detach().cpu()],
                dim=0,
            )
            results[cls_name]["anomaly_maps"].append(anomaly_map)

            amap_np = anomaly_map[0].numpy()
            if anomaly_label == 0:
                flat = amap_np.reshape(-1)
                k = max(1, int(math.ceil(flat.size * args.normal_topk_ratio)))
                topk_normal.append(float(np.partition(flat, -k)[-k:].mean()))
            else:
                mask_np = gt_mask[0].squeeze(0).numpy().astype(bool)
                if mask_np.any() and (~mask_np).any():
                    inside = float(amap_np[mask_np].mean())
                    outside = float(amap_np[~mask_np].mean())
                    inside_outside_gap.append(inside - outside)
                    outside_inside_ratio.append(outside / (inside + 1e-6))

    metric_summary = {}
    image_scores = []
    pixel_scores = []
    pro_scores = []
    for obj, obj_results in results.items():
        if class_filter and obj not in class_filter:
            continue
        if len(obj_results["gt_sp"]) == 0:
            continue
        obj_results["imgs_masks"] = torch.cat(obj_results["imgs_masks"])
        obj_results["anomaly_maps"] = torch.cat(obj_results["anomaly_maps"]).detach().cpu().numpy()
        img_auc = image_level_metrics(results, obj, "image-auroc")
        px_auc = pixel_level_metrics(results, obj, "pixel-auroc")
        pro = pixel_level_metrics(results, obj, "pixel-aupro")
        metric_summary[obj] = {
            "image_auroc": float(img_auc),
            "pixel_auroc": float(px_auc),
            "pixel_aupro": float(pro),
        }
        image_scores.append(img_auc)
        pixel_scores.append(px_auc)
        pro_scores.append(pro)

    metric_summary["mean"] = {
        "image_auroc": float(np.mean(image_scores)) if image_scores else float("nan"),
        "pixel_auroc": float(np.mean(pixel_scores)) if pixel_scores else float("nan"),
        "pixel_aupro": float(np.mean(pro_scores)) if pro_scores else float("nan"),
        "inside_outside_gap": float(np.mean(inside_outside_gap)) if inside_outside_gap else float("nan"),
        "outside_inside_ratio": float(np.mean(outside_inside_ratio)) if outside_inside_ratio else float("nan"),
        "normal_topk": float(np.mean(topk_normal)) if topk_normal else float("nan"),
    }
    return metric_summary


def main():
    parser = argparse.ArgumentParser("Probe AnomalyCLIP text effect")
    parser.add_argument("--data_path", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--dataset", type=str, default="visa")
    parser.add_argument("--baseline_ckpt", type=str, default=str(ANOMALYCLIP_ROOT / "checkpoints" / "9_12_4_multiscale_visa" / "epoch_15.pth"))
    parser.add_argument("--ours_ckpt", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_textreg_mvtec2visa" / "checkpoints" / "epoch_15.pth"))
    parser.add_argument("--save_dir", type=str, default=str(ROOT / "neurips2026" / "results" / "anomalyclip_text_probe"))
    parser.add_argument("--classes", nargs="*", default=None)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--seed", type=int, default=111)
    parser.add_argument("--normal_topk_ratio", type=float, default=0.01)
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--reference_device", type=str, default="cpu")
    args = parser.parse_args()

    setup_seed(args.seed)
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    model, params = load_model(args.device, args.depth, args.n_ctx, args.t_n_ctx)
    reference_model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=args.reference_device, design_details=None)
    reference_model.eval()

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.data_path, transform=preprocess, target_transform=target_transform, dataset_name=args.dataset)
    class_filter = set(args.classes) if args.classes else None
    if class_filter:
        dataset.data_all = [item for item in dataset.data_all if item["cls_name"] in class_filter]
        dataset.cls_names = [cls_name for cls_name in dataset.cls_names if cls_name in class_filter]
        dataset.obj_list = [cls_name for cls_name in dataset.obj_list if cls_name in class_filter]
        dataset.length = len(dataset.data_all)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    raw_text, normal_bank, _, anchors = get_raw_text_features(reference_model, args.reference_device, args.device)
    normal_anchor, anomaly_anchor = anchors
    basis = normal_basis(normal_bank)

    mode_features = {"raw": raw_text}
    baseline_learner = load_prompt_learner(model, params, args.baseline_ckpt, args.device)
    mode_features["baseline"] = get_learned_text_features(model, baseline_learner)

    ours_ckpt = Path(args.ours_ckpt)
    if ours_ckpt.is_file():
        ours_learner = load_prompt_learner(model, params, str(ours_ckpt), args.device)
        mode_features["ours"] = get_learned_text_features(model, ours_learner)

    text_metrics = {}
    score_metrics = {}
    for mode, text_features in mode_features.items():
        normal_vec = text_features[0, 0]
        anomaly_vec = text_features[0, 1]
        text_metrics[mode] = {
            "normal_anomaly_overlap": cosine(normal_vec, anomaly_vec),
            "anomaly_projection_energy": projection_energy(anomaly_vec, basis),
            "normal_anchor_retention": cosine(normal_vec, normal_anchor[0]),
            "anomaly_anchor_retention": cosine(anomaly_vec, anomaly_anchor[0]),
        }
        score_metrics[mode] = score_one_mode(model, dataloader, text_features, args, class_filter)

    output = {
        "config": {
            "dataset": args.dataset,
            "data_path": args.data_path,
            "classes": sorted(class_filter) if class_filter else "all",
            "features_list": args.features_list,
            "feature_map_layer": args.feature_map_layer,
        },
        "text_metrics": text_metrics,
        "score_metrics": score_metrics,
    }

    summary_path = save_dir / "summary.json"
    summary_path.write_text(json.dumps(output, indent=2))
    print(summary_path)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
