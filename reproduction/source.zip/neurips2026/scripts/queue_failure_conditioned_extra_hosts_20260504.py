#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "failure_conditioned_separability_extra_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "failure_conditioned_separability_extra_20260504"
BANK = ROOT / "neurips2026" / "results" / "bank_cache"

MVTEC_ROOT = Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
VISA_ROOT = ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"
MPDD_ROOT = Path("/mnt/data/MPDD")
BTAD_ROOT = ROOT / "neurips2026" / "data" / "BTAD_official"

ADACLIP_CKPTS = {
    "mvtec": ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth",
    "visa": ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth",
}
ADACLIP_BANKS = {
    "mvtec": BANK / "adaclip_mvtec_full_multilayer.pt",
    "visa": BANK / "adaclip_visa_official1cls_multilayer.pt",
}

ADAPTCLIP_CKPTS = {
    "mvtec": ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_mvtec_3adpaters_batch8" / "epoch_15.pth",
    "visa": ROOT / "neurips2026" / "AdaptCLIP" / "checkpoints" / "12_4_128_train_on_visa_3adapters_batch8" / "epoch_15.pth",
}

TRANSFERS = {
    "mvtec2visa": (MVTEC_ROOT, "mvtec", VISA_ROOT, "visa"),
    "mvtec2mpdd": (MVTEC_ROOT, "mvtec", MPDD_ROOT, "mpdd"),
    "mvtec2btad": (MVTEC_ROOT, "mvtec", BTAD_ROOT, "btad"),
    "visa2mvtec": (VISA_ROOT, "visa", MVTEC_ROOT, "mvtec"),
}


def csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_adaclip(transfer: str, device: str, seed: int) -> tuple[list[str], Path, Path]:
    source_root, source_dataset, target_root, target_dataset = TRANSFERS[transfer]
    save_dir = RESULTS / f"adaclip_vitl336_{transfer}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaclip.py",
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(ADACLIP_CKPTS[source_dataset]),
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
        "--bank_cache_path",
        str(ADACLIP_BANKS[source_dataset]),
        "--backbone",
        "ViT-L-14-336",
        "--checkpoint_load_mode",
        "strict",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--prompting_depth",
        "4",
        "--prompting_length",
        "5",
        "--prompting_branch",
        "VL",
        "--prompting_type",
        "SD",
        "--use_hsf",
        "true",
        "--k_clusters",
        "20",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--layer_recipe",
        "all4",
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "2",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_subspace_basis_control",
        "source",
        "--calib_pair_label_control",
        "correct",
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_gate_mode",
        "host",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--scoring_mode",
        "logit_gate_posneg",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--image_topk_frac",
        "0.01",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        str(seed),
        "--device",
        device,
    ]
    return cmd, save_dir, log_path


def build_adaptclip(transfer: str, device: str, seed: int) -> tuple[list[str], Path, Path]:
    source_root, source_dataset, target_root, target_dataset = TRANSFERS[transfer]
    save_dir = RESULTS / f"adaptclip_vitl336_{transfer}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    vl_bank = BANK / f"adaptclip_failure_conditioned_vitl336_{source_dataset}_vl_seed{seed}.pt"
    tl_bank = BANK / f"adaptclip_failure_conditioned_vitl336_{source_dataset}_tl_seed{seed}.pt"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaptclip_vlrefine.py",
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_root),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(ADAPTCLIP_CKPTS[source_dataset]),
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
        "--bank_cache_path",
        str(vl_bank),
        "--tl_bank_cache_path",
        str(tl_bank),
        "--pretrained_model",
        "ViT-L/14@336px",
        "--checkpoint_load_mode",
        "strict",
        "--features_list",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "1",
        "--n_ctx",
        "12",
        "--sigma",
        "4",
        "--vl_reduction",
        "4",
        "--fusion_type",
        "average_mean",
        "--tau",
        "20.0",
        "--fp_weight",
        "0.3",
        "--corr_alpha",
        "0.3",
        "--map_activation",
        "sigmoid",
        "--map_temperature",
        "1.0",
        "--vl_gate_mode",
        "host",
        "--vl_gate_quantile",
        "0.9",
        "--vl_gate_temp",
        "0.25",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_points",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--ted_insertion",
        "dual_branch",
        "--calib_epochs",
        "0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "2",
        "--calib_lambda",
        "0.005",
        "--calib_score_mode",
        "rankr_density",
        "--calib_rankr_tau",
        "0.1",
        "--calib_apply_mode",
        "add",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--aupro_expect_fpr",
        "0.3",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        str(seed),
        "--device",
        device,
        "--num_workers",
        "4",
    ]
    return cmd, save_dir, log_path


def worker_script(jobs: list[tuple[list[str], Path, Path]], worker_id: int) -> Path:
    path = LOGS / f"extra_worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        "jobs = [",
    ]
    for cmd, save_dir, log_path in jobs:
        lines.append(f"    ({cmd!r}, {str(save_dir)!r}, {str(log_path)!r}),")
    lines += [
        "]",
        "for cmd, save_dir, log_path in jobs:",
        "    summary = Path(save_dir) / 'summary.json'",
        "    Path(log_path).parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists():",
        "        print({'stage': 'skip', 'summary': str(summary)}, flush=True)",
        "        continue",
        "    print({'stage': 'run', 'save_dir': save_dir, 'log': log_path}, flush=True)",
        "    with open(log_path, 'w') as f:",
        "        subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, check=False)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    path.write_text("\n".join(lines))
    return path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="adaclip,adaptclip")
    ap.add_argument("--transfers", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    hosts = csv(args.hosts)
    transfers = csv(args.transfers)
    devices = csv(args.devices)
    builders = {"adaclip": build_adaclip, "adaptclip": build_adaptclip}

    all_jobs: list[tuple[list[str], Path, Path]] = []
    for host in hosts:
        if host not in builders:
            raise SystemExit(f"Unknown host={host}; allowed={sorted(builders)}")
        for transfer in transfers:
            if transfer not in TRANSFERS:
                raise SystemExit(f"Unknown transfer={transfer}; allowed={sorted(TRANSFERS)}")
            device = devices[len(all_jobs) % len(devices)]
            all_jobs.append(builders[host](transfer, device, args.seed))

    buckets = [[] for _ in devices]
    for i, job in enumerate(all_jobs):
        buckets[i % len(devices)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        script = worker_script(bucket, worker_id)
        log = LOGS / f"extra_worker_{worker_id}.log"
        with log.open("a") as f:
            proc = subprocess.Popen([str(PY), str(script)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "log": str(log), "script": str(script)})
    print(json.dumps({"stage": "queued_failure_conditioned_extra_hosts", "launched": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
