from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULT_ROOT = ROOT / "neurips2026/results/anomalyclip_ted_backbone_swap_seeded_20260430"

BACKBONES = [
    ("ViT-L/14 OpenAI", "vitl_openai"),
    ("ViT-B/16 projected", "vitb16_projected"),
    ("ViT-H/14 projected", "vith14_projected"),
]
TARGETS = [
    ("visa2mvtec", "MVTec"),
    ("mvtec2visa", "VisA"),
    ("mvtec2mpdd", "MPDD"),
    ("mvtec2btad", "BTAD"),
]
METHODS = [
    ("Base", "baseline_txt", 0.0),
    ("Train-free TED", "parallel_margin", -0.2),
    ("Calibrated TED", "ted_calibrated", -0.05),
]
METRICS = [
    ("I-AUROC", "image_auroc"),
    ("P-AUROC", "pixel_auroc"),
    ("P-PRO", "pixel_aupro"),
    ("P-AP", "pixel_ap"),
]


def load_mean_row(path: Path, mode: str, beta: float) -> dict | None:
    if not path.exists():
        return None
    payload = json.loads(path.read_text())
    for row in payload["rows"]:
        if row.get("target_label") == "mean" and row.get("mode") == mode and abs(float(row.get("beta", 0.0)) - beta) < 1e-8:
            return row
    return None


def fmt(values: list[float]) -> str:
    arr = np.asarray(values, dtype=np.float64)
    if arr.size == 0 or np.all(np.isnan(arr)):
        return "--.--"
    return f"{100 * np.nanmean(arr):.2f}$\\pm${100 * np.nanstd(arr):.2f}"


def main() -> None:
    print("% AnomalyCLIP backbone-swap stress results, source-only projected prompt protocol")
    print("% Each cell: I-AUROC / P-AUROC / P-PRO / P-AP")
    for backbone_label, backbone_tag in BACKBONES:
        print(f"\n% Backbone: {backbone_label}")
        for transfer, target in TARGETS:
            print(f"% Target: {target} ({transfer})")
            for method_label, mode, beta in METHODS:
                metric_values = {metric_key: [] for _, metric_key in METRICS}
                for seed in (0, 1, 2):
                    row = load_mean_row(RESULT_ROOT / f"{backbone_tag}_{transfer}_seed{seed}" / "summary.json", mode, beta)
                    if row is None:
                        continue
                    for _, metric_key in METRICS:
                        metric_values[metric_key].append(float(row[metric_key]))
                cell = " / ".join(fmt(metric_values[metric_key]) for _, metric_key in METRICS)
                print(f"{method_label} & {cell} \\\\")


if __name__ == "__main__":
    main()
