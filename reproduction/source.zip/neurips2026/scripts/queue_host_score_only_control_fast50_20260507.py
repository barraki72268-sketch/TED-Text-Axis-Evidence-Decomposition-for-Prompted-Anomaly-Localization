#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import queue_host_score_only_control_20260507 as base


ROOT = base.ROOT
PY = base.PY
RESULTS = ROOT / "neurips2026" / "results" / "host_score_only_control_fast50_20260507"
LOGS = ROOT / "neurips2026" / "logs" / "host_score_only_control_fast50_20260507"


def set_arg(cmd: list[str], option: str, value: str) -> None:
    if option in cmd:
        idx = cmd.index(option)
        if idx + 1 < len(cmd):
            cmd[idx + 1] = value
        else:
            cmd.append(value)
    else:
        cmd.extend([option, value])


def prepare_fast_job(job: dict) -> dict:
    cmd = list(job["cmd"])
    set_arg(cmd, "--aupro_max_step", "50")
    if job["host"] == "adaptclip":
        set_arg(cmd, "--ted_insertion", "dual_branch")
        save_dir = Path(job["save_dir"]).with_name(Path(job["save_dir"]).name.replace("adaptclip_vl_last24", "adaptclip_dualbranch_vl_last24"))
        job = {**job, "save_dir": save_dir}
        set_arg(cmd, "--save_dir", str(save_dir.relative_to(ROOT)))
    return {**job, "cmd": cmd}


def write_worker(jobs: list[dict], worker_id: int, force: bool) -> Path:
    worker_path = LOGS / f"worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess, time",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        f"FORCE = {bool(force)!r}",
        "jobs = [",
    ]
    for job in jobs:
        log_path = LOGS / f"{job['save_dir'].name}.log"
        lines.append(
            "    "
            + repr({
                "host": job["host"],
                "preset": job["preset"],
                "cmd": job["cmd"],
                "save_dir": str(job["save_dir"]),
                "log_path": str(log_path),
            })
            + ","
        )
    lines += [
        "]",
        "for job in jobs:",
        "    save_dir = Path(job['save_dir'])",
        "    summary = save_dir / 'summary.json'",
        "    log_path = Path(job['log_path'])",
        "    log_path.parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists() and not FORCE:",
        "        print({'stage': 'skip_done', **{k: job[k] for k in ('host', 'preset')}, 'summary': str(summary)}, flush=True)",
        "        continue",
        "    save_dir.mkdir(parents=True, exist_ok=True)",
        "    print({'stage': 'job_start', **{k: job[k] for k in ('host', 'preset')}, 'save_dir': str(save_dir), 'log': str(log_path)}, flush=True)",
        "    start = time.time()",
        "    with log_path.open('w') as f:",
        "        proc = subprocess.run(job['cmd'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)",
        "    print({'stage': 'job_done', **{k: job[k] for k in ('host', 'preset')}, 'returncode': proc.returncode, 'elapsed_sec': time.time() - start}, flush=True)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    worker_path.write_text("\n".join(lines))
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="adaclip,adaptclip")
    ap.add_argument("--presets", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = [x.strip().lower() for x in args.hosts.split(",") if x.strip()]
    presets = [x.strip().lower() for x in args.presets.split(",") if x.strip()]
    devices = [x.strip() for x in args.devices.split(",") if x.strip()]
    unknown_hosts = set(hosts) - {"adaclip", "adaptclip"}
    unknown_presets = set(presets) - set(base.PRESETS)
    if unknown_hosts:
        raise SystemExit(f"Unknown hosts={sorted(unknown_hosts)}")
    if unknown_presets:
        raise SystemExit(f"Unknown presets={sorted(unknown_presets)}")
    if not devices:
        raise SystemExit("No devices provided")

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    old_results, old_logs = base.RESULTS, base.LOGS
    base.RESULTS, base.LOGS = RESULTS, LOGS
    try:
        jobs = [prepare_fast_job(job) for job in base.build_jobs(hosts, presets, devices, args.seed)]
    finally:
        base.RESULTS, base.LOGS = old_results, old_logs

    buckets = [[] for _ in devices]
    for idx, job in enumerate(jobs):
        buckets[idx % len(buckets)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        worker_path = write_worker(bucket, worker_id, args.force)
        worker_log = LOGS / f"worker_{worker_id}.log"
        with worker_log.open("a") as f:
            proc = subprocess.Popen([str(PY), "-u", str(worker_path)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "worker": str(worker_path), "log": str(worker_log)})

    print(json.dumps({"stage": "queued_host_score_only_control_fast50", "launched": launched, "num_jobs": len(jobs)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
