from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)


RECIPES = ["Full", "EL", "L2", "L"]
BASE = np.array([58.12, 60.18, 57.51, 57.92])
CTED = np.array([60.59, 61.96, 59.66, 60.12])
DELTA = CTED - BASE


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "xtick.labelsize": 11,
            "ytick.labelsize": 10,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    x = np.arange(len(RECIPES))
    fig, ax = plt.subplots(figsize=(3.55, 2.55))
    ax.plot(x, BASE, color="#7F8790", marker="o", linewidth=2.2, markersize=6, label="B")
    ax.plot(x, CTED, color="#1B5E8A", marker="o", linewidth=2.6, markersize=6, label="C-TED")

    for xi, b, c, d in zip(x, BASE, CTED, DELTA):
        ax.plot([xi, xi], [b, c], color="#1B5E8A", alpha=0.35, linewidth=1.5)
        ax.text(xi, c + 0.35, f"+{d:.1f}", ha="center", va="bottom", fontsize=9.2, fontweight="bold", color="#1B5E8A")

    ax.set_title("Recipe changes leave hard-FP entanglement", fontweight="bold", pad=6)
    ax.set_ylabel("Defect vs. hard-FP AUC")
    ax.set_xticks(x)
    ax.set_xticklabels(RECIPES, fontweight="bold")
    ax.set_ylim(55.8, 63.0)
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.75)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(loc="lower right", frameon=False, fontsize=9.5, handlelength=1.5)

    fig.tight_layout(pad=0.25)
    pdf = FIG_DIR / "recipe_entanglement_discussion_20260503.pdf"
    png = FIG_DIR / "recipe_entanglement_discussion_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")

    tex = OUT_DIR / "recipe_entanglement_discussion_figure_20260503.tex"
    tex.write_text(
        r"""\begin{figure}[t]
\centering
\includegraphics[width=0.86\linewidth]{figure/recipe_entanglement_discussion_20260503.pdf}
\caption{
Evidence entanglement under layer-recipe retraining.
Each recipe is retrained before evaluation; C-TED consistently improves defect-versus-hard-FP separation over the retrained baseline.
}
\label{fig:recipe_entanglement_discussion}
\end{figure}
""",
        encoding="utf-8",
    )
    print(pdf)
    print(png)
    print(tex)


if __name__ == "__main__":
    main()
