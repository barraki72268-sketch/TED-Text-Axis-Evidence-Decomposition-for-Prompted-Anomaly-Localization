from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader
from WinCLIP import WinClipAD
from utils.eval_utils import specify_resolution
from utils.metrics import metric_cal


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--eta", type=float, default=0.1)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=1)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--output_tag", type=str, default="winclip_prompt_oracle_mutest")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(model: WinClipAD, batch_np) -> torch.Tensor:
    imgs = [model.transform(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(model.device)


@torch.no_grad()
def compute_mu_test(model: WinClipAD, loader) -> torch.Tensor:
    feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        image = _preprocess_batch(model, data)
        visual_features = model.encode_image(image)
        for feat in visual_features:
            feats.append(feat[normal_idx].float())
    if not feats:
        raise RuntimeError("No normal test features found for mu_test.")
    mu = torch.cat(feats, dim=0).mean(dim=0, keepdim=True)
    mu = F.normalize(mu, dim=-1)
    return mu


@torch.no_grad()
def evaluate_current_text_features(model: WinClipAD, loader, resolution: int) -> dict[str, float]:
    scores = []
    test_imgs = []
    gt_list = []
    gt_mask_list = []
    for data, mask, label, _name, _img_type in loader:
        for f in data:
            test_imgs.append(f.numpy())
        image = _preprocess_batch(model, data)
        score = model(image)
        score_batch = []
        for s in score:
            if isinstance(s, np.ndarray):
                score_batch.append(np.asarray(s).squeeze())
            else:
                score_batch.append(s.squeeze().detach().cpu().numpy())
        scores += score_batch
        for l, m in zip(label, mask):
            gt_list.append(int(l.numpy() if hasattr(l, "numpy") else l))
            gt_mask_list.append((m.numpy() > 0).astype(np.uint8))
    test_imgs, scores, gt_mask_list = specify_resolution(
        test_imgs,
        scores,
        gt_mask_list,
        resolution=(resolution, resolution),
    )
    metrics = metric_cal(np.array(scores), gt_list, gt_mask_list, cal_pro=False)
    return {
        "i_roc": float(metrics["i_roc"]),
        "p_roc": float(metrics["p_roc"]),
        "p_pro": float(metrics["p_pro"]),
    }


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"

    rows = []
    for class_name in args.class_names:
        loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)
        model = WinClipAD(
            out_size_h=args.resolution,
            out_size_w=args.resolution,
            device=device,
            backbone=args.backbone,
            pretrained_dataset=args.pretrained_dataset,
            scales=tuple(args.scales),
            img_resize=args.img_resize,
            img_cropsize=args.img_cropsize,
        ).to(device)
        model.eval_mode()
        model.build_text_feature_gallery(class_name)

        base_normal = model.avr_normal_text_features.float()
        base_abnormal = model.avr_abnormal_text_features.float()
        mu_test = compute_mu_test(model, loader)
        oracle_normal = F.normalize(base_normal + args.eta * (mu_test - base_normal), dim=-1)

        baseline_metrics = evaluate_current_text_features(model, loader, args.resolution)

        model.avr_normal_text_features = oracle_normal.to(model.device, dtype=model.text_features.dtype)
        model.text_features = torch.cat(
            [
                model.avr_normal_text_features,
                F.normalize(base_abnormal, dim=-1).to(model.device, dtype=model.text_features.dtype),
            ],
            dim=0,
        )
        model.text_features = F.normalize(model.text_features, dim=-1)
        oracle_metrics = evaluate_current_text_features(model, loader, args.resolution)

        cos_mu_normal = float(F.cosine_similarity(mu_test, base_normal, dim=-1).item())
        rows.append(
            {
                "class_name": class_name,
                "eta": float(args.eta),
                "cos_mu_base_normal": cos_mu_normal,
                "baseline_i_roc": baseline_metrics["i_roc"],
                "baseline_p_roc": baseline_metrics["p_roc"],
                "baseline_p_pro": baseline_metrics["p_pro"],
                "oracle_i_roc": oracle_metrics["i_roc"],
                "oracle_p_roc": oracle_metrics["p_roc"],
                "oracle_p_pro": oracle_metrics["p_pro"],
                "delta_i_roc": oracle_metrics["i_roc"] - baseline_metrics["i_roc"],
                "delta_p_roc": oracle_metrics["p_roc"] - baseline_metrics["p_roc"],
                "delta_p_pro": oracle_metrics["p_pro"] - baseline_metrics["p_pro"],
            }
        )
        print(
            f"{class_name} | eta={args.eta:.2f} | "
            f"dI={rows[-1]['delta_i_roc']:.2f} "
            f"dP={rows[-1]['delta_p_roc']:.2f} "
            f"dPRO={rows[-1]['delta_p_pro']:.2f} "
            f"cos(mu,t)={cos_mu_normal:.4f}",
            flush=True,
        )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(rows, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
