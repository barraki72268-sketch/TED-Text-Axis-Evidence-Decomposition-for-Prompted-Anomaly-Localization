from __future__ import annotations

import csv
import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

import matplotlib.pyplot as plt

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"

MODEL_SOURCES = {
    "AnomalyCLIP": RESULTS / "anomalyclip_text_collapse" / "collapse_metrics.json",
    "AdaptCLIP": RESULTS / "problem_geom_adaptclip_baseline_curve" / "metrics.json",
    "AdaCLIP": RESULTS / "problem_geom_adaclip_baseline_fixed" / "metrics.json",
    "FAPrompt": RESULTS / "problem_geom_faprompt_baseline" / "metrics.json",
    "Bayes-PFL": RESULTS / "problem_geom_bayespfl_baseline" / "metrics.json",
}

METRICS = [
    "overlap_cos",
    "proj_energy_to_normal",
    "anchor_retention_norm",
    "anchor_retention_anom",
]


def load_rows(path: Path):
    if not path.exists():
        return []
    with open(path, "r") as f:
        rows = json.load(f)
    if isinstance(rows, dict):
        rows = rows.get("rows", [])
    return rows


def filter_baseline(rows):
    out = []
    for row in rows:
        if row.get("series", "baseline") == "baseline":
            out.append(row)
    return out


def extract_epoch(row):
    epoch = row.get("epoch")
    if epoch is None:
        return 0
    return int(epoch)


def make_summary(rows_by_model, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    for model_name, rows in rows_by_model.items():
        if not rows:
            continue
        rows = sorted(rows, key=extract_epoch)
        last = rows[-1]
        summary_rows.append(
            {
                "model": model_name,
                "epoch": extract_epoch(last),
                **{metric: last[metric] for metric in METRICS},
            }
        )

    with open(save_dir / "geometry_final_summary.json", "w") as f:
        json.dump(summary_rows, f, indent=2)
    with open(save_dir / "geometry_final_summary.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["model", "epoch", *METRICS])
        writer.writeheader()
        writer.writerows(summary_rows)
    return summary_rows


def plot_epoch_curves(rows_by_model, save_dir: Path):
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes = axes.ravel()
    for ax, metric in zip(axes, METRICS):
        for model_name, rows in rows_by_model.items():
            if len(rows) <= 1:
                continue
            rows = sorted(rows, key=extract_epoch)
            xs = [extract_epoch(r) for r in rows]
            ys = [r[metric] for r in rows]
            ax.plot(xs, ys, marker="o", label=model_name)
        ax.set_title(metric)
        ax.set_xlabel("epoch")
        ax.grid(alpha=0.3)
    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", ncol=min(5, len(labels)))
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(save_dir / "geometry_epoch_curves.png", dpi=200)
    plt.close(fig)


def plot_final_bars(summary_rows, save_dir: Path):
    if not summary_rows:
        return
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes = axes.ravel()
    models = [row["model"] for row in summary_rows]
    for ax, metric in zip(axes, METRICS):
        vals = [row[metric] for row in summary_rows]
        ax.bar(models, vals)
        ax.set_title(metric)
        ax.tick_params(axis="x", rotation=30)
        ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(save_dir / "geometry_final_bars.png", dpi=200)
    plt.close(fig)


def main():
    save_dir = RESULTS / "problem_geometry_dashboard"
    rows_by_model = {}
    for model_name, path in MODEL_SOURCES.items():
        rows = filter_baseline(load_rows(path))
        rows_by_model[model_name] = rows

    summary_rows = make_summary(rows_by_model, save_dir)
    plot_epoch_curves(rows_by_model, save_dir)
    plot_final_bars(summary_rows, save_dir)
    with open(save_dir / "available_models.json", "w") as f:
        json.dump(
            {model: str(path) for model, path in MODEL_SOURCES.items() if rows_by_model.get(model)},
            f,
            indent=2,
        )


if __name__ == "__main__":
    main()
