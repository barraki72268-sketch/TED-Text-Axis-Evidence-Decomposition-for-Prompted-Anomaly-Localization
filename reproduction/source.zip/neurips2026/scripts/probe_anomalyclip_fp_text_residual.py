from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
ANO_ROOT = ROOT / "neurips2026" / "AnomalyCLIP"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(ANO_ROOT) not in sys.path:
    sys.path.insert(0, str(ANO_ROOT))

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from probe_anomalyclip_fp_text_decomposition import (  # noqa: E402
    build_model,
    collect_source_hardfp_bases,
    component_decompose,
    get_learned_text_pair,
    load_prompt_learner,
)
from utils import get_transform  # noqa: E402


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def save_rows(rows: list[dict], summary: dict, save_dir: Path) -> None:
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump({"rows": rows, "summary": summary}, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "alpha",
                "class_name",
                "num_anomaly",
                "num_normal",
                "inside_mean",
                "outside_mean",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Probe FP-specific text residualization for AnomalyCLIP baseline")
    parser.add_argument("--source_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_root", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_lproj_lambda_0" / "checkpoints" / "epoch_5.pth"),
    )
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "anomalyclip_fp_text_residual_baseline_epoch5"),
    )
    parser.add_argument("--device", type=str, default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--feature_map_layer", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--source_hard_frac", type=float, default=0.01)
    parser.add_argument("--max_source_per_class", type=int, default=8)
    parser.add_argument("--fp_rank", type=int, default=16)
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.0, 0.1, 0.3, 0.5, 1.0])
    parser.add_argument("--penalty_mode", type=str, default="relu", choices=["raw", "relu", "abs", "square"])
    args = parser.parse_args()

    device = args.device
    model, params = build_model(device, args.depth, args.n_ctx, args.t_n_ctx)
    learner = load_prompt_learner(model, params, Path(args.checkpoint_path), device)
    text_pair = get_learned_text_pair(model, learner)
    learned_anom = text_pair[1].detach()

    fp_bases, fp_stats = collect_source_hardfp_bases(
        model=model,
        text_pair=text_pair.to(device),
        source_root=args.source_root,
        image_size=args.image_size,
        device=device,
        features_list=args.features_list,
        feature_map_layer=args.feature_map_layer,
        max_per_class=args.max_source_per_class,
        hard_frac=args.source_hard_frac,
        fp_rank=args.fp_rank,
    )
    fp_components = {}
    for layer_idx, basis in fp_bases.items():
        e_fp, _ = component_decompose(learned_anom.cpu(), basis.cpu())
        fp_components[layer_idx] = e_fp.to(device)

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.target_root, transform=preprocess, target_transform=target_transform, dataset_name="visa")
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    per_alpha_class = {
        alpha: {
            obj: {
                "num_anomaly": 0,
                "num_normal": 0,
                "inside_sum": 0.0,
                "outside_sum": 0.0,
                "ratio_sum": 0.0,
                "normal_topk_sum": 0.0,
                "normal_mean_sum": 0.0,
            }
            for obj in dataset.obj_list
        }
        for alpha in args.alphas
    }

    print(
        json.dumps(
            {
                "stage": "fp_text_residual_start",
                "num_images": len(dataset),
                "alphas": args.alphas,
                "fp_basis_stats": fp_stats,
            },
            indent=2,
        ),
        flush=True,
    )

    with torch.no_grad():
        for img_idx, items in enumerate(loader, start=1):
            image = items["img"].to(device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            _, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            layer_score_maps: dict[float, list[torch.Tensor]] = {alpha: [] for alpha in args.alphas}

            for layer_idx, patch_feature in enumerate(patch_features):
                if layer_idx < args.feature_map_layer[0]:
                    continue
                patch_feature = patch_feature / patch_feature.norm(dim=-1, keepdim=True)
                similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_feature, text_pair)
                similarity_map = AnomalyCLIP_lib.get_similarity_map(similarity[:, 1:, :], args.image_size)
                base_score = (similarity_map[..., 1] + 1 - similarity_map[..., 0]) / 2.0

                fp_vec = fp_components[layer_idx]
                patch_tokens = F.normalize(patch_feature[:, 1:, :].float(), dim=-1)
                fp_token_score = (patch_tokens @ fp_vec).unsqueeze(-1)
                fp_score = AnomalyCLIP_lib.get_similarity_map(fp_token_score, args.image_size)[..., 0]

                if args.penalty_mode == "raw":
                    penalty = fp_score
                elif args.penalty_mode == "relu":
                    penalty = torch.clamp(fp_score, min=0.0)
                elif args.penalty_mode == "abs":
                    penalty = fp_score.abs()
                elif args.penalty_mode == "square":
                    penalty = fp_score.square()
                else:
                    raise ValueError(f"Unsupported penalty_mode: {args.penalty_mode}")

                for alpha in args.alphas:
                    adj_score = base_score - alpha * penalty
                    layer_score_maps[alpha].append(adj_score)

            for alpha in args.alphas:
                anomaly_map = torch.stack(layer_score_maps[alpha]).sum(dim=0)[0].detach().cpu().numpy()
                anomaly_map = gaussian_filter(anomaly_map, sigma=args.sigma)
                stats = per_alpha_class[alpha][cls_name]
                if is_anomaly and gt_mask.any():
                    inside = float(anomaly_map[gt_mask].mean())
                    outside = float(anomaly_map[~gt_mask].mean())
                    stats["num_anomaly"] += 1
                    stats["inside_sum"] += inside
                    stats["outside_sum"] += outside
                    stats["ratio_sum"] += outside / max(inside, 1e-8)
                else:
                    stats["num_normal"] += 1
                    stats["normal_topk_sum"] += topk_mean(anomaly_map, args.topk_frac)
                    stats["normal_mean_sum"] += float(anomaly_map.mean())

            if img_idx % 64 == 0 or img_idx == len(loader):
                print(
                    json.dumps(
                        {
                            "stage": "fp_text_residual_progress",
                            "images_done": img_idx,
                            "images_total": len(loader),
                        }
                    ),
                    flush=True,
                )

    rows = []
    summary = {
        "host": "AnomalyCLIP",
        "checkpoint_path": args.checkpoint_path,
        "penalty_mode": args.penalty_mode,
        "fp_basis_stats": fp_stats,
        "mean_by_alpha": {},
    }
    for alpha in args.alphas:
        cls_rows = []
        for cls_name, stats in per_alpha_class[alpha].items():
            row = {
                "alpha": alpha,
                "class_name": cls_name,
                "num_anomaly": stats["num_anomaly"],
                "num_normal": stats["num_normal"],
                "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
                "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
                "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
                "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
                "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
                "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
            }
            rows.append(row)
            cls_rows.append(row)

        mean_row = {
            "alpha": alpha,
            "class_name": "mean",
            "num_anomaly": sum(r["num_anomaly"] for r in cls_rows),
            "num_normal": sum(r["num_normal"] for r in cls_rows),
            "inside_mean": float(np.mean([r["inside_mean"] for r in cls_rows])),
            "outside_mean": float(np.mean([r["outside_mean"] for r in cls_rows])),
            "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in cls_rows])),
            "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in cls_rows])),
            "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in cls_rows])),
            "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in cls_rows])),
        }
        rows.append(mean_row)
        summary["mean_by_alpha"][str(alpha)] = mean_row

    save_rows(rows, summary, Path(args.save_dir))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
