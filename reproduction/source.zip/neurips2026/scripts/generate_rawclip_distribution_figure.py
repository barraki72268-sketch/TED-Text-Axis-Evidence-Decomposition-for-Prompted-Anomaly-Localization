from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from generate_rawclip_qualitative import (  # noqa: E402
    build_transforms,
    create_winclip_raw_backbone,
    load_bank_cache,
    overlay_gt,
    resize_score_map,
    score_class_items,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Generate raw-CLIP score-distribution figure")
    parser.add_argument("--target_root", type=str, default="/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec")
    parser.add_argument("--target_split", type=str, default="test")
    parser.add_argument("--class_name", type=str, nargs="+", default=["capsule", "pill"])
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--image_size", type=int, default=240)
    parser.add_argument("--prompt_mode", type=str, default="class")
    parser.add_argument("--features_list", type=int, nargs="+", default=[3, 6, 9, 12])
    parser.add_argument(
        "--bank_cache_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "bank_cache" / "rawclip_vitb_visa_multilayer.pt"),
    )
    parser.add_argument("--sigma", type=float, default=4.0)
    parser.add_argument("--tau", type=float, default=20.0)
    parser.add_argument("--image_score_topk", type=float, default=0.01)
    parser.add_argument("--scan_good", type=int, default=1)
    parser.add_argument("--scan_bad", type=int, default=8)
    parser.add_argument("--hard_fp_frac", type=float, default=0.02)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument(
        "--output_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "rawclip_distribution_capsule_pill"),
    )
    return parser.parse_args()


def split_groups(baseline_score: np.ndarray, gt_mask: np.ndarray, hard_fp_frac: float):
    mask_bool = gt_mask > 0.5
    normal_idx = np.flatnonzero(~mask_bool.reshape(-1))
    base_flat = baseline_score.reshape(-1)
    k = max(1, int(round(normal_idx.size * hard_fp_frac)))
    hard_fp_order = normal_idx[np.argsort(base_flat[normal_idx])[-k:]]
    hard_fp_mask = np.zeros_like(mask_bool.reshape(-1), dtype=bool)
    hard_fp_mask[hard_fp_order] = True
    hard_fp_mask = hard_fp_mask.reshape(mask_bool.shape)
    other_normal = (~mask_bool) & (~hard_fp_mask)
    return mask_bool, hard_fp_mask, other_normal


def choose_best_anomaly(scored_bad: list[dict]) -> dict:
    best = None
    best_key = None
    for rec in scored_bad:
        gt = rec["item"]["img_mask"][0].numpy()
        base = resize_score_map(rec["baseline_map"], gt.shape)
        ours = resize_score_map(np.clip(rec["ours_map"], 0.0, None), gt.shape)
        mask = gt > 0.5
        neg = ~mask
        if mask.sum() == 0 or neg.sum() == 0:
            continue
        base_gap = float(base[mask].mean() - base[neg].mean())
        ours_gap = float(ours[mask].mean() - ours[neg].mean())
        key = (ours_gap - base_gap, ours_gap, float(mask.sum()))
        if best is None or key > best_key:
            best = rec
            best_key = key
    return best


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=args.device,
        img_resize=args.image_size,
        img_cropsize=args.image_size,
    )
    image_transform, mask_transform = build_transforms(args.image_size)
    fp_banks, def_banks, _, _ = load_bank_cache(Path(args.bank_cache_path))

    selected = []
    for cls_name in args.class_name:
        _, scored_bad = score_class_items(backbone, args, image_transform, mask_transform, fp_banks, def_banks, cls_name)
        chosen = choose_best_anomaly(scored_bad)
        if chosen is not None:
            selected.append(chosen)

    fig, axes = plt.subplots(len(selected), 3, figsize=(17.5, 4.8 * len(selected)), constrained_layout=True)
    if len(selected) == 1:
        axes = np.expand_dims(axes, 0)

    titles = ["Input + GT", "Baseline", "Ours (D-S)"]
    for j, title in enumerate(titles):
        axes[0, j].set_title(title, fontsize=18, fontweight="bold")

    summary_rows = []
    colors = {
        "abnormal": "#c43c39",
        "hard_fp": "#3568b8",
        "other": "#8a8a8a",
    }

    for row_idx, rec in enumerate(selected):
        raw_img = rec["item"]["raw_image"]
        gt_mask = rec["item"]["img_mask"][0].numpy()
        gt_overlay = overlay_gt(raw_img, gt_mask)
        axes[row_idx, 0].imshow(gt_overlay)
        axes[row_idx, 0].axis("off")
        axes[row_idx, 0].set_ylabel(
            f"{rec['item']['cls_name']} | {Path(rec['item']['img_path']).name}",
            fontsize=15,
            fontweight="bold",
        )

        baseline_score = resize_score_map(rec["baseline_map"], gt_mask.shape)
        ours_score = resize_score_map(rec["ours_map"], gt_mask.shape)
        abnormal_mask, hard_fp_mask, other_normal_mask = split_groups(baseline_score, gt_mask, args.hard_fp_frac)
        panels = [
            (axes[row_idx, 1], baseline_score, "Baseline"),
            (axes[row_idx, 2], ours_score, "Ours (D-S)"),
        ]
        for ax, score_map, title in panels:
            x_lo = float(score_map.min())
            x_hi = float(score_map.max())
            if x_hi <= x_lo:
                x_hi = x_lo + 1e-6
            ax.hist(
                score_map[other_normal_mask].reshape(-1),
                bins=28,
                range=(x_lo, x_hi),
                density=True,
                color=colors["other"],
                alpha=0.38,
                edgecolor="none",
                label="other normal",
            )
            ax.hist(
                score_map[hard_fp_mask].reshape(-1),
                bins=28,
                range=(x_lo, x_hi),
                density=True,
                color=colors["hard_fp"],
                alpha=0.48,
                edgecolor="none",
                label="hard-FP normal",
            )
            ax.hist(
                score_map[abnormal_mask].reshape(-1),
                bins=28,
                range=(x_lo, x_hi),
                density=True,
                color=colors["abnormal"],
                alpha=0.58,
                edgecolor="none",
                label="GT abnormal",
            )
            ax.set_xlim(x_lo, x_hi)
            ax.tick_params(axis="both", labelsize=10)
            ax.grid(axis="y", linestyle="--", alpha=0.2)
            ax.set_xlabel("score", fontsize=11, fontweight="bold")
            ax.set_ylabel("density", fontsize=11)
            for spine in ["top", "right"]:
                ax.spines[spine].set_visible(False)
        if row_idx == 0:
            axes[row_idx, 2].legend(
                loc="center left",
                bbox_to_anchor=(1.03, 0.5),
                fontsize=10,
                frameon=False,
                borderaxespad=0.0,
            )

        summary_rows.append(
            {
                "img_path": rec["item"]["img_path"],
                "cls_name": rec["item"]["cls_name"],
                "num_abnormal": int(abnormal_mask.sum()),
                "num_hard_fp_normal": int(hard_fp_mask.sum()),
                "num_other_normal": int(other_normal_mask.sum()),
            }
        )

    png_path = out_dir / "rawclip_distribution_figure.png"
    pdf_path = out_dir / "rawclip_distribution_figure.pdf"
    json_path = out_dir / "rawclip_distribution_figure.json"
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    json_path.write_text(json.dumps({"selected": summary_rows}, indent=2))
    print(json.dumps({"png": str(png_path), "pdf": str(pdf_path), "json": str(json_path), "selected": summary_rows}, indent=2))


if __name__ == "__main__":
    main()
