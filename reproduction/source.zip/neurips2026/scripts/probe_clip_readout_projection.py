from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_abnormal_prompts,
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["capsules", "candle"])
    parser.add_argument("--target_layer", type=int, default=12)
    parser.add_argument(
        "--k_source_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "clip_kin_split_allvisa_analysis" / "class_best_summary.csv"),
    )
    parser.add_argument("--num_splits", type=int, default=20)
    parser.add_argument("--fit_fraction", type=float, default=0.5)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--max_fit_anom_patches", type=int, default=4096)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_readout_projection")
    return parser.parse_args()


def build_text_anchor(backbone, class_name: str, abnormal: bool) -> torch.Tensor:
    state_prompts = state_level_abnormal_prompts if abnormal else state_level_normal_prompts
    class_text = class_name.replace("_", " ")
    prompts: list[str] = []
    for template in template_level_prompts:
        for state_prompt in state_prompts:
            prompts.append(template.format(state_prompt.format(class_text)))

    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = getattr(backbone.visual, "proj", None)
    if proj is not None:
        text_anchor = proj.detach().float().to(text_anchor.device) @ text_anchor
        text_anchor = F.normalize(text_anchor, dim=0)
    return text_anchor.cpu()


def to_mask_tokens(mask_np: np.ndarray, side_h: int, side_w: int, device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=(side_h, side_w), mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def get_null_space_residual(V: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    V = F.normalize(V.float(), dim=-1)
    V_proj = (V @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return V - V_proj


def load_best_k_map(csv_path: str) -> dict[str, int]:
    best_k: dict[str, int] = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            best_k[row["class_name"]] = int(row["best_k"])
    return best_k


def collect_test_records(backbone, class_name: str, target_layer: int, args: argparse.Namespace, device: str) -> list[dict]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    side_h, side_w = backbone.grid_size
    records: list[dict] = []
    for idx, rec in enumerate(ds.records):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens = backbone.extract_layer_patch_tokens(image_t, target_layers=[target_layer])[target_layer][0]
        records.append(
            {
                "name": name,
                "img_type": img_type,
                "label": int(label != 0),
                "patch_tokens": F.normalize(tokens.float(), dim=-1).cpu(),
                "patch_mask": to_mask_tokens(mask_np, side_h, side_w, device),
            }
        )
    return records


def extract_fit_subspace(
    records: list[dict],
    fit_indices: list[int],
    p_norm: torch.Tensor,
    k: int,
    max_fit_anom_patches: int,
) -> torch.Tensor:
    chunks: list[torch.Tensor] = []
    for idx in fit_indices:
        rec = records[idx]
        mask = rec["patch_mask"] > 0
        if int(mask.sum()) == 0:
            continue
        residual = get_null_space_residual(rec["patch_tokens"][mask], p_norm)
        chunks.append(residual)
    if not chunks:
        raise RuntimeError("No anomaly patches available in fit split.")

    residual = torch.cat(chunks, dim=0)
    if max_fit_anom_patches > 0 and residual.shape[0] > max_fit_anom_patches:
        sel = torch.linspace(0, residual.shape[0] - 1, steps=max_fit_anom_patches).round().long()
        residual = residual[sel]
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:k].T.contiguous()


def evaluate_axes(
    records: list[dict],
    eval_indices: list[int],
    p_norm: torch.Tensor,
    raw_axis: torch.Tensor,
    proj_axis: torch.Tensor,
    topk_ratio: float,
) -> dict[str, float]:
    patch_labels: list[int] = []
    raw_patch_scores: list[float] = []
    proj_patch_scores: list[float] = []
    image_labels: list[int] = []
    raw_image_scores: list[float] = []
    proj_image_scores: list[float] = []

    for idx in eval_indices:
        rec = records[idx]
        residual = get_null_space_residual(rec["patch_tokens"], p_norm)
        raw_score = (residual @ raw_axis).cpu().numpy()
        proj_score = (residual @ proj_axis).cpu().numpy()
        patch_mask = rec["patch_mask"].astype(np.int64)

        patch_labels.extend(patch_mask.tolist())
        raw_patch_scores.extend(raw_score.tolist())
        proj_patch_scores.extend(proj_score.tolist())

        image_labels.append(int(rec["label"]))
        raw_image_scores.append(topk_mean(raw_score, topk_ratio))
        proj_image_scores.append(topk_mean(proj_score, topk_ratio))

    return {
        "raw_patch_auc": safe_auc(patch_labels, raw_patch_scores),
        "proj_patch_auc": safe_auc(patch_labels, proj_patch_scores),
        "raw_image_auc": safe_auc(image_labels, raw_image_scores),
        "proj_image_auc": safe_auc(image_labels, proj_image_scores),
    }


def run_class(
    backbone,
    class_name: str,
    target_layer: int,
    k: int,
    args: argparse.Namespace,
    device: str,
) -> tuple[list[dict], dict[str, float]]:
    records = collect_test_records(backbone, class_name, target_layer, args, device)
    p_norm = build_text_anchor(backbone, class_name, abnormal=False)
    p_anom = build_text_anchor(backbone, class_name, abnormal=True)
    raw_axis = F.normalize(p_anom - p_norm, dim=0)

    anomaly_indices = [i for i, rec in enumerate(records) if rec["label"] == 1]
    normal_indices = [i for i, rec in enumerate(records) if rec["label"] == 0]
    if len(anomaly_indices) < 2:
        raise RuntimeError(f"class={class_name} has too few anomaly images for split evaluation")

    split_rows: list[dict] = []
    for split_id in range(args.num_splits):
        rng = np.random.default_rng(split_id)
        perm = rng.permutation(anomaly_indices).tolist()
        fit_count = max(1, int(round(len(perm) * args.fit_fraction)))
        fit_count = min(fit_count, len(perm) - 1)
        fit_indices = perm[:fit_count]
        eval_indices = normal_indices + perm[fit_count:]

        basis = extract_fit_subspace(records, fit_indices, p_norm, k, args.max_fit_anom_patches)
        P = basis @ basis.T
        projected = P @ raw_axis
        projected_norm = float(torch.linalg.vector_norm(projected).item())
        if projected_norm <= 1e-8:
            continue
        proj_axis = projected / projected_norm

        metrics = evaluate_axes(records, eval_indices, p_norm, raw_axis, proj_axis, args.topk_ratio)
        split_rows.append(
            {
                "class_name": class_name,
                "target_layer": target_layer,
                "k": k,
                "split_id": split_id,
                "fit_anom_images": len(fit_indices),
                "eval_anom_images": len(perm[fit_count:]),
                "eval_normal_images": len(normal_indices),
                "projection_norm": projected_norm,
                "patch_auc_delta": metrics["proj_patch_auc"] - metrics["raw_patch_auc"],
                "image_auc_delta": metrics["proj_image_auc"] - metrics["raw_image_auc"],
                **metrics,
            }
        )

    if not split_rows:
        raise RuntimeError(f"class={class_name} produced no valid splits")

    def mean_of(key: str) -> float:
        return float(np.mean([row[key] for row in split_rows]))

    def std_of(key: str) -> float:
        return float(np.std([row[key] for row in split_rows]))

    summary = {
        "class_name": class_name,
        "target_layer": target_layer,
        "k": k,
        "num_splits": len(split_rows),
        "projection_norm_mean": mean_of("projection_norm"),
        "projection_norm_std": std_of("projection_norm"),
        "raw_patch_auc_mean": mean_of("raw_patch_auc"),
        "raw_patch_auc_std": std_of("raw_patch_auc"),
        "proj_patch_auc_mean": mean_of("proj_patch_auc"),
        "proj_patch_auc_std": std_of("proj_patch_auc"),
        "patch_auc_delta_mean": mean_of("patch_auc_delta"),
        "patch_auc_delta_std": std_of("patch_auc_delta"),
        "raw_image_auc_mean": mean_of("raw_image_auc"),
        "raw_image_auc_std": std_of("raw_image_auc"),
        "proj_image_auc_mean": mean_of("proj_image_auc"),
        "proj_image_auc_std": std_of("proj_image_auc"),
        "image_auc_delta_mean": mean_of("image_auc_delta"),
        "image_auc_delta_std": std_of("image_auc_delta"),
    }
    return split_rows, summary


def save_plots(detail_rows: list[dict], out_dir: Path, tag: str) -> None:
    classes = sorted({row["class_name"] for row in detail_rows})
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    width = 0.35
    x = np.arange(len(classes))

    raw_patch = []
    proj_patch = []
    raw_image = []
    proj_image = []
    for cls in classes:
        cls_rows = [row for row in detail_rows if row["class_name"] == cls]
        raw_patch.append(np.mean([row["raw_patch_auc"] for row in cls_rows]))
        proj_patch.append(np.mean([row["proj_patch_auc"] for row in cls_rows]))
        raw_image.append(np.mean([row["raw_image_auc"] for row in cls_rows]))
        proj_image.append(np.mean([row["proj_image_auc"] for row in cls_rows]))

    axes[0].bar(x - width / 2, raw_patch, width, label="raw Δp")
    axes[0].bar(x + width / 2, proj_patch, width, label="PΔp")
    axes[0].set_title("Patch AUC")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(classes)
    axes[0].set_ylim(0.0, 1.0)
    axes[0].grid(True, axis="y", alpha=0.3)
    axes[0].legend()

    axes[1].bar(x - width / 2, raw_image, width, label="raw Δp")
    axes[1].bar(x + width / 2, proj_image, width, label="PΔp")
    axes[1].set_title("Image AUC (top-k)")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(classes)
    axes[1].set_ylim(0.0, 1.0)
    axes[1].grid(True, axis="y", alpha=0.3)
    axes[1].legend()

    fig.tight_layout()
    fig.savefig(out_dir / f"{tag}_auc_comparison.png", dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(len(classes), 1, figsize=(7, 3.2 * len(classes)), sharex=True)
    if len(classes) == 1:
        axes = [axes]
    for ax, cls in zip(axes, classes):
        cls_rows = sorted([row for row in detail_rows if row["class_name"] == cls], key=lambda x: x["split_id"])
        xs = [row["split_id"] for row in cls_rows]
        patch_delta = [row["patch_auc_delta"] for row in cls_rows]
        image_delta = [row["image_auc_delta"] for row in cls_rows]
        ax.plot(xs, patch_delta, marker="o", label="patch ΔAUC")
        ax.plot(xs, image_delta, marker="s", label="image ΔAUC")
        ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.5)
        ax.set_title(cls)
        ax.grid(True, alpha=0.3)
        ax.legend()
    axes[-1].set_xlabel("split_id")
    fig.tight_layout()
    fig.savefig(out_dir / f"{tag}_delta_by_split.png", dpi=180)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    best_k_map = load_best_k_map(args.k_source_csv)
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    detail_rows: list[dict] = []
    summary_rows: list[dict] = []
    for class_name in args.class_names:
        k = int(best_k_map[class_name])
        split_rows, summary = run_class(backbone, class_name, args.target_layer, k, args, device)
        detail_rows.extend(split_rows)
        summary_rows.append(summary)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    stem = f"{args.output_tag}_{class_tag}_L{args.target_layer}"
    summary_path = out_dir / f"{stem}_summary.csv"
    detail_path = out_dir / f"{stem}_detail.csv"
    json_path = out_dir / f"{stem}_summary.json"

    with summary_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    with detail_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(detail_rows[0].keys()))
        writer.writeheader()
        writer.writerows(detail_rows)
    with json_path.open("w") as f:
        json.dump({"summary_rows": summary_rows, "detail_rows": detail_rows, "config": vars(args)}, f, indent=2)

    save_plots(detail_rows, out_dir, stem)
    print(summary_path)
    print(detail_path)
    print(json_path)
    print(json.dumps(summary_rows, indent=2))


if __name__ == "__main__":
    main()
