#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

PY="/mnt/data/envs/patchcore-conda/bin/python"
DEVICE="${DEVICE:-cuda:0}"

run_official_vitl336() {
  local preset="$1"
  local save_dir="$2"
  if [[ -f "${save_dir}/summary.json" ]]; then
    echo "skip existing ${save_dir}"
    return 0
  fi

  echo "start AA-CLIP official ViT-L-14-336 ${preset}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip.py \
    --preset "${preset}" \
    --model_name ViT-L-14-336 \
    --pretrained openai \
    --adapter_load_mode strict \
    --levels 6,12,18,24 \
    --img_size 518 \
    --batch_size 4 \
    --num_workers 4 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas=-0.5,-0.2,-0.1,-0.05,-0.02,-0.01,0.005,0.01,0.02,0.05,0.1,0.2,0.5 \
    --blend_modes prescore_rectify \
    --candidate_topk_frac 0.10 \
    --gate_sharpness 3.0 \
    --candidate_image_mode map_topk \
    --cal_pro \
    --aupro_max_step 50 \
    --device "${DEVICE}" \
    --save_dir "${save_dir}"
  echo "done AA-CLIP official ViT-L-14-336 ${preset}"
}

run_official_vitl336 visa2mvtec neurips2026/results/aaclip_official_vitl336_img518_visa2mvtec_alpha_sweep_map_topk_pro_20260427
run_official_vitl336 mvtec2visa neurips2026/results/aaclip_official_vitl336_img518_mvtec2visa_alpha_sweep_map_topk_pro_20260427
run_official_vitl336 visa2mpdd neurips2026/results/aaclip_official_vitl336_img518_visa2mpdd_alpha_sweep_map_topk_pro_20260427
run_official_vitl336 visa2btad neurips2026/results/aaclip_official_vitl336_img518_visa2btad_alpha_sweep_map_topk_pro_20260427

echo "AA-CLIP official ViT-L-14-336 alpha sweep queue finished"
