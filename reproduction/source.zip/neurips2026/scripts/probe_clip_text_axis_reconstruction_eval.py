from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
    build_text_workspace,
    encode_text_features,
    evaluate_reconstructed_axis,
    reconstruct_optimal_text_axis,
)
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["capsules", "candle"])
    parser.add_argument(
        "--class_summary_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "clip_kin_split_allvisa_analysis" / "class_best_summary.csv"),
    )
    parser.add_argument("--target_layer", type=int, default=12)
    parser.add_argument("--num_splits", type=int, default=20)
    parser.add_argument("--fit_fraction", type=float, default=0.5)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--max_fit_anomaly_patches", type=int, default=4096)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_text_axis_reconstruction_eval")
    return parser.parse_args()


def l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-8) -> torch.Tensor:
    return F.normalize(x.float(), dim=dim, eps=eps)


def safe_auc(labels: list[int], scores: list[float]) -> float:
    if not labels or len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(np.asarray(labels, dtype=np.int64), np.asarray(scores, dtype=np.float64)))


def topk_mean(vals: np.ndarray, ratio: float) -> float:
    if vals.size == 0:
        return float("nan")
    k = max(1, int(round(vals.size * ratio)))
    idx = np.argpartition(vals, -k)[-k:]
    return float(vals[idx].mean())


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def load_class_settings(csv_path: str) -> dict[str, dict[str, int | str]]:
    settings: dict[str, dict[str, int | str]] = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            settings[row["class_name"]] = {
                "best_layer": int(row["best_layer"]),
                "best_k": int(row["best_k"]),
                "group": row["group"],
            }
    return settings


def build_token_text_anchors(backbone, class_name: str) -> tuple[torch.Tensor, list[str]]:
    normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
    p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt])[0]
    return p_norm.cpu(), abnormal_prompts


def get_null_space_residual(V: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = l2_normalize(p_norm, dim=0)
    V = l2_normalize(V, dim=-1)
    V_proj = (V @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return V - V_proj


def collect_test_tokens(backbone, class_name: str, target_layer: int, args: argparse.Namespace, device: str) -> list[dict]:
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    side_h, side_w = backbone.grid_size
    records: list[dict] = []
    for idx, rec in enumerate(ds.records):
        image_np, mask_np, label, name, img_type = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens = backbone.extract_layer_patch_tokens(image_t, target_layers=[target_layer])[target_layer][0]
        records.append(
            {
                "index": idx,
                "name": name,
                "img_type": img_type,
                "label": int(label != 0),
                "patch_tokens": l2_normalize(tokens.float(), dim=-1).cpu(),
                "patch_mask": to_patch_mask(mask_np, (side_h, side_w), device),
            }
        )
    return records


def extract_visual_subspace(
    records: list[dict],
    fit_indices: list[int],
    p_norm: torch.Tensor,
    k: int,
    max_fit_anomaly_patches: int,
) -> torch.Tensor:
    chunks: list[torch.Tensor] = []
    for idx in fit_indices:
        rec = records[idx]
        pos = rec["patch_mask"] > 0
        if int(pos.sum()) == 0:
            continue
        chunks.append(rec["patch_tokens"][pos])
    if not chunks:
        raise RuntimeError("No anomaly patches available in fit split.")
    patches = torch.cat(chunks, dim=0)
    if max_fit_anomaly_patches > 0 and patches.shape[0] > max_fit_anomaly_patches:
        sel = torch.linspace(0, patches.shape[0] - 1, steps=max_fit_anomaly_patches).round().long()
        patches = patches[sel]
    residual = get_null_space_residual(patches, p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:k].T.contiguous()


def score_records(
    eval_records: list[dict],
    p_norm: torch.Tensor,
    axis: torch.Tensor,
    topk_ratio: float,
) -> tuple[float, float]:
    patch_labels: list[int] = []
    patch_scores: list[float] = []
    image_labels: list[int] = []
    image_scores: list[float] = []
    for rec in eval_records:
        scores = evaluate_reconstructed_axis(rec["patch_tokens"], p_norm, axis).cpu().numpy()
        patch_labels.extend(rec["patch_mask"].astype(np.int64).tolist())
        patch_scores.extend(scores.tolist())
        image_labels.append(int(rec["label"]))
        image_scores.append(topk_mean(scores, topk_ratio))
    return safe_auc(patch_labels, patch_scores), safe_auc(image_labels, image_scores)


def save_plots(summary_rows: list[dict], out_dir: Path, stem: str) -> None:
    classes = [row["class_name"] for row in summary_rows]
    x = np.arange(len(classes))
    width = 0.35

    raw_patch = [float(row["raw_patch_auc_mean"]) for row in summary_rows]
    recon_patch = [float(row["recon_patch_auc_mean"]) for row in summary_rows]
    raw_image = [float(row["raw_image_auc_mean"]) for row in summary_rows]
    recon_image = [float(row["recon_image_auc_mean"]) for row in summary_rows]

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    axes[0].bar(x - width / 2, raw_patch, width, label="raw Δp")
    axes[0].bar(x + width / 2, recon_patch, width, label="reconstructed")
    axes[0].set_title("Patch AUC")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(classes)
    axes[0].set_ylim(0.0, 1.0)
    axes[0].grid(True, axis="y", alpha=0.3)
    axes[0].legend()

    axes[1].bar(x - width / 2, raw_image, width, label="raw Δp")
    axes[1].bar(x + width / 2, recon_image, width, label="reconstructed")
    axes[1].set_title("Image AUC")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(classes)
    axes[1].set_ylim(0.0, 1.0)
    axes[1].grid(True, axis="y", alpha=0.3)
    axes[1].legend()

    fig.tight_layout()
    fig.savefig(out_dir / f"{stem}_auc_compare.png", dpi=180)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    class_settings = load_class_settings(args.class_summary_csv)
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    summary_rows: list[dict] = []
    detail_rows: list[dict] = []

    for class_name in args.class_names:
        setting = class_settings[class_name]
        k = int(setting["best_k"])
        group = str(setting["group"])

        p_norm, abnormal_prompts = build_token_text_anchors(backbone, class_name)
        p_anom_raw = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts)
        delta_p_raw = l2_normalize(p_anom_raw.mean(dim=0) - p_norm.to(p_anom_raw.device), dim=0).cpu()
        records = collect_test_tokens(backbone, class_name, args.target_layer, args, device)
        anomaly_indices = [i for i, rec in enumerate(records) if rec["label"] == 1]
        normal_indices = [i for i, rec in enumerate(records) if rec["label"] == 0]
        if len(anomaly_indices) < 2:
            raise RuntimeError(f"class={class_name} needs at least two anomaly images")

        class_split_rows: list[dict] = []
        sigma1_vals: list[float] = []
        proj_norm_vals: list[float] = []
        cos_raw_recon_vals: list[float] = []

        for split_id in range(args.num_splits):
            rng = np.random.default_rng(split_id)
            perm = rng.permutation(anomaly_indices).tolist()
            fit_count = max(1, int(round(len(perm) * args.fit_fraction)))
            fit_count = min(fit_count, len(perm) - 1)
            fit_indices = perm[:fit_count]
            eval_indices = normal_indices + perm[fit_count:]
            eval_records = [records[idx] for idx in eval_indices]

            V_anom = extract_visual_subspace(records, fit_indices, p_norm, k, args.max_fit_anomaly_patches)
            U_text, _ = build_text_workspace(backbone, backbone.tokenizer, abnormal_prompts, p_norm.to(device))
            delta_p_recon, M, S = reconstruct_optimal_text_axis(U_text, V_anom.to(device))
            delta_p_recon = delta_p_recon.cpu()
            sigma1 = float(S[0].item()) if S.numel() else float("nan")
            proj_norm = float(torch.linalg.vector_norm((V_anom @ V_anom.T) @ delta_p_raw).item())
            cos_raw_recon = float(F.cosine_similarity(delta_p_raw.unsqueeze(0), delta_p_recon.unsqueeze(0)).item())

            raw_patch_auc, raw_image_auc = score_records(eval_records, p_norm, delta_p_raw, args.topk_ratio)
            recon_patch_auc, recon_image_auc = score_records(eval_records, p_norm, delta_p_recon, args.topk_ratio)

            row = {
                "class_name": class_name,
                "group": group,
                "target_layer": args.target_layer,
                "k": k,
                "split_id": split_id,
                "sigma1": sigma1,
                "projection_norm_raw": proj_norm,
                "cos_raw_recon": cos_raw_recon,
                "raw_patch_auc": raw_patch_auc,
                "recon_patch_auc": recon_patch_auc,
                "patch_auc_delta": recon_patch_auc - raw_patch_auc,
                "raw_image_auc": raw_image_auc,
                "recon_image_auc": recon_image_auc,
                "image_auc_delta": recon_image_auc - raw_image_auc,
            }
            class_split_rows.append(row)
            detail_rows.append(row)
            sigma1_vals.append(sigma1)
            proj_norm_vals.append(proj_norm)
            cos_raw_recon_vals.append(cos_raw_recon)

        def mean_of(key: str) -> float:
            return float(np.mean([row[key] for row in class_split_rows]))

        def std_of(key: str) -> float:
            return float(np.std([row[key] for row in class_split_rows]))

        summary_rows.append(
            {
                "class_name": class_name,
                "group": group,
                "target_layer": args.target_layer,
                "k": k,
                "num_splits": len(class_split_rows),
                "sigma1_mean": mean_of("sigma1"),
                "sigma1_std": std_of("sigma1"),
                "projection_norm_raw_mean": mean_of("projection_norm_raw"),
                "projection_norm_raw_std": std_of("projection_norm_raw"),
                "cos_raw_recon_mean": mean_of("cos_raw_recon"),
                "cos_raw_recon_std": std_of("cos_raw_recon"),
                "raw_patch_auc_mean": mean_of("raw_patch_auc"),
                "raw_patch_auc_std": std_of("raw_patch_auc"),
                "recon_patch_auc_mean": mean_of("recon_patch_auc"),
                "recon_patch_auc_std": std_of("recon_patch_auc"),
                "patch_auc_delta_mean": mean_of("patch_auc_delta"),
                "patch_auc_delta_std": std_of("patch_auc_delta"),
                "raw_image_auc_mean": mean_of("raw_image_auc"),
                "raw_image_auc_std": std_of("raw_image_auc"),
                "recon_image_auc_mean": mean_of("recon_image_auc"),
                "recon_image_auc_std": std_of("recon_image_auc"),
                "image_auc_delta_mean": mean_of("image_auc_delta"),
                "image_auc_delta_std": std_of("image_auc_delta"),
            }
        )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    stem = f"{args.output_tag}_{class_tag}_L{args.target_layer}"
    summary_path = out_dir / f"{stem}_summary.csv"
    detail_path = out_dir / f"{stem}_detail.csv"
    json_path = out_dir / f"{stem}_summary.json"

    with summary_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    with detail_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(detail_rows[0].keys()))
        writer.writeheader()
        writer.writerows(detail_rows)
    with json_path.open("w") as f:
        json.dump({"summary_rows": summary_rows, "detail_rows": detail_rows, "config": vars(args)}, f, indent=2)

    save_plots(summary_rows, out_dir, stem)
    print(summary_path)
    print(detail_path)
    print(json_path)
    print(json.dumps(summary_rows, indent=2))


if __name__ == "__main__":
    main()
