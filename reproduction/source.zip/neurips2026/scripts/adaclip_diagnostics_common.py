from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
import torch.nn.functional as F

from neurips2026.scripts.official_parallel_test_adaclip import (
    build_model,
    build_target_dataset,
    compute_baseline_outputs,
    get_or_collect_source_patch_banks,
    layer_map_to_scalar_map,
    logmeanexp_negative_sqdist_1d,
    refine_layer_logits,
    resolve_layer_recipe,
    smooth_map,
)


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")

PRESET_CONFIGS = {
    "visa2mvtec": {
        "source_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "source_dataset": "visa",
        "target_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "target_dataset": "mvtec",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_visa_clean_multilayer.pt"),
    },
    "mvtec2btad": {
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "source_dataset": "mvtec",
        "target_root": str(ROOT / "neurips2026" / "data" / "BTAD_official"),
        "target_dataset": "btad",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"),
    },
    "mvtec2mpdd": {
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "source_dataset": "mvtec",
        "target_root": "/mnt/data/MPDD",
        "target_dataset": "mpdd",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"),
    },
    "mvtec2visa": {
        "source_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "source_dataset": "mvtec",
        "target_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "target_dataset": "visa",
        "checkpoint_path": str(ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth"),
        "bank_cache_path": str(ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_clean_multilayer.pt"),
    },
}

OOD_NORMAL_CONFIGS = {
    "mvtec": {
        "target_root": "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec",
        "target_dataset": "mvtec",
    },
    "visa": {
        "target_root": str(ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls"),
        "target_dataset": "visa",
    },
    "btad": {
        "target_root": str(ROOT / "neurips2026" / "data" / "BTAD_official"),
        "target_dataset": "btad",
    },
    "mpdd": {
        "target_root": "/mnt/data/MPDD",
        "target_dataset": "mpdd",
    },
}


@dataclass
class AdaCLIPDiagConfig:
    preset: str
    layer_recipe: str = "all4"
    image_size: int = 518
    sigma: float = 4.0
    prompting_depth: int = 4
    prompting_length: int = 5
    prompting_branch: str = "VL"
    prompting_type: str = "SD"
    use_hsf: bool = True
    k_clusters: int = 20
    hard_frac: float = 0.01
    max_good_per_class: int = 200
    max_defect_per_class: int = 80
    max_bank_per_layer: int = 512
    max_fp_per_image: int = 64
    max_defect_per_image: int = 64
    tau: float = 20.0
    fp_weight: float = 0.3
    scoring_mode: str = "logit_gate_posneg"
    refine_alpha: float = 0.3
    refine_beta: float = 0.15
    margin_norm_mode: str = "spatial_tanh_zscore"
    num_workers: int = 2
    cpu_threads: int = 1
    device: str = "cuda:0"
    class_name: str | None = None
    skip_checkpoint_load: bool = False
    seed: int = 0
    bank_cache_path: str | None = None


def set_seed(seed: int) -> None:
    torch.manual_seed(int(seed))
    np.random.seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))


def _preset_fields(preset: str) -> dict:
    if preset not in PRESET_CONFIGS:
        raise ValueError(f"Unknown preset: {preset}")
    return PRESET_CONFIGS[preset]


def load_model_and_banks(cfg: AdaCLIPDiagConfig):
    set_seed(cfg.seed)
    preset = _preset_fields(cfg.preset)
    model = build_model(
        device=cfg.device,
        checkpoint_path=preset["checkpoint_path"],
        skip_checkpoint_load=cfg.skip_checkpoint_load,
        image_size=cfg.image_size,
        prompting_depth=cfg.prompting_depth,
        prompting_length=cfg.prompting_length,
        prompting_branch=cfg.prompting_branch,
        prompting_type=cfg.prompting_type,
        use_hsf=cfg.use_hsf,
        k_clusters=cfg.k_clusters,
    )
    features_list = list(model.clip_model.output_layers)
    selected_layer_indices = resolve_layer_recipe(features_list, cfg.layer_recipe)
    selected_layers = [features_list[i] for i in selected_layer_indices]
    bank_cache_path = cfg.bank_cache_path if cfg.bank_cache_path is not None else preset["bank_cache_path"]
    if cfg.skip_checkpoint_load:
        bank_cache_path = None
    fp_banks, def_banks, bank_stats, used_bank_cache_path, bank_cache_meta = get_or_collect_source_patch_banks(
        model=model,
        skip_checkpoint_load=cfg.skip_checkpoint_load,
        seed=cfg.seed,
        source_root=preset["source_root"],
        source_dataset=preset["source_dataset"],
        image_size=cfg.image_size,
        features_list=features_list,
        device=cfg.device,
        source_exclude_class=None,
        hard_frac=cfg.hard_frac,
        max_good_per_class=cfg.max_good_per_class,
        max_defect_per_class=cfg.max_defect_per_class,
        max_bank_per_layer=cfg.max_bank_per_layer,
        max_fp_per_image=cfg.max_fp_per_image,
        max_defect_per_image=cfg.max_defect_per_image,
        sigma=cfg.sigma,
        checkpoint_path=preset["checkpoint_path"],
        bank_cache_path=bank_cache_path,
        refresh_bank_cache=False,
    )
    fp_banks_gpu = {layer_idx: bank.to(cfg.device) for layer_idx, bank in fp_banks.items()}
    def_banks_gpu = {layer_idx: bank.to(cfg.device) for layer_idx, bank in def_banks.items()}
    meta = {
        "preset": cfg.preset,
        "layer_recipe": cfg.layer_recipe,
        "features_list": features_list,
        "selected_layer_indices": selected_layer_indices,
        "selected_layers": selected_layers,
        "bank_stats": bank_stats,
        "bank_cache_path": str(used_bank_cache_path),
        "bank_cache_meta": bank_cache_meta,
    }
    return model, fp_banks_gpu, def_banks_gpu, meta


def build_loader(cfg: AdaCLIPDiagConfig, target_root: str, target_dataset: str, model):
    dataset = build_target_dataset(
        root=target_root,
        dataset_name=target_dataset,
        model=model,
        training=False,
        class_name=cfg.class_name,
    )
    loader_kwargs = {
        "batch_size": 1,
        "shuffle": False,
        "num_workers": cfg.num_workers,
    }
    if cfg.num_workers > 0:
        loader_kwargs["pin_memory"] = cfg.device.startswith("cuda")
        loader_kwargs["persistent_workers"] = True
        loader_kwargs["prefetch_factor"] = 2
    loader = torch.utils.data.DataLoader(dataset, **loader_kwargs)
    return dataset, loader


def compute_mode_outputs(
    model,
    fp_banks_gpu: dict[int, torch.Tensor],
    def_banks_gpu: dict[int, torch.Tensor],
    selected_layer_indices: list[int],
    image: torch.Tensor,
    cls_name: str,
    sigma: float,
    tau: float,
    fp_weight: float,
    scoring_mode: str,
    refine_alpha: float,
    refine_beta: float,
    margin_norm_mode: str,
    image_size: int,
):
    baseline = compute_baseline_outputs(
        model,
        image,
        cls_name,
        sigma,
        selected_layer_indices=selected_layer_indices,
    )
    axis = baseline["axis"]

    patch_baseline_scores = []
    patch_parallel_scores = []
    qdef_layers = []
    qfp_layers = []
    parallel_layer_maps = []
    refined_layer_logits = []

    text_features = baseline["text_features"]
    if text_features.ndim == 3:
        text_features_2 = text_features[0]
    else:
        text_features_2 = text_features

    for local_idx, patch_feature in enumerate(baseline["patch_tokens"]):
        layer_idx = baseline["selected_layer_indices"][local_idx]
        patch = patch_feature[0]
        fp_bank = fp_banks_gpu[layer_idx]
        def_bank = def_banks_gpu[layer_idx]
        fp_coeff = fp_bank @ axis if fp_bank.numel() else torch.empty((0,), device=image.device)
        def_coeff = def_bank @ axis if def_bank.numel() else torch.empty((0,), device=image.device)
        coeff = patch @ axis
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=tau)
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=tau)
        qfp_layers.append(q_fp)
        qdef_layers.append(q_def)

        h = int(round(patch.shape[0] ** 0.5))
        parallel_map = (q_def - fp_weight * q_fp).reshape(1, 1, h, h)
        parallel_map = F.interpolate(
            parallel_map,
            size=(image_size, image_size),
            mode="bilinear",
            align_corners=True,
        )
        parallel_layer_maps.append(parallel_map)

        logits_small = 100.0 * (patch @ text_features_2)
        probs_small = torch.softmax(logits_small, dim=-1)
        patch_baseline_scores.append(probs_small[:, 1])
        patch_parallel_scores.append(q_def - fp_weight * q_fp)

        if scoring_mode != "replace":
            refined_layer_logits.append(
                refine_layer_logits(
                    layer_logits=baseline["layer_logits"][local_idx],
                    margin_map=parallel_map,
                    scoring_mode=scoring_mode,
                    refine_alpha=refine_alpha,
                    refine_beta=refine_beta,
                    margin_norm_mode=margin_norm_mode,
                )
            )

    if scoring_mode == "replace":
        parallel_map = torch.stack(parallel_layer_maps, dim=0).mean(dim=0)[:, 0]
    else:
        aggregated_refined_logits = torch.stack(refined_layer_logits, dim=0).mean(dim=0)
        aggregated_refined_probs = torch.softmax(aggregated_refined_logits, dim=1)
        parallel_map = layer_map_to_scalar_map(aggregated_refined_probs)[:, 0]
    parallel_map = smooth_map(parallel_map, sigma=sigma).to(image.device)
    parallel_img_score = baseline["baseline_img_score"]

    baseline_patch_score = torch.stack(patch_baseline_scores, dim=0).mean(dim=0)
    parallel_patch_score = torch.stack(patch_parallel_scores, dim=0).mean(dim=0)
    provenance_margin = torch.stack(qdef_layers, dim=0).mean(dim=0) - torch.stack(qfp_layers, dim=0).mean(dim=0)

    return {
        "baseline_map": baseline["baseline_map"],
        "parallel_map": parallel_map,
        "baseline_img_score": baseline["baseline_img_score"],
        "parallel_img_score": parallel_img_score,
        "baseline_patch_score": baseline_patch_score,
        "parallel_patch_score": parallel_patch_score,
        "provenance_margin": provenance_margin,
    }


def iter_loader(loader) -> Iterable[dict]:
    for items in loader:
        yield items


def map_topk_values(map_tensor: torch.Tensor, frac: float) -> torch.Tensor:
    flat = map_tensor.flatten()
    k = max(1, int(round(flat.numel() * frac)))
    return torch.topk(flat, k=k, largest=True).values


def activation_area(map_tensor: torch.Tensor, threshold: float) -> float:
    return float((map_tensor > threshold).float().mean().item())


def save_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2))
