from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["fryum", "capsules"])
    parser.add_argument(
        "--class_summary_csv",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "clip_kin_split_allvisa_analysis" / "class_best_summary.csv"),
    )
    parser.add_argument("--inject_layer", type=int, default=1)
    parser.add_argument("--track_layers", nargs="+", type=int, default=[1, 6, 9, 12])
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--subspace_k", type=int, default=0)
    parser.add_argument("--max_fit_anomaly_images", type=int, default=20)
    parser.add_argument("--max_eval_normal_images", type=int, default=10)
    parser.add_argument("--max_anomaly_patches", type=int, default=4096)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_layerwise_manifold_fidelity")
    return parser.parse_args()


def build_token_normal_anchor(backbone, class_name: str) -> torch.Tensor:
    prompts: list[str] = []
    class_text = class_name.replace("_", " ")
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            prompts.append(template.format(normal_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = backbone.visual.proj.detach().float().to(text_anchor.device)
    token_anchor = proj @ text_anchor
    return F.normalize(token_anchor, dim=0)


def load_best_k_map(csv_path: str) -> dict[str, int]:
    out: dict[str, int] = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            out[row["class_name"]] = int(row["best_k"])
    return out


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> torch.Tensor:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .to(dtype=torch.bool)
    )


def maybe_subsample(tokens: torch.Tensor, max_count: int) -> torch.Tensor:
    if max_count <= 0 or tokens.shape[0] <= max_count:
        return tokens
    idx = torch.linspace(0, tokens.shape[0] - 1, steps=max_count, device=tokens.device).round().long()
    return tokens[idx]


def get_null_space_residual(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    p_norm = F.normalize(p_norm.float(), dim=0)
    v_proj = (v @ p_norm).unsqueeze(-1) * p_norm.unsqueeze(0)
    return v.float() - v_proj


def forward_up_to_layer(model, image: torch.Tensor, layer_idx: int, return_sequence: bool = False):
    sequence = model.prepare_sequence(image)
    seq_mid = model.run_blocks(sequence, start_layer=1, end_layer=layer_idx)
    tokens_mid = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
    if return_sequence:
        return tokens_mid, seq_mid
    return tokens_mid


def run_remaining_with_capture(
    model,
    v_mid: torch.Tensor,
    cls_token: torch.Tensor,
    start_layer: int,
    target_layers: list[int],
) -> dict[int, torch.Tensor]:
    if not target_layers:
        return {}
    batch_seq = torch.cat([cls_token, v_mid], dim=1)
    sequence = batch_seq.permute(1, 0, 2)
    outputs: dict[int, torch.Tensor] = {}

    def capture(block_idx: int, x: torch.Tensor) -> torch.Tensor:
        if block_idx in target_layers:
            outputs[block_idx] = x.permute(1, 0, 2)[:, 1:, :].float()
        return x

    model.run_blocks(sequence, start_layer=start_layer, end_layer=max(target_layers), layer_callback=capture)
    return outputs


def inject_kinematic_signal(v_mid: torch.Tensor, p_norm: torch.Tensor, V_anom: torch.Tensor, alpha: float) -> torch.Tensor:
    r_mid = get_null_space_residual(v_mid, p_norm)
    delta_v = torch.matmul(torch.matmul(r_mid, V_anom), V_anom.T)
    return v_mid + float(alpha) * delta_v


def extract_anomaly_subspace(
    backbone,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    layer_idx: int,
    max_images: int,
    max_patches: int,
    subspace_k: int,
) -> torch.Tensor:
    ds = OfficialVisAWinClipDataset(dataset_root, split_csv, class_name, "test")
    anomaly_indices = [i for i, rec in enumerate(ds.records) if rec["label"] != "normal"][:max_images]
    collected: list[torch.Tensor] = []
    for idx in anomaly_indices:
        image_np, mask_np, label, _, _ = ds[idx]
        assert label == 1
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        tokens = forward_up_to_layer(backbone, image_t, layer_idx)
        patch_mask = to_patch_mask(mask_np, backbone.grid_size, backbone.device)
        if int(patch_mask.sum().item()) == 0:
            continue
        collected.append(tokens[0][patch_mask].detach())
    if not collected:
        raise RuntimeError(f"No anomaly patches collected for class={class_name}, layer={layer_idx}")
    patches = maybe_subsample(torch.cat(collected, dim=0), max_patches)
    residual = get_null_space_residual(patches, p_norm)
    residual = residual - residual.mean(dim=0, keepdim=True)
    _, _, vh = torch.linalg.svd(residual, full_matrices=False)
    return vh[:subspace_k].T.contiguous()


def safe_cosine(a: torch.Tensor, b: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    a_norm = torch.linalg.vector_norm(a, dim=-1)
    b_norm = torch.linalg.vector_norm(b, dim=-1)
    valid = (a_norm > eps) & (b_norm > eps)
    out = torch.full_like(a_norm, float("nan"))
    if valid.any():
        out[valid] = F.cosine_similarity(a[valid], b[valid], dim=-1)
    return out


def compute_layer_metrics(
    delta_init: torch.Tensor,
    delta_cur: torch.Tensor,
    p_norm: torch.Tensor,
    V_anom: torch.Tensor,
) -> dict[str, float]:
    delta_init_null = get_null_space_residual(delta_init, p_norm)
    delta_cur_null = get_null_space_residual(delta_cur, p_norm)

    init_total = torch.linalg.vector_norm(delta_init_null, dim=-1)
    cur_total = torch.linalg.vector_norm(delta_cur_null, dim=-1)
    init_sub = torch.linalg.vector_norm(delta_init_null @ V_anom, dim=-1)
    cur_sub = torch.linalg.vector_norm(delta_cur_null @ V_anom, dim=-1)

    proj_cur = torch.matmul(torch.matmul(delta_cur_null, V_anom), V_anom.T)
    cos_to_init = safe_cosine(delta_cur_null, delta_init_null)
    cos_to_subspace = safe_cosine(delta_cur_null, proj_cur)
    semantic_leak = torch.abs(delta_cur @ p_norm)

    init_total_mean = float(init_total.mean().item())
    init_sub_mean = float(init_sub.mean().item())
    cur_total_mean = float(cur_total.mean().item())
    cur_sub_mean = float(cur_sub.mean().item())

    cos_init_arr = cos_to_init[torch.isfinite(cos_to_init)]
    cos_sub_arr = cos_to_subspace[torch.isfinite(cos_to_subspace)]
    return {
        "total_energy_mean": cur_total_mean,
        "subspace_energy_mean": cur_sub_mean,
        "total_retention_ratio": cur_total_mean / max(init_total_mean, 1e-8),
        "subspace_retention_ratio": cur_sub_mean / max(init_sub_mean, 1e-8),
        "cos_to_init_mean": float(cos_init_arr.mean().item()) if cos_init_arr.numel() > 0 else float("nan"),
        "cos_to_subspace_mean": float(cos_sub_arr.mean().item()) if cos_sub_arr.numel() > 0 else float("nan"),
        "semantic_leak_mean": float(semantic_leak.mean().item()),
    }


def evaluate_class(
    backbone,
    dataset_root: str,
    split_csv: str,
    class_name: str,
    p_norm: torch.Tensor,
    V_anom: torch.Tensor,
    inject_layer: int,
    track_layers: list[int],
    alpha: float,
    max_eval_normal_images: int,
) -> list[dict[str, float | int | str]]:
    ds = OfficialVisAWinClipDataset(dataset_root, split_csv, class_name, "test")
    normal_indices = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"][:max_eval_normal_images]
    rows: list[dict[str, float | int | str]] = []

    metric_lists: dict[int, list[dict[str, float]]] = {layer: [] for layer in track_layers}

    for idx in normal_indices:
        image_np, _, label, name, _ = ds[idx]
        assert label == 0
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(backbone.device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            _, seq_mid = forward_up_to_layer(backbone, image_t, inject_layer, return_sequence=True)
            cls_token = seq_mid.permute(1, 0, 2)[:, :1, :].float()
            v_base_l1 = seq_mid.permute(1, 0, 2)[:, 1:, :].float()
            v_inj_l1 = inject_kinematic_signal(v_base_l1, p_norm, V_anom, alpha)

            future_layers = [layer for layer in track_layers if layer > inject_layer]
            base_caps = run_remaining_with_capture(backbone, v_base_l1, cls_token, inject_layer + 1, future_layers)
            inj_caps = run_remaining_with_capture(backbone, v_inj_l1, cls_token, inject_layer + 1, future_layers)

        base_by_layer = {inject_layer: v_base_l1[0].cpu()}
        inj_by_layer = {inject_layer: v_inj_l1[0].cpu()}
        for layer in future_layers:
            base_by_layer[layer] = base_caps[layer][0].cpu()
            inj_by_layer[layer] = inj_caps[layer][0].cpu()

        delta_init = inj_by_layer[inject_layer] - base_by_layer[inject_layer]
        for layer in track_layers:
            delta_cur = inj_by_layer[layer] - base_by_layer[layer]
            metrics = compute_layer_metrics(delta_init, delta_cur, p_norm.cpu(), V_anom.cpu())
            metric_lists[layer].append(metrics)

    for layer in track_layers:
        row: dict[str, float | int | str] = {
            "class_name": class_name,
            "inject_layer": inject_layer,
            "track_layer": layer,
            "alpha": float(alpha),
            "subspace_k": int(V_anom.shape[1]),
            "num_eval_normals": len(metric_lists[layer]),
        }
        keys = metric_lists[layer][0].keys()
        for key in keys:
            vals = np.asarray([m[key] for m in metric_lists[layer]], dtype=np.float64)
            row[f"{key}_mean"] = float(np.nanmean(vals))
            row[f"{key}_std"] = float(np.nanstd(vals))
        rows.append(row)
    return rows


def plot_metric_curves(rows: list[dict[str, float | int | str]], out_dir: Path, stem: str) -> None:
    layers = sorted({int(row["track_layer"]) for row in rows})
    class_names = sorted({str(row["class_name"]) for row in rows})
    metric_specs = [
        ("total_retention_ratio_mean", "Total Energy Retention"),
        ("subspace_retention_ratio_mean", "Original-Subspace Retention"),
        ("cos_to_init_mean_mean", "Direction Cosine To L1 Injection"),
        ("cos_to_subspace_mean_mean", "Subspace Alignment Cosine"),
        ("semantic_leak_mean_mean", "Semantic Leak"),
    ]
    for metric_key, title in metric_specs:
        plt.figure(figsize=(6.0, 4.0))
        for class_name in class_names:
            xs, ys = [], []
            for layer in layers:
                match = [
                    row for row in rows
                    if str(row["class_name"]) == class_name and int(row["track_layer"]) == layer
                ]
                if not match:
                    continue
                xs.append(layer)
                ys.append(float(match[0][metric_key]))
            plt.plot(xs, ys, marker="o", label=class_name)
        plt.xlabel("Tracked Layer")
        plt.ylabel(title)
        plt.title(title)
        plt.xticks(layers)
        plt.grid(alpha=0.25)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / f"{stem}_{metric_key}.png", dpi=200)
        plt.close()


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    track_layers = sorted(set(args.track_layers))
    if args.inject_layer not in track_layers:
        track_layers = [args.inject_layer] + track_layers
        track_layers = sorted(set(track_layers))

    best_k_map = load_best_k_map(args.class_summary_csv)
    rows: list[dict[str, float | int | str]] = []
    config_rows: list[dict[str, object]] = []

    for class_name in args.class_names:
        p_norm = build_token_normal_anchor(backbone, class_name).to(backbone.device)
        k = args.subspace_k if args.subspace_k > 0 else best_k_map[class_name]
        V_anom = extract_anomaly_subspace(
            backbone=backbone,
            dataset_root=args.dataset_root,
            split_csv=args.split_csv,
            class_name=class_name,
            p_norm=p_norm,
            layer_idx=args.inject_layer,
            max_images=args.max_fit_anomaly_images,
            max_patches=args.max_anomaly_patches,
            subspace_k=k,
        ).to(backbone.device)
        class_rows = evaluate_class(
            backbone=backbone,
            dataset_root=args.dataset_root,
            split_csv=args.split_csv,
            class_name=class_name,
            p_norm=p_norm,
            V_anom=V_anom,
            inject_layer=args.inject_layer,
            track_layers=track_layers,
            alpha=args.alpha,
            max_eval_normal_images=args.max_eval_normal_images,
        )
        rows.extend(class_rows)
        config_rows.append(
            {
                "class_name": class_name,
                "subspace_k": int(k),
                "p_norm_norm": float(torch.linalg.vector_norm(p_norm).item()),
                "V_anom_shape": list(V_anom.shape),
            }
        )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "-".join(args.class_names)
    stem = f"{args.output_tag}_{class_tag}_L{args.inject_layer}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(
            {
                "config": vars(args),
                "class_configs": config_rows,
                "rows": rows,
            },
            f,
            indent=2,
        )
    plot_metric_curves(rows, out_dir, stem)
    print(csv_path)
    print(json_path)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
