#!/usr/bin/env bash
set -euo pipefail

cd /mnt/data/pilab-kingjinyoung/ADPretrain-CLIP

PY="/mnt/data/envs/patchcore-conda/bin/python"
DEVICE="${DEVICE:-cuda:0}"

run_aaclip() {
  local preset="$1"
  local tag="$2"
  local model_name="$3"
  local pretrained="$4"
  local adapter_mode="$5"
  local levels="$6"
  local img_size="$7"
  local batch_size="$8"
  local save_dir="neurips2026/results/aaclip_mvtec_source_${tag}_${preset}_residual_grid_map_topk_pro_20260427"

  if [[ -f "${save_dir}/summary.json" ]]; then
    echo "[$(date '+%F %T')] skip existing ${save_dir}"
    return 0
  fi

  echo "[$(date '+%F %T')] start AA-CLIP ${tag} ${preset}"
  "${PY}" -u neurips2026/scripts/official_parallel_test_aaclip.py \
    --preset "${preset}" \
    --model_name "${model_name}" \
    --pretrained "${pretrained}" \
    --adapter_load_mode "${adapter_mode}" \
    --levels "${levels}" \
    --img_size "${img_size}" \
    --batch_size "${batch_size}" \
    --num_workers 4 \
    --max_fp_per_class 512 \
    --max_defect_per_class 512 \
    --normal_topk_frac 0.01 \
    --defect_topk_frac 0.25 \
    --tau 0.1 \
    --fp_weight 1.0 \
    --alphas=-0.5,-0.2,-0.1,-0.05,-0.02,0.02,0.05,0.1,0.2,0.5,1.0 \
    --blend_modes replace,residual,z_residual,z_hard_residual \
    --candidate_topk_frac 0.10 \
    --gate_sharpness 3.0 \
    --candidate_image_mode map_topk \
    --cal_pro \
    --aupro_max_step 50 \
    --device "${DEVICE}" \
    --save_dir "${save_dir}"
  echo "[$(date '+%F %T')] done AA-CLIP ${tag} ${preset}"
}

for preset in mvtec2mpdd mvtec2btad; do
  run_aaclip "${preset}" "vitbplus" "ViT-B-16-plus-240" "laion400m_e32" "project_crop" "6,12" "518" "16"
  run_aaclip "${preset}" "vith14" "ViT-H-14" "laion2b_s32b_b79k" "project_crop" "8,16,24,32" "224" "4"
  run_aaclip "${preset}" "vitl_openai" "ViT-L-14-336" "openai" "strict" "6,12,18,24" "224" "8"
done

echo "[$(date '+%F %T')] AA-CLIP MVTec-source BTAD/MPDD 3-backbone queue finished"
