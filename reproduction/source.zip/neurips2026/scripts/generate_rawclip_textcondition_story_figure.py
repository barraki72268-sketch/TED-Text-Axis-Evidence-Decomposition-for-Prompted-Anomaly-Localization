from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"
SOURCE_JSON = RESULTS / "rawclip_purevision_ablation_figure" / "rawclip_purevision_ablation.json"
SAVE_DIR = RESULTS / "rawclip_textcondition_story_figure"


STAGES = [
    ("raw_wrong_pair_rate", "raw_d", "Raw\nscore"),
    ("pure_visual_wrong_pair_rate", "pure_visual_d", "Pure\nvisual"),
    ("text_bank_visual_wrong_pair_rate", "text_bank_visual_d", "Text-cond.\nbank"),
    ("full_ours_wrong_pair_rate", "full_ours_d", "Full\nmethod"),
]

DISPLAY_STAGES = [
    ("raw_wrong_pair_rate", "raw_d", "Raw\nscore"),
    ("pure_visual_wrong_pair_rate", "pure_visual_d", "Pure\nvisual"),
    ("full_ours_wrong_pair_rate", "full_ours_d", "Full\nmethod"),
]

COLORS = {
    "ViT-B": "#4C78A8",
    "ViT-L": "#F58518",
    "ViT-L OpenAI": "#54A24B",
    "ViT-H": "#B279A2",
}


def load_rows() -> list[dict]:
    payload = json.loads(SOURCE_JSON.read_text())
    return payload["rows"]


def draw_stage_lines(ax, rows: list[dict], metric_keys: list[str], ylabel: str, ylim: tuple[float, float], invert: bool = False) -> None:
    x = np.arange(len(metric_keys))
    for row in rows:
        vals = [row[key] for key in metric_keys]
        ax.plot(
            x,
            vals,
            marker="o",
            ms=8.5,
            lw=2.8,
            color=COLORS[row["backbone"]],
            label=row["backbone"],
        )
        ax.scatter(x, vals, s=78, color=COLORS[row["backbone"]], edgecolor="white", linewidth=1.0, zorder=3)
        ax.set_xticks(x, [label for _, _, label in DISPLAY_STAGES], fontsize=11, fontweight="bold")
    ax.set_ylabel(ylabel, fontsize=13, fontweight="bold")
    ax.set_ylim(*ylim)
    if invert:
        ax.invert_yaxis()
    ax.grid(axis="y", alpha=0.14)
    ax.tick_params(axis="y", labelsize=11)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)


def draw_delta_bars(ax, rows: list[dict]) -> None:
    backbones = [row["backbone"] for row in rows]
    x = np.arange(len(backbones))
    width = 0.24
    delta_raw_to_visual = [row["raw_wrong_pair_rate"] - row["pure_visual_wrong_pair_rate"] for row in rows]
    delta_visual_to_bank = [row["pure_visual_wrong_pair_rate"] - row["text_bank_visual_wrong_pair_rate"] for row in rows]
    delta_bank_to_full = [row["text_bank_visual_wrong_pair_rate"] - row["full_ours_wrong_pair_rate"] for row in rows]

    bars1 = ax.bar(x - width, delta_raw_to_visual, width=width, color="#8C8C8C", label="Raw → Pure visual")
    bars2 = ax.bar(x, delta_visual_to_bank, width=width, color="#1B9E77", label="Pure visual → Text-cond. bank")
    bars3 = ax.bar(x + width, delta_bank_to_full, width=width, color="#377EB8", label="Text-cond. bank → Full")

    for bars in (bars1, bars2, bars3):
        for bar in bars:
            h = float(bar.get_height())
            y = h + 0.01 if h >= 0 else h - 0.015
            va = "bottom" if h >= 0 else "top"
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                y,
                f"{h:+.02f}",
                ha="center",
                va=va,
                fontsize=9.2,
                fontweight="bold",
            )

    ax.axhline(0.0, color="#555555", lw=1.0)
    ax.set_xticks(x, backbones, fontsize=11, fontweight="bold")
    ax.set_ylabel("Step change in wrong pair rate", fontsize=13, fontweight="bold")
    ymin = min(delta_raw_to_visual + delta_visual_to_bank + delta_bank_to_full)
    ymax = max(delta_raw_to_visual + delta_visual_to_bank + delta_bank_to_full)
    ax.set_ylim(min(-0.10, ymin - 0.04), ymax + 0.08)
    ax.grid(axis="y", alpha=0.14)
    ax.tick_params(axis="y", labelsize=11)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)


def main() -> None:
    SAVE_DIR.mkdir(parents=True, exist_ok=True)
    rows = load_rows()

    fig, axes = plt.subplots(1, 3, figsize=(15.8, 4.6), constrained_layout=True)

    draw_stage_lines(
        axes[0],
        rows,
        [key for key, _, _ in DISPLAY_STAGES],
        ylabel="Wrong pair rate",
        ylim=(0.15, 0.62),
    )
    draw_delta_bars(axes[1], rows)
    draw_stage_lines(
        axes[2],
        rows,
        [dkey for _, dkey, _ in DISPLAY_STAGES],
        ylabel="Separation (Cohen's d)",
        ylim=(0.0, 1.42),
    )

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 1.04),
        ncol=4,
        frameon=False,
        fontsize=11.5,
    )

    fig.savefig(SAVE_DIR / "rawclip_textcondition_story.png", dpi=260, bbox_inches="tight")
    fig.savefig(SAVE_DIR / "rawclip_textcondition_story.pdf", bbox_inches="tight")
    with (SAVE_DIR / "rawclip_textcondition_story.json").open("w") as f:
        json.dump({"source": str(SOURCE_JSON), "rows": rows}, f, indent=2)


if __name__ == "__main__":
    main()
