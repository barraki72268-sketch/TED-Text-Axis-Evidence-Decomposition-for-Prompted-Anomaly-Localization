from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from neurips2026.scripts.adaclip_diagnostics_common import (
    AdaCLIPDiagConfig,
    ROOT,
    _preset_fields,
    activation_area,
    build_loader,
    compute_mode_outputs,
    load_model_and_banks,
    map_topk_values,
    save_json,
)
from neurips2026.scripts.official_parallel_test_adaclip import resolve_layer_recipe


def calibrate_threshold(loader, model, fp_banks_gpu, def_banks_gpu, features_list, cfg: AdaCLIPDiagConfig, topk_frac: float, quantile: float):
    selected = resolve_layer_recipe(features_list, cfg.layer_recipe)
    pools = {"baseline": [], "ours": []}
    with torch.no_grad():
        for items in loader:
            if int(items["anomaly"][0]) != 0:
                continue
            image = items["img"].to(cfg.device)
            cls_name = items["cls_name"][0]
            out = compute_mode_outputs(
                model=model,
                fp_banks_gpu=fp_banks_gpu,
                def_banks_gpu=def_banks_gpu,
                selected_layer_indices=selected,
                image=image,
                cls_name=cls_name,
                sigma=cfg.sigma,
                tau=cfg.tau,
                fp_weight=cfg.fp_weight,
                scoring_mode=cfg.scoring_mode,
                refine_alpha=cfg.refine_alpha,
                refine_beta=cfg.refine_beta,
                margin_norm_mode=cfg.margin_norm_mode,
                image_size=cfg.image_size,
            )
            pools["baseline"].append(map_topk_values(out["baseline_map"][0], topk_frac).cpu())
            pools["ours"].append(map_topk_values(out["parallel_map"][0], topk_frac).cpu())
    thresholds = {}
    for mode in ("baseline", "ours"):
        vals = torch.cat(pools[mode], dim=0).numpy()
        thresholds[mode] = float(np.quantile(vals, quantile))
    return thresholds


def evaluate_recipe(loader, model, fp_banks_gpu, def_banks_gpu, features_list, cfg: AdaCLIPDiagConfig, thresholds: dict[str, float]):
    selected = resolve_layer_recipe(features_list, cfg.layer_recipe)
    stats = {
        "baseline": {"normal_alarm_area": [], "normal_alarm_image": [], "anomaly_pixel_recall": [], "anomaly_image_hit": []},
        "ours": {"normal_alarm_area": [], "normal_alarm_image": [], "anomaly_pixel_recall": [], "anomaly_image_hit": []},
    }
    with torch.no_grad():
        for items in loader:
            image = items["img"].to(cfg.device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][:, 0].to(cfg.device).float() > 0.5
            is_anomaly = int(items["anomaly"][0])
            out = compute_mode_outputs(
                model=model,
                fp_banks_gpu=fp_banks_gpu,
                def_banks_gpu=def_banks_gpu,
                selected_layer_indices=selected,
                image=image,
                cls_name=cls_name,
                sigma=cfg.sigma,
                tau=cfg.tau,
                fp_weight=cfg.fp_weight,
                scoring_mode=cfg.scoring_mode,
                refine_alpha=cfg.refine_alpha,
                refine_beta=cfg.refine_beta,
                margin_norm_mode=cfg.margin_norm_mode,
                image_size=cfg.image_size,
            )
            for mode, map_key in (("baseline", "baseline_map"), ("ours", "parallel_map")):
                score_map = out[map_key][0]
                thr = thresholds[mode]
                if is_anomaly == 0:
                    area = activation_area(score_map, thr)
                    stats[mode]["normal_alarm_area"].append(area)
                    stats[mode]["normal_alarm_image"].append(float(area > 0.0))
                else:
                    pos = gt_mask[0]
                    if int(pos.sum().item()) == 0:
                        continue
                    hit = (score_map[pos] > thr).float()
                    stats[mode]["anomaly_pixel_recall"].append(float(hit.mean().item()))
                    stats[mode]["anomaly_image_hit"].append(float(hit.any().item()))
    summary = {}
    for mode in ("baseline", "ours"):
        summary[mode] = {
            "threshold": thresholds[mode],
            "normal_alarm_area_mean": float(np.mean(stats[mode]["normal_alarm_area"])),
            "normal_alarm_image_rate": float(np.mean(stats[mode]["normal_alarm_image"])),
            "anomaly_pixel_recall_mean": float(np.mean(stats[mode]["anomaly_pixel_recall"])),
            "anomaly_image_hit_rate": float(np.mean(stats[mode]["anomaly_image_hit"])),
        }
    return summary


def main() -> None:
    parser = argparse.ArgumentParser("AdaCLIP fixed-threshold deployment stress")
    parser.add_argument("--preset", type=str, required=True)
    parser.add_argument("--layer_recipes", nargs="+", default=["all4", "last2", "mid2", "earlylate", "last"])
    parser.add_argument("--run_tag", type=str, default="pilot_v1")
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--quantile", type=float, default=0.95)
    parser.add_argument("--class_name", type=str, default=None)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--cpu_threads", type=int, default=1)
    args = parser.parse_args()

    cfg = AdaCLIPDiagConfig(
        preset=args.preset,
        layer_recipe="all4",
        class_name=args.class_name,
        device=args.device,
        num_workers=args.num_workers,
        cpu_threads=args.cpu_threads,
    )
    model, fp_banks_gpu, def_banks_gpu, meta = load_model_and_banks(cfg)
    preset = _preset_fields(args.preset)
    _, loader = build_loader(cfg, preset["target_root"], preset["target_dataset"], model)
    thresholds = calibrate_threshold(loader, model, fp_banks_gpu, def_banks_gpu, meta["features_list"], cfg, args.topk_frac, args.quantile)

    rows = []
    for recipe in args.layer_recipes:
        cfg.layer_recipe = recipe
        recipe_summary = evaluate_recipe(loader, model, fp_banks_gpu, def_banks_gpu, meta["features_list"], cfg, thresholds)
        for mode_key, mode_name in (("baseline", "baseline_txt"), ("ours", "parallel_margin")):
            row = {
                "preset": args.preset,
                "layer_recipe": recipe,
                "mode": mode_name,
                **recipe_summary[mode_key],
            }
            rows.append(row)

    payload = {
        "meta": {
            "preset": args.preset,
            "run_tag": args.run_tag,
            "topk_frac": args.topk_frac,
            "quantile": args.quantile,
            "class_name": args.class_name,
            **meta,
            "thresholds_from_all4": thresholds,
        },
        "rows": rows,
    }
    out_path = ROOT / "neurips2026" / "results" / "adaclip_fixed_threshold_stress" / f"{args.preset}_{args.run_tag}.json"
    save_json(out_path, payload)
    print(json.dumps({"path": str(out_path), "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
