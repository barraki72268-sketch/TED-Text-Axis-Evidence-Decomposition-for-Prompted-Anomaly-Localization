from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from neurips2026.scripts.adaclip_diagnostics_common import (
    AdaCLIPDiagConfig,
    OOD_NORMAL_CONFIGS,
    ROOT,
    _preset_fields,
    activation_area,
    build_loader,
    compute_mode_outputs,
    load_model_and_banks,
    map_topk_values,
    save_json,
)
from neurips2026.scripts.collect_adaclip_fixed_threshold_stress import calibrate_threshold
from neurips2026.scripts.official_parallel_test_adaclip import resolve_layer_recipe


def evaluate_normal_set(loader, model, fp_banks_gpu, def_banks_gpu, features_list, cfg: AdaCLIPDiagConfig, thresholds: dict[str, float], topk_frac: float):
    selected = resolve_layer_recipe(features_list, cfg.layer_recipe)
    stats = {
        "baseline": {"alarm_area": [], "alarm_image": [], "topk_mean": []},
        "ours": {"alarm_area": [], "alarm_image": [], "topk_mean": []},
    }
    with torch.no_grad():
        for items in loader:
            if int(items["anomaly"][0]) != 0:
                continue
            image = items["img"].to(cfg.device)
            cls_name = items["cls_name"][0]
            out = compute_mode_outputs(
                model=model,
                fp_banks_gpu=fp_banks_gpu,
                def_banks_gpu=def_banks_gpu,
                selected_layer_indices=selected,
                image=image,
                cls_name=cls_name,
                sigma=cfg.sigma,
                tau=cfg.tau,
                fp_weight=cfg.fp_weight,
                scoring_mode=cfg.scoring_mode,
                refine_alpha=cfg.refine_alpha,
                refine_beta=cfg.refine_beta,
                margin_norm_mode=cfg.margin_norm_mode,
                image_size=cfg.image_size,
            )
            for mode, map_key in (("baseline", "baseline_map"), ("ours", "parallel_map")):
                score_map = out[map_key][0]
                thr = thresholds[mode]
                area = activation_area(score_map, thr)
                stats[mode]["alarm_area"].append(area)
                stats[mode]["alarm_image"].append(float(area > 0.0))
                stats[mode]["topk_mean"].append(float(map_topk_values(score_map, topk_frac).mean().item()))
    summary = {}
    for mode in ("baseline", "ours"):
        summary[mode] = {
            "normal_alarm_area_mean": float(np.mean(stats[mode]["alarm_area"])),
            "normal_alarm_image_rate": float(np.mean(stats[mode]["alarm_image"])),
            "normal_topk_mean": float(np.mean(stats[mode]["topk_mean"])),
        }
    return summary


def main() -> None:
    parser = argparse.ArgumentParser("AdaCLIP OOD normal specificity")
    parser.add_argument("--preset", type=str, required=True)
    parser.add_argument("--ood_normal_sets", nargs="+", default=["visa", "mpdd", "btad"])
    parser.add_argument("--layer_recipe", type=str, default="all4")
    parser.add_argument("--run_tag", type=str, default="pilot_v1")
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument("--quantile", type=float, default=0.95)
    parser.add_argument("--class_name", type=str, default=None)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--cpu_threads", type=int, default=1)
    args = parser.parse_args()

    cfg = AdaCLIPDiagConfig(
        preset=args.preset,
        layer_recipe=args.layer_recipe,
        class_name=args.class_name,
        device=args.device,
        num_workers=args.num_workers,
        cpu_threads=args.cpu_threads,
    )
    model, fp_banks_gpu, def_banks_gpu, meta = load_model_and_banks(cfg)
    preset = _preset_fields(args.preset)

    calib_cfg = AdaCLIPDiagConfig(**{**cfg.__dict__, "layer_recipe": "all4"})
    _, calib_loader = build_loader(calib_cfg, preset["target_root"], preset["target_dataset"], model)
    thresholds = calibrate_threshold(calib_loader, model, fp_banks_gpu, def_banks_gpu, meta["features_list"], calib_cfg, args.topk_frac, args.quantile)

    rows = []
    for normal_set in args.ood_normal_sets:
        if normal_set not in OOD_NORMAL_CONFIGS:
            raise ValueError(f"Unknown normal set: {normal_set}")
        normal_cfg = OOD_NORMAL_CONFIGS[normal_set]
        _, loader = build_loader(cfg, normal_cfg["target_root"], normal_cfg["target_dataset"], model)
        summary = evaluate_normal_set(loader, model, fp_banks_gpu, def_banks_gpu, meta["features_list"], cfg, thresholds, args.topk_frac)
        for mode_key, mode_name in (("baseline", "baseline_txt"), ("ours", "parallel_margin")):
            rows.append({
                "preset": args.preset,
                "layer_recipe": args.layer_recipe,
                "normal_set": normal_set,
                "mode": mode_name,
                **summary[mode_key],
            })

    payload = {
        "meta": {
            "preset": args.preset,
            "run_tag": args.run_tag,
            "layer_recipe": args.layer_recipe,
            "topk_frac": args.topk_frac,
            "quantile": args.quantile,
            "class_name": args.class_name,
            **meta,
            "thresholds_from_all4": thresholds,
        },
        "rows": rows,
    }
    out_path = ROOT / "neurips2026" / "results" / "adaclip_ood_normal_specificity" / f"{args.preset}_{args.run_tag}.json"
    save_json(out_path, payload)
    print(json.dumps({"path": str(out_path), "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
