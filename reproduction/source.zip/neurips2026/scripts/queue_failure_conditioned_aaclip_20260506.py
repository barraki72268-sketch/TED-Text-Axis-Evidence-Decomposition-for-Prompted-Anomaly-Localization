#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
EVAL = ROOT / "neurips2026" / "scripts" / "official_parallel_test_aaclip.py"
RESULTS = ROOT / "neurips2026" / "results" / "failure_conditioned_separability_aaclip_20260506"
LOGS = ROOT / "neurips2026" / "logs" / "failure_conditioned_separability_aaclip_20260506"


BACKBONES = {
    "vitbplus": {
        "model_name": "ViT-B-16-plus-240",
        "pretrained": "laion400m_e32",
        "adapter": "project_crop",
        "levels": "3,6,9,12",
        "img_size": "518",
        "batch_size": "8",
    },
}


def csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_cmd(preset: str, backbone: str, seed: int, device: str) -> tuple[list[str], Path, Path]:
    cfg = BACKBONES[backbone]
    save_dir = RESULTS / f"aaclip_{backbone}_{preset}_seed{seed}"
    log_path = LOGS / f"{save_dir.name}.log"
    cmd = [
        str(PY),
        "-u",
        str(EVAL.relative_to(ROOT)),
        "--preset",
        preset,
        "--model_name",
        cfg["model_name"],
        "--pretrained",
        cfg["pretrained"],
        "--adapter_load_mode",
        cfg["adapter"],
        "--levels",
        cfg["levels"],
        "--img_size",
        cfg["img_size"],
        "--batch_size",
        cfg["batch_size"],
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir, log_path


def worker_script(jobs: list[tuple[list[str], Path, Path]], worker_id: int) -> Path:
    path = LOGS / f"aaclip_worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        "jobs = [",
    ]
    for cmd, save_dir, log_path in jobs:
        lines.append(f"    ({cmd!r}, {str(save_dir)!r}, {str(log_path)!r}),")
    lines += [
        "]",
        "for cmd, save_dir, log_path in jobs:",
        "    summary = Path(save_dir) / 'summary.json'",
        "    Path(log_path).parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists():",
        "        print({'stage': 'skip', 'summary': str(summary)}, flush=True)",
        "        continue",
        "    print({'stage': 'run', 'save_dir': save_dir, 'log': log_path}, flush=True)",
        "    with open(log_path, 'w') as f:",
        "        subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, check=False)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    path.write_text("\n".join(lines))
    return path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--presets", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--backbones", default="vitbplus")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    args = ap.parse_args()

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    presets = csv(args.presets)
    backbones = csv(args.backbones)
    seeds = [int(x) for x in csv(args.seeds)]
    devices = csv(args.devices)

    all_jobs: list[tuple[list[str], Path, Path]] = []
    for seed in seeds:
        for backbone in backbones:
            if backbone not in BACKBONES:
                raise SystemExit(f"Unknown backbone={backbone}; allowed={sorted(BACKBONES)}")
            for preset in presets:
                device = devices[len(all_jobs) % len(devices)]
                all_jobs.append(build_cmd(preset, backbone, seed, device))

    buckets = [[] for _ in devices]
    for idx, job in enumerate(all_jobs):
        buckets[idx % len(devices)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        script = worker_script(bucket, worker_id)
        log = LOGS / f"aaclip_worker_{worker_id}.log"
        with log.open("a") as f:
            proc = subprocess.Popen([str(PY), str(script)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "log": str(log), "script": str(script)})
    print(json.dumps({"stage": "queued_failure_conditioned_aaclip", "launched": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
