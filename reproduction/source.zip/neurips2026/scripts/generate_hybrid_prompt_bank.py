from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.scripts.kinematic_text_axis_reconstruction import (  # noqa: E402
    build_recent_general_prompt_bank,
    encode_text_features,
)


DEFAULT_SOURCE_CLASSES = [
    "bottle",
    "cable",
    "capsule",
    "carpet",
    "hazelnut",
    "leather",
    "metal_nut",
    "pill",
    "screw",
    "tile",
    "transistor",
    "wood",
    "zipper",
]

DEFAULT_TARGET_CLASSES = [
    "chewinggum",
    "pipe_fryum",
    "pcb4",
    "macaroni2",
    "cashew",
    "pcb1",
    "macaroni1",
    "fryum",
    "pcb2",
    "capsules",
    "candle",
    "pcb3",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Generate projected / hybrid prompt banks offline.")
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--lambda_val", type=float, default=0.5)
    parser.add_argument("--include_source_classes", action="store_true", default=True)
    parser.add_argument("--include_target_classes", action="store_true", default=True)
    parser.add_argument("--class_names", nargs="*", default=None)
    parser.add_argument(
        "--output_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "hybrid_prompt_bank_L0.5.pt"),
    )
    return parser.parse_args()


def normalize_rows(x: torch.Tensor) -> torch.Tensor:
    return F.normalize(x.float(), p=2, dim=-1)


def compute_projected_and_hybrid(
    e_norm: torch.Tensor,
    e_anom: torch.Tensor,
    lambda_val: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    _, d = e_norm.shape
    eye = torch.eye(d, device=e_norm.device, dtype=e_norm.dtype)
    u = e_norm.T
    p_perp = eye - u @ torch.pinverse(u.T @ u) @ u.T
    e_anom_proj = e_anom @ p_perp.T
    e_anom_hybrid = e_anom + float(lambda_val) * e_anom_proj
    return normalize_rows(e_anom_proj), normalize_rows(e_anom_hybrid)


def compute_soft_and_adaptive(
    p_norm: torch.Tensor,
    e_anom: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    p_unit = normalize_rows(p_norm)[0]
    e_unit = normalize_rows(e_anom)
    cos = torch.matmul(e_unit, p_unit.unsqueeze(1)).squeeze(1)
    parallel = cos.unsqueeze(1) * p_unit.unsqueeze(0)
    perp = e_unit - parallel
    rho = cos.abs().clamp(0.0, 1.0)
    e_soft = e_unit - rho.unsqueeze(1) * parallel
    gamma = (1.0 - cos.abs()).clamp(0.0, 1.0)
    e_adaptive = gamma.unsqueeze(1) * parallel + perp
    return normalize_rows(e_soft), normalize_rows(e_adaptive)


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    class_names: list[str] = []
    if args.class_names:
        class_names.extend(args.class_names)
    else:
        if args.include_source_classes:
            class_names.extend(DEFAULT_SOURCE_CLASSES)
        if args.include_target_classes:
            class_names.extend(DEFAULT_TARGET_CLASSES)
    class_names = sorted(dict.fromkeys(class_names))

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
    )
    backbone.eval()

    bank: dict[str, dict] = {}
    stats: dict[str, dict[str, float]] = {}
    for class_name in class_names:
        normal_prompt, abnormal_prompts = build_recent_general_prompt_bank(class_name)
        p_norm = encode_text_features(backbone, backbone.tokenizer, [normal_prompt]).float()
        e_anom = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts).float()
        e_proj, e_hybrid = compute_projected_and_hybrid(p_norm, e_anom, args.lambda_val)
        e_soft, e_adaptive = compute_soft_and_adaptive(p_norm, e_anom)
        cos_to_norm = torch.matmul(normalize_rows(e_anom), normalize_rows(p_norm).T).squeeze(1)
        proj_ret = torch.norm(e_proj, dim=-1) / torch.norm(normalize_rows(e_anom), dim=-1).clamp_min(1e-8)
        bank[class_name] = {
            "normal_prompt": normal_prompt,
            "abnormal_prompts": abnormal_prompts,
            "p_norm": normalize_rows(p_norm).cpu(),
            "e_anom_raw": normalize_rows(e_anom).cpu(),
            "e_anom_projected": e_proj.cpu(),
            "e_anom_hybrid": e_hybrid.cpu(),
            "e_anom_soft": e_soft.cpu(),
            "e_anom_adaptive": e_adaptive.cpu(),
        }
        stats[class_name] = {
            "cosine_to_normal_mean": float(cos_to_norm.mean().item()),
            "cosine_to_normal_max": float(cos_to_norm.max().item()),
            "projected_norm_retention_mean": float(proj_ret.mean().item()),
        }

    output_path = Path(args.output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "meta": {
            "backbone": args.backbone,
            "pretrained_dataset": args.pretrained_dataset,
            "lambda_val": float(args.lambda_val),
            "class_names": class_names,
        },
        "bank": bank,
        "stats": stats,
    }
    torch.save(payload, output_path)
    print(output_path)
    print(json.dumps({"num_classes": len(class_names), "lambda_val": float(args.lambda_val)}, indent=2))


if __name__ == "__main__":
    main()
