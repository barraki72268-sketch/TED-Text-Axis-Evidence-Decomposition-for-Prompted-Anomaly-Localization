from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"
FIG_DIR.mkdir(parents=True, exist_ok=True)
OUT_DIR.mkdir(parents=True, exist_ok=True)


RECIPES = ["Full", "EL", "M2", "L2", "L"]

LAYER_GAINS = {
    "Ada PRO": [47.97 - 44.03, 26.25 - 18.18, 25.42 - 23.50, 22.78 - 15.19, 46.27 - 34.83],
    "Ada AP": [41.85 - 41.60, 23.81 - 22.40, 36.40 - 36.18, 39.28 - 36.35, 36.77 - 35.78],
    "FA PRO": [76.83 - 73.57, 77.16 - 74.70, 76.54 - 74.35, 76.63 - 72.73, 76.08 - 74.01],
    "FA AP": [30.94 - 22.35, 32.40 - 23.58, 31.46 - 22.58, 31.07 - 22.33, 31.68 - 23.01],
}

BACKBONE_GAINS = [
    ("Ada", 21.43 - 19.74, 4.46 - 4.27),
    ("Adapt", 44.17 - 43.40, 15.92 - 15.22),
    ("Anom.", 38.10 - 27.83, 5.23 - 5.06),
    ("FA", 37.96 - 35.51, 17.22 - 8.78),
]

FIXED_SWAP_PRO = 68.52076431115468 - 64.89102184772491
FIXED_SWAP_AP = 28.595763806896173 - 25.80598379332769


def setup():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.titlesize": 14,
            "axes.labelsize": 11,
            "xtick.labelsize": 10,
            "ytick.labelsize": 10,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def make_layer_plot():
    setup()
    colors = {
        "Ada PRO": "#1B5E8A",
        "Ada AP": "#1B5E8A",
        "FA PRO": "#B45F06",
        "FA AP": "#B45F06",
    }
    styles = {
        "Ada PRO": ("o", "-"),
        "Ada AP": ("s", "--"),
        "FA PRO": ("o", "-"),
        "FA AP": ("s", "--"),
    }
    x = np.arange(len(RECIPES))
    fig, ax = plt.subplots(figsize=(4.2, 2.85))
    for name, y in LAYER_GAINS.items():
        marker, linestyle = styles[name]
        ax.plot(
            x,
            y,
            color=colors[name],
            marker=marker,
            linestyle=linestyle,
            linewidth=2.3,
            markersize=5.5,
        )
        ax.text(
            x[-1] + 0.16,
            y[-1],
            name,
            color=colors[name],
            fontsize=8.5,
            fontweight="bold",
            va="center",
        )
    ax.axhline(0, color="#555555", linewidth=0.9)
    ax.set_title("(a) Layer-wise retraining", fontweight="bold", pad=6)
    ax.set_ylabel("Gain")
    ax.set_xticks(x)
    ax.set_xticklabels(RECIPES)
    ax.set_xlim(-0.25, len(RECIPES) - 0.05)
    ax.set_ylim(-0.8, 12.6)
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.75)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout(pad=0.25)
    pdf = FIG_DIR / "layer_recipe_retrain_compact_20260503.pdf"
    png = FIG_DIR / "layer_recipe_retrain_compact_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return pdf, png


def make_backbone_plot():
    setup()
    labels = [v[0] for v in BACKBONE_GAINS]
    pro = np.asarray([v[1] for v in BACKBONE_GAINS])
    ap = np.asarray([v[2] for v in BACKBONE_GAINS])
    x = np.arange(len(labels))
    w = 0.34
    fig, ax = plt.subplots(figsize=(3.75, 2.85))
    bars_pro = ax.bar(x - w / 2, pro, width=w, color="#1B5E8A", alpha=0.94)
    bars_ap = ax.bar(x + w / 2, ap, width=w, color="#B45F06", alpha=0.94)
    for bars, color in [(bars_pro, "#1B5E8A"), (bars_ap, "#B45F06")]:
        for bar in bars:
            h = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                h + 0.28,
                f"{h:.1f}",
                ha="center",
                va="bottom",
                fontsize=8.2,
                fontweight="bold",
                color=color,
            )
    ax.text(0.05, 0.94, "■ PRO", transform=ax.transAxes, ha="left", va="top", fontsize=8.6, color="#1B5E8A", fontweight="bold")
    ax.text(0.05, 0.84, "■ AP", transform=ax.transAxes, ha="left", va="top", fontsize=8.6, color="#B45F06", fontweight="bold")
    ax.axhline(0, color="#555555", linewidth=0.9)
    ax.set_title("(b) Backbone-wise retraining", fontweight="bold", pad=6)
    ax.set_ylabel("Gain")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=22, ha="right")
    ax.set_ylim(-0.5, 12.6)
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.75)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout(pad=0.25)
    pdf = FIG_DIR / "backbone_retrain_compact_20260503.pdf"
    png = FIG_DIR / "backbone_retrain_compact_20260503.png"
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return pdf, png


def write_tex():
    layer_pro = np.mean([LAYER_GAINS["Ada PRO"], LAYER_GAINS["FA PRO"]])
    layer_ap = np.mean([LAYER_GAINS["Ada AP"], LAYER_GAINS["FA AP"]])
    bb_pro = np.mean([v[1] for v in BACKBONE_GAINS])
    bb_ap = np.mean([v[2] for v in BACKBONE_GAINS])
    tex = OUT_DIR / "recipe_retrain_three_panel_20260503.tex"
    tex.write_text(
        rf"""\begin{{figure*}}[t]
\centering
\begin{{minipage}}[t]{{0.36\textwidth}}
\centering
\includegraphics[width=\linewidth]{{figure/layer_recipe_retrain_compact_20260503.pdf}}
\end{{minipage}}
\hfill
\begin{{minipage}}[t]{{0.31\textwidth}}
\centering
\includegraphics[width=\linewidth]{{figure/backbone_retrain_compact_20260503.pdf}}
\end{{minipage}}
\hfill
\begin{{minipage}}[t]{{0.29\textwidth}}
\centering
\textbf{{(c) Protocol summary}}
\vspace{{2pt}}

\scriptsize
\setlength{{\tabcolsep}}{{2.8pt}}
\renewcommand{{\arraystretch}}{{1.08}}
\begin{{tabular}}{{lccc}}
\toprule
Setting & Retrain & Bank & Avg. gain \\
\midrule
Fixed swap & -- & \textbf{{V}} & $+\!{FIXED_SWAP_PRO:.1f}$ / $+\!{FIXED_SWAP_AP:.1f}$ \\
Layer recipe & \textbf{{V}} & \textbf{{V}} & $+\!{layer_pro:.1f}$ / $+\!{layer_ap:.1f}$ \\
Backbone recipe & \textbf{{V}} & \textbf{{V}} & $+\!{bb_pro:.1f}$ / $+\!{bb_ap:.1f}$ \\
\bottomrule
\end{{tabular}}

\vspace{{2pt}}
\scriptsize PRO / AP gain over B
\end{{minipage}}
\caption{{
Recipe-retraining diagnostics.
(a) Feature-layer recipes are retrained before evaluation, but C-TED still improves local PRO/AP over the retrained baseline.
(b) Backbone-wise retraining changes the host geometry; C-TED is evaluated after rebuilding source banks for the retrained backbone.
(c) The comparison separates fixed-host swaps from recipe-consistent retraining settings.
}}
\label{{fig:recipe_retrain_three_panel}}
\end{{figure*}}
""",
        encoding="utf-8",
    )
    return tex


def main():
    print(make_layer_plot()[0])
    print(make_backbone_plot()[0])
    print(write_tex())


if __name__ == "__main__":
    main()
