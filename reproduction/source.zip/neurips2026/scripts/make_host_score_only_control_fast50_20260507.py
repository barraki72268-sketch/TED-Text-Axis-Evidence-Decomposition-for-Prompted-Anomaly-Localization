#!/usr/bin/env python3
from __future__ import annotations

import queue_host_score_only_control_20260507 as queue_base
import make_host_score_only_control_20260507 as base


ROOT = base.ROOT
base.RESULTS = ROOT / "neurips2026" / "results" / "host_score_only_control_fast50_20260507"
base.CSV_OUT = ROOT / "supp_fig" / "host_score_only_control_fast50_20260507.csv"
base.TEX_OUT = ROOT / "supp_fig" / "host_score_only_control_fast50_20260507.tex"


if __name__ == "__main__":
    raise SystemExit(base.main())
