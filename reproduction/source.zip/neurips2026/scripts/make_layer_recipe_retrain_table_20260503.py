#!/usr/bin/env python3
from __future__ import annotations

import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"

ADACLIP_ROOT = RESULTS / "layer_recipe_retrained_all_20260502"
ANOMALY_ROOT = RESULTS / "anomalyclip_layer_recipe_retrained_corrected_20260503"
FAPROMPT_ROOT = RESULTS / "faprompt_layer_recipe_retrained_20260502"

MODE_ALIASES = {
    "B": ("baseline_txt", "baseline", "baseline_official", "baseline_maptopk"),
    "T": ("parallel_margin", "ted_parallel", "support_only_alpha_1", "support_only_alpha_1.0", "support_only_alpha_0.5"),
    "C": ("ted_calibrated", "branch_calibrated_alpha_1", "branch_calibrated_alpha_1.0", "branch_calibrated_alpha_0.5"),
}


def load(path: Path) -> dict | None:
    if not path.exists():
        return None
    with path.open("r") as f:
        return json.load(f)


def pct(value) -> float | None:
    if value is None:
        return None
    value = float(value)
    if math.isnan(value):
        return None
    return value * 100.0 if abs(value) <= 1.5 else value


def row_vals(row: dict | None) -> tuple[float | None, float | None, float | None, float | None] | None:
    if not isinstance(row, dict):
        return None
    return (
        pct(row.get("image_auroc", row.get("image_auc"))),
        pct(row.get("pixel_auroc", row.get("pixel_auc"))),
        pct(row.get("pixel_aupro", row.get("pixel_pro"))),
        pct(row.get("pixel_ap")),
    )


def mean_row(summary: dict | None, mode_alias: str) -> tuple[float | None, float | None, float | None, float | None] | None:
    if summary is None:
        return None
    aliases = MODE_ALIASES[mode_alias]
    rows = summary.get("rows", [])
    if isinstance(rows, list):
        for alias in aliases:
            for row in rows:
                if row.get("target_label") == "mean" and row.get("mode") == alias:
                    return row_vals(row)
    mean = summary.get("mean", {})
    if isinstance(mean, dict):
        for alias in aliases:
            if alias in mean:
                return row_vals(mean[alias])
        # FAPrompt stores C-TED under nested parallel candidates.
        parallel = mean.get("parallel")
        if isinstance(parallel, dict):
            for alias in aliases:
                if alias in parallel:
                    return row_vals(parallel[alias])
    return None


def fmt(vals: tuple[float | None, float | None, float | None, float | None] | None) -> str:
    if vals is None or any(v is None for v in vals):
        return "--.-- / --.-- / --.-- / --.--"
    return " / ".join(f"{v:.2f}" for v in vals if v is not None)


def fmt_cells_with_bold(
    cells: tuple[
        tuple[float | None, float | None, float | None, float | None] | None,
        tuple[float | None, float | None, float | None, float | None] | None,
        tuple[float | None, float | None, float | None, float | None] | None,
    ],
) -> tuple[str, str, str]:
    parsed = []
    for vals in cells:
        if vals is None or any(v is None for v in vals):
            parsed.append(None)
        else:
            parsed.append(vals)
    best: list[float | None] = []
    for metric_idx in range(4):
        vals = [cell[metric_idx] for cell in parsed if cell is not None]
        best.append(max(vals) if vals else None)

    out = []
    for cell in parsed:
        if cell is None:
            out.append("--.-- / --.-- / --.-- / --.--")
            continue
        parts = []
        for metric_idx, value in enumerate(cell):
            text = f"{value:.2f}"
            if best[metric_idx] is not None and abs(value - best[metric_idx]) < 1e-9:
                text = rf"\textbf{{{text}}}"
            parts.append(text)
        out.append(" / ".join(parts))
    return tuple(out)  # type: ignore[return-value]


def collect_cell(path: Path) -> tuple[str, str, str]:
    summary = load(path / "summary.json")
    cells = tuple(mean_row(summary, key) for key in ("B", "T", "C"))
    return fmt_cells_with_bold(cells)  # type: ignore[arg-type,return-value]


def build_rows() -> list[tuple[str, list[tuple[str, str, str, str]]]]:
    return [
        (
            "AdaCLIP",
            [
                ("Full(B)", *collect_cell(ADACLIP_ROOT / "adaclip_visa_all4_baseline_eval")),
                ("EL-r", *collect_cell(ADACLIP_ROOT / "adaclip_visa_earlylate_eval")),
                ("M2-r", *collect_cell(ADACLIP_ROOT / "adaclip_visa_mid2_eval")),
                ("L2-r", *collect_cell(ADACLIP_ROOT / "adaclip_visa_last2_eval")),
                ("L-r", *collect_cell(ADACLIP_ROOT / "adaclip_visa_last_eval")),
            ],
        ),
        (
            "AnomalyCLIP",
            [
                ("Full(B)", *collect_cell(ANOMALY_ROOT / "anomalyclip_visa_all4_official_eval")),
                ("EL-r", *collect_cell(ANOMALY_ROOT / "anomalyclip_visa_earlylate_eval")),
                ("M2-r", *collect_cell(ANOMALY_ROOT / "anomalyclip_visa_mid2_eval")),
                ("L2-r", *collect_cell(ANOMALY_ROOT / "anomalyclip_visa_last2_eval")),
                ("L-r", *collect_cell(ANOMALY_ROOT / "anomalyclip_visa_last_eval")),
                ("F-r", *collect_cell(ANOMALY_ROOT / "anomalyclip_visa_all4_eval")),
            ],
        ),
        (
            "FAPrompt",
            [
                ("Full(B)", *collect_cell(FAPROMPT_ROOT / "faprompt_visa_all4_official_eval")),
                ("EL-r", *collect_cell(FAPROMPT_ROOT / "faprompt_visa_earlylate_eval")),
                ("M2-r", *collect_cell(FAPROMPT_ROOT / "faprompt_visa_mid2_eval")),
                ("L2-r", *collect_cell(FAPROMPT_ROOT / "faprompt_visa_last2_eval")),
                ("L-r", *collect_cell(FAPROMPT_ROOT / "faprompt_visa_last_eval")),
                ("F-r", *collect_cell(FAPROMPT_ROOT / "faprompt_visa_all4_eval")),
            ],
        ),
    ]


def write_table(rows: list[tuple[str, list[tuple[str, str, str, str]]]]) -> Path:
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{",
        r"Layer-recipe retraining comparison on VisA$\rightarrow$MVTec.",
        r"Each cell reports I-AUC / P-AUC / PRO / AP.",
        r"B, T, and C denote the host baseline, train-free TED, and source-calibrated TED, respectively.",
        r"Full(B) denotes the original official full-layer baseline recipe.",
        r"EL-r, M2-r, L2-r, L-r, and F-r denote checkpoints retrained with early+last, middle-2, last-2, last-layer, and full-layer recipes, respectively.",
        r"Rows with --.-- are reserved for retraining jobs not yet completed.",
        r"}",
        r"\label{tab:layer_recipe_retrain_expanded}",
        r"\small",
        r"\setlength{\tabcolsep}{2.6pt}",
        r"\renewcommand{\arraystretch}{1.04}",
        r"\resizebox{\textwidth}{!}{",
        r"\begin{tabular}{ll|c|c|c}",
        r"\toprule",
        r"Host & Recipe & B & T & C \\",
        r"\midrule",
    ]
    for host_idx, (host, host_rows) in enumerate(rows):
        if host_idx:
            lines.append(r"\midrule")
        for i, (recipe, b, t, c) in enumerate(host_rows):
            prefix = rf"\multirow{{{len(host_rows)}}}{{*}}{{{host}}}" if i == 0 else ""
            lines.append(f"{prefix} & {recipe} & {b} & {t} & {c} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"}", r"\end{table*}", ""]
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "layer_recipe_retrain_expanded_20260503.tex"
    path.write_text("\n".join(lines))
    return path


def main() -> int:
    rows = build_rows()
    path = write_table(rows)
    print({"tex": str(path)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
