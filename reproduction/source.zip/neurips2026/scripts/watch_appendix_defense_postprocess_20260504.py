#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
LOGS = ROOT / "neurips2026" / "logs" / "appendix_defense_20260504"


POSTPROCESS = [
    "neurips2026/scripts/collect_efficiency_bank_budget_20260504.py",
    "neurips2026/scripts/rank_direct_separability_cases_20260504.py",
    "neurips2026/scripts/make_direct_failure_case_figure_20260504.py",
    "neurips2026/scripts/make_source_bank_control_figure_20260504.py",
    "neurips2026/scripts/make_failure_conditioned_noncherry_20260504.py",
    "neurips2026/scripts/make_failure_conditioned_gain_20260504.py",
    "neurips2026/scripts/collect_defense_ready_results_20260504.py",
]


def alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def parse_pids(text: str) -> list[int]:
    out = []
    for item in text.split(","):
        item = item.strip()
        if not item:
            continue
        out.append(int(item))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pids", required=True, help="Comma-separated worker PIDs to wait for.")
    ap.add_argument("--interval", type=float, default=60.0)
    args = ap.parse_args()

    pids = parse_pids(args.pids)
    LOGS.mkdir(parents=True, exist_ok=True)
    post_log = LOGS / "appendix_postprocess.log"
    with post_log.open("ab", buffering=0) as log_f:
        log_f.write((json.dumps({"stage": "watch_start", "pids": pids}) + "\n").encode())
        while True:
            live = [pid for pid in pids if alive(pid)]
            log_f.write((json.dumps({"stage": "watch_poll", "live": live}) + "\n").encode())
            if not live:
                break
            time.sleep(args.interval)

        for script in POSTPROCESS:
            cmd = [str(PY), script]
            log_f.write((json.dumps({"stage": "postprocess_start", "script": script}) + "\n").encode())
            proc = subprocess.run(cmd, cwd=ROOT, stdout=log_f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            log_f.write(
                (json.dumps({"stage": "postprocess_done", "script": script, "returncode": proc.returncode}) + "\n").encode()
            )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
