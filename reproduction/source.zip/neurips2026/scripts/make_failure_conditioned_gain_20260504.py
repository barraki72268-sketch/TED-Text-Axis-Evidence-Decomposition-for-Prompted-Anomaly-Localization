#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"
FIG = ROOT / "figure"


SETTINGS = [
    {
        "label": "FA\nMVTec→MPDD",
        "host": "FAPrompt",
        "host_key": "faprompt",
        "preset": "mvtec2mpdd",
        "summary": RESULTS
        / "faprompt_branchcal_vitl14_336_f6-12-18-24_dpam20_mvtec2mpdd_rank4_a02_officialimg_seed0_20260428"
        / "summary.json",
    },
    {
        "label": "FA\nMVTec→BTAD",
        "host": "FAPrompt",
        "host_key": "faprompt",
        "preset": "mvtec2btad",
        "summary": RESULTS
        / "faprompt_branchcal_vitl14_336_f6-12-18-24_dpam20_mvtec2btad_rank4_a02_officialimg_seed0_20260428"
        / "summary.json",
    },
    {
        "label": "Ada\nMVTec→BTAD",
        "host": "AdaCLIP",
        "host_key": "adaclip",
        "preset": "mvtec2btad",
        "summary": RESULTS / "maintable_adaclip_vitl336_mvtec2btad_seed0_20260429" / "summary.json",
    },
]


def faprompt_gains(path: Path) -> dict[str, dict[str, float]]:
    data = json.loads(path.read_text())
    out: dict[str, dict[str, float]] = {}
    for row in data["per_class"]:
        cls = row["class_name"]
        base = row["baseline_official"]
        cand = row["parallel"].get("branch_calibrated_alpha_0.5") or next(iter(row["parallel"].values()))
        out[cls] = {
            "P-AUC": (cand["pixel_auc"] - base["pixel_auc"]) * 100.0,
            "PRO": (cand["pixel_aupro"] - base["pixel_aupro"]) * 100.0,
            "AP": (cand["pixel_ap"] - base["pixel_ap"]) * 100.0,
        }
    return out


def adaclip_gains(path: Path) -> dict[str, dict[str, float]]:
    data = json.loads(path.read_text())
    by_class: dict[str, dict[str, dict[str, Any]]] = {}
    for row in data["rows"]:
        cls = row.get("target_label")
        if cls == "mean":
            continue
        by_class.setdefault(cls, {})[row["mode"]] = row
    out: dict[str, dict[str, float]] = {}
    for cls, modes in by_class.items():
        if "baseline_txt" not in modes or "ted_calibrated" not in modes:
            continue
        base = modes["baseline_txt"]
        cand = modes["ted_calibrated"]
        out[cls] = {
            "P-AUC": (cand["pixel_auroc"] - base["pixel_auroc"]) * 100.0,
            "PRO": (cand["pixel_aupro"] - base["pixel_aupro"]) * 100.0,
            "AP": (cand["pixel_ap"] - base["pixel_ap"]) * 100.0,
        }
    return out


def load_common_failure(host_key: str, preset: str) -> dict[str, dict[str, Any]]:
    path = RESULTS / f"common_failure_{host_key}_{preset}_rerun1" / "metrics.json"
    return {row["class_name"]: row for row in json.loads(path.read_text()) if row["class_name"] != "mean"}


def bin_points(points: list[dict[str, Any]]) -> list[dict[str, Any]]:
    points = sorted(points, key=lambda x: x["severity"])
    n = len(points)
    k = max(1, n // 3)
    groups = [
        ("Low", points[:k]),
        ("Mid", points[k : n - k] if n - 2 * k > 0 else []),
        ("High", points[-k:]),
    ]
    rows = []
    for group, items in groups:
        if not items:
            continue
        rows.append(
            {
                "group": group,
                "num_classes": len(items),
                "classes": ",".join(item["class_name"] for item in items),
                "severity": float(np.mean([item["severity"] for item in items])),
                "delta_P-AUC": float(np.mean([item["gains"]["P-AUC"] for item in items])),
                "delta_PRO": float(np.mean([item["gains"]["PRO"] for item in items])),
                "delta_AP": float(np.mean([item["gains"]["AP"] for item in items])),
                "delta_Loc": float(
                    np.mean([(item["gains"]["PRO"] + item["gains"]["AP"]) / 2.0 for item in items])
                ),
            }
        )
    return rows


def collect() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for setting in SETTINGS:
        if not setting["summary"].exists():
            continue
        if setting["host"] == "FAPrompt":
            gains = faprompt_gains(setting["summary"])
        elif setting["host"] == "AdaCLIP":
            gains = adaclip_gains(setting["summary"])
        else:
            continue
        failure = load_common_failure(setting["host_key"], setting["preset"])
        points = []
        for cls, gain in gains.items():
            if cls not in failure:
                continue
            points.append(
                {
                    "class_name": cls,
                    "severity": float(failure[cls]["normal_topk_mean"]),
                    "gains": gain,
                }
            )
        for row in bin_points(points):
            row.update(
                {
                    "setting": setting["label"].replace("\n", " "),
                    "host": setting["host"],
                    "preset": setting["preset"],
                    "summary": str(setting["summary"].relative_to(ROOT)),
                }
            )
            rows.append(row)
    return rows


def fmt(x: float) -> str:
    return f"{x:+.1f}"


def plot(rows: list[dict[str, Any]]) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    by_setting = {}
    for row in rows:
        by_setting.setdefault(row["setting"], {})[row["group"]] = row

    settings = [s["label"].replace("\n", " ") for s in SETTINGS if s["label"].replace("\n", " ") in by_setting]
    groups = ["Low", "Mid", "High"]
    colors = {"Low": "#BFC7C9", "Mid": "#779DA0", "High": "#2F6F73"}

    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.65), sharex=False)
    panels = [("delta_Loc", "Mean Δ(PRO, AP)"), ("delta_PRO", "ΔPRO")]
    for ax, (field, ylabel) in zip(axes, panels):
        x = np.arange(len(settings))
        width = 0.24
        for gi, group in enumerate(groups):
            vals = [by_setting[s].get(group, {}).get(field, np.nan) for s in settings]
            offset = (gi - 1) * width
            bars = ax.bar(
                x + offset,
                vals,
                width=width,
                color=colors[group],
                edgecolor="#222222",
                linewidth=0.35,
                label=group if ax is axes[0] else None,
            )
            for bar, val in zip(bars, vals):
                if not np.isfinite(val):
                    continue
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    val + (0.55 if val >= 0 else -0.7),
                    fmt(float(val)),
                    ha="center",
                    va="bottom" if val >= 0 else "top",
                    fontsize=7.2,
                    fontweight="bold",
                )
        ax.axhline(0, color="#222222", lw=0.8)
        ax.set_xticks(x)
        ax.set_xticklabels([s.replace(" ", "\n", 1) for s in settings], fontsize=7.4, fontweight="bold")
        ax.set_ylabel(ylabel, fontsize=8.8, fontweight="bold")
        ax.grid(axis="y", color="#E7E1D8", lw=0.65)
        ax.set_axisbelow(True)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        ax.tick_params(axis="y", labelsize=8)
    axes[0].set_title("(a) Local metric gain", loc="left", fontsize=9.6, fontweight="bold")
    axes[1].set_title("(b) PRO gain", loc="left", fontsize=9.6, fontweight="bold")
    axes[0].legend(frameon=False, fontsize=8.0, ncol=3, loc="upper left", bbox_to_anchor=(0.0, 1.03))
    fig.suptitle("Failure-conditioned gains", fontsize=11, fontweight="bold", y=1.04)
    fig.tight_layout(pad=0.55, w_pad=1.0)
    fig.savefig(FIG / "failure_conditioned_gain_20260504.pdf", bbox_inches="tight")
    fig.savefig(FIG / "failure_conditioned_gain_20260504.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def write_outputs(rows: list[dict[str, Any]]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / "failure_conditioned_gain_20260504.csv"
    if rows:
        with csv_path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    lines = [
        r"\begin{figure}[t]",
        r"\centering",
        r"\includegraphics[width=1.0\columnwidth]{figure/failure_conditioned_gain_20260504.pdf}",
        r"\caption{",
        r"\textbf{Failure-conditioned gains.}",
        r"For post-hoc diagnosis, target classes are grouped by baseline hard-FP severity, measured by the top-1\% baseline activation on normal target images.",
        r"C-TED gains are larger in high-competition groups, indicating that the correction concentrates on settings where the host produces stronger hard-normal responses.",
        r"The grouping is used only for analysis and not for calibration or hyperparameter selection.",
        r"}",
        r"\label{fig:failure_conditioned_gain}",
        r"\end{figure}",
        "",
    ]
    (OUT / "failure_conditioned_gain_figure_20260504.tex").write_text("\n".join(lines))


def main() -> int:
    rows = collect()
    write_outputs(rows)
    plot(rows)
    print(
        json.dumps(
            {
                "rows": len(rows),
                "figure": "figure/failure_conditioned_gain_20260504.pdf",
                "csv": str((OUT / "failure_conditioned_gain_20260504.csv").relative_to(ROOT)),
                "tex": str((OUT / "failure_conditioned_gain_figure_20260504.tex").relative_to(ROOT)),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
