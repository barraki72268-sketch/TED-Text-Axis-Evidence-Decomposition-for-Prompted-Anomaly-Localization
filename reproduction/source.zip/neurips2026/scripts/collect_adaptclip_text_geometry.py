from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
ADAPTCLIP_ROOT = ROOT / "neurips2026" / "AdaptCLIP"
if str(ADAPTCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ADAPTCLIP_ROOT))

import adaptcliplib  # noqa: E402
from adaptcliplib import TextualAdapter  # noqa: E402
from adaptcliplib.adaptclip import tokenize  # noqa: E402


def cosine(a: torch.Tensor, b: torch.Tensor) -> float:
    a = F.normalize(a.float(), dim=-1)
    b = F.normalize(b.float(), dim=-1)
    return float((a * b).sum().item())


def normal_basis(text_bank: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    text_bank = F.normalize(text_bank.float(), dim=-1)
    _, s, vh = torch.linalg.svd(text_bank, full_matrices=False)
    rank = int((s > eps).sum().item())
    if rank == 0:
        return text_bank.new_zeros((text_bank.shape[-1], 0))
    return vh[:rank].transpose(0, 1).contiguous()


def projection_energy(vec: torch.Tensor, basis: torch.Tensor) -> float:
    vec = F.normalize(vec.float(), dim=-1)
    if basis.shape[1] == 0:
        return 0.0
    coeff = vec @ basis
    return float(coeff.pow(2).sum().item())


def build_model(device: str, pretrained_model: str):
    model, _ = adaptcliplib.load(pretrained_model, device=device)
    model.eval()
    return model


def build_textual_adapter(model, img_size: int, n_ctx: int, ckpt_path: Path, device: str):
    adapter = TextualAdapter(model.to("cpu"), img_size, n_ctx)
    ckpt = torch.load(ckpt_path, map_location="cpu")
    adapter.load_state_dict(ckpt["textual_learner"], strict=True)
    adapter.to(device)
    adapter.eval()
    model.to(device)
    model.eval()
    return adapter


@torch.no_grad()
def get_learned_text_features(model, adapter):
    prompts, tokenized_prompts = adapter.forward()
    prompts = prompts.to(next(model.parameters()).device)
    tokenized_prompts = tokenized_prompts.to(next(model.parameters()).device)
    text_features = model.encode_text(prompts, tokenized_prompts).float()
    text_features = F.normalize(text_features, dim=-1)
    return text_features


def collect_one(model, adapter, series: str, epoch: int | None = None):
    learned = get_learned_text_features(model, adapter)
    learned_normal = learned[0]
    learned_anomaly = learned[1]

    normal_description, abnormal_description = adapter.prompt()
    dev = next(model.parameters()).device
    normal_tokens = tokenize(normal_description).to(dev)
    abnormal_tokens = tokenize(abnormal_description).to(dev)
    with torch.no_grad():
        normal_text_features = model.encode_text(normal_tokens).float()
        abnormal_text_features = model.encode_text(abnormal_tokens).float()

    normal_bank = F.normalize(normal_text_features, dim=-1).to(learned.device, learned.dtype)
    normal_anchor = F.normalize(normal_text_features.mean(dim=0), dim=-1).to(learned.device, learned.dtype)
    anomaly_anchor = F.normalize(abnormal_text_features.mean(dim=0), dim=-1).to(learned.device, learned.dtype)
    basis = normal_basis(normal_bank).to(learned.device)

    row = {
        "series": series,
        "epoch": epoch,
        "overlap_cos": cosine(learned_anomaly, learned_normal),
        "proj_energy_to_normal": projection_energy(learned_anomaly, basis),
        "anchor_retention_norm": cosine(learned_normal, normal_anchor),
        "anchor_retention_anom": cosine(learned_anomaly, anomaly_anchor),
    }
    return row


def save_rows(rows, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump(rows, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "series",
                "epoch",
                "overlap_cos",
                "proj_energy_to_normal",
                "anchor_retention_norm",
                "anchor_retention_anom",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def ckpt_sort_key(path: Path):
    stem = path.stem
    if stem.startswith("epoch_"):
        return int(stem.split("_")[-1])
    return stem


def collect_series(rows, model, img_size: int, n_ctx: int, device: str, series: str, ckpt_path: Path | None = None, ckpt_dir: Path | None = None):
    if ckpt_dir is not None and ckpt_dir.exists():
        for path in sorted(ckpt_dir.glob("epoch_*.pth"), key=ckpt_sort_key):
            adapter = build_textual_adapter(model, img_size, n_ctx, path, device)
            rows.append(collect_one(model, adapter, series, ckpt_sort_key(path)))
    elif ckpt_path is not None and ckpt_path.exists():
        epoch = ckpt_sort_key(ckpt_path) if ckpt_path.stem.startswith("epoch_") else None
        adapter = build_textual_adapter(model, img_size, n_ctx, ckpt_path, device)
        rows.append(collect_one(model, adapter, series, epoch))


def main():
    parser = argparse.ArgumentParser("Collect AdaptCLIP text-geometry metrics")
    parser.add_argument(
        "--baseline_ckpt",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_official_vitl336_mvtec2visa_seed10" / "checkpoints" / "epoch_7.pth"),
    )
    parser.add_argument(
        "--baseline_dir",
        type=str,
        default="",
    )
    parser.add_argument(
        "--ours_ckpt",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_textreg_vitl336_mvtec2visa_seed10" / "checkpoints" / "epoch_7.pth"),
    )
    parser.add_argument(
        "--ours_dir",
        type=str,
        default="",
    )
    parser.add_argument("--pretrained_model", type=str, default="ViT-L/14@336px")
    parser.add_argument("--img_size", type=int, default=518)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "adaptclip_text_geometry"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    rows = []
    model = build_model(args.device, args.pretrained_model)
    collect_series(
        rows,
        model,
        args.img_size,
        args.n_ctx,
        args.device,
        "baseline",
        ckpt_path=Path(args.baseline_ckpt),
        ckpt_dir=Path(args.baseline_dir) if args.baseline_dir else None,
    )
    collect_series(
        rows,
        model,
        args.img_size,
        args.n_ctx,
        args.device,
        "ours",
        ckpt_path=Path(args.ours_ckpt),
        ckpt_dir=Path(args.ours_dir) if args.ours_dir else None,
    )

    save_rows(rows, Path(args.save_dir))
    print(json.dumps({"rows": rows, "save_dir": args.save_dir}, indent=2))


if __name__ == "__main__":
    main()
