from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from WinCLIP import WinClipAD  # noqa: E402
from neurips2026.common_backbones.winclip_vit import WinClipRawBackbone  # noqa: E402
from neurips2026.scripts.identity_residual_extractor import IdentityResidualExtractor  # noqa: E402
from neurips2026.scripts.train_clip_aqm_oracle import (  # noqa: E402
    compute_consensus_loss,
    compute_zero_signal_loss,
    normalize_feat,
)
from neurips2026.scripts.train_clip_ksm_v2_oracle import safe_auc  # noqa: E402
from neurips2026.scripts.train_clip_ksm_v3_mvtec_to_visa import (  # noqa: E402
    collect_mvtec_train_records,
    collect_realiad_train_records,
    collect_visa_eval_records,
    materialize_record_batch,
)
from neurips2026.scripts.train_identity_residual_mvtec_to_visa_multilayer_joint import build_identity_prompt_bank  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402
from utils.metrics import metric_cal  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Train a WinCLIP-native IdentityResidual textual head.")
    parser.add_argument("--source_dataset", type=str, default="mvtec", choices=["mvtec", "realiad"])
    parser.add_argument("--mvtec_root", type=str, default="/mnt/data/gijeong/AnomalyCoT/MVTecAD")
    parser.add_argument("--realiad_root", type=str, default="/mnt/sda1/realiad_full")
    parser.add_argument("--visa_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--visa_split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument(
        "--source_classes",
        nargs="+",
        default=[
            "bottle",
            "cable",
            "capsule",
            "carpet",
            "hazelnut",
            "leather",
            "metal_nut",
            "pill",
            "screw",
            "tile",
            "transistor",
            "wood",
            "zipper",
        ],
    )
    parser.add_argument("--target_classes", nargs="+", default=["capsules", "candle"])
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_id_queries", type=int, default=32)
    parser.add_argument("--num_res_queries", type=int, default=32)
    parser.add_argument("--train_normal_images", type=int, default=-1)
    parser.add_argument("--train_anomaly_images", type=int, default=-1)
    parser.add_argument("--train_batch_size", type=int, default=64)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    parser.add_argument("--lambda_id", type=float, default=1.0)
    parser.add_argument("--lambda_res", type=float, default=1.0)
    parser.add_argument("--lambda_ortho", type=float, default=1.0)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--k_shot", type=int, default=5)
    parser.add_argument("--fusion_mode", type=str, default="harmonic", choices=["textual", "harmonic"])
    parser.add_argument("--pixel_blur_sigma", type=float, default=0.0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="winclip_identity_residual_mvtec2visa")
    return parser.parse_args()


def build_stock_winclip(args: argparse.Namespace, device: str) -> WinClipAD:
    model = WinClipAD(
        out_size_h=args.resolution,
        out_size_w=args.resolution,
        device=device,
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=tuple(args.scales),
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    ).to(device)
    model.eval_mode()
    model.fusion_version = "textual" if args.fusion_mode == "textual" else "textual_visual"
    return model


def build_prompt_condition_winclip(backbone: WinClipRawBackbone, class_name: str, device: str) -> dict[str, torch.Tensor]:
    normal_prompts, abnormal_prompts = build_identity_prompt_bank(class_name)
    tokens_norm = backbone.tokenizer(normal_prompts).to(device)
    tokens_anom = backbone.tokenizer(abnormal_prompts).to(device)
    with torch.no_grad():
        e_norm = backbone.model.encode_text(tokens_norm).float()
        e_anom = backbone.model.encode_text(tokens_anom).float()
    e_norm = F.normalize(e_norm, dim=-1)
    e_anom = F.normalize(e_anom, dim=-1)
    return {"E_norm": e_norm, "E_anom": e_anom}


def wrap_stock_backbone(model: WinClipAD, device: str) -> WinClipRawBackbone:
    return WinClipRawBackbone(
        clip_model=model.model,
        tokenizer=model.tokenizer,
        device=torch.device(device),
        image_transform=model.transform,
    )


def extract_window_tokens(stock: WinClipAD, image_t: torch.Tensor) -> list[torch.Tensor]:
    visual_features = stock.encode_image(image_t)
    return [feat.float() for feat in visual_features]


def stack_window_tokens(window_features: list[torch.Tensor]) -> torch.Tensor:
    return torch.stack(window_features, dim=1)


def compute_window_overlap_mask(patch_mask: np.ndarray, masks) -> np.ndarray:
    out = np.zeros((patch_mask.shape[0], len(masks)), dtype=np.int64)
    for idx, mask in enumerate(masks):
        patch_indices = np.asarray(mask).reshape(-1).astype(np.int64)
        if patch_indices.size == 0:
            continue
        out[:, idx] = (patch_mask[:, patch_indices].max(axis=1) > 0).astype(np.int64)
    return out


def scatter_window_scores_to_textual_map(
    window_scores: np.ndarray,
    masks,
    scale_begin_indx,
    grid_size: tuple[int, int],
    resolution: int,
) -> np.ndarray:
    batch_size = window_scores.shape[0]
    num_patches = int(grid_size[0] * grid_size[1])
    token_scores = np.zeros((batch_size, num_patches), dtype=np.float32)
    token_weights = np.zeros((batch_size, num_patches), dtype=np.float32)
    scale_maps = []

    for idx, mask in enumerate(masks):
        patch_indices = np.asarray(mask).reshape(-1).astype(np.int64)
        if idx in scale_begin_indx[1:]:
            token_scores = token_scores / np.clip(token_weights, 1e-6, None)
            scale_maps.append(token_scores)
            token_scores = np.zeros((batch_size, num_patches), dtype=np.float32)
            token_weights = np.zeros((batch_size, num_patches), dtype=np.float32)

        if patch_indices.size == 0:
            continue
        token_scores[:, patch_indices] += window_scores[:, idx][:, None]
        token_weights[:, patch_indices] += 1.0

    token_scores = token_scores / np.clip(token_weights, 1e-6, None)
    scale_maps.append(token_scores)
    fused = np.stack(scale_maps, axis=0).mean(axis=0).reshape(batch_size, grid_size[0], grid_size[1])
    fused_t = torch.from_numpy(fused).unsqueeze(1)
    full_res = F.interpolate(
        fused_t,
        size=(resolution, resolution),
        mode="bilinear",
        align_corners=False,
    )[:, 0]
    return full_res.numpy().astype(np.float32)


def resize_mask(mask_path: str | None, resolution: int) -> np.ndarray:
    if not mask_path:
        return np.zeros((resolution, resolution), dtype=np.uint8)
    mask = np.asarray(Image.open(mask_path).convert("L"), dtype=np.uint8)
    mask = (mask > 0).astype(np.uint8) * 255
    return (
        np.asarray(Image.fromarray(mask).resize((resolution, resolution), resample=Image.NEAREST)) > 0
    ).astype(np.uint8)


def build_class_batches(records, batch_size: int, rng: random.Random) -> list[list]:
    by_class: dict[str, list] = {}
    for rec in records:
        by_class.setdefault(rec.class_name, []).append(rec)
    batches: list[list] = []
    for class_name, class_records in by_class.items():
        class_records = class_records[:]
        rng.shuffle(class_records)
        for start in range(0, len(class_records), batch_size):
            batches.append(class_records[start : start + batch_size])
    rng.shuffle(batches)
    return batches


def compute_identity_support_loss(
    f_id: torch.Tensor,
    raw_windows: torch.Tensor,
    E_norm: torch.Tensor,
) -> torch.Tensor:
    raw_support = torch.matmul(normalize_feat(raw_windows), normalize_feat(E_norm).T).max(dim=-1).values.detach()
    raw_support = raw_support.clamp_min(0.0)
    if float(raw_support.sum().item()) <= 0.0:
        return torch.zeros([], device=f_id.device)
    id_support = torch.matmul(normalize_feat(f_id), normalize_feat(E_norm).T).max(dim=-1).values.clamp_min(0.0)
    return 1.0 - (id_support * raw_support).sum() / raw_support.sum().clamp_min(1e-6)


def compute_loss(
    outputs: dict[str, torch.Tensor],
    raw_windows: torch.Tensor,
    E_norm: torch.Tensor,
    E_anom: torch.Tensor,
    window_mask: torch.Tensor,
    args: argparse.Namespace,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    f_id = outputs["f_id"]
    f_res = outputs["f_res"]
    l_id = compute_identity_support_loss(f_id, raw_windows, E_norm)
    l_res = compute_consensus_loss(normalize_feat(f_res), normalize_feat(E_anom), window_mask, topk_ratio=args.topk_anom_ratio)
    l_ortho = outputs["loss_ortho"]
    l_zero = compute_zero_signal_loss(f_res, window_mask, args.hard_neg_ratio)
    total = (
        float(args.lambda_id) * l_id
        + float(args.lambda_res) * l_res
        + float(args.lambda_ortho) * l_ortho
        + float(args.lambda_zero) * l_zero
    )
    return total, {"l_id": l_id, "l_res": l_res, "l_ortho": l_ortho, "l_zero": l_zero}


def train_one_epoch(
    stock: WinClipAD,
    backbone: WinClipRawBackbone,
    model: IdentityResidualExtractor,
    prompt_cache: dict[str, dict[str, torch.Tensor]],
    train_records: list,
    args: argparse.Namespace,
    optimizer: torch.optim.Optimizer,
    device: str,
    epoch: int,
) -> dict[str, float]:
    model.train()
    rng = random.Random(args.seed + epoch)
    batches = build_class_batches(train_records, args.train_batch_size, rng)
    losses = []
    l_id_vals = []
    l_res_vals = []
    l_ortho_vals = []
    l_zero_vals = []

    for batch_records in batches:
        class_name = batch_records[0].class_name
        cond = prompt_cache[class_name]
        image_t, patch_mask = materialize_record_batch(backbone, batch_records)
        image_t = image_t.to(device=device, dtype=stock.model.visual.conv1.weight.dtype)
        window_features = extract_window_tokens(stock, image_t)
        window_tokens = stack_window_tokens(window_features)
        window_mask_np = compute_window_overlap_mask(patch_mask, stock.masks)
        window_mask = torch.from_numpy(window_mask_np).to(device=device)

        outputs = model(window_tokens, cond["E_norm"], E_anom=cond["E_anom"], return_aux=False)
        loss, loss_dict = compute_loss(outputs, window_tokens, cond["E_norm"], cond["E_anom"], window_mask, args)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

        losses.append(float(loss.item()))
        l_id_vals.append(float(loss_dict["l_id"].item()))
        l_res_vals.append(float(loss_dict["l_res"].item()))
        l_ortho_vals.append(float(loss_dict["l_ortho"].item()))
        l_zero_vals.append(float(loss_dict["l_zero"].item()))

    return {
        "train_loss": float(np.mean(losses)) if losses else float("nan"),
        "train_l_id": float(np.mean(l_id_vals)) if l_id_vals else float("nan"),
        "train_l_res": float(np.mean(l_res_vals)) if l_res_vals else float("nan"),
        "train_l_ortho": float(np.mean(l_ortho_vals)) if l_ortho_vals else float("nan"),
        "train_l_zero": float(np.mean(l_zero_vals)) if l_zero_vals else float("nan"),
    }


def build_visual_gallery(stock: WinClipAD, args: argparse.Namespace, class_name: str, device: str) -> None:
    stock.visual_gallery = None
    if args.fusion_mode != "harmonic" or args.k_shot <= 0:
        return
    train_ds = OfficialVisAWinClipDataset(args.visa_root, args.visa_split_csv, class_name, "train")
    train_imgs = []
    for rec in train_ds.records[: args.k_shot]:
        train_imgs.append(stock.transform(Image.open(rec["image_path"]).convert("RGB")))
    if not train_imgs:
        return
    gallery_batch = torch.stack(train_imgs, dim=0).to(
        device=device,
        dtype=stock.model.visual.conv1.weight.dtype,
    )
    stock.build_image_feature_gallery(gallery_batch)


def evaluate_target_class(
    stock: WinClipAD,
    backbone: WinClipRawBackbone,
    model: IdentityResidualExtractor,
    cond: dict[str, torch.Tensor],
    eval_records: list,
    args: argparse.Namespace,
    device: str,
) -> dict[str, float]:
    model.eval()
    stock.eval_mode()
    image_labels = []
    gt_masks = []
    baseline_maps = []
    model_maps = []
    ortho_vals = []

    with torch.no_grad():
        for start in range(0, len(eval_records), args.eval_batch_size):
            batch_records = eval_records[start : start + args.eval_batch_size]
            image_t, patch_mask = materialize_record_batch(backbone, batch_records)
            image_t = image_t.to(device=device, dtype=stock.model.visual.conv1.weight.dtype)

            baseline_batch = stock(image_t)
            visual_features = extract_window_tokens(stock, image_t)
            window_tokens = stack_window_tokens(visual_features)
            outputs = model(window_tokens, cond["E_norm"], E_anom=cond["E_anom"], return_aux=False)
            ortho_vals.append(float(outputs["loss_ortho"].item()))
            textual_map = scatter_window_scores_to_textual_map(
                outputs["score"].detach().cpu().numpy(),
                stock.masks,
                stock.scale_begin_indx,
                stock.grid_size,
                args.resolution,
            )

            if args.fusion_mode == "harmonic" and stock.visual_gallery is not None:
                visual_features_fp = [feat.to(dtype=stock.visual_gallery[0].dtype) for feat in visual_features]
                visual_map = stock.calculate_visual_anomaly_score(visual_features_fp)
                visual_map = F.interpolate(
                    visual_map,
                    size=(args.resolution, args.resolution),
                    mode="bilinear",
                    align_corners=False,
                )[:, 0].cpu().numpy()
                eps = 1e-6
                fused_map = 1.0 / (1.0 / np.clip(textual_map, eps, None) + 1.0 / np.clip(visual_map, eps, None))
            else:
                fused_map = textual_map

            for b_idx, rec in enumerate(batch_records):
                image_labels.append(int(rec.label != 0))
                gt_masks.append(resize_mask(getattr(rec, "mask_path", None), args.resolution))
                baseline_maps.append(np.asarray(baseline_batch[b_idx], dtype=np.float32))
                model_maps.append(np.asarray(fused_map[b_idx], dtype=np.float32))

    baseline_scores = np.stack(baseline_maps, axis=0)
    model_scores = np.stack(model_maps, axis=0)
    baseline_metrics = metric_cal(baseline_scores, image_labels, gt_masks, cal_pro=True)
    model_metrics = metric_cal(model_scores, image_labels, gt_masks, cal_pro=True)
    return {
        "baseline_i_roc": float(baseline_metrics["i_roc"]),
        "baseline_p_roc": float(baseline_metrics["p_roc"]),
        "baseline_p_pro": float(baseline_metrics["p_pro"]),
        "idres_i_roc": float(model_metrics["i_roc"]),
        "idres_p_roc": float(model_metrics["p_roc"]),
        "idres_p_pro": float(model_metrics["p_pro"]),
        "delta_i_roc": float(model_metrics["i_roc"] - baseline_metrics["i_roc"]),
        "delta_p_roc": float(model_metrics["p_roc"] - baseline_metrics["p_roc"]),
        "delta_p_pro": float(model_metrics["p_pro"] - baseline_metrics["p_pro"]),
        "eval_loss_ortho": float(np.mean(ortho_vals)) if ortho_vals else float("nan"),
    }


def main() -> None:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    stock = build_stock_winclip(args, device)
    backbone = wrap_stock_backbone(stock, device)
    for p in stock.parameters():
        p.requires_grad_(False)

    if args.source_dataset == "mvtec":
        train_records = collect_mvtec_train_records(backbone, args)
        source_class_names = list(args.source_classes)
    else:
        train_records = collect_realiad_train_records(backbone, args)
        source_class_names = sorted({rec.class_name for rec in train_records})

    prompt_cache = {class_name: build_prompt_condition_winclip(backbone, class_name, device) for class_name in source_class_names}
    target_prompt_cache = {class_name: build_prompt_condition_winclip(backbone, class_name, device) for class_name in args.target_classes}
    dim = int(next(iter(prompt_cache.values()))["E_norm"].shape[1])
    model = IdentityResidualExtractor(
        dim=dim,
        num_id_queries=args.num_id_queries,
        num_res_queries=args.num_res_queries,
        detach_residual_input=True,
    ).to(device)

    token_params = [model.query_id, model.query_res]
    other_params = [p for n, p in model.named_parameters() if n not in {"query_id", "query_res"}]
    optimizer = torch.optim.AdamW(
        [
            {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
            {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
        ]
    )

    print(
        f"[setup] source_dataset={args.source_dataset} source_classes={len(source_class_names)} "
        f"source_records={len(train_records)} target_classes={len(args.target_classes)} "
        f"fusion_mode={args.fusion_mode}"
    )

    history = []
    for epoch in range(1, args.epochs + 1):
        stats = train_one_epoch(stock, backbone, model, prompt_cache, train_records, args, optimizer, device, epoch)
        history.append({"epoch": epoch, **stats})
        print(
            f"[epoch {epoch}/{args.epochs}] loss={stats['train_loss']:.6f} "
            f"id={stats['train_l_id']:.6f} res={stats['train_l_res']:.6f} "
            f"ortho={stats['train_l_ortho']:.6f} zero={stats['train_l_zero']:.6f}"
        )

    rows = []
    for class_name in args.target_classes:
        stock.build_text_feature_gallery(class_name)
        build_visual_gallery(stock, args, class_name, device)
        eval_records = collect_visa_eval_records(backbone, class_name, args)
        eval_stats = evaluate_target_class(
            stock,
            backbone,
            model,
            target_prompt_cache[class_name],
            eval_records,
            args,
            device,
        )
        rows.append(
            {
                "class_name": class_name,
                "backbone": args.backbone,
                "pretrained": args.pretrained_dataset,
                "epochs": args.epochs,
                "source_dataset": args.source_dataset,
                "source_classes": len(source_class_names),
                "source_train_records": len(train_records),
                "fusion_mode": args.fusion_mode,
                "k_shot": args.k_shot,
                **history[-1],
                **eval_stats,
            }
        )

    stem = f"{args.output_tag}_{args.backbone}_{args.fusion_mode}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    ckpt_path = out_dir / f"{stem}_checkpoint.pt"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump({"args": vars(args), "history": history, "rows": rows}, f, indent=2)
    torch.save({"args": vars(args), "history": history, "state_dict": model.state_dict()}, ckpt_path)
    print(csv_path)
    print(json_path)
    print(ckpt_path)


if __name__ == "__main__":
    main()
