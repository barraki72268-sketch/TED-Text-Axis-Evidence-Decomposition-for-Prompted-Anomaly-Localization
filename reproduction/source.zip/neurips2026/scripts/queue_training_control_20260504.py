#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "training_control_20260504"
LOGS = ROOT / "neurips2026" / "logs" / "training_control_20260504"


VARIANTS = {
    "correct": {
        "pair_label_control": "correct",
        "subspace_basis_control": "source",
    },
    "label_shuffle": {
        "pair_label_control": "shuffle",
        "subspace_basis_control": "source",
    },
    "label_swap": {
        "pair_label_control": "swap",
        "subspace_basis_control": "source",
    },
    "random_subspace": {
        "pair_label_control": "correct",
        "subspace_basis_control": "random",
    },
}


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_cmd(variant: str, preset: str, device: str, seed: int) -> tuple[list[str], Path]:
    return build_aaclip_cmd(variant, preset, device, seed)


def build_aaclip_cmd(variant: str, preset: str, device: str, seed: int) -> tuple[list[str], Path]:
    if variant not in VARIANTS:
        raise SystemExit(f"Unsupported variant={variant}; allowed={sorted(VARIANTS)}")
    cfg = VARIANTS[variant]
    save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_{variant}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=1.0",
        "--blend_modes",
        "prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_subspace_basis_control",
        cfg["subspace_basis_control"],
        "--prescore_calib_pair_label_control",
        cfg["pair_label_control"],
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir


def build_faprompt_cmd(variant: str, preset: str, device: str, seed: int) -> tuple[list[str], Path]:
    if variant not in VARIANTS:
        raise SystemExit(f"Unsupported variant={variant}; allowed={sorted(VARIANTS)}")
    cfg = VARIANTS[variant]
    save_dir = RESULTS / f"faprompt_vitl336_{preset}_{variant}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_subspace_basis_control",
        cfg["subspace_basis_control"],
        "--prescore_calib_pair_label_control",
        cfg["pair_label_control"],
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]
    return cmd, save_dir


def build_adaclip_cmd(variant: str, preset: str, device: str, seed: int) -> tuple[list[str], Path]:
    if variant not in VARIANTS:
        raise SystemExit(f"Unsupported variant={variant}; allowed={sorted(VARIANTS)}")
    cfg = VARIANTS[variant]
    source_cfg = {
        "mvtec": {
            "root": ROOT / "neurips2026" / "data" / "mvtec",
            "fallback_root": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
            "ckpt": ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_mvtec_colondb.pth",
            "bank": ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_mvtec_full_multilayer.pt",
        },
        "visa": {
            "root": ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls",
            "fallback_root": ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls",
            "ckpt": ROOT / "neurips2026" / "AdaCLIP" / "ckpt" / "pretrained_visa_clinicdb.pth",
            "bank": ROOT / "neurips2026" / "results" / "bank_cache" / "adaclip_visa_official1cls_multilayer.pt",
        },
    }
    target_roots = {
        "mvtec": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
        "visa": ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls",
        "mpdd": Path("/mnt/data/MPDD"),
        "btad": ROOT / "neurips2026" / "data" / "BTAD_official",
    }
    if "2" not in preset:
        raise SystemExit(f"Unsupported AdaCLIP preset={preset}; expected source2target")
    source_dataset, target_dataset = preset.split("2", 1)
    if source_dataset not in source_cfg or target_dataset not in target_roots:
        raise SystemExit(f"Unsupported AdaCLIP preset={preset}")
    src = source_cfg[source_dataset]
    source_root = src["root"] if src["root"].exists() else src["fallback_root"]
    save_dir = RESULTS / f"adaclip_vitl336_{preset}_{variant}_seed{seed}"
    cmd = [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_adaclip.py",
        "--source_root",
        str(source_root),
        "--source_dataset",
        source_dataset,
        "--target_root",
        str(target_roots[target_dataset]),
        "--target_dataset",
        target_dataset,
        "--checkpoint_path",
        str(src["ckpt"]),
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
        "--bank_cache_path",
        str(src["bank"]),
        "--backbone",
        "ViT-L-14-336",
        "--checkpoint_load_mode",
        "strict",
        "--image_size",
        "518",
        "--sigma",
        "4",
        "--prompting_depth",
        "4",
        "--prompting_length",
        "5",
        "--prompting_branch",
        "VL",
        "--prompting_type",
        "SD",
        "--use_hsf",
        "true",
        "--k_clusters",
        "20",
        "--max_good_per_class",
        "2",
        "--max_defect_per_class",
        "4",
        "--max_bank_per_layer",
        "512",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "64",
        "--layer_recipe",
        "all4",
        "--batch_size",
        "1",
        "--num_workers",
        "4",
        "--cpu_threads",
        "2",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--enable_calibrator",
        "--calib_epochs",
        "30",
        "--calib_lr",
        "0.02",
        "--calib_max_train_points",
        "2048",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_eta_init",
        "0.2",
        "--calib_eta_max",
        "1.0",
        "--calib_eta_reg",
        "0.001",
        "--calib_fp_weight_init",
        "1.0",
        "--calib_hardpair_frac",
        "0.75",
        "--calib_subspace_rank",
        "8",
        "--calib_subspace_basis_control",
        cfg["subspace_basis_control"],
        "--calib_pair_label_control",
        cfg["pair_label_control"],
        "--calib_preserve_host_margin_weight",
        "1.0",
        "--calib_lambda",
        "0.3",
        "--calib_gate_mode",
        "host",
        "--calib_insertion_mode",
        "prescore_rectify",
        "--calib_train_score_space",
        "cache_prob",
        "--scoring_mode",
        "logit_gate_posneg",
        "--ours_image_score_mode",
        "official_plus_map_topk",
        "--image_topk_frac",
        "0.01",
        "--eval_metrics",
        "I-AUROC",
        "I-AP",
        "P-AUROC",
        "P-AP",
        "P-AUPRO",
        "--aupro_max_step",
        "200",
        "--seed",
        str(seed),
        "--device",
        device,
    ]
    return cmd, save_dir


def launch(cmd: list[str], save_dir: Path, log_path: Path, force: bool) -> dict:
    summary = save_dir / "summary.json"
    if summary.exists() and not force:
        return {"stage": "skip_done", "summary": str(summary)}
    save_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = log_path.open("ab", buffering=0)
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        stdout=log_f,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {"stage": "launched", "pid": proc.pid, "save_dir": str(save_dir), "log": str(log_path)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--presets", default="mvtec2btad")
    ap.add_argument("--hosts", default="aaclip")
    ap.add_argument("--variants", default="label_shuffle,label_swap,random_subspace")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    presets = parse_csv(args.presets)
    hosts = parse_csv(args.hosts)
    variants = parse_csv(args.variants)
    devices = parse_csv(args.devices)
    if not devices:
        raise SystemExit("--devices cannot be empty")

    jobs = []
    builders = {
        "aaclip": build_aaclip_cmd,
        "adaclip": build_adaclip_cmd,
        "faprompt": build_faprompt_cmd,
    }
    for host in hosts:
        if host not in builders:
            raise SystemExit(f"Unsupported host={host}; allowed={sorted(builders)}")
        for preset in presets:
            for variant in variants:
                device = devices[len(jobs) % len(devices)]
                cmd, save_dir = builders[host](variant, preset, device, args.seed)
                log_path = LOGS / f"{save_dir.name}.log"
                jobs.append((cmd, save_dir, log_path))

    launched = [launch(cmd, save_dir, log_path, args.force) for cmd, save_dir, log_path in jobs]
    print(json.dumps({"stage": "training_control_queue", "jobs": launched}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
