#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results" / "source_readout_extra_baselines_20260506"
LOGS = ROOT / "neurips2026" / "logs" / "source_readout_extra_baselines_20260506"

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]


def faprompt_base(preset: str, device: str, seed: int, save_dir: Path, plugin_loss: str) -> list[str]:
    return [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L/14@336px",
        "--prompt_load_mode",
        "strict",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "20",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--source_fp_mode",
        "hardfp",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "plugin_replace,plugin_residual,branch_calibrated",
        "--plugin_epochs",
        "40",
        "--plugin_lr",
        "0.01",
        "--plugin_max_train_points",
        "4096",
        "--plugin_loss",
        plugin_loss,
        "--plugin_feature_space",
        "axis",
        "--plugin_rank_margin",
        "0.05",
        "--plugin_rank_temp",
        "0.05",
        "--plugin_hidden_dim",
        "32",
        "--plugin_gate_topk_frac",
        "0.10",
        "--plugin_gate_sharpness",
        "6.0",
        "--plugin_ambiguity_temp",
        "0.5",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--aupro_max_step",
        "50",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]


def aaclip_base(preset: str, device: str, seed: int, save_dir: Path, plugin_loss: str) -> list[str]:
    return [
        str(PY),
        "-u",
        "neurips2026/scripts/official_parallel_test_aaclip.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-L-14-336",
        "--pretrained",
        "openai",
        "--adapter_load_mode",
        "strict",
        "--levels",
        "6,12,18,24",
        "--img_size",
        "224",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--normal_topk_frac",
        "0.01",
        "--defect_topk_frac",
        "0.25",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas=0.5",
        "--blend_modes",
        "plugin_replace,plugin_residual,prescore_calibrated",
        "--candidate_topk_frac",
        "0.10",
        "--gate_sharpness",
        "3.0",
        "--candidate_image_mode",
        "baseline_plus_map_topk",
        "--cal_pro",
        "--aupro_max_step",
        "50",
        "--report_group_separability",
        "--separability_hard_frac",
        "0.01",
        "--plugin_epochs",
        "40",
        "--plugin_lr",
        "0.01",
        "--plugin_max_train_points",
        "8192",
        "--plugin_loss",
        plugin_loss,
        "--plugin_rank_margin",
        "0.05",
        "--plugin_rank_temp",
        "0.05",
        "--plugin_hidden_dim",
        "32",
        "--prescore_calib_transport_mode",
        "subspace_tanh",
        "--prescore_calib_subspace_rank",
        "8",
        "--prescore_calib_subspace_readout_mode",
        "host_residual",
        "--prescore_calib_subspace_basis_control",
        "source",
        "--prescore_calib_pair_label_control",
        "correct",
        "--prescore_calib_output_mode",
        "host_residual",
        "--prescore_calib_preserve_host_margin_weight",
        "1.0",
        "--prescore_calib_epochs",
        "20",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "8192",
        "--prescore_calib_rank_margin",
        "0.05",
        "--prescore_calib_rank_temp",
        "0.05",
        "--prescore_calib_alpha_init",
        "0.2",
        "--prescore_calib_alpha_max",
        "1.0",
        "--prescore_calib_alpha_reg",
        "0.001",
        "--prescore_calib_hardpair_frac",
        "0.75",
        "--prescore_calib_learn_fp_weight",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir.relative_to(ROOT)),
    ]


def build_jobs(hosts: list[str], variants: list[str], presets: list[str], devices: list[str], seed: int) -> list[dict]:
    jobs: list[dict] = []
    for variant in variants:
        for preset in presets:
            if "faprompt" in hosts:
                if variant == "mlp_rank":
                    loss = "pair_rank"
                elif variant == "support_affine":
                    loss = "support_rank"
                else:
                    raise ValueError(f"Unsupported FAPrompt variant: {variant}")
                device = devices[len(jobs) % len(devices)]
                save_dir = RESULTS / f"faprompt_vitl336_{preset}_{variant}_seed{seed}"
                cmd = faprompt_base(preset, device, seed, save_dir, loss)
                jobs.append({"host": "faprompt", "variant": variant, "preset": preset, "cmd": cmd, "save_dir": save_dir})
            if "aaclip" in hosts:
                if variant == "mlp_rank":
                    loss = "pair_rank"
                elif variant == "support_affine":
                    loss = "support_rank"
                else:
                    raise ValueError(f"Unsupported AA-CLIP variant: {variant}")
                device = devices[len(jobs) % len(devices)]
                save_dir = RESULTS / f"aaclip_vitl_openai224_{preset}_{variant}_seed{seed}"
                cmd = aaclip_base(preset, device, seed, save_dir, loss)
                jobs.append({"host": "aaclip", "variant": variant, "preset": preset, "cmd": cmd, "save_dir": save_dir})
    return jobs


def write_worker(jobs: list[dict], worker_id: int, force: bool) -> Path:
    worker_path = LOGS / f"worker_{worker_id}.py"
    lines = [
        "from __future__ import annotations",
        "import subprocess, time",
        "from pathlib import Path",
        f"ROOT = Path({str(ROOT)!r})",
        f"FORCE = {bool(force)!r}",
        "jobs = [",
    ]
    for job in jobs:
        log_path = LOGS / f"{job['save_dir'].name}.log"
        lines.append(
            "    "
            + repr(
                {
                    "host": job["host"],
                    "variant": job["variant"],
                    "preset": job["preset"],
                    "cmd": job["cmd"],
                    "save_dir": str(job["save_dir"]),
                    "log_path": str(log_path),
                }
            )
            + ","
        )
    lines += [
        "]",
        "for job in jobs:",
        "    save_dir = Path(job['save_dir'])",
        "    summary = save_dir / 'summary.json'",
        "    log_path = Path(job['log_path'])",
        "    log_path.parent.mkdir(parents=True, exist_ok=True)",
        "    if summary.exists() and not FORCE:",
        "        print({'stage': 'skip_done', **{k: job[k] for k in ('host', 'variant', 'preset')}, 'summary': str(summary)}, flush=True)",
        "        continue",
        "    save_dir.mkdir(parents=True, exist_ok=True)",
        "    print({'stage': 'job_start', **{k: job[k] for k in ('host', 'variant', 'preset')}, 'save_dir': str(save_dir), 'log': str(log_path)}, flush=True)",
        "    start = time.time()",
        "    with log_path.open('w') as f:",
        "        proc = subprocess.run(job['cmd'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)",
        "    print({'stage': 'job_done', **{k: job[k] for k in ('host', 'variant', 'preset')}, 'returncode': proc.returncode, 'elapsed_sec': time.time() - start}, flush=True)",
        "print({'stage': 'worker_done'}, flush=True)",
        "",
    ]
    worker_path.write_text("\n".join(lines))
    return worker_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hosts", default="faprompt,aaclip")
    ap.add_argument("--variants", default="mlp_rank,support_affine")
    ap.add_argument("--presets", default="visa2mvtec,mvtec2visa,mvtec2mpdd,mvtec2btad")
    ap.add_argument("--devices", default="cuda:0,cuda:1")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    hosts = [x.strip().lower() for x in args.hosts.split(",") if x.strip()]
    variants = [x.strip().lower() for x in args.variants.split(",") if x.strip()]
    presets = [x.strip().lower() for x in args.presets.split(",") if x.strip()]
    devices = [x.strip() for x in args.devices.split(",") if x.strip()]
    unknown_hosts = set(hosts) - {"faprompt", "aaclip"}
    unknown_variants = set(variants) - {"mlp_rank", "support_affine"}
    unknown_presets = set(presets) - set(PRESETS)
    if unknown_hosts:
        raise SystemExit(f"Unknown hosts={sorted(unknown_hosts)}")
    if unknown_variants:
        raise SystemExit(f"Unknown variants={sorted(unknown_variants)}")
    if unknown_presets:
        raise SystemExit(f"Unknown presets={sorted(unknown_presets)}")
    if not devices:
        raise SystemExit("No devices provided")

    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    jobs = build_jobs(hosts, variants, presets, devices, args.seed)
    buckets = [[] for _ in devices]
    for idx, job in enumerate(jobs):
        buckets[idx % len(buckets)].append(job)

    launched = []
    for worker_id, bucket in enumerate(buckets):
        if not bucket:
            continue
        worker_path = write_worker(bucket, worker_id, args.force)
        worker_log = LOGS / f"worker_{worker_id}.log"
        with worker_log.open("a") as f:
            proc = subprocess.Popen([str(PY), "-u", str(worker_path)], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        launched.append({"pid": proc.pid, "jobs": len(bucket), "worker": str(worker_path), "log": str(worker_log)})

    print(json.dumps({"stage": "queued_source_readout_extra_baselines", "launched": launched, "num_jobs": len(jobs)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
