from __future__ import annotations

import argparse
import os
import subprocess
import time
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
PY = "/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT = ROOT / "neurips2026/scripts/probe_bayespfl_ted_smoke.py"
OUT = ROOT / "neurips2026/results/bayespfl_pair_axis_sweep_20260503"

MVTEC_ROOT = "/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"
BTAD_ROOT = str(ROOT / "neurips2026/data/BTAD_official")
CKPT = str(ROOT / "neurips2026/results/bayespfl_strict_mvtec/epoch_post_15_1.pth")
CONFIG = str(ROOT / "neurips2026/Bayes-PFL/open_clip_local/model_configs/ViT-L-14-336.json")
PRETRAINED = "/mnt/data/hf-cache/anomalyclip/ViT-L-14-336px.pt"
BANK_CACHE = str(OUT / "mvtec_fullsource_bank.pt")


VARIANTS = [
    {
        "name": "mean_post_current",
        "axis": "mean",
        "insertion": "post_map",
        "combine": "residual",
        "sign": "def_minus_fp",
        "activation": "sigmoid",
        "alpha": "0.05",
        "eta_init": "0.01",
        "eta_max": "0.05",
    },
    {
        "name": "pair_post_alpha005",
        "axis": "pair_ensemble",
        "insertion": "post_map",
        "combine": "residual",
        "sign": "def_minus_fp",
        "activation": "sigmoid",
        "alpha": "0.05",
        "eta_init": "0.01",
        "eta_max": "0.05",
    },
    {
        "name": "pair_post_alpha02",
        "axis": "pair_ensemble",
        "insertion": "post_map",
        "combine": "residual",
        "sign": "def_minus_fp",
        "activation": "sigmoid",
        "alpha": "0.20",
        "eta_init": "0.05",
        "eta_max": "0.20",
    },
    {
        "name": "pair_post_fpminus_alpha02",
        "axis": "pair_ensemble",
        "insertion": "post_map",
        "combine": "residual",
        "sign": "fp_minus_def",
        "activation": "sigmoid",
        "alpha": "0.20",
        "eta_init": "0.05",
        "eta_max": "0.20",
    },
    {
        "name": "pair_blend_alpha02",
        "axis": "pair_ensemble",
        "insertion": "post_map",
        "combine": "blend",
        "sign": "def_minus_fp",
        "activation": "sigmoid",
        "alpha": "0.20",
        "eta_init": "0.05",
        "eta_max": "0.20",
    },
    {
        "name": "pair_replace_sigmoid",
        "axis": "pair_ensemble",
        "insertion": "post_map",
        "combine": "replace",
        "sign": "def_minus_fp",
        "activation": "sigmoid",
        "alpha": "1.00",
        "eta_init": "0.05",
        "eta_max": "0.20",
    },
    {
        "name": "pair_pre_alpha005",
        "axis": "pair_ensemble",
        "insertion": "pre_softmax",
        "combine": "residual",
        "sign": "def_minus_fp",
        "activation": "sigmoid",
        "alpha": "0.05",
        "eta_init": "0.01",
        "eta_max": "0.05",
    },
    {
        "name": "pair_pre_fpminus_alpha005",
        "axis": "pair_ensemble",
        "insertion": "pre_softmax",
        "combine": "residual",
        "sign": "fp_minus_def",
        "activation": "sigmoid",
        "alpha": "0.05",
        "eta_init": "0.01",
        "eta_max": "0.05",
    },
]


def wait_pid(pid: int) -> None:
    if not pid:
        return
    print({"stage": "wait_pid", "pid": pid}, flush=True)
    while Path(f"/proc/{pid}").exists():
        time.sleep(30)
    print({"stage": "wait_pid_done", "pid": pid}, flush=True)


def build_cmd(variant: dict[str, str]) -> list[str]:
    return [
        PY,
        "-u",
        str(SCRIPT),
        "--dataset",
        "mvtec",
        "--data_path",
        MVTEC_ROOT,
        "--target_dataset",
        "btad",
        "--target_data_path",
        BTAD_ROOT,
        "--target_class",
        "01",
        "--checkpoint_path",
        CKPT,
        "--config_path",
        CONFIG,
        "--pretrained_path",
        PRETRAINED,
        "--image_size",
        "518",
        "--features_list",
        "6",
        "12",
        "18",
        "24",
        "--device_id",
        "0",
        "--seed",
        "0",
        "--sample_num",
        "10",
        "--max_good_per_class",
        "8",
        "--max_defect_per_class",
        "8",
        "--max_bank_per_layer",
        "1024",
        "--max_fp_per_image",
        "64",
        "--max_defect_per_image",
        "128",
        "--bank_cache_path",
        BANK_CACHE,
        "--hard_frac",
        "0.01",
        "--tau",
        "20.0",
        "--fp_weight",
        "1.0",
        "--margin_sign",
        variant["sign"],
        "--ted_axis_mode",
        variant["axis"],
        "--map_activation",
        variant["activation"],
        "--ted_combine",
        variant["combine"],
        "--ted_insertion",
        variant["insertion"],
        "--ted_alpha",
        variant["alpha"],
        "--enable_calibrator",
        "--calib_epochs",
        "40",
        "--calib_lr",
        "0.02",
        "--calib_eta_init",
        variant["eta_init"],
        "--calib_eta_max",
        variant["eta_max"],
        "--calib_eta_reg",
        "1e-3",
        "--calib_rank_margin",
        "0.05",
        "--calib_rank_temp",
        "0.05",
        "--calib_hard_frac",
        "0.01",
        "--calib_max_good_per_class",
        "8",
        "--calib_max_defect_per_class",
        "8",
        "--calib_max_fp_per_image",
        "64",
        "--calib_max_defect_per_image",
        "128",
        "--calib_max_train_points",
        "8192",
        "--image_topk",
        "0.01",
        "--metric_sigma",
        "8",
        "--image_score_mode",
        "official_fused",
        "--image_fusion_alpha",
        "0.5",
        "--aupro_max_step",
        "120",
        "--max_normal_eval",
        "8",
        "--max_anomaly_eval",
        "8",
        "--save_dir",
        str(OUT / variant["name"]),
    ]


def main() -> None:
    parser = argparse.ArgumentParser("Queue BayesPFL pair-axis TED sweep.")
    parser.add_argument("--gpu", default="0")
    parser.add_argument("--wait_pid", type=int, default=0)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    wait_pid(args.wait_pid)
    OUT.mkdir(parents=True, exist_ok=True)
    log_root = OUT / "_logs"
    log_root.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    env["PYTHONUNBUFFERED"] = "1"
    for variant in VARIANTS:
        save_dir = OUT / variant["name"]
        if (save_dir / "summary.json").exists() and not args.force:
            print({"stage": "skip_existing", "variant": variant["name"]}, flush=True)
            continue
        log_path = log_root / f"{variant['name']}.log"
        print({"stage": "start", "variant": variant["name"], "log": str(log_path)}, flush=True)
        with log_path.open("w") as log:
            proc = subprocess.run(
                build_cmd(variant),
                cwd=str(ROOT),
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
            )
        print({"stage": "done", "variant": variant["name"], "returncode": proc.returncode, "log": str(log_path)}, flush=True)
        if proc.returncode != 0:
            raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
