from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.WinClip.WinCLIP.ad_prompts import (  # noqa: E402
    state_level_abnormal_prompts,
    state_level_normal_prompts,
    template_level_prompts,
)
from neurips2026.common_backbones import create_winclip_raw_backbone  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="*", default=[])
    parser.add_argument("--target_layers", nargs="*", type=int, default=[3, 6, 9, 12])
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--max_normal_images", type=int, default=0)
    parser.add_argument("--max_anomaly_images", type=int, default=0)
    parser.add_argument("--max_k", type=int, default=6)
    parser.add_argument("--principal_k", type=int, default=4)
    parser.add_argument("--num_splits", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_kinematic_split_upper")
    return parser.parse_args()


def list_all_classes(split_csv: str) -> list[str]:
    classes: list[str] = []
    seen: set[str] = set()
    with open(split_csv, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cls = row["object"]
            if cls not in seen:
                seen.add(cls)
                classes.append(cls)
    return classes


def build_text_anchor(backbone, class_name: str, abnormal: bool) -> torch.Tensor:
    state_prompts = state_level_abnormal_prompts if abnormal else state_level_normal_prompts
    class_text = class_name.replace("_", " ")
    prompts: list[str] = []
    for template in template_level_prompts:
        for state_prompt in state_prompts:
            prompts.append(template.format(state_prompt.format(class_text)))
    text = backbone.tokenizer(prompts).to(backbone.device)
    with torch.no_grad():
        text_features = backbone.encode_text(text).float()
    text_features = F.normalize(text_features, dim=-1)
    text_anchor = F.normalize(text_features.mean(dim=0), dim=0)
    proj = getattr(backbone.visual, "proj", None)
    if proj is None:
        return text_anchor.cpu()
    token_anchor = proj.detach().float().to(text_anchor.device) @ text_anchor
    return F.normalize(token_anchor, dim=0).cpu()


def to_patch_mask(mask_np: np.ndarray, grid_size: tuple[int, int], device: str) -> np.ndarray:
    mask_arr = (np.asarray(mask_np) > 0).astype(np.float32)
    mask_t = torch.from_numpy(mask_arr).unsqueeze(0).unsqueeze(0).to(device)
    return (
        F.interpolate(mask_t, size=grid_size, mode="nearest")[0, 0]
        .reshape(-1)
        .cpu()
        .numpy()
        .astype(np.int64)
    )


def project_null_space(v: torch.Tensor, p_norm: torch.Tensor) -> torch.Tensor:
    proj = (v @ p_norm).unsqueeze(1) * p_norm.unsqueeze(0)
    return v - proj


def safe_auc(norm_scores: torch.Tensor, anom_scores: torch.Tensor) -> float:
    if norm_scores.numel() == 0 or anom_scores.numel() == 0:
        return float("nan")
    y_true = np.concatenate(
        [
            np.zeros(norm_scores.shape[0], dtype=np.int64),
            np.ones(anom_scores.shape[0], dtype=np.int64),
        ]
    )
    y_score = np.concatenate(
        [
            norm_scores.detach().cpu().numpy().astype(np.float64),
            anom_scores.detach().cpu().numpy().astype(np.float64),
        ]
    )
    return float(roc_auc_score(y_true, y_score))


def compute_basis(anom_residuals: torch.Tensor, max_k: int) -> tuple[torch.Tensor, torch.Tensor]:
    centered = anom_residuals - anom_residuals.mean(dim=0, keepdim=True)
    _, s, vh = torch.linalg.svd(centered, full_matrices=False)
    basis = vh[:max_k].T.contiguous() if vh.ndim == 2 else torch.empty(anom_residuals.shape[1], 0)
    return basis, s


def score_with_basis(norm_residuals: torch.Tensor, anom_residuals: torch.Tensor, basis: torch.Tensor, k: int) -> tuple[float, float, float]:
    if basis.numel() == 0:
        return float("nan"), float("nan"), float("nan")
    v_sub = basis[:, :k]
    if v_sub.numel() == 0:
        return float("nan"), float("nan"), float("nan")
    if k == 1:
        axis = v_sub[:, 0]
        if (anom_residuals.mean(dim=0) @ axis) < 0:
            axis = -axis
        norm_scores = norm_residuals @ axis
        anom_scores = anom_residuals @ axis
    else:
        norm_scores = torch.linalg.vector_norm(norm_residuals @ v_sub, dim=-1)
        anom_scores = torch.linalg.vector_norm(anom_residuals @ v_sub, dim=-1)
    auc = safe_auc(norm_scores, anom_scores)
    return auc, float(norm_scores.mean().item()), float(anom_scores.mean().item())


def principal_angle_similarity(basis_a: torch.Tensor, basis_b: torch.Tensor, k: int) -> tuple[float, float]:
    if basis_a.numel() == 0 or basis_b.numel() == 0:
        return float("nan"), float("nan")
    ua = basis_a[:, :k]
    ub = basis_b[:, :k]
    if ua.shape[1] == 0 or ub.shape[1] == 0:
        return float("nan"), float("nan")
    m = ua.T @ ub
    sigma = torch.linalg.svdvals(m)
    return float(sigma.mean().item()), float(sigma.min().item())


def maybe_limit(indices: list[int], max_images: int) -> list[int]:
    if max_images <= 0:
        return indices
    return indices[: min(len(indices), int(max_images))]


def collect_class_image_tokens(backbone, class_name: str, layers: list[int], args: argparse.Namespace, device: str):
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
    normal_indices = maybe_limit([i for i, rec in enumerate(ds.records) if rec["label"] == "normal"], args.max_normal_images)
    anomaly_indices = maybe_limit([i for i, rec in enumerate(ds.records) if rec["label"] != "normal"], args.max_anomaly_images)

    normal_by_layer: dict[int, list[torch.Tensor]] = {layer: [] for layer in layers}
    anomaly_by_layer: dict[int, list[torch.Tensor]] = {layer: [] for layer in layers}

    for idx in normal_indices + anomaly_indices:
        image_np, mask_np, label, _, _ = ds[idx]
        image_t = backbone.transform_pil(Image.fromarray(image_np)).unsqueeze(0).to(device)
        image_t = image_t.to(dtype=backbone.visual.conv1.weight.dtype)
        with torch.no_grad():
            tokens_by_layer = backbone.extract_layer_patch_tokens(image_t, target_layers=layers)
        patch_mask = to_patch_mask(mask_np, backbone.grid_size, device)
        for layer in layers:
            tokens = F.normalize(tokens_by_layer[layer][0].float(), dim=-1).cpu()
            if label == 0:
                normal_by_layer[layer].append(tokens)
            else:
                pos = torch.from_numpy(patch_mask > 0)
                if int(pos.sum().item()) > 0:
                    anomaly_by_layer[layer].append(tokens[pos])
    return normal_by_layer, anomaly_by_layer


def summarize_values(vals: list[float]) -> tuple[float, float]:
    arr = np.asarray(vals, dtype=np.float64)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return float("nan"), float("nan")
    return float(arr.mean()), float(arr.std())


def evaluate_layer_splits(
    normal_images: list[torch.Tensor],
    anomaly_images: list[torch.Tensor],
    p_norm: torch.Tensor,
    max_k: int,
    principal_k: int,
    num_splits: int,
    seed: int,
) -> tuple[dict[str, float], list[dict[str, float]]]:
    normal_residuals = [project_null_space(x.float(), p_norm) for x in normal_images]
    anomaly_residuals = [project_null_space(x.float(), p_norm) for x in anomaly_images]

    num_anom = len(anomaly_residuals)
    if num_anom < 4:
        return {}, []

    rng = np.random.default_rng(seed)
    split_rows: list[dict[str, float]] = []
    auc_by_k: dict[int, list[float]] = {k: [] for k in range(1, max_k + 1)}
    sigma_mean_by_k: dict[int, list[float]] = {k: [] for k in range(1, max_k + 1)}
    sigma_min_by_k: dict[int, list[float]] = {k: [] for k in range(1, max_k + 1)}

    all_norm = torch.cat(normal_residuals, dim=0)

    for split_id in range(num_splits):
        perm = rng.permutation(num_anom)
        half = num_anom // 2
        fit_idx = perm[:half]
        eval_idx = perm[half:]
        if fit_idx.size == 0 or eval_idx.size == 0:
            continue

        fit_anom = torch.cat([anomaly_residuals[int(i)] for i in fit_idx], dim=0)
        eval_anom = torch.cat([anomaly_residuals[int(i)] for i in eval_idx], dim=0)
        basis_fit, _ = compute_basis(fit_anom, max_k=max_k)

        eval_row: dict[str, float] = {
            "split_id": float(split_id),
            "fit_anom_images": float(len(fit_idx)),
            "eval_anom_images": float(len(eval_idx)),
            "fit_anom_patches": float(fit_anom.shape[0]),
            "eval_anom_patches": float(eval_anom.shape[0]),
            "eval_normal_patches": float(all_norm.shape[0]),
        }

        other_perm = rng.permutation(num_anom)
        other_half = num_anom // 2
        a_idx = other_perm[:other_half]
        b_idx = other_perm[other_half:]
        if a_idx.size > 0 and b_idx.size > 0:
            basis_a, _ = compute_basis(torch.cat([anomaly_residuals[int(i)] for i in a_idx], dim=0), max_k=max_k)
            basis_b, _ = compute_basis(torch.cat([anomaly_residuals[int(i)] for i in b_idx], dim=0), max_k=max_k)
        else:
            basis_a = basis_b = torch.empty(fit_anom.shape[1], 0)

        for k in range(1, max_k + 1):
            auc, norm_mean, anom_mean = score_with_basis(all_norm, eval_anom, basis_fit, k)
            auc_by_k[k].append(auc)
            eval_row[f"auc_k{k}"] = auc
            eval_row[f"norm_score_mean_k{k}"] = norm_mean
            eval_row[f"anom_score_mean_k{k}"] = anom_mean

            sigma_mean, sigma_min = principal_angle_similarity(basis_a, basis_b, min(k, principal_k))
            sigma_mean_by_k[k].append(sigma_mean)
            sigma_min_by_k[k].append(sigma_min)
            eval_row[f"principal_sigma_mean_k{k}"] = sigma_mean
            eval_row[f"principal_sigma_min_k{k}"] = sigma_min

        split_rows.append(eval_row)

    summary: dict[str, float] = {}
    for k in range(1, max_k + 1):
        auc_mean, auc_std = summarize_values(auc_by_k[k])
        sigma_mean, sigma_std = summarize_values(sigma_mean_by_k[k])
        sigma_min_mean, sigma_min_std = summarize_values(sigma_min_by_k[k])
        summary[f"auc_k{k}_mean"] = auc_mean
        summary[f"auc_k{k}_std"] = auc_std
        summary[f"principal_sigma_mean_k{k}_mean"] = sigma_mean
        summary[f"principal_sigma_mean_k{k}_std"] = sigma_std
        summary[f"principal_sigma_min_k{k}_mean"] = sigma_min_mean
        summary[f"principal_sigma_min_k{k}_std"] = sigma_min_std

    finite_auc = [(k, summary[f"auc_k{k}_mean"]) for k in range(1, max_k + 1) if math.isfinite(summary[f"auc_k{k}_mean"])]
    if finite_auc:
        best_k, best_auc = max(finite_auc, key=lambda x: x[1])
        summary["best_k_by_mean_auc"] = float(best_k)
        summary["best_mean_auc"] = float(best_auc)
        plateau_threshold = best_auc - 0.01
        plateau_candidates = [k for k, auc in finite_auc if auc >= plateau_threshold]
        summary["plateau_k_min"] = float(min(plateau_candidates))
    else:
        summary["best_k_by_mean_auc"] = float("nan")
        summary["best_mean_auc"] = float("nan")
        summary["plateau_k_min"] = float("nan")
    summary["num_valid_splits"] = float(len(split_rows))
    return summary, split_rows


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    class_names = args.class_names or list_all_classes(args.split_csv)
    layers = sorted({int(x) for x in args.target_layers})

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )

    summary_rows: list[dict[str, float | int | str]] = []
    detail_rows: list[dict[str, float | int | str]] = []

    for class_name in class_names:
        print(f"[collect] {class_name}")
        p_norm = build_text_anchor(backbone, class_name, abnormal=False).to(torch.float32)
        normal_by_layer, anomaly_by_layer = collect_class_image_tokens(backbone, class_name, layers, args, device)

        for layer in layers:
            normal_images = normal_by_layer[layer]
            anomaly_images = anomaly_by_layer[layer]
            row: dict[str, float | int | str] = {
                "class_name": class_name,
                "layer": int(layer),
                "num_normal_images": int(len(normal_images)),
                "num_anomaly_images": int(len(anomaly_images)),
                "num_normal_patches": int(sum(x.shape[0] for x in normal_images)),
                "num_anomaly_patches": int(sum(x.shape[0] for x in anomaly_images)),
                "max_k": int(args.max_k),
                "num_splits": int(args.num_splits),
            }

            if len(anomaly_images) >= 4 and len(normal_images) > 0:
                summary, split_rows = evaluate_layer_splits(
                    normal_images=normal_images,
                    anomaly_images=anomaly_images,
                    p_norm=p_norm,
                    max_k=args.max_k,
                    principal_k=args.principal_k,
                    num_splits=args.num_splits,
                    seed=args.seed + layer * 1000 + sum(ord(c) for c in class_name),
                )
                row.update(summary)
                for split_row in split_rows:
                    detail = {"class_name": class_name, "layer": int(layer)}
                    detail.update(split_row)
                    detail_rows.append(detail)
            summary_rows.append(row)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    class_tag = "allvisa" if not args.class_names else "-".join(class_names)
    layer_tag = "-".join(str(x) for x in layers)
    stem = f"{args.output_tag}_{class_tag}_layers{layer_tag}"
    summary_csv = out_dir / f"{stem}_summary.csv"
    detail_csv = out_dir / f"{stem}_detail.csv"
    json_path = out_dir / f"{stem}_detail.json"

    if summary_rows:
        with summary_csv.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
            writer.writeheader()
            writer.writerows(summary_rows)
    if detail_rows:
        with detail_csv.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(detail_rows[0].keys()))
            writer.writeheader()
            writer.writerows(detail_rows)
    with json_path.open("w") as f:
        json.dump({"summary_rows": summary_rows, "detail_rows": detail_rows}, f, indent=2)

    print(summary_csv)
    print(detail_csv)
    print(json_path)
    print(json.dumps(summary_rows, indent=2))


if __name__ == "__main__":
    main()
