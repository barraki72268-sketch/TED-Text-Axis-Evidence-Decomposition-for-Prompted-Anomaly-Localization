#!/usr/bin/env python3
"""Make a compact T-TED 1D evidence-margin schematic inset."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def gaussian(x: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    y = np.exp(-0.5 * ((x - mu) / sigma) ** 2)
    return y / y.max()


def main() -> None:
    out_dir = Path("figure/method_figure")
    out_dir.mkdir(parents=True, exist_ok=True)

    x = np.linspace(-1.0, 1.0, 400)
    fp = gaussian(x, -0.42, 0.18)
    defect = gaussian(x, 0.46, 0.19)
    qx = 0.18
    fp_y = gaussian(np.array([qx]), -0.42, 0.18)[0]
    def_y = gaussian(np.array([qx]), 0.46, 0.19)[0]

    plt.rcParams.update(
        {
            "font.family": "DejaVu Serif",
            "mathtext.fontset": "dejavuserif",
            "axes.linewidth": 1.0,
        }
    )
    fig, ax = plt.subplots(figsize=(2.55, 1.35), dpi=300)
    fig.patch.set_facecolor("#101010")
    ax.set_facecolor("#101010")

    ax.fill_between(x, 0, 0.58 * fp, color="#4d82d8", alpha=0.45)
    ax.plot(x, 0.58 * fp, color="#8fb5ff", lw=1.4)
    ax.fill_between(x, 0, 0.58 * defect, color="#c85050", alpha=0.45)
    ax.plot(x, 0.58 * defect, color="#ffb0b0", lw=1.4)

    ax.axhline(0, color="#d8d8d8", lw=1.1)
    ax.annotate(
        "",
        xy=(0.95, 0.0),
        xytext=(-0.95, 0.0),
        arrowprops=dict(arrowstyle="->", color="#d8d8d8", lw=1.1),
    )
    ax.text(0.47, -0.10, r"$t_{\rm axis}$", color="#f2f2f2", fontsize=7, ha="center")

    ax.scatter([qx], [0.66], s=38, c="#ffffff", edgecolors="#111111", linewidths=0.7, zorder=5)
    ax.plot([qx, qx], [0.03, 0.62], color="#ffffff", lw=1.0, ls="--", alpha=0.85)
    ax.text(qx + 0.11, 0.70, "query", color="#ffffff", fontsize=6.3, ha="left", va="center")

    ax.annotate(
        "",
        xy=(-0.42, 0.40),
        xytext=(qx, 0.60),
        arrowprops=dict(arrowstyle="-|>", color="#8fb5ff", lw=1.1, shrinkA=2, shrinkB=2),
    )
    ax.annotate(
        "",
        xy=(0.46, 0.44),
        xytext=(qx, 0.60),
        arrowprops=dict(arrowstyle="-|>", color="#ffb0b0", lw=1.1, shrinkA=2, shrinkB=2),
    )

    ax.text(-0.60, 0.46, r"$q_{\rm fp}$", color="#c8dbff", fontsize=6.8)
    ax.text(0.45, 0.49, r"$q_{\rm def}$", color="#ffc4c4", fontsize=6.8)
    ax.text(-0.74, 0.15, "FP\nsupport", color="#c8dbff", fontsize=6.0, ha="center", va="center")
    ax.text(0.72, 0.15, "defect\nsupport", color="#ffc4c4", fontsize=6.0, ha="center", va="center")

    ax.text(
        0.5,
        1.03,
        r"1D evidence margin",
        color="#ffffff",
        fontsize=7.2,
        ha="center",
        va="bottom",
        transform=ax.transAxes,
    )
    ax.text(
        0.5,
        0.87,
        r"$s_T = q_{\rm def}-q_{\rm fp}$",
        color="#ffffff",
        fontsize=7.6,
        ha="center",
        va="center",
        transform=ax.transAxes,
    )

    ax.set_xlim(-1.0, 1.0)
    ax.set_ylim(-0.15, 0.83)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_color("#ffffff")
        spine.set_linewidth(1.1)

    fig.tight_layout(pad=0.22)
    for ext in ["png", "pdf"]:
        fig.savefig(out_dir / f"tted_margin_inset_20260504.{ext}", facecolor=fig.get_facecolor(), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    print(out_dir / "tted_margin_inset_20260504.png")


if __name__ == "__main__":
    main()
