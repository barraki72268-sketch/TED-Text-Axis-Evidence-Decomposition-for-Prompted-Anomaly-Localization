from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import open_clip
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ADPretrain.models.clip import ClipModel
from neurips2026.patchcore_adapters.visa_dataset import VisAOneClassDataset
from neurips2026.WinClip.WinCLIP.ad_prompts import template_level_prompts, state_level_normal_prompts


CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)
LAYER_IDS = (6, 12, 18, 24)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--backbone", type=str, default="clip-large-336", choices=["clip-large", "clip-large-336"])
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12, 18, 24])
    parser.add_argument("--resize", type=int, default=336)
    parser.add_argument("--imagesize", type=int, default=336)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--gamma", type=float, default=1.0)
    parser.add_argument("--gate_mode", type=str, default="var_mean", choices=["var_mean", "shock_topk"])
    parser.add_argument("--topk_ratio", type=float, default=0.1)
    parser.add_argument(
        "--refine_mode",
        type=str,
        default="orth_perp",
        choices=["orth_perp", "zero_mean_shift", "impedance_diag", "semantic_affine_calib"],
    )
    parser.add_argument("--max_normals", type=int, default=20)
    parser.add_argument("--max_anomalies", type=int, default=20)
    parser.add_argument("--pairwise_sample", type=int, default=1024)
    parser.add_argument("--vis_layer", type=int, default=12)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", type=str, default="cuda:1")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_text_preserve_probe")
    return parser.parse_args()


def patch_coords(side: int, device: torch.device) -> torch.Tensor:
    yy, xx = torch.meshgrid(
        torch.arange(side, device=device),
        torch.arange(side, device=device),
        indexing="ij",
    )
    return torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=-1).float()


def foreground_mask(image: torch.Tensor, side: int) -> torch.Tensor:
    mean = torch.tensor(CLIP_MEAN, dtype=image.dtype, device=image.device).view(1, 3, 1, 1)
    std = torch.tensor(CLIP_STD, dtype=image.dtype, device=image.device).view(1, 3, 1, 1)
    rgb = (image.unsqueeze(0) * std + mean).squeeze(0).clamp(0.0, 1.0)
    h, w = rgb.shape[-2:]
    patch = max(4, min(h, w) // 18)
    corners = torch.cat(
        [
            rgb[:, :patch, :patch].reshape(3, -1).T,
            rgb[:, :patch, -patch:].reshape(3, -1).T,
            rgb[:, -patch:, :patch].reshape(3, -1).T,
            rgb[:, -patch:, -patch:].reshape(3, -1).T,
        ],
        dim=0,
    )
    bg_mean = corners.mean(dim=0, keepdim=True)
    corner_dist = torch.norm(corners - bg_mean, dim=1)
    thresh = max(18.0 / 255.0, float(torch.quantile(corner_dist, 0.99).item()) + 8.0 / 255.0)
    dist = torch.norm(rgb.permute(1, 2, 0) - bg_mean.view(1, 1, 3), dim=-1)
    fg = (dist > thresh).float().view(1, 1, h, w)
    fg = F.interpolate(fg, size=(side, side), mode="bilinear", align_corners=False)
    return fg.view(-1) > 0.30


def downsample_mask(mask: torch.Tensor, side: int) -> torch.Tensor:
    m = F.interpolate(mask.unsqueeze(0), size=(side, side), mode="nearest").squeeze(0).squeeze(0)
    return m > 0.5


def maybe_project_to_text_space(tokens: torch.Tensor, model: ClipModel) -> torch.Tensor:
    visual = model.visual_encoder.visual
    proj = getattr(visual, "proj", None)
    if proj is None:
        return tokens
    target_dim = proj.shape[-1]
    if tokens.shape[-1] == target_dim:
        return tokens
    return tokens @ proj.float().to(tokens.device)


def build_normal_text_anchor(class_name: str, model: ClipModel, device: torch.device) -> torch.Tensor:
    phrases = []
    for template in template_level_prompts:
        for normal_prompt in state_level_normal_prompts:
            phrases.append(template.format(normal_prompt.format(class_name)))
    tokenizer = open_clip.get_tokenizer("ViT-L-14")
    text = tokenizer(phrases).to(device)
    with torch.no_grad():
        text_features = model.visual_encoder.encode_text(text)
    avg = text_features.float().mean(dim=0)
    return avg / avg.norm().clamp_min(1e-8)


def text_preserving_kinematic_refinement(
    v_raw: torch.Tensor,
    t_anchor: torch.Tensor,
    kernel_size: int = 3,
    gamma: float = 1.0,
    gate_mode: str = "var_mean",
    topk_ratio: float = 0.1,
    refine_mode: str = "orth_perp",
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if v_raw.dim() != 4:
        raise ValueError(f"Expected (B,D,H,W), got {tuple(v_raw.shape)}")
    if kernel_size % 2 == 0:
        raise ValueError("kernel_size must be odd.")

    if t_anchor.dim() == 1:
        t = t_anchor.view(1, -1, 1, 1)
    elif t_anchor.dim() == 4:
        t = t_anchor
    else:
        raise ValueError(f"Unexpected t_anchor shape: {tuple(t_anchor.shape)}")
    t = t.to(device=v_raw.device, dtype=v_raw.dtype)
    t = t / t.norm(dim=1, keepdim=True).clamp_min(1e-8)

    v_parallel = torch.sum(v_raw * t, dim=1, keepdim=True) * t
    v_perp = v_raw - v_parallel

    mu_perp = F.avg_pool2d(v_perp, kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
    second_moment = F.avg_pool2d(v_perp.pow(2), kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
    var_perp = (second_moment - mu_perp.pow(2)).clamp_min(1e-6)

    if gate_mode == "var_mean":
        lambda_perp = var_perp.mean(dim=1, keepdim=True)
    elif gate_mode == "shock_topk":
        shock = (v_perp - mu_perp).pow(2) / var_perp
        b, d, h, w = shock.shape
        k = max(1, min(d, int(round(d * topk_ratio))))
        shock_flat = shock.permute(0, 2, 3, 1).reshape(-1, d)
        topk_vals, _ = torch.topk(shock_flat, k=k, dim=1)
        lambda_perp = topk_vals.mean(dim=1, keepdim=True).reshape(b, h, w, 1).permute(0, 3, 1, 2)
    else:
        raise ValueError(f"Unknown gate_mode: {gate_mode}")

    alpha = 1.0 / (1.0 + gamma * lambda_perp)

    if refine_mode == "orth_perp":
        v_perp_refined = v_perp + alpha * (mu_perp - v_perp)
        v_final = v_parallel + v_perp_refined
    elif refine_mode == "zero_mean_shift":
        mu_full = F.avg_pool2d(v_raw, kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
        v_temp = v_raw + alpha * (mu_full - v_raw)
        local_shift_scalar = torch.sum((v_temp - v_raw) * t, dim=1, keepdim=True)
        global_drift_scalar = torch.mean(local_shift_scalar, dim=(2, 3), keepdim=True)
        v_final = v_temp - global_drift_scalar * t
    elif refine_mode == "impedance_diag":
        shock = (v_perp - mu_perp).pow(2) / var_perp
        stiffness = gamma * shock
        alpha_diag = stiffness / (1.0 + stiffness)
        v_perp_refined = v_perp + alpha_diag * (mu_perp - v_perp)
        v_final = v_parallel + v_perp_refined
        alpha = alpha_diag.mean(dim=1, keepdim=True)
        lambda_perp = stiffness.mean(dim=1, keepdim=True)
    elif refine_mode == "semantic_affine_calib":
        mu_full = F.avg_pool2d(v_raw, kernel_size=kernel_size, stride=1, padding=kernel_size // 2)
        v_temp = v_raw + alpha * (mu_full - v_raw)

        s_raw = torch.sum(v_raw * t, dim=1, keepdim=True)
        s_temp = torch.sum(v_temp * t, dim=1, keepdim=True)
        w = alpha.clamp_min(1e-6)

        sum_w = w.sum(dim=(2, 3), keepdim=True).clamp_min(1e-6)
        mean_raw = (w * s_raw).sum(dim=(2, 3), keepdim=True) / sum_w
        mean_temp = (w * s_temp).sum(dim=(2, 3), keepdim=True) / sum_w

        xc = s_temp - mean_temp
        yc = s_raw - mean_raw

        s_xx = (w * xc * xc).sum(dim=(2, 3), keepdim=True)
        s_xy = (w * xc * yc).sum(dim=(2, 3), keepdim=True)
        u = s_xy / (s_xx + 1e-4)
        u = u.clamp(0.5, 1.5)
        v = mean_raw - u * mean_temp

        s_hat = u * s_temp + v
        v_final = v_temp + (s_hat - s_temp) * t
    else:
        raise ValueError(f"Unknown refine_mode: {refine_mode}")
    return v_final, alpha, lambda_perp


def pairwise_mean_cos(tokens: torch.Tensor, max_points: int, seed: int) -> float:
    if tokens.shape[0] == 0:
        return float("nan")
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    if tokens.shape[0] > max_points:
        sel = torch.randperm(tokens.shape[0], generator=gen)[:max_points].to(tokens.device)
        tokens = tokens[sel]
    tokens = F.normalize(tokens.float(), dim=-1)
    sims = tokens @ tokens.T
    n = sims.shape[0]
    if n <= 1:
        return float("nan")
    tri = torch.triu_indices(n, n, offset=1, device=sims.device)
    return float(sims[tri[0], tri[1]].mean().item())


def pca_2d(x: torch.Tensor) -> torch.Tensor:
    x = x.float()
    mu = x.mean(dim=0, keepdim=True)
    centered = x - mu
    _, _, v = torch.linalg.svd(centered, full_matrices=False)
    basis = v[:2].T
    return centered @ basis


def main() -> None:
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    model = ClipModel(args.backbone, device=str(device)).eval()
    model.visual_encoder = model.visual_encoder.to(device)
    text_anchor = build_normal_text_anchor(args.class_name, model, device=device)

    test_ds = VisAOneClassDataset(
        root=args.dataset_root,
        class_name=args.class_name,
        split="test",
        resize=args.resize,
        imagesize=args.imagesize,
        mean=CLIP_MEAN,
        std=CLIP_STD,
    )
    normals = [rec for rec in test_ds.data_to_iterate if rec[1] == "good"][: args.max_normals]
    anomalies = [rec for rec in test_ds.data_to_iterate if rec[1] != "good"][: args.max_anomalies]
    test_ds.data_to_iterate = normals + anomalies

    rows: list[dict] = []
    vis_payload = None
    cache: dict[tuple[int, int], tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]] = {}

    for idx in range(len(test_ds)):
        sample = test_ds[idx]
        image = sample["image"].unsqueeze(0).to(device)
        mask = sample["mask"].to(device)
        is_anomaly = bool(sample["is_anomaly"])

        with torch.no_grad():
            feats = model.encode_image_from_tensors(image, shape="img")

        for layer_id, feat in zip(LAYER_IDS, feats):
            if layer_id not in args.layers:
                continue
            c, h, w = feat.shape[1:]
            raw = feat.float()
            raw = maybe_project_to_text_space(raw[0].permute(1, 2, 0).reshape(-1, c), model)
            d = raw.shape[-1]
            raw_map = raw.T.reshape(1, d, h, w)
            refined_map, alpha_map, lambda_map = text_preserving_kinematic_refinement(
                raw_map,
                text_anchor,
                kernel_size=args.kernel_size,
                gamma=args.gamma,
                gate_mode=args.gate_mode,
                topk_ratio=args.topk_ratio,
                refine_mode=args.refine_mode,
            )
            refined = refined_map[0].permute(1, 2, 0).reshape(-1, d)

            fg = foreground_mask(image[0], side=h)
            patch_mask = downsample_mask(mask, side=h).view(-1)
            defect = patch_mask & fg
            clean = (~patch_mask) & fg
            label_type = torch.full((raw.shape[0],), 0, device=raw.device, dtype=torch.long)
            if is_anomaly:
                label_type[clean] = 1
                label_type[defect] = 2

            delta = refined - raw
            t = text_anchor.to(device=raw.device, dtype=raw.dtype)
            text_axis_before = raw @ t
            text_axis_after = refined @ t
            text_axis_delta = text_axis_after - text_axis_before

            rows.append(
                {
                    "layer": layer_id,
                    "is_anomaly_image": int(is_anomaly),
                    "normal_count": int((label_type == 0).sum().item()),
                    "clean_count": int((label_type == 1).sum().item()),
                    "defect_count": int((label_type == 2).sum().item()),
                    "text_axis_delta_mean": float(text_axis_delta[fg].abs().mean().item()) if fg.any() else float("nan"),
                    "text_axis_signed_mean": float(text_axis_delta[fg].mean().item()) if fg.any() else float("nan"),
                    "text_axis_delta_max": float(text_axis_delta[fg].abs().max().item()) if fg.any() else float("nan"),
                    "cos_to_text_raw_mean": float(F.cosine_similarity(raw, t.unsqueeze(0), dim=-1)[fg].mean().item()) if fg.any() else float("nan"),
                    "cos_to_text_refined_mean": float(F.cosine_similarity(refined, t.unsqueeze(0), dim=-1)[fg].mean().item()) if fg.any() else float("nan"),
                    "alpha_fg_mean": float(alpha_map.view(-1)[fg].mean().item()) if fg.any() else float("nan"),
                    "lambda_fg_mean": float(lambda_map.view(-1)[fg].mean().item()) if fg.any() else float("nan"),
                }
            )

            cache[(idx, layer_id)] = (raw.detach(), refined.detach(), fg.detach(), defect.detach(), clean.detach())

            if vis_payload is None and layer_id == args.vis_layer and is_anomaly and int(defect.sum().item()) > 0:
                t = text_anchor.to(device=raw.device, dtype=raw.dtype)
                vpar = (raw @ t).unsqueeze(-1) * t.unsqueeze(0)
                vperp_before = raw - vpar
                vpar_after = (refined @ t).unsqueeze(-1) * t.unsqueeze(0)
                vperp_after = refined - vpar_after
                proj_before = pca_2d(vperp_before[fg])
                proj_after = pca_2d(vperp_after[fg])
                vis_payload = {
                    "layer": layer_id,
                    "labels": label_type[fg].detach().cpu(),
                    "axis_before": text_axis_before[fg].detach().cpu(),
                    "axis_after": text_axis_after[fg].detach().cpu(),
                    "alpha_fg": alpha_map.view(-1)[fg].detach().cpu(),
                    "proj_before": proj_before.detach().cpu(),
                    "proj_after": proj_after.detach().cpu(),
                }

    summary = {}
    detail = {}
    for layer_id in args.layers:
        layer_rows = [r for r in rows if r["layer"] == layer_id]
        if not layer_rows:
            continue
        summary[layer_id] = {
            "text_axis_delta_mean": float(np.nanmean([r["text_axis_delta_mean"] for r in layer_rows])),
            "text_axis_signed_mean": float(np.nanmean([r["text_axis_signed_mean"] for r in layer_rows])),
            "text_axis_delta_max": float(np.nanmax([r["text_axis_delta_max"] for r in layer_rows])),
            "cos_to_text_raw_mean": float(np.nanmean([r["cos_to_text_raw_mean"] for r in layer_rows])),
            "cos_to_text_refined_mean": float(np.nanmean([r["cos_to_text_refined_mean"] for r in layer_rows])),
            "alpha_fg_mean": float(np.nanmean([r["alpha_fg_mean"] for r in layer_rows])),
            "lambda_fg_mean": float(np.nanmean([r["lambda_fg_mean"] for r in layer_rows])),
        }

        normal_raw, normal_ref = [], []
        clean_raw, clean_ref = [], []
        defect_raw, defect_ref = [], []
        for idx in range(len(test_ds)):
            if (idx, layer_id) not in cache:
                continue
            raw, refined, fg, defect, clean = cache[(idx, layer_id)]
            sample = test_ds[idx]
            if bool(sample["is_anomaly"]):
                if clean.any():
                    clean_raw.append(raw[clean])
                    clean_ref.append(refined[clean])
                if defect.any():
                    defect_raw.append(raw[defect])
                    defect_ref.append(refined[defect])
            else:
                if fg.any():
                    normal_raw.append(raw[fg])
                    normal_ref.append(refined[fg])

        if not normal_raw:
            continue
        nr = torch.cat(normal_raw, dim=0)
        nrf = torch.cat(normal_ref, dim=0)
        cr = torch.cat(clean_raw, dim=0) if clean_raw else None
        cf = torch.cat(clean_ref, dim=0) if clean_ref else None
        dr = torch.cat(defect_raw, dim=0) if defect_raw else None
        df = torch.cat(defect_ref, dim=0) if defect_ref else None
        centroid_raw = nr.mean(dim=0, keepdim=True)
        centroid_ref = nrf.mean(dim=0, keepdim=True)

        detail[layer_id] = {
            "normal_pairwise_raw": pairwise_mean_cos(nr, args.pairwise_sample, args.seed),
            "normal_pairwise_refined": pairwise_mean_cos(nrf, args.pairwise_sample, args.seed),
            "defect_clean_sep_before": float((torch.norm(dr - centroid_raw, dim=-1).mean() - torch.norm(cr - centroid_raw, dim=-1).mean()).item()) if dr is not None and cr is not None else float("nan"),
            "defect_clean_sep_after": float((torch.norm(df - centroid_ref, dim=-1).mean() - torch.norm(cf - centroid_ref, dim=-1).mean()).item()) if df is not None and cf is not None else float("nan"),
        }

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.output_tag}_{args.class_name}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    png_path = out_dir / f"{stem}_vis.png"

    fieldnames = [
        "layer",
        "text_axis_delta_mean",
        "text_axis_signed_mean",
        "text_axis_delta_max",
        "cos_to_text_raw_mean",
        "cos_to_text_refined_mean",
        "alpha_fg_mean",
        "lambda_fg_mean",
        "normal_pairwise_raw",
        "normal_pairwise_refined",
        "defect_clean_sep_before",
        "defect_clean_sep_after",
    ]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for layer_id in args.layers:
            row = {"layer": layer_id}
            row.update(summary.get(layer_id, {}))
            row.update(detail.get(layer_id, {}))
            writer.writerow(row)

    with json_path.open("w") as f:
        json.dump({"summary": summary, "detail": detail}, f, indent=2)

    if vis_payload is not None:
        labels = vis_payload["labels"].numpy()
        colors = np.array(["tab:blue", "tab:green", "tab:red"], dtype=object)
        names = np.array(["normal", "clean", "defect"], dtype=object)
        fig, axes = plt.subplots(2, 2, figsize=(10, 8))

        ax = axes[0, 0]
        ax.scatter(vis_payload["axis_before"].numpy(), vis_payload["axis_after"].numpy(), s=8, alpha=0.35)
        lims = ax.get_xlim()
        ax.plot(lims, lims, "k--", linewidth=1)
        ax.set_title("Raw vs Refined text-axis")
        ax.set_xlabel("raw T^T V")
        ax.set_ylabel("refined T^T V")

        ax = axes[0, 1]
        ax.hist(vis_payload["alpha_fg"].numpy(), bins=30, color="tab:orange", alpha=0.8)
        ax.set_title("Foreground alpha distribution")
        ax.set_xlabel("alpha")
        ax.set_ylabel("count")

        for label_id in [0, 1, 2]:
            sel = labels == label_id
            if not np.any(sel):
                continue
            axes[1, 0].scatter(
                vis_payload["proj_before"][sel, 0].numpy(),
                vis_payload["proj_before"][sel, 1].numpy(),
                s=12,
                alpha=0.5,
                c=colors[label_id],
                label=names[label_id],
            )
            axes[1, 1].scatter(
                vis_payload["proj_after"][sel, 0].numpy(),
                vis_payload["proj_after"][sel, 1].numpy(),
                s=12,
                alpha=0.5,
                c=colors[label_id],
                label=names[label_id],
            )
        axes[1, 0].set_title(f"Perp-space PCA before (L{vis_payload['layer']})")
        axes[1, 1].set_title(f"Perp-space PCA after (L{vis_payload['layer']})")
        axes[1, 0].legend(frameon=False)
        plt.tight_layout()
        fig.savefig(png_path, dpi=180)

    print(csv_path)
    print(json_path)
    if vis_payload is not None:
        print(png_path)


if __name__ == "__main__":
    main()
