#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
cd "$ROOT"

PY="/mnt/data/envs/patchcore-conda/bin/python"
SCRIPT="neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py"
CKPT="neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth"
SOURCE_ROOT="neurips2026/data/VisA_pytorch_official/1cls"
SOURCE_DATASET="visa"
BANK_CACHE="neurips2026/results/bank_cache/anomalyclip_visa_official1cls_epoch15_multiscale.pt"

BTAD_ROOT="neurips2026/data/BTAD_official"
BTAD_SAVE="neurips2026/results/anomalyclip_text_decomposition_score_visa2btad_epoch15"

MPDD_ROOT="/mnt/data/MPDD"
MPDD_SAVE="neurips2026/results/anomalyclip_text_decomposition_score_visa2mpdd_epoch15"

FULL_MVTEC_PID="${1:-3632014}"

while kill -0 "$FULL_MVTEC_PID" 2>/dev/null; do
  sleep 30
done

"$PY" "$SCRIPT" \
  --device cuda:1 \
  --checkpoint_path "$CKPT" \
  --heldout_class none \
  --source_root "$SOURCE_ROOT" \
  --source_dataset "$SOURCE_DATASET" \
  --target_root "$BTAD_ROOT" \
  --target_dataset btad \
  --target_mode test \
  --bank_cache_path "$BANK_CACHE" \
  --save_dir "$BTAD_SAVE"

"$PY" "$SCRIPT" \
  --device cuda:1 \
  --checkpoint_path "$CKPT" \
  --heldout_class none \
  --source_root "$SOURCE_ROOT" \
  --source_dataset "$SOURCE_DATASET" \
  --target_root "$MPDD_ROOT" \
  --target_dataset mpdd \
  --target_mode test \
  --bank_cache_path "$BANK_CACHE" \
  --save_dir "$MPDD_SAVE"
