from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from WinCLIP import WinClipAD  # noqa: E402
from neurips2026.scripts.eval_winclip_oneclass_featureop import maybe_wrap_feature_op  # noqa: E402
from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # noqa: E402
from neurips2026.winclip_adapters.feature_ops import _local_mean_tokens, _resolve_token_space_anchor  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--max_normals", type=int, default=20)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--scales", nargs="+", type=int, default=[2, 3])
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="winclip_residualraw_diag")
    parser.add_argument("--feature_op", type=str, default="residual_raw", choices=["identity", "residual_raw"])
    return parser.parse_args()


def extract_pre_mask_tokens(visual: torch.nn.Module, x: torch.Tensor) -> torch.Tensor:
    if visual.input_patchnorm:
        x = x.reshape(
            x.shape[0],
            x.shape[1],
            visual.grid_size[0],
            visual.patch_size[0],
            visual.grid_size[1],
            visual.patch_size[1],
        )
        x = x.permute(0, 2, 4, 1, 3, 5)
        x = x.reshape(x.shape[0], visual.grid_size[0] * visual.grid_size[1], -1)
        x = visual.patchnorm_pre_ln(x)
        x = visual.conv1(x)
    else:
        x = visual.conv1(x)
        x = x.reshape(x.shape[0], x.shape[1], -1)
        x = x.permute(0, 2, 1)
    x = x + visual.positional_embedding.to(x.dtype)[1:, :]
    return x


def build_model(args: argparse.Namespace, device: str, feature_op: str) -> WinClipAD:
    model = WinClipAD(
        out_size_h=args.resolution,
        out_size_w=args.resolution,
        device=device,
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        scales=tuple(args.scales),
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    ).to(device)
    model.eval_mode()
    model.build_text_feature_gallery(args.class_name)
    maybe_wrap_feature_op(model, feature_op)
    return model


def main() -> None:
    args = parse_args()
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"
    ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, args.class_name, "test")
    normal_indices = [i for i, rec in enumerate(ds.records) if rec["label"] == "normal"][: args.max_normals]

    raw_model = build_model(args, device, "identity")
    res_model = build_model(args, device, args.feature_op)
    diag_wrapper = res_model.model.visual
    if not hasattr(diag_wrapper, "_refine_tokens"):
        raise RuntimeError(f"feature_op={args.feature_op} does not expose _refine_tokens() for diagnostics.")

    rows: list[dict] = []
    for idx in normal_indices:
        image_np, _, _, name, _ = ds[idx]
        image_t = raw_model.transform(Image.fromarray(image_np)).unsqueeze(0).to(device)
        visual_dtype = raw_model.model.visual.conv1.weight.dtype
        image_t = image_t.to(dtype=visual_dtype)

        with torch.no_grad():
            raw_tokens = extract_pre_mask_tokens(raw_model.model.visual, image_t)
            refined_tokens = diag_wrapper._refine_tokens(raw_tokens.clone())

            side = int(round(raw_tokens.shape[1] ** 0.5))
            token_anchor = _resolve_token_space_anchor(
                token_dim=raw_tokens.shape[-1],
                text_anchor=raw_model.text_features[0],
                base_visual=raw_model.model.visual,
                device=raw_tokens.device,
                dtype=raw_tokens.dtype,
            ).float()

            raw_tok = raw_tokens[0].float()
            ref_tok = refined_tokens[0].float()
            local_mean = _local_mean_tokens(raw_tok, side=side, kernel_size=diag_wrapper.kernel_size)
            delta = local_mean - raw_tok
            drift = delta @ token_anchor

            raw_norm = raw_tok.norm(dim=-1)
            ref_norm = ref_tok.norm(dim=-1)
            raw_cos = F.normalize(raw_tok, dim=-1) @ token_anchor
            ref_cos = F.normalize(ref_tok, dim=-1) @ token_anchor

            raw_score = np.asarray(raw_model(image_t)[0], dtype=np.float32)
            ref_score = np.asarray(res_model(image_t)[0], dtype=np.float32)

        rows.append(
            {
                "name": name,
                "raw_norm_mean": float(raw_norm.mean().item()),
                "ref_norm_mean": float(ref_norm.mean().item()),
                "raw_cos_mean": float(raw_cos.mean().item()),
                "ref_cos_mean": float(ref_cos.mean().item()),
                "drift_scalar_mean": float(drift.mean().item()),
                "drift_scalar_abs_mean": float(drift.abs().mean().item()),
                "drift_scalar_neg_frac": float((drift < 0).float().mean().item()),
                "score_max_raw": float(raw_score.max()),
                "score_max_ref": float(ref_score.max()),
                "score_var_raw": float(raw_score.var()),
                "score_var_ref": float(ref_score.var()),
            }
        )

    summary = {
        "num_normals": len(rows),
        "raw_norm_mean": float(np.mean([r["raw_norm_mean"] for r in rows])),
        "ref_norm_mean": float(np.mean([r["ref_norm_mean"] for r in rows])),
        "delta_norm_mean": float(np.mean([r["ref_norm_mean"] - r["raw_norm_mean"] for r in rows])),
        "raw_cos_mean": float(np.mean([r["raw_cos_mean"] for r in rows])),
        "ref_cos_mean": float(np.mean([r["ref_cos_mean"] for r in rows])),
        "delta_cos_mean": float(np.mean([r["ref_cos_mean"] - r["raw_cos_mean"] for r in rows])),
        "drift_scalar_mean": float(np.mean([r["drift_scalar_mean"] for r in rows])),
        "drift_scalar_abs_mean": float(np.mean([r["drift_scalar_abs_mean"] for r in rows])),
        "drift_scalar_neg_frac": float(np.mean([r["drift_scalar_neg_frac"] for r in rows])),
        "score_max_raw_mean": float(np.mean([r["score_max_raw"] for r in rows])),
        "score_max_ref_mean": float(np.mean([r["score_max_ref"] for r in rows])),
        "delta_score_max_mean": float(np.mean([r["score_max_ref"] - r["score_max_raw"] for r in rows])),
        "score_var_raw_mean": float(np.mean([r["score_var_raw"] for r in rows])),
        "score_var_ref_mean": float(np.mean([r["score_var_ref"] for r in rows])),
        "delta_score_var_mean": float(np.mean([r["score_var_ref"] - r["score_var_raw"] for r in rows])),
    }

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    op_tag = args.feature_op.replace(".", "_")
    stem = f"{args.output_tag}_{args.class_name}_{op_tag}"
    csv_path = out_dir / f"{stem}_summary.csv"
    json_path = out_dir / f"{stem}_detail.json"
    png_path = out_dir / f"{stem}_vis.png"

    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary.keys()))
        writer.writeheader()
        writer.writerow(summary)

    with json_path.open("w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=2)

    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    raw_norm = np.array([r["raw_norm_mean"] for r in rows])
    ref_norm = np.array([r["ref_norm_mean"] for r in rows])
    raw_cos = np.array([r["raw_cos_mean"] for r in rows])
    ref_cos = np.array([r["ref_cos_mean"] for r in rows])
    raw_max = np.array([r["score_max_raw"] for r in rows])
    ref_max = np.array([r["score_max_ref"] for r in rows])
    raw_var = np.array([r["score_var_raw"] for r in rows])
    ref_var = np.array([r["score_var_ref"] for r in rows])
    drift = np.array([r["drift_scalar_mean"] for r in rows])

    axes[0, 0].scatter(raw_norm, ref_norm, s=18, alpha=0.8)
    lim = [min(raw_norm.min(), ref_norm.min()), max(raw_norm.max(), ref_norm.max())]
    axes[0, 0].plot(lim, lim, "k--", linewidth=1)
    axes[0, 0].set_title("Patch Norm Mean")
    axes[0, 0].set_xlabel("raw")
    axes[0, 0].set_ylabel("residual_raw")

    axes[0, 1].scatter(raw_cos, ref_cos, s=18, alpha=0.8)
    lim = [min(raw_cos.min(), ref_cos.min()), max(raw_cos.max(), ref_cos.max())]
    axes[0, 1].plot(lim, lim, "k--", linewidth=1)
    axes[0, 1].set_title("Patch Cosine Mean")
    axes[0, 1].set_xlabel("raw")
    axes[0, 1].set_ylabel("residual_raw")

    axes[0, 2].hist(drift, bins=20, color="tab:orange", alpha=0.85)
    axes[0, 2].axvline(0.0, color="k", linestyle="--", linewidth=1)
    axes[0, 2].set_title("Drift Scalar Mean")

    axes[1, 0].scatter(raw_max, ref_max, s=18, alpha=0.8)
    lim = [min(raw_max.min(), ref_max.min()), max(raw_max.max(), ref_max.max())]
    axes[1, 0].plot(lim, lim, "k--", linewidth=1)
    axes[1, 0].set_title("Score Max")
    axes[1, 0].set_xlabel("raw")
    axes[1, 0].set_ylabel("residual_raw")

    axes[1, 1].scatter(raw_var, ref_var, s=18, alpha=0.8)
    lim = [min(raw_var.min(), ref_var.min()), max(raw_var.max(), ref_var.max())]
    axes[1, 1].plot(lim, lim, "k--", linewidth=1)
    axes[1, 1].set_title("Score Variance")
    axes[1, 1].set_xlabel("raw")
    axes[1, 1].set_ylabel("residual_raw")

    axes[1, 2].hist(ref_norm - raw_norm, bins=20, color="tab:green", alpha=0.85)
    axes[1, 2].axvline(0.0, color="k", linestyle="--", linewidth=1)
    axes[1, 2].set_title("Norm Delta")

    plt.tight_layout()
    fig.savefig(png_path, dpi=180)

    print(csv_path)
    print(json_path)
    print(png_path)


if __name__ == "__main__":
    main()
