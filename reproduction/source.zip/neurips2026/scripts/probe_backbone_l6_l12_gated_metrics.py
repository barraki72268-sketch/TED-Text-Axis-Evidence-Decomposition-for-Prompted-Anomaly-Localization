from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.learned_refiner import RiemannianLowRankRefiner
from neurips2026.scripts.eval_winclip_oneclass_featureop import build_dataloader
from utils.eval_utils import specify_resolution
from utils.metrics import metric_cal


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_names", nargs="+", default=["chewinggum", "pcb1"])
    parser.add_argument("--l6_ckpt", type=str, required=True)
    parser.add_argument("--l12_ckpt", type=str, required=True)
    parser.add_argument("--img_resize", type=int, default=240)
    parser.add_argument("--img_cropsize", type=int, default=240)
    parser.add_argument("--resolution", type=int, default=400)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu_id", type=int, default=1)
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--gamma", type=float, default=0.3)
    parser.add_argument("--kappa", type=float, default=30.0)
    parser.add_argument("--tau_top_percent", type=float, default=5.0)
    parser.add_argument("--no_pro", action="store_true")
    parser.add_argument("--output_tag", type=str, default="backbone_l6_l12_gated_metrics")
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    return parser.parse_args()


def _preprocess_batch(backbone, batch_np) -> torch.Tensor:
    imgs = [backbone.transform_pil(Image.fromarray(f.numpy())) for f in batch_np]
    return torch.stack(imgs, dim=0).to(backbone.device)


def load_refiner(ckpt_path: str, device: torch.device) -> tuple[RiemannianLowRankRefiner, dict]:
    payload = torch.load(ckpt_path, map_location="cpu")
    config = payload["refiner_config"]
    refiner = RiemannianLowRankRefiner(
        feature_dim=int(config["feature_dim"]),
        kernel_size=int(config["kernel_size"]),
        topk_ratio=float(config["topk_ratio"]),
        rank=int(config["rank"]),
        hidden_dim=int(config["hidden_dim"]),
        dropout=float(config["dropout"]),
        lambda_max=float(config.get("lambda_max", 2.0)),
    ).to(device)
    refiner.load_state_dict(payload["model_state_dict"], strict=True)
    refiner.eval()
    return refiner, config


@torch.no_grad()
def build_prototype(
    backbone,
    loader,
    target_layer: int,
    refiner: RiemannianLowRankRefiner | None,
    num_steps: int,
) -> torch.Tensor:
    feats = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        images = _preprocess_batch(backbone, data)
        tokens = backbone.extract_layer_patch_tokens(images, target_layers=[target_layer])[target_layer]
        if refiner is not None:
            tokens = refiner(tokens, semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=num_steps).refined
        feats.append(F.normalize(tokens[normal_idx].float(), dim=-1))
    if not feats:
        raise RuntimeError(f"No normal features found for prototype L{target_layer}.")
    proto = torch.cat(feats, dim=0).mean(dim=0, keepdim=True)
    return F.normalize(proto, dim=-1)


@torch.no_grad()
def estimate_tau_from_train_normals(
    backbone,
    loader,
    l6_refiner: RiemannianLowRankRefiner,
    l12_refiner: RiemannianLowRankRefiner,
    l6_proto: torch.Tensor,
    l12_proto: torch.Tensor,
    l6_steps: int,
    l12_steps: int,
    top_percent: float,
) -> dict[str, float]:
    l6_scores_all = []
    a12_all = []
    for data, _mask, label, _name, _img_type in loader:
        labels = torch.as_tensor(label)
        normal_idx = torch.nonzero(labels == 0, as_tuple=False).flatten()
        if normal_idx.numel() == 0:
            continue
        images = _preprocess_batch(backbone, data)
        token_dict = backbone.extract_layer_patch_tokens(images, target_layers=[6, 12])
        l6_tokens = l6_refiner(token_dict[6], semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=l6_steps).refined
        l12_tokens = l12_refiner(token_dict[12], semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=l12_steps).refined
        l6_tokens = F.normalize(l6_tokens[normal_idx].float(), dim=-1)
        l12_tokens = F.normalize(l12_tokens[normal_idx].float(), dim=-1)
        l6_proto_batch = l6_proto.to(l6_tokens.device, dtype=l6_tokens.dtype).expand(l6_tokens.shape[0], -1, -1)
        l12_proto_batch = l12_proto.to(l12_tokens.device, dtype=l12_tokens.dtype).expand(l12_tokens.shape[0], -1, -1)
        s_l6 = 1.0 - F.cosine_similarity(l6_tokens, l6_proto_batch, dim=-1)
        a12 = 1.0 - F.cosine_similarity(l12_tokens, l12_proto_batch, dim=-1)
        l6_scores_all.append(s_l6.reshape(-1).detach().cpu())
        a12_all.append(a12.reshape(-1).detach().cpu())

    l6_scores = torch.cat(l6_scores_all)
    a12_scores = torch.cat(a12_all)
    k = max(1, int(np.ceil(l6_scores.numel() * top_percent / 100.0)))
    top_idx = torch.topk(l6_scores, k=k, largest=True).indices
    top_a12 = a12_scores[top_idx]
    return {
        "tau_mean": float(top_a12.mean().item()),
        "tau_std": float(top_a12.std().item()),
        "tau_top_percent": float(top_percent),
        "tau_count": int(top_a12.numel()),
    }


@torch.no_grad()
def evaluate_variants(
    backbone,
    loader,
    raw_l6_proto: torch.Tensor,
    refined_l6_proto: torch.Tensor,
    refined_l12_proto: torch.Tensor,
    l6_refiner: RiemannianLowRankRefiner,
    l12_refiner: RiemannianLowRankRefiner,
    l6_steps: int,
    l12_steps: int,
    tau: float,
    gamma: float,
    kappa: float,
    resolution: int,
    cal_pro: bool,
) -> dict[str, float]:
    raw_scores = []
    refined_scores = []
    gated_scores = []
    test_imgs = []
    gt_list = []
    gt_mask_list = []

    for data, mask, label, _name, _img_type in loader:
        for f in data:
            test_imgs.append(f.numpy())
        images = _preprocess_batch(backbone, data)
        token_dict = backbone.extract_layer_patch_tokens(images, target_layers=[6, 12])
        raw_l6 = F.normalize(token_dict[6].float(), dim=-1)
        refined_l6 = F.normalize(
            l6_refiner(token_dict[6], semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=l6_steps).refined.float(),
            dim=-1,
        )
        refined_l12 = F.normalize(
            l12_refiner(token_dict[12], semantic_basis=None, spatial_shape=backbone.grid_size, num_steps=l12_steps).refined.float(),
            dim=-1,
        )

        raw_l6_proto_batch = raw_l6_proto.to(raw_l6.device, dtype=raw_l6.dtype).expand(raw_l6.shape[0], -1, -1)
        refined_l6_proto_batch = refined_l6_proto.to(refined_l6.device, dtype=refined_l6.dtype).expand(refined_l6.shape[0], -1, -1)
        refined_l12_proto_batch = refined_l12_proto.to(refined_l12.device, dtype=refined_l12.dtype).expand(refined_l12.shape[0], -1, -1)

        s_raw = 1.0 - F.cosine_similarity(raw_l6, raw_l6_proto_batch, dim=-1)
        s_l6 = 1.0 - F.cosine_similarity(refined_l6, refined_l6_proto_batch, dim=-1)
        a12 = 1.0 - F.cosine_similarity(refined_l12, refined_l12_proto_batch, dim=-1)
        gate = 1.0 + gamma * torch.sigmoid(kappa * (a12 - tau))
        s_gated = s_l6 * gate

        side = backbone.grid_size[0]
        raw_scores += [s for s in s_raw.view(raw_l6.shape[0], side, side).detach().cpu().numpy()]
        refined_scores += [s for s in s_l6.view(refined_l6.shape[0], side, side).detach().cpu().numpy()]
        gated_scores += [s for s in s_gated.view(refined_l6.shape[0], side, side).detach().cpu().numpy()]

        for l, m in zip(label, mask):
            gt_list.append(int(l.numpy() if hasattr(l, "numpy") else l))
            gt_mask_list.append((m.numpy() > 0).astype(np.uint8))

    _, raw_scores, raw_masks = specify_resolution(test_imgs, raw_scores, gt_mask_list, resolution=(resolution, resolution))
    _, refined_scores, refined_masks = specify_resolution(test_imgs, refined_scores, gt_mask_list, resolution=(resolution, resolution))
    _, gated_scores, gated_masks = specify_resolution(test_imgs, gated_scores, gt_mask_list, resolution=(resolution, resolution))

    raw_metrics = metric_cal(np.array(raw_scores), gt_list, raw_masks, cal_pro=cal_pro)
    refined_metrics = metric_cal(np.array(refined_scores), gt_list, refined_masks, cal_pro=cal_pro)
    gated_metrics = metric_cal(np.array(gated_scores), gt_list, gated_masks, cal_pro=cal_pro)
    return {
        "raw_i_roc": float(raw_metrics["i_roc"]),
        "raw_p_roc": float(raw_metrics["p_roc"]),
        "raw_p_pro": float(raw_metrics["p_pro"]),
        "refined_i_roc": float(refined_metrics["i_roc"]),
        "refined_p_roc": float(refined_metrics["p_roc"]),
        "refined_p_pro": float(refined_metrics["p_pro"]),
        "gated_i_roc": float(gated_metrics["i_roc"]),
        "gated_p_roc": float(gated_metrics["p_roc"]),
        "gated_p_pro": float(gated_metrics["p_pro"]),
    }


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu")

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_resize,
        img_cropsize=args.img_cropsize,
    )
    l6_refiner, l6_config = load_refiner(args.l6_ckpt, device)
    l12_refiner, l12_config = load_refiner(args.l12_ckpt, device)
    l6_steps = int(l6_config.get("num_steps", 2))
    l12_steps = int(l12_config.get("num_steps", 2))

    rows = []
    details = {}
    for class_name in args.class_names:
        train_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "train", args.batch_size)
        test_loader = build_dataloader(args.dataset_root, args.split_csv, class_name, "test", args.batch_size)

        raw_l6_proto = build_prototype(backbone, train_loader, 6, None, num_steps=1)
        refined_l6_proto = build_prototype(backbone, train_loader, 6, l6_refiner, num_steps=l6_steps)
        refined_l12_proto = build_prototype(backbone, train_loader, 12, l12_refiner, num_steps=l12_steps)
        tau_meta = estimate_tau_from_train_normals(
            backbone=backbone,
            loader=train_loader,
            l6_refiner=l6_refiner,
            l12_refiner=l12_refiner,
            l6_proto=refined_l6_proto,
            l12_proto=refined_l12_proto,
            l6_steps=l6_steps,
            l12_steps=l12_steps,
            top_percent=args.tau_top_percent,
        )
        metrics = evaluate_variants(
            backbone=backbone,
            loader=test_loader,
            raw_l6_proto=raw_l6_proto,
            refined_l6_proto=refined_l6_proto,
            refined_l12_proto=refined_l12_proto,
            l6_refiner=l6_refiner,
            l12_refiner=l12_refiner,
            l6_steps=l6_steps,
            l12_steps=l12_steps,
            tau=tau_meta["tau_mean"],
            gamma=args.gamma,
            kappa=args.kappa,
            resolution=args.resolution,
            cal_pro=not args.no_pro,
        )

        row = {
            "class_name": class_name,
            "tau_mean": tau_meta["tau_mean"],
            "tau_std": tau_meta["tau_std"],
            "gamma": float(args.gamma),
            "kappa": float(args.kappa),
            "tau_top_percent": float(args.tau_top_percent),
            **metrics,
            "delta_refined_vs_raw_i_roc": metrics["refined_i_roc"] - metrics["raw_i_roc"],
            "delta_refined_vs_raw_p_roc": metrics["refined_p_roc"] - metrics["raw_p_roc"],
            "delta_refined_vs_raw_p_pro": metrics["refined_p_pro"] - metrics["raw_p_pro"],
            "delta_gated_vs_refined_i_roc": metrics["gated_i_roc"] - metrics["refined_i_roc"],
            "delta_gated_vs_refined_p_roc": metrics["gated_p_roc"] - metrics["refined_p_roc"],
            "delta_gated_vs_refined_p_pro": metrics["gated_p_pro"] - metrics["refined_p_pro"],
            "delta_gated_vs_raw_i_roc": metrics["gated_i_roc"] - metrics["raw_i_roc"],
            "delta_gated_vs_raw_p_roc": metrics["gated_p_roc"] - metrics["raw_p_roc"],
            "delta_gated_vs_raw_p_pro": metrics["gated_p_pro"] - metrics["raw_p_pro"],
        }
        rows.append(row)
        details[class_name] = row
        print(
            f"{class_name} | tau={row['tau_mean']:.4f} | "
            f"raw {row['raw_i_roc']:.2f}/{row['raw_p_roc']:.2f}/{row['raw_p_pro']:.2f} | "
            f"ref {row['refined_i_roc']:.2f}/{row['refined_p_roc']:.2f}/{row['refined_p_pro']:.2f} | "
            f"gated {row['gated_i_roc']:.2f}/{row['gated_p_roc']:.2f}/{row['gated_p_pro']:.2f}",
            flush=True,
        )

    csv_path = output_dir / f"{args.output_tag}_aggregate.csv"
    json_path = output_dir / f"{args.output_tag}_aggregate.json"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w") as f:
        json.dump(details, f, indent=2)
    print(f"saved_csv={csv_path}")
    print(f"saved_json={json_path}")


if __name__ == "__main__":
    main()
