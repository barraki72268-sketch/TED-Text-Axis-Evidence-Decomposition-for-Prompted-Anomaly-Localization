#!/usr/bin/env python3
"""Queue FAPrompt ViT-B branch-calibrated runs for seed/std reporting."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]


def run_one(preset: str, seed: int, device: str) -> None:
    save_dir = (
        Path("neurips2026/results")
        / f"faprompt_branchcal_vitb16plus_f3-6-9-12_dpam10_{preset}_"
        f"rank4_a02_officialimg_seed{seed}_20260428"
    )
    cmd = [
        sys.executable,
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        "ViT-B-16-plus-240",
        "--prompt_load_mode",
        "project_crop",
        "--features_list",
        "3",
        "6",
        "9",
        "12",
        "--image_size",
        "518",
        "--batch_size",
        "8",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        "10",
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    print(f"[RUN] seed={seed} preset={preset} device={device} save_dir={save_dir}", flush=True)
    subprocess.run(cmd, check=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--presets", default=",".join(PRESETS))
    args = ap.parse_args()

    for preset in [p.strip() for p in args.presets.split(",") if p.strip()]:
        run_one(preset, seed=args.seed, device=args.device)


if __name__ == "__main__":
    main()
