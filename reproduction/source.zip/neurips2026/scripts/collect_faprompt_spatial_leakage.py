from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import gaussian_filter

ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
FAP_ROOT = ROOT / "neurips2026" / "FAPrompt"
if str(FAP_ROOT) not in sys.path:
    sys.path.insert(0, str(FAP_ROOT))

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl")

import AnomalyCLIP_lib  # noqa: E402
from dataset import Dataset  # noqa: E402
from FAPrompt import FAPrompt  # noqa: E402
from utils import get_transform  # noqa: E402


def topk_mean(arr: np.ndarray, frac: float) -> float:
    flat = arr.reshape(-1)
    k = max(1, int(len(flat) * frac))
    idx = np.argpartition(flat, -k)[-k:]
    return float(flat[idx].mean())


def save_rows(rows, save_dir: Path):
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "metrics.json", "w") as f:
        json.dump(rows, f, indent=2)
    with open(save_dir / "metrics.csv", "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "class_name",
                "num_anomaly",
                "num_normal",
                "inside_mean",
                "outside_mean",
                "inside_outside_gap",
                "outside_inside_ratio",
                "normal_topk_mean",
                "normal_map_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser("Collect baseline-only spatial leakage metrics for FAPrompt")
    parser.add_argument("--data_path", type=str, default="/mnt/data/gijeong/MMAD_new/VisA")
    parser.add_argument("--dataset", type=str, default="visa")
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "faprompt_baseline_mvtec" / "checkpoints" / "epoch_1.pth"),
    )
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--depth", type=int, default=9)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--t_n_ctx", type=int, default=4)
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--topk_frac", type=float, default=0.01)
    parser.add_argument(
        "--save_dir",
        type=str,
        default=str(ROOT / "neurips2026" / "results" / "problem_spatial_faprompt_baseline"),
    )
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = args.device
    params = {
        "Prompt_length": args.n_ctx,
        "learnabel_text_embedding_depth": args.depth,
        "learnabel_text_embedding_length": args.t_n_ctx,
    }
    model, _ = AnomalyCLIP_lib.load("ViT-L/14@336px", device=device, design_details=params)
    model.eval()
    model.visual.DAPM_replace(DPAM_layer=20)

    preprocess, target_transform = get_transform(args)
    dataset = Dataset(root=args.data_path, transform=preprocess, target_transform=target_transform, dataset_name=args.dataset)
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    prompt_learner = FAPrompt(model.to("cpu"), params)
    checkpoint = torch.load(args.checkpoint_path, map_location="cpu")
    prompt_learner.load_state_dict(checkpoint["prompt_learner"])
    prompt_learner.to(device)
    model.to(device)
    prompt_learner.eval()
    model.eval()

    per_class = {
        obj: {
            "num_anomaly": 0,
            "num_normal": 0,
            "inside_sum": 0.0,
            "outside_sum": 0.0,
            "ratio_sum": 0.0,
            "normal_topk_sum": 0.0,
            "normal_mean_sum": 0.0,
        }
        for obj in dataset.obj_list
    }

    with torch.no_grad():
        for items in loader:
            image = items["img"].to(device)
            cls_name = items["cls_name"][0]
            gt_mask = items["img_mask"][0, 0].numpy() > 0.5
            is_anomaly = int(items["anomaly"][0].item())

            image_features, patch_features = model.encode_image(image, args.features_list, DPAM_layer=20)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True)
            patch_features = patch_features / patch_features.norm(dim=-1, keepdim=True)

            prompts_pos, prompts_neg, tokenized_prompt_pos, tokenized_prompt_neg, compound_prompts_text, _ = prompt_learner.forward()
            text_features_pos = model.encode_text_learn(prompts_pos, tokenized_prompt_pos, compound_prompts_text).float()
            text_features_neg = model.encode_text_learn(prompts_neg, tokenized_prompt_neg, compound_prompts_text).float()
            text_features_neg = torch.mean(text_features_neg, dim=0, keepdim=True)
            text_features = torch.cat([text_features_pos, text_features_neg])
            text_features = torch.stack(torch.chunk(text_features, dim=0, chunks=2), dim=1)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

            similarity, _ = AnomalyCLIP_lib.compute_similarity_ori(patch_features, text_features[0])
            similarity_map1 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], args.image_size).squeeze(0)

            num = min(10, similarity[1:, :, 1].shape[0])
            pk_indx = torch.topk(similarity[1:, :, 1], k=num, dim=0, largest=True, sorted=True).indices
            pk_indx = pk_indx.permute(1, 0)
            selected_tokens = []
            for i in range(len(pk_indx)):
                selected_tokens2 = []
                for k in range(len(pk_indx[0])):
                    tmp_token = patch_features[1:, :, :].permute(1, 0, 2)[i, k, :]
                    selected_tokens2.append(tmp_token)
                selected_tokens2 = torch.stack(selected_tokens2)
                selected_tokens.append(selected_tokens2)
            selected_tokens = torch.stack(selected_tokens)

            text_features_list = []
            for i in range(selected_tokens.shape[0]):
                p_pos, p_neg, tok_pos, tok_neg, comp_text, _ = prompt_learner.forward(selected_tokens=selected_tokens[i])
                tf_pos = model.encode_text_learn(p_pos, tok_pos, comp_text).float()
                tf_neg = model.encode_text_learn(p_neg, tok_neg, comp_text).float()
                tf_neg = torch.mean(tf_neg, dim=0, keepdim=True)
                tf = torch.cat([tf_pos, tf_neg])
                text_features_list.append(tf)
            text_features = torch.stack(text_features_list)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

            similarity, _ = AnomalyCLIP_lib.compute_similarity(patch_features, text_features)
            similarity_map2 = AnomalyCLIP_lib.get_similarity_map(similarity[1:, :], args.image_size).squeeze(0)
            anomaly_map = (similarity_map1[1, :] + 1 - similarity_map1[0, :] + similarity_map2[1, :] + 1 - similarity_map2[0, :]) / 4.0
            anomaly_map = gaussian_filter(anomaly_map.detach().cpu().numpy(), sigma=args.sigma)

            stats = per_class[cls_name]
            if is_anomaly and gt_mask.any():
                inside = float(anomaly_map[gt_mask].mean())
                outside = float(anomaly_map[~gt_mask].mean())
                stats["num_anomaly"] += 1
                stats["inside_sum"] += inside
                stats["outside_sum"] += outside
                stats["ratio_sum"] += outside / max(inside, 1e-8)
            else:
                stats["num_normal"] += 1
                stats["normal_topk_sum"] += topk_mean(anomaly_map, args.topk_frac)
                stats["normal_mean_sum"] += float(anomaly_map.mean())

    rows = []
    for cls_name, stats in per_class.items():
        row = {
            "class_name": cls_name,
            "num_anomaly": stats["num_anomaly"],
            "num_normal": stats["num_normal"],
            "inside_mean": stats["inside_sum"] / max(stats["num_anomaly"], 1),
            "outside_mean": stats["outside_sum"] / max(stats["num_anomaly"], 1),
            "inside_outside_gap": (stats["inside_sum"] - stats["outside_sum"]) / max(stats["num_anomaly"], 1),
            "outside_inside_ratio": stats["ratio_sum"] / max(stats["num_anomaly"], 1),
            "normal_topk_mean": stats["normal_topk_sum"] / max(stats["num_normal"], 1),
            "normal_map_mean": stats["normal_mean_sum"] / max(stats["num_normal"], 1),
        }
        rows.append(row)

    mean_row = {
        "class_name": "mean",
        "num_anomaly": sum(r["num_anomaly"] for r in rows),
        "num_normal": sum(r["num_normal"] for r in rows),
        "inside_mean": float(np.mean([r["inside_mean"] for r in rows])),
        "outside_mean": float(np.mean([r["outside_mean"] for r in rows])),
        "inside_outside_gap": float(np.mean([r["inside_outside_gap"] for r in rows])),
        "outside_inside_ratio": float(np.mean([r["outside_inside_ratio"] for r in rows])),
        "normal_topk_mean": float(np.mean([r["normal_topk_mean"] for r in rows])),
        "normal_map_mean": float(np.mean([r["normal_map_mean"] for r in rows])),
    }
    rows.append(mean_row)
    save_rows(rows, Path(args.save_dir))
    print(json.dumps({"num_rows": len(rows), "save_dir": args.save_dir, "mean": mean_row}, indent=2))


if __name__ == "__main__":
    main()
