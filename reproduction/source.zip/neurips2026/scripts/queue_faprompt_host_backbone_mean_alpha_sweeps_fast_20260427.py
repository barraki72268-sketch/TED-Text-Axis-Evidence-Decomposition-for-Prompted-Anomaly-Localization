#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PY = Path("/mnt/data/envs/patchcore-conda/bin/python")
RESULTS = ROOT / "neurips2026" / "results"
SCRIPT = ROOT / "neurips2026" / "scripts" / "official_parallel_test_faprompt.py"

ALPHAS = "-0.2,-0.1,-0.05,-0.02,-0.01,0.005,0.01,0.02,0.05,0.1,0.2"
PRESETS = ["visa2mvtec", "mvtec2visa", "visa2mpdd", "visa2btad"]

BACKBONES = {
    "vith": {
        "save_prefix": "faprompt_vith14_prescore_hostaxis",
        "model_name": "ViT-H-14",
        "prompt_load_mode": "project_crop",
        "features_list": [8, 16, 24, 32],
        "dpam_layer": 30,
        "batch_size": 16,
    },
    "vitl_openai": {
        "save_prefix": "faprompt_vitl14openai_prescore_hostaxis",
        "model_name": "ViT-L/14",
        "prompt_load_mode": "strict",
        "features_list": [6, 12, 18, 24],
        "dpam_layer": 20,
        "batch_size": 16,
    },
}


def run_job(backbone_key: str, preset: str, device: str, num_workers: int) -> None:
    cfg = BACKBONES[backbone_key]
    save_dir = RESULTS / f"{cfg['save_prefix']}_{preset}_fast_20260427"
    summary = save_dir / "summary.json"
    if summary.exists():
        print(f"[skip] {summary}", flush=True)
        return

    save_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(PY),
        "-u",
        str(SCRIPT),
        "--preset",
        preset,
        "--model_name",
        str(cfg["model_name"]),
        "--prompt_load_mode",
        str(cfg["prompt_load_mode"]),
        "--features_list",
        *[str(x) for x in cfg["features_list"]],
        "--image_size",
        "518",
        "--batch_size",
        str(cfg["batch_size"]),
        "--num_workers",
        str(num_workers),
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        str(cfg["dpam_layer"]),
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        f"--alphas={ALPHAS}",
        "--ours_image_score_mode",
        "official",
        "--rectifier_gate_mode",
        "support_mass",
        "--rectifier_gate_sharpness",
        "3.0",
        "--rectifier_direction_mode",
        "host_axis",
        "--bank_chunk",
        "8192",
        "--aupro_max_step",
        "50",
        "--insert_modes",
        "prescore_rectify",
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    print(f"[run] {save_dir}", flush=True)
    print(" ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--backbone", choices=[*BACKBONES, "all"], default="all")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--num_workers", type=int, default=8)
    args = parser.parse_args()

    backbones = list(BACKBONES) if args.backbone == "all" else [args.backbone]
    for backbone_key in backbones:
        for preset in PRESETS:
            run_job(backbone_key, preset, args.device, args.num_workers)
    print("[done] FAPrompt fast alpha sweeps", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
