#!/usr/bin/env python3
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
CSV_PATH = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables" / "direct_separability_ranked_cases_20260504.csv"
FIG_DIR = ROOT / "figure"
OUT_DIR = ROOT / "neurips2026" / "results" / "final_metric_and_novelty_tables"


def load_selected() -> list[dict[str, object]]:
    rows = []
    with CSV_PATH.open() as f:
        for row in csv.DictReader(f):
            if "failure_conditioned_separability_20260504" not in row["path"]:
                continue
            if row["level"] != "class":
                continue
            rowf = {k: row[k] for k in row}
            for k in ("d_pauc", "d_pro", "d_ap", "d_auc_d_hfp", "d_gap_d_hfp", "score"):
                rowf[k] = float(row[k])
            if rowf["d_pro"] > 0 and rowf["d_ap"] > 0 and rowf["d_auc_d_hfp"] > 0 and rowf["d_gap_d_hfp"] > 0:
                rows.append(rowf)
    return sorted(rows, key=lambda r: r["score"], reverse=True)[:4]


def pretty_transfer(setting: str) -> str:
    return setting.replace("faprompt_vitl336_", "").replace("mvtec2", "M→").replace("visa2", "V→").upper()


def main() -> int:
    rows = load_selected()
    labels = [f"{pretty_transfer(str(r['setting']))}\n{r['class_name']}" for r in rows]
    y = np.arange(len(rows))

    pro = np.array([float(r["d_pro"]) for r in rows])
    ap = np.array([float(r["d_ap"]) for r in rows])
    auc = np.array([100.0 * float(r["d_auc_d_hfp"]) for r in rows])
    gap = np.array([100.0 * float(r["d_gap_d_hfp"]) for r in rows])

    fig, axes = plt.subplots(1, 2, figsize=(6.85, 2.15), sharey=True)
    h = 0.34

    axes[0].barh(y + h / 2, pro, height=h, color="#2F6F73", label=r"$\Delta$PRO")
    axes[0].barh(y - h / 2, ap, height=h, color="#E3A12D", label=r"$\Delta$AP")
    axes[0].set_title("(a) Localization gain", fontsize=8.6, fontweight="bold", loc="left")
    axes[0].set_xlabel("gain over B", fontsize=7.6, fontweight="bold")

    axes[1].barh(y + h / 2, auc, height=h, color="#6F5C8C", label=r"$\Delta$AUC")
    axes[1].barh(y - h / 2, gap, height=h, color="#B85450", label=r"$\Delta$Gap")
    axes[1].set_title("(b) Evidence correction", fontsize=8.6, fontweight="bold", loc="left")
    axes[1].set_xlabel("gain", fontsize=7.6, fontweight="bold")

    axes[0].set_yticks(y)
    axes[0].set_yticklabels(labels, fontsize=6.9, fontweight="bold")
    axes[0].invert_yaxis()
    for ax in axes:
        ax.axvline(0, color="#222222", lw=0.8)
        ax.grid(axis="x", color="#E5E0D7", lw=0.65)
        ax.set_axisbelow(True)
        ax.tick_params(axis="x", labelsize=6.9)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        ax.legend(frameon=False, fontsize=6.8, loc="lower right", handlelength=1.2)

    fig.tight_layout(rect=(0, 0, 1, 1.0), w_pad=0.85)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / "direct_failure_conditioned_cases_20260504.pdf", bbox_inches="tight")
    fig.savefig(FIG_DIR / "direct_failure_conditioned_cases_20260504.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    tex = r"""\begin{figure}[t]
\centering
\includegraphics[width=1.0\columnwidth]{figure/direct_failure_conditioned_cases_20260504.pdf}
\caption{
\textbf{Representative hard-FP failure cases.}
Selected class-level cases from the fixed FAPrompt sweep where C-TED improves localization while increasing both defect-vs-hard-FP AUC and defect-minus-hard-FP score gap.
}
\label{fig:direct_failure_conditioned_cases}
\end{figure}
"""
    (OUT_DIR / "direct_failure_conditioned_cases_figure_20260504.tex").write_text(tex)
    print({"figure": "figure/direct_failure_conditioned_cases_20260504.pdf", "rows": len(rows)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
