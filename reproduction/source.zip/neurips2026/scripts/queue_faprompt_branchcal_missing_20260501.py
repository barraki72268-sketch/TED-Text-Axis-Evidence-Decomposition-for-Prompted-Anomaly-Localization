#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"

PRESETS = ["visa2mvtec", "mvtec2visa", "mvtec2mpdd", "mvtec2btad"]

BACKBONES = {
    "vitb16plus": {
        "model_name": "ViT-B-16-plus-240",
        "prompt_load_mode": "project_crop",
        "features": ["3", "6", "9", "12"],
        "dpam_layer": "10",
        "tag": "vitb16plus_f3-6-9-12_dpam10",
    },
    "vitl14openai": {
        "model_name": "ViT-L/14",
        "prompt_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "dpam_layer": "20",
        "tag": "vitl14openai_f6-12-18-24_dpam20",
    },
    "vitl14_336": {
        "model_name": "ViT-L/14@336px",
        "prompt_load_mode": "strict",
        "features": ["6", "12", "18", "24"],
        "dpam_layer": "20",
        "tag": "vitl14_336_f6-12-18-24_dpam20",
    },
    "vith14": {
        "model_name": "ViT-H-14",
        "prompt_load_mode": "project_crop",
        "features": ["8", "16", "24", "32"],
        "dpam_layer": "27",
        "tag": "vith14_f8-16-24-32_dpam27",
    },
}


def parse_csv(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def build_cmd(backbone_key: str, preset: str, seed: int, device: str) -> tuple[Path, list[str]]:
    cfg = BACKBONES[backbone_key]
    save_dir = RESULTS / f"faprompt_branchcal_{cfg['tag']}_{preset}_rank4_a02_officialimg_seed{seed}_20260428"
    cmd = [
        sys.executable,
        "-u",
        "neurips2026/scripts/official_parallel_test_faprompt.py",
        "--preset",
        preset,
        "--model_name",
        cfg["model_name"],
        "--prompt_load_mode",
        cfg["prompt_load_mode"],
        "--features_list",
        *cfg["features"],
        "--image_size",
        "518",
        "--batch_size",
        "4",
        "--num_workers",
        "4",
        "--dap_token_mode",
        "official_firstk",
        "--dpam_layer",
        cfg["dpam_layer"],
        "--max_fp_per_class",
        "512",
        "--max_defect_per_class",
        "512",
        "--max_fp_total",
        "4096",
        "--max_defect_total",
        "4096",
        "--normal_topk_frac",
        "0.01",
        "--tau",
        "0.1",
        "--fp_weight",
        "1.0",
        "--alphas",
        "0.5,1.0,1.5",
        "--ours_image_score_mode",
        "official",
        "--insert_modes",
        "branch_calibrated",
        "--prescore_calib_epochs",
        "30",
        "--prescore_calib_lr",
        "0.02",
        "--prescore_calib_max_train_points",
        "2048",
        "--prescore_calib_alpha_init",
        "0.05",
        "--prescore_calib_alpha_max",
        "0.2",
        "--prescore_calib_subspace_rank",
        "4",
        "--aupro_max_step",
        "50",
        "--seed",
        str(seed),
        "--device",
        device,
        "--save_dir",
        str(save_dir),
    ]
    return save_dir, cmd


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backbones", default="vitb16plus,vitl14openai,vitl14_336,vith14")
    ap.add_argument("--presets", default=",".join(PRESETS))
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    backbones = parse_csv(args.backbones)
    presets = parse_csv(args.presets)
    seeds = [int(x) for x in parse_csv(args.seeds)]
    for backbone in backbones:
        if backbone not in BACKBONES:
            raise SystemExit(f"unknown backbone {backbone}; choices={sorted(BACKBONES)}")
        for preset in presets:
            if preset not in PRESETS:
                raise SystemExit(f"unknown preset {preset}; choices={PRESETS}")
            for seed in seeds:
                save_dir, cmd = build_cmd(backbone, preset, seed, args.device)
                summary = save_dir / "summary.json"
                if summary.exists() and not args.force:
                    print({"stage": "skip", "summary": str(summary)}, flush=True)
                    continue
                print(
                    {
                        "stage": "run",
                        "backbone": backbone,
                        "preset": preset,
                        "seed": seed,
                        "save_dir": str(save_dir),
                    },
                    flush=True,
                )
                print(" ".join(cmd), flush=True)
                subprocess.run(cmd, cwd=str(ROOT), check=True)
    print({"stage": "done", "host": "faprompt"}, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
