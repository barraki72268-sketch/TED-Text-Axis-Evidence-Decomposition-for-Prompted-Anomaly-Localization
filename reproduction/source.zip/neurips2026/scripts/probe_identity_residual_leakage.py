from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
WINCLIP_ROOT = ROOT / "neurips2026" / "WinClip"
if str(WINCLIP_ROOT) not in sys.path:
    sys.path.insert(0, str(WINCLIP_ROOT))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from neurips2026.common_backbones import create_winclip_raw_backbone
from neurips2026.scripts.identity_residual_extractor import IdentityResidualExtractor
from neurips2026.scripts.train_clip_ksm_v2_oracle import forward_up_to_layer, patchify_sequence, score_promptmax, topk_mean
from neurips2026.scripts.train_identity_residual_oracle import (
    build_identity_prompt_bank,
    collect_oracle_records,
    normalize_feat,
    patch_scores_to_pixel_map,
    safe_auc,
    safe_pixel_auc,
    safe_pro,
    stack_batch,
    train_one_epoch,
)
from neurips2026.scripts.kinematic_text_axis_reconstruction import encode_text_features


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Leakage diagnostics for IdentityResidual oracle.")
    parser.add_argument("--dataset_root", type=str, default="/mnt/data/VisA_20220922")
    parser.add_argument("--split_csv", type=str, default="/mnt/data/VisA_20220922/split_csv/1cls.csv")
    parser.add_argument("--class_specs", nargs="+", default=["capsules:12", "fryum:6", "chewinggum:6", "candle:3"])
    parser.add_argument("--backbone", type=str, default="ViT-B-16-plus-240")
    parser.add_argument("--pretrained_dataset", type=str, default="laion400m_e32")
    parser.add_argument("--img_size", type=int, default=240)
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--token_lr_scale", type=float, default=2.0)
    parser.add_argument("--num_id_queries", type=int, default=32)
    parser.add_argument("--num_res_queries", type=int, default=32)
    parser.add_argument("--train_normal_images", type=int, default=12)
    parser.add_argument("--train_anomaly_images", type=int, default=12)
    parser.add_argument("--eval_normal_images", type=int, default=12)
    parser.add_argument("--eval_anomaly_images", type=int, default=12)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--topk_ratio", type=float, default=0.05)
    parser.add_argument("--topk_anom_ratio", type=float, default=0.3)
    parser.add_argument("--lambda_id", type=float, default=1.0)
    parser.add_argument("--lambda_res", type=float, default=1.0)
    parser.add_argument("--lambda_ortho", type=float, default=1.0)
    parser.add_argument("--lambda_zero", type=float, default=1.0)
    parser.add_argument("--hard_neg_ratio", type=float, default=0.2)
    parser.add_argument("--pixel_blur_sigma", type=float, default=4.0)
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--output_dir", type=str, default=str(ROOT / "neurips2026" / "results"))
    parser.add_argument("--output_tag", type=str, default="clip_identity_residual_leakage")
    return parser.parse_args()


def parse_class_spec(spec: str) -> tuple[str, int]:
    class_name, layer = spec.split(":")
    return class_name, int(layer)


def prompt_overlap_stats(E_norm: torch.Tensor, E_anom: torch.Tensor) -> dict[str, float]:
    E_norm_n = normalize_feat(E_norm.float())
    E_anom_n = normalize_feat(E_anom.float())
    cos = torch.matmul(E_anom_n, E_norm_n.T)
    return {
        "prompt_overlap_mean": float(cos.mean().item()),
        "prompt_overlap_max": float(cos.max().item()),
    }


def corrcoef_safe(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=np.float64).reshape(-1)
    b = np.asarray(b, dtype=np.float64).reshape(-1)
    if a.size == 0 or b.size == 0 or a.size != b.size:
        return float("nan")
    if np.allclose(a.std(), 0.0) or np.allclose(b.std(), 0.0):
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def overlay_heatmap(ax, image_np: np.ndarray, heatmap: np.ndarray, title: str) -> None:
    ax.imshow(image_np)
    ax.imshow(heatmap, cmap="jet", alpha=0.55)
    ax.set_title(title)
    ax.axis("off")


def analyze_class(
    backbone,
    class_name: str,
    layer_idx: int,
    args: argparse.Namespace,
    device: str,
) -> tuple[dict[str, float], dict]:
    train_records, eval_records = collect_oracle_records(backbone, class_name, args)
    normal_prompts, abnormal_prompts = build_identity_prompt_bank(class_name)
    E_norm = encode_text_features(backbone, backbone.tokenizer, normal_prompts)
    E_anom = encode_text_features(backbone, backbone.tokenizer, abnormal_prompts)
    p_norm = normalize_feat(E_norm.mean(dim=0))

    model = IdentityResidualExtractor(
        dim=int(E_norm.shape[1]),
        num_id_queries=args.num_id_queries,
        num_res_queries=args.num_res_queries,
        detach_residual_input=True,
    ).to(device)
    token_params = [model.query_id, model.query_res]
    other_params = [p for n, p in model.named_parameters() if n not in {"query_id", "query_res"}]
    optimizer = torch.optim.AdamW(
        [
            {"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay},
            {"params": token_params, "lr": args.lr * args.token_lr_scale, "weight_decay": args.weight_decay},
        ]
    )

    best_state = None
    best_metric = -float("inf")
    history = []
    for epoch in range(1, args.epochs + 1):
        train_stats = train_one_epoch(
            backbone,
            model,
            layer_idx,
            train_records,
            E_norm.to(device),
            E_anom.to(device),
            p_norm.to(device),
            args,
            optimizer,
            device,
        )
        # quick selection on anomaly image score
        eval_image_scores = []
        eval_image_labels = []
        model.eval()
        with torch.no_grad():
            for start in range(0, len(eval_records), args.batch_size):
                batch_records = eval_records[start : start + args.batch_size]
                image_t, _ = stack_batch(batch_records)
                image_t = image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
                seq = forward_up_to_layer(backbone, image_t, layer_idx)
                _, patches = patchify_sequence(seq)
                outputs = model(patches, E_norm.to(device), E_anom=E_anom.to(device), return_aux=True)
                scores = outputs["score"].detach().cpu().numpy()
                for rec, s in zip(batch_records, scores):
                    eval_image_labels.append(rec.label)
                    eval_image_scores.append(topk_mean(np.asarray(s), args.topk_ratio))
        metric = safe_auc(eval_image_labels, eval_image_scores)
        history.append({"epoch": epoch, **train_stats, "eval_prompt_image_auc": metric})
        if metric > best_metric:
            best_metric = metric
            best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}

    if best_state is None:
        raise RuntimeError(f"Failed to train diagnostics model for {class_name}")
    model.load_state_dict(best_state)
    model.eval()

    image_labels = []
    base_image_scores = []
    ours_image_scores = []
    patch_labels = []
    base_patch_scores = []
    ours_patch_scores = []
    gt_masks = []
    base_pixel_maps = []
    ours_pixel_maps = []
    normal_image_base = []
    normal_image_ours = []
    anom_inside_base = []
    anom_outside_base = []
    anom_inside_ours = []
    anom_outside_ours = []
    base_id_corrs = []
    ours_id_corrs = []
    ours_res_corrs = []
    sample_candidates = []

    with torch.no_grad():
        for start in range(0, len(eval_records), args.batch_size):
            batch_records = eval_records[start : start + args.batch_size]
            image_t, mask = stack_batch(batch_records)
            image_t = image_t.to(device=device, dtype=backbone.visual.conv1.weight.dtype)
            seq = forward_up_to_layer(backbone, image_t, layer_idx)
            _, patches = patchify_sequence(seq)
            outputs = model(patches, E_norm.to(device), E_anom=E_anom.to(device), return_aux=True)
            base_scores = score_promptmax(patches, p_norm.to(device), E_anom.to(device))
            ours_scores = outputs["score"].detach().cpu().numpy()
            id_support = outputs["id_support"].detach().cpu().numpy()
            res_evidence = outputs["res_evidence"].detach().cpu().numpy()

            for rec, rec_mask, bs, os, ids, res in zip(batch_records, mask.cpu().numpy(), base_scores, ours_scores, id_support, res_evidence):
                patch_labels.extend(rec_mask.astype(np.int64).tolist())
                base_patch_scores.extend(bs.tolist())
                ours_patch_scores.extend(os.tolist())
                image_labels.append(rec.label)
                base_img = topk_mean(np.asarray(bs), args.topk_ratio)
                ours_img = topk_mean(np.asarray(os), args.topk_ratio)
                base_image_scores.append(base_img)
                ours_image_scores.append(ours_img)

                gt = rec.pixel_mask.astype(np.uint8)
                target_size = int(gt.shape[0])
                base_map = patch_scores_to_pixel_map(np.asarray(bs), target_size, args.pixel_blur_sigma)
                ours_map = patch_scores_to_pixel_map(np.asarray(os), target_size, args.pixel_blur_sigma)
                id_map = patch_scores_to_pixel_map(np.asarray(ids), target_size, args.pixel_blur_sigma)
                res_map = patch_scores_to_pixel_map(np.asarray(res), target_size, args.pixel_blur_sigma)
                gt_masks.append(gt)
                base_pixel_maps.append(base_map)
                ours_pixel_maps.append(ours_map)

                if rec.label == 0:
                    normal_image_base.append(base_img)
                    normal_image_ours.append(ours_img)
                    continue

                pos = gt > 0
                neg = ~pos
                base_in = float(base_map[pos].mean()) if pos.any() else float("nan")
                base_out = float(base_map[neg].mean()) if neg.any() else float("nan")
                ours_in = float(ours_map[pos].mean()) if pos.any() else float("nan")
                ours_out = float(ours_map[neg].mean()) if neg.any() else float("nan")
                anom_inside_base.append(base_in)
                anom_outside_base.append(base_out)
                anom_inside_ours.append(ours_in)
                anom_outside_ours.append(ours_out)
                base_id_corrs.append(corrcoef_safe(base_map, id_map))
                ours_id_corrs.append(corrcoef_safe(ours_map, id_map))
                ours_res_corrs.append(corrcoef_safe(ours_map, res_map))

                sample_candidates.append(
                    {
                        "record": rec,
                        "base_map": base_map,
                        "ours_map": ours_map,
                        "id_map": id_map,
                        "res_map": res_map,
                        "gt": gt,
                        "base_gap": base_in - base_out,
                        "ours_gap": ours_in - ours_out,
                        "base_outside_to_inside": base_out / max(base_in, 1e-6),
                    }
                )

    sample_candidates.sort(key=lambda x: x["base_outside_to_inside"], reverse=True)
    chosen = sample_candidates[0] if sample_candidates else None

    row = {
        "class_name": class_name,
        "layer": layer_idx,
        **prompt_overlap_stats(E_norm, E_anom),
        "base_prompt_image_auc": safe_auc(image_labels, base_image_scores),
        "idres_prompt_image_auc": safe_auc(image_labels, ours_image_scores),
        "prompt_image_auc_delta": safe_auc(image_labels, ours_image_scores) - safe_auc(image_labels, base_image_scores),
        "base_prompt_patch_auc": safe_auc(patch_labels, base_patch_scores),
        "idres_prompt_patch_auc": safe_auc(patch_labels, ours_patch_scores),
        "prompt_patch_auc_delta": safe_auc(patch_labels, ours_patch_scores) - safe_auc(patch_labels, base_patch_scores),
        "base_prompt_pixel_auc": safe_pixel_auc(base_pixel_maps, gt_masks),
        "idres_prompt_pixel_auc": safe_pixel_auc(ours_pixel_maps, gt_masks),
        "prompt_pixel_auc_delta": safe_pixel_auc(ours_pixel_maps, gt_masks) - safe_pixel_auc(base_pixel_maps, gt_masks),
        "base_prompt_p_pro": safe_pro(base_pixel_maps, gt_masks),
        "idres_prompt_p_pro": safe_pro(ours_pixel_maps, gt_masks),
        "prompt_p_pro_delta": safe_pro(ours_pixel_maps, gt_masks) - safe_pro(base_pixel_maps, gt_masks),
        "normal_image_score_base_mean": float(np.mean(normal_image_base)) if normal_image_base else float("nan"),
        "normal_image_score_idres_mean": float(np.mean(normal_image_ours)) if normal_image_ours else float("nan"),
        "normal_image_score_delta": (float(np.mean(normal_image_ours)) - float(np.mean(normal_image_base))) if normal_image_base and normal_image_ours else float("nan"),
        "anom_inside_mean_base": float(np.mean(anom_inside_base)) if anom_inside_base else float("nan"),
        "anom_outside_mean_base": float(np.mean(anom_outside_base)) if anom_outside_base else float("nan"),
        "anom_gap_base": (float(np.mean(anom_inside_base)) - float(np.mean(anom_outside_base))) if anom_inside_base else float("nan"),
        "anom_inside_mean_idres": float(np.mean(anom_inside_ours)) if anom_inside_ours else float("nan"),
        "anom_outside_mean_idres": float(np.mean(anom_outside_ours)) if anom_outside_ours else float("nan"),
        "anom_gap_idres": (float(np.mean(anom_inside_ours)) - float(np.mean(anom_outside_ours))) if anom_inside_ours else float("nan"),
        "outside_to_inside_base": float(np.mean([o / max(i, 1e-6) for i, o in zip(anom_inside_base, anom_outside_base)])) if anom_inside_base else float("nan"),
        "outside_to_inside_idres": float(np.mean([o / max(i, 1e-6) for i, o in zip(anom_inside_ours, anom_outside_ours)])) if anom_inside_ours else float("nan"),
        "base_id_corr_mean": float(np.nanmean(base_id_corrs)) if base_id_corrs else float("nan"),
        "idres_id_corr_mean": float(np.nanmean(ours_id_corrs)) if ours_id_corrs else float("nan"),
        "idres_res_corr_mean": float(np.nanmean(ours_res_corrs)) if ours_res_corrs else float("nan"),
    }

    detail = {
        "class_name": class_name,
        "layer": layer_idx,
        "history": history,
        "summary": row,
    }

    if chosen is not None:
        from neurips2026.winclip_adapters import OfficialVisAWinClipDataset  # local import

        ds = OfficialVisAWinClipDataset(args.dataset_root, args.split_csv, class_name, "test")
        image_native = None
        for idx in range(len(ds)):
            image_arr, _, _, name, _ = ds[idx]
            if name == chosen["record"].name:
                image_native = image_arr
                break
        if image_native is not None:
            fig, axes = plt.subplots(2, 3, figsize=(15, 10))
            axes[0, 0].imshow(image_native)
            axes[0, 0].set_title("Image")
            axes[0, 0].axis("off")
            axes[0, 1].imshow(chosen["gt"], cmap="gray")
            axes[0, 1].set_title("GT Mask")
            axes[0, 1].axis("off")
            overlay_heatmap(axes[0, 2], image_native, chosen["base_map"], "Base Prompt")
            overlay_heatmap(axes[1, 0], image_native, chosen["id_map"], "Identity Support")
            overlay_heatmap(axes[1, 1], image_native, chosen["res_map"], "Residual Evidence")
            overlay_heatmap(axes[1, 2], image_native, chosen["ours_map"], "IdentityResidual")
            fig.suptitle(
                f"{class_name} L{layer_idx} | base_gap={chosen['base_gap']:.4f} | idres_gap={chosen['ours_gap']:.4f}",
                fontsize=12,
            )
            fig.tight_layout()
            detail["visualization_ready"] = True
            detail["chosen_sample_name"] = chosen["record"].name
            detail["chosen_base_gap"] = chosen["base_gap"]
            detail["chosen_idres_gap"] = chosen["ours_gap"]
            detail["figure"] = fig
        else:
            detail["visualization_ready"] = False
    else:
        detail["visualization_ready"] = False

    return row, detail


def main() -> None:
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    device = f"cuda:{args.gpu_id}" if torch.cuda.is_available() else "cpu"

    backbone = create_winclip_raw_backbone(
        backbone=args.backbone,
        pretrained_dataset=args.pretrained_dataset,
        device=device,
        img_resize=args.img_size,
        img_cropsize=args.img_size,
    )
    backbone.eval()
    for p in backbone.parameters():
        p.requires_grad_(False)

    rows = []
    details = []
    for class_name, layer_idx in [parse_class_spec(spec) for spec in args.class_specs]:
        row, detail = analyze_class(backbone, class_name, layer_idx, args, device)
        rows.append(row)

        if detail.pop("visualization_ready", False):
            fig = detail.pop("figure")
            fig_path = out_dir / f"{args.output_tag}_{class_name}_{args.backbone}_L{layer_idx}_heatmap.png"
            fig.savefig(fig_path, dpi=180, bbox_inches="tight")
            plt.close(fig)
            detail["heatmap_path"] = str(fig_path)
        details.append(detail)

    csv_path = out_dir / f"{args.output_tag}_summary.csv"
    json_path = out_dir / f"{args.output_tag}_detail.json"
    fieldnames = sorted({k for row in rows for k in row.keys()})
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    with json_path.open("w") as f:
        json.dump(details, f, indent=2)
    print(f"[saved] {csv_path}")
    print(f"[saved] {json_path}")


if __name__ == "__main__":
    main()
