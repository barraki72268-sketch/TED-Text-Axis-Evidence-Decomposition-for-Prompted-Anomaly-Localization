from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from analyze_realiad_patch_energy_map_aggregation_validation import (  # noqa: E402
    build_backbone,
    extract_backbone_features,
    load_image_tensor,
)
from policy_precheck_common import (  # noqa: E402
    VISA_ROOT,
    VISA_SPLIT_CSV,
    estimate_foreground_mask_grid,
    load_mask_grid,
    load_visa_split_records,
    set_seed,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Naive layer-wise patch-norm probe on VisA.")
    parser.add_argument("--visa_root", type=str, default=VISA_ROOT)
    parser.add_argument("--visa_split_csv", type=str, default=VISA_SPLIT_CSV)
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--backbones", nargs="+", default=["dinov2-large", "clip-large"])
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12, 18, 24])
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--image_score_ratio", type=float, default=0.10)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output_tag", type=str, default="backbone_patchnorm_probe")
    return parser.parse_args()


def safe_roc_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    try:
        return float(roc_auc_score(y_true, y_score))
    except ValueError:
        return float("nan")


def image_score_topk_mean(score_map: np.ndarray, ratio: float) -> float:
    flat = score_map.reshape(-1)
    k = max(1, int(np.ceil(flat.size * ratio)))
    return float(np.partition(flat, -k)[-k:].mean())


def image_score_max(score_map: np.ndarray) -> float:
    return float(score_map.max())


def collect_tokens(
    backbone_bundle: dict,
    image_paths: list[str],
    layers: list[int],
    batch_size: int,
    device: torch.device,
) -> dict[int, torch.Tensor]:
    outputs = {layer: [] for layer in layers}
    preprocess = backbone_bundle["preprocess"]
    with torch.no_grad():
        for start in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[start : start + batch_size]
            batch = torch.cat([load_image_tensor(path, preprocess, device) for path in batch_paths], dim=0)
            feats = extract_backbone_features(backbone_bundle, batch, layers)
            for layer, feat in zip(layers, feats):
                outputs[layer].append(feat.cpu())
    return {layer: torch.cat(chunks, dim=0) for layer, chunks in outputs.items()}


def safe_mean(values: np.ndarray) -> float:
    if values.size == 0:
        return float("nan")
    return float(values.mean())


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    out_dir = ROOT / "neurips2026" / "results"
    out_dir.mkdir(parents=True, exist_ok=True)

    normals = load_visa_split_records(args.visa_root, args.visa_split_csv, args.class_name, "test", "normal")
    anoms = load_visa_split_records(args.visa_root, args.visa_split_csv, args.class_name, "test", "anomaly")
    records = normals + anoms
    image_paths = [record["image_path"] for record in records]
    image_labels = np.asarray([0] * len(normals) + [1] * len(anoms), dtype=np.uint8)

    summary_rows: list[dict[str, object]] = []
    detail_runs: list[dict[str, object]] = []

    for backbone_name in args.backbones:
        device = torch.device(args.device)
        backbone_bundle = build_backbone(backbone_name, device)
        tokens_by_layer = collect_tokens(backbone_bundle, image_paths, args.layers, args.batch_size, device)

        for layer in args.layers:
            feat = tokens_by_layer[layer].float()
            n, patch_count, dim = feat.shape
            side = int(round(patch_count**0.5))
            if side * side != patch_count:
                raise RuntimeError(f"Layer {layer} feature patch count {patch_count} is not square.")

            norm_maps = torch.norm(feat, dim=-1).view(n, side, side).numpy()

            image_scores_top10 = np.asarray(
                [image_score_topk_mean(norm_maps[idx], ratio=args.image_score_ratio) for idx in range(n)],
                dtype=np.float32,
            )
            image_scores_max = np.asarray([image_score_max(norm_maps[idx]) for idx in range(n)], dtype=np.float32)

            patch_labels: list[np.ndarray] = []
            patch_scores: list[np.ndarray] = []
            fg_normal_vals: list[np.ndarray] = []
            fg_anom_vals: list[np.ndarray] = []
            clean_anom_vals: list[np.ndarray] = []
            defect_vals: list[np.ndarray] = []

            for idx, record in enumerate(records):
                fg = estimate_foreground_mask_grid(record["image_path"], side).view(side, side).numpy().astype(bool)
                score = norm_maps[idx]
                patch_scores.append(score.reshape(-1))

                if record["label"] == "normal":
                    patch_labels.append(np.zeros((side * side,), dtype=np.uint8))
                    fg_normal_vals.append(score[fg])
                else:
                    defect = load_mask_grid(record["mask_path"], side).view(side, side).numpy().astype(bool)
                    clean = fg & (~defect)
                    patch_labels.append(defect.reshape(-1).astype(np.uint8))
                    fg_anom_vals.append(score[fg])
                    clean_anom_vals.append(score[clean])
                    defect_vals.append(score[defect])

            patch_auc = safe_roc_auc(
                np.concatenate(patch_labels, axis=0),
                np.concatenate(patch_scores, axis=0),
            )

            row = {
                "class_name": args.class_name,
                "backbone": backbone_name,
                "layer": int(layer),
                "grid_size": int(side),
                "feat_dim": int(dim),
                "n_normals": int(len(normals)),
                "n_anomalies": int(len(anoms)),
                "i_auc_top10": safe_roc_auc(image_labels, image_scores_top10),
                "i_auc_max": safe_roc_auc(image_labels, image_scores_max),
                "p_auc_patch": patch_auc,
                "normal_fg_mean": safe_mean(np.concatenate(fg_normal_vals, axis=0)),
                "anom_fg_mean": safe_mean(np.concatenate(fg_anom_vals, axis=0)),
                "anom_clean_mean": safe_mean(np.concatenate(clean_anom_vals, axis=0)),
                "anom_defect_mean": safe_mean(np.concatenate(defect_vals, axis=0)),
            }
            row["defect_minus_clean_gap"] = float(row["anom_defect_mean"] - row["anom_clean_mean"])
            row["defect_minus_normal_gap"] = float(row["anom_defect_mean"] - row["normal_fg_mean"])
            row["normal_img_mean_top10"] = float(image_scores_top10[: len(normals)].mean())
            row["anom_img_mean_top10"] = float(image_scores_top10[len(normals) :].mean())
            row["normal_img_mean_max"] = float(image_scores_max[: len(normals)].mean())
            row["anom_img_mean_max"] = float(image_scores_max[len(normals) :].mean())
            summary_rows.append(row)

            detail_runs.append(
                {
                    **row,
                    "image_scores_top10": image_scores_top10.tolist(),
                    "image_scores_max": image_scores_max.tolist(),
                }
            )

    summary_df = pd.DataFrame(summary_rows).sort_values(["backbone", "layer"])
    stem = f"{args.output_tag}_{args.class_name}"
    summary_path = out_dir / f"{stem}_summary.csv"
    detail_path = out_dir / f"{stem}_detail.json"
    summary_df.to_csv(summary_path, index=False)
    detail_path.write_text(json.dumps({"class_name": args.class_name, "runs": detail_runs}, indent=2))

    print(json.dumps({"summary_csv": str(summary_path), "detail_json": str(detail_path)}, indent=2))
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
