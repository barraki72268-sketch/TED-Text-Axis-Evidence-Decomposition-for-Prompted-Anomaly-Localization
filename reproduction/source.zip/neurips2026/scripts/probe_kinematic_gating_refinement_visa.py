from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from types import SimpleNamespace

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.manifold import TSNE
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from policy_precheck_common import (  # noqa: E402
    VISA_ROOT,
    VISA_SPLIT_CSV,
    build_backbone as build_dino_backbone,
    estimate_foreground_mask_grid,
    extract_tokens as extract_dino_tokens,
    load_mask_grid,
    load_visa_split_records,
    set_seed,
)
from analyze_realiad_patch_energy_map_aggregation_validation import (  # noqa: E402
    build_backbone as build_legacy_backbone,
    extract_backbone_features,
    load_image_tensor,
)
from probe_zeroshot_geometry_ad_visa import evaluate_layer  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Training-free kinematic gating refinement probe on VisA.")
    parser.add_argument("--visa_root", type=str, default=VISA_ROOT)
    parser.add_argument("--visa_split_csv", type=str, default=VISA_SPLIT_CSV)
    parser.add_argument("--class_name", type=str, default="capsules")
    parser.add_argument("--backbones", nargs="+", default=["dinov2-large", "clip-large"])
    parser.add_argument("--layers", nargs="+", type=int, default=[6, 12, 18, 24])
    parser.add_argument("--image_size", type=int, default=448)
    parser.add_argument("--limit_normals", type=int, default=0)
    parser.add_argument("--limit_anoms", type=int, default=0)
    parser.add_argument("--kernel_size", type=int, default=3)
    parser.add_argument("--pca_rank", type=int, default=1)
    parser.add_argument("--tau_quantile", type=float, default=0.8)
    parser.add_argument("--self_exclude_radius", type=int, default=1)
    parser.add_argument("--match_cos_thresh", type=float, default=0.25)
    parser.add_argument("--ransac_iters", type=int, default=1000)
    parser.add_argument("--ransac_thresh", type=float, default=0.15)
    parser.add_argument("--piecewise_models", type=int, default=2)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--image_score_ratio", type=float, default=0.10)
    parser.add_argument("--tsne_samples_per_group", type=int, default=300)
    parser.add_argument("--alpha_mode", type=str, default="exp", choices=["exp", "rational", "rational_sq", "rational_var"])
    parser.add_argument("--refine_style", type=str, default="normalized", choices=["normalized", "residual_raw"])
    parser.add_argument("--use_inflation", action="store_true")
    parser.add_argument("--inflation_gamma", type=float, default=1.0)
    parser.add_argument("--skip_tsne", action="store_true")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output_tag", type=str, default="kinematic_gating_refinement")
    return parser.parse_args()


def safe_roc_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    try:
        return float(roc_auc_score(y_true, y_score))
    except ValueError:
        return float("nan")


def image_score_topk_mean(score_map: np.ndarray, ratio: float) -> float:
    flat = score_map.reshape(-1)
    k = max(1, int(np.ceil(flat.size * ratio)))
    return float(np.partition(flat, -k)[-k:].mean())


def collect_tokens(
    backbone_bundle: dict,
    image_paths: list[str],
    layers: list[int],
    batch_size: int,
    device: torch.device,
) -> dict[int, torch.Tensor]:
    if backbone_bundle.get("name") == "dinov2-large-fast":
        out = extract_dino_tokens(backbone_bundle["bundle"], image_paths, layers=layers, batch_size=batch_size)
        return {layer: out[layer].float() for layer in layers}
    outputs = {layer: [] for layer in layers}
    preprocess = backbone_bundle["preprocess"]
    with torch.no_grad():
        for start in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[start : start + batch_size]
            batch = torch.cat([load_image_tensor(path, preprocess, device) for path in batch_paths], dim=0)
            feats = extract_backbone_features(backbone_bundle, batch, layers)
            for layer, feat in zip(layers, feats):
                outputs[layer].append(F.normalize(feat.float(), dim=-1).cpu())
    return {layer: torch.cat(chunks, dim=0) for layer, chunks in outputs.items()}


def local_mean_tokens(tokens: torch.Tensor, side: int, kernel_size: int, normalize_output: bool) -> torch.Tensor:
    feat = tokens.view(side, side, -1).permute(2, 0, 1).unsqueeze(0)  # [1, D, H, W]
    unfolded = F.unfold(feat, kernel_size=kernel_size, padding=kernel_size // 2)
    d = feat.shape[1]
    k2 = kernel_size * kernel_size
    unfolded = unfolded.view(1, d, k2, side * side)
    mean = unfolded.mean(dim=2).squeeze(0).T
    if normalize_output:
        mean = F.normalize(mean, dim=-1)
    return mean


def local_variance_map(tokens: torch.Tensor, side: int, kernel_size: int) -> torch.Tensor:
    feat = tokens.view(side, side, -1).permute(2, 0, 1).unsqueeze(0)
    unfolded = F.unfold(feat, kernel_size=kernel_size, padding=kernel_size // 2)
    d = feat.shape[1]
    k2 = kernel_size * kernel_size
    unfolded = unfolded.view(1, d, k2, side * side).squeeze(0).permute(2, 1, 0)  # [HW, D, K2]
    mean = unfolded.mean(dim=-1, keepdim=True)
    var = (unfolded - mean).pow(2).mean(dim=(1, 2))
    return var


def refine_tokens(
    tokens: torch.Tensor,
    e_pca: torch.Tensor,
    e_geo: torch.Tensor,
    fg: torch.Tensor,
    kernel_size: int,
    alpha_mode: str,
    refine_style: str,
    use_inflation: bool,
    inflation_gamma: float,
) -> tuple[torch.Tensor, torch.Tensor, float]:
    side = int(round(tokens.shape[0] ** 0.5))
    local_mean = local_mean_tokens(
        tokens,
        side=side,
        kernel_size=kernel_size,
        normalize_output=(refine_style == "normalized"),
    )
    energy = e_pca + e_geo
    tau = float(energy[fg].mean().item()) if fg.any() else float(energy.mean().item())
    tau = max(tau, 1e-8)
    lam = energy / tau
    if alpha_mode == "exp":
        alpha = torch.exp(-lam)
    elif alpha_mode == "rational":
        alpha = 1.0 / (1.0 + lam)
    elif alpha_mode == "rational_sq":
        alpha = 1.0 / (1.0 + lam.square())
    elif alpha_mode == "rational_var":
        sigma2 = local_variance_map(tokens, side=side, kernel_size=kernel_size)
        sigma2_scale = float(sigma2[fg].mean().item()) if fg.any() else float(sigma2.mean().item())
        sigma2_scale = max(sigma2_scale, 1e-8)
        sigma2_norm = sigma2 / sigma2_scale
        alpha = 1.0 / (1.0 + lam * sigma2_norm)
    else:
        raise ValueError(f"Unknown alpha_mode: {alpha_mode}")
    alpha = alpha.clamp(0.0, 1.0)
    if refine_style == "normalized":
        mixed = (1.0 - alpha.unsqueeze(-1)) * tokens + alpha.unsqueeze(-1) * local_mean
        refined = F.normalize(mixed, dim=-1)
    elif refine_style == "residual_raw":
        refined = tokens + alpha.unsqueeze(-1) * (local_mean - tokens)
    else:
        raise ValueError(f"Unknown refine_style: {refine_style}")
    if use_inflation:
        inflation = 1.0 + torch.tanh(inflation_gamma * lam)
        refined = refined * inflation.unsqueeze(-1)
    return refined, alpha, tau


def pairwise_cosine_mean(x: torch.Tensor, max_samples: int = 2048, seed: int = 7) -> float:
    if x.shape[0] < 2:
        return float("nan")
    if x.shape[0] > max_samples:
        gen = torch.Generator(device=x.device)
        gen.manual_seed(seed)
        idx = torch.randperm(x.shape[0], generator=gen, device=x.device)[:max_samples]
        x = x[idx]
    sims = x @ x.T
    n = x.shape[0]
    mask = ~torch.eye(n, dtype=torch.bool, device=x.device)
    return float(sims[mask].mean().item())


def mean_cosine_to_centroid(x: torch.Tensor, centroid: torch.Tensor) -> float:
    if x.shape[0] == 0:
        return float("nan")
    centroid = F.normalize(centroid, dim=-1)
    return float((x @ centroid).mean().item())


def mean_distance_to_centroid(x: torch.Tensor, centroid: torch.Tensor) -> float:
    if x.shape[0] == 0:
        return float("nan")
    return float(torch.norm(x - centroid.unsqueeze(0), dim=-1).mean().item())


def mean_alignment_cos(x_raw: torch.Tensor, x_ref: torch.Tensor) -> float:
    if x_raw.shape[0] == 0:
        return float("nan")
    x_raw_n = F.normalize(x_raw, dim=-1)
    x_ref_n = F.normalize(x_ref, dim=-1)
    return float((x_raw_n * x_ref_n).sum(dim=-1).mean().item())


def mean_relative_shift(x_raw: torch.Tensor, x_ref: torch.Tensor) -> float:
    if x_raw.shape[0] == 0:
        return float("nan")
    denom = torch.norm(x_raw, dim=-1).clamp_min(1e-8)
    rel = torch.norm(x_ref - x_raw, dim=-1) / denom
    return float(rel.mean().item())


def knn_retention(x_raw: torch.Tensor, x_ref: torch.Tensor, k: int, max_samples: int, seed: int) -> float:
    if x_raw.shape[0] <= k:
        return float("nan")
    if x_raw.shape[0] > max_samples:
        gen = torch.Generator(device=x_raw.device)
        gen.manual_seed(seed)
        idx = torch.randperm(x_raw.shape[0], generator=gen, device=x_raw.device)[:max_samples]
        x_raw = x_raw[idx]
        x_ref = x_ref[idx]
    raw_dist = torch.cdist(x_raw, x_raw)
    ref_dist = torch.cdist(x_ref, x_ref)
    inf = torch.tensor(float("inf"), device=x_raw.device, dtype=x_raw.dtype)
    raw_dist.fill_diagonal_(inf)
    ref_dist.fill_diagonal_(inf)
    raw_knn = torch.topk(raw_dist, k, largest=False).indices
    ref_knn = torch.topk(ref_dist, k, largest=False).indices
    overlap = 0.0
    for i in range(raw_knn.shape[0]):
        overlap += len(set(raw_knn[i].tolist()) & set(ref_knn[i].tolist())) / float(k)
    return float(overlap / raw_knn.shape[0])


def sample_points(x: torch.Tensor, n: int, seed: int) -> torch.Tensor:
    if x.shape[0] <= n:
        return x
    gen = torch.Generator(device=x.device)
    gen.manual_seed(seed)
    idx = torch.randperm(x.shape[0], generator=gen, device=x.device)[:n]
    return x[idx]


def save_tsne_plot(
    out_path: Path,
    normal_before: torch.Tensor,
    clean_before: torch.Tensor,
    defect_before: torch.Tensor,
    normal_after: torch.Tensor,
    clean_after: torch.Tensor,
    defect_after: torch.Tensor,
    seed: int,
    title: str,
) -> None:
    def build_group(normal_x: torch.Tensor, clean_x: torch.Tensor, defect_x: torch.Tensor) -> tuple[np.ndarray, list[str]]:
        arr = torch.cat([normal_x, clean_x, defect_x], dim=0).cpu().numpy()
        labels = (
            ["normal"] * normal_x.shape[0]
            + ["anom_clean"] * clean_x.shape[0]
            + ["defect"] * defect_x.shape[0]
        )
        return arr, labels

    before_arr, before_labels = build_group(normal_before, clean_before, defect_before)
    after_arr, after_labels = build_group(normal_after, clean_after, defect_after)
    tsne_before = TSNE(n_components=2, random_state=seed, init="pca", learning_rate="auto").fit_transform(before_arr)
    tsne_after = TSNE(n_components=2, random_state=seed, init="pca", learning_rate="auto").fit_transform(after_arr)

    colors = {"normal": "#1f77b4", "anom_clean": "#2ca02c", "defect": "#d62728"}
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, emb, labels, name in [
        (axes[0], tsne_before, before_labels, "before"),
        (axes[1], tsne_after, after_labels, "after"),
    ]:
        for key in ["normal", "anom_clean", "defect"]:
            mask = np.asarray([lab == key for lab in labels], dtype=bool)
            if mask.any():
                ax.scatter(emb[mask, 0], emb[mask, 1], s=8, alpha=0.7, c=colors[key], label=key)
        ax.set_title(name)
        ax.legend(loc="best", fontsize=8)
        ax.set_xticks([])
        ax.set_yticks([])
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    out_dir = ROOT / "neurips2026" / "results"
    out_dir.mkdir(parents=True, exist_ok=True)

    normals = load_visa_split_records(args.visa_root, args.visa_split_csv, args.class_name, "test", "normal")
    anoms = load_visa_split_records(args.visa_root, args.visa_split_csv, args.class_name, "test", "anomaly")
    if args.limit_normals > 0:
        normals = normals[: args.limit_normals]
    if args.limit_anoms > 0:
        anoms = anoms[: args.limit_anoms]
    records = normals + anoms
    image_paths = [record["image_path"] for record in records]
    image_labels = np.asarray([0] * len(normals) + [1] * len(anoms), dtype=np.uint8)

    geometry_args = SimpleNamespace(
        kernel_size=args.kernel_size,
        pca_rank=args.pca_rank,
        tau_quantile=args.tau_quantile,
        self_exclude_radius=args.self_exclude_radius,
        match_cos_thresh=args.match_cos_thresh,
        ransac_iters=args.ransac_iters,
        ransac_thresh=args.ransac_thresh,
        piecewise_models=args.piecewise_models,
        seed=args.seed,
    )

    summary_rows: list[dict[str, object]] = []

    for backbone_name in args.backbones:
        device = torch.device(args.device)
        if backbone_name == "dinov2-large":
            backbone_bundle = {
                "name": "dinov2-large-fast",
                "bundle": build_dino_backbone(device, image_size=args.image_size),
            }
        else:
            backbone_bundle = build_legacy_backbone(backbone_name, device)
        tokens_by_layer = collect_tokens(backbone_bundle, image_paths, args.layers, args.batch_size, device)

        for layer in args.layers:
            feat_all = tokens_by_layer[layer]
            n, patch_count, dim = feat_all.shape
            side = int(round(patch_count**0.5))
            if side * side != patch_count:
                raise RuntimeError(f"Layer {layer} feature patch count {patch_count} is not square.")

            before_maps = torch.norm(feat_all, dim=-1).view(n, side, side).numpy()
            after_maps: list[np.ndarray] = []
            image_scores_before: list[float] = []
            image_scores_after: list[float] = []

            normal_fg_before: list[torch.Tensor] = []
            normal_fg_after: list[torch.Tensor] = []
            defect_before: list[torch.Tensor] = []
            defect_after: list[torch.Tensor] = []
            clean_before: list[torch.Tensor] = []
            clean_after: list[torch.Tensor] = []
            alpha_means: list[float] = []

            patch_labels: list[np.ndarray] = []
            patch_scores_before: list[np.ndarray] = []
            patch_scores_after: list[np.ndarray] = []

            for idx, record in enumerate(records):
                tokens = feat_all[idx].to(device)
                fg = estimate_foreground_mask_grid(record["image_path"], side, image_size=args.image_size).to(device)
                defect = None
                defect_mask_np = np.zeros((side, side), dtype=np.uint8)
                if record["label"] == "anomaly":
                    defect = load_mask_grid(record["mask_path"], side).to(device)
                    defect_mask_np = defect.view(side, side).cpu().numpy().astype(np.uint8)

                payload = evaluate_layer(tokens, fg, defect, geometry_args)
                e_pca = torch.tensor(payload["maps"]["e_pca"], dtype=torch.float32, device=device).view(-1)
                e_geo = torch.tensor(payload["maps"]["e_geo"], dtype=torch.float32, device=device).view(-1)

                refined, alpha, tau = refine_tokens(
                    tokens,
                    e_pca,
                    e_geo,
                    fg,
                    kernel_size=args.kernel_size,
                    alpha_mode=args.alpha_mode,
                    refine_style=args.refine_style,
                    use_inflation=args.use_inflation,
                    inflation_gamma=args.inflation_gamma,
                )
                alpha_means.append(float(alpha[fg].mean().item()) if fg.any() else float(alpha.mean().item()))

                before_norm = torch.norm(tokens, dim=-1).view(side, side)
                after_norm = torch.norm(refined, dim=-1).view(side, side)
                after_maps.append(after_norm.cpu().numpy())
                image_scores_before.append(image_score_topk_mean(before_norm.cpu().numpy(), ratio=args.image_score_ratio))
                image_scores_after.append(image_score_topk_mean(after_norm.cpu().numpy(), ratio=args.image_score_ratio))

                fg2d = fg.view(side, side)
                tokens_before_fg = tokens[fg]
                tokens_after_fg = refined[fg]

                patch_labels.append(defect_mask_np.reshape(-1))
                patch_scores_before.append(before_norm.cpu().numpy().reshape(-1))
                patch_scores_after.append(after_norm.cpu().numpy().reshape(-1))

                if record["label"] == "normal":
                    normal_fg_before.append(tokens_before_fg.detach().cpu())
                    normal_fg_after.append(tokens_after_fg.detach().cpu())
                else:
                    defect_flat = defect.to(device)
                    clean_flat = fg & (~defect_flat)
                    if defect_flat.any():
                        defect_before.append(tokens[defect_flat].detach().cpu())
                        defect_after.append(refined[defect_flat].detach().cpu())
                    if clean_flat.any():
                        clean_before.append(tokens[clean_flat].detach().cpu())
                        clean_after.append(refined[clean_flat].detach().cpu())

            normal_before_all = torch.cat(normal_fg_before, dim=0)
            normal_after_all = torch.cat(normal_fg_after, dim=0)
            clean_before_all = torch.cat(clean_before, dim=0) if clean_before else torch.empty((0, dim))
            clean_after_all = torch.cat(clean_after, dim=0) if clean_after else torch.empty((0, dim))
            defect_before_all = torch.cat(defect_before, dim=0) if defect_before else torch.empty((0, dim))
            defect_after_all = torch.cat(defect_after, dim=0) if defect_after else torch.empty((0, dim))

            normal_centroid_before = F.normalize(normal_before_all.mean(dim=0), dim=-1)
            normal_centroid_after = F.normalize(normal_after_all.mean(dim=0), dim=-1)

            row = {
                "class_name": args.class_name,
                "backbone": backbone_name,
                "layer": int(layer),
                "alpha_mode": args.alpha_mode,
                "refine_style": args.refine_style,
                "use_inflation": bool(args.use_inflation),
                "inflation_gamma": float(args.inflation_gamma),
                "image_size": int(args.image_size),
                "grid_size": int(side),
                "feat_dim": int(dim),
                "i_auc_norm_before": safe_roc_auc(image_labels, np.asarray(image_scores_before, dtype=np.float32)),
                "i_auc_norm_after": safe_roc_auc(image_labels, np.asarray(image_scores_after, dtype=np.float32)),
                "p_auc_norm_before": safe_roc_auc(np.concatenate(patch_labels), np.concatenate(patch_scores_before)),
                "p_auc_norm_after": safe_roc_auc(np.concatenate(patch_labels), np.concatenate(patch_scores_after)),
                "normal_pairwise_cos_before": pairwise_cosine_mean(normal_before_all, seed=args.seed),
                "normal_pairwise_cos_after": pairwise_cosine_mean(normal_after_all, seed=args.seed),
                "normal_to_centroid_cos_before": mean_cosine_to_centroid(normal_before_all, normal_centroid_before),
                "normal_to_centroid_cos_after": mean_cosine_to_centroid(normal_after_all, normal_centroid_after),
                "clean_to_centroid_dist_before": mean_distance_to_centroid(clean_before_all, normal_centroid_before),
                "clean_to_centroid_dist_after": mean_distance_to_centroid(clean_after_all, normal_centroid_after),
                "defect_to_centroid_dist_before": mean_distance_to_centroid(defect_before_all, normal_centroid_before),
                "defect_to_centroid_dist_after": mean_distance_to_centroid(defect_after_all, normal_centroid_after),
                "normal_align_cos": mean_alignment_cos(normal_before_all, normal_after_all),
                "clean_align_cos": mean_alignment_cos(clean_before_all, clean_after_all),
                "defect_align_cos": mean_alignment_cos(defect_before_all, defect_after_all),
                "normal_rel_shift": mean_relative_shift(normal_before_all, normal_after_all),
                "clean_rel_shift": mean_relative_shift(clean_before_all, clean_after_all),
                "defect_rel_shift": mean_relative_shift(defect_before_all, defect_after_all),
                "normal_knn1_retention": knn_retention(normal_before_all, normal_after_all, k=1, max_samples=2048, seed=args.seed),
                "normal_knn5_retention": knn_retention(normal_before_all, normal_after_all, k=5, max_samples=2048, seed=args.seed),
                "alpha_fg_mean": float(np.mean(alpha_means)),
            }
            row["normal_cos_gain"] = float(row["normal_pairwise_cos_after"] - row["normal_pairwise_cos_before"])
            row["defect_clean_sep_before"] = float(
                row["defect_to_centroid_dist_before"] - row["clean_to_centroid_dist_before"]
            )
            row["defect_clean_sep_after"] = float(
                row["defect_to_centroid_dist_after"] - row["clean_to_centroid_dist_after"]
            )
            row["defect_clean_sep_gain"] = float(row["defect_clean_sep_after"] - row["defect_clean_sep_before"])
            row["i_auc_norm_gain"] = float(row["i_auc_norm_after"] - row["i_auc_norm_before"])
            row["p_auc_norm_gain"] = float(row["p_auc_norm_after"] - row["p_auc_norm_before"])
            summary_rows.append(row)

            if not args.skip_tsne:
                normal_before_plot = sample_points(normal_before_all, args.tsne_samples_per_group, args.seed)
                normal_after_plot = sample_points(normal_after_all, args.tsne_samples_per_group, args.seed)
                clean_before_plot = sample_points(clean_before_all, args.tsne_samples_per_group, args.seed + 1)
                clean_after_plot = sample_points(clean_after_all, args.tsne_samples_per_group, args.seed + 1)
                defect_before_plot = sample_points(defect_before_all, args.tsne_samples_per_group, args.seed + 2)
                defect_after_plot = sample_points(defect_after_all, args.tsne_samples_per_group, args.seed + 2)
                tsne_path = out_dir / f"{args.output_tag}_{args.class_name}_{backbone_name}_L{layer}_tsne.png"
                save_tsne_plot(
                    tsne_path,
                    normal_before_plot,
                    clean_before_plot,
                    defect_before_plot,
                    normal_after_plot,
                    clean_after_plot,
                    defect_after_plot,
                    seed=args.seed,
                    title=f"{args.class_name} {backbone_name} L{layer} {args.alpha_mode}",
                )

    summary_df = pd.DataFrame(summary_rows).sort_values(["backbone", "layer"])
    stem = f"{args.output_tag}_{args.class_name}"
    summary_path = out_dir / f"{stem}_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    print(json.dumps({"summary_csv": str(summary_path)}, indent=2))
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
