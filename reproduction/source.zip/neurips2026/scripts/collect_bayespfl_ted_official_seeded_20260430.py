from __future__ import annotations

import json
import argparse
from pathlib import Path

import numpy as np


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
DEFAULT_RESULT_ROOT = ROOT / "neurips2026/results/bayespfl_ted_official_mvtecsource_seeded_20260430"
TARGETS = [
    ("mvtec2mvtec", "MVTec"),
    ("mvtec2visa", "VisA"),
    ("mvtec2mpdd", "MPDD"),
    ("mvtec2btad", "BTAD"),
]
METHODS = [
    ("Base", "baseline_txt"),
    ("Train-free TED", "ted_trainfree"),
    ("Calibrated TED", "ted_calibrated"),
]
METRICS = [
    ("I-AUROC", "image_auroc"),
    ("P-AUROC", "pixel_auroc"),
    ("P-PRO", "pixel_aupro"),
    ("P-AP", "pixel_ap"),
]


def load_mean_row(path: Path, mode: str) -> dict | None:
    if not path.exists():
        return None
    payload = json.loads(path.read_text())
    for row in payload["rows"]:
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return row
    return None


def fmt(values: list[float]) -> str:
    arr = np.array(values, dtype=np.float64)
    if arr.size == 0 or np.all(np.isnan(arr)):
        return "--.--"
    return f"{100*np.nanmean(arr):.2f}$\\pm${100*np.nanstd(arr):.2f}"


def main() -> None:
    parser = argparse.ArgumentParser("Collect BayesPFL TED seeded table rows.")
    parser.add_argument("--result_root", type=str, default=str(DEFAULT_RESULT_ROOT))
    parser.add_argument("--title", type=str, default="BayesPFL ViT-L/14-336, MVTec-source checkpoint, official roots")
    args = parser.parse_args()
    result_root = Path(args.result_root)
    print(f"% {args.title}")
    print("% Each cell: I-AUROC / P-AUROC / P-PRO / P-AP")
    for transfer, target in TARGETS:
        print(f"\n% Target: {target} ({transfer})")
        for method_label, mode in METHODS:
            metric_values = {metric_key: [] for _, metric_key in METRICS}
            for seed in (0, 1, 2):
                row = load_mean_row(result_root / f"{transfer}_seed{seed}" / "summary.json", mode)
                if row is None:
                    continue
                for _, metric_key in METRICS:
                    metric_values[metric_key].append(float(row[metric_key]))
            cell = " / ".join(fmt(metric_values[metric_key]) for _, metric_key in METRICS)
            print(f"{method_label} & {cell} \\\\")


if __name__ == "__main__":
    main()
