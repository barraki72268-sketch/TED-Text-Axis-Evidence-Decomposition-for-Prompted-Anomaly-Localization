from __future__ import annotations

import argparse
import csv
import gc
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
RESULTS = ROOT / "neurips2026" / "results"
SCRIPT_ROOT = ROOT / "neurips2026" / "scripts"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

from neurips2026.common_backbones import create_imagebind_raw_backbone, create_winclip_raw_backbone  # noqa: E402
from official_parallel_test_rawclip import GenericMetaDataset, build_transforms as build_clip_transforms, load_bank_cache as load_rawclip_bank_cache  # noqa: E402
from official_parallel_test_rawclip import logmeanexp_negative_sqdist_1d, topk_mean as map_topk_mean  # noqa: E402
from official_parallel_test_rawclip import smooth_map as smooth_clip_map  # noqa: E402
from official_parallel_test_rawimagebind import activate_margin_map, encode_prompt_pair as encode_imagebind_prompt_pair  # noqa: E402
from official_parallel_test_rawimagebind import load_bank_cache as load_imagebind_bank_cache  # noqa: E402


PRESET_LABELS = {
    "visa2mvtec": "VisA→MVTec",
    "mvtec2visa": "MVTec→VisA",
    "mvtec2mpdd": "MVTec→MPDD",
    "mvtec2btad": "MVTec→BTAD",
}

TARGET_ROOTS = {
    "visa2mvtec": Path("/mnt/data/pilab-kingjinyoung/ijepa/data/mvtec"),
    "mvtec2visa": ROOT / "neurips2026" / "data" / "VisA_pytorch_official" / "1cls",
    "mvtec2mpdd": Path("/mnt/data/MPDD"),
    "mvtec2btad": ROOT / "neurips2026" / "data" / "BTAD_official",
}

MODEL_SPECS = {
    "rawclip_vitb": {
        "family": "rawclip",
        "display_name": "RawCLIP ViT-B",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitb_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitb_mvtec2btad_all" / "summary.json",
        },
    },
    "rawclip_vitl": {
        "family": "rawclip",
        "display_name": "RawCLIP ViT-L",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitl_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitl_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitl_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitl_mvtec2btad_all" / "summary.json",
        },
    },
    "rawclip_vitl14openai": {
        "family": "rawclip",
        "display_name": "RawCLIP ViT-L OpenAI",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vitl14openai_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vitl14openai_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vitl14openai_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vitl14openai_mvtec2btad_all" / "summary.json",
        },
    },
    "rawclip_vith14": {
        "family": "rawclip",
        "display_name": "RawCLIP ViT-H",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawclip_vith14_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawclip_vith14_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawclip_vith14_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawclip_vith14_mvtec2btad_all" / "summary.json",
        },
    },
    "rawimagebind": {
        "family": "rawimagebind",
        "display_name": "RawImageBind",
        "summaries": {
            "visa2mvtec": RESULTS / "official_parallel_test_rawimagebind_visa2mvtec_all" / "summary.json",
            "mvtec2visa": RESULTS / "official_parallel_test_rawimagebind_mvtec2visa_all" / "summary.json",
            "mvtec2mpdd": RESULTS / "official_parallel_test_rawimagebind_mvtec2mpdd_all" / "summary.json",
            "mvtec2btad": RESULTS / "official_parallel_test_rawimagebind_mvtec2btad_all" / "summary.json",
        },
    },
}


def load_json(path: Path) -> dict:
    with path.open("r") as f:
        return json.load(f)


def compute_auc(pos: np.ndarray, neg: np.ndarray) -> float:
    labels = np.concatenate([np.ones_like(pos), np.zeros_like(neg)])
    scores = np.concatenate([pos, neg])
    order = np.argsort(scores)
    ranks = np.empty_like(order)
    ranks[order] = np.arange(order.size)
    pos_ranks = ranks[: pos.size]
    u = float(pos_ranks.sum() - pos.size * (pos.size - 1) / 2.0)
    return float(u / max(pos.size * neg.size, 1))


def histogram_overlap(pos: np.ndarray, neg: np.ndarray, bins: int = 60) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    lo = float(min(pos.min(), neg.min()))
    hi = float(max(pos.max(), neg.max()))
    if hi <= lo:
        hi = lo + 1e-6
    edges = np.linspace(lo, hi, bins + 1)
    pos_hist, _ = np.histogram(pos, bins=edges, density=True)
    neg_hist, _ = np.histogram(neg, bins=edges, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    overlap = np.minimum(pos_hist, neg_hist)
    ovl = float(np.sum(overlap * np.diff(edges)))
    return centers, pos_hist, neg_hist, ovl


def cohens_d(pos: np.ndarray, neg: np.ndarray) -> float:
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    v1 = float(np.var(pos, ddof=1)) if pos.size > 1 else 0.0
    v0 = float(np.var(neg, ddof=1)) if neg.size > 1 else 0.0
    denom = pos.size + neg.size - 2
    if denom <= 0:
        return float("nan")
    pooled = math.sqrt(max(((pos.size - 1) * v1 + (neg.size - 1) * v0) / denom, 1e-12))
    return float((float(np.mean(pos)) - float(np.mean(neg))) / pooled)


def distribution_metrics(pos: np.ndarray, neg: np.ndarray) -> dict:
    _, _, _, ovl = histogram_overlap(pos, neg, bins=60)
    auc = compute_auc(pos, neg)
    mean_gap = float(np.mean(pos) - np.mean(neg))
    return {
        "auc": float(auc),
        "ovl": float(ovl),
        "bayes_error_lb": float(0.5 * ovl),
        "mean_gap": mean_gap,
        "cohens_d": cohens_d(pos, neg),
    }


def compute_rawclip_maps(backbone, item: dict, fp_banks: dict[int, torch.Tensor], def_banks: dict[int, torch.Tensor], meta: dict):
    image = item["img"].unsqueeze(0).to(backbone.device)
    cls_name = item["cls_name"]
    text_pair = __import__("generate_rawclip_qualitative").compute_maps  # type: ignore[attr-defined]


def _compute_rawclip_scores(backbone, item: dict, fp_banks: dict[int, torch.Tensor], def_banks: dict[int, torch.Tensor], meta: dict) -> tuple[float, float]:
    from generate_rawclip_qualitative import compute_maps  # local import to keep startup light

    class Args:
        pass

    args = Args()
    args.prompt_mode = meta["prompt_mode"]
    args.features_list = list(meta["features_list"])
    args.image_size = int(meta["image_size"])
    args.sigma = float(meta["sigma"])
    args.tau = float(meta["tau"])
    args.image_score_topk = float(meta["image_score_topk"])
    baseline_map, parallel_map, _, _ = compute_maps(backbone, item, fp_banks, def_banks, args)
    return map_topk_mean(baseline_map.reshape(-1), args.image_score_topk), map_topk_mean(
        parallel_map.reshape(-1), args.image_score_topk
    )


def _compute_imagebind_scores(backbone, item: dict, fp_banks: dict[int, torch.Tensor], def_banks: dict[int, torch.Tensor], meta: dict) -> tuple[float, float]:
    image = item["img"].unsqueeze(0).to(backbone.device)
    cls_name = item["cls_name"]
    text_pair = encode_imagebind_prompt_pair(backbone, cls_name, meta["prompt_mode"])
    global_feat = backbone.encode_global_image(image)
    global_logits = global_feat @ torch.stack([text_pair["norm_joint"], text_pair["anom_joint"]], dim=1)
    global_anom_prob = float((global_logits / 0.07).softmax(dim=-1)[0, 1].item())

    patch_dict = backbone.extract_layer_patch_tokens(image, target_layers=meta["features_list"], project_to_joint=True)
    baseline_layer_maps = []
    parallel_layer_maps = []
    for out_idx, layer in enumerate(meta["features_list"]):
        patch = F.normalize(patch_dict[layer][0].float(), dim=-1)
        logits = patch @ torch.stack([text_pair["norm_joint"], text_pair["anom_joint"]], dim=1)
        probs = (logits / 0.07).softmax(dim=-1)[:, 1]
        side = int(round(math.sqrt(patch.shape[0])))
        baseline_map = probs.reshape(1, 1, side, side)
        baseline_map = F.interpolate(
            baseline_map,
            size=(int(meta["image_size"]), int(meta["image_size"])),
            mode="bilinear",
            align_corners=False,
        )[:, 0]
        baseline_layer_maps.append(baseline_map)

        axis = text_pair["axis_joint"]
        coeff = patch @ axis
        fp_coeff = fp_banks[out_idx].to(backbone.device) @ axis if fp_banks[out_idx].numel() else torch.empty((0,), device=backbone.device)
        def_coeff = def_banks[out_idx].to(backbone.device) @ axis if def_banks[out_idx].numel() else torch.empty((0,), device=backbone.device)
        q_fp = logmeanexp_negative_sqdist_1d(coeff, fp_coeff, tau=float(meta["tau"]))
        q_def = logmeanexp_negative_sqdist_1d(coeff, def_coeff, tau=float(meta["tau"]))
        parallel_map = (q_def - float(meta["fp_weight"]) * q_fp).reshape(1, 1, side, side)
        parallel_map = F.interpolate(
            parallel_map,
            size=(int(meta["image_size"]), int(meta["image_size"])),
            mode="bilinear",
            align_corners=False,
        )[:, 0]
        parallel_layer_maps.append(parallel_map)

    baseline_map = smooth_clip_map(torch.stack(baseline_layer_maps).mean(dim=0), sigma=float(meta["sigma"]))
    parallel_map = smooth_clip_map(torch.stack(parallel_layer_maps).mean(dim=0), sigma=float(meta["sigma"]))
    parallel_map = activate_margin_map(
        parallel_map, activation=meta["map_activation"], temperature=float(meta["map_temperature"])
    )
    if meta["hybrid_source"] != "none" and float(meta["hybrid_weight"]) > 0:
        parallel_map = (1.0 - float(meta["hybrid_weight"])) * parallel_map + float(meta["hybrid_weight"]) * baseline_map

    raw_score = float(meta["image_fusion_weight"]) * global_anom_prob + (1.0 - float(meta["image_fusion_weight"])) * map_topk_mean(
        baseline_map[0].cpu().numpy().reshape(-1), float(meta["image_score_topk"])
    )
    parallel_score = float(meta["image_fusion_weight"]) * global_anom_prob + (1.0 - float(meta["image_fusion_weight"])) * map_topk_mean(
        parallel_map[0].cpu().numpy().reshape(-1), float(meta["image_score_topk"])
    )
    return raw_score, parallel_score


def _build_backbone_and_banks(model_key: str, preset: str, device: str):
    spec = MODEL_SPECS[model_key]
    summary_path = spec["summaries"][preset]
    meta = load_json(summary_path)["summary"]
    family = spec["family"]
    if family == "rawclip":
        backbone = create_winclip_raw_backbone(
            backbone=meta["backbone"],
            pretrained_dataset=meta["pretrained_dataset"],
            device=device,
            img_resize=int(meta["image_size"]),
            img_cropsize=int(meta["image_size"]),
        )
        fp_banks, def_banks, _, _ = load_rawclip_bank_cache(Path(meta["bank_cache_path"]))
    elif family == "rawimagebind":
        backbone = create_imagebind_raw_backbone(device=device, image_size=int(meta["image_size"]))
        fp_banks, def_banks, _, _ = load_imagebind_bank_cache(Path(meta["bank_cache_path"]))
    else:
        raise ValueError(f"Unsupported family: {family}")
    return backbone, fp_banks, def_banks, meta


def collect_gtfree_topk_scores(
    model_key: str,
    preset: str,
    device: str,
    max_normal_images: int | None,
    max_anomaly_images: int | None,
    seed: int,
) -> tuple[dict[str, np.ndarray], dict]:
    spec = MODEL_SPECS[model_key]
    summary_path = spec["summaries"][preset]
    meta = load_json(summary_path)["summary"]
    target_root = TARGET_ROOTS[preset]
    family = spec["family"]

    if family == "rawclip":
        image_transform, mask_transform = build_clip_transforms(int(meta["image_size"]))
    else:
        image_transform, mask_transform = build_clip_transforms(int(meta["image_size"]))

    backbone, fp_banks, def_banks, meta = _build_backbone_and_banks(model_key, preset, device)
    ds = GenericMetaDataset(
        root=str(target_root),
        image_transform=image_transform,
        mask_transform=mask_transform,
        split="test",
    )

    rng = np.random.default_rng(seed)
    normal_indices = [idx for idx, item in enumerate(ds.items) if int(item["anomaly"]) == 0]
    anomaly_indices = [idx for idx, item in enumerate(ds.items) if int(item["anomaly"]) == 1]
    if max_normal_images is not None and len(normal_indices) > max_normal_images:
        normal_indices = rng.choice(normal_indices, size=max_normal_images, replace=False).tolist()
    if max_anomaly_images is not None and len(anomaly_indices) > max_anomaly_images:
        anomaly_indices = rng.choice(anomaly_indices, size=max_anomaly_images, replace=False).tolist()
    selected_indices = sorted(normal_indices + anomaly_indices)

    out = {
        "raw_anomaly": [],
        "raw_normal": [],
        "parallel_anomaly": [],
        "parallel_normal": [],
    }
    records = []

    with torch.no_grad():
        for idx in selected_indices:
            item = ds[idx]
            anomaly_flag = int(item["anomaly"])
            if family == "rawclip":
                raw_score, parallel_score = _compute_rawclip_scores(backbone, item, fp_banks, def_banks, meta)
            else:
                raw_score, parallel_score = _compute_imagebind_scores(backbone, item, fp_banks, def_banks, meta)
            if anomaly_flag == 1:
                out["raw_anomaly"].append(raw_score)
                out["parallel_anomaly"].append(parallel_score)
            else:
                out["raw_normal"].append(raw_score)
                out["parallel_normal"].append(parallel_score)
            records.append(
                {
                    "image_path": item["img_path"],
                    "cls_name": item["cls_name"],
                    "anomaly": int(anomaly_flag),
                    "raw_score": float(raw_score),
                    "parallel_score": float(parallel_score),
                }
            )

    arrays = {k: np.asarray(v, dtype=np.float32) for k, v in out.items()}
    payload = {
        "meta": {
            "model_key": model_key,
            "model_label": spec["display_name"],
            "preset": preset,
            "preset_label": PRESET_LABELS[preset],
            "target_root": str(target_root),
            "summary_path": str(summary_path),
            "num_anomaly": int(arrays["raw_anomaly"].size),
            "num_normal": int(arrays["raw_normal"].size),
        }
    }
    payload["records"] = records

    del backbone
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return arrays, payload


def save_model_outputs(rows: list[dict], arrays_manifest: dict[str, str], model_label: str, save_dir: Path) -> None:
    with (save_dir / "metrics.json").open("w") as f:
        json.dump({"rows": rows, "arrays": arrays_manifest}, f, indent=2)
    with (save_dir / "metrics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    labels = [r["preset_label"] for r in rows]
    y = np.arange(len(rows))
    raw_auc = [r["raw_auc"] for r in rows]
    par_auc = [r["parallel_auc"] for r in rows]
    raw_ovl = [r["raw_ovl"] for r in rows]
    par_ovl = [r["parallel_ovl"] for r in rows]

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.2), constrained_layout=True)
    ax0, ax1 = axes
    for i in range(len(rows)):
        ax0.plot([raw_auc[i], par_auc[i]], [i, i], color="#9A9A9A", lw=1.8)
        ax0.scatter(raw_auc[i], i, s=58, color="#D95F02", label="Baseline" if i == 0 else None)
        ax0.scatter(par_auc[i], i, s=58, color="#1B9E77", label="OURS" if i == 0 else None)
        ax0.text(max(raw_auc[i], par_auc[i]) + 0.01, i, f"{par_auc[i] - raw_auc[i]:+.2f}", va="center", fontsize=9)
    ax0.set_yticks(y, labels)
    ax0.set_xlim(0.0, 1.02)
    ax0.set_xlabel("AUC(Anomaly-image top-k > Normal-image top-k)")
    ax0.set_title("Ranking Separability")
    ax0.grid(axis="x", alpha=0.15)
    ax0.legend(frameon=False, loc="lower right")

    for i in range(len(rows)):
        ax1.plot([raw_ovl[i], par_ovl[i]], [i, i], color="#9A9A9A", lw=1.8)
        ax1.scatter(raw_ovl[i], i, s=58, color="#D95F02", label="Baseline" if i == 0 else None)
        ax1.scatter(par_ovl[i], i, s=58, color="#1B9E77", label="OURS" if i == 0 else None)
        ax1.text(max(raw_ovl[i], par_ovl[i]) + 0.01, i, f"{raw_ovl[i] - par_ovl[i]:+.2f}", va="center", fontsize=9)
    ax1.set_yticks(y, labels)
    ax1.set_xlim(0.0, 1.02)
    ax1.set_xlabel("Overlap Coefficient (OVL)")
    ax1.set_title("Entanglement")
    ax1.grid(axis="x", alpha=0.15)

    fig.suptitle(f"GT-free Entanglement Metrics for {model_label}", fontsize=13)
    fig.savefig(save_dir / "entanglement_summary.png", dpi=220, bbox_inches="tight")
    fig.savefig(save_dir / "entanglement_summary.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser("Collect GT-free entanglement metrics for raw-family backbones")
    parser.add_argument(
        "--model_keys",
        type=str,
        default="rawclip_vitl,rawclip_vitl14openai,rawclip_vith14,rawimagebind",
    )
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--max_normal_images", type=int, default=64)
    parser.add_argument("--max_anomaly_images", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--save_root",
        type=str,
        default=str(RESULTS / "rawfamily_gtfree_entanglement"),
    )
    args = parser.parse_args()

    model_keys = [k.strip() for k in args.model_keys.split(",") if k.strip()]
    save_root = Path(args.save_root)
    save_root.mkdir(parents=True, exist_ok=True)

    manifest = {}
    for model_key in model_keys:
        spec = MODEL_SPECS[model_key]
        model_dir = save_root / model_key
        model_dir.mkdir(parents=True, exist_ok=True)
        rows = []
        arrays_manifest = {}
        for preset in PRESET_LABELS:
            arrays, payload = collect_gtfree_topk_scores(
                model_key=model_key,
                preset=preset,
                device=args.device,
                max_normal_images=args.max_normal_images,
                max_anomaly_images=args.max_anomaly_images,
                seed=args.seed,
            )
            raw = distribution_metrics(arrays["raw_anomaly"], arrays["raw_normal"])
            parallel = distribution_metrics(arrays["parallel_anomaly"], arrays["parallel_normal"])
            row = {
                "model_key": model_key,
                "model_label": spec["display_name"],
                "preset": preset,
                "preset_label": PRESET_LABELS[preset],
                "num_anomaly": int(payload["meta"]["num_anomaly"]),
                "num_normal": int(payload["meta"]["num_normal"]),
                "raw_auc": raw["auc"],
                "parallel_auc": parallel["auc"],
                "raw_ovl": raw["ovl"],
                "parallel_ovl": parallel["ovl"],
                "raw_bayes_error_lb": raw["bayes_error_lb"],
                "parallel_bayes_error_lb": parallel["bayes_error_lb"],
                "raw_mean_gap": raw["mean_gap"],
                "parallel_mean_gap": parallel["mean_gap"],
                "raw_cohens_d": raw["cohens_d"],
                "parallel_cohens_d": parallel["cohens_d"],
                "auc_gain": parallel["auc"] - raw["auc"],
                "ovl_reduction": raw["ovl"] - parallel["ovl"],
                "bayes_error_reduction": raw["bayes_error_lb"] - parallel["bayes_error_lb"],
            }
            rows.append(row)
            arrays_file = model_dir / f"{preset}_arrays.npz"
            np.savez_compressed(arrays_file, **arrays)
            arrays_manifest[preset] = str(arrays_file)
            print(
                json.dumps(
                    {
                        "model_key": model_key,
                        "preset": preset,
                        "auc_gain": row["auc_gain"],
                        "ovl_reduction": row["ovl_reduction"],
                    }
                ),
                flush=True,
            )
        save_model_outputs(rows, arrays_manifest, spec["display_name"], model_dir)
        manifest[model_key] = {
            "display_name": spec["display_name"],
            "metrics_json": str(model_dir / "metrics.json"),
            "figure_png": str(model_dir / "entanglement_summary.png"),
        }

    with (save_root / "manifest.json").open("w") as f:
        json.dump(manifest, f, indent=2)


if __name__ == "__main__":
    main()
