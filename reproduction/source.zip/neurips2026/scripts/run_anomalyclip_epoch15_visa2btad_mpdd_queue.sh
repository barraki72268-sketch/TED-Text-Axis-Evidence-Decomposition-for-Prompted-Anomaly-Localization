#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/data/pilab-kingjinyoung/ADPretrain-CLIP"
PY="/mnt/data/envs/patchcore-conda/bin/python"
CKPT="$ROOT/neurips2026/AnomalyCLIP/checkpoints/9_12_4_multiscale/epoch_15.pth"
SOURCE_ROOT="$ROOT/neurips2026/data/VisA_pytorch_official/1cls"
BANK_CACHE="$ROOT/neurips2026/results/bank_cache/anomalyclip_visa_official1cls_epoch15_multiscale.pt"

cd "$ROOT"

$PY neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py \
  --device cuda:1 \
  --checkpoint_path "$CKPT" \
  --heldout_class bottle \
  --source_root "$SOURCE_ROOT" \
  --source_dataset visa \
  --target_root "$ROOT/neurips2026/data/BTAD_official" \
  --target_dataset btad \
  --target_mode test \
  --bank_cache_path "$BANK_CACHE" \
  --save_dir "$ROOT/neurips2026/results/anomalyclip_text_decomposition_score_visa2btad_epoch15"

$PY neurips2026/scripts/probe_anomalyclip_text_decomposition_score.py \
  --device cuda:1 \
  --checkpoint_path "$CKPT" \
  --heldout_class bottle \
  --source_root "$SOURCE_ROOT" \
  --source_dataset visa \
  --target_root /mnt/data/MPDD \
  --target_dataset mpdd \
  --target_mode test \
  --bank_cache_path "$BANK_CACHE" \
  --save_dir "$ROOT/neurips2026/results/anomalyclip_text_decomposition_score_visa2mpdd_epoch15"
