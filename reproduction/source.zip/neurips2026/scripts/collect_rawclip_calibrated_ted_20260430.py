from __future__ import annotations

import argparse
import json
from pathlib import Path


ROOT = Path("/mnt/data/pilab-kingjinyoung/ted-reproduce-20261008/snapshot")
DEFAULT_RESULT_ROOT = ROOT / "neurips2026/results/rawclip_calibrated_ted_20260430"

BACKBONES = [
    ("ViT-L-14-336", "rawclip_vitl336"),
    ("ViT-B-16-plus-240", "rawclip_vitbplus"),
    ("ViT-L(OpenAI)", "rawclip_vitl_openai"),
    ("ViT-H(laion2b)", "rawclip_vith14"),
    ("ImageBind", "rawimagebind"),
]
TARGETS = [
    ("MVTec", "visa2mvtec"),
    ("VisA", "mvtec2visa"),
    ("MPDD", "mvtec2mpdd"),
    ("BTAD", "mvtec2btad"),
]
METHODS = [
    ("Baseline", "baseline_txt"),
    ("Train-free TED", "parallel_margin"),
    ("Calibrated TED", "ted_calibrated"),
]
METRICS = [
    ("I-AUC", "image_auroc"),
    ("P-AUC", "pixel_auroc"),
    ("PRO", "pixel_aupro"),
    ("AP", "pixel_ap"),
]


def load_mean(result_root: Path, prefix: str, transfer: str, mode: str) -> dict | None:
    path = result_root / f"{prefix}_{transfer}" / "summary.json"
    if not path.exists():
        return None
    payload = json.loads(path.read_text())
    for row in payload["rows"]:
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return row
    return None


def fmt(row: dict | None) -> str:
    if row is None:
        return "--.-- / --.-- / --.-- / --.--"
    return " / ".join(f"{100*float(row[key]):.1f}" for _, key in METRICS)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result_root", type=str, default=str(DEFAULT_RESULT_ROOT))
    parser.add_argument("--title", type=str, default="Raw backbone calibrated TED")
    args = parser.parse_args()
    result_root = Path(args.result_root)
    print(f"% {args.title}. Each cell: I-AUC / P-AUC / PRO / AP")
    for label, prefix in BACKBONES:
        print(f"\n% Backbone: {label}")
        for method_label, mode in METHODS:
            cells = [fmt(load_mean(result_root, prefix, transfer, mode)) for _, transfer in TARGETS]
            print(method_label + " & " + " & ".join(cells) + r" \\")


if __name__ == "__main__":
    main()
