#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "neurips2026" / "results"
OUT = RESULTS / "final_metric_and_novelty_tables"

TRAINING_CONTROL = RESULTS / "training_control_20260504"
SOURCE_BANK_MD = OUT / "source_bank_control_values_20260504.md"
ADAPTED_HOST_CSV = OUT / "adapted_host_b_t_c_records_20260502.csv"

VARIANTS = ("correct", "label_shuffle", "label_swap", "random_subspace")
PIXEL_METRICS = ("P-AUC", "PRO", "AP")


def pct(x: Any) -> float | None:
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    if not np.isfinite(v):
        return None
    return v * 100.0 if abs(v) <= 1.5 else v


def metric_blob(blob: dict[str, Any] | None) -> dict[str, float] | None:
    if not blob:
        return None
    return {
        "I-AUC": pct(blob.get("image_auc", blob.get("image_auroc"))),
        "P-AUC": pct(blob.get("pixel_auc", blob.get("pixel_auroc"))),
        "PRO": pct(blob.get("pixel_pro", blob.get("pixel_aupro"))),
        "AP": pct(blob.get("pixel_ap")),
    }


def first_value(mapping: dict[str, Any] | None, preferred: str | None = None) -> dict[str, Any] | None:
    if not isinstance(mapping, dict) or not mapping:
        return None
    if preferred and preferred in mapping:
        return mapping[preferred]
    return mapping[sorted(mapping.keys())[0]]


def row_mean_metrics(rows: list[dict[str, Any]], mode: str) -> dict[str, float] | None:
    for row in rows:
        if row.get("target_label") == "mean" and row.get("mode") == mode:
            return metric_blob(row)
    return None


def extract_metrics(summary_path: Path) -> tuple[dict[str, float], dict[str, float]] | None:
    data = json.loads(summary_path.read_text())

    if "mean" in data:
        mean = data["mean"]
        if "baseline" in mean:
            baseline = metric_blob(mean.get("baseline"))
            cted = metric_blob(first_value(mean.get("candidates"), "prescore_calibrated_alpha_1"))
            if baseline and cted:
                return baseline, cted
        if "baseline_official" in mean:
            baseline = metric_blob(mean.get("baseline_official"))
            cted = metric_blob(first_value(mean.get("parallel"), "branch_calibrated_alpha_0.5"))
            if baseline and cted:
                return baseline, cted

    rows = data.get("rows")
    if isinstance(rows, list):
        baseline = row_mean_metrics(rows, "baseline_txt")
        cted = (
            row_mean_metrics(rows, "ted_calibrated")
            or row_mean_metrics(rows, "ted_calibrated_vl")
            or row_mean_metrics(rows, "ted_calibrated_tl")
        )
        if baseline and cted:
            return baseline, cted

    return None


def parse_training_control_name(name: str) -> tuple[str, str, str] | None:
    for variant in sorted(VARIANTS, key=len, reverse=True):
        suffix = f"_{variant}_seed"
        if suffix not in name:
            continue
        left = name.split(suffix, 1)[0]
        if left.startswith("aaclip_vitl_openai224_"):
            return "AA-CLIP", left.removeprefix("aaclip_vitl_openai224_"), variant
        if left.startswith("adaclip_vitl336_"):
            return "AdaCLIP", left.removeprefix("adaclip_vitl336_"), variant
        if left.startswith("faprompt_vitl336_"):
            return "FAPrompt", left.removeprefix("faprompt_vitl336_"), variant
        if left.startswith("adaptclip_vl_last24_"):
            return "AdaptCLIP", left.removeprefix("adaptclip_vl_last24_"), variant
        if left.startswith("anomalyclip_last24_"):
            return "AnomalyCLIP", left.removeprefix("anomalyclip_last24_"), variant
    return None


def collect_training_controls() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(TRAINING_CONTROL.glob("*/summary.json")):
        parsed = parse_training_control_name(path.parent.name)
        extracted = extract_metrics(path)
        if parsed is None or extracted is None:
            continue
        host, transfer, variant = parsed
        baseline, cted = extracted
        row: dict[str, Any] = {
            "host": host,
            "transfer": transfer,
            "variant": variant,
            "path": str(path.relative_to(ROOT)),
        }
        for metric in ("I-AUC",) + PIXEL_METRICS:
            row[f"base_{metric}"] = baseline.get(metric)
            row[f"cted_{metric}"] = cted.get(metric)
            if baseline.get(metric) is None or cted.get(metric) is None:
                row[f"delta_{metric}"] = None
            else:
                row[f"delta_{metric}"] = cted[metric] - baseline[metric]
        row["avg_pixel_delta"] = float(np.mean([row[f"delta_{m}"] for m in PIXEL_METRICS]))
        rows.append(row)
    return rows


def collect_control_pairs(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key: dict[tuple[str, str], dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        by_key[(row["host"], row["transfer"])][row["variant"]] = row

    out: list[dict[str, Any]] = []
    for (host, transfer), variants in by_key.items():
        correct = variants.get("correct")
        if not correct:
            continue
        for control_name in ("label_swap", "label_shuffle", "random_subspace"):
            control = variants.get(control_name)
            if not control:
                continue
            row = {
                "host": host,
                "transfer": transfer,
                "control": control_name,
                "correct_avg_pixel_delta": correct["avg_pixel_delta"],
                "control_avg_pixel_delta": control["avg_pixel_delta"],
                "control_drop": correct["avg_pixel_delta"] - control["avg_pixel_delta"],
            }
            for metric in PIXEL_METRICS:
                row[f"correct_{metric}"] = correct[f"delta_{metric}"]
                row[f"control_{metric}"] = control[f"delta_{metric}"]
                row[f"drop_{metric}"] = correct[f"delta_{metric}"] - control[f"delta_{metric}"]
            out.append(row)
    return out


def collect_adapted_host_top_gains(limit: int = 30) -> list[dict[str, Any]]:
    if not ADAPTED_HOST_CSV.exists():
        return []
    raw = list(csv.DictReader(ADAPTED_HOST_CSV.open()))
    groups: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in raw:
        if row["metric"] in ("p_auc", "p_pro", "p_ap") and row.get("delta_c"):
            groups[(row["host"], row["backbone"], row["target"])].append(row)
    rows = []
    for (host, backbone, target), items in groups.items():
        if len(items) < 3:
            continue
        deltas = {item["metric"]: float(item["delta_c"]) for item in items}
        rows.append(
            {
                "host": host,
                "backbone": backbone,
                "target": target,
                "delta_p_auc": deltas.get("p_auc"),
                "delta_pro": deltas.get("p_pro"),
                "delta_ap": deltas.get("p_ap"),
                "avg_pixel_delta": float(np.mean([deltas.get("p_auc"), deltas.get("p_pro"), deltas.get("p_ap")])),
            }
        )
    return sorted(rows, key=lambda x: x["avg_pixel_delta"], reverse=True)[:limit]


def fmt(x: float | None) -> str:
    if x is None or not np.isfinite(x):
        return "--"
    return f"{x:+.2f}"


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("")
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(
    training_rows: list[dict[str, Any]],
    pair_rows: list[dict[str, Any]],
    top_host_rows: list[dict[str, Any]],
) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    lines += [
        "# Defense-Ready Positive Results",
        "",
        "All values are C-TED minus the corresponding host baseline. No target mask/score selection is used in these control runs.",
        "",
        "## 1. Strong Source-Supervision Controls",
        "",
        "Sorted by the drop from correct C-TED to the corrupted control.",
        "",
        "| Host | Transfer | Control | Correct avg | Control avg | Drop | Drop P-AUC | Drop PRO | Drop AP |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in sorted(pair_rows, key=lambda x: x["control_drop"], reverse=True):
        if row["control"] == "random_subspace":
            continue
        lines.append(
            "| {host} | {transfer} | {control} | {correct} | {ctrl} | {drop} | {pa} | {pro} | {ap} |".format(
                host=row["host"],
                transfer=row["transfer"],
                control=row["control"].replace("_", " "),
                correct=fmt(row["correct_avg_pixel_delta"]),
                ctrl=fmt(row["control_avg_pixel_delta"]),
                drop=fmt(row["control_drop"]),
                pa=fmt(row["drop_P-AUC"]),
                pro=fmt(row["drop_PRO"]),
                ap=fmt(row["drop_AP"]),
            )
        )

    lines += [
        "",
        "## 2. Correct C-TED Positive Control Runs",
        "",
        "| Host | Transfer | Avg pixel gain | ΔP-AUC | ΔPRO | ΔAP |",
        "|---|---|---:|---:|---:|---:|",
    ]
    correct_rows = [r for r in training_rows if r["variant"] == "correct"]
    for row in sorted(correct_rows, key=lambda x: x["avg_pixel_delta"], reverse=True):
        lines.append(
            f"| {row['host']} | {row['transfer']} | {fmt(row['avg_pixel_delta'])} | "
            f"{fmt(row['delta_P-AUC'])} | {fmt(row['delta_PRO'])} | {fmt(row['delta_AP'])} |"
        )

    lines += [
        "",
        "## 3. Source-Bank Controls Already Available",
        "",
    ]
    if SOURCE_BANK_MD.exists():
        lines.extend(SOURCE_BANK_MD.read_text().splitlines()[3:])
    else:
        lines.append("Source-bank control table not found.")

    lines += [
        "",
        "## 4. Strong Adapted-Host C-TED Gains",
        "",
        "| Host | Backbone | Target | Avg pixel gain | ΔP-AUC | ΔPRO | ΔAP |",
        "|---|---|---|---:|---:|---:|---:|",
    ]
    for row in top_host_rows:
        lines.append(
            f"| {row['host']} | {row['backbone']} | {row['target']} | {fmt(row['avg_pixel_delta'])} | "
            f"{fmt(row['delta_p_auc'])} | {fmt(row['delta_pro'])} | {fmt(row['delta_ap'])} |"
        )

    (OUT / "defense_ready_positive_results_20260504.md").write_text("\n".join(lines) + "\n")


def write_wraptable(pair_rows: list[dict[str, Any]]) -> None:
    selected = []
    preferred = [
        ("AA-CLIP", "visa2btad", "label_swap"),
        ("AA-CLIP", "mvtec2btad", "label_swap"),
        ("AA-CLIP", "mvtec2btad", "label_shuffle"),
        ("AdaCLIP", "visa2btad", "label_swap"),
        ("AdaCLIP", "visa2mpdd", "label_swap"),
    ]
    for key in preferred:
        match = [r for r in pair_rows if (r["host"], r["transfer"], r["control"]) == key]
        if match:
            selected.append(match[0])
    if not selected:
        selected = sorted(pair_rows, key=lambda x: x["control_drop"], reverse=True)[:5]

    tex_lines = [
        r"\begin{wraptable}{r}{0.57\columnwidth}",
        r"\vspace{-0.8em}",
        r"\centering",
        r"\caption{",
        r"Source-supervision control for C-TED.",
        r"All variants use the same source-only calibration budget and residual capacity.",
        r"Values report gains over the host baseline; corrupted labels remove the gain.",
        r"}",
        r"\label{tab:cted_source_supervision_control}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.0pt}",
        r"\renewcommand{\arraystretch}{1.03}",
        r"\resizebox{\linewidth}{!}{%",
        r"\begin{tabular}{lllrrrr}",
        r"\toprule",
        r"Host & Transfer & Ctrl & C avg & Ctrl avg & $\Delta$PRO & $\Delta$AP \\",
        r"\midrule",
    ]
    for row in selected:
        transfer_label = row["transfer"].replace("2", r"$\to$")
        control_label = "Swap" if row["control"] == "label_swap" else "Shuffle"
        tex_lines.append(
            f"{row['host']} & {transfer_label} & {control_label} & "
            f"{fmt(row['correct_avg_pixel_delta'])} & {fmt(row['control_avg_pixel_delta'])} & "
            f"{fmt(row['drop_PRO'])} & {fmt(row['drop_AP'])} \\\\"
        )
    tex_lines += [
        r"\bottomrule",
        r"\end{tabular}%",
        r"}",
        r"\vspace{-0.9em}",
        r"\end{wraptable}",
        "",
    ]
    (OUT / "cted_source_supervision_control_wraptable_20260504.tex").write_text("\n".join(tex_lines))


def draw_source_supervision_figure(pair_rows: list[dict[str, Any]]) -> None:
    preferred = [
        ("AA-CLIP", "visa2btad", "label_swap"),
        ("AA-CLIP", "mvtec2btad", "label_swap"),
        ("AA-CLIP", "mvtec2btad", "label_shuffle"),
        ("AdaCLIP", "visa2btad", "label_swap"),
        ("AdaCLIP", "visa2mpdd", "label_swap"),
    ]
    selected = []
    for key in preferred:
        match = [r for r in pair_rows if (r["host"], r["transfer"], r["control"]) == key]
        if match:
            selected.append(match[0])
    if not selected:
        return

    labels = [
        f"{r['host'].replace('-CLIP', '')}\n{r['transfer'].replace('2', '→')}\n{r['control'].replace('_', ' ')}"
        for r in selected
    ]
    x = np.arange(len(selected))
    w = 0.34
    correct = np.array([r["correct_avg_pixel_delta"] for r in selected], dtype=float)
    control = np.array([r["control_avg_pixel_delta"] for r in selected], dtype=float)
    drops = correct - control

    fig, ax = plt.subplots(figsize=(7.1, 2.75))
    ax.bar(x - w / 2, correct, width=w, color="#2F6F73", label="Correct C-TED")
    ax.bar(x + w / 2, control, width=w, color="#B85450", label="Corrupted control")
    ax.axhline(0.0, color="#222222", lw=0.8)
    ax.set_ylim(float(min(control.min(), 0.0)) - 1.0, float(max(correct.max(), 0.0)) + 2.4)
    ax.set_ylabel("Avg. pixel gain", fontsize=9.5, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=7.4, fontweight="bold")
    ax.tick_params(axis="y", labelsize=8.5)
    ax.grid(axis="y", color="#E6E1D8", lw=0.7)
    ax.set_axisbelow(True)
    for i, (c, ctrl, drop) in enumerate(zip(correct, control, drops)):
        ymax = max(c, ctrl)
        ax.text(
            i,
            ymax + 0.55,
            f"drop {drop:+.1f}",
            ha="center",
            va="bottom",
            fontsize=7.5,
            fontweight="bold",
            color="#222222",
        )
    ax.legend(frameon=False, loc="upper right", fontsize=8.5, ncol=2)
    ax.set_title("Source-supervision controls", loc="left", fontsize=10.5, fontweight="bold", pad=2)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    fig.tight_layout(pad=0.5)
    fig.savefig(ROOT / "figure" / "source_supervision_control_20260504.pdf", bbox_inches="tight")
    fig.savefig(ROOT / "figure" / "source_supervision_control_20260504.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    training_rows = collect_training_controls()
    pair_rows = collect_control_pairs(training_rows)
    top_host_rows = collect_adapted_host_top_gains()

    write_csv(OUT / "training_control_all_deltas_20260504.csv", training_rows)
    write_csv(OUT / "training_control_pair_drops_20260504.csv", pair_rows)
    write_csv(OUT / "adapted_host_top_cted_gains_20260504.csv", top_host_rows)
    write_markdown(training_rows, pair_rows, top_host_rows)
    write_wraptable(pair_rows)
    draw_source_supervision_figure(pair_rows)

    print(
        json.dumps(
            {
                "training_rows": len(training_rows),
                "pair_rows": len(pair_rows),
                "top_host_rows": len(top_host_rows),
                "markdown": str((OUT / "defense_ready_positive_results_20260504.md").relative_to(ROOT)),
                "wraptable": str((OUT / "cted_source_supervision_control_wraptable_20260504.tex").relative_to(ROOT)),
                "figure": "figure/source_supervision_control_20260504.pdf",
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
